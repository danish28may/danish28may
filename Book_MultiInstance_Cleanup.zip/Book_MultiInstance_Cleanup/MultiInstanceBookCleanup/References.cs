﻿using DocumentFormat.OpenXml.Packaging;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using System.IO.Packaging;
using OpenXmlPowerTools;
using DocumentFormat.OpenXml.Wordprocessing;
using DocumentFormat.OpenXml;
using System.Xml;
using System.Text.RegularExpressions;
using System.IO;
using System.Configuration;

namespace MultiInstanceBookCleanup
{
    class References
    {
        public static OnOffValue History { get; private set; }
        public static string Id { get; private set; }
        public static List<string> singleAuthorWithYear = new List<string>();//Developer Name:Priyanka Vishwakarma,Requirement:check valid author for reference callout.

        public static List<string> LstReferenceStyleColl = null;

        public static void MergeReferenceElements(string strWordDoc, string strRefPattern, string strJournalColl, string strPublisherColl)

        {
            try
            {
                // Read the Reference Pattern Lookup and sort the pattern on length //
                // Read the Reference patterns from the configuration and store in list
                List<string> strRefPatterns = new List<string>();
                strRefPatterns = GlobalMethods.ReadAndStoreFileValuesInArray(strRefPattern);

                UpdateReferencePatternIndex(strRefPatterns, strRefPattern);

                // Update the Reference Pattern Lookup File //

                LstReferenceStyleColl = new List<string>();
                LstReferenceStyleColl.Clear();

                GlobalMethods.strReferenceStyleDB = ConfigurationManager.AppSettings.Get("ReferenceStyleDB");

                LstReferenceStyleColl = GlobalMethods.ReadAndStoreFileValuesInArray(GlobalMethods.strReferenceStyleDB);

                Ref_StyleApplied(strWordDoc);
                AutoStructuringStyles.Ref1_StyleApplied(strWordDoc); //04102019
                AddNewJournalTitle(strWordDoc, strJournalColl); //Developer name :Priyanka Vishwakarma. Date:12_9_2019, Requirement:journalList & PublisherList is not available in config file then it should read from input and added in config file.  ,Integrated By:Vikas sir. 
                AddNewPublisher(strWordDoc, strPublisherColl); //Developer name :Priyanka Vishwakarma. Date:12_9_2019, Requirement:journalList & PublisherList is not available in config file then it should read from input and added in config file.  ,Integrated By:Vikas sir. 
                MergeReferenceElementsIntoOneGroup(strWordDoc, strRefPattern, strJournalColl, strPublisherColl);

                //Developer Name:Priyanka Vishwakarma,Date:10-02-2021, Requirement:Add functions for reference Marking for sage book input.
                if (GlobalMethods.strClientName.ToLower() == "jaypee") //10-02-2021
                {
                    var REF1ParaFound = CheckIfREF1ParaFind(strWordDoc);
                    if (REF1ParaFound)
                    {

                        GlobalMethods.refStructureDone = true;
                        bool AlreadyStructuredRef = CheckAllreadyStructuredReference(strWordDoc); //Developer Name:Priyanka Vishwakarma,Date:31-07-2021,Add function for avoid to structure structured references..
                        if (AlreadyStructuredRef == false)
                        {
                            ApplybibnumberCharstyle(strWordDoc);
                            SearchAndReplace.GeneralSearchAndReplaceInRef(strWordDoc);
                            SearchAndReplace.ReferenceSearchAndReplaceVolumeIssueForJaypeeBasisOftextfile(strWordDoc);// Developer Name:Priyanka Vishwakarma, Date:30-10-2021, Requirement: add function for mark volume,issue,fpage and lpage and doi 
                            MarkVolumeIssueFpageLpage(strWordDoc);
                            SearchAndReplace.ReferenceSearchAndReplaceSurnameFnameForJaypee(strWordDoc);//// Developer Name:Priyanka Vishwakarma, Date:30-10-2021, Requirement: add function for mark surname and fname
                            MarkSurnameFname(strWordDoc);
                            applyetalJaypee(strWordDoc);
                            MarkArticleAndJournalTitle(strWordDoc);
                            SearchAndReplace.ApplyJournalTitleForJaypee(strWordDoc);//Developer Name:Priyanka Vishwakarma, Date:10-09-2021, Requirement: add function for marking journal title
                            SearchAndReplace.ApplyPMIDAndPMCIDForJaypee(strWordDoc);//Developer Name:Priyanka Vishwakarma, Date:27-1-2022, Requirement: apply PMID and PMCID char style.
                            RemovePMIDandPMCIDText(strWordDoc);//Developer Name:Priyanka Vishwakarma, Date:27-1-2022, Requirement: apply PMID and PMCID char style.
                            ChangeRefTypeOnBasisofJournalTitleandPubname(strWordDoc);//Developer Name:Priyanka Vishwakarma, Date:1-12-2021, Requirement: add function for add <jrn> tag on basis of journal titile text file.
                            ApplybibArticleinJrnRefInJaypee(strWordDoc);//Developer Name:Priyanka  Vishwakarma Date:25-10-2021, Requirement:add function for mark articletitle in jrn ref.
                        }
                        
                        MarkCitationsInDocumentForJypee(strWordDoc); //Mark refference callout
                       
                    }


                    MarkCitationsInDocument(strWordDoc);
                }
                else if (GlobalMethods.strClientName.ToLower() == "sage") //10-02-2021
                {

                    //SearchAndReplace.ReferenceSearchAndReplaceVolumeIssue(strWordDoc);  //10-10-2020
                    //applyFpageandLpage(strWordDoc);
                    //ReferenceSearchAndReplaceSurnameFname(strWordDoc);//09-02-2021
                    //applyFirstnameSurname(strWordDoc);//09-02-2021
                    //RemoveFnameandsurnameafteryear(strWordDoc);//09-02-2021
                    var REF1ParaFound = CheckIfREF1ParaFind(strWordDoc);
                    if (REF1ParaFound)
                    {
                        // GlobalMethods.refStructureDone = true;
                        ApplybibnumberCharstyle(strWordDoc);
                        SearchAndReplace.ReferenceSearchAndReplaceSurnameFname(strWordDoc);
                        RemoveFnameandsurnameafteryear(strWordDoc);
                        applyFirstnameSurname(strWordDoc);

                        SearchAndReplace.ReferenceSearchAndReplaceVolumeIssue(strWordDoc);  //10-10-2020
                        applyFpageandLpage(strWordDoc);

                        SearchAndReplace.ReferenceSearchAndReplace(strWordDoc);  //10-10-2020
                        AdditalicRunpropertiesforReference(strWordDoc);
                        ChangeRefTypeOnBasisofJournalTitleandPubname(strWordDoc);
                        MergeReferenceElementsIntoOneGroupSage(strWordDoc, strRefPattern, strJournalColl, strPublisherColl);
                        applyJournalTitleToitalictext(strWordDoc);//Developer Name:Priyanka Vishwakarma, Date:15-09-2021,Requirement:apply bibjournal to italic text in reference.
                        ApplybibArticleinBookRef(strWordDoc);
                        ApplybibArticleinJrnRef(strWordDoc);
                        List<string> strRefNumColl = MarkCitationsInDocumentForINF(strWordDoc);
                        singleAuthorWithYear = checkedAllSingleAuthorRef(strWordDoc, singleAuthorWithYear);
                        SearchAndReplace.applyCitebibcharSage(strWordDoc, strRefNumColl, singleAuthorWithYear);
                    }
                }

                //End on 10-02-2021
                MarkCitationsInDocument(strWordDoc);

                // ReferenceRenumber(strWordDoc);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void MarkCitationsInDocument(string strWordDoc)
        {
            try
            {
                // Reference Renumbering //

                List<string> strRefNumColl = new List<string>();

                using (WordprocessingDocument WPD = WordprocessingDocument
                    .Open(strWordDoc, true))
                {
                    SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                    {
                        //RemoveComments = false,
                        RemoveContentControls = true,
                        RemoveEndAndFootNotes = false,
                        //RemoveFieldCodes = false,
                        RemoveLastRenderedPageBreak = true,
                        RemovePermissions = true,
                        RemoveProof = true,
                        RemoveRsidInfo = true,
                        RemoveSmartTags = true,
                        RemoveSoftHyphens = false,
                        ReplaceTabsWithSpaces = false,
                    };

                    MarkupSimplifier.SimplifyMarkup(WPD, settings);

                    MainDocumentPart MDP = WPD.MainDocumentPart;

                    Document D = MDP.Document;

                    //string strRefNum = "";
                    bool bRefNumberStart = false;
                    //int nRefNum = 0;

                    int nRefIndex = 0;

                    strRefNumColl.Clear();





                    // Search all Paragraphs that is "TOC1 to TOC3" style.
                    foreach (Paragraph P in D.Descendants<Paragraph>().ToList().
                    Where(e => e.ParagraphProperties != null
                        && e.ParagraphProperties.ParagraphStyleId != null
                        && e.ParagraphProperties.ParagraphStyleId.Val == "REF1"))
                    {
                        if (P.HasChildren)
                        {
                            if (P.Descendants<Run>().Count() > 0)
                            {
                                foreach (Run R in P.Descendants<Run>().ToList())
                                {
                                    if (R.RunProperties != null)
                                    {
                                        if (R.RunProperties.RunStyle != null)
                                        {
                                            if (R.RunProperties.RunStyle.Val == "bibnumber")
                                            {
                                                bRefNumberStart = true;
                                                nRefIndex++;
                                            }
                                            else
                                            {
                                                bRefNumberStart = false;
                                            }
                                        }
                                    }
                                    foreach (Text T in R.Descendants<Text>().ToList())
                                    {
                                        if (bRefNumberStart)
                                        {
                                            if (T.Text != ".")
                                            {
                                                strRefNumColl.Add(T.Text);
                                                bRefNumberStart = false;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Compare the Reference Number with Reference Citation //

                    bool bRefCiteStart = false;

                    foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                    {
                        if (P.HasChildren)
                        {
                            if (P.Descendants<Run>().Count() > 0)
                            {
                                foreach (Run R in P.Descendants<Run>().ToList())
                                {
                                    if (R.RunProperties != null)
                                    {
                                        if (R.RunProperties.VerticalTextAlignment != null)
                                        {
                                            if (R.RunProperties.VerticalTextAlignment.Val == "superscript")
                                            {
                                                bRefCiteStart = true;
                                            }

                                        }
                                        if (R.RunProperties.RunStyle != null)
                                        {
                                            if (R.RunProperties.RunStyle.Val == "citebib")
                                            {
                                                bRefCiteStart = false;
                                            }
                                            //else
                                            //{
                                            //    bRefCiteStart = false;
                                            //}
                                        }
                                    }
                                    foreach (Text T in R.Descendants<Text>().ToList())
                                    {
                                        bool bCiteNumExistInRef = false;

                                        if (bRefCiteStart)
                                        {
                                            if (T.Text.Contains(","))
                                            {
                                                // Split the containts on comma and check if the numbers are coming in references //
                                                string strRefCite = T.Text;
                                                string[] strRefCiteColl;
                                                strRefCiteColl = strRefCite.Split(',');

                                                if (strRefCiteColl != null)
                                                {
                                                    if (strRefCiteColl.Length > 0)
                                                    {
                                                        int nIndex = 0;

                                                        for (nIndex = 0; nIndex < strRefCiteColl.Length; nIndex++)
                                                        {
                                                            if (strRefNumColl.Contains(strRefCiteColl[nIndex]))
                                                            {
                                                                bCiteNumExistInRef = true;
                                                            }
                                                            else
                                                            {
                                                                bCiteNumExistInRef = false;
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                            else
                                            {
                                                if (strRefNumColl.Contains(T.Text))
                                                {
                                                    bCiteNumExistInRef = true;
                                                }
                                            }

                                            if (bCiteNumExistInRef)
                                            {
                                                if (R.RunProperties != null)
                                                {
                                                    if (R.RunProperties.RunStyle != null)
                                                    {
                                                        R.RunProperties.RunStyle.Val = "citebib";
                                                        bRefCiteStart = false;
                                                        break;
                                                    }
                                                    else
                                                    {
                                                        RunStyle rs = new RunStyle();
                                                        rs.Val = "citebib";
                                                        R.RunProperties.Append(rs);
                                                        bRefCiteStart = false;
                                                        break; ;
                                                    }
                                                }
                                                else
                                                {
                                                    Run run = new Run(new RunProperties(new RunStyle() { Val = "citebib" }));
                                                    R.Append(run);
                                                    bRefCiteStart = false;
                                                    break;
                                                }
                                            }
                                            else
                                            {
                                                bRefCiteStart = false;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // ================================= //
                    D.Save();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void ReferenceRenumber(string strWordDoc)
        {
            try
            {
                // Reference Renumbering //

                List<string> strRefNumColl = new List<string>();

                using (WordprocessingDocument WPD = WordprocessingDocument
                    .Open(strWordDoc, true))
                {
                    SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                    {
                        //RemoveComments = false,
                        RemoveContentControls = true,
                        RemoveEndAndFootNotes = false,
                        //RemoveFieldCodes = false,
                        RemoveLastRenderedPageBreak = true,
                        RemovePermissions = true,
                        RemoveProof = true,
                        RemoveRsidInfo = true,
                        RemoveSmartTags = true,
                        RemoveSoftHyphens = false,
                        ReplaceTabsWithSpaces = false,
                    };

                    MarkupSimplifier.SimplifyMarkup(WPD, settings);

                    MainDocumentPart MDP = WPD.MainDocumentPart;

                    Document D = MDP.Document;

                    //string strRefNum = "";
                    bool bRefNumberStart = false;
                    //int nRefNum = 0;

                    int nRefIndex = 0;

                    strRefNumColl.Clear();

                    // Search all Paragraphs that is "TOC1 to TOC3" style.
                    foreach (Paragraph P in D.Descendants<Paragraph>().ToList().
                        Where(e => e.ParagraphProperties != null
                            && e.ParagraphProperties.ParagraphStyleId != null
                            && e.ParagraphProperties.ParagraphStyleId.Val == "REF1"))
                    {
                        if (P.HasChildren)
                        {
                            if (P.Descendants<Run>().Count() > 0)
                            {
                                foreach (Run R in P.Descendants<Run>().ToList())
                                {
                                    if (R.RunProperties != null)
                                    {
                                        if (R.RunProperties.RunStyle != null)
                                        {
                                            if (R.RunProperties.RunStyle.Val == "bibnumber")
                                            {
                                                bRefNumberStart = true;
                                                nRefIndex++;
                                            }
                                            else
                                            {
                                                bRefNumberStart = false;
                                            }
                                        }
                                    }
                                    foreach (Text T in R.Descendants<Text>().ToList())
                                    {
                                        if (bRefNumberStart)
                                        {
                                            if (T.Text != ".")
                                            {
                                                strRefNumColl.Add(T.Text);
                                                T.Text = nRefIndex.ToString();
                                                bRefNumberStart = false;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }


                    //// ======================= EXTRACT CITATIONS FROM THE BODY====================== ///

                    nRefIndex = 0;
                    bool bRefCiteStart = false;
                    int nCounter = 0;

                    List<string> strCiteColl = new List<string>();
                    strCiteColl.Clear();

                    // Search all Paragraphs that is "TOC1 to TOC3" style.
                    foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                    {
                        if (P.HasChildren)
                        {
                            if (P.Descendants<Run>().Count() > 0)
                            {
                                foreach (Run R in P.Descendants<Run>().ToList())
                                {
                                    if (R.RunProperties != null)
                                    {
                                        if (R.RunProperties.RunStyle != null)
                                        {
                                            if (R.RunProperties.RunStyle.Val == "citebib")
                                            {
                                                bRefCiteStart = true;
                                                nRefIndex++;
                                            }
                                            else
                                            {
                                                bRefCiteStart = false;
                                            }
                                        }
                                    }
                                    foreach (Text T in R.Descendants<Text>().ToList())
                                    {
                                        if (bRefCiteStart)
                                        {
                                            if (T.Text.Contains(","))
                                            {
                                                string[] separators = { "," };
                                                string[] strRefCite = T.Text.Split(separators, StringSplitOptions.RemoveEmptyEntries);

                                                nCounter = 0;

                                                for (nCounter = 0; nCounter < strRefCite.Count(); nCounter++)
                                                {
                                                    //if(strCiteColl.Contains(strRefCite[nCounter]) == false)
                                                    strCiteColl.Add(strRefCite[nCounter]);
                                                }

                                                // Split the reference citation and then check all the entries
                                                bRefCiteStart = false;
                                            }
                                            else
                                            {
                                                bRefCiteStart = false;
                                                //if (strCiteColl.Contains(T.Text) == false)
                                                strCiteColl.Add(T.Text);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }


                    // =============== Compare the reference number with Citation number====================///

                    /// ================= if any citation is not matching then push it to remove cite collection ///


                    nCounter = 0;
                    List<string> strRemoveCite = new List<string>();
                    strRemoveCite.Clear();

                    if (strCiteColl.Count > 0)
                    {
                        for (nCounter = 0; nCounter < strCiteColl.Count; nCounter++)
                        {
                            if (strRefNumColl.Count > 0)
                            {
                                if (strRefNumColl.Contains(strCiteColl[nCounter]) == false)
                                {
                                    if (strRemoveCite.Contains(strCiteColl[nCounter]) == false)
                                        strRemoveCite.Add(strCiteColl[nCounter]);
                                }
                            }
                        }
                    }

                    /// =================== BELOW CODE TO BE DELETED ============================= /////
                    /// 
                    // Logic to delete the citation and replace the existing citation with new number //

                    List<int> nNewCitationList = new List<int>();
                    int num1 = 0;
                    int num2 = 0;

                    int n = 0;
                    bool bReduceOne = false;

                    // Convert all the numbers to integer

                    List<int> nNumList = new List<int>();
                    nNumList.Clear();

                    for (nCounter = 0; nCounter < strCiteColl.Count; nCounter++)
                    {
                        nNumList.Add(Convert.ToInt32(strCiteColl[nCounter]));
                    }

                    List<int> nRemoveCiteList = new List<int>();
                    nRemoveCiteList.Clear();

                    for (nCounter = 0; nCounter < strRemoveCite.Count; nCounter++)
                    {
                        if (nRemoveCiteList.Contains(Convert.ToInt32(strRemoveCite[nCounter])) == false)
                            nRemoveCiteList.Add(Convert.ToInt32(strRemoveCite[nCounter]));
                    }

                    List<int> nFinalCiteList = new List<int>();

                    int nNum = 0;
                    nFinalCiteList.Clear();
                    int nAddDelVal = 0;
                    bool bDelEntry = false;
                    for (nCounter = 0; nCounter < nNumList.Count; nCounter++)
                    {
                        nNum = nNumList[nCounter];
                        if (nRemoveCiteList.Contains(nNum))
                        {
                            bDelEntry = true;
                            nAddDelVal++;
                            nFinalCiteList.Add(0);
                            nNum = 0;
                            continue;
                        }

                        if (bDelEntry == true)
                        {
                            // Check if the Number is greater then the number deleted

                            for (int x = 0; x < nRemoveCiteList.Count; x++)
                            {
                                if (nNum >= nRemoveCiteList[x])
                                {
                                    if (nNum > 0)
                                        nNum = nNum - 1;
                                }
                            }

                            nFinalCiteList.Add(nNum);
                        }
                        else
                        {
                            nFinalCiteList.Add(nNum);
                        }
                    }

                    if (nFinalCiteList.Count <= 0)
                        goto SaveContent;


                    // Compare the Reference Number with Reference Citation //

                    //bool bRefCiteStart = false;
                    bRefCiteStart = false;
                    int nCitCounter = 0;

                    if (strRemoveCite.Count > 0)
                    {
                        nCitCounter = 0;

                        foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                        {
                            if (P.HasChildren)
                            {
                                if (P.Descendants<Run>().Count() > 0)
                                {
                                    foreach (Run R in P.Descendants<Run>().ToList())
                                    {
                                        if (R.RunProperties != null)
                                        {
                                            if (R.RunProperties.RunStyle != null)
                                            {
                                                if (R.RunProperties.RunStyle.Val == "citebib")
                                                {
                                                    bRefCiteStart = true;
                                                    nRefIndex++;
                                                }
                                                else
                                                {
                                                    bRefCiteStart = false;
                                                }
                                            }
                                        }



                                        foreach (Text T in R.Descendants<Text>().ToList())
                                        {
                                            if (bRefCiteStart)
                                            {
                                                bRefCiteStart = false;
                                                if (T.Text.Contains(","))
                                                {
                                                    string[] separators = { "," };
                                                    string[] strRefCite = T.Text.Split(separators, StringSplitOptions.RemoveEmptyEntries);

                                                    nCounter = 0;
                                                    nNum = 0;
                                                    string strModifiedText = null;
                                                    int nFinalCite = 0;
                                                    for (nCounter = 0; nCounter < strRefCite.Count(); nCounter++)
                                                    {
                                                        nFinalCite = nFinalCiteList[nCitCounter];

                                                        if (nFinalCite != 0)
                                                        {
                                                            if (strModifiedText != null)
                                                            {
                                                                if (strModifiedText.Length > 0)
                                                                    strModifiedText = strModifiedText + "," + nFinalCite.ToString();
                                                                else
                                                                    strModifiedText = nFinalCite.ToString();
                                                            }
                                                            else
                                                            {
                                                                strModifiedText = nFinalCite.ToString();
                                                            }
                                                        }

                                                        nCitCounter++;
                                                    }

                                                    // Update the modified text //
                                                    if (strModifiedText != null)
                                                    {
                                                        if (strModifiedText.Length > 0)
                                                        {
                                                            if (T.Text != strModifiedText)
                                                                T.Text = strModifiedText;
                                                            strModifiedText = null;
                                                        }
                                                    }
                                                    else
                                                    {
                                                        R.Remove();
                                                    }
                                                }
                                                else
                                                {
                                                    bRefCiteStart = false;
                                                    //int nSelCite = 0;
                                                    //nSelCite = Convert.ToInt32(T.Text);
                                                    nNum = 0;
                                                    nNum = nFinalCiteList[nCitCounter];

                                                    if (nNum == 0)
                                                    {
                                                        R.Remove();
                                                    }
                                                    else
                                                    {

                                                        if (T.Text != nNum.ToString())
                                                            T.Text = nNum.ToString();
                                                    }

                                                    nCitCounter++;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    SaveContent:
                    { }
                    // ================================= //
                    D.Save();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void UpdateReferencePatternIndex(List<string> strRefPatterns, string strRefPatternFilename)
        {
            string strPatternGroup = null;
            bool bPatternStart = false;

            List<string> strReferencePattern = new List<string>();
            List<string> strRefPatternGrp = new List<string>();

            strReferencePattern.Clear();
            strRefPatternGrp.Clear();

            for (int i = 0; i < strRefPatterns.Count; i++)
            {
                if (strRefPatterns[i].ToLower().StartsWith("[pattern start]") == true)
                {
                    strPatternGroup = "";
                    strPatternGroup = strRefPatterns[i];
                    bPatternStart = true;
                    continue;
                }
                else if (strRefPatterns[i].ToLower().StartsWith("[pattern end]") == true)
                {
                    strPatternGroup = strPatternGroup + System.Environment.NewLine + strRefPatterns[i];

                    // Add the complete Pattern Group String in List array
                    strRefPatternGrp.Add(strPatternGroup);
                    strPatternGroup = "";
                    bPatternStart = false;
                }
                else
                {
                    if (bPatternStart == true)
                    {
                        if (strRefPatterns[i].ToLower().StartsWith("searchpattern:") == true)
                        {
                            strReferencePattern.Add(strRefPatterns[i].Replace("SearchPattern:", "SearchPattern" + i + ":"));
                            strPatternGroup = strPatternGroup + System.Environment.NewLine + strRefPatterns[i].Replace("SearchPattern:", "SearchPattern" + i + ":");
                        }
                        else
                        {
                            strPatternGroup = strPatternGroup + System.Environment.NewLine + strRefPatterns[i];
                        }
                    }
                }
            }

            // Sort the pattern array on length //
            strReferencePattern = GlobalMethods.SortStringListOnLength(strReferencePattern);

            // Sort the master list array as per the sorted pattern list

            strRefPatterns.Clear();

            for (int i = 0; i < strReferencePattern.Count; i++)
            {
                for (int j = 0; j < strRefPatternGrp.Count; j++)
                {
                    if (strRefPatternGrp[j].Contains(strReferencePattern[i]))
                    {
                        string strSearchText = "";
                        strReferencePattern[i] = "";
                        strSearchText = GlobalMethods.SearchRegEx(strRefPatternGrp[j], @"SearchPattern[0-9]+\:");

                        if (strSearchText != null)
                        {
                            if (strSearchText.ToLower().StartsWith("searchpattern"))
                            {
                                strRefPatterns.Add(strRefPatternGrp[j].Replace(strSearchText, "SearchPattern:"));
                            }
                            else
                            {
                                strRefPatterns.Add(strRefPatternGrp[j]);
                            }
                        }

                        break;
                    }
                }
            }

            // Write the list array contents back to the pattern file //

            StreamWriter sw = new StreamWriter(strRefPatternFilename);

            for (int i = 0; i < strRefPatterns.Count; i++)
            {
                sw.WriteLine(strRefPatterns[i]);
            }

            sw.Close();
        }

        private static bool CheckIfTheStyleIsReferenceStyle(string strStyleName)
        {

            if (LstReferenceStyleColl.Contains(strStyleName))
            {
                return true;
            }

            return false;
        }

        private static bool CheckIfParaHasStructuredReference(List<OpenXmlElement> RList)
        {
            foreach (OpenXmlElement R in RList)
            {
                if (R.LocalName != null)
                {
                    if (R.LocalName == "r")
                    {
                        if (R.HasChildren)
                        {
                            foreach (OpenXmlElement el in R.Elements())
                            {
                                if (el.LocalName == "t")
                                {
                                    if (el.InnerText == "<eref>")
                                    {
                                        return true;
                                    }

                                    if (el.InnerText == "<bok>")
                                    {
                                        return true;
                                    }

                                    if (el.InnerText == "<unknown>")
                                    {
                                        return true;
                                    }
                                }
                                else if (el.LocalName == "rPr")
                                {
                                    if (el.HasChildren)
                                    {
                                        foreach (OpenXmlElement el1 in el.Elements())
                                        {
                                            if (el1.LocalName == "rStyle")
                                            {
                                                string Style = ((DocumentFormat.OpenXml.Wordprocessing.String253Type)el1).Val;

                                                if (Style != null)
                                                {
                                                    if (CheckIfTheStyleIsReferenceStyle(Style) == true)
                                                        return true;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            return false;
        }
        public static void Ref_StyleApplied(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P != null && P.InnerText != "")
                    {
                        if (P.InnerText.ToLower().Trim().Equals("references") || P.InnerText.ToLower().Trim().Equals("reference") || P.InnerText.ToLower().Replace(" ", "").Equals("suggestedreading") || P.InnerText.Trim().ToLower() == "bibliografia" || P.InnerText.Trim().ToLower() == "further reading" || P.InnerText.ToLower().Replace(" ", "").Trim() == ("6.literatur") || P.InnerText.ToLower().Trim() == ("bibliografia recomendada")|| P.InnerText.ToUpper().ToUpper() == "LEITURAS SUGERIDAS"|| Regex.Replace(P.InnerText.ToLower().Trim(), @"^\<[A-Za-z0-9]+\>", "").ToString() == "references" || Regex.Replace(P.InnerText.ToLower().Trim(), @"^\<[A-Za-z0-9]+\>", "").ToString() == "reference" || Regex.Replace(P.InnerText.ToLower().Trim(), @"^\<[A-Za-z0-9]+\>", "").ToString() == "further reading" || Regex.Replace(P.InnerText.ToLower().Trim(), @"^\<[A-Za-z0-9]+\>", "").ToString() == "literaturverzeichnis" || Regex.Replace(P.InnerText.ToLower().Trim(), @"^\<[A-Za-z0-9]+\>", "").ToString() == "bibliografia" || Regex.Replace(P.InnerText.ToUpper().Trim(), @"^\<[A-Za-z0-9]+\>", "").ToString() == "REFERÊNCIAS" || Regex.Replace(P.InnerText.ToUpper().Trim(), @"^\<[A-Za-z0-9]+\>", "").ToString() == "REFERÊNCIAS BIBLIOGRÁFICAS" || Regex.Replace(P.InnerText.ToUpper().Trim(), @"^\<[A-Za-z0-9]+\>", "").ToString() == "BIBLIOGRÁFICAS" || Regex.Replace(P.InnerText.ToUpper().Trim(), @"^\<[A-Za-z0-9]+\>", "").ToString() == "LEITURAS SUGERIDAS")  //Developer Name:Priyanka Vishwakarma ,Date:09072020  ,Requirement:For portuguese language epub
                        {
                            if (P.ParagraphProperties != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null)
                                {
                                    
                                        P.ParagraphProperties.ParagraphStyleId.Val = "REF";
                                    
                                }
                                else
                                {
                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "REF" };
                                }
                            }
                            else
                            {
                                P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "REF" });
                            }
                        }
                    }
                }
                D.Save();
            }
        }

        private static void MergeReferenceElementsIntoOneGroup(string newDoc, string RefPatternFile, string JournalDB, string PublisherDB)
        {
            // Read the Reference patterns from the configuration and store in list
            List<string> strRefPatterns = new List<string>();
            strRefPatterns = GlobalMethods.ReadAndStoreFileValuesInArray(RefPatternFile);

            // Read the Journal list from the configuration and store in list

            List<string> strJournalsColl = new List<string>();
            strJournalsColl = GlobalMethods.ReadAndStoreFileValuesInArray(JournalDB);

            // Sort the Journals array on length //
            strJournalsColl = GlobalMethods.SortStringListOnLength(strJournalsColl);

            List<string> strPublisherColl = new List<string>();
            strPublisherColl = GlobalMethods.ReadAndStoreFileValuesInArray(PublisherDB);

            // Sort the Publisher array on length //
            strPublisherColl = GlobalMethods.SortStringListOnLength(strPublisherColl);

            //string strUsedPatternFilename = ConfigurationManager.AppSettings.Get("UsedPattern");
            //StreamWriter sw = new StreamWriter(strUsedPatternFilename);

            //string strUnStructuredReferencesFilename = ConfigurationManager.AppSettings.Get("UnStructuredReferences");
            //StreamWriter sw1 = new StreamWriter(strUnStructuredReferencesFilename);
            bool bookRefFind = false;
            bool jrnRefFind = false;
            bool edbRefFind = false;
            bool unknownRefFind = false;
            OpenXmlElement newP = null;  //Developer Name:Priyanka Vishwakarma ,Date:6_6_2019 ,Requirement:Add Para as it is if New Pattern of Reference Comes ,Integrated By:Vikas Sir.

            int nRefNumberCounter = 0;

            using (WordprocessingDocument WPD = WordprocessingDocument
                .Open(newDoc, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    RemoveComments = false,
                    RemoveContentControls = true,
                    RemoveEndAndFootNotes = false,
                    //RemoveFieldCodes = false,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = false,//Developer name :Priyanka Vishwakarma. Date:29_5_2019, Requirement:it removes the indentation from the nested list  ,Integrated By:Vikas sir. 
                };

                MarkupSimplifier.SimplifyMarkup(WPD, settings);

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                bool bParaHasStructuredRef = false;
                string refText = null;

                Dictionary<int, string> commentRangeStartText = new Dictionary<int, string>();
                // Search all Paragraphs that is "TOC1 to TOC3" style.
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().
                    Where(e => e.ParagraphProperties != null
                        && e.ParagraphProperties.ParagraphStyleId != null
                        && e.ParagraphProperties.ParagraphStyleId.Val == "REF1"))
                {
                    newP = P.CloneNode(true);   //Develope Name:Priyanka Vishwakarma ,Date:8_6_2019 ,Requirement: for adding Comment in Reference on bibnumber only.
                    bool numberedRef = false;
                    bParaHasStructuredRef = false;
                    bookRefFind = false;
                    jrnRefFind = false;
                    edbRefFind = false;
                    unknownRefFind = false;
                    nRefNumberCounter++;
                    commentRangeStartText.Clear();

                    ////Develope Name:Priyanka Vishwakarma ,Date:05_10_2019 ,Requirement: for unnumbered reference 

                    if (P.InnerText.ToLower().StartsWith("<jrn>") || P.InnerText.ToLower().StartsWith("<bok>") || P.InnerText.ToLower().StartsWith("<edb>") || P.InnerText.ToLower().StartsWith("<unknown>"))
                    {
                        refText = P.InnerText.Replace("<jrn>", "").Replace("<bok>", "").Replace("<edb>", "").Replace("<unknown>", "").Replace("</jrn>", "").Replace("</bok>", "").Replace("</edb>", "").Replace("</unknown>", "").Trim();
                        Regex startwithnumber = new Regex(@"^\d+");
                        if (startwithnumber.IsMatch(refText))
                        {
                            numberedRef = true;
                        }
                    }


                    //Develope Name:Priyanka Vishwakarma ,Date:28_5_2019 ,Requirement: for adding Comment in Reference on bibnumber only.
                    foreach (var PS in P.Descendants().ToList().Where(x => x.XName == W.commentRangeStart).ToList())
                    {
                        commentRangeStartText.Add(Convert.ToInt16(((DocumentFormat.OpenXml.Wordprocessing.MarkupRangeType)PS).Id.InnerText), PS.NextSibling().InnerText.Trim());

                    }

                    if (P.HasChildren == false)
                    {
                        try
                        {
                            P.Remove();
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(ex.Message);
                        }
                    }
                    else
                    {
                        if (P.HasChildren == true)
                        {
                            if (P.Descendants<Run>().Count() > 0)
                            {
                                List<OpenXmlElement> RList = P.Descendants<OpenXmlElement>().ToList();

                                bParaHasStructuredRef = CheckIfParaHasStructuredReference(RList);

                                if (bParaHasStructuredRef == true)
                                {
                                    bParaHasStructuredRef = false;
                                    //continue;   //Commented by Priyanka on 15_5_2019 for apply RefCharStyle .  
                                }
                                if (P.InnerText.ToLower().StartsWith("<bok>"))
                                {
                                    bookRefFind = true;
                                }
                                else if (P.InnerText.ToLower().StartsWith("<jrn>"))
                                {
                                    jrnRefFind = true;
                                }
                                else if (P.InnerText.ToLower().StartsWith("<edb>"))
                                {
                                    edbRefFind = true;
                                }
                                else if (P.InnerText.ToLower().StartsWith("<unknown>"))
                                {
                                    unknownRefFind = true;
                                }


                                if (/*P.InnerText.ToLower().StartsWith("<unknown>") ||*/ P.InnerText.ToLower().StartsWith("<eref>") || P.InnerText.ToLower().StartsWith("<ths>"))  //11022020  Priyanka Comment <unknown>
                                {
                                    goto NextRef;
                                }
                                //Developer name :Priyanka Vishwakarma. Date:29_5_2019, Requirement:If other types of references other than jrn,bok,edb,unknown,eref come and add it as it is. ,Integrated By:Vikas sir. 
                                else if (!P.InnerText.ToLower().StartsWith("<jrn>") && !P.InnerText.ToLower().StartsWith("<bok>") && !P.InnerText.ToLower().StartsWith("<edb>") && !P.InnerText.ToLower().StartsWith("<unknown>") && !P.InnerText.ToLower().StartsWith("<eref>"))
                                {
                                    if (P.InnerText.ToLower().StartsWith("<") && P.InnerText.ToLower().EndsWith(">"))
                                    {
                                        goto NextRef;
                                    }
                                }
                                string strReferenceText = null;
                                foreach (Run R in P.Descendants<Run>().ToList())
                                {
                                    //foreach (Text T in R.Descendants<Text>().ToList())
                                    //{
                                    //    strReferenceText = strReferenceText + T.Text;
                                    //}
                                    //R.Remove();
                                    //---------Developer Name:Priyanka Vishwakarma ,Date:12_6_2019 ,Requirement:nobreakHyphen present in book references instead of emdash . ,Integrated By:Vikas Sir.
                                    if (R.Descendants().Where(x => x.XName == W.noBreakHyphen).ToList().Count > 0)
                                    {
                                        strReferenceText = strReferenceText + "–";
                                    }
                                    else
                                    {
                                        strReferenceText = strReferenceText + R.InnerText;
                                    }
                                    //----------------------------end----------------------------------------------------------------------
                                    //foreach (Text T in R.Descendants<Text>().ToList())
                                    //{
                                    //    strReferenceText = strReferenceText + T.Text;
                                    //}
                                    R.Remove();
                                }

                                if (strReferenceText.Trim() == "")
                                {
                                    P.Remove();
                                    goto NextRef;
                                }

                                if (strReferenceText == "<jrn> </jrn>")
                                {
                                    P.Remove();
                                    goto NextRef;
                                }

                                if (strReferenceText == "<jrn> ")
                                {
                                    P.Remove();
                                    goto NextRef;
                                }

                                strReferenceText = strReferenceText.Replace("<jrn>", "").Replace("</jrn>", "").Trim();
                                string strjrnrefNumber = null;
                                strjrnrefNumber = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(strReferenceText, @"^[0-9]+.\s|^[0-9]+\.");
                                if (!string.IsNullOrEmpty(strjrnrefNumber))
                                {
                                    strReferenceText = strReferenceText.Replace(strjrnrefNumber, "");
                                }
                                // if already tagged reference //



                                // Increment the Reference Counter
                                //nRefNumberCounter++;
                                // Build the pattern and Groups before searching and creating runs //

                                List<string> strRefGroups = new List<string>();
                                bool bPatternStart = false;
                                string SearchPattern = null;
                                int ReplaceGrpCount = 0;
                                string PubMedPattern = null;
                                strRefGroups.Clear();
                                List<string> strRefSearchPattern = new List<string>();
                                int nIndex = 0;
                                int nGrpCounter = 0;
                                int nPatternIndex = 0;

                                // Check if the reference is other //
                                #region  for <unknown> tag

                                if (unknownRefFind == true)
                                {


                                    if (strReferenceText.ToLower().StartsWith("<unknown>") || strReferenceText.ToLower().Contains("www.") || strReferenceText.ToLower().Contains("http:") || strReferenceText.ToLower().Contains("https:") || strReferenceText.ToLower().Contains("conference")
                                        || strReferenceText.ToLower().Contains("presented at") || strReferenceText.ToLower().Contains("presentation at"))  //11022020 for Unknown reference 
                                    {
                                        // Insert Reference Number //

                                        //--------------------------------------------
                                        // Publisher found then mark the reference as Journal Reference //
                                        strReferenceText = strReferenceText.Replace("<unknown>", "").Replace("</unknown>", "").Trim();
                                        string stredbrefNumber = null;
                                        stredbrefNumber = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(strReferenceText, @"^[0-9]+.\s|^[0-9]+\.");
                                        if (!string.IsNullOrEmpty(stredbrefNumber))
                                        {
                                            strReferenceText = strReferenceText.Replace(stredbrefNumber, "");
                                        }
                                        //---------------------------------------

                                        Run newrunx = P.AppendChild(new Run());
                                        // Add Text to the Run element.
                                        newrunx.AppendChild(new Text("<unknown>"));
                                        if (numberedRef)
                                        {
                                            Run run3 = new Run(new RunProperties(new RunStyle() { Val = "bibnumber" }));
                                            P.AppendChild(run3);
                                            // Add Text to the Run element.
                                            run3.AppendChild(new Text(nRefNumberCounter.ToString()));

                                            Run newrun4 = P.AppendChild(new Run());
                                            // Add Text to the Run element.
                                            newrun4.AppendChild(new Text(". ") { Space = SpaceProcessingModeValues.Preserve });
                                        }
                                        Run newrun5 = P.AppendChild(new Run());
                                        // Add Text to the Run element.
                                        newrun5.AppendChild(new Text(strReferenceText.Trim()));

                                        Run newrund = P.AppendChild(new Run());
                                        // Add Text to the Run element.
                                        newrund.AppendChild(new Text("</unknown>"));

                                        goto NextRef;
                                    }
                                }
                                #endregion



                                #region for<bok> tag
                                else if (bookRefFind == true)
                                {

                                    // Publisher found then mark the reference as Journal Reference //
                                    strReferenceText = strReferenceText.Replace("<bok>", "").Replace("</bok>", "").Trim();
                                    string stredbrefNumber = null;
                                    stredbrefNumber = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(strReferenceText, @"^[0-9]+.\s|^[0-9]+\.");
                                    if (!string.IsNullOrEmpty(stredbrefNumber))
                                    {
                                        strReferenceText = strReferenceText.Replace(stredbrefNumber, "");
                                    }

                                    if (strReferenceText != "")

                                        strReferenceText = strReferenceText.Replace("–", "-");
                                    for (int i = 0; i < strRefPatterns.Count; i++)
                                    {
                                        if (strRefPatterns[i].ToLower().StartsWith("[pattern start]") == true)
                                        {
                                            nPatternIndex++;
                                            strRefGroups.Clear();
                                            bPatternStart = true;
                                            continue;
                                        }

                                        if (bPatternStart == true)
                                        {
                                            if (strRefPatterns[i].ToLower().StartsWith("searchpattern:") == true)
                                            {
                                                SearchPattern = strRefPatterns[i].Replace("SearchPattern:", "");

                                                if (SearchPattern.Contains(@"(et al)(\.)"))
                                                {
                                                    //  Console.WriteLine("Got it");
                                                }

                                                continue;
                                            }

                                            if (strRefPatterns[i].ToLower().StartsWith("replacegroup:") == true)
                                            {
                                                string RpGrp = strRefPatterns[i].Replace("ReplaceGroup:", "");
                                                ReplaceGrpCount = Convert.ToInt32(RpGrp);
                                                continue;
                                            }

                                            if (strRefPatterns[i].ToLower().StartsWith("pubmed:") == true)
                                            {
                                                PubMedPattern = strRefPatterns[i].Replace("Pubmed:", "");
                                                continue;
                                            }

                                            if (strRefPatterns[i].ToLower().StartsWith("group:") == true)
                                            {
                                                strRefGroups.Add(strRefPatterns[i].Replace("Group:", ""));
                                                continue;
                                            }
                                        }

                                        if (strRefPatterns[i].ToLower().StartsWith("[pattern end]") == true)
                                        {
                                            bPatternStart = false;

                                            // Build the search Pattern by Replacing the JournalInfo
                                            for (nIndex = 0; nIndex < strPublisherColl.Count; nIndex++)
                                            {
                                                string strTmp; //= strJournalsColl[nIndex].Replace("(", @"\(").Replace(")", @"\)").Replace(".", @"\.");

                                                if (strReferenceText.Contains(strPublisherColl[nIndex]))
                                                {

                                                    strTmp = strPublisherColl[nIndex].Replace("(", @"\(").Replace(")", @"\)").Replace(".", @"\.");
                                                    strRefSearchPattern.Add(SearchPattern.Replace("(PublicationInfo)", "(" + strTmp + ")"));
                                                    break;
                                                }
                                            }


                                            if (strRefSearchPattern.Count > 0)
                                            {


                                                if (ReplaceGrpCount > 0)
                                                {
                                                    if (strRefGroups.Count != ReplaceGrpCount)
                                                    {
                                                        strRefGroups.Clear();
                                                        goto NextRefSearchPattern;
                                                    }

                                                    for (nIndex = 0; nIndex < strRefSearchPattern.Count; nIndex++)
                                                    {
                                                        MatchCollection matches = Regex.Matches(strReferenceText, strRefSearchPattern[nIndex]);

                                                        if (matches.Count == 1)
                                                        {
                                                            //if (strReferenceText.Contains("et al") && strRefSearchPattern[nIndex].Contains("et al") == false)
                                                            //{
                                                            //    goto NextRefPat;
                                                            //}


                                                            foreach (Match match in matches)
                                                            {
                                                                if ((match.Groups.Count - 1) != ReplaceGrpCount)
                                                                {
                                                                    goto NextRefPat;   //---------Develope Name:Priyanka Vishwakarma ,Date:24_6_2019 ,Requirement:missing references because of group not match , integrated by:Vikas sir..
                                                                    //break;
                                                                }

                                                                //---------Develope Name:Priyanka Vishwakarma ,Date:4_6_2019 ,Requirement: for adding Comment in Reference.
                                                                foreach (var PS in P.Descendants().ToList().Where(x => x.XName == W.commentRangeStart).ToList())
                                                                {

                                                                    PS.Remove();
                                                                }
                                                                foreach (var PE in P.Descendants().ToList().Where(x => x.XName == W.commentRangeEnd).ToList())
                                                                {

                                                                    PE.Remove();
                                                                }
                                                                foreach (var PR in P.Descendants().ToList().Where(x => x.XName == W.commentReference).ToList())
                                                                {

                                                                    PR.Remove();
                                                                }

                                                                //------------------------------End----------------------------------
                                                                // Extract group info 
                                                                int GrpNo = 0;
                                                                PubMedPattern = GlobalMethods.ReplaceWholeWord(PubMedPattern, "space", " ");
                                                                for (nGrpCounter = 0; nGrpCounter < strRefGroups.Count; nGrpCounter++)
                                                                {
                                                                    string tmpstr = null;
                                                                    tmpstr = strRefGroups[nGrpCounter];
                                                                    GrpNo = 0;
                                                                    GrpNo = nGrpCounter + 1;

                                                                    if (nGrpCounter == 0)
                                                                    {
                                                                        Run newruna = P.AppendChild(new Run());
                                                                        // Add Text to the Run element.
                                                                        newruna.AppendChild(new Text("<bok>"));
                                                                        if (numberedRef)
                                                                        {
                                                                            // Insert Reference Number //
                                                                            Run run = new Run(new RunProperties(new RunStyle() { Val = "bibnumber" }));
                                                                            P.AppendChild(run);
                                                                            // Add Text to the Run element.
                                                                            run.AppendChild(new Text(nRefNumberCounter.ToString()));
                                                                            //---------Develope Name:Priyanka Vishwakarma ,Date:4_6_2019 ,Requirement: for adding Comment in Reference.
                                                                            if (commentRangeStartText.ContainsValue(run.InnerText.Trim()))
                                                                            {
                                                                                var key = commentRangeStartText.FirstOrDefault(x => x.Value == run.InnerText.Trim()).Key;
                                                                                if (!string.IsNullOrEmpty(key.ToString()))
                                                                                {
                                                                                    run.InsertBeforeSelf(new CommentRangeStart() { Id = key.ToString() });
                                                                                    RunProperties rpr = new RunProperties(new RunStyle() { Val = "CommentReference" });

                                                                                    run.InsertAfterSelf(new Run(new CommentReference() { Id = key.ToString() })).Append(rpr);
                                                                                    run.InsertAfterSelf(new CommentRangeEnd() { Id = key.ToString() });
                                                                                    new Run(new CommentReference() { Id = key.ToString() });
                                                                                }

                                                                            }

                                                                            //--------------------end-----------------------------------------------------------

                                                                            Run newrun2 = P.AppendChild(new Run());
                                                                            // Add Text to the Run element.
                                                                            newrun2.AppendChild(new Text(". ") { Space = SpaceProcessingModeValues.Preserve });
                                                                        }
                                                                    }

                                                                    if (tmpstr.Contains(":"))
                                                                    {
                                                                        // Split the string
                                                                        string[] separators = { ":" };
                                                                        string[] strValues = tmpstr.Split(separators, StringSplitOptions.RemoveEmptyEntries);

                                                                        if (strValues.Length > 0)
                                                                        {
                                                                            if (strValues[0] == "space")
                                                                            {
                                                                                Run run = P.AppendChild(new Run());
                                                                                //OpenXmlAttribute openXmlAttribute = new OpenXmlAttribute("space", "xml", "preserve");
                                                                                // Add Text to the Run element.
                                                                                Text T = new Text(" ") { Space = SpaceProcessingModeValues.Preserve };
                                                                                //T.SetAttribute(openXmlAttribute);
                                                                                run.AppendChild(T);
                                                                            }
                                                                            else if (strValues[0] == "blank")
                                                                            {
                                                                                // No action required
                                                                            }
                                                                            else if (strValues[0] == "value")
                                                                            {
                                                                                Run run = P.AppendChild(new Run());
                                                                                // Add Text to the Run element.
                                                                                run.AppendChild(new Text(match.Groups[nGrpCounter + 1].Value));

                                                                                PubMedPattern = GlobalMethods.ReplaceWholeWord(PubMedPattern, "Group" + GrpNo, match.Groups[nGrpCounter + 1].Value);
                                                                            }

                                                                            if (strValues[1] != "") // Style
                                                                            {
                                                                                Run run = new Run(new RunProperties(new RunStyle() { Val = strValues[1] }));
                                                                                P.AppendChild(run);
                                                                                // Add Text to the Run element.
                                                                                run.AppendChild(new Text(match.Groups[nGrpCounter + 1].Value));
                                                                                //---------Develope Name:Priyanka Vishwakarma ,Date:4_6_2019 ,Requirement: for adding Comment in Reference.

                                                                                if (commentRangeStartText.ContainsValue(run.InnerText.Trim()))
                                                                                {

                                                                                    var key = commentRangeStartText.FirstOrDefault(x => x.Value == run.InnerText.Trim()).Key;
                                                                                    if (!string.IsNullOrEmpty(key.ToString()))
                                                                                    {

                                                                                        run.InsertBeforeSelf(new CommentRangeStart() { Id = key.ToString() });
                                                                                        RunProperties rpr = new RunProperties(new RunStyle() { Val = "CommentReference" });

                                                                                        run.InsertAfterSelf(new Run(new CommentReference() { Id = key.ToString() })).Append(rpr);
                                                                                        run.InsertAfterSelf(new CommentRangeEnd() { Id = key.ToString() });
                                                                                        new Run(new CommentReference() { Id = key.ToString() });
                                                                                    }

                                                                                }
                                                                                else if (commentRangeStartText.Any(kvp => run.InnerText.StartsWith(kvp.Value)))
                                                                                {

                                                                                    var key = 0;
                                                                                    foreach (var val in commentRangeStartText)
                                                                                    {

                                                                                        if (run.InnerText.StartsWith(val.Value))
                                                                                        {
                                                                                            key = val.Key;
                                                                                        }

                                                                                    }

                                                                                    //var key = commentRangeStartText.Where(x => run.InnerText.StartsWith(x.Value));

                                                                                    // var key = commentRangeStartText.FirstOrDefault(x => x.Value == run.InnerText.Trim()).Key;

                                                                                    if (!string.IsNullOrEmpty(key.ToString()))
                                                                                    {

                                                                                        run.InsertBeforeSelf(new CommentRangeStart() { Id = key.ToString() });
                                                                                        RunProperties rpr = new RunProperties(new RunStyle() { Val = "CommentReference" });

                                                                                        run.InsertAfterSelf(new Run(new CommentReference() { Id = key.ToString() })).Append(rpr);
                                                                                        run.InsertAfterSelf(new CommentRangeEnd() { Id = key.ToString() });
                                                                                        new Run(new CommentReference() { Id = key.ToString() });
                                                                                    }

                                                                                }
                                                                                else if (commentRangeStartText.Any(kvp => run.InnerText.EndsWith(kvp.Value)))
                                                                                {

                                                                                    var key = 0;
                                                                                    foreach (var val in commentRangeStartText)
                                                                                    {

                                                                                        if (run.InnerText.EndsWith(val.Value))
                                                                                        {
                                                                                            key = val.Key;
                                                                                        }

                                                                                    }

                                                                                    //  var key = commentRangeStartText.FirstOrDefault(x => x.Value == run.InnerText.Trim()).Key;
                                                                                    if (!string.IsNullOrEmpty(key.ToString()))
                                                                                    {

                                                                                        run.InsertBeforeSelf(new CommentRangeStart() { Id = key.ToString() });
                                                                                        RunProperties rpr = new RunProperties(new RunStyle() { Val = "CommentReference" });

                                                                                        run.InsertAfterSelf(new Run(new CommentReference() { Id = key.ToString() })).Append(rpr);
                                                                                        run.InsertAfterSelf(new CommentRangeEnd() { Id = key.ToString() });
                                                                                        new Run(new CommentReference() { Id = key.ToString() });
                                                                                    }

                                                                                }
                                                                                //--------------------end-----------------------------------------------------------


                                                                                PubMedPattern = GlobalMethods.ReplaceWholeWord(PubMedPattern, "Group" + GrpNo, match.Groups[nGrpCounter + 1].Value);
                                                                            }
                                                                        }
                                                                    }
                                                                    else if (tmpstr.Contains("space"))
                                                                    {
                                                                        Run run = P.AppendChild(new Run());
                                                                        //OpenXmlAttribute openXmlAttribute = new OpenXmlAttribute("space", "xml", "preserve");
                                                                        // Add Text to the Run element.
                                                                        Text T = new Text(" ") { Space = SpaceProcessingModeValues.Preserve };
                                                                        //T.SetAttribute(openXmlAttribute);
                                                                        run.AppendChild(T);
                                                                    }
                                                                    else if (tmpstr.Contains("blank"))
                                                                    {
                                                                    }
                                                                    else if (tmpstr.Contains("value"))
                                                                    {
                                                                        Run run = P.AppendChild(new Run());
                                                                        // Add Text to the Run element.
                                                                        if (((match.Groups[nGrpCounter + 1].Value)) != null && ((match.Groups[nGrpCounter + 1].Value) == "-"))   //23_4_2019
                                                                        {
                                                                            string s = (match.Groups[nGrpCounter + 1].Value).Replace("-", "–");
                                                                            run.AppendChild(new Text(s));
                                                                            PubMedPattern = GlobalMethods.ReplaceWholeWord(PubMedPattern, "Group" + GrpNo, s);
                                                                        }
                                                                        else
                                                                        {
                                                                            run.AppendChild(new Text(match.Groups[nGrpCounter + 1].Value));
                                                                            PubMedPattern = GlobalMethods.ReplaceWholeWord(PubMedPattern, "Group" + GrpNo, match.Groups[nGrpCounter + 1].Value);
                                                                        }
                                                                    }
                                                                    else
                                                                    {
                                                                        Run run = new Run(new RunProperties(new RunStyle() { Val = tmpstr }));
                                                                        P.AppendChild(run);
                                                                        // Add Text to the Run element.
                                                                        run.AppendChild(new Text(match.Groups[nGrpCounter + 1].Value));
                                                                        //---------Develope Name:Priyanka Vishwakarma ,Date:4_6_2019 ,Requirement: for adding Comment in Reference.
                                                                        //------code for comment on surname...
                                                                        if (commentRangeStartText.ContainsValue(run.InnerText.Trim()))
                                                                        {

                                                                            var key = commentRangeStartText.FirstOrDefault(x => x.Value == run.InnerText.Trim()).Key;
                                                                            if (!string.IsNullOrEmpty(key.ToString()))
                                                                            {

                                                                                run.InsertBeforeSelf(new CommentRangeStart() { Id = key.ToString() });
                                                                                RunProperties rpr = new RunProperties(new RunStyle() { Val = "CommentReference" });

                                                                                run.InsertAfterSelf(new Run(new CommentReference() { Id = key.ToString() })).Append(rpr);
                                                                                run.InsertAfterSelf(new CommentRangeEnd() { Id = key.ToString() });
                                                                                new Run(new CommentReference() { Id = key.ToString() });
                                                                            }

                                                                        }

                                                                        //-----------------end----------------------------------------------

                                                                        PubMedPattern = GlobalMethods.ReplaceWholeWord(PubMedPattern, "Group" + GrpNo, match.Groups[nGrpCounter + 1].Value);
                                                                    }
                                                                }
                                                            }

                                                            if (PubMedPattern.Contains("Group") == false)
                                                            {
                                                                // Extract PmID from PubMed //
                                                                string retPMIDVal = null;

                                                                retPMIDVal = PubMed.ExtractPMID("http://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=pubmed&retmode=XML&retmax=1000&term=" + PubMedPattern);

                                                                if (retPMIDVal != null && retPMIDVal != "")
                                                                {
                                                                    // Build the new Hyperlink with the PMID to be inserted as Hyperlink //

                                                                    //add the url
                                                                    string urlLabel = "PubMed";
                                                                    System.Uri uri = new Uri("http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&list_uids=" + retPMIDVal + "&dopt=Abstract");

                                                                    bool bExtRefFound = false;
                                                                    foreach (HyperlinkRelationship hRel in WPD.MainDocumentPart.HyperlinkRelationships)
                                                                    {
                                                                        if (hRel.Uri == uri)
                                                                        {
                                                                            bExtRefFound = true;
                                                                        }
                                                                    }

                                                                    if (!bExtRefFound)
                                                                    {
                                                                        // Add the new URL to document Relations
                                                                        HyperlinkRelationship rel = MDP.AddHyperlinkRelationship(uri, true);
                                                                        string relationshipId = rel.Id;

                                                                        Hyperlink hlink = new Hyperlink(new Run(new RunProperties(new RunStyle() { Val = "bibmedline" }), new Text("PubMed"))) { History = OnOffValue.FromBoolean(true), Id = relationshipId };

                                                                        // Insert PubMed ID at the end of the newly marked Reference //

                                                                        P.AppendChild(hlink);
                                                                    }
                                                                }
                                                            }

                                                            // Insert Journal closing tag here //
                                                            Run newrunb = P.AppendChild(new Run());
                                                            // Add Text to the Run element.
                                                            newrunb.AppendChild(new Text("</bok>"));
                                                            //---------Develope Name:Priyanka Vishwakarma ,Date:4_6_2019 ,Requirement: for adding Comment in Reference.
                                                            if (commentRangeStartText.ContainsValue(newrunb.InnerText.Trim()))
                                                            {
                                                                var key = commentRangeStartText.FirstOrDefault(x => x.Value == newrunb.InnerText.Trim()).Key;
                                                                if (!string.IsNullOrEmpty(key.ToString()))
                                                                {

                                                                    newrunb.InsertBeforeSelf(new CommentRangeStart() { Id = key.ToString() });
                                                                    RunProperties rpr = new RunProperties(new RunStyle() { Val = "CommentReference" });

                                                                    newrunb.InsertAfterSelf(new Run(new CommentReference() { Id = key.ToString() })).Append(rpr);
                                                                    newrunb.InsertAfterSelf(new CommentRangeEnd() { Id = key.ToString() });
                                                                    new Run(new CommentReference() { Id = key.ToString() });
                                                                }

                                                            }
                                                            //--------------------end-----------------------------------------------------------

                                                            goto NextRef;
                                                        }

                                                        NextRefPat:
                                                        {
                                                        }
                                                    }

                                                }
                                            }
                                        }

                                        //strRefGroups.Clear();

                                        NextRefSearchPattern:
                                        {
                                            continue;
                                        }
                                    }




                                    //int nCounter = 0;
                                    //for (nCounter = 0; nCounter < strPublisherColl.Count(); nCounter++)
                                    //{
                                    //    if (strReferenceText.Contains(strPublisherColl[nCounter]))
                                    //    {
                                    //        // Publisher found then mark the reference as Journal Reference //

                                    //        Run newrunx = P.AppendChild(new Run());
                                    //        // Add Text to the Run element.
                                    //        newrunx.AppendChild(new Text("<bok>"));

                                    //        // Insert Reference Number //

                                    //        Run run3 = new Run(new RunProperties(new RunStyle() { Val = "bibnumber" }));
                                    //        P.AppendChild(run3);
                                    //        // Add Text to the Run element.
                                    //        run3.AppendChild(new Text(nRefNumberCounter.ToString()));

                                    //        Run newrun4 = P.AppendChild(new Run());
                                    //        // Add Text to the Run element.
                                    //        newrun4.AppendChild(new Text(". ") { Space = SpaceProcessingModeValues.Preserve });

                                    //        Run newrun5 = P.AppendChild(new Run());
                                    //        // Add Text to the Run element.
                                    //        newrun5.AppendChild(new Text(strReferenceText.Trim()));

                                    //        Run newrunt = P.AppendChild(new Run());
                                    //        // Add Text to the Run element.
                                    //        newrunt.AppendChild(new Text("</bok>"));

                                    //        goto NextRef;

                                    //    }
                                    //}
                                }
                                #endregion

                                #region for <edb> tag
                                else if (edbRefFind == true)
                                {
                                    if (strReferenceText.ToLower().Contains("eds.") || strReferenceText.ToLower().Contains("in: ") || strReferenceText.ToLower().Contains("in; "))
                                    {
                                        // Publisher found then mark the reference as Journal Reference //
                                        strReferenceText = strReferenceText.Replace("<edb>", "").Replace("</edb>", "").Trim();
                                        string stredbrefNumber = null;
                                        stredbrefNumber = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(strReferenceText, @"^[0-9]+.\s|^[0-9]+\.");
                                        if (!string.IsNullOrEmpty(stredbrefNumber))
                                        {
                                            strReferenceText = strReferenceText.Replace(stredbrefNumber, "");
                                        }


                                        #region

                                        if (strReferenceText != "")

                                            strReferenceText = strReferenceText.Replace("–", "-");

                                        for (int i = 0; i < strRefPatterns.Count; i++)
                                        {
                                            if (strRefPatterns[i].ToLower().StartsWith("[pattern start]") == true)
                                            {
                                                nPatternIndex++;
                                                strRefGroups.Clear();
                                                bPatternStart = true;
                                                continue;
                                            }

                                            if (bPatternStart == true)
                                            {
                                                if (strRefPatterns[i].ToLower().StartsWith("searchpattern:") == true)
                                                {
                                                    SearchPattern = strRefPatterns[i].Replace("SearchPattern:", "");

                                                    if (SearchPattern.Contains(@"(et al)(\.)"))
                                                    {
                                                        // Console.WriteLine("Got it");
                                                    }

                                                    continue;
                                                }

                                                if (strRefPatterns[i].ToLower().StartsWith("replacegroup:") == true)
                                                {
                                                    string RpGrp = strRefPatterns[i].Replace("ReplaceGroup:", "");
                                                    ReplaceGrpCount = Convert.ToInt32(RpGrp);
                                                    continue;
                                                }

                                                if (strRefPatterns[i].ToLower().StartsWith("pubmed:") == true)
                                                {
                                                    PubMedPattern = strRefPatterns[i].Replace("Pubmed:", "");
                                                    continue;
                                                }

                                                if (strRefPatterns[i].ToLower().StartsWith("group:") == true)
                                                {
                                                    strRefGroups.Add(strRefPatterns[i].Replace("Group:", ""));
                                                    continue;
                                                }
                                            }

                                            if (strRefPatterns[i].ToLower().StartsWith("[pattern end]") == true)
                                            {
                                                bPatternStart = false;

                                                // Build the search Pattern by Replacing the JournalInfo
                                                for (nIndex = 0; nIndex < strPublisherColl.Count; nIndex++)
                                                {
                                                    string strTmp; //= strJournalsColl[nIndex].Replace("(", @"\(").Replace(")", @"\)").Replace(".", @"\.");

                                                    if (strReferenceText.Contains(strPublisherColl[nIndex]))
                                                    {

                                                        strTmp = strPublisherColl[nIndex].Replace("(", @"\(").Replace(")", @"\)").Replace(".", @"\.");
                                                        strRefSearchPattern.Add(SearchPattern.Replace("(PublicationInfo)", "(" + strTmp + ")"));
                                                        break;
                                                    }
                                                }


                                                if (strRefSearchPattern.Count > 0)
                                                {
                                                    // Search operation is ready

                                                    if (ReplaceGrpCount > 0)
                                                    {
                                                        if (strRefGroups.Count != ReplaceGrpCount)
                                                        {
                                                            strRefGroups.Clear();
                                                            goto NextRefSearchPattern;
                                                        }

                                                        for (nIndex = 0; nIndex < strRefSearchPattern.Count; nIndex++)
                                                        {
                                                            MatchCollection matches = Regex.Matches(strReferenceText, strRefSearchPattern[nIndex]);

                                                            if (matches.Count == 1)
                                                            {
                                                                if (strReferenceText.Contains("et al") && strRefSearchPattern[nIndex].Contains("et al") == false)
                                                                {
                                                                    goto NextRefPat;
                                                                }



                                                                foreach (Match match in matches)
                                                                {
                                                                    if ((match.Groups.Count - 1) != ReplaceGrpCount)
                                                                    {
                                                                        goto NextRefPat;   //---------Develope Name:Priyanka Vishwakarma ,Date:24_6_2019 ,Requirement:missing references because of group not match , integrated by:Vikas sir..
                                                                                           //break;
                                                                    }
                                                                    // break;

                                                                    //---------Develope Name:Priyanka Vishwakarma ,Date:4_6_2019 ,Requirement: for adding Comment in Reference.
                                                                    foreach (var PS in P.Descendants().ToList().Where(x => x.XName == W.commentRangeStart).ToList())
                                                                    {

                                                                        PS.Remove();
                                                                    }
                                                                    foreach (var PE in P.Descendants().ToList().Where(x => x.XName == W.commentRangeEnd).ToList())
                                                                    {

                                                                        PE.Remove();
                                                                    }
                                                                    foreach (var PR in P.Descendants().ToList().Where(x => x.XName == W.commentReference).ToList())
                                                                    {

                                                                        PR.Remove();
                                                                    }

                                                                    //------------------------------End----------------------------------
                                                                    // Extract group info 
                                                                    int GrpNo = 0;
                                                                    PubMedPattern = GlobalMethods.ReplaceWholeWord(PubMedPattern, "space", " ");
                                                                    for (nGrpCounter = 0; nGrpCounter < strRefGroups.Count; nGrpCounter++)
                                                                    {
                                                                        string tmpstr = null;
                                                                        tmpstr = strRefGroups[nGrpCounter];
                                                                        GrpNo = 0;
                                                                        GrpNo = nGrpCounter + 1;

                                                                        if (nGrpCounter == 0)
                                                                        {
                                                                            Run newruna = P.AppendChild(new Run());
                                                                            // Add Text to the Run element.
                                                                            newruna.AppendChild(new Text("<edb>"));
                                                                            if (numberedRef)
                                                                            {
                                                                                // Insert Reference Number //
                                                                                Run run = new Run(new RunProperties(new RunStyle() { Val = "bibnumber" }));
                                                                                P.AppendChild(run);
                                                                                // Add Text to the Run element.
                                                                                run.AppendChild(new Text(nRefNumberCounter.ToString()));
                                                                                //---------Develope Name:Priyanka Vishwakarma ,Date:4_6_2019 ,Requirement: for adding Comment in Reference.
                                                                                if (commentRangeStartText.ContainsValue(run.InnerText.Trim()))
                                                                                {
                                                                                    var key = commentRangeStartText.FirstOrDefault(x => x.Value == run.InnerText.Trim()).Key;
                                                                                    if (!string.IsNullOrEmpty(key.ToString()))
                                                                                    {
                                                                                        run.InsertBeforeSelf(new CommentRangeStart() { Id = key.ToString() });
                                                                                        RunProperties rpr = new RunProperties(new RunStyle() { Val = "CommentReference" });

                                                                                        run.InsertAfterSelf(new Run(new CommentReference() { Id = key.ToString() })).Append(rpr);
                                                                                        run.InsertAfterSelf(new CommentRangeEnd() { Id = key.ToString() });
                                                                                        new Run(new CommentReference() { Id = key.ToString() });
                                                                                    }

                                                                                }
                                                                                //--------------------end-----------------------------------------------------------


                                                                                Run newrun2 = P.AppendChild(new Run());
                                                                                // Add Text to the Run element.
                                                                                newrun2.AppendChild(new Text(". ") { Space = SpaceProcessingModeValues.Preserve });
                                                                            }
                                                                        }

                                                                        if (tmpstr.Contains(":"))
                                                                        {
                                                                            // Split the string
                                                                            string[] separators = { ":" };
                                                                            string[] strValues = tmpstr.Split(separators, StringSplitOptions.RemoveEmptyEntries);

                                                                            if (strValues.Length > 0)
                                                                            {
                                                                                if (strValues[0] == "space")
                                                                                {
                                                                                    Run run = P.AppendChild(new Run());
                                                                                    //OpenXmlAttribute openXmlAttribute = new OpenXmlAttribute("space", "xml", "preserve");
                                                                                    // Add Text to the Run element.
                                                                                    Text T = new Text(" ") { Space = SpaceProcessingModeValues.Preserve };
                                                                                    //T.SetAttribute(openXmlAttribute);
                                                                                    run.AppendChild(T);
                                                                                }
                                                                                else if (strValues[0] == "blank")
                                                                                {
                                                                                    // No action required
                                                                                }
                                                                                else if (strValues[0] == "value")
                                                                                {
                                                                                    Run run = P.AppendChild(new Run());
                                                                                    // Add Text to the Run element.
                                                                                    run.AppendChild(new Text(match.Groups[nGrpCounter + 1].Value));

                                                                                    PubMedPattern = GlobalMethods.ReplaceWholeWord(PubMedPattern, "Group" + GrpNo, match.Groups[nGrpCounter + 1].Value);
                                                                                }

                                                                                if (strValues[1] != "") // Style
                                                                                {
                                                                                    Run run = new Run(new RunProperties(new RunStyle() { Val = strValues[1] }));
                                                                                    P.AppendChild(run);
                                                                                    // Add Text to the Run element.
                                                                                    run.AppendChild(new Text(match.Groups[nGrpCounter + 1].Value));
                                                                                    //---------Develope Name:Priyanka Vishwakarma ,Date:4_6_2019 ,Requirement: for adding Comment in Reference.

                                                                                    if (commentRangeStartText.ContainsValue(run.InnerText.Trim()))
                                                                                    {

                                                                                        var key = commentRangeStartText.FirstOrDefault(x => x.Value == run.InnerText.Trim()).Key;
                                                                                        if (!string.IsNullOrEmpty(key.ToString()))
                                                                                        {

                                                                                            run.InsertBeforeSelf(new CommentRangeStart() { Id = key.ToString() });
                                                                                            RunProperties rpr = new RunProperties(new RunStyle() { Val = "CommentReference" });

                                                                                            run.InsertAfterSelf(new Run(new CommentReference() { Id = key.ToString() })).Append(rpr);
                                                                                            run.InsertAfterSelf(new CommentRangeEnd() { Id = key.ToString() });
                                                                                            new Run(new CommentReference() { Id = key.ToString() });
                                                                                        }

                                                                                    }
                                                                                    else if (commentRangeStartText.Any(kvp => run.InnerText.StartsWith(kvp.Value)))
                                                                                    {

                                                                                        var key = 0;
                                                                                        foreach (var val in commentRangeStartText)
                                                                                        {

                                                                                            if (run.InnerText.StartsWith(val.Value))
                                                                                            {
                                                                                                key = val.Key;
                                                                                            }

                                                                                        }

                                                                                        //var key = commentRangeStartText.Where(x => run.InnerText.StartsWith(x.Value));

                                                                                        // var key = commentRangeStartText.FirstOrDefault(x => x.Value == run.InnerText.Trim()).Key;

                                                                                        if (!string.IsNullOrEmpty(key.ToString()))
                                                                                        {

                                                                                            run.InsertBeforeSelf(new CommentRangeStart() { Id = key.ToString() });
                                                                                            RunProperties rpr = new RunProperties(new RunStyle() { Val = "CommentReference" });

                                                                                            run.InsertAfterSelf(new Run(new CommentReference() { Id = key.ToString() })).Append(rpr);
                                                                                            run.InsertAfterSelf(new CommentRangeEnd() { Id = key.ToString() });
                                                                                            new Run(new CommentReference() { Id = key.ToString() });
                                                                                        }

                                                                                    }
                                                                                    else if (commentRangeStartText.Any(kvp => run.InnerText.EndsWith(kvp.Value)))
                                                                                    {

                                                                                        var key = 0;
                                                                                        foreach (var val in commentRangeStartText)
                                                                                        {

                                                                                            if (run.InnerText.EndsWith(val.Value))
                                                                                            {
                                                                                                key = val.Key;
                                                                                            }

                                                                                        }

                                                                                        //  var key = commentRangeStartText.FirstOrDefault(x => x.Value == run.InnerText.Trim()).Key;
                                                                                        if (!string.IsNullOrEmpty(key.ToString()))
                                                                                        {

                                                                                            run.InsertBeforeSelf(new CommentRangeStart() { Id = key.ToString() });
                                                                                            RunProperties rpr = new RunProperties(new RunStyle() { Val = "CommentReference" });

                                                                                            run.InsertAfterSelf(new Run(new CommentReference() { Id = key.ToString() })).Append(rpr);
                                                                                            run.InsertAfterSelf(new CommentRangeEnd() { Id = key.ToString() });
                                                                                            new Run(new CommentReference() { Id = key.ToString() });
                                                                                        }

                                                                                    }
                                                                                    //--------------------end-----------------------------------------------------------


                                                                                    PubMedPattern = GlobalMethods.ReplaceWholeWord(PubMedPattern, "Group" + GrpNo, match.Groups[nGrpCounter + 1].Value);
                                                                                }
                                                                            }
                                                                        }
                                                                        else if (tmpstr.Contains("space"))
                                                                        {
                                                                            Run run = P.AppendChild(new Run());
                                                                            //OpenXmlAttribute openXmlAttribute = new OpenXmlAttribute("space", "xml", "preserve");
                                                                            // Add Text to the Run element.
                                                                            Text T = new Text(" ") { Space = SpaceProcessingModeValues.Preserve };
                                                                            //T.SetAttribute(openXmlAttribute);
                                                                            run.AppendChild(T);
                                                                        }
                                                                        else if (tmpstr.Contains("blank"))
                                                                        {
                                                                        }
                                                                        else if (tmpstr.Contains("value"))
                                                                        {
                                                                            Run run = P.AppendChild(new Run());
                                                                            // Add Text to the Run element.
                                                                            if (((match.Groups[nGrpCounter + 1].Value)) != null && ((match.Groups[nGrpCounter + 1].Value) == "-"))   //23_4_2019
                                                                            {
                                                                                string s = (match.Groups[nGrpCounter + 1].Value).Replace("-", "–");
                                                                                run.AppendChild(new Text(s));
                                                                                PubMedPattern = GlobalMethods.ReplaceWholeWord(PubMedPattern, "Group" + GrpNo, s);
                                                                            }
                                                                            else
                                                                            {
                                                                                run.AppendChild(new Text(match.Groups[nGrpCounter + 1].Value));
                                                                                PubMedPattern = GlobalMethods.ReplaceWholeWord(PubMedPattern, "Group" + GrpNo, match.Groups[nGrpCounter + 1].Value);
                                                                            }
                                                                        }
                                                                        else
                                                                        {
                                                                            Run run = new Run(new RunProperties(new RunStyle() { Val = tmpstr }));
                                                                            P.AppendChild(run);
                                                                            // Add Text to the Run element.
                                                                            run.AppendChild(new Text(match.Groups[nGrpCounter + 1].Value));
                                                                            //---------Develope Name:Priyanka Vishwakarma ,Date:4_6_2019 ,Requirement: for adding Comment in Reference.
                                                                            //------code for comment on surname...
                                                                            if (commentRangeStartText.ContainsValue(run.InnerText.Trim()))
                                                                            {

                                                                                var key = commentRangeStartText.FirstOrDefault(x => x.Value == run.InnerText.Trim()).Key;
                                                                                if (!string.IsNullOrEmpty(key.ToString()))
                                                                                {

                                                                                    run.InsertBeforeSelf(new CommentRangeStart() { Id = key.ToString() });
                                                                                    RunProperties rpr = new RunProperties(new RunStyle() { Val = "CommentReference" });

                                                                                    run.InsertAfterSelf(new Run(new CommentReference() { Id = key.ToString() })).Append(rpr);
                                                                                    run.InsertAfterSelf(new CommentRangeEnd() { Id = key.ToString() });
                                                                                    new Run(new CommentReference() { Id = key.ToString() });
                                                                                }

                                                                            }

                                                                            //-----------------end----------------------------------------------
                                                                            PubMedPattern = GlobalMethods.ReplaceWholeWord(PubMedPattern, "Group" + GrpNo, match.Groups[nGrpCounter + 1].Value);
                                                                        }
                                                                    }
                                                                }

                                                                if (PubMedPattern.Contains("Group") == false)
                                                                {
                                                                    // Extract PmID from PubMed //
                                                                    string retPMIDVal = null;

                                                                    retPMIDVal = PubMed.ExtractPMID("http://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=pubmed&retmode=XML&retmax=1000&term=" + PubMedPattern);

                                                                    if (retPMIDVal != null && retPMIDVal != "")
                                                                    {
                                                                        // Build the new Hyperlink with the PMID to be inserted as Hyperlink //

                                                                        //add the url
                                                                        string urlLabel = "PubMed";
                                                                        System.Uri uri = new Uri("http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&list_uids=" + retPMIDVal + "&dopt=Abstract");

                                                                        bool bExtRefFound = false;
                                                                        foreach (HyperlinkRelationship hRel in WPD.MainDocumentPart.HyperlinkRelationships)
                                                                        {
                                                                            if (hRel.Uri == uri)
                                                                            {
                                                                                bExtRefFound = true;
                                                                            }
                                                                        }

                                                                        if (!bExtRefFound)
                                                                        {
                                                                            // Add the new URL to document Relations
                                                                            HyperlinkRelationship rel = MDP.AddHyperlinkRelationship(uri, true);
                                                                            string relationshipId = rel.Id;

                                                                            Hyperlink hlink = new Hyperlink(new Run(new RunProperties(new RunStyle() { Val = "bibmedline" }), new Text("PubMed"))) { History = OnOffValue.FromBoolean(true), Id = relationshipId };

                                                                            // Insert PubMed ID at the end of the newly marked Reference //

                                                                            P.AppendChild(hlink);
                                                                        }
                                                                    }
                                                                }

                                                                // Insert Journal closing tag here //
                                                                Run newrunb = P.AppendChild(new Run());
                                                                // Add Text to the Run element.
                                                                newrunb.AppendChild(new Text("</edb>"));
                                                                //---------Develope Name:Priyanka Vishwakarma ,Date:4_6_2019 ,Requirement: for adding Comment in Reference.
                                                                if (commentRangeStartText.ContainsValue(newrunb.InnerText.Trim()))
                                                                {
                                                                    var key = commentRangeStartText.FirstOrDefault(x => x.Value == newrunb.InnerText.Trim()).Key;
                                                                    if (!string.IsNullOrEmpty(key.ToString()))
                                                                    {

                                                                        newrunb.InsertBeforeSelf(new CommentRangeStart() { Id = key.ToString() });
                                                                        RunProperties rpr = new RunProperties(new RunStyle() { Val = "CommentReference" });

                                                                        newrunb.InsertAfterSelf(new Run(new CommentReference() { Id = key.ToString() })).Append(rpr);
                                                                        newrunb.InsertAfterSelf(new CommentRangeEnd() { Id = key.ToString() });
                                                                        new Run(new CommentReference() { Id = key.ToString() });
                                                                    }

                                                                }
                                                                //--------------------end-----------------------------------------------------------

                                                                goto NextRef;
                                                            }

                                                            NextRefPat:
                                                            {
                                                            }
                                                        }

                                                    }
                                                }
                                            }

                                            //strRefGroups.Clear();

                                            NextRefSearchPattern:
                                            {
                                                continue;
                                            }
                                        }


                                    }





                                    #endregion
                                    //Run newrunx = P.AppendChild(new Run());
                                    //// Add Text to the Run element.
                                    //newrunx.AppendChild(new Text("<bok>"));

                                    //// Insert Reference Number //

                                    //Run run3 = new Run(new RunProperties(new RunStyle() { Val = "bibnumber" }));
                                    //P.AppendChild(run3);
                                    //// Add Text to the Run element.
                                    //run3.AppendChild(new Text(nRefNumberCounter.ToString()));

                                    //Run newrun4 = P.AppendChild(new Run());
                                    //// Add Text to the Run element.
                                    //newrun4.AppendChild(new Text(". ") { Space = SpaceProcessingModeValues.Preserve });

                                    //Run newrun5 = P.AppendChild(new Run());
                                    //// Add Text to the Run element.
                                    //newrun5.AppendChild(new Text(strReferenceText.Trim()));

                                    //Run newrunt = P.AppendChild(new Run());
                                    //// Add Text to the Run element.
                                    //newrunt.AppendChild(new Text("</bok>"));

                                    //goto NextRef;
                                }



                                #endregion


                                #region else for <jrn> tag
                                // Check if the reference is other or Journal reference //
                                else if (jrnRefFind == true)
                                {
                                    if (strReferenceText != "")

                                        strReferenceText = strReferenceText.Replace("–", "-");


                                    //bib_medline style for Pubmed to be inserted //


                                    for (int i = 0; i < strRefPatterns.Count; i++)
                                    {
                                        if (strRefPatterns[i].ToLower().StartsWith("[pattern start]") == true)
                                        {
                                            nPatternIndex++;
                                            strRefGroups.Clear();
                                            bPatternStart = true;
                                            continue;
                                        }

                                        if (bPatternStart == true)
                                        {
                                            if (strRefPatterns[i].ToLower().StartsWith("searchpattern:") == true)
                                            {
                                                SearchPattern = strRefPatterns[i].Replace("SearchPattern:", "");

                                                if (SearchPattern.Contains(@"(et al)(\.)"))
                                                {
                                                    //Console.WriteLine("Got it");
                                                }

                                                continue;
                                            }

                                            if (strRefPatterns[i].ToLower().StartsWith("replacegroup:") == true)
                                            {
                                                string RpGrp = strRefPatterns[i].Replace("ReplaceGroup:", "");
                                                ReplaceGrpCount = Convert.ToInt32(RpGrp);
                                                continue;
                                            }

                                            if (strRefPatterns[i].ToLower().StartsWith("pubmed:") == true)
                                            {
                                                PubMedPattern = strRefPatterns[i].Replace("Pubmed:", "");
                                                continue;
                                            }

                                            if (strRefPatterns[i].ToLower().StartsWith("group:") == true)
                                            {
                                                strRefGroups.Add(strRefPatterns[i].Replace("Group:", ""));
                                                continue;
                                            }
                                        }

                                        if (strRefPatterns[i].ToLower().StartsWith("[pattern end]") == true)
                                        {
                                            bPatternStart = false;

                                            // Build the search Pattern by Replacing the JournalInfo

                                            for (nIndex = 0; nIndex < strJournalsColl.Count; nIndex++)
                                            {
                                                string strTmp; //= strJournalsColl[nIndex].Replace("(", @"\(").Replace(")", @"\)").Replace(".", @"\.");

                                                if (strReferenceText.Contains(strJournalsColl[nIndex]))
                                                {

                                                    strTmp = strJournalsColl[nIndex].Replace("(", @"\(").Replace(")", @"\)").Replace(".", @"\.");
                                                    strRefSearchPattern.Add(SearchPattern.Replace("(JournalInfo)", "(" + strTmp + ")"));
                                                    break;
                                                }
                                            }

                                            if (strRefSearchPattern.Count > 0)
                                            {
                                                // Search operation is ready

                                                if (ReplaceGrpCount > 0)
                                                {
                                                    if (strRefGroups.Count != ReplaceGrpCount)
                                                    {
                                                        strRefGroups.Clear();
                                                        goto NextRefSearchPattern;
                                                    }

                                                    for (nIndex = 0; nIndex < strRefSearchPattern.Count; nIndex++)
                                                    {
                                                        MatchCollection matches = Regex.Matches(strReferenceText, strRefSearchPattern[nIndex]);

                                                        if (matches.Count == 1)
                                                        {
                                                            //if (strReferenceText.Contains("et al") && strRefSearchPattern[nIndex].Contains("et al") == false)
                                                            //{
                                                            //    goto NextRefPat;
                                                            //}



                                                            foreach (Match match in matches)
                                                            {
                                                                if ((match.Groups.Count - 1) != ReplaceGrpCount)
                                                                {
                                                                    goto NextRefPat;   //---------Develope Name:Priyanka Vishwakarma ,Date:24_6_2019 ,Requirement:missing references because of group not match , integrated by:Vikas sir..
                                                                    //break;
                                                                }

                                                                //---------Develope Name:Priyanka Vishwakarma ,Date:4_6_2019 ,Requirement: for adding Comment in Reference.
                                                                foreach (var PS in P.Descendants().ToList().Where(x => x.XName == W.commentRangeStart).ToList())
                                                                {

                                                                    PS.Remove();
                                                                }
                                                                foreach (var PE in P.Descendants().ToList().Where(x => x.XName == W.commentRangeEnd).ToList())
                                                                {

                                                                    PE.Remove();
                                                                }
                                                                foreach (var PR in P.Descendants().ToList().Where(x => x.XName == W.commentReference).ToList())
                                                                {

                                                                    PR.Remove();
                                                                }

                                                                //------------------------------End----------------------------------
                                                                // Extract group info 
                                                                int GrpNo = 0;
                                                                PubMedPattern = GlobalMethods.ReplaceWholeWord(PubMedPattern, "space", " ");
                                                                for (nGrpCounter = 0; nGrpCounter < strRefGroups.Count; nGrpCounter++)
                                                                {
                                                                    string tmpstr = null;
                                                                    tmpstr = strRefGroups[nGrpCounter];
                                                                    GrpNo = 0;
                                                                    GrpNo = nGrpCounter + 1;

                                                                    if (nGrpCounter == 0)
                                                                    {
                                                                        Run newruna = P.AppendChild(new Run());
                                                                        // Add Text to the Run element.
                                                                        newruna.AppendChild(new Text("<jrn>"));
                                                                        if (numberedRef)
                                                                        {
                                                                            // Insert Reference Number //
                                                                            Run run = new Run(new RunProperties(new RunStyle() { Val = "bibnumber" }));
                                                                            P.AppendChild(run);
                                                                            // Add Text to the Run element.
                                                                            run.AppendChild(new Text(nRefNumberCounter.ToString()));


                                                                            //---------Develope Name:Priyanka Vishwakarma ,Date:4_6_2019 ,Requirement: for adding Comment in Reference.
                                                                            if (commentRangeStartText.ContainsValue(run.InnerText.Trim()))
                                                                            {
                                                                                var key = commentRangeStartText.FirstOrDefault(x => x.Value == run.InnerText.Trim()).Key;
                                                                                if (!string.IsNullOrEmpty(key.ToString()))
                                                                                {
                                                                                    run.InsertBeforeSelf(new CommentRangeStart() { Id = key.ToString() });
                                                                                    RunProperties rpr = new RunProperties(new RunStyle() { Val = "CommentReference" });

                                                                                    run.InsertAfterSelf(new Run(new CommentReference() { Id = key.ToString() })).Append(rpr);
                                                                                    run.InsertAfterSelf(new CommentRangeEnd() { Id = key.ToString() });
                                                                                    new Run(new CommentReference() { Id = key.ToString() });
                                                                                }

                                                                            }
                                                                            //--------------------end-----------------------------------------------------------

                                                                            Run newrun2 = P.AppendChild(new Run());
                                                                            // Add Text to the Run element.
                                                                            newrun2.AppendChild(new Text(". ") { Space = SpaceProcessingModeValues.Preserve });
                                                                        }
                                                                    }

                                                                    if (tmpstr.Contains(":"))
                                                                    {
                                                                        // Split the string
                                                                        string[] separators = { ":" };
                                                                        string[] strValues = tmpstr.Split(separators, StringSplitOptions.RemoveEmptyEntries);

                                                                        if (strValues.Length > 0)
                                                                        {
                                                                            if (strValues[0] == "space")
                                                                            {
                                                                                Run run = P.AppendChild(new Run());
                                                                                //OpenXmlAttribute openXmlAttribute = new OpenXmlAttribute("space", "xml", "preserve");
                                                                                // Add Text to the Run element.
                                                                                Text T = new Text(" ") { Space = SpaceProcessingModeValues.Preserve };
                                                                                //T.SetAttribute(openXmlAttribute);
                                                                                run.AppendChild(T);
                                                                            }
                                                                            else if (strValues[0] == "blank")
                                                                            {
                                                                                // No action required
                                                                            }
                                                                            else if (strValues[0] == "value")
                                                                            {
                                                                                Run run = P.AppendChild(new Run());
                                                                                // Add Text to the Run element.
                                                                                run.AppendChild(new Text(match.Groups[nGrpCounter + 1].Value));

                                                                                PubMedPattern = GlobalMethods.ReplaceWholeWord(PubMedPattern, "Group" + GrpNo, match.Groups[nGrpCounter + 1].Value);
                                                                            }

                                                                            if (strValues[1] != "") // Style
                                                                            {
                                                                                Run run = new Run(new RunProperties(new RunStyle() { Val = strValues[1] }));
                                                                                P.AppendChild(run);
                                                                                // Add Text to the Run element.
                                                                                run.AppendChild(new Text(match.Groups[nGrpCounter + 1].Value));

                                                                                //---------Develope Name:Priyanka Vishwakarma ,Date:4_6_2019 ,Requirement: for adding Comment in Reference.

                                                                                if (commentRangeStartText.ContainsValue(run.InnerText.Trim()))
                                                                                {

                                                                                    var key = commentRangeStartText.FirstOrDefault(x => x.Value == run.InnerText.Trim()).Key;
                                                                                    if (!string.IsNullOrEmpty(key.ToString()))
                                                                                    {

                                                                                        run.InsertBeforeSelf(new CommentRangeStart() { Id = key.ToString() });
                                                                                        RunProperties rpr = new RunProperties(new RunStyle() { Val = "CommentReference" });

                                                                                        run.InsertAfterSelf(new Run(new CommentReference() { Id = key.ToString() })).Append(rpr);
                                                                                        run.InsertAfterSelf(new CommentRangeEnd() { Id = key.ToString() });
                                                                                        new Run(new CommentReference() { Id = key.ToString() });
                                                                                    }

                                                                                }
                                                                                else if (commentRangeStartText.Any(kvp => run.InnerText.StartsWith(kvp.Value)))
                                                                                {

                                                                                    var key = 0;
                                                                                    foreach (var val in commentRangeStartText)
                                                                                    {

                                                                                        if (run.InnerText.StartsWith(val.Value))
                                                                                        {
                                                                                            key = val.Key;
                                                                                        }

                                                                                    }

                                                                                    //var key = commentRangeStartText.Where(x => run.InnerText.StartsWith(x.Value));

                                                                                    // var key = commentRangeStartText.FirstOrDefault(x => x.Value == run.InnerText.Trim()).Key;

                                                                                    if (!string.IsNullOrEmpty(key.ToString()))
                                                                                    {

                                                                                        run.InsertBeforeSelf(new CommentRangeStart() { Id = key.ToString() });
                                                                                        RunProperties rpr = new RunProperties(new RunStyle() { Val = "CommentReference" });

                                                                                        run.InsertAfterSelf(new Run(new CommentReference() { Id = key.ToString() })).Append(rpr);
                                                                                        run.InsertAfterSelf(new CommentRangeEnd() { Id = key.ToString() });
                                                                                        new Run(new CommentReference() { Id = key.ToString() });
                                                                                    }

                                                                                }
                                                                                else if (commentRangeStartText.Any(kvp => run.InnerText.EndsWith(kvp.Value)))
                                                                                {

                                                                                    var key = 0;
                                                                                    foreach (var val in commentRangeStartText)
                                                                                    {

                                                                                        if (run.InnerText.EndsWith(val.Value))
                                                                                        {
                                                                                            key = val.Key;
                                                                                        }

                                                                                    }

                                                                                    //  var key = commentRangeStartText.FirstOrDefault(x => x.Value == run.InnerText.Trim()).Key;
                                                                                    if (!string.IsNullOrEmpty(key.ToString()))
                                                                                    {

                                                                                        run.InsertBeforeSelf(new CommentRangeStart() { Id = key.ToString() });
                                                                                        RunProperties rpr = new RunProperties(new RunStyle() { Val = "CommentReference" });

                                                                                        run.InsertAfterSelf(new Run(new CommentReference() { Id = key.ToString() })).Append(rpr);
                                                                                        run.InsertAfterSelf(new CommentRangeEnd() { Id = key.ToString() });
                                                                                        new Run(new CommentReference() { Id = key.ToString() });
                                                                                    }

                                                                                }
                                                                                //--------------------end-----------------------------------------------------------

                                                                                PubMedPattern = GlobalMethods.ReplaceWholeWord(PubMedPattern, "Group" + GrpNo, match.Groups[nGrpCounter + 1].Value);
                                                                            }
                                                                        }
                                                                    }
                                                                    else if (tmpstr.Contains("space"))
                                                                    {
                                                                        Run run = P.AppendChild(new Run());
                                                                        //OpenXmlAttribute openXmlAttribute = new OpenXmlAttribute("space", "xml", "preserve");
                                                                        // Add Text to the Run element.
                                                                        Text T = new Text(" ") { Space = SpaceProcessingModeValues.Preserve };
                                                                        //T.SetAttribute(openXmlAttribute);
                                                                        run.AppendChild(T);
                                                                    }
                                                                    else if (tmpstr.Contains("blank"))
                                                                    {
                                                                    }
                                                                    else if (tmpstr.Contains("value"))
                                                                    {
                                                                        Run run = P.AppendChild(new Run());
                                                                        // Add Text to the Run element.
                                                                        if (((match.Groups[nGrpCounter + 1].Value)) != null && ((match.Groups[nGrpCounter + 1].Value) == "-"))   //23_4_2019
                                                                        {
                                                                            string s = (match.Groups[nGrpCounter + 1].Value).Replace("-", "–");
                                                                            run.AppendChild(new Text(s));
                                                                            PubMedPattern = GlobalMethods.ReplaceWholeWord(PubMedPattern, "Group" + GrpNo, s);
                                                                        }
                                                                        else
                                                                        {
                                                                            run.AppendChild(new Text(match.Groups[nGrpCounter + 1].Value));
                                                                            PubMedPattern = GlobalMethods.ReplaceWholeWord(PubMedPattern, "Group" + GrpNo, match.Groups[nGrpCounter + 1].Value);
                                                                        }
                                                                    }
                                                                    else
                                                                    {
                                                                        Run run = new Run(new RunProperties(new RunStyle() { Val = tmpstr }));
                                                                        P.AppendChild(run);
                                                                        // Add Text to the Run element.
                                                                        run.AppendChild(new Text(match.Groups[nGrpCounter + 1].Value));
                                                                        //---------Develope Name:Priyanka Vishwakarma ,Date:4_6_2019 ,Requirement: for adding Comment in Reference.
                                                                        //------code for comment on surname...
                                                                        if (commentRangeStartText.ContainsValue(run.InnerText.Trim()))
                                                                        {

                                                                            var key = commentRangeStartText.FirstOrDefault(x => x.Value == run.InnerText.Trim()).Key;
                                                                            if (!string.IsNullOrEmpty(key.ToString()))
                                                                            {

                                                                                run.InsertBeforeSelf(new CommentRangeStart() { Id = key.ToString() });
                                                                                RunProperties rpr = new RunProperties(new RunStyle() { Val = "CommentReference" });

                                                                                run.InsertAfterSelf(new Run(new CommentReference() { Id = key.ToString() })).Append(rpr);
                                                                                run.InsertAfterSelf(new CommentRangeEnd() { Id = key.ToString() });
                                                                                new Run(new CommentReference() { Id = key.ToString() });
                                                                            }

                                                                        }

                                                                        //-----------------end----------------------------------------------

                                                                        //----------------------------------
                                                                        PubMedPattern = GlobalMethods.ReplaceWholeWord(PubMedPattern, "Group" + GrpNo, match.Groups[nGrpCounter + 1].Value);
                                                                    }
                                                                }
                                                            }

                                                            if (PubMedPattern.Contains("Group") == false)
                                                            {
                                                                // Extract PmID from PubMed //
                                                                string retPMIDVal = null;

                                                                retPMIDVal = PubMed.ExtractPMID("http://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=pubmed&retmode=XML&retmax=1000&term=" + PubMedPattern);

                                                                if (retPMIDVal != null && retPMIDVal != "")
                                                                {
                                                                    // Build the new Hyperlink with the PMID to be inserted as Hyperlink //

                                                                    //add the url
                                                                    string urlLabel = "PubMed";
                                                                    System.Uri uri = new Uri("http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&list_uids=" + retPMIDVal + "&dopt=Abstract");

                                                                    bool bExtRefFound = false;
                                                                    foreach (HyperlinkRelationship hRel in WPD.MainDocumentPart.HyperlinkRelationships)
                                                                    {
                                                                        if (hRel.Uri == uri)
                                                                        {
                                                                            bExtRefFound = true;
                                                                        }
                                                                    }

                                                                    if (!bExtRefFound)
                                                                    {
                                                                        // Add the new URL to document Relations
                                                                        HyperlinkRelationship rel = MDP.AddHyperlinkRelationship(uri, true);
                                                                        string relationshipId = rel.Id;

                                                                        Hyperlink hlink = new Hyperlink(new Run(new RunProperties(new RunStyle() { Val = "bibmedline" }), new Text("PubMed"))) { History = OnOffValue.FromBoolean(true), Id = relationshipId };

                                                                        // Insert PubMed ID at the end of the newly marked Reference //

                                                                        P.AppendChild(hlink);
                                                                    }
                                                                }
                                                            }

                                                            // Insert Journal closing tag here //
                                                            Run newrunb = P.AppendChild(new Run());
                                                            // Add Text to the Run element.
                                                            newrunb.AppendChild(new Text("</jrn>"));
                                                            //---------Develope Name:Priyanka Vishwakarma ,Date:4_6_2019 ,Requirement: for adding Comment in Reference.
                                                            if (commentRangeStartText.ContainsValue(newrunb.InnerText.Trim()))
                                                            {
                                                                var key = commentRangeStartText.FirstOrDefault(x => x.Value == newrunb.InnerText.Trim()).Key;
                                                                if (!string.IsNullOrEmpty(key.ToString()))
                                                                {

                                                                    newrunb.InsertBeforeSelf(new CommentRangeStart() { Id = key.ToString() });
                                                                    RunProperties rpr = new RunProperties(new RunStyle() { Val = "CommentReference" });

                                                                    newrunb.InsertAfterSelf(new Run(new CommentReference() { Id = key.ToString() })).Append(rpr);
                                                                    newrunb.InsertAfterSelf(new CommentRangeEnd() { Id = key.ToString() });
                                                                    new Run(new CommentReference() { Id = key.ToString() });
                                                                }

                                                            }
                                                            //--------------------end-----------------------------------------------------------

                                                            goto NextRef;
                                                        }

                                                        NextRefPat:
                                                        {
                                                        }
                                                    }
                                                }
                                            }
                                        }

                                        //strRefGroups.Clear();

                                        NextRefSearchPattern:
                                        {
                                            continue;
                                        }
                                    }
                                }
                                #endregion

                                if (jrnRefFind == true)
                                {
                                    //Developer Name:Priyanka Vishwakarma ,Date:6_6_2019 ,Requirement:Add Para as it is if New Pattern of Reference Comes ,Integrated By:Vikas Sir.
                                    P.InsertAfterSelf(newP);
                                    P.Remove();
                                    strRefGroups.Clear();
                                    //// P.InsertAfterSelf(newP);
                                    //Run newrunc = P.AppendChild(new Run());
                                    //// Add Text to the Run element.
                                    //newrunc.AppendChild(new Text("<jrn>"));

                                    //// Insert Reference Number //
                                    //Run run1 = new Run(new RunProperties(new RunStyle() { Val = "bibnumber" }));
                                    //P.AppendChild(run1);
                                    //// Add Text to the Run element.
                                    //run1.AppendChild(new Text(nRefNumberCounter.ToString()));
                                    ////-------------------------------------------------3_6_2019 for adding Comment
                                    //if (commentRangeStartText.ContainsValue(run1.InnerText.Trim()))     //Develope Name:Priyanka Vishwakarma ,Date:4_6_2019 ,Requirement: for adding Comment in Reference., Integrated By:Vikas Sir.
                                    //{
                                    //    foreach (var PS in P.Descendants().ToList().Where(x => x.XName == W.commentRangeStart).ToList())
                                    //    {
                                    //        PS.Remove();
                                    //    }
                                    //    foreach (var PE in P.Descendants().ToList().Where(x => x.XName == W.commentRangeEnd).ToList())
                                    //    {
                                    //        PE.Remove();
                                    //    }
                                    //    foreach (var PR in P.Descendants().ToList().Where(x => x.XName == W.commentReference).ToList())
                                    //    {
                                    //        PR.Remove();
                                    //    }

                                    //    var key = commentRangeStartText.FirstOrDefault(x => x.Value == run1.InnerText.Trim()).Key;
                                    //    if (!string.IsNullOrEmpty(key.ToString()))
                                    //    {
                                    //        run1.InsertBeforeSelf(new CommentRangeStart() { Id = key.ToString() });
                                    //        RunProperties rpr = new RunProperties(new RunStyle() { Val = "CommentReference" });

                                    //        run1.InsertAfterSelf(new Run(new CommentReference() { Id = key.ToString() })).Append(rpr);
                                    //        run1.InsertAfterSelf(new CommentRangeEnd() { Id = key.ToString() });
                                    //        new Run(new CommentReference() { Id = key.ToString() });
                                    //    }

                                    //}
                                    ////--------------------end-----------------------------------------------------------

                                    //Run newrun1 = P.AppendChild(new Run());
                                    //// Add Text to the Run element.
                                    //newrun1.AppendChild(new Text(". ") { Space = SpaceProcessingModeValues.Preserve });

                                    //Run newrun = P.AppendChild(new Run());
                                    //// Add Text to the Run element.
                                    //newrun.AppendChild(new Text(strReferenceText.Trim()));

                                    //Run newruny = P.AppendChild(new Run());
                                    //// Add Text to the Run element.
                                    //newruny.AppendChild(new Text("</jrn>"));

                                    //strRefGroups.Clear();
                                }
                                else if (edbRefFind == true)
                                {
                                    //Developer Name:Priyanka Vishwakarma ,Date:6_6_2019 ,Requirement:Add Para as it is if New Pattern of Reference Comes ,Integrated By:Vikas Sir.
                                    P.InsertAfterSelf(newP);
                                    P.Remove();
                                    strRefGroups.Clear();
                                    //Run newrunx = P.AppendChild(new Run());
                                    //// Add Text to the Run element.
                                    //newrunx.AppendChild(new Text("<edb>"));

                                    //// Insert Reference Number //

                                    //Run run3 = new Run(new RunProperties(new RunStyle() { Val = "bibnumber" }));
                                    //P.AppendChild(run3);
                                    //// Add Text to the Run element.
                                    //run3.AppendChild(new Text(nRefNumberCounter.ToString()));
                                    ////-------------------------------------------------28_5_2019  for adding Comment
                                    //if (commentRangeStartText.ContainsValue(run3.InnerText.Trim()))     //Develope Name:Priyanka Vishwakarma ,Date:28_5_2019 ,Requirement: for adding Comment in Reference.
                                    //{
                                    //    foreach (var PS in P.Descendants().ToList().Where(x => x.XName == W.commentRangeStart).ToList())
                                    //    {
                                    //        PS.Remove();
                                    //    }
                                    //    foreach (var PE in P.Descendants().ToList().Where(x => x.XName == W.commentRangeEnd).ToList())
                                    //    {
                                    //        PE.Remove();
                                    //    }
                                    //    foreach (var PR in P.Descendants().ToList().Where(x => x.XName == W.commentReference).ToList())
                                    //    {
                                    //        PR.Remove();
                                    //    }

                                    //    var key = commentRangeStartText.FirstOrDefault(x => x.Value == run3.InnerText.Trim()).Key;
                                    //    if (!string.IsNullOrEmpty(key.ToString()))
                                    //    {
                                    //        run3.InsertBeforeSelf(new CommentRangeStart() { Id = key.ToString() });
                                    //        RunProperties rpr = new RunProperties(new RunStyle() { Val = "CommentReference" });

                                    //        run3.InsertAfterSelf(new Run(new CommentReference() { Id = key.ToString() })).Append(rpr);
                                    //        run3.InsertAfterSelf(new CommentRangeEnd() { Id = key.ToString() });
                                    //        new Run(new CommentReference() { Id = key.ToString() });
                                    //    }

                                    //}
                                    ////--------------------end-----------------------------------------------------------
                                    //Run newrun4 = P.AppendChild(new Run());
                                    //// Add Text to the Run element.
                                    //newrun4.AppendChild(new Text(". ") { Space = SpaceProcessingModeValues.Preserve });

                                    //Run newrun5 = P.AppendChild(new Run());
                                    //// Add Text to the Run element.
                                    //newrun5.AppendChild(new Text(strReferenceText.Trim()));

                                    //Run newrunt = P.AppendChild(new Run());
                                    //// Add Text to the Run element.
                                    //newrunt.AppendChild(new Text("</edb>"));

                                    //strRefGroups.Clear();
                                }
                                else if (bookRefFind == true)
                                {
                                    //Developer Name:Priyanka Vishwakarma ,Date:6_6_2019 ,Requirement:Add Para as it is if New Pattern of Reference Comes ,Integrated By:Vikas Sir.
                                    P.InsertAfterSelf(newP);
                                    P.Remove();
                                    strRefGroups.Clear();
                                    //Run newrunx = P.AppendChild(new Run());
                                    //// Add Text to the Run element.
                                    //newrunx.AppendChild(new Text("<bok>"));

                                    //// Insert Reference Number //

                                    //Run run3 = new Run(new RunProperties(new RunStyle() { Val = "bibnumber" }));
                                    //P.AppendChild(run3);
                                    //// Add Text to the Run element.
                                    //run3.AppendChild(new Text(nRefNumberCounter.ToString()));
                                    ////-------------------------------------------------3_6_2019 for adding Comment
                                    //if (commentRangeStartText.ContainsValue(run3.InnerText.Trim()))     //Develope Name:Priyanka Vishwakarma ,Date:3_6_2019 ,Requirement: for adding Comment in Reference.
                                    //{
                                    //    foreach (var PS in P.Descendants().ToList().Where(x => x.XName == W.commentRangeStart).ToList())
                                    //    {
                                    //        PS.Remove();
                                    //    }
                                    //    foreach (var PE in P.Descendants().ToList().Where(x => x.XName == W.commentRangeEnd).ToList())
                                    //    {
                                    //        PE.Remove();
                                    //    }
                                    //    foreach (var PR in P.Descendants().ToList().Where(x => x.XName == W.commentReference).ToList())
                                    //    {
                                    //        PR.Remove();
                                    //    }

                                    //    var key = commentRangeStartText.FirstOrDefault(x => x.Value == run3.InnerText.Trim()).Key;
                                    //    if (!string.IsNullOrEmpty(key.ToString()))
                                    //    {
                                    //        run3.InsertBeforeSelf(new CommentRangeStart() { Id = key.ToString() });
                                    //        RunProperties rpr = new RunProperties(new RunStyle() { Val = "CommentReference" });

                                    //        run3.InsertAfterSelf(new Run(new CommentReference() { Id = key.ToString() })).Append(rpr);
                                    //        run3.InsertAfterSelf(new CommentRangeEnd() { Id = key.ToString() });
                                    //        new Run(new CommentReference() { Id = key.ToString() });
                                    //    }

                                    //}
                                    //--------------------end-----------------------------------------------------------

                                    //Run newrun4 = P.AppendChild(new Run());
                                    //// Add Text to the Run element.
                                    //newrun4.AppendChild(new Text(". ") { Space = SpaceProcessingModeValues.Preserve });

                                    //Run newrun5 = P.AppendChild(new Run());
                                    //// Add Text to the Run element.
                                    //newrun5.AppendChild(new Text(strReferenceText.Trim()));

                                    //Run newrunt = P.AppendChild(new Run());
                                    //// Add Text to the Run element.
                                    //newrunt.AppendChild(new Text("</bok>"));

                                    //strRefGroups.Clear();
                                }
                                else
                                {
                                    // newP = P;   //Commented by Priyanka on 01012019 
                                    P.InsertAfterSelf(newP);
                                    P.Remove();
                                    strRefGroups.Clear();

                                }

                                //sw1.WriteLine(strReferenceText);
                                //sw1.WriteLine("");

                                NextRef:
                                {
                                    continue;
                                }
                            }
                        }
                    }
                }

                D.Save();
            }
        }


        //private static void MergeReferenceElementsIntoOneGroup(string newDoc, string RefPatternFile, string JournalDB, string PublisherDB)
        //{
        //    // Read the Reference patterns from the configuration and store in list
        //    List<string> strRefPatterns = new List<string>();
        //    strRefPatterns = GlobalMethods.ReadAndStoreFileValuesInArray(RefPatternFile);

        //    // Read the Journal list from the configuration and store in list

        //    List<string> strJournalsColl = new List<string>();
        //    strJournalsColl = GlobalMethods.ReadAndStoreFileValuesInArray(JournalDB);

        //    // Sort the Journals array on length //
        //    strJournalsColl = GlobalMethods.SortStringListOnLength(strJournalsColl);

        //    List<string> strPublisherColl = new List<string>();
        //    strPublisherColl = GlobalMethods.ReadAndStoreFileValuesInArray(PublisherDB);

        //    // Sort the Publisher array on length //
        //    strPublisherColl = GlobalMethods.SortStringListOnLength(strPublisherColl);

        //    //string strUsedPatternFilename = ConfigurationManager.AppSettings.Get("UsedPattern");
        //    //StreamWriter sw = new StreamWriter(strUsedPatternFilename);

        //    //string strUnStructuredReferencesFilename = ConfigurationManager.AppSettings.Get("UnStructuredReferences");
        //    //StreamWriter sw1 = new StreamWriter(strUnStructuredReferencesFilename);


        //    int nRefNumberCounter = 0;

        //    using (WordprocessingDocument WPD = WordprocessingDocument
        //        .Open(newDoc, true))
        //    {
        //        SimplifyMarkupSettings settings = new SimplifyMarkupSettings
        //        {
        //            //RemoveComments = false,
        //            RemoveContentControls = true,
        //            RemoveEndAndFootNotes = false,
        //            RemoveFieldCodes = false,
        //            RemoveLastRenderedPageBreak = true,
        //            RemovePermissions = true,
        //            RemoveProof = true,
        //            RemoveRsidInfo = true,
        //            RemoveSmartTags = true,
        //            RemoveSoftHyphens = false,
        //            ReplaceTabsWithSpaces = false,
        //        };

        //        MarkupSimplifier.SimplifyMarkup(WPD, settings);

        //        MainDocumentPart MDP = WPD.MainDocumentPart;

        //        Document D = MDP.Document;

        //        bool bParaHasStructuredRef = false;

        //        // Search all Paragraphs that is "TOC1 to TOC3" style.
        //        foreach (Paragraph P in D.Descendants<Paragraph>().ToList().
        //            Where(e => e.ParagraphProperties != null
        //                && e.ParagraphProperties.ParagraphStyleId != null
        //                && e.ParagraphProperties.ParagraphStyleId.Val == "REF1"))
        //        {
        //            bParaHasStructuredRef = false;

        //            if (P.HasChildren == false)
        //            {
        //                try
        //                {
        //                    P.Remove();
        //                }
        //                catch (Exception ex)
        //                {
        //                    Console.WriteLine(ex.Message);
        //                }
        //            }
        //            else
        //            {
        //                if (P.HasChildren == true)
        //                {
        //                    if(P.Descendants<Run>().Count() > 0 )
        //                    {
        //                        List<OpenXmlElement> RList = P.Descendants<OpenXmlElement>().ToList();

        //                        bParaHasStructuredRef = CheckIfParaHasStructuredReference(RList);

        //                        if (bParaHasStructuredRef == true)
        //                        {
        //                            bParaHasStructuredRef = false;
        //                            continue;
        //                        }

        //                        if (P.InnerText.ToLower().StartsWith("<bok>"))
        //                        {
        //                            goto NextRef;
        //                        }

        //                        string strReferenceText = null;

        //                        foreach (Run R in P.Descendants<Run>().ToList())
        //                        {
        //                            foreach (Text T in R.Descendants<Text>().ToList())
        //                            {
        //                                strReferenceText = strReferenceText + T.Text;
        //                            }

        //                            R.Remove();
        //                        }

        //                        if (strReferenceText.Trim() == "")
        //                        {
        //                            P.Remove();
        //                            goto NextRef;
        //                        }

        //                        if (strReferenceText == "<jrn> </jrn>")
        //                        {
        //                            P.Remove();
        //                            goto NextRef;
        //                        }

        //                        if (strReferenceText == "<jrn> ")
        //                        {
        //                            P.Remove();
        //                            goto NextRef;
        //                        }

        //                        // if already tagged reference //
        //                        if (strReferenceText.ToLower().StartsWith("<bok>") || strReferenceText.ToLower().StartsWith("<unknown>") || strReferenceText.ToLower().StartsWith("<jrn>"))
        //                        {
        //                            goto NextRef;
        //                        }

        //                        // Increment the Reference Counter
        //                        nRefNumberCounter++;

        //                        // Check if the reference is other //

        //                        if (strReferenceText.ToLower().Contains("www.") || strReferenceText.ToLower().Contains("http:") || strReferenceText.ToLower().Contains("https:") || strReferenceText.ToLower().Contains("conference")
        //                            || strReferenceText.ToLower().Contains("presented at") || strReferenceText.ToLower().Contains("presentation at")) 
        //                        {
        //                            // Insert Reference Number //

        //                            Run newrunx = P.AppendChild(new Run());
        //                            // Add Text to the Run element.
        //                            newrunx.AppendChild(new Text("<unknown>"));

        //                            Run run3 = new Run(new RunProperties(new RunStyle() { Val = "bibnumber" }));
        //                            P.AppendChild(run3);
        //                            // Add Text to the Run element.
        //                            run3.AppendChild(new Text(nRefNumberCounter.ToString()));

        //                            Run newrun4 = P.AppendChild(new Run());
        //                            // Add Text to the Run element.
        //                            newrun4.AppendChild(new Text(". ") { Space = SpaceProcessingModeValues.Preserve });

        //                            Run newrun5 = P.AppendChild(new Run());
        //                            // Add Text to the Run element.
        //                            newrun5.AppendChild(new Text(Regex.Replace(strReferenceText.Trim(), "(^[0-9]+)(. )", "")));

        //                            Run newrund = P.AppendChild(new Run());
        //                            // Add Text to the Run element.
        //                            newrund.AppendChild(new Text("</unknown>"));

        //                            goto NextRef;
        //                        }

        //                        // Check for Book Reference //

        //                        int nCounter = 0;

        //                        for(nCounter = 0; nCounter < strPublisherColl.Count(); nCounter++)
        //                        {
        //                            if(strReferenceText.Contains(strPublisherColl[nCounter]))
        //                            {
        //                                // Publisher found then mark the reference as Book Reference //

        //                                Run newrunx = P.AppendChild(new Run());
        //                                // Add Text to the Run element.
        //                                newrunx.AppendChild(new Text("<bok>"));

        //                                // Insert Reference Number //

        //                                Run run3 = new Run(new RunProperties(new RunStyle() { Val = "bibnumber" }));
        //                                P.AppendChild(run3);
        //                                // Add Text to the Run element.
        //                                run3.AppendChild(new Text(nRefNumberCounter.ToString()));

        //                                Run newrun4 = P.AppendChild(new Run());
        //                                // Add Text to the Run element.
        //                                newrun4.AppendChild(new Text(". ") { Space = SpaceProcessingModeValues.Preserve });

        //                                Run newrun5 = P.AppendChild(new Run());
        //                                // Add Text to the Run element.
        //                                newrun5.AppendChild(new Text(strReferenceText.Trim()));

        //                                Run newrunt = P.AppendChild(new Run());
        //                                // Add Text to the Run element.
        //                                newrunt.AppendChild(new Text("</bok>"));

        //                                goto NextRef;

        //                            }
        //                        }


        //                        if (strReferenceText.ToLower().Contains("eds.") || strReferenceText.ToLower().Contains("in: "))
        //                        {
        //                            // Publisher found then mark the reference as Book Reference //

        //                            Run newrunx = P.AppendChild(new Run());
        //                            // Add Text to the Run element.
        //                            newrunx.AppendChild(new Text("<bok>"));

        //                            // Insert Reference Number //

        //                            Run run3 = new Run(new RunProperties(new RunStyle() { Val = "bibnumber" }));
        //                            P.AppendChild(run3);
        //                            // Add Text to the Run element.
        //                            run3.AppendChild(new Text(nRefNumberCounter.ToString()));

        //                            Run newrun4 = P.AppendChild(new Run());
        //                            // Add Text to the Run element.
        //                            newrun4.AppendChild(new Text(". ") { Space = SpaceProcessingModeValues.Preserve });

        //                            Run newrun5 = P.AppendChild(new Run());
        //                            // Add Text to the Run element.
        //                            newrun5.AppendChild(new Text(Regex.Replace(strReferenceText.Trim(), "(^[0-9]+)(. )", "")));

        //                            Run newrunt = P.AppendChild(new Run());
        //                            // Add Text to the Run element.
        //                            newrunt.AppendChild(new Text("</bok>"));

        //                            goto NextRef;
        //                        }


        //                        // Check if the reference is other or Book reference //

        //                        if (strReferenceText != "")
        //                            strReferenceText = strReferenceText.Replace("–", "-");

        //                        // Build the pattern and Groups before searching and creating runs //

        //                        List<string> strRefGroups = new List<string>();
        //                        bool bPatternStart = false;
        //                        string SearchPattern = null;
        //                        int ReplaceGrpCount=0;
        //                        string PubMedPattern = null;
        //                        strRefGroups.Clear();
        //                        List<string> strRefSearchPattern = new List<string>();
        //                        int nIndex = 0;
        //                        int nGrpCounter = 0;
        //                        int nPatternIndex = 0;

        //                        //bib_medline style for Pubmed to be inserted //


        //                        for (int i= 0; i < strRefPatterns.Count; i++)
        //                        {
        //                            if(strRefPatterns[i].ToLower().StartsWith("[pattern start]") == true)
        //                            {
        //                                nPatternIndex++;
        //                                strRefGroups.Clear();
        //                                bPatternStart = true;
        //                                continue;
        //                            }

        //                            if(bPatternStart == true)
        //                            {
        //                                if (strRefPatterns[i].ToLower().StartsWith("searchpattern:") == true)
        //                                {
        //                                    SearchPattern = strRefPatterns[i].Replace("SearchPattern:", "");

        //                                    if (SearchPattern.Contains(@"(et al)(\.)"))
        //                                    {
        //                                        Console.WriteLine("Got it");
        //                                    }

        //                                    continue;
        //                                }

        //                                if (strRefPatterns[i].ToLower().StartsWith("replacegroup:") == true)
        //                                {
        //                                    string RpGrp = strRefPatterns[i].Replace("ReplaceGroup:", "");
        //                                    ReplaceGrpCount = Convert.ToInt32(RpGrp);
        //                                    continue;
        //                                }

        //                                if (strRefPatterns[i].ToLower().StartsWith("pubmed:") == true)
        //                                {
        //                                    PubMedPattern = strRefPatterns[i].Replace("Pubmed:", "");
        //                                    continue;
        //                                }

        //                                if (strRefPatterns[i].ToLower().StartsWith("group:") == true)
        //                                {
        //                                    strRefGroups.Add(strRefPatterns[i].Replace("Group:", ""));
        //                                    continue;
        //                                }
        //                            }

        //                            if (strRefPatterns[i].ToLower().StartsWith("[pattern end]") == true)
        //                            {
        //                                bPatternStart = false;

        //                                // Build the search Pattern by Replacing the JournalInfo

        //                                for(nIndex = 0; nIndex < strJournalsColl.Count; nIndex++)
        //                                {
        //                                    string strTmp; //= strJournalsColl[nIndex].Replace("(", @"\(").Replace(")", @"\)").Replace(".", @"\.");

        //                                    if (strReferenceText.Contains(strJournalsColl[nIndex]))
        //                                    {

        //                                        strTmp = strJournalsColl[nIndex].Replace("(", @"\(").Replace(")", @"\)").Replace(".", @"\.");
        //                                        strRefSearchPattern.Add(SearchPattern.Replace("(JournalInfo)", "(" + strTmp + ")"));
        //                                        break;
        //                                    }
        //                                }

        //                                if(strRefSearchPattern.Count > 0)
        //                                {
        //                                    // Search operation is ready

        //                                    if(ReplaceGrpCount > 0)
        //                                    {
        //                                        if (strRefGroups.Count != ReplaceGrpCount)
        //                                        {
        //                                            strRefGroups.Clear();
        //                                            goto NextRefSearchPattern;
        //                                        }

        //                                        for (nIndex = 0; nIndex < strRefSearchPattern.Count; nIndex++)
        //                                        {
        //                                            MatchCollection matches = Regex.Matches(strReferenceText, strRefSearchPattern[nIndex]);

        //                                            if (matches.Count == 1)
        //                                            {
        //                                                if (strReferenceText.Contains("et al") && strRefSearchPattern[nIndex].Contains("et al") == false)
        //                                                {
        //                                                    goto NextRefPat;
        //                                                }

        //                                                //sw.WriteLine("Pattern Index: " + nPatternIndex);
        //                                                //sw.WriteLine(strReferenceText);
        //                                                //sw.WriteLine(strRefSearchPattern[nIndex]);
        //                                                //sw.WriteLine("");

        //                                                foreach (Match match in matches)
        //                                                {
        //                                                    if ((match.Groups.Count-1) != ReplaceGrpCount)
        //                                                        break;

        //                                                    // Extract group info 
        //                                                    int GrpNo = 0;
        //                                                    PubMedPattern = GlobalMethods.ReplaceWholeWord(PubMedPattern, "space", " ");
        //                                                    for (nGrpCounter = 0; nGrpCounter < strRefGroups.Count; nGrpCounter++)
        //                                                    {
        //                                                        string tmpstr = null;
        //                                                        tmpstr = strRefGroups[nGrpCounter];
        //                                                        GrpNo = 0;
        //                                                        GrpNo = nGrpCounter + 1;

        //                                                        if(nGrpCounter == 0)
        //                                                        {
        //                                                            Run newruna = P.AppendChild(new Run());
        //                                                            // Add Text to the Run element.
        //                                                            newruna.AppendChild(new Text("<jrn>"));

        //                                                            // Insert Reference Number //
        //                                                            Run run = new Run(new RunProperties(new RunStyle() { Val = "bibnumber" }));
        //                                                            P.AppendChild(run);
        //                                                            // Add Text to the Run element.
        //                                                            run.AppendChild(new Text(nRefNumberCounter.ToString()));

        //                                                            Run newrun2 = P.AppendChild(new Run());
        //                                                            // Add Text to the Run element.
        //                                                            newrun2.AppendChild(new Text(". ") { Space = SpaceProcessingModeValues.Preserve });
        //                                                        }

        //                                                        if (tmpstr.Contains(":"))
        //                                                        {
        //                                                            // Split the string
        //                                                            string[] separators = { ":" };
        //                                                            string[] strValues = tmpstr.Split(separators, StringSplitOptions.RemoveEmptyEntries);

        //                                                            if(strValues.Length > 0)
        //                                                            {
        //                                                                if(strValues[0] == "space")
        //                                                                {
        //                                                                    Run run = P.AppendChild(new Run());
        //                                                                    //OpenXmlAttribute openXmlAttribute = new OpenXmlAttribute("space", "xml", "preserve");
        //                                                                    // Add Text to the Run element.
        //                                                                    Text T = new Text(" ") { Space = SpaceProcessingModeValues.Preserve };
        //                                                                    //T.SetAttribute(openXmlAttribute);
        //                                                                    run.AppendChild(T);
        //                                                                }
        //                                                                else if (strValues[0] == "blank")
        //                                                                {
        //                                                                    // No action required
        //                                                                }
        //                                                                else if (strValues[0] == "value")
        //                                                                {
        //                                                                    Run run = P.AppendChild(new Run());
        //                                                                    // Add Text to the Run element.
        //                                                                    run.AppendChild(new Text(match.Groups[nGrpCounter+1].Value));

        //                                                                    PubMedPattern = GlobalMethods.ReplaceWholeWord(PubMedPattern, "Group" + GrpNo, match.Groups[nGrpCounter + 1].Value);
        //                                                                }

        //                                                                if (strValues[1] != "") // Style
        //                                                                {
        //                                                                    Run run = new Run(new RunProperties(new RunStyle() { Val = strValues[1] }));
        //                                                                    P.AppendChild(run);
        //                                                                    // Add Text to the Run element.
        //                                                                    run.AppendChild(new Text(match.Groups[nGrpCounter+1].Value));

        //                                                                    PubMedPattern = GlobalMethods.ReplaceWholeWord(PubMedPattern, "Group" + GrpNo, match.Groups[nGrpCounter + 1].Value);
        //                                                                }
        //                                                            }
        //                                                        }
        //                                                        else if (tmpstr.Contains("space"))
        //                                                        {
        //                                                            Run run = P.AppendChild(new Run());
        //                                                            //OpenXmlAttribute openXmlAttribute = new OpenXmlAttribute("space", "xml", "preserve");
        //                                                            // Add Text to the Run element.
        //                                                            Text T = new Text(" "){ Space = SpaceProcessingModeValues.Preserve };
        //                                                            //T.SetAttribute(openXmlAttribute);
        //                                                            run.AppendChild(T);
        //                                                        }
        //                                                        else if (tmpstr.Contains("blank"))
        //                                                        {
        //                                                        }
        //                                                        else if (tmpstr.Contains("value"))
        //                                                        {
        //                                                            Run run = P.AppendChild(new Run());
        //                                                            // Add Text to the Run element.
        //                                                            run.AppendChild(new Text(match.Groups[nGrpCounter+1].Value));
        //                                                            PubMedPattern = GlobalMethods.ReplaceWholeWord(PubMedPattern, "Group" + GrpNo, match.Groups[nGrpCounter + 1].Value);
        //                                                        }
        //                                                        else
        //                                                        {
        //                                                            Run run = new Run(new RunProperties(new RunStyle() { Val = tmpstr }));
        //                                                            P.AppendChild(run);
        //                                                            // Add Text to the Run element.
        //                                                            run.AppendChild(new Text(match.Groups[nGrpCounter+1].Value));

        //                                                            PubMedPattern = GlobalMethods.ReplaceWholeWord(PubMedPattern, "Group" + GrpNo, match.Groups[nGrpCounter + 1].Value);
        //                                                        }
        //                                                    }
        //                                                }

        //                                                if(PubMedPattern.Contains("Group") == false)
        //                                                {
        //                                                    // Extract PmID from PubMed //
        //                                                    string retPMIDVal = null;

        //                                                    retPMIDVal = PubMed.ExtractPMID("http://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=pubmed&retmode=XML&retmax=1000&term=" + PubMedPattern);

        //                                                    if (retPMIDVal != null && retPMIDVal != "")
        //                                                    {
        //                                                        // Build the new Hyperlink with the PMID to be inserted as Hyperlink //

        //                                                        //add the url
        //                                                        string urlLabel = "PubMed";
        //                                                        System.Uri uri = new Uri("http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&list_uids=" + retPMIDVal + "&dopt=Abstract");

        //                                                        bool bExtRefFound = false;
        //                                                        foreach (HyperlinkRelationship hRel in WPD.MainDocumentPart.HyperlinkRelationships)
        //                                                        {
        //                                                            if (hRel.Uri == uri)
        //                                                            {
        //                                                                bExtRefFound = true;
        //                                                            }
        //                                                        }

        //                                                        if (!bExtRefFound)
        //                                                        {
        //                                                            // Add the new URL to document Relations
        //                                                            HyperlinkRelationship rel = MDP.AddHyperlinkRelationship(uri, true);
        //                                                            string relationshipId = rel.Id;

        //                                                            Hyperlink hlink = new Hyperlink(new Run(new RunProperties(new RunStyle() { Val = "bibmedline" }), new Text("PubMed"))){ History = OnOffValue.FromBoolean(true), Id = relationshipId };

        //                                                            // Insert PubMed ID at the end of the newly marked Reference //

        //                                                            P.AppendChild(hlink);                                                                    
        //                                                        }
        //                                                    }
        //                                                }

        //                                                // Insert Journal closing tag here //
        //                                                Run newrunb = P.AppendChild(new Run());
        //                                                // Add Text to the Run element.
        //                                                newrunb.AppendChild(new Text("</jrn>"));

        //                                                goto NextRef;
        //                                            }

        //                                            NextRefPat:
        //                                            {
        //                                            }
        //                                        }
        //                                    }
        //                                }
        //                            }

        //                            //strRefGroups.Clear();

        //                            NextRefSearchPattern:
        //                            {
        //                                continue;
        //                            }
        //                        }

        //                        Run newrunc = P.AppendChild(new Run());
        //                        // Add Text to the Run element.
        //                        newrunc.AppendChild(new Text("<jrn>"));

        //                        // Insert Reference Number //
        //                        Run run1 = new Run(new RunProperties(new RunStyle() { Val = "bibnumber" }));
        //                        P.AppendChild(run1);
        //                        // Add Text to the Run element.
        //                        run1.AppendChild(new Text(nRefNumberCounter.ToString()));

        //                        Run newrun1 = P.AppendChild(new Run());
        //                        // Add Text to the Run element.
        //                        newrun1.AppendChild(new Text(". "){ Space = SpaceProcessingModeValues.Preserve });

        //                        Run newrun = P.AppendChild(new Run());
        //                        // Add Text to the Run element.
        //                        newrun.AppendChild(new Text(Regex.Replace( strReferenceText.Trim(), "(^[0-9]+)(. )", "")));

        //                        Run newruny = P.AppendChild(new Run());
        //                        // Add Text to the Run element.
        //                        newruny.AppendChild(new Text("</jrn>"));

        //                        strRefGroups.Clear();

        //                        //sw1.WriteLine(strReferenceText);
        //                        //sw1.WriteLine("");

        //                        NextRef:
        //                        {
        //                            continue;
        //                        }
        //                    }
        //                }
        //            }
        //        }
        //        //sw.Close();
        //        //sw1.Close();
        //        D.Save();
        //    }
        //}        


        private static void AddNewJournalTitle(string strWordDoc, string JournalDB)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                   .Open(strWordDoc, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    RemoveComments = false,
                    RemoveContentControls = true,
                    RemoveEndAndFootNotes = false,
                    //RemoveFieldCodes = false,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = false,//Developer name :Priyanka Vishwakarma. Date:29_5_2019, Requirement:it removes the indentation from the nested list  ,Integrated By:Vikas sir. 
                };

                MarkupSimplifier.SimplifyMarkup(WPD, settings);

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;


                List<string> strJournalsColl = new List<string>();
                strJournalsColl = GlobalMethods.ReadAndStoreFileValuesInArray(JournalDB);

                // Sort the Journals array on length //
                strJournalsColl = GlobalMethods.SortStringListOnLength(strJournalsColl);

                List<string> newjournaltitle = new List<string>();
                List<string> list = new List<string>();
                bool newJournalNameFound = false;
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().
                       Where(e => e.ParagraphProperties != null
                           && e.ParagraphProperties.ParagraphStyleId != null
                           && e.ParagraphProperties.ParagraphStyleId.Val == "REF1"))
                {
                    string journalname = null;

                    if (P.HasChildren)
                    {
                        if (P.Descendants<Run>().Count() > 0)
                        {
                            foreach (Run R in P.Descendants<Run>().ToList())
                            {
                                if (R.RunProperties != null)
                                {
                                    if (R.RunProperties.RunStyle != null)
                                    {
                                        if (R.RunProperties.RunStyle.Val == "bibjournal")
                                        {
                                            if (R.InnerText.Trim() != "" && R.InnerText != null)
                                            {
                                                journalname = R.InnerText.Trim();
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }



                    //Check if JournalList contains Journalname in text file.
                    if (!string.IsNullOrEmpty(journalname) && journalname.Trim() != "")
                    {
                        if (strJournalsColl.ToList().Contains(journalname))
                        {
                            newJournalNameFound = false;
                        }
                        else
                        {
                            newJournalNameFound = true;
                        }
                    }



                    if (newJournalNameFound)
                    {
                        if (!string.IsNullOrEmpty(journalname) && journalname.Trim() != "")
                        {
                            newjournaltitle.Add(journalname.Trim());
                        }
                    }


                }


                //Write new journal name in Journallist text file.
                if (newjournaltitle.Count > 0)
                {
                    list = newjournaltitle.Distinct().ToList();
                    StringBuilder sb = new StringBuilder();
                    int count = 1;
                    foreach (string line in list)
                    {
                        if (count != list.Count())
                        {
                            count++;
                            sb.AppendLine(line.Trim());
                        }
                        else
                        {
                            sb.Append(line.Trim());
                        }

                    }
                    using (System.IO.StreamWriter file = new System.IO.StreamWriter(JournalDB, true))
                    {

                        file.WriteLine("\n");
                        file.Write(sb.ToString());
                        file.Close();
                    }

                }

                D.Save();
            }
        }

        private static void AddNewPublisher(string strWordDoc, string PublisherDB)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                   .Open(strWordDoc, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    RemoveComments = false,
                    RemoveContentControls = true,
                    RemoveEndAndFootNotes = false,
                    //RemoveFieldCodes = false,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = false,//Developer name :Priyanka Vishwakarma. Date:29_5_2019, Requirement:it removes the indentation from the nested list  ,Integrated By:Vikas sir. 
                };

                MarkupSimplifier.SimplifyMarkup(WPD, settings);

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;


                List<string> strPublisherColl = new List<string>();
                strPublisherColl = GlobalMethods.ReadAndStoreFileValuesInArray(PublisherDB);

                // Sort the Publisher array on length //
                strPublisherColl = GlobalMethods.SortStringListOnLength(strPublisherColl);

                List<string> newpublishertitle = new List<string>();
                List<string> list = new List<string>();
                bool newPublisherNameFound = false;
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().
                       Where(e => e.ParagraphProperties != null
                           && e.ParagraphProperties.ParagraphStyleId != null
                           && e.ParagraphProperties.ParagraphStyleId.Val == "REF1"))
                {
                    string publishername = null;

                    if (P.HasChildren)
                    {
                        if (P.Descendants<Run>().Count() > 0)
                        {
                            foreach (Run R in P.Descendants<Run>().ToList())
                            {
                                if (R.RunProperties != null)
                                {
                                    if (R.RunProperties.RunStyle != null)
                                    {
                                        if (R.RunProperties.RunStyle.Val == "bibpubname")
                                        {
                                            if (R.InnerText.Trim() != "" && R.InnerText != null)
                                            {
                                                publishername = R.InnerText.Trim();
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }



                    //Check if JournalList contains Journalname in text file.
                    if (!string.IsNullOrEmpty(publishername) && publishername.Trim() != "")
                    {
                        if (strPublisherColl.ToList().Contains(publishername))
                        {
                            newPublisherNameFound = false;
                        }
                        else
                        {
                            newPublisherNameFound = true;
                        }
                    }



                    if (newPublisherNameFound)
                    {
                        if (!string.IsNullOrEmpty(publishername) && publishername.Trim() != "")
                        {
                            newpublishertitle.Add(publishername.Trim());
                        }
                    }


                }


                //Write new journal name in Journallist text file.
                if (newpublishertitle.Count > 0)
                {
                    list = newpublishertitle.Distinct().ToList();
                    StringBuilder sb = new StringBuilder();
                    int count = 1;
                    foreach (string line in list)
                    {
                        if (count != list.Count())
                        {
                            count++;
                            sb.AppendLine(line.Trim());
                        }
                        else
                        {
                            sb.Append(line.Trim());
                        }

                    }
                    using (System.IO.StreamWriter file = new System.IO.StreamWriter(PublisherDB, true))
                    {

                        file.WriteLine("\n");
                        file.Write(sb.ToString());
                        file.Close();
                    }

                }

                D.Save();
            }
        }

        public static void MarkReferenceCitations(string strWordDoc)
        {
            try
            {
                // Reference citation citebib style apply for brazil project added by vikas on 19-05-2020 tis will run for inly xmloutput required by client //

       
                using (WordprocessingDocument WPD = WordprocessingDocument
                    .Open(strWordDoc, true))
                {

                    MainDocumentPart MDP = WPD.MainDocumentPart;

                    Document D = MDP.Document;

                    foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                    {                                             
                        if (P.HasChildren)
                        {
                            if (P.Descendants<Run>().Count() > 0)
                            {
                                foreach (Run R in P.Descendants<Run>().ToList())
                                {
                                    if (R.RunProperties != null && R.PreviousSibling()!=null && R.PreviousSibling<Run>()!=null &&(R.PreviousSibling<Run>().InnerText.EndsWith(".") || R.PreviousSibling<Run>().InnerText.EndsWith(",")|| R.PreviousSibling<Run>().InnerText.EndsWith(":")))
                                    {
                                        if (R.RunProperties.VerticalTextAlignment != null)
                                        {
                                            if (R.RunProperties.VerticalTextAlignment.Val == "superscript")
                                            {
                                                R.RunProperties.Append(new RunStyle() { Val = "citebib" });
                                            }

                                        }
                                        if (R.RunProperties.Position != null)
                                        {
                                            if (Convert.ToInt32(R.RunProperties.Position.Val.Value)>0)
                                            {
                                                R.RunProperties.Append(new RunStyle() { Val = "citebib" });
                                            }

                                        }
                                    }
                                    else if(R.InnerText=="-"|| R.InnerText == "–"|| Regex.Match(R.InnerText,"[0-9]+").Success)
                                    {
                                        if(R.RunProperties != null && R.RunProperties.VerticalTextAlignment != null)
                                        {
                                            if (R.RunProperties.VerticalTextAlignment.Val == "superscript")
                                            {
                                                R.RunProperties.Append(new RunStyle() { Val = "citebib" });
                                            }

                                        }
                                        if (R.RunProperties != null && R.RunProperties.Position != null)
                                        {
                                            if (Convert.ToInt32(R.RunProperties.Position.Val.Value) > 0)
                                            {
                                                R.RunProperties.Append(new RunStyle() { Val = "citebib" });
                                            }

                                        }
                                    }
                                }
                            }
                        }
                    }

                    D.Save();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public static void applyFpageandLpage(string newDoc)
        {
            bool bParaHasStructuredRef = false;

            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(x => x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val != null && x.ParagraphProperties.ParagraphStyleId.Val.Value == "REF1").ToList())
                {
                    if (Regex.Match(P.InnerText, @"([0-9]+\s{0,}\([0-9]\)\:\s{0,}[0-9]+[\-\–\−][0-9]+\.)").Success)
                    {
                        if (P.Descendants<Run>().Count() > 0)
                        {
                            if (P.Descendants<Run>().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList().Count() > 0)
                            {
                                var runlist = P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList();
                                if (runlist.Count > 0)
                                {
                                    int count = runlist.Count();
                                    Run lastrun = P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList().LastOrDefault();
                                    string volumeText = "";
                                    foreach (var text in runlist.ToList())
                                    {
                                        volumeText += text.InnerText;
                                    }
                                    if (!string.IsNullOrEmpty(volumeText))
                                    {
                                        string[] separators = { "(", ")", ",", "-", "–", " ", "−", " ",":" };
                                        var values = volumeText.Trim().TrimEnd('.').Split(separators, StringSplitOptions.RemoveEmptyEntries).ToList();
                                        if (values.Count() == 4)
                                        {
                                            Run newRVolume = new Run();
                                            newRVolume.RunProperties = new RunProperties(new RunStyle { Val = "bibvolume" });
                                            Italic italic = new Italic();
                                            newRVolume.RunProperties.AppendChild(italic);
                                            Text newTVolume = new Text() { Text = values[0] };
                                            newRVolume.AppendChild(newTVolume);
                                            lastrun.InsertBeforeSelf(newRVolume);

                                            Run runtxt1 = new Run((new Text { Text = "(", Space = SpaceProcessingModeValues.Preserve }));
                                            lastrun.InsertBeforeSelf(runtxt1);
                                            Run newRIssue = new Run();
                                            newRIssue.RunProperties = new RunProperties(new RunStyle { Val = "bibissue" });
                                            Text newTIssue = new Text() { Text = values[1] };
                                            newRIssue.AppendChild(newTIssue);
                                            lastrun.InsertBeforeSelf(newRIssue);
                                            Run runtxt2 = new Run((new Text { Text = "), ", Space = SpaceProcessingModeValues.Preserve }));
                                            lastrun.InsertBeforeSelf(runtxt2);
                                            Run newRfpage = new Run();
                                            newRfpage.RunProperties = new RunProperties(new RunStyle { Val = "bibfpage" });
                                            Text newTfpage = new Text() { Text = values[2] };
                                            newRfpage.AppendChild(newTfpage);
                                            lastrun.InsertBeforeSelf(newRfpage);
                                            Run runtxt3 = new Run((new Text { Text = "–", Space = SpaceProcessingModeValues.Preserve }));
                                            lastrun.InsertBeforeSelf(runtxt3);

                                            Run newRlpage = new Run();
                                            newRlpage.RunProperties = new RunProperties(new RunStyle { Val = "biblpage" });
                                            Text newTlpage = new Text() { Text = values[3] };
                                            newRlpage.AppendChild(newTlpage);

                                            lastrun.InsertBeforeSelf(newRlpage);
                                            Run runtxt4 = new Run((new Text { Text = ".", Space = SpaceProcessingModeValues.Preserve }));
                                            lastrun.InsertBeforeSelf(runtxt4);

                                            ///lastrun.Remove();
                                            int n = 0;
                                            foreach (var r in runlist.ToList())
                                            {
                                                n++;
                                                if (n <= count)
                                                {
                                                    r.Remove();
                                                }
                                            }

                                        }
                                        else if (P.Descendants<Run>().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList().Count() > 0)
                                        {
                                            foreach (Run run in P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList())
                                            {
                                                run.RunProperties = null;

                                            }


                                        }
                                    }

                                }

                            }

                        }
                        else if (P.Descendants<Run>().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList().Count() > 0)
                        {
                            foreach (Run run in P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList())
                            {
                                run.RunProperties = null;

                            }


                        }


                    }
                    else if (Regex.Match(P.InnerText, @"([0-9]+\([0-9]+\)\,\s{1,}[0-9]+\s{1,}[\-\–\−]\s{1,}[0-9]+\.)|([0-9]+\([0-9A-Za-z\.]+\)\,\s{1,}[0-9]+[\-\–\−][0-9]+\.)|([0-9]+\([0-9A-Za-z\.]+\)\,\s{1,}[0-9]+[\-\–\−][0-9]+[\.|\,])|([0-9]+\([0-9]+\)\,\s{1,}[0-9]+\s{0,1}[\-\–\−]\s{0,1}[0-9]+\.)").Success)
                    {
                        if (P.Descendants<Run>().Count() > 0)
                        {
                            if (P.Descendants<Run>().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList().Count() > 0)
                            {
                                var runlist = P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList();
                                if (runlist.Count > 0)
                                {
                                    int count = runlist.Count();
                                    Run lastrun = P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList().LastOrDefault();
                                    string volumeText = "";
                                    foreach (var text in runlist.ToList())
                                    {
                                        volumeText += text.InnerText;
                                    }
                                    if (!string.IsNullOrEmpty(volumeText))
                                    {
                                        string[] separators = { "(", ")", ",", "-", "–", " ", "−", " " };
                                        var values = volumeText.Trim().TrimEnd('.').Split(separators, StringSplitOptions.RemoveEmptyEntries).ToList();
                                        if (values.Count() == 4)
                                        {
                                            Run newRVolume = new Run();
                                            newRVolume.RunProperties = new RunProperties(new RunStyle { Val = "bibvolume" });
                                            Italic italic = new Italic();
                                            newRVolume.RunProperties.AppendChild(italic);
                                            Text newTVolume = new Text() { Text = values[0] };
                                            newRVolume.AppendChild(newTVolume);
                                            lastrun.InsertBeforeSelf(newRVolume);

                                            Run runtxt1 = new Run((new Text { Text = "(", Space = SpaceProcessingModeValues.Preserve }));
                                            lastrun.InsertBeforeSelf(runtxt1);
                                            Run newRIssue = new Run();
                                            newRIssue.RunProperties = new RunProperties(new RunStyle { Val = "bibissue" });
                                            Text newTIssue = new Text() { Text = values[1] };
                                            newRIssue.AppendChild(newTIssue);
                                            lastrun.InsertBeforeSelf(newRIssue);
                                            Run runtxt2 = new Run((new Text { Text = "), ", Space = SpaceProcessingModeValues.Preserve }));
                                            lastrun.InsertBeforeSelf(runtxt2);
                                            Run newRfpage = new Run();
                                            newRfpage.RunProperties = new RunProperties(new RunStyle { Val = "bibfpage" });
                                            Text newTfpage = new Text() { Text = values[2] };
                                            newRfpage.AppendChild(newTfpage);
                                            lastrun.InsertBeforeSelf(newRfpage);
                                            Run runtxt3 = new Run((new Text { Text = "–", Space = SpaceProcessingModeValues.Preserve }));
                                            lastrun.InsertBeforeSelf(runtxt3);

                                            Run newRlpage = new Run();
                                            newRlpage.RunProperties = new RunProperties(new RunStyle { Val = "biblpage" });
                                            Text newTlpage = new Text() { Text = values[3] };
                                            newRlpage.AppendChild(newTlpage);

                                            lastrun.InsertBeforeSelf(newRlpage);
                                            Run runtxt4 = new Run((new Text { Text = ".", Space = SpaceProcessingModeValues.Preserve }));
                                            lastrun.InsertBeforeSelf(runtxt4);

                                            ///lastrun.Remove();
                                            int n = 0;
                                            foreach (var r in runlist.ToList())
                                            {
                                                n++;
                                                if (n <= count)
                                                {
                                                    r.Remove();
                                                }
                                            }

                                        }
                                        else if (P.Descendants<Run>().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList().Count() > 0)
                                        {
                                            foreach (Run run in P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList())
                                            {
                                                run.RunProperties = null;

                                            }


                                        }
                                    }

                                }

                            }

                        }
                        else if (P.Descendants<Run>().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList().Count() > 0)
                        {
                            foreach (Run run in P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList())
                            {
                                run.RunProperties = null;

                            }


                        }


                    }
                    else if (Regex.Match(P.InnerText, @"([0-9]+\([A-Za-z]+\s[A-Za-z]+\)\,\s{1,}[0-9]+\s{0,1}[\-\–\−]\s{0,1}[0-9]+\.)|([0-9]+\([A-Za-z]+\)\,\s{1,}[0-9]+\s{0,1}[\-\–\−]\s{0,1}[0-9]+\.)").Success)
                    {
                        if (P.Descendants<Run>().Count() > 0)
                        {
                            if (P.Descendants<Run>().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList().Count() > 0)
                            {
                                var runlist = P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList();
                                if (runlist.Count > 0)
                                {
                                    int count = runlist.Count();
                                    Run lastrun = P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList().LastOrDefault();
                                    string volumeText = "";
                                    foreach (var text in runlist.ToList())
                                    {
                                        volumeText += text.InnerText;
                                    }
                                    if (!string.IsNullOrEmpty(volumeText))
                                    {
                                        string[] separators = { "(", ")", ",", "-", "–", " ", "−", " " };
                                        var values = volumeText.Trim().TrimEnd('.').Split(separators, StringSplitOptions.RemoveEmptyEntries).ToList();

                                        if (values.Count == 4)
                                        {
                                            Run newRVolume = new Run();
                                            newRVolume.RunProperties = new RunProperties(new RunStyle { Val = "bibvolume" });
                                            Italic italic = new Italic();
                                            newRVolume.RunProperties.AppendChild(italic);
                                            Text newTVolume = new Text() { Text = values[0] };
                                            newRVolume.AppendChild(newTVolume);
                                            lastrun.InsertBeforeSelf(newRVolume);

                                            Run runtxt1 = new Run((new Text { Text = "(", Space = SpaceProcessingModeValues.Preserve }));
                                            lastrun.InsertBeforeSelf(runtxt1);

                                            Run newRIssue = new Run();
                                            newRIssue.RunProperties = new RunProperties(new RunStyle { Val = "bibissue" });
                                            Text newTIssue = new Text() { Text = values[1] };
                                            newRIssue.AppendChild(newTIssue);
                                            lastrun.InsertBeforeSelf(newRIssue);
                                            Run runtxt2 = new Run((new Text { Text = "), ", Space = SpaceProcessingModeValues.Preserve }));
                                            lastrun.InsertBeforeSelf(runtxt2);
                                            Run newRfpage = new Run();
                                            newRfpage.RunProperties = new RunProperties(new RunStyle { Val = "bibfpage" });
                                            Text newTfpage = new Text() { Text = values[2] };
                                            newRfpage.AppendChild(newTfpage);
                                            lastrun.InsertBeforeSelf(newRfpage);
                                            Run runtxt3 = new Run((new Text { Text = "–", Space = SpaceProcessingModeValues.Preserve }));
                                            lastrun.InsertBeforeSelf(runtxt3);

                                            Run newRlpage = new Run();
                                            newRlpage.RunProperties = new RunProperties(new RunStyle { Val = "biblpage" });
                                            Text newTlpage = new Text() { Text = values[3] };
                                            newRlpage.AppendChild(newTlpage);

                                            lastrun.InsertBeforeSelf(newRlpage);
                                            Run runtxt4 = new Run((new Text { Text = ".", Space = SpaceProcessingModeValues.Preserve }));
                                            lastrun.InsertBeforeSelf(runtxt4);

                                            ///lastrun.Remove();
                                            int n = 0;
                                            foreach (var r in runlist.ToList())
                                            {
                                                n++;
                                                if (n <= count)
                                                {
                                                    r.Remove();
                                                }
                                            }

                                        }
                                        else if (values.Count() == 5)
                                        {
                                            Run newRVolume = new Run();
                                            newRVolume.RunProperties = new RunProperties(new RunStyle { Val = "bibvolume" });
                                            Italic italic = new Italic();
                                            newRVolume.RunProperties.AppendChild(italic);
                                            Text newTVolume = new Text() { Text = values[0] };
                                            newRVolume.AppendChild(newTVolume);
                                            lastrun.InsertBeforeSelf(newRVolume);

                                            Run runtxt1 = new Run((new Text { Text = "(", Space = SpaceProcessingModeValues.Preserve }));
                                            lastrun.InsertBeforeSelf(runtxt1);

                                            Run newRIssue = new Run();
                                            newRIssue.RunProperties = new RunProperties(new RunStyle { Val = "bibissue" });
                                            Text newTIssue = new Text() { Text = values[1] + " " + values[2] };
                                            newRIssue.AppendChild(newTIssue);
                                            lastrun.InsertBeforeSelf(newRIssue);
                                            Run runtxt2 = new Run((new Text { Text = "), ", Space = SpaceProcessingModeValues.Preserve }));
                                            lastrun.InsertBeforeSelf(runtxt2);
                                            Run newRfpage = new Run();
                                            newRfpage.RunProperties = new RunProperties(new RunStyle { Val = "bibfpage" });
                                            Text newTfpage = new Text() { Text = values[3] };
                                            newRfpage.AppendChild(newTfpage);
                                            lastrun.InsertBeforeSelf(newRfpage);
                                            Run runtxt3 = new Run((new Text { Text = "–", Space = SpaceProcessingModeValues.Preserve }));
                                            lastrun.InsertBeforeSelf(runtxt3);

                                            Run newRlpage = new Run();
                                            newRlpage.RunProperties = new RunProperties(new RunStyle { Val = "biblpage" });
                                            Text newTlpage = new Text() { Text = values[4] };
                                            newRlpage.AppendChild(newTlpage);

                                            lastrun.InsertBeforeSelf(newRlpage);
                                            Run runtxt4 = new Run((new Text { Text = ".", Space = SpaceProcessingModeValues.Preserve }));
                                            lastrun.InsertBeforeSelf(runtxt4);

                                            ///lastrun.Remove();
                                            int n = 0;
                                            foreach (var r in runlist.ToList())
                                            {
                                                n++;
                                                if (n <= count)
                                                {
                                                    r.Remove();
                                                }
                                            }

                                        }
                                        else if (P.Descendants<Run>().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList().Count() > 0)
                                        {
                                            foreach (Run run in P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList())
                                            {
                                                run.RunProperties = null;

                                            }


                                        }
                                    }

                                }

                            }

                        }
                        else if (P.Descendants<Run>().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList().Count() > 0)
                        {
                            foreach (Run run in P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList())
                            {
                                run.RunProperties = null;

                            }


                        }


                    }
                    else if (Regex.Match(P.InnerText, @"([0-9]+\([0-9]+\)\,\spp\.\s{0,1}[0-9]+\s{0,1}[\-\–\−]\s{0,1}[0-9]+\.)").Success)
                    {
                        if (P.Descendants<Run>().Count() > 0)
                        {
                            if (P.Descendants<Run>().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList().Count() > 0)
                            {
                                var runlist = P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList();
                                if (runlist.Count > 0)
                                {
                                    int count = runlist.Count();
                                    Run lastrun = P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList().LastOrDefault();
                                    string volumeText = "";
                                    foreach (var text in runlist.ToList())
                                    {
                                        volumeText += text.InnerText;
                                    }
                                    if (!string.IsNullOrEmpty(volumeText))
                                    {
                                        string[] separators = { "(", ")", ",", "-", "–", " ", "−", " " }; //02-04-2021

                                        var values = volumeText.Trim().TrimEnd('.').Split(separators, StringSplitOptions.RemoveEmptyEntries).ToList();
                                        if (values.Count() == 5)
                                        {
                                            Run newRVolume = new Run();
                                            newRVolume.RunProperties = new RunProperties(new RunStyle { Val = "bibvolume" });
                                            Italic italic = new Italic();
                                            newRVolume.RunProperties.AppendChild(italic);
                                            Text newTVolume = new Text() { Text = values[0] };
                                            newRVolume.AppendChild(newTVolume);
                                            lastrun.InsertBeforeSelf(newRVolume);

                                            Run runtxt1 = new Run((new Text { Text = "(", Space = SpaceProcessingModeValues.Preserve }));
                                            lastrun.InsertBeforeSelf(runtxt1);
                                            Run newRIssue = new Run();
                                            newRIssue.RunProperties = new RunProperties(new RunStyle { Val = "bibissue" });
                                            Text newTIssue = new Text() { Text = values[1] };
                                            newRIssue.AppendChild(newTIssue);
                                            lastrun.InsertBeforeSelf(newRIssue);
                                            Run runtxt2 = new Run((new Text { Text = "), ", Space = SpaceProcessingModeValues.Preserve }));
                                            lastrun.InsertBeforeSelf(runtxt2);

                                            Run newPPtxt = new Run();
                                            newPPtxt.RunProperties = new RunProperties(new RunStyle { Val = "bibtxt" });
                                            Text newTpp = new Text() { Text = values[2].Trim().TrimEnd('.') };
                                            newPPtxt.AppendChild(newTpp);
                                            lastrun.InsertBeforeSelf(newPPtxt);
                                            Run runpptxt = new Run((new Text { Text = ". ", Space = SpaceProcessingModeValues.Preserve }));
                                            lastrun.InsertBeforeSelf(runpptxt);

                                            Run newRfpage = new Run();
                                            newRfpage.RunProperties = new RunProperties(new RunStyle { Val = "bibfpage" });
                                            Text newTfpage = new Text() { Text = values[3] };
                                            newRfpage.AppendChild(newTfpage);
                                            lastrun.InsertBeforeSelf(newRfpage);
                                            Run runtxt3 = new Run((new Text { Text = "–", Space = SpaceProcessingModeValues.Preserve }));
                                            lastrun.InsertBeforeSelf(runtxt3);

                                            Run newRlpage = new Run();
                                            newRlpage.RunProperties = new RunProperties(new RunStyle { Val = "biblpage" });
                                            Text newTlpage = new Text() { Text = values[4] };
                                            newRlpage.AppendChild(newTlpage);

                                            lastrun.InsertBeforeSelf(newRlpage);
                                            Run runtxt4 = new Run((new Text { Text = ".", Space = SpaceProcessingModeValues.Preserve }));
                                            lastrun.InsertBeforeSelf(runtxt4);

                                            ///lastrun.Remove();
                                            int n = 0;
                                            foreach (var r in runlist.ToList())
                                            {
                                                n++;
                                                if (n <= count)
                                                {
                                                    r.Remove();
                                                }
                                            }
                                        }
                                        else if (P.Descendants<Run>().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList().Count() > 0)
                                        {
                                            foreach (Run run in P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList())
                                            {
                                                run.RunProperties = null;

                                            }


                                        }

                                    }

                                }

                            }

                        }
                        else if (P.Descendants<Run>().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList().Count() > 0)
                        {
                            foreach (Run run in P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList())
                            {
                                run.RunProperties = null;

                            }


                        }


                    }
                    else if (Regex.Match(P.InnerText, @"(pp[\.]\s{0,1}[0-9]+\s{0,1}[\-\–\−\–]\s{0,1}[0-9]+)").Success)
                    {
                        if (P.Descendants<Run>().Count() > 0)
                        {
                            if (P.Descendants<Run>().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibfpage").ToList().Count() > 0)
                            {
                                var runlist = P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibfpage").ToList();
                                if (runlist.Count > 0)
                                {
                                    int count = runlist.Count();
                                    Run lastrun = P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibfpage").ToList().LastOrDefault();
                                    string volumeText = "";
                                    foreach (var text in runlist.ToList())
                                    {
                                        volumeText += text.InnerText;
                                    }
                                    if (!string.IsNullOrEmpty(volumeText))
                                    {
                                        string[] separators = { "(", ")", ",", "-", "–", " ", "−", " " };
                                        var values = volumeText.Trim().TrimEnd('.').Split(separators, StringSplitOptions.RemoveEmptyEntries).ToList();
                                        if (values.Count() == 3)
                                        {
                                            Run newPPtxt = new Run();
                                            newPPtxt.RunProperties = new RunProperties(new RunStyle { Val = "bibtxt" });
                                            Text newTpp = new Text() { Text = values[0].Trim().TrimEnd('.') };
                                            newPPtxt.AppendChild(newTpp);
                                            lastrun.InsertBeforeSelf(newPPtxt);
                                            Run runpptxt = new Run((new Text { Text = ". ", Space = SpaceProcessingModeValues.Preserve }));
                                            lastrun.InsertBeforeSelf(runpptxt);

                                            Run newRfpage = new Run();
                                            newRfpage.RunProperties = new RunProperties(new RunStyle { Val = "bibfpage" });
                                            Text newTfpage = new Text() { Text = values[1] };
                                            newRfpage.AppendChild(newTfpage);
                                            lastrun.InsertBeforeSelf(newRfpage);
                                            Run runtxt3 = new Run((new Text { Text = "–", Space = SpaceProcessingModeValues.Preserve }));
                                            lastrun.InsertBeforeSelf(runtxt3);

                                            Run newRlpage = new Run();
                                            newRlpage.RunProperties = new RunProperties(new RunStyle { Val = "biblpage" });
                                            Text newTlpage = new Text() { Text = values[2] };
                                            newRlpage.AppendChild(newTlpage);

                                            lastrun.InsertBeforeSelf(newRlpage);


                                            ///lastrun.Remove();
                                            int n = 0;
                                            foreach (var r in runlist.ToList())
                                            {
                                                n++;
                                                if (n <= count)
                                                {
                                                    r.Remove();
                                                }
                                            }
                                        }
                                        else if (P.Descendants<Run>().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList().Count() > 0)
                                        {
                                            foreach (Run run in P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList())
                                            {
                                                run.RunProperties = null;

                                            }
                                        }
                                    }

                                }

                            }

                        }
                    }
                    else if (Regex.Match(P.InnerText, @"([0-9]+\([0-9]+\)\:\s[0-9]+[\-\–]{1}[0-9]+)").Success)  //Developer Name:Priyanka Vishwakarma,Date:02-04-2021,Requirement:Add condiiton for apply bibvolume, bibissue, fpage, lpage for sage india input.
                    {
                        if (P.Descendants<Run>().Count() > 0)
                        {
                            if (P.Descendants<Run>().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList().Count() > 0)
                            {
                                var runlist = P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList();
                                if (runlist.Count > 0)
                                {
                                    int count = runlist.Count();
                                    Run lastrun = P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList().LastOrDefault();
                                    string volumeText = "";
                                    foreach (var text in runlist.ToList())
                                    {
                                        volumeText += text.InnerText;
                                    }
                                    if (!string.IsNullOrEmpty(volumeText))
                                    {
                                        string[] separators = { "(", ")", ",", "-", "–", " ", "−", " ", ":" };
                                        var values = volumeText.Trim().TrimEnd('.').Split(separators, StringSplitOptions.RemoveEmptyEntries).ToList();
                                        if (values.Count() == 4)
                                        {
                                            Run newRVolume = new Run();
                                            newRVolume.RunProperties = new RunProperties(new RunStyle { Val = "bibvolume" });
                                            Italic italic = new Italic();
                                            newRVolume.RunProperties.AppendChild(italic);
                                            Text newTVolume = new Text() { Text = values[0] };
                                            newRVolume.AppendChild(newTVolume);
                                            lastrun.InsertBeforeSelf(newRVolume);

                                            Run runtxt1 = new Run((new Text { Text = "(", Space = SpaceProcessingModeValues.Preserve }));
                                            lastrun.InsertBeforeSelf(runtxt1);
                                            Run newRIssue = new Run();
                                            newRIssue.RunProperties = new RunProperties(new RunStyle { Val = "bibissue" });
                                            Text newTIssue = new Text() { Text = values[1] };
                                            newRIssue.AppendChild(newTIssue);
                                            lastrun.InsertBeforeSelf(newRIssue);
                                            Run runtxt2 = new Run((new Text { Text = "): ", Space = SpaceProcessingModeValues.Preserve }));
                                            lastrun.InsertBeforeSelf(runtxt2);
                                            Run newRfpage = new Run();
                                            newRfpage.RunProperties = new RunProperties(new RunStyle { Val = "bibfpage" });
                                            Text newTfpage = new Text() { Text = values[2] };
                                            newRfpage.AppendChild(newTfpage);
                                            lastrun.InsertBeforeSelf(newRfpage);
                                            Run runtxt3 = new Run((new Text { Text = "–", Space = SpaceProcessingModeValues.Preserve }));
                                            lastrun.InsertBeforeSelf(runtxt3);

                                            Run newRlpage = new Run();
                                            newRlpage.RunProperties = new RunProperties(new RunStyle { Val = "biblpage" });
                                            Text newTlpage = new Text() { Text = values[3] };
                                            newRlpage.AppendChild(newTlpage);

                                            lastrun.InsertBeforeSelf(newRlpage);


                                            ///lastrun.Remove();
                                            int n = 0;
                                            foreach (var r in runlist.ToList())
                                            {
                                                n++;
                                                if (n <= count)
                                                {
                                                    r.Remove();
                                                }
                                            }
                                        }
                                        else if (P.Descendants<Run>().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList().Count() > 0)
                                        {
                                            foreach (Run run in P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList())
                                            {
                                                run.RunProperties = null;

                                            }
                                        }

                                    }

                                }

                            }

                        }
                        else if (P.Descendants<Run>().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList().Count() > 0)
                        {
                            foreach (Run run in P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList())
                            {
                                run.RunProperties = null;

                            }
                        }
                    }
                    else if (Regex.Match(P.InnerText, @"([0-9]+\s{0,1}\([0-9]+\)\,[\s\ ]{0,1}[0-9]+[\-\–\−][0-9]+)").Success)  //Developer Name:Priyanka Vishwakarma,Date:02-04-2021,Requirement:Add condiiton for apply bibvolume, bibissue, fpage, lpage for sage india input.
                    {
                        if (P.Descendants<Run>().Count() > 0)
                        {
                            if (P.Descendants<Run>().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList().Count() > 0)
                            {
                                var runlist = P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList();
                                if (runlist.Count > 0)
                                {
                                    int count = runlist.Count();
                                    Run lastrun = P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList().LastOrDefault();
                                    string volumeText = "";
                                    foreach (var text in runlist.ToList())
                                    {
                                        volumeText += text.InnerText;
                                    }
                                    if (!string.IsNullOrEmpty(volumeText))
                                    {
                                        string[] separators = { "(", ")", ",", "-", "–", " ", "−", " ", ":" };
                                        var values = volumeText.Trim().TrimEnd('.').Split(separators, StringSplitOptions.RemoveEmptyEntries).ToList();
                                        if (values.Count() == 4)
                                        {
                                            Run newRVolume = new Run();
                                            newRVolume.RunProperties = new RunProperties(new RunStyle { Val = "bibvolume" });
                                            Italic italic = new Italic();
                                            newRVolume.RunProperties.AppendChild(italic);
                                            Text newTVolume = new Text() { Text = values[0] };
                                            newRVolume.AppendChild(newTVolume);
                                            lastrun.InsertBeforeSelf(newRVolume);

                                            Run runtxt1 = new Run((new Text { Text = "(", Space = SpaceProcessingModeValues.Preserve }));
                                            lastrun.InsertBeforeSelf(runtxt1);
                                            Run newRIssue = new Run();
                                            newRIssue.RunProperties = new RunProperties(new RunStyle { Val = "bibissue" });
                                            Text newTIssue = new Text() { Text = values[1] };
                                            newRIssue.AppendChild(newTIssue);
                                            lastrun.InsertBeforeSelf(newRIssue);
                                            Run runtxt2 = new Run((new Text { Text = "), ", Space = SpaceProcessingModeValues.Preserve }));
                                            lastrun.InsertBeforeSelf(runtxt2);
                                            Run newRfpage = new Run();
                                            newRfpage.RunProperties = new RunProperties(new RunStyle { Val = "bibfpage" });
                                            Text newTfpage = new Text() { Text = values[2] };
                                            newRfpage.AppendChild(newTfpage);
                                            lastrun.InsertBeforeSelf(newRfpage);
                                            Run runtxt3 = new Run((new Text { Text = "–", Space = SpaceProcessingModeValues.Preserve }));
                                            lastrun.InsertBeforeSelf(runtxt3);

                                            Run newRlpage = new Run();
                                            newRlpage.RunProperties = new RunProperties(new RunStyle { Val = "biblpage" });
                                            Text newTlpage = new Text() { Text = values[3] };
                                            newRlpage.AppendChild(newTlpage);

                                            lastrun.InsertBeforeSelf(newRlpage);


                                            ///lastrun.Remove();
                                            int n = 0;
                                            foreach (var r in runlist.ToList())
                                            {
                                                n++;
                                                if (n <= count)
                                                {
                                                    r.Remove();
                                                }
                                            }
                                        }
                                        else if (P.Descendants<Run>().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList().Count() > 0)
                                        {
                                            foreach (Run run in P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList())
                                            {
                                                run.RunProperties = null;

                                            }
                                        }

                                    }

                                }

                            }

                        }
                        else if (P.Descendants<Run>().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList().Count() > 0)
                        {
                            foreach (Run run in P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList())
                            {
                                run.RunProperties = null;

                            }
                        }
                    }
                    else if (Regex.Match(P.InnerText, @"([0-9]+\,\s[0-9]+[\-|\–][0-9]+)").Success)  //Developer Name:Priyanka Vishwakarma,Date:16-09-2021,Requirement:Add condiiton for apply bibvolume, bibissue, fpage, lpage for sage india input.
                    {
                        if (P.Descendants<Run>().Count() > 0)
                        {
                            if (P.Descendants<Run>().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList().Count() > 0)
                            {
                                var runlist = P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList();
                                if (runlist.Count > 0)
                                {
                                    int count = runlist.Count();
                                    Run lastrun = P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList().LastOrDefault();
                                    string volumeText = "";
                                    foreach (var text in runlist.ToList())
                                    {
                                        volumeText += text.InnerText;
                                    }
                                    if (!string.IsNullOrEmpty(volumeText))
                                    {
                                        string[] separators = { "(", ")", ",", "-", "–", " ", "−", " ", ":" };
                                        var values = volumeText.Trim().TrimEnd('.').Split(separators, StringSplitOptions.RemoveEmptyEntries).ToList();
                                        if (values.Count() == 3)
                                        {
                                            Run newRVolume = new Run();
                                            newRVolume.RunProperties = new RunProperties(new RunStyle { Val = "bibvolume" });
                                            Italic italic = new Italic();
                                            newRVolume.RunProperties.AppendChild(italic);
                                            Text newTVolume = new Text() { Text = values[0] };
                                            newRVolume.AppendChild(newTVolume);
                                            lastrun.InsertBeforeSelf(newRVolume);

                                            Run runtxt2 = new Run((new Text { Text = ", ", Space = SpaceProcessingModeValues.Preserve }));
                                            lastrun.InsertBeforeSelf(runtxt2);
                                            Run newRfpage = new Run();
                                            newRfpage.RunProperties = new RunProperties(new RunStyle { Val = "bibfpage" });
                                            Text newTfpage = new Text() { Text = values[1] };
                                            newRfpage.AppendChild(newTfpage);
                                            lastrun.InsertBeforeSelf(newRfpage);
                                            Run runtxt3 = new Run((new Text { Text = "–", Space = SpaceProcessingModeValues.Preserve }));
                                            lastrun.InsertBeforeSelf(runtxt3);

                                            Run newRlpage = new Run();
                                            newRlpage.RunProperties = new RunProperties(new RunStyle { Val = "biblpage" });
                                            Text newTlpage = new Text() { Text = values[2] };
                                            newRlpage.AppendChild(newTlpage);

                                            lastrun.InsertBeforeSelf(newRlpage);


                                            ///lastrun.Remove();
                                            int n = 0;
                                            foreach (var r in runlist.ToList())
                                            {
                                                n++;
                                                if (n <= count)
                                                {
                                                    r.Remove();
                                                }
                                            }
                                        }
                                        else if (P.Descendants<Run>().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList().Count() > 0)
                                        {
                                            foreach (Run run in P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList())
                                            {
                                                run.RunProperties = null;

                                            }
                                        }

                                    }

                                }

                            }

                        }
                        else if (P.Descendants<Run>().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList().Count() > 0)
                        {
                            foreach (Run run in P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList())
                            {
                                run.RunProperties = null;

                            }
                        }
                    }
                    else if (Regex.Match(P.InnerText, @"([0-9]+\([0-9]+[\-\–\–][0-9]+\)\,\s[0-9]+[\-|\–][0-9]+)").Success)  //Developer Name:Priyanka Vishwakarma,Date:16-09-2021,Requirement:Add condiiton for apply bibvolume, bibissue, fpage, lpage for sage india input.
                    {
                        if (P.Descendants<Run>().Count() > 0)
                        {
                            if (P.Descendants<Run>().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList().Count() > 0)
                            {
                                var runlist = P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList();
                                if (runlist.Count > 0)
                                {
                                    int count = runlist.Count();
                                    Run lastrun = P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList().LastOrDefault();
                                    string volumeText = "";
                                    foreach (var text in runlist.ToList())
                                    {
                                        volumeText += text.InnerText;
                                    }
                                    if (!string.IsNullOrEmpty(volumeText))
                                    {
                                        string[] separators = { "(", ")", ",", "-", "–", " ", "−", " ", ":" };
                                        var values = volumeText.Trim().TrimEnd('.').Split(separators, StringSplitOptions.RemoveEmptyEntries).ToList();
                                        if (values.Count() == 5)
                                        {
                                            Run newRVolume = new Run();
                                            newRVolume.RunProperties = new RunProperties(new RunStyle { Val = "bibvolume" });
                                            Italic italic = new Italic();
                                            newRVolume.RunProperties.AppendChild(italic);
                                            Text newTVolume = new Text() { Text = values[0] };
                                            newRVolume.AppendChild(newTVolume);
                                            lastrun.InsertBeforeSelf(newRVolume);

                                            Run runtxt1 = new Run((new Text { Text = "(", Space = SpaceProcessingModeValues.Preserve }));
                                            lastrun.InsertBeforeSelf(runtxt1);
                                            Run newRIssue = new Run();
                                            newRIssue.RunProperties = new RunProperties(new RunStyle { Val = "bibissue" });
                                            Text newTIssue = new Text() { Text = values[1] + "–" + values[2] };
                                            newRIssue.AppendChild(newTIssue);
                                            lastrun.InsertBeforeSelf(newRIssue);
                                            Run runtxt2 = new Run((new Text { Text = "),", Space = SpaceProcessingModeValues.Preserve }));
                                            lastrun.InsertBeforeSelf(runtxt2);

                                            Run newRfpage = new Run();
                                            newRfpage.RunProperties = new RunProperties(new RunStyle { Val = "bibfpage" });
                                            Text newTfpage = new Text() { Text = values[3] };
                                            newRfpage.AppendChild(newTfpage);
                                            lastrun.InsertBeforeSelf(newRfpage);
                                            Run runtxt3 = new Run((new Text { Text = "–", Space = SpaceProcessingModeValues.Preserve }));
                                            lastrun.InsertBeforeSelf(runtxt3);

                                            Run newRlpage = new Run();
                                            newRlpage.RunProperties = new RunProperties(new RunStyle { Val = "biblpage" });
                                            Text newTlpage = new Text() { Text = values[4] };
                                            newRlpage.AppendChild(newTlpage);

                                            lastrun.InsertBeforeSelf(newRlpage);



                                            int n = 0;
                                            foreach (var r in runlist.ToList())
                                            {
                                                n++;
                                                if (n <= count)
                                                {
                                                    r.Remove();
                                                }
                                            }
                                        }
                                        else if (P.Descendants<Run>().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList().Count() > 0)
                                        {
                                            foreach (Run run in P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList())
                                            {
                                                run.RunProperties = null;

                                            }
                                        }
                                    }
                                }
                            }
                        }
                        else if (P.Descendants<Run>().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList().Count() > 0)
                        {
                            foreach (Run run in P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList())
                            {
                                run.RunProperties = null;

                            }
                        }
                    }
                    else if (Regex.Match(P.InnerText, @"([0-9]+\([0-9]+[\/][0-9]+\)\,\s[0-9]+[\-|\–][0-9]+)").Success)  //Developer Name:Priyanka Vishwakarma,Date:16-09-2021,Requirement:Add condiiton for apply bibvolume, bibissue, fpage, lpage for sage india input.
                    {
                        if (P.Descendants<Run>().Count() > 0)
                        {
                            if (P.Descendants<Run>().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList().Count() > 0)
                            {
                                var runlist = P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList();
                                if (runlist.Count > 0)
                                {
                                    int count = runlist.Count();
                                    Run lastrun = P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList().LastOrDefault();
                                    string volumeText = "";
                                    foreach (var text in runlist.ToList())
                                    {
                                        volumeText += text.InnerText;
                                    }
                                    if (!string.IsNullOrEmpty(volumeText))
                                    {
                                        string[] separators = { "(", ")", ",", "-", "–", " ", "−", " ", ":" };
                                        var values = volumeText.Trim().TrimEnd('.').Split(separators, StringSplitOptions.RemoveEmptyEntries).ToList();
                                        if (values.Count() == 4)
                                        {
                                            Run newRVolume = new Run();
                                            newRVolume.RunProperties = new RunProperties(new RunStyle { Val = "bibvolume" });
                                            Italic italic = new Italic();
                                            newRVolume.RunProperties.AppendChild(italic);
                                            Text newTVolume = new Text() { Text = values[0] };
                                            newRVolume.AppendChild(newTVolume);
                                            lastrun.InsertBeforeSelf(newRVolume);

                                            Run runtxt1 = new Run((new Text { Text = "(", Space = SpaceProcessingModeValues.Preserve }));
                                            lastrun.InsertBeforeSelf(runtxt1);
                                            Run newRIssue = new Run();
                                            newRIssue.RunProperties = new RunProperties(new RunStyle { Val = "bibissue" });
                                            Text newTIssue = new Text() { Text = values[1] };
                                            newRIssue.AppendChild(newTIssue);
                                            lastrun.InsertBeforeSelf(newRIssue);
                                            Run runtxt2 = new Run((new Text { Text = "),", Space = SpaceProcessingModeValues.Preserve }));
                                            lastrun.InsertBeforeSelf(runtxt2);

                                            Run newRfpage = new Run();
                                            newRfpage.RunProperties = new RunProperties(new RunStyle { Val = "bibfpage" });
                                            Text newTfpage = new Text() { Text = values[2] };
                                            newRfpage.AppendChild(newTfpage);
                                            lastrun.InsertBeforeSelf(newRfpage);
                                            Run runtxt3 = new Run((new Text { Text = "–", Space = SpaceProcessingModeValues.Preserve }));
                                            lastrun.InsertBeforeSelf(runtxt3);

                                            Run newRlpage = new Run();
                                            newRlpage.RunProperties = new RunProperties(new RunStyle { Val = "biblpage" });
                                            Text newTlpage = new Text() { Text = values[3] };
                                            newRlpage.AppendChild(newTlpage);

                                            lastrun.InsertBeforeSelf(newRlpage);

                                            int n = 0;
                                            foreach (var r in runlist.ToList())
                                            {
                                                n++;
                                                if (n <= count)
                                                {
                                                    r.Remove();
                                                }
                                            }
                                        }
                                        else if (P.Descendants<Run>().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList().Count() > 0)
                                        {
                                            foreach (Run run in P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList())
                                            {
                                                run.RunProperties = null;

                                            }
                                        }
                                    }
                                }
                            }
                        }
                        else if (P.Descendants<Run>().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList().Count() > 0)
                        {
                            foreach (Run run in P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList())
                            {
                                run.RunProperties = null;

                            }
                        }
                    }
                    else if (Regex.Match(P.InnerText, @"([0-9]+\([0-9]+\)\,\s[0-9]+)|([0-9]+\([0-9]+\)\,\s[A-Za-z0-9]+)").Success)  //Developer Name:Priyanka Vishwakarma,Date:16-09-2021,Requirement:Add condiiton for apply bibvolume, bibissue, fpage, lpage for sage india input.
                    {
                        if (P.Descendants<Run>().Count() > 0)
                        {
                            if (P.Descendants<Run>().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList().Count() > 0)
                            {
                                var runlist = P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList();
                                if (runlist.Count > 0)
                                {
                                    int count = runlist.Count();
                                    Run lastrun = P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList().LastOrDefault();
                                    string volumeText = "";
                                    foreach (var text in runlist.ToList())
                                    {
                                        volumeText += text.InnerText;
                                    }
                                    if (!string.IsNullOrEmpty(volumeText))
                                    {
                                        string[] separators = { "(", ")", ",", "-", "–", " ", "−", " ", ":" };
                                        var values = volumeText.Trim().TrimEnd('.').Split(separators, StringSplitOptions.RemoveEmptyEntries).ToList();
                                        if (values.Count() == 3)
                                        {
                                            Run newRVolume = new Run();
                                            newRVolume.RunProperties = new RunProperties(new RunStyle { Val = "bibvolume" });
                                            Italic italic = new Italic();
                                            newRVolume.RunProperties.AppendChild(italic);
                                            Text newTVolume = new Text() { Text = values[0] };
                                            newRVolume.AppendChild(newTVolume);
                                            lastrun.InsertBeforeSelf(newRVolume);

                                            Run runtxt1 = new Run((new Text { Text = "(", Space = SpaceProcessingModeValues.Preserve }));
                                            lastrun.InsertBeforeSelf(runtxt1);
                                            Run newRIssue = new Run();
                                            newRIssue.RunProperties = new RunProperties(new RunStyle { Val = "bibissue" });
                                            Text newTIssue = new Text() { Text = values[1] };
                                            newRIssue.AppendChild(newTIssue);
                                            lastrun.InsertBeforeSelf(newRIssue);
                                            Run runtxt2 = new Run((new Text { Text = "), ", Space = SpaceProcessingModeValues.Preserve }));
                                            lastrun.InsertBeforeSelf(runtxt2);

                                            Run newRfpage = new Run();
                                            newRfpage.RunProperties = new RunProperties(new RunStyle { Val = "bibfpage" });
                                            Text newTfpage = new Text() { Text = values[2] };
                                            newRfpage.AppendChild(newTfpage);
                                            lastrun.InsertBeforeSelf(newRfpage);

                                            int n = 0;
                                            foreach (var r in runlist.ToList())
                                            {
                                                n++;
                                                if (n <= count)
                                                {
                                                    r.Remove();
                                                }
                                            }
                                        }
                                        else if (P.Descendants<Run>().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList().Count() > 0)
                                        {
                                            foreach (Run run in P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList())
                                            {
                                                run.RunProperties = null;

                                            }
                                        }
                                    }
                                }
                            }
                        }
                        else if (P.Descendants<Run>().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList().Count() > 0)
                        {
                            foreach (Run run in P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList())
                            {
                                run.RunProperties = null;

                            }
                        }
                    }



                }




                D.Save();
            }
        }

        public static void ReferenceSearchAndReplaceSurnameFname(string strDocPath)
        {
            Microsoft.Office.Interop.Word.Document mdoc = null;

            try
            {

                string strDocContent = null;

                // Read the Document Content from Word Document //
                //strDocContent = GlobalMethods.ReadDocumentContent(strDocPath);


                // Load Word Document Content
                mdoc = GlobalMethods.LoadWordDocument(strDocPath);

                strDocContent = mdoc.Content.Text;

                if (strDocContent == null)
                    return;

                // Search the patterns in the document content using Regular Expression
                if (mdoc != null)
                {

                    //GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    List<string> strMatchText = new List<string>();
                    string strSearchRegEx = null;



                    strMatchText.Clear();
                    strSearchRegEx = null;

                    ///configuration added by Karan Start
                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"Kaggle Inc");

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter], "", "REF1", "bib_organization", "", true, false, true, true, false);
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"SPSS Tutorials");

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter], "", "REF1", "bib_organization", "", true, false, true, true, false);
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"([\(][0-9]{4}[\)])");

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter].Replace("(", "").Replace(")", "").Replace(".", ""), "", "REF1", "bib_year", "", true, false, true, true, false);
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"([A-Z][A-Za-záňíü\-\–\‐]+\s{0,}[A-Z][A-Za-záňíü\-\–\‐]+\s{0,}[A-Z][A-Za-záňíü\-\–\‐]+\,\s{0,}[A-Z]\.)|([A-Z][A-Za-záňíü\-\–\‐]+\,\s[A-Z]\.\s[A-Z]\.)|([A-Z][A-Za-záňíü\-\–\‐]+\,\s{1,}[A-Z]\.\s[A-Z][A-Za-zzáňíü]+\.\s[A-Z]\.)|([A-Z][A-Za-záňíü\-\–\‐]+\s{0,}[A-Z][A-Za-záňíü\-\–\‐]+\,\s{0,}[A-Z]\.)|([A-Z][A-Za-záňíü\-\–\‐]+\,\s{1,}[A-Z]\.\s{0,}[A-Z]\.\s[A-Z]\.)|([A-Z][A-Za-záňíü\-\–\‐]+\,\s{1,}[A-Z]\.\s{0,}[A-Z]\.)|([A-Z][A-Za-záňíü\-\–\‐]+\,\s{1,}[A-Z]\.)|([A-Z][A-Za-záňíü\-\–\‐]+\,\s[A-Z]\.\s[A-Z])");  //15-10-2020
                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter], "", "REF1", "bib_surname", "", true, false, true, true, false);
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;

                    GlobalMethods.wordApp.Selection.HomeKey(Microsoft.Office.Interop.Word.WdUnits.wdStory);

                    GlobalMethods.SearchAndReplace(mdoc, "^p ", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(Microsoft.Office.Interop.Word.WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, " ^p", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(Microsoft.Office.Interop.Word.WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "<jrn> ^p", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(Microsoft.Office.Interop.Word.WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "<jrn> </jrn>", "", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(Microsoft.Office.Interop.Word.WdUnits.wdStory);
                    // GlobalMethods.SearchAndReplace(mdoc, "^p^p", "^p", "", "", "", false, false, true, false, false);//commented on 11020202 For boxstart and BoxEnd style remove. 
                    GlobalMethods.wordApp.Selection.HomeKey(Microsoft.Office.Interop.Word.WdUnits.wdStory);
                    //GlobalMethods.SearchAndReplace(mdoc, "^g", "^&", "", "", "FIG", false, true, true, false);
                    GlobalMethods.SearchAndReplace(mdoc, "^~", "-", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(Microsoft.Office.Interop.Word.WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "", "", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(Microsoft.Office.Interop.Word.WdUnits.wdStory);
                    //GlobalMethods.SearchAndReplace(mdoc, "", "", "BullList", "", "", false, false, false, false, false);//19022020 comment for indend remove.
                    GlobalMethods.wordApp.Selection.HomeKey(Microsoft.Office.Interop.Word.WdUnits.wdStory);

                    object oMissing = System.Reflection.Missing.Value;

                    object saveChanges = Microsoft.Office.Interop.Word.WdSaveOptions.wdSaveChanges;
                    ((Microsoft.Office.Interop.Word._Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;

                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                if (mdoc != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    object saveChanges = Microsoft.Office.Interop.Word.WdSaveOptions.wdSaveChanges;
                    ((Microsoft.Office.Interop.Word._Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;
                }
                if (GlobalMethods.wordApp != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    ((Microsoft.Office.Interop.Word._Application)GlobalMethods.wordApp).Quit(ref oMissing, ref oMissing, ref oMissing);
                    GlobalMethods.wordApp = null;
                }
            }


        }

        public static void applyFirstnameSurname(string newDoc)
        {
            bool bParaHasStructuredRef = false;

            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(x => x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val != null && x.ParagraphProperties.ParagraphStyleId.Val.Value == "REF1").ToList())
                {
                    if (Regex.Match(P.InnerText, @"(([A-Za-zá\-\–]+\,\s[A-Z\.\s]{10})|([A-Za-zá\-\–]+\,\s[A-Z\.\s]{8})|([A-Za-zá\-\–]+\,\s[A-Z\.\s]{5})|([A-Za-zá\-\–]+\,\s[A-Z\.\s]{2}))").Success)
                    {
                        if (P.Descendants<Run>().Count() > 0)
                        {

                            if (P.Descendants<Run>().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibsurname").ToList().Count() > 0)
                            {
                                var runlist = P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibsurname").ToList();

                                foreach (Run run in runlist.ToList())
                                {
                                    if (run.InnerText.Trim().Contains(','))
                                    {
                                        var splitname = run.InnerText.Trim().Split(',').ToList();
                                        if (splitname.Count() == 2)
                                        {
                                            Run newSurname = new Run();
                                            newSurname.RunProperties = new RunProperties(new RunStyle { Val = "bibsurname" });
                                            Text newTSurname = new Text() { Text = splitname[0] };
                                            newSurname.AppendChild(newTSurname);
                                            run.InsertBeforeSelf(newSurname);

                                            Run runtxt3 = new Run((new Text { Text = ", ", Space = SpaceProcessingModeValues.Preserve }));
                                            run.InsertBeforeSelf(runtxt3);

                                            Run newfname = new Run();
                                            newfname.RunProperties = new RunProperties(new RunStyle { Val = "bibfname" });
                                            Text newTFname = new Text() { Text = splitname[1] };
                                            newfname.AppendChild(newTFname);

                                            run.InsertBeforeSelf(newfname);
                                            run.Remove();

                                        }
                                        else
                                        {
                                            run.RunProperties = null;
                                        }
                                    }
                                    else
                                    {
                                        run.RunProperties = null;
                                    }
                                }
                            }


                        }

                    }

                }


                D.Save();
            }
        }

        public static void RemoveFnameandsurnameafteryear(string newDoc)
        {
            bool bibyearStart = false;
            bool FirstbibyearFound = false;

            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(x => x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val != null && x.ParagraphProperties.ParagraphStyleId.Val.Value == "REF1").ToList())
                {
                    bibyearStart = false;
                    FirstbibyearFound = false;
                    if (P.Descendants<Run>().Count() > 0)
                    {
                        foreach (var run in P.Descendants<Run>().ToList())
                        {

                            if (run.RunProperties != null && run.RunProperties.RunStyle != null && run.RunProperties.RunStyle.Val != null && run.RunProperties.RunStyle.Val.Value == "bibyear")
                            {
                                bibyearStart = true;
                                if (FirstbibyearFound == false)
                                {
                                    FirstbibyearFound = true;
                                    continue;
                                }
                                else
                                {
                                    FirstbibyearFound = false;

                                }


                            }
                            if (bibyearStart)
                            {
                                if (run.RunProperties != null && run.RunProperties.RunStyle != null && run.RunProperties.RunStyle.Val != null && run.RunProperties.RunStyle.Val.Value == "bibsurname")
                                {
                                    run.RunProperties = null;
                                }
                                else if (FirstbibyearFound == false && run.RunProperties != null && run.RunProperties.RunStyle != null && run.RunProperties.RunStyle.Val != null && run.RunProperties.RunStyle.Val.Value == "bibyear")
                                {
                                    FirstbibyearFound = true;
                                    run.RunProperties = null;
                                }

                            }
                        }
                    }



                }

                D.Save();
            }
        }

        private static bool CheckIfREF1ParaFind(string newDoc)
        {
            bool bParaHasStructuredRef = false;

            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                if (D.Descendants<Paragraph>().ToList().Where(x => x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val != null && x.ParagraphProperties.ParagraphStyleId.Val.Value == "REF1").ToList().Count() > 0)
                {
                    bParaHasStructuredRef = true;
                }

                D.Save();
            }

            return bParaHasStructuredRef;
        }
        public static void AdditalicRunpropertiesforReference(string newDoc)
        {
            bool bParaHasStructuredRef = false;

            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(x => x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val != null && x.ParagraphProperties.ParagraphStyleId.Val.Value == "REF1").ToList())
                {
                    foreach (Run run in P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val != null && x.RunProperties.RunStyle.Val.Value == "bibjournal").ToList())
                    {

                        Italic italic = new Italic();
                        run.RunProperties.AppendChild(italic);
                    }

                }


                D.Save();
            }
        }
        public static void ChangeRefTypeOnBasisofJournalTitleandPubname(string newDoc)
        {
            bool bParaHasStructuredRef = false;

            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(x => x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val != null && x.ParagraphProperties.ParagraphStyleId.Val.Value == "REF1").ToList())
                {

                    if (P.Descendants<Run>().Count() > 0 && P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val != null && x.RunProperties.RunStyle.Val.Value == "bibpubname").Count() > 0)
                    {
                        P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().ForEach(t => t.ToList().ForEach(txt =>
                        {

                            if (txt == P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().FirstOrDefault().FirstOrDefault())
                            {
                                txt.Text = txt.Text.Replace("<unknown>", "<bok>").Replace("</unknown>", "</bok>").Replace("<jrn>", "<bok>").Replace("</jrn>", "</bok>");
                            }
                            if (txt == P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().LastOrDefault().LastOrDefault())
                            {
                                txt.Text = txt.Text.Replace("<unknown>", "<bok>").Replace("</unknown>", "</bok>").Replace("<jrn>", "<bok>").Replace("</jrn>", "</bok>");
                            }
                            else if (txt == P.Descendants<Text>().ToList().LastOrDefault())
                            {
                                txt.Text = txt.Text.Replace("<unknown>", "<bok>").Replace("</unknown>", "</bok>").Replace("<jrn>", "<bok>").Replace("</jrn>", "</bok>");
                            }
                        }));
                    }
                    else if (P.Descendants<Run>().Count() > 0 && P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val != null && x.RunProperties.RunStyle.Val.Value == "bibjournal").Count() > 0)
                    {
                        P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().ForEach(t => t.ToList().ForEach(txt =>
                        {

                            if (txt == P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().FirstOrDefault().FirstOrDefault())
                            {
                                txt.Text = txt.Text.Replace("<unknown>", "<jrn>").Replace("</unknown>", "</jrn>").Replace("<bok>", "<jrn>").Replace("</bok>", "</jrn>");
                            }
                            if (txt == P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().LastOrDefault().LastOrDefault())
                            {
                                txt.Text = txt.Text.Replace("<unknown>", "<jrn>").Replace("</unknown>", "</jrn>").Replace("<bok>", "<jrn>").Replace("</bok>", "</jrn>");
                            }
                            else if (txt == P.Descendants<Text>().ToList().LastOrDefault())
                            {
                                txt.Text = txt.Text.Replace("<unknown>", "<jrn>").Replace("</unknown>", "</jrn>").Replace("<bok>", "<jrn>").Replace("</bok>", "</jrn>");
                            }
                        }));
                    }
                    else
                    {
                        if (!P.InnerText.Contains("<jrn>"))
                        {
                            P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().ForEach(t => t.ToList().ForEach(txt =>
                            {

                                if (txt == P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().FirstOrDefault().FirstOrDefault())
                                {
                                    txt.Text = txt.Text.Replace("<bok>", "<unknown>").Replace("</bok>", "</unknown>").Replace("<jrn>", "<unknown>").Replace("</jrn>", "</unknown>");
                                }
                                if (txt == P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().LastOrDefault().LastOrDefault())
                                {
                                    txt.Text = txt.Text.Replace("<bok>", "<unknown>").Replace("</bok>", "</unknown>").Replace("<jrn>", "<unknown>").Replace("</jrn>", "</unknown>");
                                }
                                else if (txt == P.Descendants<Text>().ToList().LastOrDefault())
                                {
                                    txt.Text = txt.Text.Replace("<bok>", "<unknown>").Replace("</bok>", "</unknown>").Replace("<jrn>", "<unknown>").Replace("</jrn>", "</unknown>");
                                }
                            }));
                        }
                    }


                }



                D.Save();
            }
        }
        private static void MergeReferenceElementsIntoOneGroupSage(string newDoc, string RefPatternFile, string JournalDB, string PublisherDB)
        {
            // Read the Reference patterns from the configuration and store in list
            List<string> strRefPatterns = new List<string>();
            strRefPatterns = GlobalMethods.ReadAndStoreFileValuesInArray(RefPatternFile);

            // Read the Journal list from the configuration and store in list

            List<string> strJournalsColl = new List<string>();
            strJournalsColl = GlobalMethods.ReadAndStoreFileValuesInArray(JournalDB);

            // Sort the Journals array on length //
            strJournalsColl = GlobalMethods.SortStringListOnLength(strJournalsColl);

            List<string> strPublisherColl = new List<string>();
            strPublisherColl = GlobalMethods.ReadAndStoreFileValuesInArray(PublisherDB);

            // Sort the Publisher array on length //
            strPublisherColl = GlobalMethods.SortStringListOnLength(strPublisherColl);

            //string strUsedPatternFilename = ConfigurationManager.AppSettings.Get("UsedPattern");
            //StreamWriter sw = new StreamWriter(strUsedPatternFilename);

            //string strUnStructuredReferencesFilename = ConfigurationManager.AppSettings.Get("UnStructuredReferences");
            //StreamWriter sw1 = new StreamWriter(strUnStructuredReferencesFilename);
            bool bookRefFind = false;
            bool jrnRefFind = false;
            bool edbRefFind = false;
            bool unknownRefFind = false;
            bool unknownRefIsStructured = false;  // //Develope Name:Priyanka Vishwakarma ,Date:18_10_2019 ,Requirement:Unknown reference comment  not added .,Integrated by:Vikas sir.
            bool CommentWithoutTextFound = false;//Developer Name:Priyanka Vishwakarma ,Date:28_11_2019 ,Requirement:Author comment without text added in document. Integrated by:Vikas sir.
            OpenXmlElement newP = null;  //Developer Name:Priyanka Vishwakarma ,Date:6_6_2019 ,Requirement:Add Para as it is if New Pattern of Reference Comes ,Integrated By:Vikas Sir.

            int nRefNumberCounter = 0;

            using (WordprocessingDocument WPD = WordprocessingDocument
                .Open(newDoc, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    RemoveComments = false,
                    RemoveContentControls = true,
                    RemoveEndAndFootNotes = false,
                    RemoveFieldCodes = true,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = false,//Developer name :Priyanka Vishwakarma. Date:29_5_2019, Requirement:it removes the indentation from the nested list  ,Integrated By:Vikas sir. 
                };

                MarkupSimplifier.SimplifyMarkup(WPD, settings);

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                bool bParaHasStructuredRef = false;


                Dictionary<int, string> commentRangeStartText = new Dictionary<int, string>();
                // Search all Paragraphs that is "TOC1 to TOC3" style.
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().
                    Where(e => e.ParagraphProperties != null
                        && e.ParagraphProperties.ParagraphStyleId != null
                        && e.ParagraphProperties.ParagraphStyleId.Val == "REF1"))
                {


                    newP = P.CloneNode(true);  //Develope Name:Priyanka Vishwakarma ,Date:8_6_2019 ,Requirement: for adding Comment in Reference on bibnumber only.
                    bParaHasStructuredRef = false;
                    bookRefFind = false;
                    jrnRefFind = false;
                    edbRefFind = false;
                    unknownRefFind = false;
                    nRefNumberCounter++;
                    commentRangeStartText.Clear();
                    string refText = "";
                    bool numberedRef = false;
                    Run CommentWithoutText = new Run();  //Developer Name:Priyanka Vishwakarma ,Date:28_11_2019 ,Requirement:Author comment without text added in document. Integrated by:Vikas sir.
                    ////Develope Name:Priyanka Vishwakarma ,Date:14_10_2019 ,Requirement: for unnumbered reference 

                    if (P.InnerText.ToLower().StartsWith("<jrn>") || P.InnerText.ToLower().StartsWith("<bok>") || P.InnerText.ToLower().StartsWith("<edb>") || P.InnerText.ToLower().StartsWith("<unknown>"))
                    {
                        refText = P.InnerText.Replace("<jrn>", "").Replace("<bok>", "").Replace("<edb>", "").Replace("<unknown>", "").Replace("</jrn>", "").Replace("</bok>", "").Replace("</edb>", "").Replace("</unknown>", "").Trim();
                        Regex startwithnumber = new Regex(@"^(\d+)|^(\[\d+\])");
                        if (startwithnumber.IsMatch(refText))
                        {
                            numberedRef = true;
                        }
                    }


                    //Develope Name:Priyanka Vishwakarma ,Date:28_5_2019 ,Requirement: for adding Comment in Reference on bibnumber only.
                    foreach (var PS in P.Descendants().ToList().Where(x => x.XName == W.commentRangeStart).ToList())
                    {
                        commentRangeStartText.Add(Convert.ToInt16(((DocumentFormat.OpenXml.Wordprocessing.MarkupRangeType)PS).Id.InnerText), PS.NextSibling().InnerText.Trim());

                    }
                    //Developer Name:Priyanka Vishwakarma ,Date:28_11_2019 ,Requirement:Author comment without text added in document. Integrated by:Vikas sir.
                    if (P.Descendants().ToList().Where(x => x.XName == W.commentReference).ToList().Count > 0 && (P.Descendants().ToList().Where(x => x.XName == W.commentReference).ToList().Count > P.Descendants().ToList().Where(x => x.XName == W.commentRangeStart).ToList().Count))
                    {

                        foreach (var ps in P.Descendants().ToList().Where(x => x.XName == W.commentReference).ToList())
                        {
                            int commmentid = 0;
                            if (ps.HasAttributes)
                            {
                                commmentid = Convert.ToInt32(((DocumentFormat.OpenXml.Wordprocessing.MarkupType)ps).Id.Value);
                                if (commmentid > 0)
                                {
                                    if (!commentRangeStartText.ContainsKey(commmentid))
                                    {

                                        string key = ((DocumentFormat.OpenXml.Wordprocessing.MarkupType)ps).Id.Value;
                                        CommentReference cRef = new CommentReference() { Id = key.ToString() };
                                        CommentWithoutText.AppendChild(cRef);
                                        CommentWithoutTextFound = true;
                                    }
                                }

                            }
                        }

                    }

                    //-----------------End----------------------------------------------------------
                    if (P.HasChildren == false)
                    {
                        try
                        {
                            P.Remove();
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(ex.Message);
                        }
                    }
                    else
                    {
                        if (P.HasChildren == true)
                        {
                            if (P.Descendants<Run>().Count() > 0)
                            {
                                List<OpenXmlElement> RList = P.Descendants<OpenXmlElement>().ToList();

                                bParaHasStructuredRef = CheckIfParaHasStructuredReference(RList);

                                if (bParaHasStructuredRef == true)
                                {
                                    bParaHasStructuredRef = false;
                                    //continue;   //Commented by Priyanka on 15_5_2019 for apply RefCharStyle .  
                                }
                                if (P.InnerText.ToLower().StartsWith("<bok>"))
                                {
                                    bookRefFind = true;
                                }
                                else if (P.InnerText.ToLower().StartsWith("<jrn>"))
                                {
                                    jrnRefFind = true;
                                }
                                else if (P.InnerText.ToLower().StartsWith("<edb>"))
                                {
                                    edbRefFind = true;
                                }
                                else if (P.InnerText.ToLower().StartsWith("<unknown>"))
                                {
                                    unknownRefFind = true;
                                    //Develope Name:Priyanka Vishwakarma ,Date:18_10_2019 ,Requirement:Unknown reference comment  not added .,Integrated by:Vikas sir.
                                    if (P.Descendants<Run>().ToList().Any(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val != null && x.RunProperties.RunStyle.Val.Value == "bibnumber"))
                                    {
                                        unknownRefIsStructured = true;
                                    }
                                    //-----------------End--------------------------------------

                                }
                                //else if(Regex.Match(P.InnerText,"^[0-9]+").Success)
                                //{
                                //    jrnRefFind = true;
                                //}

                                if (/*P.InnerText.ToLower().StartsWith("<unknown>") ||*/ P.InnerText.ToLower().StartsWith("<eref>") || P.InnerText.ToLower().StartsWith("<ths>"))
                                {
                                    goto NextRef;
                                }
                                //Developer name :Priyanka Vishwakarma. Date:29_5_2019, Requirement:If other types of references other than jrn,bok,edb,unknown,eref come and add it as it is. ,Integrated By:Vikas sir. 
                                else if (!P.InnerText.ToLower().StartsWith("<jrn>") && !P.InnerText.ToLower().StartsWith("<bok>") && !P.InnerText.ToLower().StartsWith("<edb>") && !P.InnerText.ToLower().StartsWith("<unknown>") && !P.InnerText.ToLower().StartsWith("<eref>"))
                                {
                                    if (P.InnerText.ToLower().StartsWith("<") && P.InnerText.ToLower().EndsWith(">"))
                                    {
                                        goto NextRef;
                                    }
                                }
                                //Developer Name:Priyanka Vishwakarma ,Date:20_12_2019 ,Requirement:for structured reference withoout opening and closing tags.,Integrated By:Vikas Sir.
                                if (jrnRefFind == false && bookRefFind == false && unknownRefFind == false && edbRefFind == false)
                                {
                                    goto NextRef;
                                }
                                string strReferenceText = null;
                                foreach (Run R in P.Descendants<Run>().ToList())
                                {
                                    //foreach (Text T in R.Descendants<Text>().ToList())
                                    //{
                                    //    strReferenceText = strReferenceText + T.Text;
                                    //}
                                    //R.Remove();
                                    //---------Developer Name:Priyanka Vishwakarma ,Date:12_6_2019 ,Requirement:nobreakHyphen present in book references instead of emdash . ,Integrated By:Vikas Sir.
                                    if (R.Descendants().Where(x => x.XName == W.noBreakHyphen).ToList().Count > 0)
                                    {
                                        strReferenceText = strReferenceText + "–";
                                    }
                                    else
                                    {
                                        strReferenceText = strReferenceText + R.InnerText;
                                    }
                                    //----------------------------end----------------------------------------------------------------------
                                    //foreach (Text T in R.Descendants<Text>().ToList())
                                    //{
                                    //    strReferenceText = strReferenceText + T.Text;
                                    //}
                                    R.Remove();
                                }

                                if (strReferenceText.Trim() == "")
                                {
                                    P.Remove();
                                    goto NextRef;
                                }

                                if (strReferenceText == "<jrn> </jrn>")
                                {
                                    P.Remove();
                                    goto NextRef;
                                }

                                if (strReferenceText == "<jrn> ")
                                {
                                    P.Remove();
                                    goto NextRef;
                                }

                                strReferenceText = strReferenceText.Replace("<jrn>", "").Replace("</jrn>", "").Replace("<unknown>", "").Replace("</unknown>", "").Trim();
                                string strjrnrefNumber = null;
                                strjrnrefNumber = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(strReferenceText, @"^(\[[0-9]+\]\s{1,})");
                                if (!string.IsNullOrEmpty(strjrnrefNumber))
                                {
                                    strReferenceText = Regex.Replace(strReferenceText, @"^(\[[0-9]+\]\s{1,})", "");//strReferenceText.Replace(strjrnrefNumber, "");
                                }
                                // if already tagged reference //



                                // Increment the Reference Counter
                                //nRefNumberCounter++;
                                // Build the pattern and Groups before searching and creating runs //

                                List<string> strRefGroups = new List<string>();
                                bool bPatternStart = false;
                                string SearchPattern = null;
                                int ReplaceGrpCount = 0;
                                string PubMedPattern = null;
                                strRefGroups.Clear();
                                List<string> strRefSearchPattern = new List<string>();
                                int nIndex = 0;
                                int nGrpCounter = 0;
                                int nPatternIndex = 0;

                                // Check if the reference is other //
                                #region  for <unknown> tag

                                if (unknownRefFind == true)
                                {
                                    //if (strReferenceText.ToLower().Contains("www.") || strReferenceText.ToLower().Contains("http:") || strReferenceText.ToLower().Contains("https:") || strReferenceText.ToLower().Contains("conference")
                                    //    || strReferenceText.ToLower().Contains("presented at") || strReferenceText.ToLower().Contains("presentation at"))
                                    //{
                                    // Insert Reference Number //
                                    if (unknownRefIsStructured == false && GlobalMethods.strClientName.ToLower() != "sage")    //Develope Name:Priyanka Vishwakarma ,Date:18_10_2019 ,Requirement:Unknown reference comment  not added .,Integrated by:Vikas sir.
                                    {
                                        Run newrunx = P.AppendChild(new Run());
                                        // Add Text to the Run element.
                                        newrunx.AppendChild(new Text("<unknown>"));
                                        if (numberedRef)
                                        {

                                            Run run3 = new Run(new RunProperties(new RunStyle() { Val = "bibnumber" }));
                                            P.AppendChild(run3);
                                            // Add Text to the Run element.
                                            run3.AppendChild(new Text("[" + nRefNumberCounter.ToString() + "]"));

                                            Run newrun4 = P.AppendChild(new Run());
                                            // Add Text to the Run element.
                                            newrun4.AppendChild(new Text(" ") { Space = SpaceProcessingModeValues.Preserve });
                                        }

                                        Run newrun5 = P.AppendChild(new Run());
                                        // Add Text to the Run element.
                                        newrun5.AppendChild(new Text(strReferenceText.Trim()));

                                        Run newrund = P.AppendChild(new Run());
                                        // Add Text to the Run element.
                                        newrund.AppendChild(new Text("</unknown>"));

                                        goto NextRef;
                                    }
                                    else
                                    {
                                        P.InsertAfterSelf(newP);
                                        P.Remove();
                                        strRefGroups.Clear();
                                    }
                                    //}
                                }
                                #endregion



                                #region for<bok> tag
                                else if (bookRefFind == true)
                                {

                                    // Publisher found then mark the reference as Journal Reference //
                                    strReferenceText = strReferenceText.Replace("<bok>", "").Replace("</bok>", "").Trim();
                                    string stredbrefNumber = null;
                                    stredbrefNumber = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(strReferenceText, @"^(\[[0-9]+\]\s{1,})");
                                    if (!string.IsNullOrEmpty(stredbrefNumber))
                                    {
                                        strReferenceText = Regex.Replace(strReferenceText, @"^(\[[0-9]+\]\s{1,})", "");///strReferenceText.Replace(stredbrefNumber, "");
                                    }

                                    if (strReferenceText != "")

                                        strReferenceText = strReferenceText.Replace("–", "-");
                                    for (int i = 0; i < strRefPatterns.Count; i++)
                                    {
                                        if (strRefPatterns[i].ToLower().StartsWith("[pattern start]") == true)
                                        {
                                            nPatternIndex++;
                                            strRefGroups.Clear();
                                            bPatternStart = true;
                                            continue;
                                        }

                                        if (bPatternStart == true)
                                        {
                                            if (strRefPatterns[i].ToLower().StartsWith("searchpattern:") == true)
                                            {
                                                SearchPattern = strRefPatterns[i].Replace("SearchPattern:", "");

                                                if (SearchPattern.Contains(@"(et al)(\.)"))
                                                {
                                                    //  Console.WriteLine("Got it");
                                                }

                                                continue;
                                            }

                                            if (strRefPatterns[i].ToLower().StartsWith("replacegroup:") == true)
                                            {
                                                string RpGrp = strRefPatterns[i].Replace("ReplaceGroup:", "");
                                                ReplaceGrpCount = Convert.ToInt32(RpGrp);
                                                continue;
                                            }

                                            if (strRefPatterns[i].ToLower().StartsWith("pubmed:") == true)
                                            {
                                                PubMedPattern = strRefPatterns[i].Replace("Pubmed:", "");
                                                continue;
                                            }

                                            if (strRefPatterns[i].ToLower().StartsWith("group:") == true)
                                            {
                                                strRefGroups.Add(strRefPatterns[i].Replace("Group:", ""));
                                                continue;
                                            }
                                        }

                                        if (strRefPatterns[i].ToLower().StartsWith("[pattern end]") == true)
                                        {
                                            bPatternStart = false;

                                            // Build the search Pattern by Replacing the JournalInfo
                                            ////for (nIndex = 0; nIndex < strPublisherColl.Count; nIndex++)
                                            ////{
                                            ////    string strTmp; //= strJournalsColl[nIndex].Replace("(", @"\(").Replace(")", @"\)").Replace(".", @"\.");

                                            ////    if (strReferenceText.Contains(strPublisherColl[nIndex]))
                                            ////    {

                                            ////        strTmp = strPublisherColl[nIndex].Replace("(", @"\(").Replace(")", @"\)").Replace(".", @"\.");
                                            ////        strRefSearchPattern.Add(SearchPattern.Replace("(PublicationInfo)", "(" + strTmp + ")"));
                                            ////        break;
                                            ////    }
                                            ////}

                                            foreach (var Publst in strPublisherColl.ToList().Where(x => strReferenceText.Contains(x)))
                                            {
                                                string strTmp;
                                                strTmp = Publst.Replace("(", @"\(").Replace(")", @"\)").Replace(".", @"\.");
                                                strRefSearchPattern.Add(SearchPattern.Replace("(PublicationInfo)", "(" + strTmp + ")"));
                                                //break;

                                                if (strRefSearchPattern.Count > 0 && ReplaceGrpCount > 0)
                                                {
                                                    if (strRefGroups.Count == ReplaceGrpCount)
                                                    {
                                                        MatchCollection Checkmatches = Regex.Matches(strReferenceText, SearchPattern.Replace("(PublicationInfo)", "(" + strTmp + ")"));

                                                        if (Checkmatches.Count == 1)
                                                        {
                                                            break;
                                                        }
                                                        else
                                                        {
                                                            goto notMatchRef;
                                                        }
                                                    }
                                                }
                                            }




                                            if (strRefSearchPattern.Count > 0)
                                            {


                                                if (ReplaceGrpCount > 0)
                                                {
                                                    if (strRefGroups.Count != ReplaceGrpCount)
                                                    {
                                                        strRefGroups.Clear();
                                                        goto NextRefSearchPattern;
                                                    }

                                                    for (nIndex = 0; nIndex < strRefSearchPattern.Count; nIndex++)
                                                    {
                                                        MatchCollection matches = Regex.Matches(strReferenceText, strRefSearchPattern[nIndex]);

                                                        if (matches.Count == 1)
                                                        {
                                                            if (strReferenceText.Contains("et al") && strRefSearchPattern[nIndex].Contains("et al") == false)
                                                            {
                                                                goto NextRefPat;
                                                            }

                                                            //Develope Name:Priyanka Vishwakarma ,Date:4_6_2019 ,Requirement: full text match .
                                                            if (matches[0].Value.ToString().Replace("PubMed", "").Trim() != strReferenceText.Replace("PubMed", "").Trim())
                                                            {
                                                                goto NextRefPat;
                                                            }

                                                            foreach (Match match in matches)
                                                            {
                                                                if ((match.Groups.Count - 1) != ReplaceGrpCount)
                                                                    goto NextRefPat;
                                                                //---------Develope Name:Priyanka Vishwakarma ,Date:4_6_2019 ,Requirement: for adding Comment in Reference.
                                                                foreach (var PS in P.Descendants().ToList().Where(x => x.XName == W.commentRangeStart).ToList())
                                                                {

                                                                    PS.Remove();
                                                                }
                                                                foreach (var PE in P.Descendants().ToList().Where(x => x.XName == W.commentRangeEnd).ToList())
                                                                {

                                                                    PE.Remove();
                                                                }
                                                                foreach (var PR in P.Descendants().ToList().Where(x => x.XName == W.commentReference).ToList())
                                                                {

                                                                    PR.Remove();
                                                                }

                                                                //------------------------------End----------------------------------
                                                                // Extract group info 
                                                                int GrpNo = 0;
                                                                PubMedPattern = GlobalMethods.ReplaceWholeWord(PubMedPattern, "space", " ");
                                                                for (nGrpCounter = 0; nGrpCounter < strRefGroups.Count; nGrpCounter++)
                                                                {
                                                                    string tmpstr = null;
                                                                    tmpstr = strRefGroups[nGrpCounter];
                                                                    GrpNo = 0;
                                                                    GrpNo = nGrpCounter + 1;

                                                                    if (nGrpCounter == 0)
                                                                    {
                                                                        Run newruna = P.AppendChild(new Run());
                                                                        // Add Text to the Run element.
                                                                        newruna.AppendChild(new Text("<bok>"));
                                                                        if (numberedRef)
                                                                        {

                                                                            // Insert Reference Number //
                                                                            Run run = new Run(new RunProperties(new RunStyle() { Val = "bibnumber" }));
                                                                            P.AppendChild(run);
                                                                            // Add Text to the Run element.
                                                                            run.AppendChild(new Text("[" + nRefNumberCounter.ToString() + "]"));
                                                                            //---------Develope Name:Priyanka Vishwakarma ,Date:4_6_2019 ,Requirement: for adding Comment in Reference.
                                                                            if (commentRangeStartText.ContainsValue(run.InnerText.Trim()))
                                                                            {
                                                                                var key = commentRangeStartText.FirstOrDefault(x => x.Value == run.InnerText.Trim()).Key;
                                                                                if (!string.IsNullOrEmpty(key.ToString()))
                                                                                {
                                                                                    if (!P.Descendants<CommentRangeStart>().ToList().Any(x => x.GetAttributes().Any(l => l.LocalName == "id" && l.Value == key.ToString())))   //Developer Name:Priyanka Vishwakarma, Date:09_09_2019 ,Requirement:Check paragraph having comment with same id . integrated by:Vikas sir.
                                                                                    {
                                                                                        run.InsertBeforeSelf(new CommentRangeStart() { Id = key.ToString() });
                                                                                        RunProperties rpr = new RunProperties(new RunStyle() { Val = "CommentReference" });

                                                                                        run.InsertAfterSelf(new Run(new CommentReference() { Id = key.ToString() })).Append(rpr);
                                                                                        run.InsertAfterSelf(new CommentRangeEnd() { Id = key.ToString() });
                                                                                        new Run(new CommentReference() { Id = key.ToString() });
                                                                                    }
                                                                                }

                                                                            }
                                                                            //--------------------end-----------------------------------------------------------

                                                                            Run newrun2 = P.AppendChild(new Run());
                                                                            //// Add Text to the Run element.
                                                                            newrun2.AppendChild(new Text(" ") { Space = SpaceProcessingModeValues.Preserve });
                                                                        }
                                                                    }

                                                                    if (tmpstr.Contains(":"))
                                                                    {
                                                                        // Split the string
                                                                        string[] separators = { ":" };
                                                                        string[] strValues = tmpstr.Split(separators, StringSplitOptions.RemoveEmptyEntries);

                                                                        if (strValues.Length > 0)
                                                                        {
                                                                            if (strValues[0] == "space")
                                                                            {
                                                                                Run run = P.AppendChild(new Run());
                                                                                //OpenXmlAttribute openXmlAttribute = new OpenXmlAttribute("space", "xml", "preserve");
                                                                                // Add Text to the Run element.
                                                                                Text T = new Text(" ") { Space = SpaceProcessingModeValues.Preserve };
                                                                                //T.SetAttribute(openXmlAttribute);
                                                                                run.AppendChild(T);
                                                                            }
                                                                            else if (strValues[0] == "blank")
                                                                            {
                                                                                // No action required
                                                                            }
                                                                            else if (strValues[0] == "value")
                                                                            {
                                                                                Run run = P.AppendChild(new Run());
                                                                                // Add Text to the Run element.
                                                                                run.AppendChild(new Text(match.Groups[nGrpCounter + 1].Value));

                                                                                PubMedPattern = GlobalMethods.ReplaceWholeWord(PubMedPattern, "Group" + GrpNo, match.Groups[nGrpCounter + 1].Value);
                                                                            }

                                                                            if (strValues[1] != "") // Style
                                                                            {

                                                                                Run run = new Run(new RunProperties(new RunStyle() { Val = strValues[1] }));
                                                                                if (strValues[1].Trim() == "bibarticle" || strValues[1].Trim() == "bibjournal")
                                                                                {
                                                                                    Italic italic = new Italic();
                                                                                    run.RunProperties.AppendChild(italic);
                                                                                }
                                                                                P.AppendChild(run);
                                                                                // Add Text to the Run element.
                                                                                run.AppendChild(new Text(match.Groups[nGrpCounter + 1].Value));
                                                                                //---------Develope Name:Priyanka Vishwakarma ,Date:4_6_2019 ,Requirement: for adding Comment in Reference.

                                                                                if (commentRangeStartText.ContainsValue(run.InnerText.Trim()))
                                                                                {

                                                                                    var key = commentRangeStartText.FirstOrDefault(x => x.Value == run.InnerText.Trim()).Key;
                                                                                    if (!string.IsNullOrEmpty(key.ToString()))
                                                                                    {
                                                                                        if (!P.Descendants<CommentRangeStart>().ToList().Any(x => x.GetAttributes().Any(l => l.LocalName == "id" && l.Value == key.ToString())))   //Developer Name:Priyanka Vishwakarma, Date:09_09_2019 ,Requirement:Check paragraph having comment with same id . integrated by:Vikas sir.
                                                                                        {
                                                                                            run.InsertBeforeSelf(new CommentRangeStart() { Id = key.ToString() });
                                                                                            RunProperties rpr = new RunProperties(new RunStyle() { Val = "CommentReference" });

                                                                                            run.InsertAfterSelf(new Run(new CommentReference() { Id = key.ToString() })).Append(rpr);
                                                                                            run.InsertAfterSelf(new CommentRangeEnd() { Id = key.ToString() });
                                                                                            new Run(new CommentReference() { Id = key.ToString() });
                                                                                        }
                                                                                    }

                                                                                }
                                                                                else if (commentRangeStartText.Any(kvp => run.InnerText.StartsWith(kvp.Value)))
                                                                                {

                                                                                    var key = 0;
                                                                                    foreach (var val in commentRangeStartText)
                                                                                    {

                                                                                        if (run.InnerText.StartsWith(val.Value))
                                                                                        {
                                                                                            key = val.Key;
                                                                                        }

                                                                                    }

                                                                                    //var key = commentRangeStartText.Where(x => run.InnerText.StartsWith(x.Value));

                                                                                    // var key = commentRangeStartText.FirstOrDefault(x => x.Value == run.InnerText.Trim()).Key;

                                                                                    if (!string.IsNullOrEmpty(key.ToString()))
                                                                                    {
                                                                                        if (!P.Descendants<CommentRangeStart>().ToList().Any(x => x.GetAttributes().Any(l => l.LocalName == "id" && l.Value == key.ToString())))   //Developer Name:Priyanka Vishwakarma, Date:09_09_2019 ,Requirement:Check paragraph having comment with same id . integrated by:Vikas sir.
                                                                                        {
                                                                                            run.InsertBeforeSelf(new CommentRangeStart() { Id = key.ToString() });
                                                                                            RunProperties rpr = new RunProperties(new RunStyle() { Val = "CommentReference" });

                                                                                            run.InsertAfterSelf(new Run(new CommentReference() { Id = key.ToString() })).Append(rpr);
                                                                                            run.InsertAfterSelf(new CommentRangeEnd() { Id = key.ToString() });
                                                                                            new Run(new CommentReference() { Id = key.ToString() });
                                                                                        }
                                                                                    }

                                                                                }
                                                                                else if (commentRangeStartText.Any(kvp => run.InnerText.EndsWith(kvp.Value)))
                                                                                {

                                                                                    var key = 0;
                                                                                    foreach (var val in commentRangeStartText)
                                                                                    {

                                                                                        if (run.InnerText.EndsWith(val.Value))
                                                                                        {
                                                                                            key = val.Key;
                                                                                        }

                                                                                    }

                                                                                    //  var key = commentRangeStartText.FirstOrDefault(x => x.Value == run.InnerText.Trim()).Key;
                                                                                    if (!string.IsNullOrEmpty(key.ToString()))
                                                                                    {
                                                                                        if (!P.Descendants<CommentRangeStart>().ToList().Any(x => x.GetAttributes().Any(l => l.LocalName == "id" && l.Value == key.ToString())))   //Developer Name:Priyanka Vishwakarma, Date:09_09_2019 ,Requirement:Check paragraph having comment with same id . integrated by:Vikas sir.
                                                                                        {
                                                                                            run.InsertBeforeSelf(new CommentRangeStart() { Id = key.ToString() });
                                                                                            RunProperties rpr = new RunProperties(new RunStyle() { Val = "CommentReference" });

                                                                                            run.InsertAfterSelf(new Run(new CommentReference() { Id = key.ToString() })).Append(rpr);
                                                                                            run.InsertAfterSelf(new CommentRangeEnd() { Id = key.ToString() });
                                                                                            new Run(new CommentReference() { Id = key.ToString() });
                                                                                        }
                                                                                    }

                                                                                }
                                                                                //--------------------end-----------------------------------------------------------


                                                                                PubMedPattern = GlobalMethods.ReplaceWholeWord(PubMedPattern, "Group" + GrpNo, match.Groups[nGrpCounter + 1].Value);
                                                                            }
                                                                        }
                                                                    }
                                                                    else if (tmpstr.Contains("space"))
                                                                    {
                                                                        Run run = P.AppendChild(new Run());
                                                                        //OpenXmlAttribute openXmlAttribute = new OpenXmlAttribute("space", "xml", "preserve");
                                                                        // Add Text to the Run element.
                                                                        Text T = new Text(" ") { Space = SpaceProcessingModeValues.Preserve };
                                                                        //T.SetAttribute(openXmlAttribute);
                                                                        run.AppendChild(T);
                                                                    }
                                                                    else if (tmpstr.Contains("blank"))
                                                                    {
                                                                    }
                                                                    else if (tmpstr.Contains("value"))
                                                                    {
                                                                        Run run = P.AppendChild(new Run());
                                                                        // Add Text to the Run element.
                                                                        if (((match.Groups[nGrpCounter + 1].Value)) != null && ((match.Groups[nGrpCounter + 1].Value) == "-"))   //23_4_2019
                                                                        {
                                                                            string s = (match.Groups[nGrpCounter + 1].Value).Replace("-", "–");
                                                                            run.AppendChild(new Text(s));
                                                                            PubMedPattern = GlobalMethods.ReplaceWholeWord(PubMedPattern, "Group" + GrpNo, s);
                                                                        }
                                                                        else
                                                                        {
                                                                            run.AppendChild(new Text(match.Groups[nGrpCounter + 1].Value));
                                                                            PubMedPattern = GlobalMethods.ReplaceWholeWord(PubMedPattern, "Group" + GrpNo, match.Groups[nGrpCounter + 1].Value);
                                                                        }
                                                                    }
                                                                    else
                                                                    {
                                                                        Run run = new Run(new RunProperties(new RunStyle() { Val = tmpstr }));
                                                                        P.AppendChild(run);
                                                                        // Add Text to the Run element.
                                                                        run.AppendChild(new Text(match.Groups[nGrpCounter + 1].Value));
                                                                        //---------Develope Name:Priyanka Vishwakarma ,Date:4_6_2019 ,Requirement: for adding Comment in Reference.
                                                                        //------code for comment on surname...
                                                                        if (commentRangeStartText.ContainsValue(run.InnerText.Trim()))
                                                                        {

                                                                            var key = commentRangeStartText.FirstOrDefault(x => x.Value == run.InnerText.Trim()).Key;
                                                                            if (!string.IsNullOrEmpty(key.ToString()))
                                                                            {
                                                                                if (!P.Descendants<CommentRangeStart>().ToList().Any(x => x.GetAttributes().Any(l => l.LocalName == "id" && l.Value == key.ToString())))   //Developer Name:Priyanka Vishwakarma, Date:09_09_2019 ,Requirement:Check paragraph having comment with same id . integrated by:Vikas sir.
                                                                                {
                                                                                    run.InsertBeforeSelf(new CommentRangeStart() { Id = key.ToString() });
                                                                                    RunProperties rpr = new RunProperties(new RunStyle() { Val = "CommentReference" });

                                                                                    run.InsertAfterSelf(new Run(new CommentReference() { Id = key.ToString() })).Append(rpr);
                                                                                    run.InsertAfterSelf(new CommentRangeEnd() { Id = key.ToString() });
                                                                                    new Run(new CommentReference() { Id = key.ToString() });
                                                                                }
                                                                            }

                                                                        }

                                                                        //-----------------end----------------------------------------------

                                                                        PubMedPattern = GlobalMethods.ReplaceWholeWord(PubMedPattern, "Group" + GrpNo, match.Groups[nGrpCounter + 1].Value);
                                                                    }
                                                                }
                                                            }

                                                            //if (PubMedPattern.Contains("Group") == false)/////commented by priyanka for unstructured refrences
                                                            //{
                                                            //    // Extract PmID from PubMed //
                                                            //    string retPMIDVal = null;

                                                            //    retPMIDVal = PubMed.ExtractPMID("http://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=pubmed&retmode=XML&retmax=1000&term=" + PubMedPattern);

                                                            //    if (retPMIDVal != null && retPMIDVal != "")
                                                            //    {
                                                            //        // Build the new Hyperlink with the PMID to be inserted as Hyperlink //

                                                            //        //add the url
                                                            //        string urlLabel = "PubMed";
                                                            //        System.Uri uri = new Uri("http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&list_uids=" + retPMIDVal + "&dopt=Abstract");

                                                            //        bool bExtRefFound = false;
                                                            //        foreach (HyperlinkRelationship hRel in WPD.MainDocumentPart.HyperlinkRelationships)
                                                            //        {
                                                            //            if (hRel.Uri == uri)
                                                            //            {
                                                            //                bExtRefFound = true;
                                                            //            }
                                                            //        }

                                                            //        if (!bExtRefFound)
                                                            //        {
                                                            //            // Add the new URL to document Relations
                                                            //            HyperlinkRelationship rel = MDP.AddHyperlinkRelationship(uri, true);
                                                            //            string relationshipId = rel.Id;

                                                            //            Hyperlink hlink = new Hyperlink(new Run(new RunProperties(new RunStyle() { Val = "bibmedline" }), new Text("PubMed"))) { History = OnOffValue.FromBoolean(true), Id = relationshipId };

                                                            //            // Insert PubMed ID at the end of the newly marked Reference //

                                                            //            P.AppendChild(hlink);
                                                            //        }
                                                            //    }
                                                            //}

                                                            // Insert Journal closing tag here //
                                                            Run newrunb = P.AppendChild(new Run());
                                                            // Add Text to the Run element.
                                                            newrunb.AppendChild(new Text("</bok>"));
                                                            //---------Develope Name:Priyanka Vishwakarma ,Date:4_6_2019 ,Requirement: for adding Comment in Reference.
                                                            if (commentRangeStartText.ContainsValue(newrunb.InnerText.Trim()))
                                                            {
                                                                var key = commentRangeStartText.FirstOrDefault(x => x.Value == newrunb.InnerText.Trim()).Key;
                                                                if (!string.IsNullOrEmpty(key.ToString()))
                                                                {
                                                                    if (!P.Descendants<CommentRangeStart>().ToList().Any(x => x.GetAttributes().Any(l => l.LocalName == "id" && l.Value == key.ToString())))   //Developer Name:Priyanka Vishwakarma, Date:09_09_2019 ,Requirement:Check paragraph having comment with same id . integrated by:Vikas sir.
                                                                    {
                                                                        newrunb.InsertBeforeSelf(new CommentRangeStart() { Id = key.ToString() });
                                                                        RunProperties rpr = new RunProperties(new RunStyle() { Val = "CommentReference" });

                                                                        newrunb.InsertAfterSelf(new Run(new CommentReference() { Id = key.ToString() })).Append(rpr);
                                                                        newrunb.InsertAfterSelf(new CommentRangeEnd() { Id = key.ToString() });
                                                                        new Run(new CommentReference() { Id = key.ToString() });
                                                                    }
                                                                }

                                                            }
                                                            //--------------------end-----------------------------------------------------------
                                                            //Developer name :Priyanka Vishwakarma ,Date :29_11_2019 ,Requirement:Add blank text Author query in xml. Integrated by:Vikas sir.
                                                            else if (CommentWithoutText != null && CommentWithoutTextFound == true)
                                                            {


                                                                if (CommentWithoutText.Descendants().ToList().Where(x => x.LocalName == "commentReference").Count() > 0 && CommentWithoutText.Descendants().ToList().Where(x => x.LocalName == "commentReference").FirstOrDefault().HasAttributes)
                                                                {
                                                                    string key = CommentWithoutText.Descendants().FirstOrDefault().GetAttribute("id", (CommentWithoutText.Descendants().FirstOrDefault().GetAttributes().FirstOrDefault()).NamespaceUri).Value;


                                                                    if (key != null)
                                                                    {
                                                                        if (!P.Descendants<CommentReference>().ToList().Any(x => x.GetAttributes().Any(l => l.LocalName == "id" && l.Value == key.ToString())))
                                                                        {
                                                                            newrunb.InsertAfterSelf(CommentWithoutText);  //28_11_2019
                                                                        }
                                                                    }

                                                                }
                                                            }

                                                            //-------------------------------------End-----------------------------
                                                            goto NextRef;
                                                        }

                                                    NextRefPat:
                                                        {
                                                        }
                                                    }

                                                }
                                            }
                                        notMatchRef: { }
                                        }

                                    //strRefGroups.Clear();

                                    NextRefSearchPattern:
                                        {
                                            continue;
                                        }
                                    }




                                    //int nCounter = 0;
                                    //for (nCounter = 0; nCounter < strPublisherColl.Count(); nCounter++)
                                    //{
                                    //    if (strReferenceText.Contains(strPublisherColl[nCounter]))
                                    //    {
                                    //        // Publisher found then mark the reference as Journal Reference //

                                    //        Run newrunx = P.AppendChild(new Run());
                                    //        // Add Text to the Run element.
                                    //        newrunx.AppendChild(new Text("<bok>"));

                                    //        // Insert Reference Number //

                                    //        Run run3 = new Run(new RunProperties(new RunStyle() { Val = "bibnumber" }));
                                    //        P.AppendChild(run3);
                                    //        // Add Text to the Run element.
                                    //        run3.AppendChild(new Text(nRefNumberCounter.ToString()));

                                    //        Run newrun4 = P.AppendChild(new Run());
                                    //        // Add Text to the Run element.
                                    //        newrun4.AppendChild(new Text(". ") { Space = SpaceProcessingModeValues.Preserve });

                                    //        Run newrun5 = P.AppendChild(new Run());
                                    //        // Add Text to the Run element.
                                    //        newrun5.AppendChild(new Text(strReferenceText.Trim()));

                                    //        Run newrunt = P.AppendChild(new Run());
                                    //        // Add Text to the Run element.
                                    //        newrunt.AppendChild(new Text("</bok>"));

                                    //        goto NextRef;

                                    //    }
                                    //}

                                }
                                #endregion


                                #region else for <jrn> tag
                                // Check if the reference is other or Journal reference //
                                else if (jrnRefFind == true)
                                {
                                    if (strReferenceText != "")

                                        strReferenceText = strReferenceText.Replace("–", "-");


                                    //bib_medline style for Pubmed to be inserted //


                                    for (int i = 0; i < strRefPatterns.Count; i++)
                                    {
                                        if (strRefPatterns[i].ToLower().StartsWith("[pattern start]") == true)
                                        {
                                            nPatternIndex++;
                                            strRefGroups.Clear();
                                            bPatternStart = true;
                                            continue;
                                        }

                                        if (bPatternStart == true)
                                        {
                                            if (strRefPatterns[i].ToLower().StartsWith("searchpattern:") == true)
                                            {
                                                SearchPattern = strRefPatterns[i].Replace("SearchPattern:", "");

                                                if (SearchPattern.Contains(@"(et al)(\.)"))
                                                {
                                                    //Console.WriteLine("Got it");
                                                }

                                                continue;
                                            }

                                            if (strRefPatterns[i].ToLower().StartsWith("replacegroup:") == true)
                                            {
                                                string RpGrp = strRefPatterns[i].Replace("ReplaceGroup:", "");
                                                ReplaceGrpCount = Convert.ToInt32(RpGrp);
                                                continue;
                                            }

                                            if (strRefPatterns[i].ToLower().StartsWith("pubmed:") == true)
                                            {
                                                PubMedPattern = strRefPatterns[i].Replace("Pubmed:", "");
                                                continue;
                                            }

                                            if (strRefPatterns[i].ToLower().StartsWith("group:") == true)
                                            {
                                                strRefGroups.Add(strRefPatterns[i].Replace("Group:", ""));
                                                continue;
                                            }
                                        }

                                        if (strRefPatterns[i].ToLower().StartsWith("[pattern end]") == true)
                                        {
                                            bPatternStart = false;

                                            // Build the search Pattern by Replacing the JournalInfo

                                            //for (nIndex = 0; nIndex < strJournalsColl.Count; nIndex++)
                                            //{
                                            //    string strTmp; //= strJournalsColl[nIndex].Replace("(", @"\(").Replace(")", @"\)").Replace(".", @"\.");

                                            //    if (strReferenceText.Contains(strJournalsColl[nIndex]))
                                            //    {

                                            //        strTmp = strJournalsColl[nIndex].Replace("(", @"\(").Replace(")", @"\)").Replace(".", @"\.");
                                            //        strRefSearchPattern.Add(SearchPattern.Replace("(JournalInfo)", "(" + strTmp + ")"));
                                            //        break;
                                            //    }
                                            //}

                                            foreach (var Jurnlst in strJournalsColl.ToList().Where(x => strReferenceText.Contains(x)))
                                            {
                                                string strTmp;
                                                strTmp = Jurnlst.Replace("(", @"\(").Replace(")", @"\)").Replace(".", @"\.");
                                                strRefSearchPattern.Add(SearchPattern.Replace("(JournalInfo)", "(" + strTmp + ")"));
                                                //break;

                                                if (strRefSearchPattern.Count > 0 && ReplaceGrpCount > 0)
                                                {
                                                    if (strRefGroups.Count == ReplaceGrpCount)
                                                    {
                                                        MatchCollection Checkmatches = Regex.Matches(strReferenceText, SearchPattern.Replace("(JournalInfo)", "(" + strTmp + ")"));

                                                        if (Checkmatches.Count == 1)
                                                        {
                                                            break;
                                                        }
                                                        else
                                                        {
                                                            goto notMatchRef;
                                                        }
                                                    }
                                                }
                                            }


                                            if (strRefSearchPattern.Count > 0)
                                            {
                                                // Search operation is ready

                                                if (ReplaceGrpCount > 0)
                                                {
                                                    if (strRefGroups.Count != ReplaceGrpCount)
                                                    {
                                                        strRefGroups.Clear();
                                                        goto NextRefSearchPattern;
                                                    }

                                                    for (nIndex = 0; nIndex < strRefSearchPattern.Count; nIndex++)
                                                    {
                                                        MatchCollection matches = Regex.Matches(strReferenceText, strRefSearchPattern[nIndex]);

                                                        if (matches.Count == 1)
                                                        {
                                                            if (strReferenceText.Contains("et al.") && strRefSearchPattern[nIndex].Contains("et al") == false)
                                                            {
                                                                goto NextRefPat;
                                                            }

                                                            //Develope Name:Priyanka Vishwakarma ,Date:4_6_2019 ,Requirement: full text match .
                                                            if (matches[0].Value.ToString().Replace("PubMed", "").Trim() != strReferenceText.Replace("PubMed", "").Trim())
                                                            {
                                                                goto NextRefPat;
                                                            }


                                                            foreach (Match match in matches)
                                                            {
                                                                if ((match.Groups.Count - 1) != ReplaceGrpCount)
                                                                    goto NextRefPat;

                                                                //---------Develope Name:Priyanka Vishwakarma ,Date:4_6_2019 ,Requirement: for adding Comment in Reference.
                                                                foreach (var PS in P.Descendants().ToList().Where(x => x.XName == W.commentRangeStart).ToList())
                                                                {

                                                                    PS.Remove();
                                                                }
                                                                foreach (var PE in P.Descendants().ToList().Where(x => x.XName == W.commentRangeEnd).ToList())
                                                                {

                                                                    PE.Remove();
                                                                }
                                                                foreach (var PR in P.Descendants().ToList().Where(x => x.XName == W.commentReference).ToList())
                                                                {

                                                                    PR.Remove();
                                                                }

                                                                //------------------------------End----------------------------------
                                                                // Extract group info 
                                                                int GrpNo = 0;
                                                                PubMedPattern = GlobalMethods.ReplaceWholeWord(PubMedPattern, "space", " ");
                                                                for (nGrpCounter = 0; nGrpCounter < strRefGroups.Count; nGrpCounter++)
                                                                {
                                                                    string tmpstr = null;
                                                                    tmpstr = strRefGroups[nGrpCounter];
                                                                    GrpNo = 0;
                                                                    GrpNo = nGrpCounter + 1;

                                                                    if (nGrpCounter == 0)
                                                                    {
                                                                        Run newruna = P.AppendChild(new Run());
                                                                        // Add Text to the Run element.
                                                                        newruna.AppendChild(new Text("<jrn>"));
                                                                        if (numberedRef)
                                                                        {

                                                                            // Insert Reference Number //
                                                                            Run run = new Run(new RunProperties(new RunStyle() { Val = "bibnumber" }));
                                                                            P.AppendChild(run);
                                                                            // Add Text to the Run element.
                                                                            run.AppendChild(new Text("[" + nRefNumberCounter.ToString() + "]"));


                                                                            //---------Develope Name:Priyanka Vishwakarma ,Date:4_6_2019 ,Requirement: for adding Comment in Reference.
                                                                            if (commentRangeStartText.ContainsValue(run.InnerText.Trim()))
                                                                            {
                                                                                var key = commentRangeStartText.FirstOrDefault(x => x.Value == run.InnerText.Trim()).Key;
                                                                                if (!string.IsNullOrEmpty(key.ToString()))
                                                                                {
                                                                                    if (!P.Descendants<CommentRangeStart>().ToList().Any(x => x.GetAttributes().Any(l => l.LocalName == "id" && l.Value == key.ToString())))   //Developer Name:Priyanka Vishwakarma, Date:09_09_2019 ,Requirement:Check paragraph having comment with same id . integrated by:Vikas sir.
                                                                                    {
                                                                                        run.InsertBeforeSelf(new CommentRangeStart() { Id = key.ToString() });
                                                                                        RunProperties rpr = new RunProperties(new RunStyle() { Val = "CommentReference" });

                                                                                        run.InsertAfterSelf(new Run(new CommentReference() { Id = key.ToString() })).Append(rpr);
                                                                                        run.InsertAfterSelf(new CommentRangeEnd() { Id = key.ToString() });
                                                                                        new Run(new CommentReference() { Id = key.ToString() });
                                                                                    }
                                                                                }

                                                                            }
                                                                            //--------------------end-----------------------------------------------------------

                                                                            Run newrun2 = P.AppendChild(new Run());
                                                                            // Add Text to the Run element.
                                                                            newrun2.AppendChild(new Text(" ") { Space = SpaceProcessingModeValues.Preserve });
                                                                        }
                                                                    }

                                                                    if (tmpstr.Contains(":"))
                                                                    {
                                                                        // Split the string
                                                                        string[] separators = { ":" };
                                                                        string[] strValues = tmpstr.Split(separators, StringSplitOptions.RemoveEmptyEntries);

                                                                        if (strValues.Length > 0)
                                                                        {
                                                                            if (strValues[0] == "space")
                                                                            {
                                                                                Run run = P.AppendChild(new Run());
                                                                                //OpenXmlAttribute openXmlAttribute = new OpenXmlAttribute("space", "xml", "preserve");
                                                                                // Add Text to the Run element.
                                                                                Text T = new Text(" ") { Space = SpaceProcessingModeValues.Preserve };
                                                                                //T.SetAttribute(openXmlAttribute);
                                                                                run.AppendChild(T);
                                                                            }
                                                                            else if (strValues[0] == "blank")
                                                                            {
                                                                                // No action required
                                                                            }
                                                                            else if (strValues[0] == "value")
                                                                            {
                                                                                Run run = P.AppendChild(new Run());
                                                                                // Add Text to the Run element.
                                                                                run.AppendChild(new Text(match.Groups[nGrpCounter + 1].Value));

                                                                                PubMedPattern = GlobalMethods.ReplaceWholeWord(PubMedPattern, "Group" + GrpNo, match.Groups[nGrpCounter + 1].Value);
                                                                            }

                                                                            if (strValues[1] != "") // Style
                                                                            {
                                                                                Run run = new Run(new RunProperties(new RunStyle() { Val = strValues[1] }));

                                                                                if (strValues[1].Trim() == "bibjournal" || strValues[1].Trim() == "bibvolume")  //16-09-2020
                                                                                {
                                                                                    Italic italic = new Italic();
                                                                                    run.RunProperties.AppendChild(italic);
                                                                                }
                                                                                P.AppendChild(run);
                                                                                // Add Text to the Run element.
                                                                                run.AppendChild(new Text(match.Groups[nGrpCounter + 1].Value));

                                                                                //---------Develope Name:Priyanka Vishwakarma ,Date:4_6_2019 ,Requirement: for adding Comment in Reference.

                                                                                if (commentRangeStartText.ContainsValue(run.InnerText.Trim()))
                                                                                {

                                                                                    var key = commentRangeStartText.FirstOrDefault(x => x.Value == run.InnerText.Trim()).Key;
                                                                                    if (!string.IsNullOrEmpty(key.ToString()))
                                                                                    {
                                                                                        if (!P.Descendants<CommentRangeStart>().ToList().Any(x => x.GetAttributes().Any(l => l.LocalName == "id" && l.Value == key.ToString())))   //Developer Name:Priyanka Vishwakarma, Date:09_09_2019 ,Requirement:Check paragraph having comment with same id . integrated by:Vikas sir.
                                                                                        {
                                                                                            run.InsertBeforeSelf(new CommentRangeStart() { Id = key.ToString() });
                                                                                            RunProperties rpr = new RunProperties(new RunStyle() { Val = "CommentReference" });

                                                                                            run.InsertAfterSelf(new Run(new CommentReference() { Id = key.ToString() })).Append(rpr);
                                                                                            run.InsertAfterSelf(new CommentRangeEnd() { Id = key.ToString() });
                                                                                            new Run(new CommentReference() { Id = key.ToString() });
                                                                                        }
                                                                                    }

                                                                                }
                                                                                else if (commentRangeStartText.Any(kvp => run.InnerText.StartsWith(kvp.Value)))
                                                                                {

                                                                                    var key = 0;
                                                                                    foreach (var val in commentRangeStartText)
                                                                                    {

                                                                                        if (run.InnerText.StartsWith(val.Value))
                                                                                        {
                                                                                            key = val.Key;
                                                                                        }

                                                                                    }

                                                                                    //var key = commentRangeStartText.Where(x => run.InnerText.StartsWith(x.Value));

                                                                                    // var key = commentRangeStartText.FirstOrDefault(x => x.Value == run.InnerText.Trim()).Key;

                                                                                    if (!string.IsNullOrEmpty(key.ToString()))
                                                                                    {
                                                                                        if (!P.Descendants<CommentRangeStart>().ToList().Any(x => x.GetAttributes().Any(l => l.LocalName == "id" && l.Value == key.ToString())))   //Developer Name:Priyanka Vishwakarma, Date:09_09_2019 ,Requirement:Check paragraph having comment with same id . integrated by:Vikas sir.
                                                                                        {
                                                                                            run.InsertBeforeSelf(new CommentRangeStart() { Id = key.ToString() });
                                                                                            RunProperties rpr = new RunProperties(new RunStyle() { Val = "CommentReference" });

                                                                                            run.InsertAfterSelf(new Run(new CommentReference() { Id = key.ToString() })).Append(rpr);
                                                                                            run.InsertAfterSelf(new CommentRangeEnd() { Id = key.ToString() });
                                                                                            new Run(new CommentReference() { Id = key.ToString() });
                                                                                        }
                                                                                    }

                                                                                }
                                                                                else if (commentRangeStartText.Any(kvp => run.InnerText.EndsWith(kvp.Value)))
                                                                                {

                                                                                    var key = 0;
                                                                                    foreach (var val in commentRangeStartText)
                                                                                    {

                                                                                        if (run.InnerText.EndsWith(val.Value))
                                                                                        {
                                                                                            key = val.Key;
                                                                                        }

                                                                                    }

                                                                                    //  var key = commentRangeStartText.FirstOrDefault(x => x.Value == run.InnerText.Trim()).Key;
                                                                                    if (!string.IsNullOrEmpty(key.ToString()))
                                                                                    {
                                                                                        if (!P.Descendants<CommentRangeStart>().ToList().Any(x => x.GetAttributes().Any(l => l.LocalName == "id" && l.Value == key.ToString())))   //Developer Name:Priyanka Vishwakarma, Date:09_09_2019 ,Requirement:Check paragraph having comment with same id . integrated by:Vikas sir.
                                                                                        {
                                                                                            run.InsertBeforeSelf(new CommentRangeStart() { Id = key.ToString() });
                                                                                            RunProperties rpr = new RunProperties(new RunStyle() { Val = "CommentReference" });

                                                                                            run.InsertAfterSelf(new Run(new CommentReference() { Id = key.ToString() })).Append(rpr);
                                                                                            run.InsertAfterSelf(new CommentRangeEnd() { Id = key.ToString() });
                                                                                            new Run(new CommentReference() { Id = key.ToString() });
                                                                                        }
                                                                                    }

                                                                                }
                                                                                //--------------------end-----------------------------------------------------------

                                                                                PubMedPattern = GlobalMethods.ReplaceWholeWord(PubMedPattern, "Group" + GrpNo, match.Groups[nGrpCounter + 1].Value);
                                                                            }
                                                                        }
                                                                    }
                                                                    else if (tmpstr.Contains("space"))
                                                                    {
                                                                        Run run = P.AppendChild(new Run());
                                                                        //OpenXmlAttribute openXmlAttribute = new OpenXmlAttribute("space", "xml", "preserve");
                                                                        // Add Text to the Run element.
                                                                        Text T = new Text(" ") { Space = SpaceProcessingModeValues.Preserve };
                                                                        //T.SetAttribute(openXmlAttribute);
                                                                        run.AppendChild(T);
                                                                    }
                                                                    else if (tmpstr.Contains("blank"))
                                                                    {
                                                                    }
                                                                    else if (tmpstr.Contains("value"))
                                                                    {
                                                                        Run run = P.AppendChild(new Run());
                                                                        // Add Text to the Run element.
                                                                        if (((match.Groups[nGrpCounter + 1].Value)) != null && ((match.Groups[nGrpCounter + 1].Value) == "-"))   //23_4_2019
                                                                        {
                                                                            string s = (match.Groups[nGrpCounter + 1].Value).Replace("-", "–");
                                                                            run.AppendChild(new Text(s));
                                                                            PubMedPattern = GlobalMethods.ReplaceWholeWord(PubMedPattern, "Group" + GrpNo, s);
                                                                        }
                                                                        else
                                                                        {
                                                                            run.AppendChild(new Text(match.Groups[nGrpCounter + 1].Value));
                                                                            PubMedPattern = GlobalMethods.ReplaceWholeWord(PubMedPattern, "Group" + GrpNo, match.Groups[nGrpCounter + 1].Value);
                                                                        }
                                                                    }
                                                                    else
                                                                    {
                                                                        Run run = new Run(new RunProperties(new RunStyle() { Val = tmpstr }));
                                                                        P.AppendChild(run);
                                                                        // Add Text to the Run element.
                                                                        run.AppendChild(new Text(match.Groups[nGrpCounter + 1].Value));
                                                                        //---------Develope Name:Priyanka Vishwakarma ,Date:4_6_2019 ,Requirement: for adding Comment in Reference.
                                                                        //------code for comment on surname...
                                                                        if (commentRangeStartText.ContainsValue(run.InnerText.Trim()))
                                                                        {

                                                                            var key = commentRangeStartText.FirstOrDefault(x => x.Value == run.InnerText.Trim()).Key;
                                                                            if (!string.IsNullOrEmpty(key.ToString()))
                                                                            {
                                                                                if (!P.Descendants<CommentRangeStart>().ToList().Any(x => x.GetAttributes().Any(l => l.LocalName == "id" && l.Value == key.ToString())))   //Developer Name:Priyanka Vishwakarma, Date:09_09_2019 ,Requirement:Check paragraph having comment with same id . integrated by:Vikas sir.
                                                                                {
                                                                                    run.InsertBeforeSelf(new CommentRangeStart() { Id = key.ToString() });
                                                                                    RunProperties rpr = new RunProperties(new RunStyle() { Val = "CommentReference" });

                                                                                    run.InsertAfterSelf(new Run(new CommentReference() { Id = key.ToString() })).Append(rpr);
                                                                                    run.InsertAfterSelf(new CommentRangeEnd() { Id = key.ToString() });
                                                                                    new Run(new CommentReference() { Id = key.ToString() });
                                                                                }
                                                                            }

                                                                        }

                                                                        //-----------------end----------------------------------------------

                                                                        //----------------------------------
                                                                        PubMedPattern = GlobalMethods.ReplaceWholeWord(PubMedPattern, "Group" + GrpNo, match.Groups[nGrpCounter + 1].Value);
                                                                    }
                                                                }
                                                            }

                                                            if (PubMedPattern.Contains("Group") == false)
                                                            {
                                                                // Extract PmID from PubMed //
                                                                string retPMIDVal = null;

                                                                retPMIDVal = PubMed.ExtractPMID("http://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=pubmed&retmode=XML&retmax=1000&term=" + PubMedPattern);

                                                                if (retPMIDVal != null && retPMIDVal != "")
                                                                {
                                                                    // Build the new Hyperlink with the PMID to be inserted as Hyperlink //

                                                                    //add the url
                                                                    string urlLabel = "PubMed";
                                                                    System.Uri uri = new Uri("http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&list_uids=" + retPMIDVal + "&dopt=Abstract");

                                                                    bool bExtRefFound = false;
                                                                    foreach (HyperlinkRelationship hRel in WPD.MainDocumentPart.HyperlinkRelationships)
                                                                    {
                                                                        if (hRel.Uri == uri)
                                                                        {
                                                                            bExtRefFound = true;
                                                                        }
                                                                    }

                                                                    if (!bExtRefFound)
                                                                    {
                                                                        // Add the new URL to document Relations
                                                                        HyperlinkRelationship rel = MDP.AddHyperlinkRelationship(uri, true);
                                                                        string relationshipId = rel.Id;

                                                                        Hyperlink hlink = new Hyperlink(new Run(new RunProperties(new RunStyle() { Val = "bibmedline" }), new Text("PubMed"))) { History = OnOffValue.FromBoolean(true), Id = relationshipId };

                                                                        // Insert PubMed ID at the end of the newly marked Reference //

                                                                        P.AppendChild(hlink);
                                                                    }
                                                                }
                                                            }

                                                            // Insert Journal closing tag here //
                                                            Run newrunb = P.AppendChild(new Run());
                                                            // Add Text to the Run element.
                                                            newrunb.AppendChild(new Text("</jrn>"));
                                                            //---------Develope Name:Priyanka Vishwakarma ,Date:4_6_2019 ,Requirement: for adding Comment in Reference.
                                                            if (commentRangeStartText.ContainsValue(newrunb.InnerText.Trim()))
                                                            {
                                                                var key = commentRangeStartText.FirstOrDefault(x => x.Value == newrunb.InnerText.Trim()).Key;
                                                                if (!string.IsNullOrEmpty(key.ToString()))
                                                                {
                                                                    if (!P.Descendants<CommentRangeStart>().ToList().Any(x => x.GetAttributes().Any(l => l.LocalName == "id" && l.Value == key.ToString())))   //Developer Name:Priyanka Vishwakarma, Date:09_09_2019 ,Requirement:Check paragraph having comment with same id . integrated by:Vikas sir.
                                                                    {
                                                                        newrunb.InsertBeforeSelf(new CommentRangeStart() { Id = key.ToString() });
                                                                        RunProperties rpr = new RunProperties(new RunStyle() { Val = "CommentReference" });

                                                                        newrunb.InsertAfterSelf(new Run(new CommentReference() { Id = key.ToString() })).Append(rpr);
                                                                        newrunb.InsertAfterSelf(new CommentRangeEnd() { Id = key.ToString() });
                                                                        new Run(new CommentReference() { Id = key.ToString() });
                                                                    }
                                                                }

                                                            }
                                                            //Developer name :Priyanka Vishwakarma ,Date :29_11_2019 ,Requirement:Add blank text Author query in xml. Integrated by:Vikas sir.
                                                            else if (CommentWithoutText != null && CommentWithoutTextFound == true)
                                                            {


                                                                if (CommentWithoutText.Descendants().ToList().Where(x => x.LocalName == "commentReference").Count() > 0 && CommentWithoutText.Descendants().ToList().Where(x => x.LocalName == "commentReference").FirstOrDefault().HasAttributes)
                                                                {
                                                                    string key = CommentWithoutText.Descendants().FirstOrDefault().GetAttribute("id", (CommentWithoutText.Descendants().FirstOrDefault().GetAttributes().FirstOrDefault()).NamespaceUri).Value;


                                                                    if (key != null)
                                                                    {
                                                                        if (!P.Descendants<CommentReference>().ToList().Any(x => x.GetAttributes().Any(l => l.LocalName == "id" && l.Value == key.ToString())))
                                                                        {
                                                                            newrunb.InsertAfterSelf(CommentWithoutText);  //28_11_2019
                                                                        }
                                                                    }

                                                                }
                                                            }

                                                            //-------------------------------------End-----------------------------
                                                            //--------------------end-----------------------------------------------------------

                                                            goto NextRef;
                                                        }

                                                    NextRefPat:
                                                        {
                                                        }
                                                    }
                                                }
                                            }
                                        notMatchRef: { }
                                        }

                                    //strRefGroups.Clear();

                                    NextRefSearchPattern:
                                        {
                                            continue;
                                        }
                                    }
                                }
                                #endregion

                                if (jrnRefFind == true)
                                {
                                    P.InsertAfterSelf(newP);
                                    P.Remove();
                                    strRefGroups.Clear();

                                    goto NextRef;
                                }
                                else if (bookRefFind == true)
                                {

                                    P.InsertAfterSelf(newP);
                                    P.Remove();
                                    strRefGroups.Clear();
                                    goto NextRef;
                                }




                            //sw1.WriteLine(strReferenceText);
                            //sw1.WriteLine("");

                            NextRef:
                                {
                                    continue;
                                }
                            }
                        }
                    }
                }

                D.Save();
            }
        }
        public static void applyJournalTitleToitalictext(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(x => x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val != null && x.ParagraphProperties.ParagraphStyleId.Val.Value == "REF1").ToList())
                {
                    if (P.Descendants<Run>().Count() > 0 && P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val != null && x.RunProperties.RunStyle.Val.Value == "bibjournal").Count() == 0)
                    {
                        foreach (Run run in P.Descendants<Run>().ToList())
                        {
                            var italicRun = run.Descendants().ToList().Where(y => y.LocalName.ToString() == "i").ToList();
                            foreach (var r in italicRun.ToList())
                            {
                                if (!run.InnerText.Trim().Contains(",") && !run.InnerText.Trim().Contains(".") && !run.InnerText.Trim().Contains(";") && Regex.Replace(run.InnerText.Trim(), @"[0-9]+", "") != "")
                                {
                                    if (run.RunProperties == null)
                                    {
                                        run.RunProperties = new RunProperties(new RunStyle { Val = "bibjournal" });
                                    }
                                    else if (run.RunProperties.RunStyle == null)
                                    {
                                        run.RunProperties.RunStyle = new RunStyle { Val = "bibjournal" };
                                    }
                                    else if (run.RunProperties.RunStyle.Val == null)
                                    {
                                        run.RunProperties.RunStyle.Val = "bibjournal";
                                    }
                                }
                                else if ((run.InnerText.Trim() != "." && run.InnerText.Trim() != "," && run.InnerText.Trim() != ";") && run.InnerText.Trim().EndsWith(",") && (!run.InnerText.Trim().Contains("(") && !run.InnerText.Trim().Contains(")")))
                                {
                                    var text = run.InnerText.Split(',').ToList();
                                    if (text.Count() == 2)
                                    {
                                        Run run1 = new Run();
                                        run1.RunProperties = new RunProperties(new RunStyle { Val = "bibjournal" });
                                        Text text1 = new Text(text[0]);
                                        run1.AppendChild(text1);
                                        Run run2 = new Run();
                                        Text text2 = new Text("," + text[1]);
                                        run2.AppendChild(text2);
                                        run.Parent.InsertBefore(run1, run);
                                        run.Parent.InsertBefore(run2, run);
                                        run.Remove();
                                    }
                                }
                                else if ((run.InnerText.Trim() != "." && run.InnerText.Trim() != "," && run.InnerText.Trim() != ";") && run.InnerText.Trim().EndsWith(".") && (!run.InnerText.Trim().Contains("(") && !run.InnerText.Trim().Contains(")")))
                                {
                                    var text = run.InnerText.Split('.').ToList();
                                    if (text.Count() == 2)
                                    {
                                        Run run1 = new Run();
                                        run1.RunProperties = new RunProperties(new RunStyle { Val = "bibjournal" });
                                        Text text1 = new Text(text[0]);
                                        run1.AppendChild(text1);
                                        Run run2 = new Run();
                                        Text text2 = new Text("." + text[1]);
                                        run2.AppendChild(text2);
                                        run.Parent.InsertBefore(run1, run);
                                        run.Parent.InsertBefore(run2, run);
                                        run.Remove();
                                    }
                                }
                                else if ((run.InnerText.Trim() != "." && run.InnerText.Trim() != "," && run.InnerText.Trim() != ";") && run.InnerText.Trim().EndsWith(";") && (!run.InnerText.Trim().Contains("(") && !run.InnerText.Trim().Contains(")")))
                                {
                                    var text = run.InnerText.Split(';').ToList();
                                    if (text.Count() == 2)
                                    {
                                        Run run1 = new Run();
                                        run1.RunProperties = new RunProperties(new RunStyle { Val = "bibjournal" });
                                        Text text1 = new Text(text[0]);
                                        run1.AppendChild(text1);
                                        Run run2 = new Run();
                                        Text text2 = new Text(";" + text[1]);
                                        run2.AppendChild(text2);
                                        run.Parent.InsertBefore(run1, run);
                                        run.Parent.InsertBefore(run2, run);
                                        run.Remove();
                                    }
                                }
                            }
                        }
                    }
                }
                D.Save();
            }
        }
        public static void ApplybibArticleinBookRef(string newDoc)
        {
            bool bParaHasStructuredRef = false;

            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(x => x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val != null && x.ParagraphProperties.ParagraphStyleId.Val.Value == "REF1").ToList())
                {

                    if (P.InnerText.Trim().StartsWith("<bok>"))
                    {
                        if (P.InnerText.Contains("Charmaz, K. , & Belgrave, L. (2012). Qualitative interviewing "))
                        {

                        }
                        foreach (Run run in P.Descendants<Run>().ToList())
                        {
                            if (run.RunProperties != null && run.RunProperties.Italic != null)
                            {
                                if (run.RunProperties.RunStyle != null && run.RunProperties.RunStyle.Val != null && run.RunProperties.RunStyle.Val.Value == "bibarticle" && P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val != null && x.RunProperties.RunStyle.Val.Value == "bibjournal").ToList().Count() > 0)
                                {
                                    run.RunProperties.Italic.Remove();


                                }
                                else if (run.RunProperties.RunStyle != null && run.RunProperties.RunStyle.Val != null && run.RunProperties.RunStyle.Val.Value == "bibarticle") //Developer Name:Priyanka Vishwakarma ,Date:22-10-2020,Requirement:make italic text when articletitle found in book type reference.
                                {

                                    run.RunProperties.RunStyle.Val.Value = "bibjournal";
                                }
                                //if (run.RunProperties.RunStyle == null)
                                //{
                                //    if (run.InnerText.EndsWith(". ")) //Developer Name:Priyanka Vishwakarma,Date:23-10-2020,Requirement:Check text ends with dot space in bibarticle. 
                                //    {
                                //        Run newRun = new Run();
                                //        newRun.RunProperties = new RunProperties(new RunStyle { Val = "bibarticle" });
                                //        Italic italic = new Italic();
                                //        newRun.RunProperties.AppendChild(italic);
                                //        Text newText = new Text() { Text = run.InnerText.TrimEnd().TrimEnd('.') };
                                //        newRun.AppendChild(newText);
                                //        run.InsertBeforeSelf(newRun);

                                //        Run runtxt3 = new Run((new Text { Text = ". ", Space = SpaceProcessingModeValues.Preserve }));
                                //        newRun.InsertAfterSelf(runtxt3);
                                //        run.Remove();

                                //    }
                                //    else if (run.InnerText.Trim().EndsWith("."))
                                //    {
                                //        Run newRun = new Run();
                                //        newRun.RunProperties = new RunProperties(new RunStyle { Val = "bibarticle" });
                                //        Italic italic = new Italic();
                                //        newRun.RunProperties.AppendChild(italic);
                                //        Text newText = new Text() { Text = run.InnerText.TrimEnd().TrimEnd('.') };
                                //        newRun.AppendChild(newText);
                                //        run.InsertBeforeSelf(newRun);

                                //        Run runtxt3 = new Run((new Text { Text = ".", Space = SpaceProcessingModeValues.Preserve }));
                                //        newRun.InsertAfterSelf(runtxt3);
                                //        run.Remove();

                                //    }
                                //    else if (run.InnerText.Trim() != "." && run.InnerText.Trim() != "," && run.InnerText.Trim() != ":" && run.InnerText.Trim() != ";")
                                //    {
                                //        Run newRun = new Run();
                                //        newRun.RunProperties = new RunProperties(new RunStyle { Val = "bibarticle" });
                                //        Italic italic = new Italic();
                                //        newRun.RunProperties.AppendChild(italic);
                                //        Text newText = new Text() { Text = run.InnerText.Trim() };
                                //        newRun.AppendChild(newText);
                                //        run.InsertBeforeSelf(newRun);
                                //        Run runtxt3 = null;
                                //        if (run.InnerText.EndsWith(" "))
                                //        {
                                //            runtxt3 = new Run((new Text { Text = " ", Space = SpaceProcessingModeValues.Preserve }));
                                //            newRun.InsertAfterSelf(runtxt3);
                                //        }

                                //        run.Remove();


                                //        //Run newRun = new Run();
                                //        //newRun.RunProperties = new RunProperties(new RunStyle { Val = "bibarticle" });
                                //        //Italic italic = new Italic();
                                //        //newRun.RunProperties.AppendChild(italic);
                                //        //Text newText = null;
                                //        //if (run.InnerText.EndsWith(" "))
                                //        //{
                                //        //    newText = (new Text { Text = " ", Space = SpaceProcessingModeValues.Preserve });

                                //        //}                                       
                                //        //newRun.AppendChild(newText);
                                //        //run.InsertBeforeSelf(newRun);                                        
                                //        //run.Remove();
                                //    }

                                //}

                            }
                            if (run.RunProperties != null && run.RunProperties.RunStyle != null && run.RunProperties.RunStyle.Val != null && run.RunProperties.RunStyle.Val.Value == "bibarticle" && P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val != null && x.RunProperties.RunStyle.Val.Value == "bibjournal").ToList().Count() > 0)
                            {
                                if (run.RunProperties.Italic != null)
                                {
                                    run.RunProperties.Italic.Remove();
                                }






                            }
                            else if (run.RunProperties != null && run.RunProperties.RunStyle != null && run.RunProperties.RunStyle.Val != null && run.RunProperties.RunStyle.Val.Value == "bibarticle") //Developer Name:Priyanka Vishwakarma ,Date:22-10-2020,Requirement:make italic text when articletitle found in book type reference.
                            {
                                Italic italic = new Italic();
                                run.RunProperties.AppendChild(italic);
                                run.RunProperties.RunStyle.Val.Value = "bibjournal";
                            }

                        }
                    NextParagraph: { }
                    }
                    else if (P.InnerText.Trim().StartsWith("<unknown>"))
                    {

                        foreach (Run run in P.Descendants<Run>().ToList())
                        {

                            if (run.RunProperties != null && run.RunProperties.RunStyle != null && run.RunProperties.RunStyle.Val != null && run.RunProperties.RunStyle.Val.Value == "bibarticle") //Developer Name:Priyanka Vishwakarma ,Date:22-10-2020,Requirement:make italic text when articletitle found in unknown type reference.
                            {
                                Italic italic = new Italic();
                                run.RunProperties.AppendChild(italic);
                            }

                        }
                    }



                }



                D.Save();
            }
        }

        public static void ApplybibArticleinJrnRef(string newDoc)
        {
            bool CheckedForbibjournal = false;

            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(x => x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val != null && x.ParagraphProperties.ParagraphStyleId.Val.Value == "REF1").ToList())
                {
                    CheckedForbibjournal = false;

                    if (P.InnerText.Trim().StartsWith("<jrn>"))
                    {
                        foreach (Run run in P.Descendants<Run>().ToList())
                        {
                            if (run.RunProperties != null && run.RunProperties.RunStyle != null && run.RunProperties.RunStyle.Val != null && run.RunProperties.RunStyle.Val.Value == "bibyear")
                            {
                                CheckedForbibjournal = true;
                            }
                            else if (run.RunProperties != null && run.RunProperties.RunStyle != null && run.RunProperties.RunStyle.Val != null && run.RunProperties.RunStyle.Val.Value == "bibjournal")
                            {
                                CheckedForbibjournal = false;
                            }

                            if (CheckedForbibjournal)
                            {
                                if (run.RunProperties != null && run.RunProperties.RunStyle == null)
                                {
                                    if (run.InnerText != "")
                                    {

                                        var text = GlobalMethods.DocumentRegEx(run.InnerText, @"(\.)\s{1,}([A-Za-z0-9\/\:\–\s\-\'\'\?\,\(\)\‐\“\”]+)(\.)").FirstOrDefault();
                                        if (text != null)
                                        {
                                            var values = run.InnerText.Split('.').ToList();

                                            if (values.Count() == 3 && values[2].Trim() == "")
                                            {
                                                Run runtxt1 = new Run((new Text { Text = values[0] + ". ", Space = SpaceProcessingModeValues.Preserve }));


                                                Run newRun = new Run();
                                                newRun.RunProperties = new RunProperties(new RunStyle { Val = "bibarticle" });
                                                Text newText = new Text() { Text = values[1] };
                                                newRun.AppendChild(newText);

                                                run.InsertBeforeSelf(runtxt1);
                                                run.InsertBeforeSelf(newRun);
                                                Run runtxt2 = new Run((new Text { Text = ". ", Space = SpaceProcessingModeValues.Preserve }));
                                                run.InsertBeforeSelf(runtxt2);
                                                run.Remove();
                                                goto NextParagraphStyle;

                                            }


                                        }
                                    }
                                }
                            }

                        }


                    }

                NextParagraphStyle: { }

                }



                D.Save();
            }
        }
        private static List<string> MarkCitationsInDocumentForINF(string strWordDoc)
        {
            List<string> strRefNumColl = new List<string>();
            try
            {
                // Reference Renumbering //



                using (WordprocessingDocument WPD = WordprocessingDocument
                    .Open(strWordDoc, true))
                {
                    SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                    {
                        RemoveComments = false,
                        RemoveContentControls = true,
                        RemoveEndAndFootNotes = false,
                        RemoveFieldCodes = true,
                        RemoveLastRenderedPageBreak = true,
                        RemovePermissions = true,
                        RemoveProof = true,
                        RemoveRsidInfo = true,
                        RemoveSmartTags = true,
                        RemoveSoftHyphens = false,
                        ReplaceTabsWithSpaces = false,//Developer name :Priyanka Vishwakarma. Date:29_5_2019, Requirement:it removes the indentation from the nested list  ,Integrated By:Vikas sir. 
                    };

                    MarkupSimplifier.SimplifyMarkup(WPD, settings);

                    MainDocumentPart MDP = WPD.MainDocumentPart;

                    Document D = MDP.Document;

                    //string strRefNum = "";
                    bool bRefNumberStart = false;
                    //int nRefNum = 0;

                    int nRefIndex = 0;

                    strRefNumColl.Clear();

                    // Search all Paragraphs that is "TOC1 to TOC3" style.
                    foreach (Paragraph P in D.Descendants<Paragraph>().ToList().
                    Where(e => e.ParagraphProperties != null
                        && e.ParagraphProperties.ParagraphStyleId != null
                        && e.ParagraphProperties.ParagraphStyleId.Val == "REF1"))
                    {
                        if (P.HasChildren)
                        {
                            if (P.Descendants<Run>().Count() > 0)
                            {
                                foreach (Run R in P.Descendants<Run>().ToList())
                                {
                                    if (R.RunProperties != null)
                                    {
                                        if (R.RunProperties.RunStyle != null)
                                        {
                                            if (R.RunProperties.RunStyle.Val == "bibnumber")
                                            {
                                                bRefNumberStart = true;
                                                nRefIndex++;
                                            }
                                            else
                                            {
                                                bRefNumberStart = false;
                                            }
                                        }
                                    }
                                    foreach (Text T in R.Descendants<Text>().ToList())
                                    {
                                        if (bRefNumberStart)
                                        {
                                            if (T.Text != ".")
                                            {
                                                strRefNumColl.Add(T.Text);
                                                bRefNumberStart = false;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }






                    // ================================= //
                    D.Save();
                    return strRefNumColl;
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return strRefNumColl;
            }
        }
        public static List<string> checkedAllSingleAuthorRef(string strWordDoc, List<string> singleAuthorWithYear)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(strWordDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().
                    Where(e => e.ParagraphProperties != null
                        && e.ParagraphProperties.ParagraphStyleId != null
                        && e.ParagraphProperties.ParagraphStyleId.Val == "REF1"))
                {
                    if (P.Descendants<Run>().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibsurname").ToList().Count() == 1 && P.Descendants<Run>().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibyear").ToList().Count() == 1)
                    {
                        var surname = P.Descendants<Run>().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibsurname").ToList().FirstOrDefault().InnerText;
                        var year = P.Descendants<Run>().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibyear").ToList().FirstOrDefault().InnerText;
                        if (!singleAuthorWithYear.Contains(surname + "," + year))
                            singleAuthorWithYear.Add(surname + "," + year);
                    }

                }
                D.Save();
            }
            return singleAuthorWithYear;
        }
        public static bool CheckAllreadyStructuredReference(string strWordDoc)
        {
            bool bParaHasStructuredRef = false;
            using (WordprocessingDocument WPD = WordprocessingDocument
                .Open(strWordDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;
                Document D = MDP.Document;
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().
                    Where(e => e.ParagraphProperties != null
                        && e.ParagraphProperties.ParagraphStyleId != null
                        && e.ParagraphProperties.ParagraphStyleId.Val == "REF1"))
                {
                    if (P.HasChildren == true)
                    {
                        if (P.Descendants<Run>().Count() > 0)
                        {
                            List<OpenXmlElement> RList = P.Descendants<OpenXmlElement>().ToList();

                            bParaHasStructuredRef = CheckIfParaHasStructuredReference(RList);

                            if (bParaHasStructuredRef == true)
                            {
                                continue;
                            }
                            else
                            {
                                bParaHasStructuredRef = false;
                                break;
                            }
                        }
                    }
                }
                D.Save();

                return bParaHasStructuredRef;
            }

        }
        private static void ApplybibnumberCharstyle(string newDoc)
        {

            bool bookRefFind = false;
            bool jrnRefFind = false;
            bool edbRefFind = false;
            bool unknownRefFind = false;
            bool CommentWithoutTextFound = false;
            Dictionary<int, string> commentRangeStartText = new Dictionary<int, string>();
            int nRefNumberCounter = 0;

            using (WordprocessingDocument WPD = WordprocessingDocument
                .Open(newDoc, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    RemoveComments = false,
                    RemoveContentControls = true,
                    RemoveEndAndFootNotes = false,
                    RemoveFieldCodes = true,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = false,//Developer name :Priyanka Vishwakarma. Date:29_5_2019, Requirement:it removes the indentation from the nested list  ,Integrated By:Vikas sir. 
                };

                MarkupSimplifier.SimplifyMarkup(WPD, settings);

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                bool bParaHasStructuredRef = false;
                // Search all Paragraphs that is "TOC1 to TOC3" style.
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().
                    Where(e => e.ParagraphProperties != null
                        && e.ParagraphProperties.ParagraphStyleId != null
                        && e.ParagraphProperties.ParagraphStyleId.Val == "REF1"))
                {
                    if (P.InnerText != null && P.InnerText.Trim() == "") //Developer Name:Priyanka Vishwakarma, Date:16-11-2021, Requirement:for handle blank REF1 para within references
                    {
                        continue;
                    }
                    bParaHasStructuredRef = false;
                    bookRefFind = false;
                    jrnRefFind = false;
                    edbRefFind = false;
                    unknownRefFind = false;
                    nRefNumberCounter++;
                    commentRangeStartText.Clear();
                    string refText = "";
                    bool numberedRef = false;
                    Run CommentWithoutText = new Run();  //Developer Name:Priyanka Vishwakarma ,Date:28_11_2019 ,Requirement:Author comment without text added in document. Integrated by:Vikas sir.
                    foreach (var PS in P.Descendants().ToList().Where(x => x.XName == W.commentRangeStart).ToList())//Developer Name:Priyanka Vishwakarma ,Date:21-07-2021 ,Requirement:Add author query at last of paragraph
                    {
                        commentRangeStartText.Add(Convert.ToInt16(((DocumentFormat.OpenXml.Wordprocessing.MarkupRangeType)PS).Id.InnerText), PS.NextSibling().InnerText.Trim());
                        CommentWithoutTextFound = true;

                    }
                    if (P.InnerText.ToLower().StartsWith("<bok>"))
                    {
                        bookRefFind = true;
                    }
                    else if (P.InnerText.ToLower().StartsWith("<jrn>"))
                    {
                        jrnRefFind = true;
                    }
                    else if (P.InnerText.ToLower().StartsWith("<edb>"))
                    {
                        edbRefFind = true;
                    }
                    else if (P.InnerText.ToLower().StartsWith("<unknown>"))
                    {
                        unknownRefFind = true;
                    }
                    string strReferenceText = null;
                    foreach (Run R in P.Descendants<Run>().ToList())
                    {
                        if (R.Descendants().Where(x => x.XName == W.noBreakHyphen).ToList().Count > 0)
                        {
                            strReferenceText = strReferenceText + "–";
                        }
                        else
                        {
                            strReferenceText = strReferenceText + R.InnerText;
                        }
                        R.Remove();
                    }
                    strReferenceText = strReferenceText.Replace("<jrn>", "").Replace("</jrn>", "").Replace("<bok>", "").Replace("</bok>", "").Replace("<edb>", "").Replace("</edb>", "").Replace("<unknown>", "").Replace("</unknown>", "").Trim();
                    string strjrnrefNumber = null;
                    strjrnrefNumber = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(strReferenceText, @"^([0-9]+\.)|^([0-9]+\s{1,})");
                    if (!string.IsNullOrEmpty(strjrnrefNumber))
                    {
                        strReferenceText = Regex.Replace(strReferenceText, @"^([0-9]+\.)|^([0-9]+\s{1,})", "");//strReferenceText.Replace(strjrnrefNumber, "");
                    }

                    List<string> strRefGroups = new List<string>();

                    strRefGroups.Clear();
                    List<string> strRefSearchPattern = new List<string>();


                    if (unknownRefFind == true)
                    {
                        Run newrunx = P.AppendChild(new Run());
                        // Add Text to the Run element.
                        newrunx.AppendChild(new Text("<unknown>"));

                        Run run3 = new Run(new RunProperties(new RunStyle() { Val = "bibnumber" }));
                        P.AppendChild(run3);
                        // Add Text to the Run element.
                        run3.AppendChild(new Text(nRefNumberCounter.ToString()));

                        Run newrun4 = P.AppendChild(new Run());
                        // Add Text to the Run element.
                        newrun4.AppendChild(new Text(". ") { Space = SpaceProcessingModeValues.Preserve });

                        Run newrun5 = P.AppendChild(new Run());
                        // Add Text to the Run element.
                        newrun5.AppendChild(new Text(strReferenceText.Trim()));
                        if (CommentWithoutTextFound)
                        {
                            CommentWithoutTextFound = false;
                            foreach (var cmt in commentRangeStartText.ToList())
                            {
                                var key = cmt.Key;
                                if (!string.IsNullOrEmpty(key.ToString()))
                                {
                                    P.AppendChild(new CommentRangeStart() { Id = key.ToString() });
                                    RunProperties rpr = new RunProperties(new RunStyle() { Val = "CommentReference" });

                                    P.AppendChild(new Run(new CommentReference() { Id = key.ToString() })).Append(rpr);
                                    P.AppendChild(new CommentRangeEnd() { Id = key.ToString() });
                                    new Run(new CommentReference() { Id = key.ToString() });
                                }
                            }

                        }


                        Run newrund = P.AppendChild(new Run());
                        // Add Text to the Run element.

                        newrund.AppendChild(new Text("</unknown>"));
                    }
                    else if (jrnRefFind == true)
                    {
                        Run newrunx = P.AppendChild(new Run());
                        // Add Text to the Run element.
                        newrunx.AppendChild(new Text("<jrn>"));

                        Run run3 = new Run(new RunProperties(new RunStyle() { Val = "bibnumber" }));
                        P.AppendChild(run3);
                        // Add Text to the Run element.
                        run3.AppendChild(new Text(nRefNumberCounter.ToString()));

                        Run newrun4 = P.AppendChild(new Run());
                        // Add Text to the Run element.
                        newrun4.AppendChild(new Text(". ") { Space = SpaceProcessingModeValues.Preserve });

                        Run newrun5 = P.AppendChild(new Run());
                        // Add Text to the Run element.
                        newrun5.AppendChild(new Text(strReferenceText.Trim()));
                        if (CommentWithoutTextFound)
                        {
                            CommentWithoutTextFound = false;
                            foreach (var cmt in commentRangeStartText.ToList())
                            {
                                var key = cmt.Key;
                                if (!string.IsNullOrEmpty(key.ToString()))
                                {
                                    P.AppendChild(new CommentRangeStart() { Id = key.ToString() });
                                    RunProperties rpr = new RunProperties(new RunStyle() { Val = "CommentReference" });

                                    P.AppendChild(new Run(new CommentReference() { Id = key.ToString() })).Append(rpr);
                                    P.AppendChild(new CommentRangeEnd() { Id = key.ToString() });
                                    new Run(new CommentReference() { Id = key.ToString() });
                                }
                            }

                        }
                        Run newrund = P.AppendChild(new Run());
                        // Add Text to the Run element.
                        newrund.AppendChild(new Text("</jrn>"));
                    }
                    else if (bookRefFind == true || edbRefFind == true)
                    {
                        Run newrunx = P.AppendChild(new Run());
                        // Add Text to the Run element.
                        newrunx.AppendChild(new Text("<bok>"));

                        Run run3 = new Run(new RunProperties(new RunStyle() { Val = "bibnumber" }));
                        P.AppendChild(run3);
                        // Add Text to the Run element.
                        run3.AppendChild(new Text(nRefNumberCounter.ToString()));

                        Run newrun4 = P.AppendChild(new Run());
                        // Add Text to the Run element.
                        newrun4.AppendChild(new Text(". ") { Space = SpaceProcessingModeValues.Preserve });

                        Run newrun5 = P.AppendChild(new Run());
                        // Add Text to the Run element.
                        newrun5.AppendChild(new Text(strReferenceText.Trim()));
                        if (CommentWithoutTextFound)
                        {
                            CommentWithoutTextFound = false;
                            foreach (var cmt in commentRangeStartText.ToList())
                            {
                                var key = cmt.Key;
                                if (!string.IsNullOrEmpty(key.ToString()))
                                {
                                    P.AppendChild(new CommentRangeStart() { Id = key.ToString() });
                                    RunProperties rpr = new RunProperties(new RunStyle() { Val = "CommentReference" });

                                    P.AppendChild(new Run(new CommentReference() { Id = key.ToString() })).Append(rpr);
                                    P.AppendChild(new CommentRangeEnd() { Id = key.ToString() });
                                    new Run(new CommentReference() { Id = key.ToString() });
                                }
                            }

                        }
                        Run newrund = P.AppendChild(new Run());
                        // Add Text to the Run element.
                        newrund.AppendChild(new Text("</bok>"));
                    }
                    else  //DeveloperName:Priyanka Vishwakarma, Date:26-10-2021, Requiremnt :avoid to remove Ref when ref not identify as jrn, bok or unknown
                    {
                        Run newrunx = P.AppendChild(new Run());
                        // Add Text to the Run element.
                        newrunx.AppendChild(new Text("<unknown>"));

                        Run run3 = new Run(new RunProperties(new RunStyle() { Val = "bibnumber" }));
                        P.AppendChild(run3);
                        // Add Text to the Run element.
                        run3.AppendChild(new Text(nRefNumberCounter.ToString()));

                        Run newrun4 = P.AppendChild(new Run());
                        // Add Text to the Run element.
                        newrun4.AppendChild(new Text(". ") { Space = SpaceProcessingModeValues.Preserve });

                        Run newrun5 = P.AppendChild(new Run());
                        // Add Text to the Run element.
                        newrun5.AppendChild(new Text(strReferenceText.Trim()));
                        if (CommentWithoutTextFound)
                        {
                            CommentWithoutTextFound = false;
                            foreach (var cmt in commentRangeStartText.ToList())
                            {
                                var key = cmt.Key;
                                if (!string.IsNullOrEmpty(key.ToString()))
                                {
                                    P.AppendChild(new CommentRangeStart() { Id = key.ToString() });
                                    RunProperties rpr = new RunProperties(new RunStyle() { Val = "CommentReference" });

                                    P.AppendChild(new Run(new CommentReference() { Id = key.ToString() })).Append(rpr);
                                    P.AppendChild(new CommentRangeEnd() { Id = key.ToString() });
                                    new Run(new CommentReference() { Id = key.ToString() });
                                }
                            }

                        }


                        Run newrund = P.AppendChild(new Run());
                        // Add Text to the Run element.

                        newrund.AppendChild(new Text("</unknown>"));
                    }
                }
                D.Save();
            }
        }
        public static void MarkVolumeIssueFpageLpage(string newDoc)
        {
            var strVolumeIssuePagerangeDBFilename = ConfigurationManager.AppSettings.Get("ListOfVolumeIssuePageRangePatternWithStyles");
            var strRefStructureCol = GlobalMethods.ReadAndStoreFileValuesInArray(strVolumeIssuePagerangeDBFilename);

            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(x => x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val != null && x.ParagraphProperties.ParagraphStyleId.Val.Value == "REF1").ToList())
                {
                    List<Run> allRun = new List<Run>();
                    bool patternMatch = false;
                    if (P.Descendants<Run>().Count() > 0)
                    {
                        if (P.Descendants<Run>().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList().Count() > 0)
                        {
                            var runlist = P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList();
                            if (runlist.Count > 0)
                            {
                                int count = runlist.Count();
                                Run lastrun = P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList().LastOrDefault();
                                string volumeText = "";
                                foreach (var text in runlist.ToList())
                                {
                                    volumeText += text.InnerText;
                                }
                                if (!string.IsNullOrEmpty(volumeText))
                                {
                                    foreach (var strPattern in strRefStructureCol)
                                    {
                                        string pattern = Regex.Split(strPattern, "<S>").FirstOrDefault();
                                        if (Regex.Match(volumeText, pattern).Success)
                                        {
                                            MatchCollection matches = Regex.Matches(volumeText, pattern);

                                            if (matches.Count == 1)
                                            {
                                                if (matches[0].Value.ToString() == volumeText)
                                                {
                                                    patternMatch = true;
                                                    var GroupNumber = Regex.Split(strPattern, "<S>").ToList()[1].Split(',').ToList();
                                                    var StyleList = Regex.Split(strPattern, "<S>").ToList()[2].Split(',').ToList();
                                                    var groups = matches[0].Groups;
                                                    int cnt = groups.Count;
                                                    int grpCnt = 0;
                                                    int styleCnt = 0;

                                                    for (int i = 1; i < cnt; i++)
                                                    {
                                                        grpCnt++;
                                                        if (GroupNumber.Contains(grpCnt.ToString()))
                                                        {
                                                            var val = GroupNumber.ToList().Where(x => x == grpCnt.ToString()).FirstOrDefault();
                                                            var Runstyle = StyleList[styleCnt];
                                                            Run newRun = new Run();
                                                            newRun.RunProperties = new RunProperties(new RunStyle { Val = Runstyle });
                                                            Text newT = new Text() { Text = groups[grpCnt].ToString() };
                                                            newRun.AppendChild(newT);
                                                            allRun.Add(newRun);
                                                            styleCnt++;
                                                        }
                                                        else
                                                        {
                                                            Run newRuntxt = new Run((new Text { Text = groups[grpCnt].ToString().Replace("-", "–").Replace("—", "–"), Space = SpaceProcessingModeValues.Preserve }));
                                                            allRun.Add(newRuntxt);
                                                        }
                                                    }
                                                    if (allRun.Count() > 0)
                                                    {
                                                        foreach (var run in allRun.ToList())
                                                        {
                                                            if (lastrun.Parent != null)
                                                                lastrun.InsertBeforeSelf(run);
                                                        }
                                                    }

                                                    int n = 0;
                                                    foreach (var r in runlist.ToList())
                                                    {
                                                        n++;
                                                        if (n <= count)
                                                        {
                                                            r.Remove();
                                                        }
                                                    }
                                                    break;
                                                }
                                            }
                                        }
                                    }
                                    if (patternMatch == false)
                                    {
                                        foreach (Run run in P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibvolume").ToList())
                                        {
                                            run.RunProperties = null;

                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                D.Save();
            }
        }
        public static void MarkSurnameFname(string newDoc)
        {
            var strSurnameFnameFilename = ConfigurationManager.AppSettings.Get("ListOfSunameFnamePattern");
            var strRefStructureCol = GlobalMethods.ReadAndStoreFileValuesInArray(strSurnameFnameFilename);

            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(x => x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val != null && x.ParagraphProperties.ParagraphStyleId.Val.Value == "REF1").ToList())
                {
                    List<Run> allRun = new List<Run>();
                    bool patternMatch = false;
                    if (P.Descendants<Run>().Count() > 0)
                    {
                        if (P.Descendants<Run>().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibsurname").ToList().Count() > 0)
                        {
                            var runlist = P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibsurname").ToList();
                            if (runlist.Count > 0)
                            {
                                int count = runlist.Count();
                                foreach (var surnamerun in runlist)
                                {
                                    allRun = new List<Run>();
                                    string volumeText = "";
                                    //foreach (var text in surnamerun.ToList())
                                    //{
                                    //    volumeText += text.InnerText;
                                    //}

                                    volumeText = surnamerun.InnerText;
                                    if (!string.IsNullOrEmpty(volumeText))
                                    {
                                        foreach (var strPattern in strRefStructureCol)
                                        {
                                            string pattern = Regex.Split(strPattern, "<S>").FirstOrDefault();
                                            if (Regex.Match(volumeText, pattern).Success)
                                            {
                                                MatchCollection matches = Regex.Matches(volumeText, pattern);

                                                if (matches.Count == 1)
                                                {
                                                    if (matches[0].Value.ToString() == volumeText)
                                                    {
                                                        patternMatch = true;
                                                        var GroupNumber = Regex.Split(strPattern, "<S>").ToList()[1].Split(',').ToList();
                                                        var StyleList = Regex.Split(strPattern, "<S>").ToList()[2].Split(',').ToList();
                                                        var groups = matches[0].Groups;
                                                        int cnt = groups.Count;
                                                        int grpCnt = 0;
                                                        int styleCnt = 0;

                                                        for (int i = 1; i < cnt; i++)
                                                        {
                                                            grpCnt++;
                                                            if (GroupNumber.Contains(grpCnt.ToString()))
                                                            {
                                                                var val = GroupNumber.ToList().Where(x => x == grpCnt.ToString()).FirstOrDefault();
                                                                var Runstyle = StyleList[styleCnt];
                                                                Run newRun = new Run();
                                                                newRun.RunProperties = new RunProperties(new RunStyle { Val = Runstyle });
                                                                Text newT = new Text() { Text = groups[grpCnt].ToString() };
                                                                newRun.AppendChild(newT);
                                                                allRun.Add(newRun);
                                                                styleCnt++;
                                                            }
                                                            else
                                                            {
                                                                Run newRuntxt = new Run((new Text { Text = groups[grpCnt].ToString(), Space = SpaceProcessingModeValues.Preserve }));
                                                                allRun.Add(newRuntxt);
                                                            }
                                                        }
                                                        if (allRun.Count() > 0)
                                                        {
                                                            foreach (var run in allRun.ToList())
                                                            {
                                                                if (surnamerun.Parent != null)
                                                                    surnamerun.InsertBeforeSelf(run);
                                                            }
                                                        }

                                                        //int n = 0;
                                                        //foreach (var r in surnamerun.ToList())
                                                        //{
                                                        //    n++;
                                                        //    if (n <= count)
                                                        //    {
                                                        //        r.Remove();
                                                        //    }
                                                        //}
                                                        surnamerun.Remove();
                                                        break;
                                                    }
                                                }
                                            }
                                        }

                                        if (patternMatch == false)
                                        {
                                            foreach (Run run in P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibsurname").ToList())
                                            {
                                                run.RunProperties = null;

                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                D.Save();
            }
        }

        public static void applyetalJaypee(string newDoc)
        {
            bool bParaHasStructuredRef = false;

            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(x => x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val != null && x.ParagraphProperties.ParagraphStyleId.Val.Value == "REF1").ToList())
                {
                    if (Regex.Match(P.InnerText, @"(\set al\.)").Success)
                    {
                        if (P.Descendants<Run>().Count() > 0)
                        {

                            if (P.Descendants<Run>().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibetal").ToList().Count() > 0)
                            {
                                var runlist = P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "bibetal").ToList();

                                foreach (Run run in runlist.ToList())
                                {
                                    if (run.InnerText.Trim().Contains("et al."))
                                    {
                                        Run runtxt1 = new Run((new Text { Text = " ", Space = SpaceProcessingModeValues.Preserve }));
                                        run.InsertBeforeSelf(runtxt1);

                                        Run newbibrtal = new Run();
                                        newbibrtal.RunProperties = new RunProperties(new RunStyle { Val = "bibetal" });
                                        Text newTbibetal = new Text() { Text = "et al" };
                                        newbibrtal.AppendChild(newTbibetal);
                                        run.InsertBeforeSelf(newbibrtal);

                                        Run runtxt2 = new Run((new Text { Text = ". ", Space = SpaceProcessingModeValues.Preserve }));
                                        run.InsertBeforeSelf(runtxt2);
                                        run.Remove();
                                    }
                                    else
                                    {
                                        run.RunProperties = null;
                                    }
                                }
                            }


                        }

                    }

                }


                D.Save();
            }
        }
        public static void MarkArticleAndJournalTitle(string newDoc)
        {
            bool CheckedForbibjournal = false;
            bool CheckedForsurnameStart = false;
            string articletext = "";

            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(x => x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val != null && x.ParagraphProperties.ParagraphStyleId.Val.Value == "REF1").ToList())
                {
                    CheckedForbibjournal = false;
                    CheckedForsurnameStart = false;
                    articletext = "";

                    if (P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val != null && x.RunProperties.RunStyle.Val.Value == "bibsurname").ToList().Count() > 0 && P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val != null && x.RunProperties.RunStyle.Val.Value == "bibfname").ToList().Count() > 0 && P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val != null && x.RunProperties.RunStyle.Val.Value == "bibyear").ToList().Count() > 0)
                    {
                        List<Run> allRun = new List<Run>();
                        bool patternMatch = false;
                        foreach (Run run in P.Descendants<Run>().ToList())
                        {
                            if (run.RunProperties != null && run.RunProperties.RunStyle != null && run.RunProperties.RunStyle.Val != null && (run.RunProperties.RunStyle.Val.Value == "bibsurname" || run.RunProperties.RunStyle.Val.Value == "bibfname" || run.RunProperties.RunStyle.Val.Value == "bibetal"))
                            {
                                CheckedForsurnameStart = true;
                                continue;
                            }
                            else if (run.RunProperties != null && run.RunProperties.RunStyle != null && run.RunProperties.RunStyle.Val != null && run.RunProperties.RunStyle.Val.Value == "bibyear")
                            {
                                CheckedForbibjournal = true;
                                goto NextPara;
                            }
                            else if (CheckedForbibjournal == true)
                            {
                                break;
                            }
                            else
                            {
                                if (CheckedForsurnameStart && run.InnerText.Trim() != "." && run.InnerText.Trim() != "," && run.InnerText.Trim() != ";" && run.InnerText.Trim() != "")
                                {
                                    string pattern = Regex.Split(@"(\s)([^.]+)([\.?\s]+)([a-z A-Z.\-]+)([,.\s]+)<S>1,2,3,4,5<S>value,bibarticle,value,bibjournal,value", "<S>").FirstOrDefault(); //Developer Name: Priyanka Vishwakarma, Date:2-12-2021, Requirement: add new pattern for mark article titile and journal title.
                                    if (Regex.Match(run.InnerText, pattern).Success)
                                    {
                                        MatchCollection matches = Regex.Matches(run.InnerText, pattern);

                                        if (matches.Count == 1)
                                        {
                                            if (matches[0].Value.ToString() == run.InnerText)
                                            {
                                                patternMatch = true;
                                                var GroupNumber = Regex.Split(@"(\s)([^.]+)([\.?\s]+)([a-z A-Z.\-]+)([,.\s]+)<S>1,2,3,4,5<S>value,bibarticle,value,bibjournal,value", "<S>").ToList()[1].Split(',').ToList();
                                                var StyleList = Regex.Split(@"(\s)([^.]+)([\.?\s]+)([a-z A-Z.\-]+)([,.\s]+)<S>1,2,3,4,5<S>value,bibarticle,value,bibjournal,value", "<S>").ToList()[2].Split(',').ToList();
                                                var groups = matches[0].Groups;
                                                int cnt = groups.Count;
                                                int grpCnt = 0;
                                                int styleCnt = 0;

                                                for (int i = 1; i < cnt; i++)
                                                {
                                                    grpCnt++;
                                                    if (GroupNumber.Contains(grpCnt.ToString()))
                                                    {
                                                        var val = GroupNumber.ToList().Where(x => x == grpCnt.ToString()).FirstOrDefault();
                                                        var Runstyle = StyleList[styleCnt];
                                                        Run newRun = new Run();
                                                        if (Runstyle != "value")
                                                        {
                                                            newRun.RunProperties = new RunProperties(new RunStyle { Val = Runstyle });
                                                        }
                                                        Text newT = new Text() { Text = groups[grpCnt].ToString(), Space = SpaceProcessingModeValues.Preserve };
                                                        newRun.AppendChild(newT);
                                                        allRun.Add(newRun);
                                                        styleCnt++;
                                                    }
                                                    else
                                                    {
                                                        Run newRuntxt = new Run((new Text { Text = groups[grpCnt].ToString(), Space = SpaceProcessingModeValues.Preserve }));
                                                        allRun.Add(newRuntxt);
                                                    }
                                                }
                                                if (allRun.Count() > 0)
                                                {
                                                    foreach (var run1 in allRun.ToList())
                                                    {
                                                        if (run.Parent != null)
                                                            run.InsertBeforeSelf(run1);
                                                    }
                                                }
                                                run.Remove();
                                                break;
                                            }
                                        }
                                    }
                                }
                            }
                        }

                    NextPara: { }
                    }

                NextParagraphStyle: { }

                }
                D.Save();
            }
        }
        public static void RemovePMIDandPMCIDText(string newDoc)
        {
            bool bParaHasStructuredRef = false;

            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(x => x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val != null && x.ParagraphProperties.ParagraphStyleId.Val.Value == "REF1").ToList())
                {

                    if (P.Descendants<Run>().Count() > 0 && P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val != null && x.RunProperties.RunStyle.Val.Value == "bibpmid").Count() > 0)
                    {
                        var pmidRun = P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val != null && x.RunProperties.RunStyle.Val.Value == "bibpmid").ToList();
                        if (pmidRun.Count() > 0 && pmidRun.Count() == 1)
                        {
                            var runtext = pmidRun.FirstOrDefault().Descendants<Text>().ToList();
                            foreach (var text in runtext.ToList())
                            {
                                if (text.Text.Contains("PMID: "))
                                {
                                    Run r1 = new Run();
                                    Text t1 = new Text("PMID: ");
                                    r1.AppendChild(t1);
                                    Run spacerun = new Run();
                                    spacerun.AppendChild(new Text(" ") { Space = SpaceProcessingModeValues.Preserve });
                                    text.Text = text.Text.Replace("PMID: ", "");
                                    pmidRun.FirstOrDefault().InsertBeforeSelf(r1);
                                    pmidRun.FirstOrDefault().InsertBeforeSelf(spacerun);
                                }
                            }
                        }
                    }
                    if (P.Descendants<Run>().Count() > 0 && P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val != null && x.RunProperties.RunStyle.Val.Value == "bibpmcid").Count() > 0)
                    {
                        var pmidRun = P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val != null && x.RunProperties.RunStyle.Val.Value == "bibpmcid").ToList();
                        if (pmidRun.Count() > 0 && pmidRun.Count() == 1)
                        {
                            var runtext = pmidRun.FirstOrDefault().Descendants<Text>().ToList();
                            foreach (var text in runtext.ToList())
                            {
                                if (text.Text.Contains("PMCID: "))
                                {
                                    Run r1 = new Run();
                                    Text t1 = new Text("PMCID: ");
                                    r1.AppendChild(t1);
                                    Run spacerun = new Run();
                                    spacerun.AppendChild(new Text(" ") { Space = SpaceProcessingModeValues.Preserve });
                                    text.Text = text.Text.Replace("PMCID: ", "");
                                    pmidRun.FirstOrDefault().InsertBeforeSelf(r1);
                                    pmidRun.FirstOrDefault().InsertBeforeSelf(spacerun);
                                }
                            }
                        }
                    }
                }

                D.Save();
            }
        }
        public static void ApplybibArticleinJrnRefInJaypee(string newDoc)
        {
            bool CheckedForbibjournal = false;
            bool CheckedForsurnameStart = false;
            string articletext = "";

            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(x => x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val != null && x.ParagraphProperties.ParagraphStyleId.Val.Value == "REF1").ToList())
                {
                    CheckedForbibjournal = false;
                    CheckedForsurnameStart = false;
                    articletext = "";
                    if (P.InnerText.Trim().StartsWith("<jrn>"))
                    {
                        if (P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val != null && x.RunProperties.RunStyle.Val.Value == "bibsurname").ToList().Count() > 0 && P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val != null && x.RunProperties.RunStyle.Val.Value == "bibfname").ToList().Count() > 0 && P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val != null && x.RunProperties.RunStyle.Val.Value == "bibjournal").ToList().Count() > 0)
                        {
                            foreach (Run run in P.Descendants<Run>().ToList())
                            {
                                if (run.RunProperties != null && run.RunProperties.RunStyle != null && run.RunProperties.RunStyle.Val != null && (run.RunProperties.RunStyle.Val.Value == "bibsurname" || run.RunProperties.RunStyle.Val.Value == "bibfname" || run.RunProperties.RunStyle.Val.Value == "bibetal"))
                                {
                                    CheckedForsurnameStart = true;
                                    continue;
                                }
                                else if (run.RunProperties != null && run.RunProperties.RunStyle != null && run.RunProperties.RunStyle.Val != null && run.RunProperties.RunStyle.Val.Value == "bibjournal")
                                {
                                    CheckedForbibjournal = true;
                                    goto NextPara;
                                }
                                else if (CheckedForbibjournal == true)
                                {
                                    break;
                                }
                                else
                                {
                                    if (CheckedForsurnameStart && run.InnerText.Trim() != "." && run.InnerText.Trim() != "," && run.InnerText.Trim() != ";" && run.InnerText.Trim() != "")
                                    {
                                        var text1 = GlobalMethods.DocumentRegEx(run.InnerText, @"(\.)\s{1,}([A-Za-z0-9\/\:\–\s\-\'\'\?\,\(\)\‐\“\”\%]+)(\.)").FirstOrDefault();
                                        var text2 = GlobalMethods.DocumentRegEx(run.InnerText, @"(\,)\s{1,}([A-Za-z0-9\/\:\–\s\-\'\'\?\,\(\)\‐\“\”\%]+)(\.)").FirstOrDefault();
                                        var text3 = GlobalMethods.DocumentRegEx(run.InnerText, @"(\.)\s{1,}([A-Za-z0-9\/\:\–\s\-\'\'\?\,\(\)\‐\“\”\%]+)(\?)").FirstOrDefault();
                                        var text4 = GlobalMethods.DocumentRegEx(run.InnerText, @"(\,)\s{1,}([A-Za-z0-9\/\:\–\s\-\'\'\?\,\(\)\‐\“\”\%]+)(\?)").FirstOrDefault();
                                        if (text1 != null)
                                        {
                                            var values = run.InnerText.Split('.').ToList();

                                            if (values.Count() == 3 && values[2].Trim() == "")
                                            {
                                                Run runtxt1 = new Run((new Text { Text = values[0] + ". ", Space = SpaceProcessingModeValues.Preserve }));


                                                Run newRun = new Run();
                                                newRun.RunProperties = new RunProperties(new RunStyle { Val = "bibarticle" });
                                                Text newText = new Text() { Text = values[1] };
                                                newRun.AppendChild(newText);

                                                run.InsertBeforeSelf(runtxt1);
                                                run.InsertBeforeSelf(newRun);
                                                Run runtxt2 = new Run((new Text { Text = ". ", Space = SpaceProcessingModeValues.Preserve }));
                                                run.InsertBeforeSelf(runtxt2);
                                                run.Remove();
                                                goto NextParagraphStyle;

                                            }


                                        }
                                        else if (text2 != null)
                                        {
                                            var values = Regex.Split(run.InnerText, @"[\.\,]+").ToList();

                                            if (values.Count() == 3 && values[2].Trim() == "")
                                            {
                                                Run runtxt1 = new Run((new Text { Text = values[0] + ", ", Space = SpaceProcessingModeValues.Preserve }));


                                                Run newRun = new Run();
                                                newRun.RunProperties = new RunProperties(new RunStyle { Val = "bibarticle" });
                                                Text newText = new Text() { Text = values[1] };
                                                newRun.AppendChild(newText);

                                                run.InsertBeforeSelf(runtxt1);
                                                run.InsertBeforeSelf(newRun);
                                                Run runtxt2 = new Run((new Text { Text = ". ", Space = SpaceProcessingModeValues.Preserve }));
                                                run.InsertBeforeSelf(runtxt2);
                                                run.Remove();
                                                goto NextParagraphStyle;

                                            }


                                        }
                                        else if (text3 != null)
                                        {
                                            var values = Regex.Split(run.InnerText, @"[\.\?]+").ToList();

                                            if (values.Count() == 3 && values[2].Trim() == "")
                                            {
                                                Run runtxt1 = new Run((new Text { Text = values[0] + ". ", Space = SpaceProcessingModeValues.Preserve }));


                                                Run newRun = new Run();
                                                newRun.RunProperties = new RunProperties(new RunStyle { Val = "bibarticle" });
                                                Text newText = new Text() { Text = values[1] + "?" };
                                                newRun.AppendChild(newText);

                                                run.InsertBeforeSelf(runtxt1);
                                                run.InsertBeforeSelf(newRun);
                                                Run runtxt2 = new Run((new Text { Text = " ", Space = SpaceProcessingModeValues.Preserve }));
                                                run.InsertBeforeSelf(runtxt2);
                                                run.Remove();
                                                goto NextParagraphStyle;

                                            }


                                        }
                                        else if (text4 != null)
                                        {
                                            var values = Regex.Split(run.InnerText, @"[\,\?]+").ToList();

                                            if (values.Count() == 3 && values[2].Trim() == "")
                                            {
                                                Run runtxt1 = new Run((new Text { Text = values[0] + ", ", Space = SpaceProcessingModeValues.Preserve }));


                                                Run newRun = new Run();
                                                newRun.RunProperties = new RunProperties(new RunStyle { Val = "bibarticle" });
                                                Text newText = new Text() { Text = values[1] + "?" };
                                                newRun.AppendChild(newText);

                                                run.InsertBeforeSelf(runtxt1);
                                                run.InsertBeforeSelf(newRun);
                                                Run runtxt2 = new Run((new Text { Text = " ", Space = SpaceProcessingModeValues.Preserve }));
                                                run.InsertBeforeSelf(runtxt2);
                                                run.Remove();
                                                goto NextParagraphStyle;

                                            }


                                        }

                                    }
                                }


                            }
                        }
                    NextPara: { }
                    }

                NextParagraphStyle: { }

                }
                D.Save();
            }
        }
        private static void MarkCitationsInDocumentForJypee(string strWordDoc)
        {
            try
            {
                // Reference Renumbering //

                List<string> strRefNumColl = new List<string>();

                using (WordprocessingDocument WPD = WordprocessingDocument
                    .Open(strWordDoc, true))
                {
                    SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                    {
                        RemoveComments = false,
                        RemoveContentControls = true,
                        RemoveEndAndFootNotes = false,
                        RemoveFieldCodes = true,
                        RemoveLastRenderedPageBreak = true,
                        RemovePermissions = true,
                        RemoveProof = true,
                        RemoveRsidInfo = true,
                        RemoveSmartTags = true,
                        RemoveSoftHyphens = false,
                        ReplaceTabsWithSpaces = false,//Developer name :Priyanka Vishwakarma. Date:29_5_2019, Requirement:it removes the indentation from the nested list  ,Integrated By:Vikas sir. 
                    };

                    MarkupSimplifier.SimplifyMarkup(WPD, settings);

                    MainDocumentPart MDP = WPD.MainDocumentPart;

                    Document D = MDP.Document;

                    //string strRefNum = "";
                    bool bRefNumberStart = false;
                    //int nRefNum = 0;

                    int nRefIndex = 0;

                    strRefNumColl.Clear();

                    // Search all Paragraphs that is "TOC1 to TOC3" style.
                    foreach (Paragraph P in D.Descendants<Paragraph>().ToList().
                    Where(e => e.ParagraphProperties != null
                        && e.ParagraphProperties.ParagraphStyleId != null
                        && e.ParagraphProperties.ParagraphStyleId.Val == "REF1"))
                    {
                        if (P.HasChildren)
                        {
                            if (P.Descendants<Run>().Count() > 0)
                            {
                                foreach (Run R in P.Descendants<Run>().ToList())
                                {
                                    if (R.RunProperties != null)
                                    {
                                        if (R.RunProperties.RunStyle != null)
                                        {
                                            if (R.RunProperties.RunStyle.Val == "bibnumber")
                                            {
                                                bRefNumberStart = true;
                                                nRefIndex++;
                                            }
                                            else
                                            {
                                                bRefNumberStart = false;
                                            }
                                        }
                                    }
                                    foreach (Text T in R.Descendants<Text>().ToList())
                                    {
                                        if (bRefNumberStart)
                                        {
                                            if (T.Text != ".")
                                            {
                                                strRefNumColl.Add(T.Text);
                                                bRefNumberStart = false;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Compare the Reference Number with Reference Citation //



                    bool bRefCiteStart = false;

                    //foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                    foreach (Paragraph P in D.Descendants<Paragraph>().ToList().
                 Where(e => e.ParagraphProperties != null
                     && e.ParagraphProperties.ParagraphStyleId != null
                     && e.ParagraphProperties.ParagraphStyleId.Val != "REF1"
                     && e.ParagraphProperties.ParagraphStyleId.Val != "AFFL"
                     && e.ParagraphProperties.ParagraphStyleId.Val != "AU"
                     && e.ParagraphProperties.ParagraphStyleId.Val != "CORR"
                     && e.ParagraphProperties.ParagraphStyleId.Val != "UID"))
                    {
                        if (P.HasChildren)
                        {
                            if (P.Descendants<Run>().Count() > 0 && (GlobalMethods.strRefNum != null && GlobalMethods.strRefNum != "UnNumbered"))/////GlobalMethods.strRefNum and bRefNumberStart condition added by vikas on 15-07-2020
                            {

                                foreach (Run R in P.Descendants<Run>().ToList().Where(k => k.RunProperties != null && k.RunProperties.VerticalTextAlignment != null).ToList())
                                {
                                    if (R.RunProperties != null)
                                    {
                                        if (R.RunProperties.VerticalTextAlignment != null)
                                        {
                                            if (R.RunProperties.VerticalTextAlignment.Val == "superscript" && !string.IsNullOrEmpty(R.InnerText.Trim()))  //Developer Name:Priyanka Vishwakarma , Date:10072019 ,Requirement :apply citebib character style to text because of run property contains space with superscript in docx(2289_THI_J_EJD-19-00116.docx)
                                            {
                                                bRefCiteStart = true;
                                            }

                                        }
                                        if (R.RunProperties.RunStyle != null)
                                        {
                                            if (R.RunProperties.RunStyle.Val == "citebib")
                                            {
                                                bRefCiteStart = false;
                                            }
                                        }
                                    }
                                    foreach (Text T in R.Descendants<Text>().ToList())
                                    {
                                        bool bCiteNumExistInRef = false;

                                        //============================ Modified Citaton Marking start ===========================//

                                        if (bRefCiteStart)
                                        {
                                            //check if text has comma or dash

                                            if (T.Text.Contains(",") || T.Text.Contains("-") || T.Text.Contains("–"))//////added by vikas for – on 22-09-2019
                                            {
                                                string getallsup = T.Text;

                                                string[] getsinglesup = getallsup.Split(',', '-', '–');

                                                if (T.Text.Trim() == ",")
                                                {
                                                    Run run = new Run(new RunProperties(new VerticalTextAlignment() { Val = VerticalPositionValues.Superscript }, new RunStyle() { Val = "citebib" }));
                                                    Text text1 = new Text(T.Text);
                                                    run.AppendChild(text1);
                                                    R.InsertBeforeSelf(run);
                                                    R.Remove();
                                                    bRefCiteStart = false;
                                                    goto nextRun;
                                                }

                                                for (int i = 0; i < getsinglesup.Count(); i++)
                                                {
                                                    if (strRefNumColl.Contains(getsinglesup[i]))
                                                    {

                                                        if (strRefNumColl.Contains(getsinglesup[i]))
                                                        {
                                                            bCiteNumExistInRef = true;
                                                        }
                                                        else
                                                        {
                                                            bCiteNumExistInRef = false;
                                                        }

                                                        if (bCiteNumExistInRef)
                                                        {
                                                            if (R.RunProperties != null)
                                                            {
                                                                if (R.RunProperties.RunStyle != null)
                                                                {
                                                                    R.RunProperties.RunStyle.Val = "citebib";
                                                                    bRefCiteStart = false;

                                                                }
                                                                else
                                                                {
                                                                    Run run = new Run(new RunProperties(new VerticalTextAlignment() { Val = VerticalPositionValues.Superscript }, new RunStyle() { Val = "citebib" }));
                                                                    Text text1 = new Text(T.Text);
                                                                    run.AppendChild(text1);
                                                                    R.InsertBeforeSelf(run);
                                                                    R.Remove();
                                                                    bRefCiteStart = false;
                                                                    break;

                                                                }
                                                            }
                                                            else
                                                            {
                                                                Run run = new Run(new RunProperties(new RunStyle() { Val = "citebib" }));
                                                                R.Append(run);
                                                                bRefCiteStart = false;

                                                            }
                                                        }
                                                        else
                                                        {
                                                            bRefCiteStart = false;
                                                        }

                                                    }
                                                }
                                            nextRun: { }
                                                bRefCiteStart = false;
                                            }
                                            else
                                            {
                                                if (strRefNumColl.Contains(T.Text.Trim()))
                                                {
                                                    Run run = new Run(new RunProperties(new VerticalTextAlignment() { Val = VerticalPositionValues.Superscript }, new RunStyle() { Val = "citebib" }));
                                                    Text text1 = new Text(T.Text);
                                                    run.AppendChild(text1);
                                                    R.InsertBeforeSelf(run);
                                                    R.Remove();
                                                    bRefCiteStart = false;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    D.Save();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public static void RemoveJournalTitle(string newDoc)
        {
            bool bibyearStart = false;
            bool FirstbibyearFound = false;

            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(x => x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val != null && x.ParagraphProperties.ParagraphStyleId.Val.Value == "REF1").ToList())
                {
                    bibyearStart = false;
                    FirstbibyearFound = false;
                    if (P.Descendants<Run>().Count() > 0)
                    {
                        if (P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val != null && x.RunProperties.RunStyle.Val.Value == "bibjournal").ToList().Count() > 1)
                        {
                            var JournalTitleRun = P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val != null && x.RunProperties.RunStyle.Val.Value == "bibjournal").ToList().SkipLast(1).ToList();
                            foreach (var run in JournalTitleRun.ToList())
                            {
                                run.RunProperties = null;
                            }
                        }
                    }
                }

                D.Save();
            }
        }
        public static void ApplybibArticleinJrnRefInJaypeeWhenAuthorMissing(string newDoc)
        {
            bool CheckedForbibjournal = false;
            bool CheckedForsurnameStart = false;
            string articletext = "";

            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(x => x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val != null && x.ParagraphProperties.ParagraphStyleId.Val.Value == "REF1").ToList())
                {
                    CheckedForbibjournal = false;
                    CheckedForsurnameStart = false;
                    articletext = "";
                    if (P.InnerText.Trim().StartsWith("<jrn>"))
                    {

                        if (P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val != null && x.RunProperties.RunStyle.Val.Value == "bibjournal").ToList().Count() > 0 && P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val != null && x.RunProperties.RunStyle.Val.Value == "bibfname").ToList().Count() == 0 && P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val != null && x.RunProperties.RunStyle.Val.Value == "bibsurname").ToList().Count() == 0 && P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val != null && x.RunProperties.RunStyle.Val.Value == "bibetal").ToList().Count() == 0)
                        {
                            foreach (Run run in P.Descendants<Run>().ToList())
                            {
                                if (run.RunProperties != null && run.RunProperties.RunStyle != null && run.RunProperties.RunStyle.Val != null && run.RunProperties.RunStyle.Val.Value == "bibnumber")
                                {
                                    CheckedForsurnameStart = true;
                                    continue;
                                }
                                else if (run.RunProperties != null && run.RunProperties.RunStyle != null && run.RunProperties.RunStyle.Val != null && run.RunProperties.RunStyle.Val.Value == "bibjournal")
                                {
                                    CheckedForbibjournal = true;
                                    goto NextPara;
                                }
                                else if (CheckedForbibjournal == true)
                                {
                                    break;
                                }
                                else
                                {
                                    if (CheckedForsurnameStart && run.InnerText.Trim() != "." && run.InnerText.Trim() != "," && run.InnerText.Trim() != ";" && run.InnerText.Trim() != "")
                                    {
                                        var text1 = GlobalMethods.DocumentRegEx(run.InnerText, @"(\.)\s{1,}([A-Za-z0-9\/\:\–\s\-\'\'\?\,\(\)\‐\“\”\%]+)(\.)").FirstOrDefault();
                                        var text2 = GlobalMethods.DocumentRegEx(run.InnerText, @"(\,)\s{1,}([A-Za-z0-9\/\:\–\s\-\'\'\?\,\(\)\‐\“\”\%]+)(\.)").FirstOrDefault();
                                        var text3 = GlobalMethods.DocumentRegEx(run.InnerText, @"(\.)\s{1,}([A-Za-z0-9\/\:\–\s\-\'\'\?\,\(\)\‐\“\”\%]+)(\?)").FirstOrDefault();
                                        var text4 = GlobalMethods.DocumentRegEx(run.InnerText, @"(\,)\s{1,}([A-Za-z0-9\/\:\–\s\-\'\'\?\,\(\)\‐\“\”\%]+)(\?)").FirstOrDefault();
                                        if (text1 != null)
                                        {
                                            var values = run.InnerText.Split('.').ToList();

                                            if (values.Count() == 3 && values[2].Trim() == "")
                                            {
                                                Run runtxt1 = new Run((new Text { Text = values[0] + ". ", Space = SpaceProcessingModeValues.Preserve }));


                                                Run newRun = new Run();
                                                newRun.RunProperties = new RunProperties(new RunStyle { Val = "bibarticle" });
                                                Text newText = new Text() { Text = values[1] };
                                                newRun.AppendChild(newText);

                                                run.InsertBeforeSelf(runtxt1);
                                                run.InsertBeforeSelf(newRun);
                                                Run runtxt2 = new Run((new Text { Text = ". ", Space = SpaceProcessingModeValues.Preserve }));
                                                run.InsertBeforeSelf(runtxt2);
                                                run.Remove();
                                                goto NextParagraphStyle;

                                            }


                                        }
                                        else if (text2 != null)
                                        {
                                            var values = Regex.Split(run.InnerText, @"[\.\,]+").ToList();

                                            if (values.Count() == 3 && values[2].Trim() == "")
                                            {
                                                Run runtxt1 = new Run((new Text { Text = values[0] + ", ", Space = SpaceProcessingModeValues.Preserve }));


                                                Run newRun = new Run();
                                                newRun.RunProperties = new RunProperties(new RunStyle { Val = "bibarticle" });
                                                Text newText = new Text() { Text = values[1] };
                                                newRun.AppendChild(newText);

                                                run.InsertBeforeSelf(runtxt1);
                                                run.InsertBeforeSelf(newRun);
                                                Run runtxt2 = new Run((new Text { Text = ". ", Space = SpaceProcessingModeValues.Preserve }));
                                                run.InsertBeforeSelf(runtxt2);
                                                run.Remove();
                                                goto NextParagraphStyle;

                                            }


                                        }
                                        else if (text3 != null)
                                        {
                                            var values = Regex.Split(run.InnerText, @"[\.\?]+").ToList();

                                            if (values.Count() == 3 && values[2].Trim() == "")
                                            {
                                                Run runtxt1 = new Run((new Text { Text = values[0] + ". ", Space = SpaceProcessingModeValues.Preserve }));


                                                Run newRun = new Run();
                                                newRun.RunProperties = new RunProperties(new RunStyle { Val = "bibarticle" });
                                                Text newText = new Text() { Text = values[1] + "?" };
                                                newRun.AppendChild(newText);

                                                run.InsertBeforeSelf(runtxt1);
                                                run.InsertBeforeSelf(newRun);
                                                Run runtxt2 = new Run((new Text { Text = " ", Space = SpaceProcessingModeValues.Preserve }));
                                                run.InsertBeforeSelf(runtxt2);
                                                run.Remove();
                                                goto NextParagraphStyle;

                                            }


                                        }
                                        else if (text4 != null)
                                        {
                                            var values = Regex.Split(run.InnerText, @"[\,\?]+").ToList();

                                            if (values.Count() == 3 && values[2].Trim() == "")
                                            {
                                                Run runtxt1 = new Run((new Text { Text = values[0] + ", ", Space = SpaceProcessingModeValues.Preserve }));


                                                Run newRun = new Run();
                                                newRun.RunProperties = new RunProperties(new RunStyle { Val = "bibarticle" });
                                                Text newText = new Text() { Text = values[1] + "?" };
                                                newRun.AppendChild(newText);

                                                run.InsertBeforeSelf(runtxt1);
                                                run.InsertBeforeSelf(newRun);
                                                Run runtxt2 = new Run((new Text { Text = " ", Space = SpaceProcessingModeValues.Preserve }));
                                                run.InsertBeforeSelf(runtxt2);
                                                run.Remove();
                                                goto NextParagraphStyle;

                                            }


                                        }

                                    }
                                }


                            }
                        }
                    NextPara: { }
                    }

                NextParagraphStyle: { }

                }
                D.Save();
            }
        }


    }
}
