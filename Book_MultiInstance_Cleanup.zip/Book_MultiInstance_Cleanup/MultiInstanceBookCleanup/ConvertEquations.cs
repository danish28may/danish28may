﻿using Ionic.Zip;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MultiInstanceBookCleanup
{
    class ConvertEquations
    {
        public static void EquationsConvertion(string strDocPath)
        {
            ExtractWord(strDocPath);

            System.Threading.Thread.Sleep(500);

            FileInfo sourceDoc = new FileInfo(strDocPath);

            Process pr = new Process();
            pr.StartInfo.Arguments = sourceDoc.DirectoryName + " TXT" + " " + GlobalMethods.ChapterNumber ;
            pr.StartInfo.FileName = "ConvertEquations.exe";
            pr.StartInfo.WindowStyle = ProcessWindowStyle.Normal;
            pr.Start();
            pr.WaitForExit();

            // Check if any Image and text file exist in the folder //
            string strFormula = "";

            if (sourceDoc.DirectoryName.EndsWith("\\") == false)
                strFormula = sourceDoc.DirectoryName + "\\";

            strFormula = strFormula + "formulas";

            if (Directory.Exists(strFormula) == false)
                return;

            // Check the files in the folder and move the files on server path //

            string[] filePaths = Directory.GetFiles(strFormula);
            string strServerEquationFolderPath = "";

            if(GlobalMethods.ChapterImagePath != "")
            {
                strServerEquationFolderPath = GlobalMethods.ChapterImagePath;

                if (strServerEquationFolderPath.EndsWith("\\") == false)
                    strServerEquationFolderPath = strServerEquationFolderPath + "\\";

                strServerEquationFolderPath = strServerEquationFolderPath + "Equations";

                if(Directory.Exists(strServerEquationFolderPath)==false)
                {
                    Directory.CreateDirectory(strServerEquationFolderPath);
                }
            }

            foreach (string file in filePaths)
            {
                FileInfo ff = new FileInfo(file);

                File.Copy(ff.FullName, strServerEquationFolderPath + "\\" + ff.Name, true);

                ff.Delete();
            }

            DeletePreviousImages(strFormula);
        }

        private static void ExtractWord(string templatePath)
        {
            var sourceDoc = new FileInfo(templatePath);
            var sourcePath = sourceDoc.DirectoryName;

            using (ZipFile template = ZipFile.Read(templatePath))
            {
                //template.ExtractAll(("Temp_Files"), ExtractExistingFileAction.OverwriteSilently);

                template.ExtractAll((sourcePath + "\\Temp_Files"), ExtractExistingFileAction.OverwriteSilently);
            }
        }

        private static void DeletePreviousImages(string imgPath)
        {
            var sourceDoc = new FileInfo(imgPath);
            var dir = new DirectoryInfo(sourceDoc.FullName + "\\Temp_Files");

            System.Threading.Thread.Sleep(500);

            if (dir.Exists)
                dir.Delete(true);
        }
    }
}
