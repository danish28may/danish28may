﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MultiInstanceBookCleanup
{
    class Program
    {
        static void Main(string[] args)
        {
            //string filepath = @"C:\3CMAutomation\BooksCleanupMarkup\Process\34893";

            string filepath = args[0];
            
            try
            {
              Start(filepath);

                //string dirPath = @"C:\3ClicksMaster\Processing\publishing\Generic\Indesign\In";////For delete file if it exist longer than 5 min 
                //foreach (string file in Directory.GetFiles(dirPath))
                //{
                //    FileInfo fi = new FileInfo(file);
                //    if (fi.CreationTime < DateTime.Now.AddMinutes(-5))
                //        fi.Delete();
                //}

            }
            catch (Exception ex)
            {
                string folderpath = filepath.Substring(filepath.LastIndexOf("\\"));

                //folderpath = folderpath.Substring(folderpath.LastIndexOf("\\"));

                string strErrorFileName = null;
                string strProcessFolder = null;

                if (GlobalMethods.StrOutFolder != null || GlobalMethods.StrOutFolder != "")
                {
                    strErrorFileName = GlobalMethods.StrOutFolder;
                    if (folderpath.StartsWith("\\"))
                        strErrorFileName = strErrorFileName + folderpath;
                    else
                        strErrorFileName = strErrorFileName + "\\" + folderpath;

                    if (Directory.Exists(strErrorFileName) == false)
                        Directory.CreateDirectory(strErrorFileName);

                    if (strErrorFileName.EndsWith("\\") == false)
                        strErrorFileName = strErrorFileName + "\\";

                    strErrorFileName = strErrorFileName + "Error.log";

                    // Generate Error log and the move the error log in the out folder
                    StreamWriter sw = new StreamWriter(strErrorFileName);
                    sw.WriteLine(ex.ToString());
                    sw.WriteLine("Books CleanupMarkup");
                    sw.WriteLine("Exception in Processing the document. Please consult 3CM Administrator.");
                    sw.Close();

                    Directory.Delete(GlobalMethods.StrProcessFolder + folderpath, true);
                }

                strProcessFolder = GlobalMethods.StrProcessFolder;

                if (folderpath.StartsWith("\\"))
                    strProcessFolder = strProcessFolder + folderpath;
                else
                    strProcessFolder = strProcessFolder + "\\" + folderpath;
                if (Directory.Exists(strProcessFolder))
                    Directory.Delete(strProcessFolder, true);
            }
        }

        public static void Start(string strDocumentName)
        {

            object OutputFilename = null;

            FileInfo ff = null;

            GlobalMethods.strJobTransId = null;
            GlobalMethods.strDocumentType = null;
            GlobalMethods.strServiceType = null;
            GlobalMethods.strDegree = null;

            GlobalMethods.strDegree = ConfigurationManager.AppSettings.Get("AuthorSTyle_Degree");
            GlobalMethods.strParagraphStyleMappingConfig = ConfigurationManager.AppSettings.Get("3CMParagraphStyleMappingConfig");

            DirectoryInfo Dir = new DirectoryInfo(strDocumentName);


            FileInfo[] filesForProcess = Dir.GetFiles();
            string strSourceFileName = null;
            foreach (var files in filesForProcess)
            {
                if (files.Extension == ".xml")
                {
                    /// read XML file for document custom properties
                    GlobalMethods.ReadCustomPropertiesXML(files.FullName);
                }
                if (files.Extension == ".docx")
                {
                    if (!files.Name.StartsWith("~$"))
                    {
                        ff = files;
                    }
                }
            }

            if (ff == null)
            {
                string strErrorFileName = null;

                if (GlobalMethods.StrOutFolder != null && GlobalMethods.StrOutFolder != "")
                {
                    strErrorFileName = GlobalMethods.StrOutFolder + "\\" + Dir.Name;

                    if (Directory.Exists(strErrorFileName) == false)
                        Directory.CreateDirectory(strErrorFileName);

                    if (strErrorFileName.EndsWith("\\") == false)
                        strErrorFileName = strErrorFileName + "\\";

                    strErrorFileName = strErrorFileName + "Error.log";

                    // Generate Error log and the move the error log in the out folder
                    StreamWriter sw = new StreamWriter(strErrorFileName);
                    sw.WriteLine("Document not found Books CleanupMarkup in Input folder. Please consult 3CM Administrator.");
                    sw.Close();
                }

                // Remove the document from Process folder

                goto EndProcess;
            }

            if (GlobalMethods.strJobTransId == null || GlobalMethods.strJobTransId == "")
            {
                string strErrorFileName = null;

                if (GlobalMethods.StrOutFolder != null && GlobalMethods.StrOutFolder != "")
                {
                    strErrorFileName = GlobalMethods.StrOutFolder + "\\" + ff.Directory.Name;

                    if (Directory.Exists(strErrorFileName) == false)
                        Directory.CreateDirectory(strErrorFileName);

                    if (strErrorFileName.EndsWith("\\") == false)
                        strErrorFileName = strErrorFileName + "\\";

                    // Generate Error log and the move the error log in the out folder
                    StreamWriter sw = new StreamWriter(strErrorFileName);
                    sw.WriteLine("Books CleanupMarkup");
                    sw.WriteLine("Either the Job Transaction ID is missing in the document properties or is empty. Please consult 3CM Administrator.");
                    sw.Close();
                }

                // Remove the document from Process folder

                goto EndProcess;
            }

            if (GlobalMethods.strDocumentType == null || GlobalMethods.strDocumentType == "")
            {
                string strErrorFileName = null;

                if (GlobalMethods.StrOutFolder != null && GlobalMethods.StrOutFolder != "")
                {
                    strErrorFileName = GlobalMethods.StrOutFolder + "\\" + GlobalMethods.strJobTransId;

                    if (Directory.Exists(strErrorFileName) == false)
                        Directory.CreateDirectory(strErrorFileName);

                    if (strErrorFileName.EndsWith("\\") == false)
                        strErrorFileName = strErrorFileName + "\\";

                    // Generate Error log and the move the error log in the out folder
                    StreamWriter sw = new StreamWriter(strErrorFileName);
                    sw.WriteLine("Books CleanupMarkup");
                    sw.WriteLine("Either the DocumentType is missing in the document properties or is empty. Please consult 3CM Administrator.");
                    sw.Close();
                }

                // Remove the document from Process folder

                goto EndProcess;
            }

            if (GlobalMethods.strServiceType == null || GlobalMethods.strServiceType == "")
            {
                string strErrorFileName = null;

                if (GlobalMethods.StrOutFolder != null && GlobalMethods.StrOutFolder != "")
                {
                    strErrorFileName = GlobalMethods.StrOutFolder + "\\" + GlobalMethods.strJobTransId;

                    if (Directory.Exists(strErrorFileName) == false)
                        Directory.CreateDirectory(strErrorFileName);

                    if (strErrorFileName.EndsWith("\\") == false)
                        strErrorFileName = strErrorFileName + "\\";

                    // Generate Error log and the move the error log in the out folder
                    StreamWriter sw = new StreamWriter(strErrorFileName);
                    sw.WriteLine("Books CleanupMarkup");
                    sw.WriteLine("Either the ServiceType is missing in the document properties or is empty. Please consult 3CM Administrator.");
                    sw.Close();
                }

                // Remove the document from Process folder

                goto EndProcess;
            }

            strSourceFileName = ff.FullName.Replace(ff.Extension, "");

            strSourceFileName = strSourceFileName + "_Source" + ff.Extension;

            File.Copy(ff.FullName, strSourceFileName, true);

            ///Commented by Karan on 17-10-2018 for CT Style applied ..ConditionalStyleMappingCont() Function Start
            //GlobalMethods.ChapterPath = "";
            //GlobalMethods.DOI = "";
            //GlobalMethods.ISBN = "";
            //GlobalMethods.eISBN = "";
            //GlobalMethods.VolumeTitle = "";
            //GlobalMethods.SeriesTitle = "";
            //GlobalMethods.BookSubTitle = "";
            //GlobalMethods.CopyrightNote = "";
            //GlobalMethods.CopyrightYear = "";
            //GlobalMethods.Publisher = "";
            //GlobalMethods.ChapterTitle = "";
            //GlobalMethods.strCleanup = "";
            //GlobalMethods.ChapterImagePath = "";

            //GlobalMethods.strStyleMappingConfig = "";
            //GlobalMethods.str3CMWordTemplate = "";
            ///Commented by Karan on 17-10-2018 for CT Style applied ..ConditionalStyleMappingCont() Function End

            //---- Here we SaveAs the input document ----//
            //GlobalMethods.funcSaveAsInputFile(ff.FullName);

            // Extract Document Properties and Store in Variable //
            //System.Threading.Thread.Sleep(3000);
            //GlobalMethods.DOI = CustomProperties.WDGetCustomProperty(ff.FullName, "DOI");
            //System.Threading.Thread.Sleep(3000);
            //GlobalMethods.ISBN = CustomProperties.WDGetCustomProperty(ff.FullName, "ISBN");
            //System.Threading.Thread.Sleep(3000);
            //GlobalMethods.eISBN = CustomProperties.WDGetCustomProperty(ff.FullName, "EISBN");
            //System.Threading.Thread.Sleep(3000);
            //GlobalMethods.VolumeTitle = CustomProperties.WDGetCustomProperty(ff.FullName, "Volume Title");
            //System.Threading.Thread.Sleep(3000);
            //GlobalMethods.SeriesTitle = CustomProperties.WDGetCustomProperty(ff.FullName, "Series Title");
            //System.Threading.Thread.Sleep(3000);
            //GlobalMethods.BookTitle = CustomProperties.WDGetCustomProperty(ff.FullName, "Book Title");
            //System.Threading.Thread.Sleep(3000);
            //GlobalMethods.BookSubTitle = CustomProperties.WDGetCustomProperty(ff.FullName, "Book Sub Title");
            //System.Threading.Thread.Sleep(3000);
            //GlobalMethods.CopyrightNote = CustomProperties.WDGetCustomProperty(ff.FullName, "Copyright Note");
            //System.Threading.Thread.Sleep(3000);
            //GlobalMethods.CopyrightYear = CustomProperties.WDGetCustomProperty(ff.FullName, "Copyright Year");
            //System.Threading.Thread.Sleep(3000);
            //GlobalMethods.Publisher = CustomProperties.WDGetCustomProperty(ff.FullName, "Publisher");
            //System.Threading.Thread.Sleep(3000);
            //GlobalMethods.ChapterTitle = CustomProperties.WDGetCustomProperty(ff.FullName, "ChapterTitle");
            //System.Threading.Thread.Sleep(3000);
            //GlobalMethods.ChapterNumber = CustomProperties.WDGetCustomProperty(ff.FullName, "ChapterNumber");
            //System.Threading.Thread.Sleep(3000);
            //GlobalMethods.strCleanup = CustomProperties.WDGetCustomProperty(ff.FullName, "Cleanup");
            //System.Threading.Thread.Sleep(3000);
            //GlobalMethods.ChapterPath = CustomProperties.WDGetCustomProperty(ff.FullName, "ChapterPath");
            //System.Threading.Thread.Sleep(3000);


            GlobalMethods.strStyleMappingConfig = ConfigurationManager.AppSettings.Get("3CMStyleMappingConfig");
            GlobalMethods.str3CMWordTemplate = ConfigurationManager.AppSettings.Get("3CMWordTemplate");
            GlobalMethods.StrInFolder = ConfigurationManager.AppSettings.Get("CleanupMarkupIN");
            GlobalMethods.StrOutFolder = ConfigurationManager.AppSettings.Get("CleanupMarkupOUT");
            GlobalMethods.StrProcessFolder = ConfigurationManager.AppSettings.Get("CleanupMarkupPROCESS");
            GlobalMethods.str3CMBoxStyle = ConfigurationManager.AppSettings.Get("3CMBoxStyleMappingConfig"); //04_10_2019
            GlobalMethods.strStyleMappingNew = ConfigurationManager.AppSettings.Get("Mapping");


            if (GlobalMethods.strJobCategory == "WTO" || GlobalMethods.strClientName.ToLower() == "wto")
            {

                CleanupMarkup.GlobalMethodsWTO.strStyleMappingConfig = ConfigurationManager.AppSettings.Get("3CMWTOStyleMappingConfig");
                // Normalize the Word document
                CleanupMarkup.NormalizeWordDocumentWTO.NormalizeWord(ff.FullName);

                // Perform CopyEditing // 

                // Thieme specific comment for WTO //
                //CopyEditing.PerformCopyEditing(ff.FullName);


                //// Remove Character filename to be extracted from Configuration
                string strRemoveCharStyleFilename = ConfigurationManager.AppSettings.Get("RemoveCharStyleFile");

                //// Clean Word Document and save
                CleanupMarkup.FilterWordDocumentWTO.CleanWordDocument(ff.FullName, strRemoveCharStyleFilename);

                //// Copy Styles from Word Template to the document
                CleanupMarkup.CopyStylesFromTemplateWTO.ExtractStyles(ff.FullName, CleanupMarkup.GlobalMethodsWTO.str3CMWordTemplate);

                //// Start Word Markup //
                CleanupMarkup.MapStylesWithWordTemplateWTO.ExecuteStyleMapping(ff.FullName, CleanupMarkup.GlobalMethodsWTO.strStyleMappingConfig);

                CleanupMarkup.TableStylingWTO.Tt_StyleApplied(ff.FullName);

                CleanupMarkup.TableStylingWTO.CheckAllPara(ff.FullName);

                //// Move Footnotes within main document
                CleanupMarkup.ArrangeFootNotesWTO.Footnotes(ff.FullName);

                // ID Generation and Crosslinking ///

                //string SearchAndReplaceConfig = GlobalMethods.strStyleMappingJSONConfig;   // .json File Name
                CleanupMarkup.SearchAndReplaceWTO.GeneralSearchAndReplace(ff.FullName); // add full path of .docx file

                CleanupMarkup.TableStylingWTO.AdditionalWordMarkup(ff.FullName);
                
                goto nextWTO;
            }



            if (GlobalMethods.strCleanup != null)
            {
                if (GlobalMethods.strCleanup != "")
                {
                    if (GlobalMethods.strCleanup.ToLower() == "yes")
                    {
                        GlobalMethods.bCleanupRequired = true;
                    }
                    else
                    {
                        GlobalMethods.bCleanupRequired = false;
                    }
                }
                else
                {
                    GlobalMethods.bCleanupRequired = true;

                }
            }
            else
            {
                GlobalMethods.bCleanupRequired = true;
            }

            if (GlobalMethods.ChapterPath != null)
            {
                if (GlobalMethods.ChapterPath != "")
                {
                    DirectoryInfo dd = new DirectoryInfo(GlobalMethods.ChapterPath);
                    GlobalMethods.ChapterImagePath = dd.Parent.FullName;

                    if (GlobalMethods.ChapterImagePath.EndsWith("\\"))
                        GlobalMethods.ChapterImagePath = GlobalMethods.ChapterImagePath + "Images";
                    else
                        GlobalMethods.ChapterImagePath = GlobalMethods.ChapterImagePath + "\\Images";
                }
            }

            if (GlobalMethods.bCleanupRequired == true)
            {
                //Developer name:Priyanka Vishwakarma ,Date:17-06-2020 ,Requirement:ePub Automation. 
                if (GlobalMethods.strXMLOutputrequired == "false" && GlobalMethods.strOutputRequired.ToLower() == "epub")
                {
                    MapStylesWithWordTemplate.RemoveEmptyPara(ff.FullName);
                    FrontMatter.Book_title_and_book_subtitle(ff.FullName);
                    FrontMatter.AuthorStyleApply(ff.FullName, GlobalMethods.strDegree);
                    FrontMatter.Title1_Style_Apply(ff.FullName);
                    FrontMatter.FrontMatterKeywords(ff.FullName);
                    FrontMatter.ArtInfo_and_CongressCataloging_StyleApply(ff.FullName);
                    FrontMatter.Signature_StyleApply(ff.FullName);
                    AutoStructuringStyles.ApplyTableStyletoUnstructuredInput(ff.FullName);  //09-06-2020  
                    AutoStructuringStyles.Tt_StyleApplied(ff.FullName); //04102019                
                    MapStylesWithWordTemplate.ExecuteStyleMapping(ff.FullName, GlobalMethods.strStyleMappingConfig);
                    AutoStructuringStyles.ApplyChapterNumCharStyle(ff.FullName); //Developer Name:Priyanka Vishwakarma ,Date:09072020  ,Requirement:For portuguese language epub
                    MapStylesWithWordTemplate.ApplyTextbasedStyle(ff.FullName);
                    SearchAndReplace.GeneralSearchAndReplace(ff.FullName);
                    MapStylesWithWordTemplate.ListStyleApply(ff.FullName);

                    MapStylesWithWordTemplate.ApplyParaStyleToNormalParagraph(ff.FullName);
                    References.Ref_StyleApplied(ff.FullName);
                    AutoStructuringStyles.applyREF1StyleForEpub(ff.FullName);
                    AutoStructuringStyles.applyIndexmarkingbasedonpagenoEpub(ff.FullName);
                    AutoStructuringStyles.checkForNummeredRef(ff.FullName);
                    References.MarkCitationsInDocument(ff.FullName);
                    FrontMatter.applyCTStyleToBM(ff.FullName);
                    FrontMatter.applyContributeStyle(ff.FullName);
                    AutoStructuringStyles.ApplyAlignmentStyles(ff.FullName);/////added by vikas on 30-07-2020 for handle Align text para in ePub
                    ArrangeFootNotes.Footnotes(ff.FullName); //Developer Name:Priyanka Vishwakarma,Date:03-08-2020 ,Requirement:Apply FTN Paragraph style and citefn char style.
                    AutoStructuringStyles.ApplyLabelStrongStyle(ff.FullName);/////Added by vikas on 05-08-2020 for Label strong style apply to table,figure and box caption
                    FrontMatter.applyFigStyleForEpub(ff.FullName);
                    MapStylesWithWordTemplate.ApplyBodyAtoNot3CMStyles(ff.FullName);
                    AutoStructuringStyles.ApplyBodyAStyle(ff.FullName);//Developer Name:Priyanka Vishwakarma, Date:23-07-2020,Requirement:Apply BodyA paragraph style if pragraphstyleid is null
                    goto nextWTO;



                }
                //----------------END by priyanka Vishwakarma on 17-06-2020------------------------------
                // Extract the styles and its properties from the word document //
                // and store it in a Dictionary list object defined globally //
                GlobalMethods.StyleList = GlobalMethods.ExtractStylesPart(ff.FullName, false);

                //AutoStructuringStyles.NormalStyleApply(ff.FullName);

                //Autostyling
                //AutoStructuringStyles.EpubWordMarkup(ff.FullName);

                //// Normalize the Word document
                //NormalizeWordDocument.NormalizeWord(ff.FullName);



                MapStylesWithWordTemplate.RemoveEmptyPara(ff.FullName);

                StyleMappingNew.ApplyQuote(ff.FullName);// ADDED BY AARTI29-1-2019
                ///New function added by Karan on 18-07-2018
                MapStylesWithWordTemplate.Removecolor(ff.FullName);

                ////// Entity Conversion //
                EntityConversion.ConvertEntities(ff.FullName);

                //// Remove Character filename to be extracted from Configuration
                string strRemoveCharStyleFilename = ConfigurationManager.AppSettings.Get("RemoveCharStyleFile");

                #region old process code commented move to spliting
                //// Clean Word Document and save
                //FilterWordDocument.CleanWordDocument(ff.FullName, strRemoveCharStyleFilename);

                //MapStylesWithWordTemplate.RemoveCharStyleFromParagraphMarkRunProperties(ff.FullName);

                ////"NewExtractAndStoreParaStylePropertiesInDocument" commented by Karan becasue this function added in spliting 25-07-2018 Start
                ////MapStylesWithWordTemplate.NewExtractAndStoreParaStylePropertiesInDocument(ff.FullName);
                ////"NewExtractAndStoreParaStylePropertiesInDocument" commented by Karan becasue this function added in spliting 25-07-2018 End

                //GlobalMethods.swriter.Close();

                //MapStylesWithWordTemplate.ExtractAndStoreCharStylePropertiesInDocument(ff.FullName);

                //MapStylesWithWordTemplate.CopyParagraphMarkRunPropertiesToTextRun(ff.FullName);

                // Remove Customer Specific Styles which are matching 3CM Styles //

                //MapStylesWithWordTemplate.RemoveCustomerSpecificParaStylesFromDocumentStyles(ff.FullName);

                //MapStylesWithWordTemplate.RemoveCustomerSpecificParaStylesFromTheDocument(ff.FullName);

                //// Copy Styles from Word Template to the document
                ///CopyStylesFromTemplate.ExtractStyles(ff.FullName, GlobalMethods.str3CMWordTemplate);
                #endregion old process code commented


                ////SearchAndReplace.GenerateListLabels(ff.FullName);


                //// Start Word Markup //
                //if (GlobalMethods.strClientName.ToLower() != "travelguide")
                //{
                //    clsLinking.funcLinking(ff.FullName);   //Developer name:Priyanka Vishwakarma ,Date:03_10_2019 ,Requirement:Apply citation style ,Integrated By:Vikas sir.
                //}
                AutoStructuringStyles.Tt_StyleApplied(ff.FullName); //04102019
                                                                    /// AutoStructuringStyles.Tfn_StyleApplied(ff.FullName); //04102019//////for un-structure document on 16-11-2019 commented for italian sample
                AutoStructuringStyles.BoxStyleMapping(ff.FullName); //04102019
                AutoStructuringStyles.CN_StyleApplied(ff.FullName); //04102019
                if (GlobalMethods.strClientName == "VTH")   //Developer Name:Priyanka Vishwakarma,Date:07-08-2020,Requirement:Apply Figc para for Figure caption only for VTH client.
                {
                    AutoStructuringStyles.ApplyFIGCPara(ff.FullName);
                    AutoStructuringStyles.ApplyBodyAParaToEQ(ff.FullName); //Developer Name:Priyanka Vishwakarma ,Date:08-08-2020 ,Requirement:Add Multiple equation in single para add inline equations.
                }
                if(GlobalMethods.strClientName.ToLower()=="jaypee")
                {
                    AutoStructuringStyles.ApplyFIGCParaJaypee(ff.FullName);
                    AutoStructuringStyles.ApplyTableStyletoUnstructuredInput(ff.FullName);  //09-06-2020  
                }
                MapStylesWithWordTemplate.StyleMapping(ff.FullName, GlobalMethods.strStyleMappingConfig);
                if (GlobalMethods.strClientName.ToLower() != "travelguide" && GlobalMethods.strClientName.ToLower() != "jaypee")
                {
                    clsLinking.funcLinking(ff.FullName);   //Developer name:Priyanka Vishwakarma ,Date:03_10_2019 ,Requirement:Apply citation style ,Integrated By:Vikas sir.
                }
                AutoStructuringStyles.AUStyleApply(ff.FullName);//04102019



                if (/*GlobalMethods.strClientName.ToLower() == "fm"*/GlobalMethods.strJobCategory != null && GlobalMethods.strJobCategory.ToLower() == "frontmatter")
                {
                    //FrontMatter.ParaStyleApply(ff.FullName);
                    FrontMatter.Book_title_and_book_subtitle(ff.FullName);
                    MapStylesWithWordTemplate.ListStyleApply(ff.FullName);////For Listing called by vikas on 18-01-2021
                    // FrontMatter.AuthorStyleApply(ff.FullName, GlobalMethods.strDegree);////commnted by vikas on 16-01-2021
                    FrontMatter.Heading_Style_Apply(ff.FullName);
                    FrontMatter.Signature_StyleApply(ff.FullName);
                    FrontMatter.ArtInfo_and_CongressCataloging_StyleApply(ff.FullName);
                    FrontMatter.applyContributeStyle(ff.FullName);/////called this function by vikas on 15-01-2021
                    FrontMatter.AuthorDetailsStyleApply(ff.FullName, GlobalMethods.strDegree);////Added by vikas on 16-01-2021 for apply authordetails style
                    MapStylesWithWordTemplate.TableStructuring(ff.FullName);
                }
                else if (GlobalMethods.strClientName.ToLower() == "travelguide")
                {
                    TravelGuide.H1StyleaApply(ff.FullName);

                    TravelGuide.CT_StyleApply(ff.FullName);

                    TravelGuide.BoxStyleApply(ff.FullName);

                    TravelGuide.FigStyleApply(ff.FullName);

                    TravelGuide.Txt_1StyleApply(ff.FullName);

                    TravelGuide.QuoteStyleApply(ff.FullName);

                    TravelGuide.Top_TenStyle(ff.FullName);
                }
                ////Added here by vikas for all jobcategory on 04-06-2021
                FrontMatter.Media_Style_Apply(ff.FullName);////Added by vikas on 18-01-2021 for apply media styles like FIG-for un_numbered images,VIDEOC style for video and audio information para 

                //CopyEditing.ApplyTextListStyle(ff.FullName);

                //SearchAndReplace.ApplyListNumStyle(ff.FullName);

                // ID Generation and Crosslinking ///
                SearchAndReplace.ReplaceMultipleTabsWithSingleTab(ff.FullName); // add full path of .docx file

                //// Move Footnotes within main document
                ArrangeFootNotes.Footnotes(ff.FullName);

                // Perform CopyEditing //

                if (GlobalMethods.strClientName.ToLower() != "jaypee") //10-02-2021
                {
                    CopyEditing.PerformCopyEditing(ff.FullName);
                }
                AutoStructuringStyles.BodyTextIndendStyleApply(ff.FullName);
                MapStylesWithWordTemplate.ApplyParaStyleToNormalParagraph(ff.FullName);
            }
            else
            {
                //// Copy Styles from Word Template to the document
                CopyStylesFromTemplate.ExtractStyles(ff.FullName, GlobalMethods.str3CMWordTemplate);

                //// Start Word Markup //
                clsLinking.funcLinking(ff.FullName);  //Developer name:Priyanka Vishwakarma ,Date:03_10_2019 ,Requirement:Apply citation style ,Integrated By:Vikas sir.
                MapStylesWithWordTemplate.StyleMapping(ff.FullName, GlobalMethods.strStyleMappingConfig);
            }
            if (GlobalMethods.strJobCategory != null && GlobalMethods.strJobCategory.ToLower() != "frontmatter")
            {
                MapStylesWithWordTemplate.ListStyleApply(ff.FullName);
            }
            //clsLinking.funcLinking(ff.FullName);  //Commented on 03_10_2019 by Priyanka for apply citation style read by text file.

            StyleMappingNew.ApplyBullList(ff.FullName);//added by bhavesh
            if (GlobalMethods.strClientName == "VTH")   //Developer Name:Priyanka Vishwakarma,Date:07-08-2020,Requirement:Apply Figc para for Figure caption only for VTH client.
            {
                AutoStructuringStyles.checkNormalParaorListingPara(ff.FullName);
            }
            if (GlobalMethods.strClientName.ToLower() == "randomhouse")
            {
                RandomHouseStructuring.StartRandomHouseStructuring(ff.FullName);
            }
            MapStylesWithWordTemplate.CheckParacitationStyle(ff.FullName);
            // Compare the updated document with Source document and delete source document //

            //GlobalMethods.OpenWordDocumentAndCompare(strSourceFileName, ff.FullName);
            MapStylesWithWordTemplate.MovetoFigurecallout(ff.FullName);

            if (GlobalMethods.strXMLOutputrequired.ToLower() == "true")/////For content job only
            {
                TableStyling.RemoveWrongCaptionStyle(ff.FullName);///Remove wrong applied table caption style added on 21-06-2020 by vikas
                MapStylesWithWordTemplate.CaptionStyleCorrection(ff.FullName);///Added by vikas for remove wrong caption style applied on 07-07-2020
            }
            if (GlobalMethods.strClientName == "VTH")  //08-08-2020
            {
                MapStylesWithWordTemplate.CiteFIGStyleRemoveVTHFIGStyle(ff.FullName);
                /////Start Added on 05-07-2021
                AutoStructuringStyles.ApplyheadingStyletoNumberedPara(ff.FullName);
                AutoStructuringStyles.ApplyCTandCN_FM(ff.FullName);
                AutoStructuringStyles.ApplyBoxStartandEnd(ff.FullName);
                /////End Added on 05-07-2021
            }

            if (GlobalMethods.strClientName.ToLower() == "sage")
            {
                MapStylesWithWordTemplate.SageChapterMappinngBasedonText(ff.FullName);/////Added by vikas on 08-02-2021 for sage book chapter structuring
            }
            AutoStructuringStyles.ApplyEqtoBodyA(ff.FullName);////Developer Name:Priyanka Vishwakarma,Date:24-03-2021,Requirement:change eq para to bodyA if equation is inline equation
            MapStylesWithWordTemplate.ApplyBodyAtoNot3CMStyles(ff.FullName);///Added by vikas on 24-07-2020
            nextWTO:
            { }
            try
            {
                GlobalMethods.CleanupAnalysisReport(ff.FullName);
            }
            catch (Exception er)
            {

            }
            System.Threading.Thread.Sleep(1000);

            // Delete the Source Document //

            File.Delete(strSourceFileName);

            OutputFilename = ff.FullName;

            if (OutputFilename != null)
            {
                if (File.Exists(OutputFilename.ToString()))
                {
                    // Move the processed document to out folder
                    FileInfo fout = new FileInfo(OutputFilename.ToString());

                    string strParentDirectory = GlobalMethods.strJobTransId;
                    string outfile = null;
                    string EmptyDoc = null;

                    EmptyDoc = fout.Directory.FullName;

                    if (EmptyDoc.EndsWith("\\") == false)
                    {
                        EmptyDoc += "\\EmptyDocument.docx";
                    }
                    else
                    {
                        EmptyDoc += "EmptyDocument.docx";
                    }

                    // Delete EmptyDocument.docx
                    if (File.Exists(EmptyDoc))
                    {
                        File.Delete(EmptyDoc);
                    }

                    outfile = fout.Name;

                    if (Directory.Exists(GlobalMethods.StrOutFolder + "\\" + strParentDirectory) == false)
                    {
                        Directory.CreateDirectory(GlobalMethods.StrOutFolder + "\\" + strParentDirectory);
                    }

                    outfile = GlobalMethods.StrOutFolder + "\\" + strParentDirectory + "\\" + outfile;

                    // On completion copy the output file in out folder

                    File.Copy(OutputFilename.ToString(), outfile, true);

                    // Delete the files from the Process folder


                    fout.Delete();

                    Directory.Delete(fout.Directory.FullName, true);

                    System.Threading.Thread.Sleep(3000);
                }
            }
            EndProcess:
            {
                if (Directory.Exists(GlobalMethods.StrProcessFolder + "\\" + Dir.Name))
                {
                    Directory.Delete(GlobalMethods.StrProcessFolder + "\\" + Dir.Name);
                }
            }
            //ff.Delete();
            //bProcessingInProgress = false;
            // Reinitiate the processing to check other input //
        }
    }
}
