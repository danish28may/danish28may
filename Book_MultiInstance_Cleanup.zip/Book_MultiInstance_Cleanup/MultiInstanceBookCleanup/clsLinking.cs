﻿using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Wordprocessing;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Office.Interop.Word;
using System.Configuration;

namespace MultiInstanceBookCleanup
{
    class clsLinking
    {
        public static List<string> lstAllLabelStrong = new List<string>();
        public static void funcLinking(string WordPath)
        {
            WordprocessingDocument docx = WordprocessingDocument.Open(WordPath, true);
            try
            {
                funcRemoveCiteFigStyle(docx);
                funcGetAllLabelStrong(docx);
                funcRemoveCiteSecStyleFromCNFMparaStyle(docx);
                //funcApplyBIBAndREFStyle(docx);
                docx.Close();
            }
            catch (Exception)
            {
                if(docx != null)
                    docx.Close();
            }

            try
            {
                //funcApplyCiteFigStyle(WordPath);
                ApplyCiteFigStyle(WordPath);
            }
            catch (Exception ex)
            {

            }
        }

        private static void funcApplyBIBAndREFStyle(WordprocessingDocument docx)
        {
            foreach (var p in docx.MainDocumentPart.Document.Body.Descendants<DocumentFormat.OpenXml.Wordprocessing.Paragraph>().ToList())
            {
                if (p.InnerText != "")
                {
                    if (p.ParagraphProperties != null &&
                        p.ParagraphProperties.ParagraphStyleId != null &&
                        p.ParagraphProperties.ParagraphStyleId.Val != null &&
                        p.ParagraphProperties.ParagraphStyleId.Val.HasValue &&
                        p.ParagraphProperties.ParagraphStyleId.Val.Value.Equals("bib1", StringComparison.CurrentCultureIgnoreCase) ||
                         p.ParagraphProperties.ParagraphStyleId.Val.Value.Equals("ref1", StringComparison.CurrentCultureIgnoreCase))
                    {

                        if (p.PreviousSibling() == null)
                        {
                            goto BIB1Found;
                        }

                        var preElement = p.PreviousSibling();

                        foreach (var para in preElement)
                        {
                            if (para.LocalName.ToLower().Trim() == "ppr")
                            {
                                foreach (ParagraphStyleId pstyle in para.Elements<ParagraphStyleId>().ToList())
                                {
                                    if (pstyle.Val != null && pstyle.Val.HasValue && pstyle.Val.Value.Equals("h1", StringComparison.CurrentCultureIgnoreCase))
                                    {
                                        if (p.ParagraphProperties.ParagraphStyleId.Val.Value.Equals("bib1",StringComparison.CurrentCultureIgnoreCase))
                                        {
                                            pstyle.Val = "BIB";
                                            goto BIB1Found;
                                        }
                                        else if (p.ParagraphProperties.ParagraphStyleId.Val.Value.Equals("ref1", StringComparison.CurrentCultureIgnoreCase))
                                        {
                                            pstyle.Val = "REF";
                                            goto BIB1Found;
                                        }
                                        else
                                        {
                                            goto BIB1Found;
                                        }
                                    }
                                    else
                                    {
                                        goto BIB1Found;
                                    }
                                }
                            }
                            break;
                        }
                    }
                }
            }

            BIB1Found: { }
        }
        private static void funcGetAllLabelStrong(WordprocessingDocument docx)
        {
            var eleLabelStrongTxt = docx.MainDocumentPart.Document.Body.Descendants<Run>().
                Where(r => r.RunProperties != null &&
                      r.RunProperties.RunStyle != null &&
                      r.RunProperties.RunStyle.Val != null &&
                      r.RunProperties.RunStyle.Val == "label-Strong").ToList();

            foreach (var i in eleLabelStrongTxt.ToList())
            {
                lstAllLabelStrong.Add(i.InnerText);
            }
        }

        ////private static void funcApplyCiteFigStyle(string WordPath)
        ////{
        ////    if (lstAllLabelStrong.Count() != 0)
        ////    {
        ////        Microsoft.Office.Interop.Word.Document mdoc = null;
        ////        try
        ////        {
        ////            string strDocContent = null;

        ////            mdoc = GlobalMethods.LoadWordDocument(WordPath);

        ////            strDocContent = mdoc.Content.Text;

        ////            if (strDocContent == null)
        ////                return;

        ////            if (mdoc != null)
        ////            {
        ////                List<string> strMatchText = new List<string>();
        ////                string strSearchRegEx = null;

        ////                for (int i = 0; i < lstAllLabelStrong.Count(); i++)
        ////                {
        ////                    strSearchRegEx = lstAllLabelStrong[i];
        ////                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

        ////                    if (strMatchText.Count > 0)
        ////                    {
        ////                        for (int counter = 0; counter < strMatchText.Count; counter++)
        ////                        {
        ////                            if(strMatchText[counter].ToLower().StartsWith("table") || strMatchText[counter].ToLower().StartsWith("tab"))
        ////                            {
        ////                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, true, false);
        ////                            }

        ////                            if (strMatchText[counter].ToLower().StartsWith("fig"))
        ////                            {
        ////                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, true, false);
        ////                            }
        ////                        }
        ////                    }
        ////                }

        ////                strSearchRegEx = @"(Figs\. [0-9]+\.[0-9]+[-–—][0-9]+\.[0-9]+)";
        ////                strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

        ////                if (strMatchText.Count > 0)
        ////                {
        ////                    for (int counter = 0; counter < strMatchText.Count; counter++)
        ////                    {
        ////                        GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, true, false);
        ////                    }
        ////                }


        ////                strSearchRegEx = @"(Figs\. [0-9]+\.[0-9]+\s+and\s+[0-9]+\.[0-9]+)";
        ////                strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

        ////                if (strMatchText.Count > 0)
        ////                {
        ////                    for (int counter = 0; counter < strMatchText.Count; counter++)
        ////                    {
        ////                        GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, true, false);
        ////                    }
        ////                }


        ////                object oMissing = System.Reflection.Missing.Value;
        ////                object saveChanges = WdSaveOptions.wdSaveChanges;
        ////                ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
        ////                mdoc = null;
        ////            }
        ////        }
        ////        catch (Exception ex)
        ////        {
        ////            object oMissing = System.Reflection.Missing.Value;
        ////            object saveChanges = WdSaveOptions.wdSaveChanges;
        ////            ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
        ////            mdoc = null;
        ////        }
        ////        finally
        ////        {
        ////            if (GlobalMethods.wordApp != null)
        ////            {
        ////                object oMissing = System.Reflection.Missing.Value;
        ////                ((_Application)GlobalMethods.wordApp).Quit(ref oMissing, ref oMissing, ref oMissing);
        ////                GlobalMethods.wordApp = null;
        ////            }
        ////        }
        ////    }
        ////}

        private static void funcApplyCiteFigStyle(string WordPath)
        {
            if (lstAllLabelStrong.Count() != 0)
            {
                Microsoft.Office.Interop.Word.Document mdoc = null;
                try
                {
                    string strDocContent = null;

                    mdoc = GlobalMethods.LoadWordDocument(WordPath);

                    strDocContent = mdoc.Content.Text;

                    if (strDocContent == null)
                        return;

                    if (mdoc != null)
                    {
                        List<string> strMatchText = new List<string>();
                        string strSearchRegEx = null;

                        for (int i = 0; i < lstAllLabelStrong.Count(); i++)
                        {
                            strSearchRegEx = lstAllLabelStrong[i];
                            strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                            if (strMatchText.Count > 0)
                            {
                                for (int counter = 0; counter < strMatchText.Count; counter++)
                                {
                                    if (strMatchText[counter].ToLower().StartsWith("table") || strMatchText[counter].ToLower().StartsWith("tab"))
                                    {
                                        GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, true, false);
                                    }

                                    if (strMatchText[counter].ToLower().StartsWith("fig"))
                                    {
                                        GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, true, false);
                                    }
                                    ////22/1/2019 add by ashwini & aarti for cite_video start
                                    //if (strMatchText[counter].ToLower().StartsWith("video"))///commented by aarti 07-02-2019
                                    //{
                                    //    GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_video", "", true, false, false, true, false);
                                    //}
                                    ////22/1/2019 add by ashwini & aarti for cite_video end
                                }
                            }
                        }


                        strSearchRegEx = @"(Fig\.\s[0-9]+\.[0-9]+)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, true, false);
                            }
                        }

                        strSearchRegEx = @"(Figs\. [0-9]+\.[0-9]+[-–—][0-9]+\.[0-9]+)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, true, false);
                            }
                        }


                        strSearchRegEx = @"(Figs\. [0-9]+\.[0-9]+\s+and\s+[0-9]+\.[0-9]+)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, true, false);
                            }
                        }

                        ////=====add pattern by Karan on 07-06-2018 Start=============================//////////

                        //1)**********start for Figs. 1–3 and tables*****************//
                        strSearchRegEx = @"(Figs.\s+([0-9]\–)+([0-9]))";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Tables.\s+([0-9]\–)+([0-9]))";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;
                        //**********end for Figs. 1–3 and tables*****************//

                        //2)**********start for Figs 1 and 2 and tables*****************//
                        strSearchRegEx = @"(Figs\s+([0-9])\s+(and\s)+([0-9]))";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Tables\s+([0-9])\s+(and\s)+([0-9]))";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;
                        //**********end for Figs 1 and 2 and tables*****************//

                        //3)**********start for Figs 1 to 2 and tables*****************//
                        strSearchRegEx = @"(Figs\s+([0-9])\s+(to\s)+([0-9]))";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Tables\s+([0-9])\s+(to\s)+([0-9]))";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;
                        //**********end for Figs 1 to 2 and tables*****************//

                        //4)**********start for Figs 1 & 2 and tables*****************//
                        strSearchRegEx = @"(Figs\s+([0-9])\s+(&\s)+([0-9]))";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Tables\s+([0-9])\s+(&\s)+([0-9]))";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;
                        //**********end for Figs 1 & 2 and tables*****************//

                        //5)**********start for Fig 1 and Fig 2 and tables*****************//
                        strSearchRegEx = @"(Fig\s+([0-9])\s+(and\s)+Fig\s+([0-9]))";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Table\s+([0-9])\s+(and\s)+Table\s+([0-9]))";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;
                        //**********end for Figs 1 & 2 and tables*****************//

                        //7-6-2018
                        //6)**********start for Figs. 4.1A,4.1C and tables *****************//
                        strSearchRegEx = @"(Figs\.+\s+[0-9]+\.[0-9]+[A-Za-z]+\,+[0-9]+\.[0-9]+[A-Za-z]+)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Tables\.+\s+[0-9]+\.[0-9]+[A-Za-z]+\,+[0-9]+\.[0-9]+[A-Za-z]+)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;
                        //**********end for Figs. 4.1A,4.1C and tables*****************//


                        //7)**********start for Figs. 4.1A-1F and tables *****************//
                        strSearchRegEx = @"(Figs\.+\s+[0-9]+\.[0-9]+[A-Za-z]+\-+[0-9]+[A-Za-z]+)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Tables\.+\s+[0-9]+\.[0-9]+[A-Za-z]+\-+[0-9]+[A-Za-z]+)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;
                        //**********end for Figs. 4.1A-1F and tables*****************//


                        //8)**********start for Figs. 4.1A, 4.1C (In regex Spaces cover)and tables  *****************//
                        strSearchRegEx = @"(Figs\.+\s+[0-9]+\.?[0-9]+[A-Za-z]+\,?\s+[0-9]+\.[0-9]+[A-Za-z]+)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Tables\.+\s+[0-9]+\.?[0-9]+[A-Za-z]+\,?\s+[0-9]+\.[0-9]+[A-Za-z]+)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;
                        //**********end for Figs. 4.1A, 4.1C (In regex Spaces cover) and tables*****************//

                        //9)**********start for Figs. 4.3, 4.4 (In regex Spaces cover) and tables  *****************//
                        strSearchRegEx = @"(Figs\.+\s+[0-9]+\.[0-9]+\,?\s+[0-9]+\.[0-9]+)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Tables\.+\s+[0-9]+\.[0-9]+\,?\s+[0-9]+\.[0-9]+)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;
                        //**********end for Figs. 4.3, 4.4 (In regex Spaces cover) and tables*****************//

                        //10)**********start for Figs.  4.8D, 4.8E; Figs. 4.9F-4.9H (In regex Spaces cover) and tables  *****************//
                        strSearchRegEx = @"(Figs\.+\s+[0-9]+\.?[0-9]+[A-Za-z]+\,?\s+[0-9]+\.[0-9]+[A-Za-z]+\;\s+[A-Za-z]+\.?\s+[0-9]+\.[0-9]+[A-Za-z]+\-+[0-9]+\.[0-9]+[A-Za-z]+)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Tables\.+\s+[0-9]+\.?[0-9]+[A-Za-z]+\,?\s+[0-9]+\.[0-9]+[A-Za-z]+\;\s+[A-Za-z]+\.?\s+[0-9]+\.[0-9]+[A-Za-z]+\-+[0-9]+\.[0-9]+[A-Za-z]+)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;
                        //**********end for Figs.  4.8D, 4.8E; Figs. 4.9F-4.9H (In regex Spaces cover) and tables*****************//

                        //11)**********start for Figs. 4.2A-4.2F (In regex Spaces cover) and tables  *****************//
                        strSearchRegEx = @"(Figs\.+\s+[0-9]+\.[0-9]+[A-Za-z]+\-+[0-9]+\.[0-9]+[A-Za-z]+)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Tables\.+\s+[0-9]+\.[0-9]+[A-Za-z]+\-+[0-9]+\.[0-9]+[A-Za-z]+)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;
                        //**********end for Figs. 4.2A-4.2F (In regex Spaces cover) and tables*****************//


                        //12)**********start for Fig. 4.2L and tables  *****************//
                        strSearchRegEx = @"(Fig\.+\s+[0-9]+\.[0-9]+[A-Za-z]+)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Tables\.+\s+[0-9]+\.[0-9]+[A-Za-z]+)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;
                        //**********end for Fig. 4.2L (In regex Spaces cover) and tables*****************//

                        //7-6-2018

                        //*************start for Table2******************** //
                        strSearchRegEx = @"(Table+([0-9]))";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;
                        //**************** end for Table2**************//

                        ////=====add pattern by Karan on 07-06-2018 End=============================//////////

                        //new pattern update by Karan on 06-11-2018 For Cap5 document start
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Tab [0-9]+\.[0-9]+)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, false, false);
                            }
                        }
                        //new pattern update by Karan on 06-11-2018 For Cap5 document End

                        object oMissing = System.Reflection.Missing.Value;
                        object saveChanges = WdSaveOptions.wdSaveChanges;
                        ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                        mdoc = null;
                    }
                }
                catch (Exception ex)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;
                }
                finally
                {
                    if (GlobalMethods.wordApp != null)
                    {
                        object oMissing = System.Reflection.Missing.Value;
                        ((_Application)GlobalMethods.wordApp).Quit(ref oMissing, ref oMissing, ref oMissing);
                        GlobalMethods.wordApp = null;
                    }
                }
            }
        }

        private static void ApplyCiteFigStyle(string WordPath)   
        {
            if (lstAllLabelStrong.Count() != 0)
            {
                Microsoft.Office.Interop.Word.Document mdoc = null;
                try
                {
                    string strDocContent = null;

                    mdoc = GlobalMethods.LoadWordDocument(WordPath);

                    strDocContent = mdoc.Content.Text;

                    if (strDocContent == null)
                        return;

                    if (mdoc != null)
                    {
                        List<string> strMatchText = new List<string>();
                        string strSearchRegEx = null;

                        for (int i = 0; i < lstAllLabelStrong.Count(); i++)
                        {
                            strSearchRegEx = lstAllLabelStrong[i];
                            strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                            if (strMatchText.Count > 0)
                            {
                                for (int counter = 0; counter < strMatchText.Count; counter++)
                                {
                                    if (strMatchText[counter].ToLower().StartsWith("table") || strMatchText[counter].ToLower().StartsWith("tab"))
                                    {
                                        GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, true, false);
                                    }

                                    if (strMatchText[counter].ToLower().StartsWith("fig"))
                                    {
                                        GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, true, false);
                                    }

                                }
                            }
                        }
                        //Regex for fig pattern ex. Fig. 3A  
                        //Developer Name:Priyanka Vishwakarma ,Date:3_6_2019, Requiredment:Regex for fig pattern ex. Fig. 3A  ,Intergrated by:Vikas Sir
                        //strSearchRegEx = @"(Fig\.+\s+[0-9]+[A-Za-z]+)";
                        strSearchRegEx = @"(Fig\.+\s+[0-9]+[A-Z])";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, true, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;
                        //----------------------------------end----------------------------------------------

                        strSearchRegEx = @"(Fig\.\s[0-9]+\.[0-9]+)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, true, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        //strSearchRegEx = @"[(]Figs.[\s][0-9][][0-9][)]|[(]Fig.[\s][0-9][)]";
                        strSearchRegEx = @"(Figs.[\s][0-9][.][0-9])|(Fig.[\s][0-9])";    //23_5_2019 Triangle missing along with figure citation (eg. Fig. 1, Fig. 4, etc)
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, true, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Figs\. [0-9]+\.[0-9]+[-–—][0-9]+\.[0-9]+)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, true, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;


                        strSearchRegEx = @"(Figs\. [0-9]+\.[0-9]+\s+and\s+[0-9]+\.[0-9]+)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, true, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;


                        strSearchRegEx = @"(Figs.\s+([0-9]\–)+([0-9]))";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Figs.\s+([0-9]\-)+([0-9]))";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Tables.\s+([0-9]\–)+([0-9]))";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Table.\s+([0-9]\.)+([0-9]))";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Figs\s+([0-9])\s+(and\s)+([0-9]))";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Tables\s+([0-9])\s+(and\s)+([0-9]))";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Figs\s+([0-9])\s+(to\s)+([0-9]))";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Tables\s+([0-9])\s+(to\s)+([0-9]))";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Figs\s+([0-9])\s+(&\s)+([0-9]))";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Tables\s+([0-9])\s+(&\s)+([0-9]))";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Fig\s+([0-9])\s+(and\s)+Fig\s+([0-9]))";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Table\s+([0-9])\s+(and\s)+Table\s+([0-9]))";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Figs\.+\s+[0-9]+\.[0-9]+[A-Za-z]+\,+[0-9]+\.[0-9]+[A-Za-z]+)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Figures\s[0-9\,\s\.]+and\s[0-9]+\.[0-9]+)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Tables\.+\s+[0-9]+\.[0-9]+[A-Za-z]+\,+[0-9]+\.[0-9]+[A-Za-z]+)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Figs\.+\s+[0-9]+\.[0-9]+[A-Za-z]+\-+[0-9]+[A-Za-z]+)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Tables\.+\s+[0-9]+\.[0-9]+[A-Za-z]+\-+[0-9]+[A-Za-z]+)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Figs\.+\s+[0-9]+\.?[0-9]+[A-Za-z]+\,?\s+[0-9]+\.[0-9]+[A-Za-z]+)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Tables\.+\s+[0-9]+\.?[0-9]+[A-Za-z]+\,?\s+[0-9]+\.[0-9]+[A-Za-z]+)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Figs\.+\s+[0-9]+\.[0-9]+\,?\s+[0-9]+\.[0-9]+)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Tables\.+\s+[0-9]+\.[0-9]+\,?\s+[0-9]+\.[0-9]+)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Figs\.+\s+[0-9]+\.?[0-9]+[A-Za-z]+\,?\s+[0-9]+\.[0-9]+[A-Za-z]+\;\s+[A-Za-z]+\.?\s+[0-9]+\.[0-9]+[A-Za-z]+\-+[0-9]+\.[0-9]+[A-Za-z]+)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Tables\.+\s+[0-9]+\.?[0-9]+[A-Za-z]+\,?\s+[0-9]+\.[0-9]+[A-Za-z]+\;\s+[A-Za-z]+\.?\s+[0-9]+\.[0-9]+[A-Za-z]+\-+[0-9]+\.[0-9]+[A-Za-z]+)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Figs\.+\s+[0-9]+\.[0-9]+[A-Za-z]+\-+[0-9]+\.[0-9]+[A-Za-z]+)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Tables\.+\s+[0-9]+\.[0-9]+[A-Za-z]+\-+[0-9]+\.[0-9]+[A-Za-z]+)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Fig\.+\s+[0-9]+\.[0-9]+[A-Za-z]+)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Tables\.+\s+[0-9]+\.[0-9]+[A-Za-z]+)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Table+([0-9]))";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;
                  
                        strSearchRegEx = @"(Tab [0-9]+\.[0-9]+)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, false, false);
                            }
                        }


                       

                        ///////added by vikas for citation pattern read from text file apply citation style on 27-03-2020
                        var CitationStyle = ConfigurationManager.AppSettings.Get("CitationStyle");
                        List<string> CitationPatternsColl = new List<string>();

                        CitationPatternsColl = GlobalMethods.ReadAndStoreFileValuesInArray(CitationStyle);

                        foreach (var item in CitationPatternsColl)
                        {                            
                            strMatchText = GlobalMethods.DocumentRegEx(strDocContent, item);

                            if (strMatchText.Count > 0)
                            {
                                for (int counter = 0; counter < strMatchText.Count; counter++)
                                {
                                    if (strMatchText[counter].ToLower().Contains("fig"))
                                    {
                                        GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                                    }
                                    if (strMatchText[counter].ToLower().Contains("[foto"))
                                    {
                                        GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                                    }
                                    else if (strMatchText[counter].ToLower().Contains(".tif") || strMatchText[counter].ToLower().Contains(".eps"))  //Developer name:Priyanka Vishwakarma ,Date:30_09_2019,Requirement:Apply cite_fig character style to .tif and .eps extension figure for academic ,Integrated by:Vikas sir.
                                    {
                                        GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                                    }
                                    if (strMatchText[counter].ToLower().Contains("abb."))
                                    {
                                        GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                                    }
                                    if (strMatchText[counter].ToLower().Contains("tab"))
                                    {
                                        GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, false, false);
                                    }
                                    if (strMatchText[counter].ToLower().Contains("bild"))
                                    {
                                        GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                                    }
                                }
                            }
                            strMatchText.Clear();
                            strSearchRegEx = null;
                        }

                        object oMissing = System.Reflection.Missing.Value;
                        object saveChanges = WdSaveOptions.wdSaveChanges;
                        ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                        mdoc = null;
                    }
                }
                catch (Exception ex)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;
                }
                finally
                {
                    if (GlobalMethods.wordApp != null)
                    {
                        object oMissing = System.Reflection.Missing.Value;
                        ((_Application)GlobalMethods.wordApp).Quit(ref oMissing, ref oMissing, ref oMissing);
                        GlobalMethods.wordApp = null;
                    }
                }
            }
            else
            {
                SearchAndReplace.GeneralSearchAndReplace(WordPath);
            }
        }

        private static void funcRemoveCiteFigStyle(WordprocessingDocument docx)
        {
            var eleAllRprOfCiteFig = docx.MainDocumentPart.Document.Body.Descendants<RunStyle>().
                Where(rStyle => rStyle != null && rStyle.Val == "citefig").ToList();

            foreach (var i in eleAllRprOfCiteFig)
            {
                i.Remove();
            }
            docx.Save();
        }
        private static void funcRemoveCiteSecStyleFromCNFMparaStyle(WordprocessingDocument docx)
        {
            List<RunStyle> eleAllRprOfCiteFig = new List<RunStyle>();
            docx.MainDocumentPart.Document.Body.Descendants<DocumentFormat.OpenXml.Wordprocessing.Paragraph>().Where(x => x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && (x.ParagraphProperties.ParagraphStyleId.Val == "CN-FM"|| x.ParagraphProperties.ParagraphStyleId.Val == "CT")).ToList().ForEach(b =>
            {
                eleAllRprOfCiteFig = b.Descendants<RunStyle>().
                       Where(rStyle => rStyle != null && rStyle.Val == "citesec").ToList();
            });

            foreach (var i in eleAllRprOfCiteFig)
            {
                i.Remove();
            }
            docx.Save();
        }
    }
}
