﻿using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MultiInstanceBookCleanup
{
    class TravelGuide
    {
        public static void CT_StyleApply(string strDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument.Open(strDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                bool CTStylefound = false;
                string splittxt = null;
                int counter = 0;
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P != null && P.InnerText.Trim() != "" && !P.InnerText.Trim().ToLower().StartsWith("[insert"))
                    {
                        if (CTStylefound == false)
                        {
                            #region for : split logic comment
                            ////if (P.InnerText.Contains(":"))
                            ////{
                            ////splittxt = P.InnerText;
                            ////string[] separators = { ":" };
                            ////string[] links = splittxt.Split(separators, StringSplitOptions.RemoveEmptyEntries);
                            ////Paragraph firstpara = new Paragraph();
                            ////Paragraph secondpara = new Paragraph();
                            ////for (int i = 0; i < links.Count(); i++)
                            ////{
                            ////    if (i == 0)
                            ////    {

                            ////        ParagraphProperties firstpro = new ParagraphProperties();
                            ////        ParagraphStyleId firstpsid = firstpro.AppendChild(new ParagraphStyleId() { Val = "CT" });

                            ////        Run firstrun = new Run();
                            ////        RunProperties firstRp = firstrun.AppendChild(new RunProperties(new Bold()));
                            ////        Text firstparatext = new Text();
                            ////        string chpname = links[i] + ":";

                            ////        firstparatext.Text = chpname;

                            ////        firstrun.Append(firstparatext);
                            ////        firstpara.Append(firstpro);
                            ////        firstpara.Append(firstrun);
                            ////        P.InsertBeforeSelf(firstpara);
                            ////    }
                            ////    else
                            ////    {
                            ////        ParagraphProperties secondtpro = new ParagraphProperties();
                            ////        ParagraphStyleId secondpsid = secondtpro.AppendChild(new ParagraphStyleId() { Val = "CT" });

                            ////        Run secondtrun = new Run();
                            ////        RunProperties secondRp = secondtrun.AppendChild(new RunProperties(new Bold()));
                            ////        Text secondparatext = new Text();
                            ////        secondparatext.Text = links[i];
                            ////        secondtrun.Append(secondparatext);
                            ////        secondpara.Append(secondtpro);
                            ////        secondpara.Append(secondtrun);
                            ////        firstpara.InsertAfterSelf(secondpara);
                            ////        CTStylefound = true;
                            ////    }
                            ////}
                            ////P.Remove();
                            ////}
                            #endregion
                            if (P.ParagraphProperties != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId.Val.Value != null && P.ParagraphProperties.ParagraphStyleId.Val.Value != "")
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val.Value = "CT";
                                        CTStylefound = true;
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "CT" };
                                    CTStylefound = true;
                                }
                            }
                            else
                            {
                                P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "CT" });
                                CTStylefound = true;
                            }
                        }
                        else
                        {
                            if (counter == 0)
                            {
                                if (P.ParagraphProperties != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId != null)
                                    {
                                        if (P.ParagraphProperties.ParagraphStyleId.Val.Value != null && P.ParagraphProperties.ParagraphStyleId.Val.Value != "" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "TGAddressStart")
                                        {
                                            P.ParagraphProperties.ParagraphStyleId.Val.Value = "AbstractTravell";
                                            CTStylefound = true;
                                            counter++;
                                        }
                                        else
                                        {
                                            break;
                                        }
                                    }
                                    else
                                    {
                                        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "AbstractTravell" };
                                        CTStylefound = true;
                                        counter++;
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "AbstractTravell" });
                                    CTStylefound = true;
                                    counter++;
                                }
                            }
                        }

                    }
                }
                D.Save();
            }
        }
        public static void H1StyleaApply(string strDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument.Open(strDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    bool bBold = false;
                    bool bItalic = false;
                    bool bUnderline = false;

                    int nBold = 0;
                    int nItalic = 0;
                    int nUnderline = 0;

                    string strParaText = null;
                    foreach (Run R in P.Descendants<Run>().ToList())
                    {
                        strParaText = null;
                        foreach (Run R1 in P.Descendants<Run>().ToList())
                        {
                            foreach (Text T in R1.Descendants<Text>().ToList())
                            {
                                strParaText += T.Text;
                            }
                        }

                        if (strParaText != null)
                        {
                            if (strParaText.StartsWith("●") || strParaText.StartsWith("·") || strParaText.StartsWith("•") ||
                                                    strParaText.StartsWith("▪") || strParaText.StartsWith("■") || strParaText.StartsWith("") ||
                                                    strParaText.StartsWith("●") || strParaText.StartsWith("*") || strParaText.ToLower().Trim().StartsWith("references"))
                                continue;
                        }

                        if (R.RunProperties != null)
                        {
                            if (R.RunProperties.Bold != null && nBold == 0 && R.RunProperties.Bold.Val != "0")
                            {
                                if (R.RunProperties.Bold.Val == null)
                                {
                                    bBold = true;
                                }

                                else if (R.RunProperties.Bold.Val != "0")
                                {
                                    bBold = true;
                                }
                                else if (R.RunProperties.Bold.Val == "0")
                                {
                                    bBold = false;
                                }

                            }
                            ///New condition Added by Karan on 17-08-2018 Start
                            else if (R.RunProperties.RunStyle != null)
                            {
                                if (R.RunProperties.RunStyle.Val != null)
                                {
                                    if (R.RunProperties.RunStyle.Val == "Strong")
                                    {
                                        bBold = true;
                                    }
                                    else
                                    {
                                        nBold = 1;
                                        bBold = false;
                                    }
                                }
                            }
                            ///New condition Added by Karan on 17-08-2018 End
                            else
                            {
                                if (R.InnerText.Trim().Equals(".") || R.InnerText.Trim().Equals("-"))
                                {
                                    goto next;
                                }
                                if (R.InnerText.Trim() != "")
                                {
                                    bBold = false;
                                    nBold = 1;
                                }
                            }
                            if (R.RunProperties.Italic != null && nItalic == 0 && R.RunProperties.Italic.Val != "0")
                            {
                                bItalic = true;
                            }
                            ///New condition Added by Karan on 17-08-2018 Start
                            else if (R.RunProperties.RunStyle != null)
                            {
                                if (R.RunProperties.RunStyle.Val != null)
                                {
                                    if (R.RunProperties.RunStyle.Val == "Emphasis")
                                    {
                                        bItalic = true;
                                    }
                                    else
                                    {
                                        nItalic = 1;
                                        bItalic = false;
                                    }
                                }
                            }
                            ///New condition Added by Karan on 17-08-2018 End
                            else
                            {
                                if (R.InnerText.Trim().Equals(".") || R.InnerText.Trim().Equals("-"))
                                {
                                    goto next;
                                }
                                if (R.InnerText.Trim() != "")
                                {
                                    nItalic = 1;
                                    bItalic = false;
                                }
                            }
                            if (R.RunProperties.Underline != null && nUnderline == 0 && R.RunProperties.Underline.Val != null && R.RunProperties.Underline.Val != "0" &&
                                R.RunProperties.Underline.Val != "none")
                            {
                                bUnderline = true;
                            }
                            else
                            {
                                if (R.InnerText.Trim().Equals(".") || R.InnerText.Trim().Equals("-"))
                                {
                                    goto next;
                                }
                                if (R.InnerText.Trim() != "")
                                {
                                    nUnderline = 1;
                                    bUnderline = false;
                                }
                            }
                        }
                        next: { }
                    }
                    if (P.ParagraphProperties != null)
                    {
                        if (bBold == true && bItalic == false && bUnderline == false)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val = "H1";
                            }
                            else
                            {
                                P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId();
                                P.ParagraphProperties.ParagraphStyleId.Val = "H1";
                            }
                        }
                    }
                }
                D.Save();
            }
        }
        public static void BoxStyleApply(string strDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument.Open(strDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                bool foundpubboxstart = false;
                bool foundbxti = false;

                int counter = 0;
                Document D = MDP.Document;
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null &&
                         P.ParagraphProperties.ParagraphStyleId.Val == "PubBoxStart")
                    {
                        foundpubboxstart = true;
                        foundbxti = false;
                        counter++;
                        continue;
                    }
                    else if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null &&
                        P.ParagraphProperties.ParagraphStyleId.Val == "PubBoxEnd")
                    {
                        foundpubboxstart = false;
                        counter = 0;
                    }
                    if (foundpubboxstart)
                    {
                        if (P.InnerText != null && P.InnerText.Trim() != "")
                        {
                            if (counter == 1 && foundbxti == false)
                            {
                                if (P.ParagraphProperties != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId != null)
                                    {
                                        if (P.ParagraphProperties.ParagraphStyleId.Val.Value != null && P.ParagraphProperties.ParagraphStyleId.Val.Value != "")
                                        {
                                            P.ParagraphProperties.ParagraphStyleId.Val.Value = "BX-TI";
                                            foundbxti = true;
                                        }
                                    }
                                    else
                                    {
                                        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "BX-TI" };
                                        foundbxti = true;
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "BX-TI" });
                                    foundbxti = true;
                                }
                            }
                            else
                            {
                                if (P.ParagraphProperties != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId != null)
                                    {
                                        if (P.ParagraphProperties.ParagraphStyleId.Val.Value != null && P.ParagraphProperties.ParagraphStyleId.Val.Value != "")
                                        {
                                            P.ParagraphProperties.ParagraphStyleId.Val.Value = "BX-TXT";
                                        }
                                    }
                                    else
                                    {
                                        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "BX-TXT" };
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "BX-TXT" });
                                }
                            }
                        }
                    }
                }
                D.Save();
            }
        }
        public static void FigStyleApply(string strDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument.Open(strDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P != null)
                    {
                        if (P.InnerText != null && P.InnerText.Trim() != "")
                        {
                            if (P.InnerText.Trim().ToLower().StartsWith("[insert image") && P.InnerText.Trim().ToLower().EndsWith("]"))
                            {
                                if (P.ParagraphProperties != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId != null)
                                    {
                                        if (P.ParagraphProperties.ParagraphStyleId.Val.Value != null && P.ParagraphProperties.ParagraphStyleId.Val.Value != "")
                                        {
                                            P.ParagraphProperties.ParagraphStyleId.Val.Value = "FIGC";
                                        }
                                    }
                                    else
                                    {
                                        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "FIGC" };
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "FIGC" });
                                }
                            }
                            else if (P.InnerText.Trim().ToLower().Contains("[tooltip"))
                            {
                                string a = P.InnerText;

                                var item = P.Descendants<ParagraphProperties>().ToList();

                                string[] words = a.Split('[', ']');
                                Paragraph firstpara = new Paragraph();
                                firstpara.ParagraphProperties = new ParagraphProperties();
                                foreach (var ppr in item)
                                {
                                    firstpara.Append(ppr.CloneNode(true));
                                }


                                for (int i = 0; i < words.Count(); i++)
                                {
                                    Run r = new Run();
                                    if (words[i] != null && words[i].Trim() != "" && words[i].Contains("Tooltip"))
                                    {

                                        r.RunProperties = new RunProperties();
                                        r.RunProperties.RunStyle = new RunStyle { Val = "Tooltipcite" };

                                        Text firstparatext = new Text();

                                        words[i] = words[i].Trim().Replace("Tooltip:", "");

                                        string withtooltiptext = words[i];

                                        firstparatext.Text = withtooltiptext;

                                        r.Append(firstparatext);

                                    }
                                    else if (words[i] == "")
                                    {
                                        continue;
                                    }
                                    else
                                    {
                                        Text firstparatext = new Text();
                                        string withouttooltiptext = words[i];
                                        firstparatext.Text = withouttooltiptext;
                                        r.Append(firstparatext);

                                    }
                                    firstpara.Append(r);
                                }
                                P.InsertAfterSelf(firstpara);
                                //firstpara.InsertAfterSelf(P.CloneNode(true));
                                P.Remove();
                            }
                            else if (P.InnerText.Trim().ToLower().StartsWith("[insert video") && P.InnerText.Trim().ToLower().EndsWith("]"))
                            {
                                if (P.ParagraphProperties != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId != null)
                                    {
                                        if (P.ParagraphProperties.ParagraphStyleId.Val.Value != null && P.ParagraphProperties.ParagraphStyleId.Val.Value != "")
                                        {
                                            P.ParagraphProperties.ParagraphStyleId.Val.Value = "VIDEOC";
                                        }
                                    }
                                    else
                                    {
                                        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "VIDEOC" };
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "VIDEOC" });
                                }
                            }
                            else if (P.InnerText.Trim().ToLower().Contains("[imageref"))
                            {
                                string a = P.InnerText;

                                var item = P.Descendants<ParagraphProperties>().ToList();

                                string[] words = a.Split('[', ']');
                                Paragraph firstpara = new Paragraph();
                                firstpara.ParagraphProperties = new ParagraphProperties();
                                foreach (var ppr in item)
                                {
                                    firstpara.Append(ppr.CloneNode(true));
                                }


                                for (int i = 0; i < words.Count(); i++)
                                {
                                    Run r = new Run();
                                    if (words[i] != null && words[i].Trim() != "" && words[i].Contains("Imageref"))
                                    {

                                        r.RunProperties = new RunProperties();
                                        r.RunProperties.RunStyle = new RunStyle { Val = "Imageref" };

                                        Text firstparatext = new Text();

                                        words[i] = words[i].Trim().Replace("Imageref:", "");

                                        string withtooltiptext = words[i];

                                        firstparatext.Text = withtooltiptext;

                                        r.Append(firstparatext);

                                    }
                                    else if (words[i] == "")
                                    {
                                        continue;
                                    }
                                    else
                                    {
                                        Text firstparatext = new Text();
                                        string withouttooltiptext = words[i];
                                        firstparatext.Text = withouttooltiptext;
                                        r.Append(firstparatext);

                                    }
                                    firstpara.Append(r);

                                }
                                P.InsertAfterSelf(firstpara);
                                //firstpara.InsertAfterSelf(P.CloneNode(true));
                                P.Remove();
                            }
                            else if (P.InnerText.Trim().ToLower().Contains("[insert audio"))
                            {
                                string a = P.InnerText;

                                var item = P.Descendants<ParagraphProperties>().ToList();

                                a = a.Replace("[Insert Audio", "Insert Audio").Replace(".wav]", ".wav");


                                string[] words = a.Split('[', ']');
                                Paragraph firstpara = new Paragraph();
                                firstpara.ParagraphProperties = new ParagraphProperties();
                                foreach (var ppr in item)
                                {
                                    firstpara.Append(ppr.CloneNode(true));
                                }


                                for (int i = 0; i < words.Count(); i++)
                                {
                                    bool rfound = false;

                                    Run r = new Run();
                                    if (words[i] != null && words[i].Trim() != "" && words[i].ToLower().Contains("insert audio"))
                                    {
                                        //MERIAN Tipp Insert Audio: 1.wav

                                        if (words[i].StartsWith("Insert Audio:"))
                                        {

                                            r.RunProperties = new RunProperties();
                                            r.RunProperties.RunStyle = new RunStyle { Val = "Audioref1" };

                                            Text firstparatext = new Text();
                                            string withtooltiptext = words[i];

                                            firstparatext.Text = withtooltiptext;

                                            r.Append(firstparatext);
                                        }
                                        else
                                        {
                                            string abc=words[i];

                                            string[] audiostring = abc.Split(new string[]{ "Insert Audio:"},StringSplitOptions.None);


                                            for (int j = 0; j < audiostring.Count(); j++)
                                            {
                                                if (audiostring[j].Contains(".wav"))
                                                {
                                                    r = new Run();
                                                    r.RunProperties = new RunProperties();
                                                    r.RunProperties.RunStyle = new RunStyle { Val = "Audioref1" };

                                                    Text firstparatext = new Text();
                                                    string withtooltiptext = "Insert Audio: " + audiostring[j];

                                                    firstparatext.Text = withtooltiptext;

                                                    r.Append(firstparatext);
                                                    firstpara.Append(r);
                                                    rfound = true;
                                                }
                                                else
                                                {
                                                    r = new Run();
                                                    Text firstparatext = new Text();
                                                    string withtooltiptext = audiostring[j];

                                                    firstparatext.Text = withtooltiptext;

                                                    r.Append(firstparatext);
                                                    firstpara.Append(r);
                                                    rfound = true;
                                                }
                                            }
                                            
                                        }

                                    }
                                    else if (words[i] == "")
                                    {
                                        continue;
                                    }
                                    else
                                    {
                                        Text firstparatext = new Text();
                                        string withouttooltiptext = null;
                                        if (words[i].StartsWith("Insert InlineGraphics"))
                                        {
                                            withouttooltiptext ="[" +words[i]+"]";
                                        }
                                        else
                                        {
                                            withouttooltiptext = words[i];
                                        }
                                         
                                        firstparatext.Text = withouttooltiptext;
                                        r.Append(firstparatext);

                                    }
                                    if(!rfound)
                                    firstpara.Append(r);

                                }
                                P.InsertAfterSelf(firstpara);
                                //firstpara.InsertAfterSelf(P.CloneNode(true));
                                P.Remove();
                            }
                        }
                    }
                }
                D.Save();
            }
        }
        public static void Txt_1StyleApply(string strDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument.Open(strDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                bool bstylefound = false;
                int counter = 0;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null
                       && (P.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower().EndsWith("end") || P.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower().EndsWith("start")))
                    {
                        bstylefound = false;
                        continue;
                    }
                    else if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null)
                    {
                        if (P.ParagraphProperties.ParagraphStyleId.Val == "CT" || P.ParagraphProperties.ParagraphStyleId.Val == "H1" || P.ParagraphProperties.ParagraphStyleId.Val == "AbstractTravell")
                        {
                            counter = 0;
                            bstylefound = true;
                            counter++;
                            continue;
                        }
                    }
                    if (bstylefound)
                    {
                        if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val == "FIGC")
                        {
                            continue;
                        }
                        else
                        {
                            if (counter == 1)////for TXT Style
                            {
                                if (P.ParagraphProperties != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId != null)
                                    {
                                        if (P.ParagraphProperties.ParagraphStyleId.Val.Value != null && P.ParagraphProperties.ParagraphStyleId.Val.Value != "")
                                        {
                                            P.ParagraphProperties.ParagraphStyleId.Val.Value = "TXT";
                                            counter++;
                                        }
                                    }
                                    else
                                    {
                                        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "TXT" };
                                        counter++;
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "TXT" });
                                    counter++;
                                }
                            }
                            else////for TXT-2 Style
                            {
                                if (P.ParagraphProperties != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId != null)
                                    {
                                        if (P.ParagraphProperties.ParagraphStyleId.Val.Value != null && P.ParagraphProperties.ParagraphStyleId.Val.Value != "")
                                        {
                                            P.ParagraphProperties.ParagraphStyleId.Val.Value = "TXT-2";
                                        }
                                    }
                                    else
                                    {
                                        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "TXT-2" };
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "TXT-2" });
                                }
                            }
                        }
                    }
                }
                D.Save();
            }
        }
        public static void QuoteStyleApply(string strDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument.Open(strDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                bool Quotestylefound = false;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null &&
                          P.ParagraphProperties.ParagraphStyleId.Val == "QuoteStart")
                    {
                        Quotestylefound = true;
                        continue;
                    }
                    else if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null &&
                        P.ParagraphProperties.ParagraphStyleId.Val == "QuoteEnd")
                    {
                        Quotestylefound = false;
                    }
                    if (Quotestylefound)
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId.Val.Value != null && P.ParagraphProperties.ParagraphStyleId.Val.Value != "")
                                {
                                    P.ParagraphProperties.ParagraphStyleId.Val.Value = "TravellQuote";
                                }
                            }
                            else
                            {
                                P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "TravellQuote" };
                            }
                        }
                        else
                        {
                            P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "TravellQuote" });
                        }
                    }
                }
                D.Save();
            }
        }


        public static void Top_TenStyle(string strDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument.Open(strDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;
                Document D = MDP.Document;

                bool tgtoptenstylefound = false;
                bool tgattractionfound = false;

                bool tgeatanddrinkfound = false;
                bool tgeveningfound = false;
                bool tgshoppingfound = false;

                bool tgblueboxfound = false;
                bool bxtistyleapply = false;

                bool tgtoptenbluefound = false;

                bool tgaddressfound = false;

                foreach (var item in D.Descendants<Paragraph>().ToList().Where(a => a.ParagraphProperties != null
                && a.ParagraphProperties.ParagraphStyleId != null
                && a.ParagraphProperties.ParagraphStyleId.Val != null))
                {
                    if (item.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower().EndsWith("toptenstart")/*item.ParagraphProperties.ParagraphStyleId.Val == "TGToptenStart"*/)
                    {
                        tgtoptenstylefound = true;
                        continue;
                    }
                    else if (item.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower().EndsWith("toptenend")/*item.ParagraphProperties.ParagraphStyleId.Val == "TGToptenEnd"*/)
                    {
                        tgtoptenstylefound = false;
                        continue;
                    }
                    else if (item.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower().EndsWith("attractionstart")/*item.ParagraphProperties.ParagraphStyleId.Val == "TGAttractionStart"*/)
                    {
                        tgattractionfound = true;
                        continue;
                    }
                    else if (item.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower().EndsWith("attractionend")/*item.ParagraphProperties.ParagraphStyleId.Val == "TGAttractionEnd"*/)
                    {
                        tgattractionfound = false;
                        continue;
                    }

                    else if (item.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower().EndsWith("eatdrinkstart")/*item.ParagraphProperties.ParagraphStyleId.Val == "TGEatandDrinkStart"*/)
                    {
                        tgeatanddrinkfound = true;
                        continue;
                    }
                    else if (item.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower().EndsWith("eatdrinkend")/*item.ParagraphProperties.ParagraphStyleId.Val == "TGEatandDrinkEnd"*/)
                    {
                        tgeatanddrinkfound = false;
                        continue;
                    }
                    else if (item.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower().EndsWith("eveningstart")/*item.ParagraphProperties.ParagraphStyleId.Val == "TGEveningStart"*/)
                    {
                        tgeveningfound = true;
                        continue;
                    }
                    else if (item.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower().EndsWith("eveningend")/*item.ParagraphProperties.ParagraphStyleId.Val == "TGEveningEnd"*/)
                    {
                        tgeveningfound = false;
                        continue;
                    }
                    else if (item.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower().EndsWith("shoppingstart")/*item.ParagraphProperties.ParagraphStyleId.Val == "TGShoppingStart"*/)
                    {
                        tgshoppingfound = true;
                        continue;
                    }
                    else if (item.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower().EndsWith("shoppingend")/*item.ParagraphProperties.ParagraphStyleId.Val == "TGShoppingEnd"*/)
                    {
                        tgshoppingfound = false;
                        continue;
                    }
                    else if (item.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower().EndsWith("blueboxstart")/*item.ParagraphProperties.ParagraphStyleId.Val == "TGBlueBoxStart"*/)
                    {
                        tgblueboxfound = true;
                        continue;
                    }
                    else if (item.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower().EndsWith("blueboxend")/*item.ParagraphProperties.ParagraphStyleId.Val == "TGBlueBoxEnd"*/)
                    {
                        tgblueboxfound = false;
                        continue;
                    }
                    else if (item.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower().EndsWith("toptenbluestart")/*item.ParagraphProperties.ParagraphStyleId.Val == "TGTopTenBlueStart"*/)
                    {
                        tgtoptenbluefound = true;
                        continue;
                    }
                    else if (item.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower().EndsWith("toptenblueend")/*item.ParagraphProperties.ParagraphStyleId.Val == "TGTopTenBlueEnd"*/)
                    {
                        tgtoptenbluefound = false;
                        continue;
                    }
                    else if (item.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower().EndsWith("addressstart")/*item.ParagraphProperties.ParagraphStyleId.Val == "TGAddressStart"*/)
                    {
                        tgaddressfound = true;
                        continue;
                    }
                    else if (item.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower().EndsWith("addressend")/*item.ParagraphProperties.ParagraphStyleId.Val == "TGAddressEnd"*/)
                    {
                        tgaddressfound = false;
                        continue;
                    }



                    if (tgtoptenstylefound)
                    {
                        if (item.ParagraphProperties.ParagraphStyleId.Val == "H1" || item.ParagraphProperties.ParagraphStyleId.Val == "H2")
                        {
                            item.ParagraphProperties.ParagraphStyleId.Val = "TopTenheader";
                        }
                        else if (item.ParagraphProperties.ParagraphStyleId.Val != "FIGC")
                        {
                            item.ParagraphProperties.ParagraphStyleId.Val = "TopTenBodyPara";
                        }
                    }
                    else if (tgattractionfound)
                    {
                        if (item.ParagraphProperties.ParagraphStyleId.Val == "H1" || item.ParagraphProperties.ParagraphStyleId.Val == "H2")
                        {
                            item.ParagraphProperties.ParagraphStyleId.Val = "Attractionheader";
                        }
                        else if (item.ParagraphProperties.ParagraphStyleId.Val != "FIGC")
                        {
                            item.ParagraphProperties.ParagraphStyleId.Val = "AttractionBodyPara";
                        }
                    }
                    else if (tgeatanddrinkfound)
                    {
                        if (item.ParagraphProperties.ParagraphStyleId.Val == "H1" || item.ParagraphProperties.ParagraphStyleId.Val == "H2")
                        {
                            item.ParagraphProperties.ParagraphStyleId.Val = "EatandDrinkheader";
                        }
                        else if (item.ParagraphProperties.ParagraphStyleId.Val != "FIGC")
                        {
                            item.ParagraphProperties.ParagraphStyleId.Val = "EatandDrinkBodyPara";
                        }
                    }
                    else if (tgeveningfound)
                    {
                        if (item.ParagraphProperties.ParagraphStyleId.Val == "H1" || item.ParagraphProperties.ParagraphStyleId.Val == "H2")
                        {
                            item.ParagraphProperties.ParagraphStyleId.Val = "Eveningheader";
                        }
                        else if (item.ParagraphProperties.ParagraphStyleId.Val != "FIGC")
                        {
                            item.ParagraphProperties.ParagraphStyleId.Val = "EveningBodyPara";
                        }
                    }
                    else if (tgshoppingfound)
                    {
                        if (item.ParagraphProperties.ParagraphStyleId.Val == "H1" || item.ParagraphProperties.ParagraphStyleId.Val == "H2")
                        {
                            item.ParagraphProperties.ParagraphStyleId.Val = "Shoppingheader";
                        }
                        else if (item.ParagraphProperties.ParagraphStyleId.Val != "FIGC")
                        {
                            item.ParagraphProperties.ParagraphStyleId.Val = "ShoppingBodyPara";
                        }
                    }
                    else if (tgblueboxfound)
                    {
                        if (item.ParagraphProperties.ParagraphStyleId.Val != null && bxtistyleapply == false)
                        {
                            item.ParagraphProperties.ParagraphStyleId.Val = "BX-TI";
                            bxtistyleapply = true;
                        }
                        else if (item.ParagraphProperties.ParagraphStyleId.Val != "FIGC" && bxtistyleapply == true)
                        {
                            item.ParagraphProperties.ParagraphStyleId.Val = "BX-TXT";
                        }
                    }
                    else if (tgtoptenbluefound)
                    {
                        if (item.ParagraphProperties.ParagraphStyleId.Val == "H1" || item.ParagraphProperties.ParagraphStyleId.Val == "H2")
                        {
                            item.ParagraphProperties.ParagraphStyleId.Val = "TopTenBlueheader";
                        }
                        else if (item.ParagraphProperties.ParagraphStyleId.Val != "FIGC")
                        {
                            item.ParagraphProperties.ParagraphStyleId.Val = "TopTenBlueBodyPara";
                        }
                    }

                    else if (tgaddressfound)
                    {
                        if (item.InnerText.Trim().ToLower().StartsWith("[insert map"))
                        {
                            item.ParagraphProperties.ParagraphStyleId.Val = "AddressMapInline";
                        }
                        else if (item.ParagraphProperties.ParagraphStyleId.Val != null)
                        {
                            item.ParagraphProperties.ParagraphStyleId.Val = "AddressPara";
                        }
                    }
                }
                D.Save();
            }
        }

    }
}
