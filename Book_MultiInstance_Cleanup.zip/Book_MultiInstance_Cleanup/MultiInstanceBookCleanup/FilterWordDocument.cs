﻿using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;
using OpenXmlPowerTools;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;

namespace MultiInstanceBookCleanup
{
    class FilterWordDocument
    {
        public static object OpenPT { get; private set; }

        public static void CleanWordDocument(string strWordDocPath, string strRemoveCharStyleFilename)
        {
            //RemovePageBreaks(strWordDocPath);

            //RemoveBlankPara(strWordDocPath);

            List<string> strCharacterStyleColl;

            strCharacterStyleColl = GlobalMethods.ReadAndStoreFileValuesInArray(strRemoveCharStyleFilename);

            RemoveUnwantedStylesFromDocument(strWordDocPath, strCharacterStyleColl);
        }

        private static void RemoveUnwantedStylesFromDocument(string newDoc, List<string> strCharacterStyleColl)
        {
            if(strCharacterStyleColl.Count > 0)
            {
                using (WordprocessingDocument WPD = WordprocessingDocument
                    .Open(newDoc, true))
                {
                    SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                    {
                        //RemoveComments = false,
                        RemoveContentControls = true,
                        RemoveEndAndFootNotes = false,
                        RemoveFieldCodes = false,
                        RemoveLastRenderedPageBreak = true,
                        RemovePermissions = true,
                        RemoveProof = true,
                        RemoveRsidInfo = true,
                        RemoveSmartTags = true,
                        RemoveSoftHyphens = false,
                        ReplaceTabsWithSpaces = false,
                    };

                    MarkupSimplifier.SimplifyMarkup(WPD, settings);

                    MainDocumentPart MDP = WPD.MainDocumentPart;

                    Document D = MDP.Document;

                    int counter = 0;

                    string prevStyleID = null;

                    for(counter = 0; counter < strCharacterStyleColl.Count; counter++)
                    {
                        foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                        {
                            if (P.HasChildren == true)
                            {
                                try
                                {
                                    if(P.ParagraphProperties != null)
                                    {
                                        if (P.ParagraphProperties.ParagraphStyleId != null)
                                        {
                                            if (P.ParagraphProperties.ParagraphStyleId.Val == "NoteText")
                                            {
                                                if(prevStyleID.ToLower() == "caption")
                                                {
                                                    P.ParagraphProperties.ParagraphStyleId.Val = "BodyA";
                                                }

                                                prevStyleID = P.ParagraphProperties.ParagraphStyleId.Val;
                                            }
                                            else
                                            {
                                                prevStyleID = P.ParagraphProperties.ParagraphStyleId.Val;
                                            }
                                        }
                                        else
                                        {
                                            prevStyleID = "";
                                        }
                                    }
                                    else
                                    {
                                        prevStyleID = "";
                                    }

                                    foreach (Run R in P.Descendants<Run>().ToList().
                                     Where(e => e.RunProperties != null
                                    && e.RunProperties.RunStyle.LocalName != null
                                    && e.RunProperties.RunStyle.Val == strCharacterStyleColl[counter]))
                                    {
                                        R.RunProperties.RunStyle.Val = "";
                                    }
                                }
                                catch (Exception ex)
                                {
                                    Console.WriteLine(ex.Message);
                                }
                            }
                        }
                    }

                    D.Save();
                }
            }
        }

        private static void ReplaceNoBreakHypenWithHypen(string newDoc)
        {
            using (WordprocessingDocument wDoc = WordprocessingDocument.Open(newDoc, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    //RemoveComments = false,
                    RemoveContentControls = true,
                    RemoveEndAndFootNotes = false,
                    RemoveFieldCodes = false,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = false,
                };

                MarkupSimplifier.SimplifyMarkup(wDoc, settings);

                var xDoc = wDoc.MainDocumentPart.GetXDocument();

                XmlDocument xd = xDoc.GetXmlDocument();

                xd.LoadXml(xd.InnerXml);

                XmlNodeList nodeList;
                XmlNamespaceManager ns = new XmlNamespaceManager(xd.NameTable);
                ns.AddNamespace("w", "http://schemas.openxmlformats.org/wordprocessingml/2006/main");

                XmlNode root = xd.DocumentElement;

                nodeList = root.SelectNodes("w:body//w:p//w:r", ns);

                XElement xe = null;

                bool bNonBreakHypenFound = false;

                foreach (XmlNode book in nodeList)
                {
                    XmlNode nodeParent = book.ParentNode;

                    xe = book.GetXElement();

                    if (xe.HasElements)
                    {
                        //bNonBreakHypenFound = false;
                        foreach (XElement xee in xe.Elements().ToList())
                        {
                            if (xee.Name == W.noBreakHyphen)
                            {
                                bNonBreakHypenFound = true;
                                xe.Remove();
                                book.InnerXml = "";
                                continue;
                            }

                            if (xee.Name == W.t)
                            {
                                if(bNonBreakHypenFound == true)
                                {
                                    xee.Value = "-" + xee.Value;
                                    book.InnerXml = ((System.Xml.XmlDocument)(xe.GetXmlNode())).DocumentElement.InnerXml;
                                    bNonBreakHypenFound = false;
                                }
                                continue;
                            }
                        } // foreach (XElement xee in xe.Elements())

                    }//if (xee.HasElements)

                }

                wDoc.MainDocumentPart.PutXDocument(xd.GetXDocument());

            } // End of Word Processing

        }

        private static void RemoveBlankPara(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                .Open(newDoc, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    //NormalizeXml = true,
                    RemoveHyperlinks = false,
                    //RemoveComments = false,
                    RemoveContentControls = true,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = false,

                    RemoveEndAndFootNotes = false,
                    RemoveFieldCodes = false,
                    AcceptRevisions = true,
                    RemoveBookmarks = true,
                    RemoveGoBackBookmark = true,
                    RemoveWebHidden = true,
                    RemoveMarkupForDocumentComparison = true,
                };

                MarkupSimplifier.SimplifyMarkup(WPD, settings);

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    bool bContentsText = IsParaEmpty(P);

                    if (bContentsText == false)
                    {
                        P.Remove();
                        continue;
                    }

                    if (P.HasChildren == false)
                    {
                        try
                        {
                            P.Remove();
                        }
                        catch(Exception ex)
                        {
                            Console.WriteLine("Error");
                        }
                    }
                }

                D.Save();
            }
        }

        private static bool IsParaEmpty(Paragraph P)
        {
            if (P.HasChildren == true)
            {
                if (P.ParagraphProperties != null)
                {
                    if (P.ParagraphProperties.ParagraphStyleId != null)
                    {
                        foreach (Run R in P.Descendants<Run>().ToList())
                        {
                            foreach (Text T in R.Descendants<Text>().ToList())
                            {
                                return true;
                            }
                        }

                        return true;
                    }
                    else
                    {
                        foreach (Run R in P.Descendants<Run>().ToList())
                        {
                            foreach (Text T in R.Descendants<Text>().ToList())
                            {
                                return true;
                            }
                        }
                    }
                }
            }

            return false;
        }

        private static void RemovePageBreaks(string filename)
        {

            using (WordprocessingDocument myDoc = WordprocessingDocument.Open(filename, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    //NormalizeXml = true,
                    //RemoveComments = false,
                    RemoveContentControls = true,
                    RemoveEndAndFootNotes = false,
                    RemoveFieldCodes = false,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = false,
                    AcceptRevisions = true,
                    RemoveBookmarks = true,
                    RemoveGoBackBookmark = true,
                    RemoveWebHidden = true,
                };

                MarkupSimplifier.SimplifyMarkup(myDoc, settings);

                MainDocumentPart mainPart = myDoc.MainDocumentPart;

                List<Hyperlink> hlinks = mainPart.Document.Descendants<Hyperlink>().ToList();

                foreach (Hyperlink h in hlinks)
                {
                    h.Remove();
                }

                mainPart.Document.Save();
            }
        }
    }
}
