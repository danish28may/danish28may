﻿using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;
using OpenXmlPowerTools;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MultiInstanceBookCleanup
{
    class StyleMappingNew
    {
        public static void Edisis(string strDoc, string strEdisisMappingFile)
        {
            List<string> strValidParagraphStyles = new List<string>();
            strValidParagraphStyles = GlobalMethods.ReadAndStoreFileValuesInArray(strEdisisMappingFile);

            using (WordprocessingDocument WPD = WordprocessingDocument
                                                .Open(strDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P != null)
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null)
                            {
                                string getstylename = P.ParagraphProperties.ParagraphStyleId.Val;

                                foreach (var item in strValidParagraphStyles.ToList())
                                {
                                    string[] separators = { "|" };
                                    string[] links = item.Split(separators, StringSplitOptions.RemoveEmptyEntries);

                                    if (links[0] != null && links[0].Trim() == getstylename)
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val.Value = links[1];
                                        goto nextpara;
                                    }
                                }
                            }
                        }
                    }
                nextpara:
                    {

                    }
                }
                D.Save();
            }
        }
        public static void ApplyBullList(string strDoc)
        {

            using (WordprocessingDocument WPD = WordprocessingDocument
                                               .Open(strDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                string strParaText = null;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P.Descendants<Run>().Count() > 0)
                    {
                        if (P.Parent != null)
                        {
                            if (P.Parent.LocalName != null)
                            {
                                if (P.Parent.LocalName == "body")
                                {
                                    strParaText = null;

                                    foreach (Run R in P.Descendants<Run>().ToList())
                                    {
                                        foreach (DocumentFormat.OpenXml.OpenXmlElement ox in R.Elements())
                                        {
                                            if (ox.XName == W.tab)
                                            {
                                                strParaText += "\u0009";
                                            }
                                        }

                                        foreach (Text T in R.Descendants<Text>().ToList())
                                        {
                                            strParaText += T.Text;
                                        }
                                    }

                                    if (strParaText != null)
                                    {

                                        if (P.ParagraphProperties!=null && P.ParagraphProperties.ParagraphStyleId!=null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val == "LargeBullList")
                                        {

                                            if (strParaText.StartsWith("●") || strParaText.StartsWith("·") || strParaText.StartsWith("●") || strParaText.StartsWith("•"))
                                            {
                                                P.ParagraphProperties.ParagraphStyleId.Val = "BullList";
                                            }
                                        }
                                    }

                                }
                            }
                        }
                    }
                }
                D.Save();

            }
        } ///added by bhavesh
        // added by aarti 29-1-2019 start
        public static void ApplyQuote(string strDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                                               .Open(strDoc, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    //RemoveComments = false,
                    RemoveContentControls = true,
                    RemoveEndAndFootNotes = false,
                    RemoveFieldCodes = false,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = false,
                };
                MarkupSimplifier.SimplifyMarkup(WPD, settings);
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                string strParaText = null;
                //  bool ext = false;
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P.Descendants<Run>().Count() > 0)
                    {
                        if (P.Parent != null)
                        {
                            if (P.Parent.LocalName != null)
                            {
                                if (P.Parent.LocalName == "body")
                                {
                                    strParaText = null;

                                    foreach (Run R in P.Descendants<Run>().ToList())
                                    {

                                        foreach (Text T in R.Descendants<Text>().ToList())
                                        {
                                            strParaText += T.Text;
                                        }
                                    }

                                    if (strParaText != null)
                                    {
                                        //  var indent = "";
                                        if (P.ParagraphProperties!=null && P.ParagraphProperties.ParagraphStyleId!=null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val == "EXT")
                                        {
                                            P.ParagraphProperties.ParagraphStyleId.Val = "3CMQuote"; 
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                D.Save();

            }
        }
        // 29-1-2019 aarti end

    }
}
