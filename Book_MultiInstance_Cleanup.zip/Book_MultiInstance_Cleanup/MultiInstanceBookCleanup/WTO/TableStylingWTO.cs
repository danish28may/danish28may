﻿using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;
using OpenXmlPowerTools;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;

namespace CleanupMarkup
{
    class TableStylingWTO
    {
        static List<string> strTableFootnoteText = new List<string>();

        public static void AdditionalWordMarkup(string newDoc)
        {
             // Table Styling and Table Footnote handling Starts //
            strTableFootnoteText.Clear();
           

            ApplyTableStyling(newDoc);

            ApplyTableFootnoteLabel(newDoc);

            ApplyTableStylingForGroupTables(newDoc);

            ApplyTableCitation(newDoc);
            strTableFootnoteText.Clear();
            
            // Table Styling and Table Footnote handling Ends //


            // Box Footnote handling Starts //
            strTableFootnoteText.Clear();
            ApplyBoxFootnoteLabel(newDoc);
            ApplyBoxCitation(newDoc);
            strTableFootnoteText.Clear();
            // Table Styling and Table Footnote handling Ends //



            //ExtractTableLabelText(newDoc); // not required now new method developed///
            //ApplyTableFootnote(newDoc); // not required now
        }

        private static void ApplyBoxFootnoteLabel(string newDoc)
        {
            strTableFootnoteText.Clear();

            int counter = 0;
            int nIndex = 0;
            bool bStyleFound = false;
            int lcounter = 0;


            using (WordprocessingDocument WPD = WordprocessingDocument
                            .Open(newDoc, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    RemoveComments = true,
                    RemoveContentControls = true,
                    RemoveEndAndFootNotes = false,
                    //RemoveFieldCodes = false,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = true,
                };

                MarkupSimplifier.SimplifyMarkup(WPD, settings);

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                counter = 0;
                nIndex = 0;
                lcounter = 0;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    try
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId.Val != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId.Val == "BX-FTN")
                                    {
                                        if (P.HasChildren == true)
                                        {
                                            try
                                            {
                                                List<OpenXmlElement> RList = P.Descendants<OpenXmlElement>().ToList();

                                                counter = 0;
                                                nIndex = 0;
                                                lcounter = 0;

                                                foreach (OpenXmlElement R in RList)
                                                {
                                                    if (R.LocalName != null)
                                                    {
                                                        if (R.LocalName.ToLower() == "rstyle")
                                                        {
                                                            string str = R.LocalName;

                                                            string Style = ((DocumentFormat.OpenXml.Wordprocessing.String253Type)R).Val;

                                                            if (Style != null)
                                                            {
                                                                lcounter = 0;
                                                                if (Style == "label-bxftn")
                                                                {
                                                                    lcounter = nIndex;
                                                                    bStyleFound = true;
                                                                }

                                                                if (Style == "Hyperlink")
                                                                {
                                                                    counter = nIndex;
                                                                    ((DocumentFormat.OpenXml.Wordprocessing.String253Type)R).Val = "weblinks";
                                                                    ((DocumentFormat.OpenXml.Wordprocessing.String253Type)(RList.ElementAt(counter))).Val = ((DocumentFormat.OpenXml.Wordprocessing.String253Type)R).Val;
                                                                }
                                                            }
                                                        }
                                                        else if (R.LocalName.ToLower() == "t")
                                                        {
                                                            if (bStyleFound == false)
                                                            {
                                                                string Value = ((DocumentFormat.OpenXml.OpenXmlLeafTextElement)R).Text;

                                                                bStyleFound = false;
                                                                if (Value.StartsWith(".."))
                                                                {
                                                                    if (Value.Trim().Length > 2)
                                                                    {
                                                                        // Split the content into two Run
                                                                        Run run = new Run(new RunProperties(new RunStyle() { Val = "label-bxftn" }));
                                                                        run.AppendChild(new Text(".."));

                                                                        R.Parent.InsertBeforeSelf(run);

                                                                        Value = Value.Substring(2, Value.Length - 2);
                                                                        if (Value.StartsWith(" "))
                                                                        {
                                                                            ((DocumentFormat.OpenXml.OpenXmlLeafTextElement)R).Text = Value.TrimStart();
                                                                            Run run1 = new Run(new RunProperties());
                                                                            Text T = new Text(" ") { Space = SpaceProcessingModeValues.Preserve };
                                                                            run1.AppendChild(T);
                                                                            run.InsertAfterSelf(run1);
                                                                        }
                                                                        else
                                                                        {
                                                                            ((DocumentFormat.OpenXml.OpenXmlLeafTextElement)R).Text = Value;
                                                                        }
                                                                    }
                                                                    else
                                                                    {
                                                                        if (Value.EndsWith(" "))
                                                                        {
                                                                            if (((DocumentFormat.OpenXml.Wordprocessing.Run)R.Parent).RunProperties != null)
                                                                            {
                                                                                Run run = new Run(new RunStyle() { Val = "label-bxftn" });
                                                                                run.AppendChild(new Text(Value.Trim()));
                                                                                R.Parent.InsertBeforeSelf(run);
                                                                                R.Remove();

                                                                                Run run1 = new Run(new RunProperties());
                                                                                Text T = new Text(" ") { Space = SpaceProcessingModeValues.Preserve };
                                                                                run1.AppendChild(T);
                                                                                run.InsertAfterSelf(run1);
                                                                            }
                                                                            else
                                                                            {
                                                                                Run run = new Run(new RunProperties(new RunStyle() { Val = "label-bxftn" }));
                                                                                run.AppendChild(new Text(Value.Trim()));
                                                                                R.Parent.InsertBeforeSelf(run);
                                                                                R.Remove();

                                                                                Run run1 = new Run(new RunProperties());
                                                                                Text T = new Text(" ") { Space = SpaceProcessingModeValues.Preserve };
                                                                                run1.AppendChild(T);
                                                                                run.InsertAfterSelf(run1);
                                                                            }
                                                                        }
                                                                        else
                                                                        {
                                                                            if (((DocumentFormat.OpenXml.Wordprocessing.Run)R.Parent).RunProperties != null)
                                                                            {
                                                                                Run run = new Run(new RunStyle() { Val = "label-bxftn" });
                                                                                run.AppendChild(new Text(Value));
                                                                                R.Parent.InsertBeforeSelf(run);
                                                                                R.Remove();
                                                                            }
                                                                            else
                                                                            {
                                                                                Run run = new Run(new RunProperties(new RunStyle() { Val = "label-bxftn" }));
                                                                                run.AppendChild(new Text(Value));
                                                                                R.Parent.InsertBeforeSelf(run);
                                                                                R.Remove();
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                                else if (Value.StartsWith("n.a."))
                                                                {
                                                                    if (Value.Trim().Length > 4)
                                                                    {
                                                                        // Split the content into two Run
                                                                        Run run = new Run(new RunProperties(new RunStyle() { Val = "label-bxftn" }));
                                                                        run.AppendChild(new Text("n.a."));
                                                                        R.Parent.InsertBeforeSelf(run);

                                                                        // Remove the character from the starting text
                                                                        Value = Value.Substring(4, Value.Length - 4);

                                                                        if (Value.StartsWith(" "))
                                                                        {
                                                                            ((DocumentFormat.OpenXml.OpenXmlLeafTextElement)R).Text = Value.TrimStart();
                                                                            Run run1 = new Run(new RunProperties());
                                                                            Text T = new Text(" ") { Space = SpaceProcessingModeValues.Preserve };
                                                                            run1.AppendChild(T);
                                                                            run.InsertAfterSelf(run1);
                                                                        }
                                                                        else
                                                                        {
                                                                            ((DocumentFormat.OpenXml.OpenXmlLeafTextElement)R).Text = Value;
                                                                        }
                                                                    }
                                                                    else
                                                                    {
                                                                        if (Value.EndsWith(" "))
                                                                        {
                                                                            if (((DocumentFormat.OpenXml.Wordprocessing.Run)R.Parent).RunProperties != null)
                                                                            {
                                                                                Run run = new Run(new RunStyle() { Val = "label-bxftn" });
                                                                                run.AppendChild(new Text(Value.Trim()));
                                                                                R.Parent.InsertBeforeSelf(run);
                                                                                R.Remove();

                                                                                Run run1 = new Run(new RunProperties());
                                                                                Text T = new Text(" ") { Space = SpaceProcessingModeValues.Preserve };
                                                                                run1.AppendChild(T);
                                                                                run.InsertAfterSelf(run1);
                                                                            }
                                                                            else
                                                                            {
                                                                                Run run = new Run(new RunProperties(new RunStyle() { Val = "label-bxftn" }));
                                                                                run.AppendChild(new Text(Value.Trim()));
                                                                                R.Parent.InsertBeforeSelf(run);
                                                                                R.Remove();

                                                                                Run run1 = new Run(new RunProperties());
                                                                                Text T = new Text(" ") { Space = SpaceProcessingModeValues.Preserve };
                                                                                run1.AppendChild(T);
                                                                                run.InsertAfterSelf(run1);
                                                                            }
                                                                        }
                                                                        else
                                                                        {
                                                                            if (((DocumentFormat.OpenXml.Wordprocessing.Run)R.Parent).RunProperties != null)
                                                                            {
                                                                                Run run = new Run(new RunStyle() { Val = "label-bxftn" });
                                                                                run.AppendChild(new Text(Value));
                                                                                R.Parent.InsertBeforeSelf(run);
                                                                                R.Remove();
                                                                            }
                                                                            else
                                                                            {
                                                                                Run run = new Run(new RunProperties(new RunStyle() { Val = "label-bxftn" }));
                                                                                run.AppendChild(new Text(Value));
                                                                                R.Parent.InsertBeforeSelf(run);
                                                                                R.Remove();
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                                else if (Value.StartsWith("n.d."))
                                                                {
                                                                    if (Value.Trim().Length > 4)
                                                                    {
                                                                        // Split the content into two Run
                                                                        Run run = new Run(new RunProperties(new RunStyle() { Val = "label-bxftn" }));
                                                                        run.AppendChild(new Text("n.d."));
                                                                        R.Parent.InsertBeforeSelf(run);

                                                                        // Remove the character from the starting text
                                                                        Value = Value.Substring(4, Value.Length - 4);

                                                                        if (Value.StartsWith(" "))
                                                                        {
                                                                            ((DocumentFormat.OpenXml.OpenXmlLeafTextElement)R).Text = Value.TrimStart();
                                                                            Run run1 = new Run(new RunProperties());
                                                                            Text T = new Text(" ") { Space = SpaceProcessingModeValues.Preserve };
                                                                            run1.AppendChild(T);
                                                                            run.InsertAfterSelf(run1);
                                                                        }
                                                                        else
                                                                        {
                                                                            ((DocumentFormat.OpenXml.OpenXmlLeafTextElement)R).Text = Value;
                                                                        }
                                                                    }
                                                                    else
                                                                    {
                                                                        if (Value.EndsWith(" "))
                                                                        {
                                                                            if (((DocumentFormat.OpenXml.Wordprocessing.Run)R.Parent).RunProperties != null)
                                                                            {
                                                                                Run run = new Run(new RunStyle() { Val = "label-bxftn" });
                                                                                run.AppendChild(new Text(Value.Trim()));
                                                                                R.Parent.InsertBeforeSelf(run);
                                                                                R.Remove();

                                                                                Run run1 = new Run(new RunProperties());
                                                                                Text T = new Text(" ") { Space = SpaceProcessingModeValues.Preserve };
                                                                                run1.AppendChild(T);
                                                                                run.InsertAfterSelf(run1);
                                                                            }
                                                                            else
                                                                            {
                                                                                Run run = new Run(new RunProperties(new RunStyle() { Val = "label-bxftn" }));
                                                                                run.AppendChild(new Text(Value.Trim()));
                                                                                R.Parent.InsertBeforeSelf(run);
                                                                                R.Remove();

                                                                                Run run1 = new Run(new RunProperties());
                                                                                Text T = new Text(" ") { Space = SpaceProcessingModeValues.Preserve };
                                                                                run1.AppendChild(T);
                                                                                run.InsertAfterSelf(run1);
                                                                            }
                                                                        }
                                                                        else
                                                                        {
                                                                            if (((DocumentFormat.OpenXml.Wordprocessing.Run)R.Parent).RunProperties != null)
                                                                            {
                                                                                Run run = new Run(new RunStyle() { Val = "label-bxftn" });
                                                                                run.AppendChild(new Text(Value));
                                                                                R.Parent.InsertBeforeSelf(run);
                                                                                R.Remove();
                                                                            }
                                                                            else
                                                                            {
                                                                                Run run = new Run(new RunProperties(new RunStyle() { Val = "label-bxftn" }));
                                                                                run.AppendChild(new Text(Value));
                                                                                R.Parent.InsertBeforeSelf(run);
                                                                                R.Remove();
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                                else if (Value.StartsWith("a ") || Value.StartsWith("b ") || Value.StartsWith("c ") || Value.StartsWith("d ") || Value.StartsWith("e ")
                                                                    || Value.StartsWith("f ") || Value.StartsWith("g ") || Value.StartsWith("h ")
                                                                    || Value.StartsWith("i ") || Value.StartsWith("j ") || Value.StartsWith("k ")
                                                                    || Value.StartsWith("l ") || Value.StartsWith("m ") || Value.StartsWith("n ")
                                                                    || Value.StartsWith("o ") || Value.StartsWith("p ") || Value.StartsWith("q ")
                                                                    || Value.StartsWith("r ") || Value.StartsWith("s ") || Value.StartsWith("t ")
                                                                    || Value.StartsWith("u ") || Value.StartsWith("v ") || Value.StartsWith("w ")
                                                                    || Value.StartsWith("x ") || Value.StartsWith("y ") || Value.StartsWith("z ")
                                                                    || Value.StartsWith("a") || Value.StartsWith("b") || Value.StartsWith("c") || Value.StartsWith("d") || Value.StartsWith("e")
                                                                    || Value.StartsWith("f") || Value.StartsWith("g") || Value.StartsWith("h")
                                                                    || Value.StartsWith("i") || Value.StartsWith("j") || Value.StartsWith("k")
                                                                    || Value.StartsWith("l") || Value.StartsWith("m") || Value.StartsWith("n")
                                                                    || Value.StartsWith("o") || Value.StartsWith("p") || Value.StartsWith("q")
                                                                    || Value.StartsWith("r") || Value.StartsWith("s") || Value.StartsWith("t")
                                                                    || Value.StartsWith("u") || Value.StartsWith("v") || Value.StartsWith("w")
                                                                    || Value.StartsWith("x") || Value.StartsWith("y") || Value.StartsWith("z"))
                                                                {
                                                                    if (Value.Trim().Length > 1)
                                                                    {
                                                                        string strFirstChar = null;
                                                                        strFirstChar = Value.Substring(0, 1);

                                                                        // Remove the character from the starting text
                                                                        Value = Value.Substring(1, Value.Length - 1);

                                                                        if (Value.StartsWith(" "))
                                                                        {
                                                                            // Split the content into two Run
                                                                            Run run = new Run(new RunProperties(new RunStyle() { Val = "label-bxftn" }));
                                                                            run.AppendChild(new Text(strFirstChar));
                                                                            R.Parent.InsertBeforeSelf(run);

                                                                            if (Value.StartsWith(" "))
                                                                            {
                                                                                ((DocumentFormat.OpenXml.OpenXmlLeafTextElement)R).Text = Value.TrimStart();
                                                                                Run run1 = new Run(new RunProperties());
                                                                                Text T = new Text(" ") { Space = SpaceProcessingModeValues.Preserve };
                                                                                run1.AppendChild(T);
                                                                                run.InsertAfterSelf(run1);
                                                                            }
                                                                            else
                                                                            {
                                                                                ((DocumentFormat.OpenXml.OpenXmlLeafTextElement)R).Text = Value;
                                                                            }
                                                                        }
                                                                    }
                                                                    else
                                                                    {
                                                                        if (Value.EndsWith(" "))
                                                                        {
                                                                            if (((DocumentFormat.OpenXml.Wordprocessing.Run)R.Parent).RunProperties != null)
                                                                            {
                                                                                Run run = new Run(new RunStyle() { Val = "label-bxftn" });
                                                                                run.AppendChild(new Text(Value.Trim()));
                                                                                R.Parent.InsertBeforeSelf(run);
                                                                                R.Remove();

                                                                                Run run1 = new Run(new RunProperties());
                                                                                Text T = new Text(" ") { Space = SpaceProcessingModeValues.Preserve };
                                                                                run1.AppendChild(T);
                                                                                run.InsertAfterSelf(run1);
                                                                            }
                                                                            else
                                                                            {
                                                                                Run run = new Run(new RunProperties(new RunStyle() { Val = "label-bxftn" }));
                                                                                run.AppendChild(new Text(Value.Trim()));
                                                                                R.Parent.InsertBeforeSelf(run);
                                                                                R.Remove();

                                                                                Run run1 = new Run(new RunProperties());
                                                                                Text T = new Text(" ") { Space = SpaceProcessingModeValues.Preserve };
                                                                                run1.AppendChild(T);
                                                                                run.InsertAfterSelf(run1);
                                                                            }
                                                                        }
                                                                        else
                                                                        {
                                                                            if (((DocumentFormat.OpenXml.Wordprocessing.Run)R.Parent).RunProperties != null)
                                                                            {
                                                                                Run run = new Run(new RunStyle() { Val = "label-bxftn" });
                                                                                run.AppendChild(new Text(Value));
                                                                                R.Parent.InsertBeforeSelf(run);
                                                                                R.Remove();
                                                                            }
                                                                            else
                                                                            {
                                                                                Run run = new Run(new RunProperties(new RunStyle() { Val = "label-bxftn" }));
                                                                                run.AppendChild(new Text(Value));
                                                                                R.Parent.InsertBeforeSelf(run);
                                                                                R.Remove();
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                    nIndex++;
                                                }
                                            }
                                            catch (Exception ex)
                                            {
                                                Console.WriteLine(ex.Message);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                }

                D.Save();
            }
        }

        private static void ApplyBoxCitation(string newDoc)
        {
            try
            {
                OpenXmlElement RunProp = null;
                bool bRunPropertiesFound = false;
                strTableFootnoteText.Clear();

                bool bBoxCaptionFound = false;

                bool bStyleFound = false;

                bool bCaptureFootnote = false;

                using (WordprocessingDocument WPD = WordprocessingDocument
                                .Open(newDoc, true))
                {
                    SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                    {
                        RemoveComments = true,
                        RemoveContentControls = true,
                        RemoveEndAndFootNotes = false,
                       // RemoveFieldCodes = false,
                        RemoveLastRenderedPageBreak = true,
                        RemovePermissions = true,
                        RemoveProof = true,
                        RemoveRsidInfo = true,
                        RemoveSmartTags = true,
                        RemoveSoftHyphens = false,
                        ReplaceTabsWithSpaces = true,
                    };

                    MarkupSimplifier.SimplifyMarkup(WPD, settings);

                    MainDocumentPart MDP = WPD.MainDocumentPart;

                    Document D = MDP.Document;

                    bRunPropertiesFound = false;
                    foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                    {
                        try
                        {
                            if (P.ParagraphProperties != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId.Val != null)
                                    {
                                        if (P.ParagraphProperties.ParagraphStyleId.Val == "BX-FTN")
                                        {
                                            bBoxCaptionFound = false;
                                            bCaptureFootnote = false;
                                        }

                                        else if (P.ParagraphProperties.ParagraphStyleId.Val == "BT")
                                        {
                                            bBoxCaptionFound = true;
                                            bRunPropertiesFound = false;
                                            strTableFootnoteText.Clear();
                                            bCaptureFootnote = true;
                                            strTableFootnoteText = ExtractBoxLabelFootnoteText(P);
                                        }
                                        else if (P.ParagraphProperties.ParagraphStyleId.Val == "BullList" ||
                                                P.ParagraphProperties.ParagraphStyleId.Val == "L1" ||
                                                P.ParagraphProperties.ParagraphStyleId.Val == "L2" ||
                                                P.ParagraphProperties.ParagraphStyleId.Val == "L3" ||
                                                P.ParagraphProperties.ParagraphStyleId.Val == "T-TXT")
                                        {
                                            bRunPropertiesFound = false;

                                            if(bBoxCaptionFound)
                                                bCaptureFootnote = true;
                                        }
                                        else
                                        {
                                            if(bBoxCaptionFound == false)
                                            {
                                                bRunPropertiesFound = false;
                                                bCaptureFootnote = false;
                                            }
                                        }

                                        if (bCaptureFootnote == true)
                                        {
                                            if (P.HasChildren == true)
                                            {
                                                try
                                                {
                                                    List<OpenXmlElement> RList = P.Descendants<OpenXmlElement>().ToList();

                                                    foreach (OpenXmlElement R in RList)
                                                    {
                                                        if (R.LocalName != null)
                                                        {
                                                            if (R.LocalName == "r")
                                                            {
                                                                if (R.HasChildren)
                                                                {
                                                                    foreach (OpenXmlElement el in R.Elements())
                                                                    {
                                                                        if (el.LocalName == "rPr")
                                                                        {
                                                                            bRunPropertiesFound = true;

                                                                            RunProp = el;

                                                                            if (el.HasChildren)
                                                                            {
                                                                                foreach (OpenXmlElement el1 in el.Elements())
                                                                                {
                                                                                    if (el1.LocalName == "rstyle")
                                                                                    {
                                                                                        string Style = ((DocumentFormat.OpenXml.Wordprocessing.String253Type)el1).Val;

                                                                                        if (Style != null)
                                                                                        {
                                                                                            if (Style == "citebxftn")
                                                                                            {
                                                                                                bStyleFound = true;
                                                                                                break;
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                        else if (el.LocalName == "t")
                                                                        {
                                                                            if (bStyleFound == false)
                                                                            {
                                                                                string Value = ((DocumentFormat.OpenXml.OpenXmlLeafTextElement)el).Text;
                                                                                bStyleFound = false;
                                                                                if (Value != ".")
                                                                                {
                                                                                    if (strTableFootnoteText.Contains(Value.Trim()) == true)
                                                                                    {
                                                                                        if (bRunPropertiesFound)
                                                                                        {
                                                                                            // Add to the existing Run Properties
                                                                                            if (RunProp != null)
                                                                                            {
                                                                                                Text TStart = null;
                                                                                                Text TEnd = null;
                                                                                                bool bRemoveCurrentNode = false;
                                                                                                if (Value.StartsWith(" "))
                                                                                                {
                                                                                                    TStart = new Text(" ") { Space = SpaceProcessingModeValues.Preserve };
                                                                                                    bRemoveCurrentNode = true;
                                                                                                }

                                                                                                if (Value.EndsWith(" "))
                                                                                                {
                                                                                                    TEnd = new Text(" ") { Space = SpaceProcessingModeValues.Preserve };
                                                                                                    bRemoveCurrentNode = true;
                                                                                                }

                                                                                                if (bRemoveCurrentNode)
                                                                                                    el.Remove();

                                                                                                if (TStart != null)
                                                                                                {
                                                                                                    Run run = new Run(new RunProperties());
                                                                                                    run.AppendChild(TStart);
                                                                                                    R.InsertBeforeSelf(run);
                                                                                                    bRemoveCurrentNode = true;
                                                                                                }

                                                                                                RunStyle rs = new RunStyle() { Val = "citebxftn" };
                                                                                                RunProp.AppendChild(rs);
                                                                                                if (bRemoveCurrentNode)
                                                                                                {
                                                                                                    Text newText = new Text(Value.Trim());
                                                                                                    R.AppendChild(newText);
                                                                                                }

                                                                                                if (TEnd != null)
                                                                                                {
                                                                                                    Run run = new Run(new RunProperties());
                                                                                                    run.AppendChild(TEnd);
                                                                                                    R.InsertAfterSelf(run);
                                                                                                    bRemoveCurrentNode = true;
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                        else
                                                                                        {
                                                                                            // Create new Run Properties
                                                                                            Run run = new Run(new RunProperties(new RunStyle() { Val = "citebxftn" }));
                                                                                            run.AppendChild(new Text(Value));
                                                                                            R.AppendChild(run);
                                                                                            el.Remove();
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                                catch (Exception ex)
                                                {
                                                    Console.WriteLine(ex.Message);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(ex.Message);
                        }
                    }

                    D.Save();
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //private static void ApplyTableFootnote(string newDoc)
        //{
        //    bool bStyleFound = false;
        //    RunProperties rP = null;
        //    int counter = 0;
        //    int nIndex = 0;

        //    using (WordprocessingDocument WPD = WordprocessingDocument
        //        .Open(newDoc, true))
        //    {
        //        SimplifyMarkupSettings settings = new SimplifyMarkupSettings
        //        {
        //            RemoveComments = true,
        //            RemoveContentControls = true,
        //            RemoveEndAndFootNotes = false,
        //            RemoveFieldCodes = false,
        //            RemoveLastRenderedPageBreak = true,
        //            RemovePermissions = true,
        //            RemoveProof = true,
        //            RemoveRsidInfo = true,
        //            RemoveSmartTags = true,
        //            RemoveSoftHyphens = false,
        //            ReplaceTabsWithSpaces = true,
        //        };

        //        MarkupSimplifier.SimplifyMarkup(WPD, settings);

        //        MainDocumentPart MDP = WPD.MainDocumentPart;

        //        Document D = MDP.Document;

        //        foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
        //        {
        //            if (P.ParagraphProperties == null)
        //                continue;

        //            if (P.ParagraphProperties.ParagraphStyleId != null)
        //            {
        //                if (P.ParagraphProperties.ParagraphStyleId.Val != null)
        //                {
        //                    if (P.ParagraphProperties.ParagraphStyleId.Val == "TCH" || P.ParagraphProperties.ParagraphStyleId.Val == "T-TXT" || P.ParagraphProperties.ParagraphStyleId.Val == "L1" || P.ParagraphProperties.ParagraphStyleId.Val == "L2" || P.ParagraphProperties.ParagraphStyleId.Val == "TT" || P.ParagraphProperties.ParagraphStyleId.Val == "L3" || P.ParagraphProperties.ParagraphStyleId.Val == "TCH-btLr")
        //                    {
        //                        if (P.HasChildren == true)
        //                        {
        //                            try
        //                            {
        //                                List<OpenXmlElement> RList = P.Descendants<OpenXmlElement>().ToList();
        //                                nIndex = 0;
        //                                counter = 0;
        //                                foreach (OpenXmlElement R in RList)
        //                                {
        //                                    if (R.LocalName != null)
        //                                    {
        //                                        if (R.LocalName.ToLower() == "rpr")
        //                                        {
        //                                            if (R.GetType().Name == "RunProperties")
        //                                            {
        //                                                rP = ((DocumentFormat.OpenXml.Wordprocessing.RunProperties)R);
        //                                                counter = nIndex;
        //                                            }
        //                                        }
        //                                        else if (R.LocalName.ToLower() == "rstyle")
        //                                        {
        //                                            bStyleFound = true;
        //                                        }
        //                                        else if (R.LocalName.ToLower() == "t")
        //                                        {
        //                                            string Value = ((DocumentFormat.OpenXml.OpenXmlLeafTextElement)R).Text;

        //                                            if (strTableFootnoteText.Contains(Value) == true)
        //                                            {
        //                                                if (bStyleFound == false)
        //                                                {
        //                                                    if (rP != null)
        //                                                    {
        //                                                        if (Value == ".." || Value == "n.d.")
        //                                                        {
        //                                                            RunStyle newrun3 = new RunStyle() { Val = "citetfnnormal" };
        //                                                            rP.AppendChild(newrun3);

        //                                                            RList.ElementAt(counter).InnerXml = rP.InnerXml;
        //                                                        }
        //                                                        else
        //                                                        {
        //                                                            RunStyle newrun3 = new RunStyle() { Val = "citetfn" };
        //                                                            rP.AppendChild(newrun3);

        //                                                            RList.ElementAt(counter).InnerXml = rP.InnerXml;
        //                                                        }
        //                                                    }
        //                                                }

        //                                                bStyleFound = false;
        //                                            }
        //                                        }
        //                                    }

        //                                    nIndex++;
        //                                }
        //                            }
        //                            catch (Exception ex)
        //                            {
        //                                Console.WriteLine(ex.Message);
        //                            }
        //                        }
        //                    }
        //                }
        //            }
        //        }

        //        D.Save();
        //    }
        //}
        private static void ApplyTableFootnoteLabel(string newDoc)
        {
            strTableFootnoteText.Clear();

            int counter = 0;
            int nIndex = 0;
            bool bStyleFound = false;
            int lcounter = 0;
            

            using (WordprocessingDocument WPD = WordprocessingDocument
                            .Open(newDoc, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    RemoveComments = true,
                    RemoveContentControls = true,
                    RemoveEndAndFootNotes = false,
                    //RemoveFieldCodes = false,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = true,
                };

                MarkupSimplifier.SimplifyMarkup(WPD, settings);

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                counter = 0;
                nIndex = 0;
                lcounter = 0;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    try
                    {
                        if(P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId.Val != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId.Val == "TFN")
                                    {
                                        if (P.HasChildren == true)
                                        {
                                            try
                                            {
                                                List<OpenXmlElement> RList = P.Descendants<OpenXmlElement>().ToList();

                                                counter = 0;
                                                nIndex = 0;
                                                lcounter = 0;

                                                foreach (OpenXmlElement R in RList)
                                                {
                                                    if (R.LocalName != null)
                                                    {
                                                        if (R.LocalName.ToLower() == "rstyle")
                                                        {
                                                            string str = R.LocalName;

                                                            string Style = ((DocumentFormat.OpenXml.Wordprocessing.String253Type)R).Val;

                                                            if (Style != null)
                                                            {
                                                                lcounter = 0;
                                                                if (Style == "label-tfn")
                                                                {
                                                                    lcounter = nIndex;
                                                                    bStyleFound = true;
                                                                }

                                                                if (Style == "Hyperlink")
                                                                {
                                                                    counter = nIndex;
                                                                    ((DocumentFormat.OpenXml.Wordprocessing.String253Type)R).Val = "weblinks";
                                                                    ((DocumentFormat.OpenXml.Wordprocessing.String253Type)(RList.ElementAt(counter))).Val = ((DocumentFormat.OpenXml.Wordprocessing.String253Type)R).Val;
                                                                }
                                                            }
                                                        }
                                                        else if (R.LocalName.ToLower() == "t")
                                                        {
                                                            if (bStyleFound == false)
                                                            {
                                                                string Value = ((DocumentFormat.OpenXml.OpenXmlLeafTextElement)R).Text;

                                                                bStyleFound = false;
                                                                if (Value.StartsWith(".."))
                                                                {
                                                                    if (Value.Trim().Length > 2)
                                                                    {
                                                                        // Split the content into two Run
                                                                        Run run = new Run(new RunProperties(new RunStyle() { Val = "label-tfn" }));
                                                                        run.AppendChild(new Text(".."));

                                                                        R.Parent.InsertBeforeSelf(run);

                                                                        Value = Value.Substring(2, Value.Length-2);
                                                                        if(Value.StartsWith(" "))
                                                                        {
                                                                            ((DocumentFormat.OpenXml.OpenXmlLeafTextElement)R).Text = Value.TrimStart();
                                                                            Run run1 = new Run(new RunProperties());
                                                                            Text T = new Text(" ") { Space = SpaceProcessingModeValues.Preserve };
                                                                            run1.AppendChild(T);
                                                                            run.InsertAfterSelf(run1);
                                                                        }
                                                                        else
                                                                        {
                                                                            ((DocumentFormat.OpenXml.OpenXmlLeafTextElement)R).Text = Value;
                                                                        }
                                                                    }
                                                                    else
                                                                    {
                                                                        if (Value.EndsWith(" "))
                                                                        {
                                                                            if (((DocumentFormat.OpenXml.Wordprocessing.Run)R.Parent).RunProperties != null)
                                                                            {
                                                                                Run run = new Run(new RunStyle() { Val = "label-tfn" });
                                                                                run.AppendChild(new Text(Value.Trim()));
                                                                                R.Parent.InsertBeforeSelf(run);
                                                                                R.Remove();

                                                                                Run run1 = new Run(new RunProperties());
                                                                                Text T = new Text(" ") { Space = SpaceProcessingModeValues.Preserve };
                                                                                run1.AppendChild(T);
                                                                                run.InsertAfterSelf(run1);
                                                                            }
                                                                            else
                                                                            {
                                                                                Run run = new Run(new RunProperties(new RunStyle() { Val = "label-tfn" }));
                                                                                run.AppendChild(new Text(Value.Trim()));
                                                                                R.Parent.InsertBeforeSelf(run);
                                                                                R.Remove();

                                                                                Run run1 = new Run(new RunProperties());
                                                                                Text T = new Text(" ") { Space = SpaceProcessingModeValues.Preserve };
                                                                                run1.AppendChild(T);
                                                                                run.InsertAfterSelf(run1);
                                                                            }
                                                                        }
                                                                        else
                                                                        {
                                                                            if (((DocumentFormat.OpenXml.Wordprocessing.Run)R.Parent).RunProperties != null)
                                                                            {
                                                                                Run run = new Run(new RunStyle() { Val = "label-tfn" });
                                                                                run.AppendChild(new Text(Value));
                                                                                R.Parent.InsertBeforeSelf(run);
                                                                                R.Remove();
                                                                            }
                                                                            else
                                                                            {
                                                                                Run run = new Run(new RunProperties(new RunStyle() { Val = "label-tfn" }));
                                                                                run.AppendChild(new Text(Value));
                                                                                R.Parent.InsertBeforeSelf(run);
                                                                                R.Remove();
                                                                            }
                                                                        }
                                                                    }
                                                                }

                                                                else if (Value.StartsWith("n.i.o.p."))
                                                                {
                                                                    if (Value.Trim().Length > 8)
                                                                    {
                                                                        // Split the content into two Run
                                                                        Run run = new Run(new RunProperties(new RunStyle() { Val = "label-tfn" }));
                                                                        run.AppendChild(new Text("n.i.o.p."));
                                                                        R.Parent.InsertBeforeSelf(run);

                                                                        // Remove the character from the starting text
                                                                        Value = Value.Substring(8, Value.Length - 8);

                                                                        if (Value.StartsWith(" "))
                                                                        {
                                                                            ((DocumentFormat.OpenXml.OpenXmlLeafTextElement)R).Text = Value.TrimStart();
                                                                            Run run1 = new Run(new RunProperties());
                                                                            Text T = new Text(" ") { Space = SpaceProcessingModeValues.Preserve };
                                                                            run1.AppendChild(T);
                                                                            run.InsertAfterSelf(run1);
                                                                        }
                                                                        else
                                                                        {
                                                                            ((DocumentFormat.OpenXml.OpenXmlLeafTextElement)R).Text = Value;
                                                                        }
                                                                    }
                                                                    else
                                                                    {
                                                                        if (Value.EndsWith(" "))
                                                                        {
                                                                            if (((DocumentFormat.OpenXml.Wordprocessing.Run)R.Parent).RunProperties != null)
                                                                            {
                                                                                Run run = new Run(new RunStyle() { Val = "label-tfn" });
                                                                                run.AppendChild(new Text(Value.Trim()));
                                                                                R.Parent.InsertBeforeSelf(run);
                                                                                R.Remove();

                                                                                Run run1 = new Run(new RunProperties());
                                                                                Text T = new Text(" ") { Space = SpaceProcessingModeValues.Preserve };
                                                                                run1.AppendChild(T);
                                                                                run.InsertAfterSelf(run1);
                                                                            }
                                                                            else
                                                                            {
                                                                                Run run = new Run(new RunProperties(new RunStyle() { Val = "label-tfn" }));
                                                                                run.AppendChild(new Text(Value.Trim()));
                                                                                R.Parent.InsertBeforeSelf(run);
                                                                                R.Remove();

                                                                                Run run1 = new Run(new RunProperties());
                                                                                Text T = new Text(" ") { Space = SpaceProcessingModeValues.Preserve };
                                                                                run1.AppendChild(T);
                                                                                run.InsertAfterSelf(run1);
                                                                            }
                                                                        }
                                                                        else
                                                                        {
                                                                            if (((DocumentFormat.OpenXml.Wordprocessing.Run)R.Parent).RunProperties != null)
                                                                            {
                                                                                Run run = new Run(new RunStyle() { Val = "label-tfn" });
                                                                                run.AppendChild(new Text(Value));
                                                                                R.Parent.InsertBeforeSelf(run);
                                                                                R.Remove();
                                                                            }
                                                                            else
                                                                            {
                                                                                Run run = new Run(new RunProperties(new RunStyle() { Val = "label-tfn" }));
                                                                                run.AppendChild(new Text(Value));
                                                                                R.Parent.InsertBeforeSelf(run);
                                                                                R.Remove();
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                                else if (Value.StartsWith("n.a."))
                                                                {
                                                                    if (Value.Trim().Length > 4)
                                                                    {
                                                                        // Split the content into two Run
                                                                        Run run = new Run(new RunProperties(new RunStyle() { Val = "label-tfn" }));
                                                                        run.AppendChild(new Text("n.a."));
                                                                        R.Parent.InsertBeforeSelf(run);

                                                                        // Remove the character from the starting text
                                                                        Value = Value.Substring(4, Value.Length - 4);

                                                                        if (Value.StartsWith(" "))
                                                                        {
                                                                            ((DocumentFormat.OpenXml.OpenXmlLeafTextElement)R).Text = Value.TrimStart();
                                                                            Run run1 = new Run(new RunProperties());
                                                                            Text T = new Text(" ") { Space = SpaceProcessingModeValues.Preserve };
                                                                            run1.AppendChild(T);
                                                                            run.InsertAfterSelf(run1);
                                                                        }
                                                                        else
                                                                        {
                                                                            ((DocumentFormat.OpenXml.OpenXmlLeafTextElement)R).Text = Value;
                                                                        }
                                                                    }
                                                                    else
                                                                    {
                                                                        if (Value.EndsWith(" "))
                                                                        {
                                                                            if (((DocumentFormat.OpenXml.Wordprocessing.Run)R.Parent).RunProperties != null)
                                                                            {
                                                                                Run run = new Run(new RunStyle() { Val = "label-tfn" });
                                                                                run.AppendChild(new Text(Value.Trim()));
                                                                                R.Parent.InsertBeforeSelf(run);
                                                                                R.Remove();

                                                                                Run run1 = new Run(new RunProperties());
                                                                                Text T = new Text(" ") { Space = SpaceProcessingModeValues.Preserve };
                                                                                run1.AppendChild(T);
                                                                                run.InsertAfterSelf(run1);
                                                                            }
                                                                            else
                                                                            {
                                                                                Run run = new Run(new RunProperties(new RunStyle() { Val = "label-tfn" }));
                                                                                run.AppendChild(new Text(Value.Trim()));
                                                                                R.Parent.InsertBeforeSelf(run);
                                                                                R.Remove();

                                                                                Run run1 = new Run(new RunProperties());
                                                                                Text T = new Text(" ") { Space = SpaceProcessingModeValues.Preserve };
                                                                                run1.AppendChild(T);
                                                                                run.InsertAfterSelf(run1);
                                                                            }
                                                                        }
                                                                        else
                                                                        {
                                                                            if (((DocumentFormat.OpenXml.Wordprocessing.Run)R.Parent).RunProperties != null)
                                                                            {
                                                                                Run run = new Run(new RunStyle() { Val = "label-tfn" });
                                                                                run.AppendChild(new Text(Value));
                                                                                R.Parent.InsertBeforeSelf(run);
                                                                                R.Remove();
                                                                            }
                                                                            else
                                                                            {
                                                                                Run run = new Run(new RunProperties(new RunStyle() { Val = "label-tfn" }));
                                                                                run.AppendChild(new Text(Value));
                                                                                R.Parent.InsertBeforeSelf(run);
                                                                                R.Remove();
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                                else if (Value.StartsWith("n.d."))
                                                                {
                                                                    if (Value.Trim().Length > 4)
                                                                    {
                                                                        // Split the content into two Run
                                                                        Run run = new Run(new RunProperties(new RunStyle() { Val = "label-tfn" }));
                                                                        run.AppendChild(new Text("n.d."));
                                                                        R.Parent.InsertBeforeSelf(run);

                                                                        // Remove the character from the starting text
                                                                        Value = Value.Substring(4, Value.Length-4);

                                                                        if (Value.StartsWith(" "))
                                                                        {
                                                                            ((DocumentFormat.OpenXml.OpenXmlLeafTextElement)R).Text = Value.TrimStart();
                                                                            Run run1 = new Run(new RunProperties());
                                                                            Text T = new Text(" ") { Space = SpaceProcessingModeValues.Preserve };
                                                                            run1.AppendChild(T);
                                                                            run.InsertAfterSelf(run1);
                                                                        }
                                                                        else
                                                                        {
                                                                            ((DocumentFormat.OpenXml.OpenXmlLeafTextElement)R).Text = Value;
                                                                        }
                                                                    }
                                                                    else
                                                                    {
                                                                        if (Value.EndsWith(" "))
                                                                        {
                                                                            if (((DocumentFormat.OpenXml.Wordprocessing.Run)R.Parent).RunProperties != null)
                                                                            {
                                                                                Run run = new Run(new RunStyle() { Val = "label-tfn" });
                                                                                run.AppendChild(new Text(Value.Trim()));
                                                                                R.Parent.InsertBeforeSelf(run);
                                                                                R.Remove();

                                                                                Run run1 = new Run(new RunProperties());
                                                                                Text T = new Text(" ") { Space = SpaceProcessingModeValues.Preserve };
                                                                                run1.AppendChild(T);
                                                                                run.InsertAfterSelf(run1);
                                                                            }
                                                                            else
                                                                            {
                                                                                Run run = new Run(new RunProperties(new RunStyle() { Val = "label-tfn" }));
                                                                                run.AppendChild(new Text(Value.Trim()));
                                                                                R.Parent.InsertBeforeSelf(run);
                                                                                R.Remove();

                                                                                Run run1 = new Run(new RunProperties());
                                                                                Text T = new Text(" ") { Space = SpaceProcessingModeValues.Preserve };
                                                                                run1.AppendChild(T);
                                                                                run.InsertAfterSelf(run1);
                                                                            }
                                                                        }
                                                                        else
                                                                        {
                                                                            if (((DocumentFormat.OpenXml.Wordprocessing.Run)R.Parent).RunProperties != null)
                                                                            {
                                                                                Run run = new Run(new RunStyle() { Val = "label-tfn" });
                                                                                run.AppendChild(new Text(Value));
                                                                                R.Parent.InsertBeforeSelf(run);
                                                                                R.Remove();
                                                                            }
                                                                            else
                                                                            {
                                                                                Run run = new Run(new RunProperties(new RunStyle() { Val = "label-tfn" }));
                                                                                run.AppendChild(new Text(Value));
                                                                                R.Parent.InsertBeforeSelf(run);
                                                                                R.Remove();
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                                else if (Value.StartsWith("a ") || Value.StartsWith("b ") || Value.StartsWith("c ") || Value.StartsWith("d ") || Value.StartsWith("e ")
                                                                    || Value.StartsWith("f ") || Value.StartsWith("g ") || Value.StartsWith("h ")
                                                                    || Value.StartsWith("i ") || Value.StartsWith("j ") || Value.StartsWith("k ")
                                                                    || Value.StartsWith("l ") || Value.StartsWith("m ") || Value.StartsWith("n ")
                                                                    || Value.StartsWith("o ") || Value.StartsWith("p ") || Value.StartsWith("q ")
                                                                    || Value.StartsWith("r ") || Value.StartsWith("s ") || Value.StartsWith("t ")
                                                                    || Value.StartsWith("u ") || Value.StartsWith("v ") || Value.StartsWith("w ")
                                                                    || Value.StartsWith("x ") || Value.StartsWith("y ") || Value.StartsWith("z ")
                                                                    || Value.StartsWith("a") || Value.StartsWith("b") || Value.StartsWith("c") || Value.StartsWith("d") || Value.StartsWith("e")
                                                                    || Value.StartsWith("f") || Value.StartsWith("g") || Value.StartsWith("h")
                                                                    || Value.StartsWith("i") || Value.StartsWith("j") || Value.StartsWith("k")
                                                                    || Value.StartsWith("l") || Value.StartsWith("m") || Value.StartsWith("n")
                                                                    || Value.StartsWith("o") || Value.StartsWith("p") || Value.StartsWith("q")
                                                                    || Value.StartsWith("r") || Value.StartsWith("s") || Value.StartsWith("t")
                                                                    || Value.StartsWith("u") || Value.StartsWith("v") || Value.StartsWith("w")
                                                                    || Value.StartsWith("x") || Value.StartsWith("y") || Value.StartsWith("z"))
                                                                {
                                                                    if (Value.Trim().Length > 1)
                                                                    {
                                                                        string strFirstChar = null;
                                                                        strFirstChar = Value.Substring(0, 1);

                                                                        // Remove the character from the starting text
                                                                        Value = Value.Substring(1, Value.Length - 1);

                                                                        if(Value.StartsWith(" "))
                                                                        {
                                                                            // Split the content into two Run
                                                                            Run run = new Run(new RunProperties(new RunStyle() { Val = "label-tfn" }));
                                                                            run.AppendChild(new Text(strFirstChar));
                                                                            R.Parent.InsertBeforeSelf(run);

                                                                            if (Value.StartsWith(" "))
                                                                            {
                                                                                ((DocumentFormat.OpenXml.OpenXmlLeafTextElement)R).Text = Value.TrimStart();
                                                                                Run run1 = new Run(new RunProperties());
                                                                                Text T = new Text(" ") { Space = SpaceProcessingModeValues.Preserve };
                                                                                run1.AppendChild(T);
                                                                                run.InsertAfterSelf(run1);
                                                                            }
                                                                            else
                                                                            {
                                                                                ((DocumentFormat.OpenXml.OpenXmlLeafTextElement)R).Text = Value;
                                                                            }
                                                                        }
                                                                     }
                                                                    else
                                                                    {
                                                                        if (Value.EndsWith(" "))
                                                                        {
                                                                            if (((DocumentFormat.OpenXml.Wordprocessing.Run)R.Parent).RunProperties != null)
                                                                            {
                                                                                Run run = new Run(new RunProperties(new RunStyle() { Val = "label-tfn" }));
                                                                                run.AppendChild(new Text(Value.Trim()));
                                                                                R.Parent.InsertBeforeSelf(run);
                                                                                if(R.Parent!=null && R.Parent.LocalName=="r")
                                                                                R.Parent.Remove();

                                                                                Run run1 = new Run(new RunProperties());
                                                                                Text T = new Text(" ") { Space = SpaceProcessingModeValues.Preserve };
                                                                                run1.AppendChild(T);
                                                                                run.InsertAfterSelf(run1);
                                                                            }
                                                                            else
                                                                            {
                                                                                Run run = new Run(new RunProperties(new RunStyle() { Val = "label-tfn" }));
                                                                                run.AppendChild(new Text(Value.Trim()));
                                                                                R.Parent.InsertBeforeSelf(run);
                                                                                R.Remove();

                                                                                Run run1 = new Run(new RunProperties());
                                                                                Text T = new Text(" ") { Space = SpaceProcessingModeValues.Preserve };
                                                                                run1.AppendChild(T);
                                                                                run.InsertAfterSelf(run1);
                                                                            }
                                                                        }
                                                                        else
                                                                        {
                                                                            if (((DocumentFormat.OpenXml.Wordprocessing.Run)R.Parent).RunProperties != null)
                                                                            {
                                                                                Run run = new Run(new RunStyle() { Val = "label-tfn" });
                                                                                run.AppendChild(new Text(Value));
                                                                                R.Parent.InsertBeforeSelf(run);
                                                                                R.Remove();
                                                                            }
                                                                            else
                                                                            {
                                                                                Run run = new Run(new RunProperties(new RunStyle() { Val = "label-tfn" }));
                                                                                run.AppendChild(new Text(Value));
                                                                                R.Parent.InsertBeforeSelf(run);
                                                                                R.Remove();
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                    nIndex++;
                                                }
                                            }
                                            catch (Exception ex)
                                            {
                                                Console.WriteLine(ex.Message);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                }

                D.Save();
            }
        }
        //private static void ExtractTableLabelText(string newDoc)
        //{
        //    strTableFootnoteText.Clear();

        //    int counter = 0;
        //    int nIndex = 0;
        //    bool bStyleFound = false;
        //    int lcounter = 0;

        //    using (WordprocessingDocument WPD = WordprocessingDocument
        //                    .Open(newDoc, true))
        //    {
        //        SimplifyMarkupSettings settings = new SimplifyMarkupSettings
        //        {
        //            RemoveComments = true,
        //            RemoveContentControls = true,
        //            RemoveEndAndFootNotes = false,
        //            RemoveFieldCodes = false,
        //            RemoveLastRenderedPageBreak = true,
        //            RemovePermissions = true,
        //            RemoveProof = true,
        //            RemoveRsidInfo = true,
        //            RemoveSmartTags = true,
        //            RemoveSoftHyphens = false,
        //            ReplaceTabsWithSpaces = true,
        //        };

        //        MarkupSimplifier.SimplifyMarkup(WPD, settings);

        //        MainDocumentPart MDP = WPD.MainDocumentPart;
 
        //        Document D = MDP.Document;

        //        counter = 0;
        //        nIndex = 0;
        //        lcounter = 0;

        //        foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
        //        {
        //            try
        //            {
        //                if(P.ParagraphProperties.ParagraphStyleId != null)
        //                {
        //                    if (P.ParagraphProperties.ParagraphStyleId.Val != null)
        //                    {
        //                        if (P.ParagraphProperties.ParagraphStyleId.Val == "TFN")
        //                        {
        //                            if (P.HasChildren == true)
        //                            {
        //                                try
        //                                {
        //                                    List<OpenXmlElement> RList = P.Descendants<OpenXmlElement>().ToList();

        //                                    counter = 0;
        //                                    nIndex = 0;
        //                                    lcounter = 0;

        //                                    foreach (OpenXmlElement R in RList)
        //                                    {
        //                                        if (R.LocalName != null)
        //                                        {
        //                                            if (R.LocalName.ToLower() == "rstyle")
        //                                            {
        //                                                string str = R.LocalName;

        //                                                string Style = ((DocumentFormat.OpenXml.Wordprocessing.String253Type)R).Val;

        //                                                if (Style != null)
        //                                                {
        //                                                    lcounter = 0;
        //                                                    if (Style == "label-tfn")
        //                                                    {
        //                                                        lcounter = nIndex;
        //                                                        bStyleFound = true;
        //                                                    }

        //                                                    if (Style == "Hyperlink")
        //                                                    {
        //                                                        counter = nIndex;
        //                                                        ((DocumentFormat.OpenXml.Wordprocessing.String253Type)R).Val = "weblinks";
        //                                                        ((DocumentFormat.OpenXml.Wordprocessing.String253Type)(RList.ElementAt(counter))).Val = ((DocumentFormat.OpenXml.Wordprocessing.String253Type)R).Val;
        //                                                    }
        //                                                }
        //                                            }
        //                                            else if (R.LocalName.ToLower() == "t")
        //                                            {
        //                                                if (bStyleFound)
        //                                                {
        //                                                    string Value = ((DocumentFormat.OpenXml.OpenXmlLeafTextElement)R).Text;
        //                                                    bStyleFound = false;
        //                                                    if(Value != ".")
        //                                                    {
        //                                                        if (strTableFootnoteText.Contains(Value) == false)
        //                                                            strTableFootnoteText.Add(Value);
        //                                                    }
        //                                                    else
        //                                                    {
        //                                                        ((DocumentFormat.OpenXml.Wordprocessing.String253Type)(RList.ElementAt(lcounter))).Val = "Default Paragraph Font";
        //                                                        lcounter = 0;
        //                                                    }
        //                                                }
        //                                            }
        //                                        }
        //                                        nIndex++;
        //                                    }
        //                                }
        //                                catch (Exception ex)
        //                                {
        //                                    Console.WriteLine(ex.Message);
        //                                }
        //                            }
        //                        }
        //                        else
        //                        {
        //                            if (P.HasChildren == true)
        //                            {
        //                                try
        //                                {
        //                                    List<OpenXmlElement> RList = P.Descendants<OpenXmlElement>().ToList();

        //                                    counter = 0;
        //                                    nIndex = 0;

        //                                    foreach (OpenXmlElement R in RList)
        //                                    {
        //                                        if (R.LocalName != null)
        //                                        {
        //                                            if (R.LocalName.ToLower() == "rstyle")
        //                                            {
        //                                                string str = R.LocalName;

        //                                                string Style = ((DocumentFormat.OpenXml.Wordprocessing.String253Type)R).Val;

        //                                                if (Style != null)
        //                                                {
        //                                                    if (Style == "Hyperlink")
        //                                                    {
        //                                                        counter = nIndex;
        //                                                        ((DocumentFormat.OpenXml.Wordprocessing.String253Type)R).Val = "weblinks";
        //                                                        ((DocumentFormat.OpenXml.Wordprocessing.String253Type)(RList.ElementAt(counter))).Val = ((DocumentFormat.OpenXml.Wordprocessing.String253Type)R).Val;
        //                                                    }
        //                                                }
        //                                            }
        //                                        }
        //                                        nIndex++;
        //                                    }
        //                                }
        //                                catch (Exception ex)
        //                                {
        //                                    Console.WriteLine(ex.Message);
        //                                }
        //                            }
        //                        }
        //                    }
        //                }
        //            }
        //            catch (Exception ex)
        //            {

        //            }
        //        }

        //        D.Save();
        //    }
        //}
        private static void ApplyTableStyling(string newDoc)
        {
            using (WordprocessingDocument wDoc = WordprocessingDocument.Open(newDoc, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    RemoveComments = true,
                    RemoveContentControls = true,
                    RemoveEndAndFootNotes = false,
                    RemoveFieldCodes = false,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = true,
                };

                MarkupSimplifier.SimplifyMarkup(wDoc, settings);

                var xDoc = wDoc.MainDocumentPart.GetXDocument();

                XmlDocument xd = xDoc.GetXmlDocument();

                xd.LoadXml(xd.InnerXml);

                XmlNodeList nodeList;
                XmlNamespaceManager ns = new XmlNamespaceManager(xd.NameTable);
                ns.AddNamespace("w", "http://schemas.openxmlformats.org/wordprocessingml/2006/main");

                XmlNode root = xd.DocumentElement;

                nodeList = root.SelectNodes("w:body//w:tbl//w:tr//w:tc", ns);

                //w:tcPr//w:shd

                int nIndex = 0;

                XElement xe = null;

                string strcolor = null;
                string strStyle = null;

                Single leftInd = 0;

                bool bColorFound = false;

                List<int> nNodeIndex = new List<int>();

                Single level1 = 0;
                Single level2 = 0;
                Single level3 = 0;

                bool bTextDirectionFound = false;

                XElement XpEle = null;
                XElement XrPrEle = null; 

                bool bBulletList = false;
                bool bTableFootnote = false;

                bool bParaPropertiesFound = false;

                nNodeIndex.Clear();
                foreach (XmlNode book in nodeList)
                {
                    XmlNode nodeParent = book.ParentNode;

                    bBulletList = false;
                    bTextDirectionFound = false;

                    xe = book.GetXElement();

                    bColorFound = false;
                    bTextDirectionFound = false;

                    if (xe.HasElements) // Check if the TC has child elements
                    {
                        foreach (XElement xee in xe.Elements()) // loop through all TC child elements
                        {
                            if(xee.Name == W.tcPr) // Cell color will be obtained from this node
                            {
                                bColorFound = false;

                                if(xee.HasElements)
                                {
                                    foreach (XElement xTcPr in xee.Elements())
                                    {
                                        if(xTcPr.Name == W.shd)
                                        {
                                            if(xTcPr.HasAttributes)
                                            {
                                                foreach(XAttribute xa in xTcPr.Attributes())
                                                {
                                                    if(xa.Name == W.fill)
                                                    {
                                                        if(xa.Value == "006283")
                                                        {
                                                            bColorFound = true;
                                                            break;
                                                        }
                                                    }
                                                }
                                            }
                                        }

                                        else if(xTcPr.Name == W.textDirection)
                                        {
                                            if (xTcPr.HasAttributes)
                                            {
                                                foreach (XAttribute xa in xTcPr.Attributes())
                                                {
                                                    if (xa.Name == W.val)
                                                    {
                                                        if (xa.Value == "btLr")
                                                        {
                                                            bTextDirectionFound = true;
                                                            break;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            } // if(xee.Name == W.tcPr) // Cell color will be obtained from this node
                            if(xee.Name == W.p)
                            {
                                bParaPropertiesFound = false;

                                if (xee.HasElements) // Check if the paragraph has child elements
                                {
                                    foreach(XElement xpara in xee.Elements())
                                    {
                                        if (xpara.Name == W.r)
                                        {
                                            if(bParaPropertiesFound == false)
                                            {
                                                if (strStyle == null)
                                                {
                                                    if (bColorFound == true)
                                                    {
                                                        level1 = 0;
                                                        level2 = 0;
                                                        level3 = 0;

                                                        // add TCH style
                                                        XNamespace w = @"http://schemas.openxmlformats.org/wordprocessingml/2006/main";

                                                        XElement style = null;
                                                        XElement xpPr = null;

                                                        xpPr = new XElement(w + "pPr");

                                                        if (bTextDirectionFound)
                                                        {
                                                            style = new XElement(w + "pStyle", new XAttribute(w + "val", "TCH-btLr"));
                                                        }
                                                        else
                                                        {
                                                            style = new XElement(w + "pStyle", new XAttribute(w + "val", "TCH"));
                                                        }

                                                        //"TCH-btLr"
                                                        xpPr.Add(style);
                                                        xee.AddFirst(xpPr);

                                                        book.InnerXml = ((System.Xml.XmlDocument)(xe.GetXmlNode())).DocumentElement.InnerXml;

                                                        leftInd = 0;
                                                        bBulletList = false;
                                                        bTextDirectionFound = false;
                                                        //bColorFound = false;

                                                        if (xee.NextNode == null)
                                                            goto nextNode;
                                                    }
                                                    else
                                                    {
                                                        //bColorFound = false;

                                                        //Console.WriteLine(nodeParent.ParentNode.OuterXml);

                                                        // add TCH style
                                                        XNamespace w = @"http://schemas.openxmlformats.org/wordprocessingml/2006/main";

                                                        XElement style = null;
                                                        //leftInd

                                                        if (bBulletList == true)
                                                        {
                                                            style = new XElement(w + "pStyle", new XAttribute(w + "val", "BullList"));
                                                            goto applystyle1;
                                                        }

                                                        if (leftInd == 0)
                                                        {
                                                            style = new XElement(w + "pStyle", new XAttribute(w + "val", "T-TXT"));
                                                            goto applystyle1;
                                                        }

                                                        if (leftInd > 0)
                                                        {
                                                            if (leftInd < level1)
                                                            {
                                                                level1 = leftInd;
                                                                style = new XElement(w + "pStyle", new XAttribute(w + "val", "L1"));
                                                                goto applystyle1;
                                                            }

                                                            if (level1 == 0)
                                                            {
                                                                level1 = leftInd;
                                                                style = new XElement(w + "pStyle", new XAttribute(w + "val", "L1"));
                                                                goto applystyle1;
                                                            }

                                                            if (leftInd == level1)
                                                            {
                                                                level1 = leftInd;
                                                                style = new XElement(w + "pStyle", new XAttribute(w + "val", "L1"));
                                                                goto applystyle1;
                                                            }

                                                            if (leftInd > level1)
                                                            {
                                                                if (leftInd < level2)
                                                                {
                                                                    level2 = leftInd;
                                                                    style = new XElement(w + "pStyle", new XAttribute(w + "val", "L2"));
                                                                    goto applystyle1;
                                                                }

                                                                if (level2 == 0)
                                                                {
                                                                    level2 = leftInd;
                                                                    style = new XElement(w + "pStyle", new XAttribute(w + "val", "L2"));
                                                                    goto applystyle1;
                                                                }

                                                                if (leftInd == level2)
                                                                {
                                                                    level2 = leftInd;
                                                                    style = new XElement(w + "pStyle", new XAttribute(w + "val", "L2"));
                                                                    goto applystyle1;
                                                                }
                                                            }

                                                            if (leftInd > level2)
                                                            {
                                                                if (leftInd < level3)
                                                                {
                                                                    level3 = leftInd;
                                                                    style = new XElement(w + "pStyle", new XAttribute(w + "val", "L3"));
                                                                    goto applystyle1;
                                                                }

                                                                if (level3 == 0)
                                                                {
                                                                    level3 = leftInd;
                                                                    style = new XElement(w + "pStyle", new XAttribute(w + "val", "L3"));
                                                                    goto applystyle1;
                                                                }

                                                                if (leftInd == level3)
                                                                {
                                                                    level3 = leftInd;
                                                                    style = new XElement(w + "pStyle", new XAttribute(w + "val", "L3"));
                                                                    goto applystyle1;
                                                                }
                                                            }

                                                            if (leftInd > level3)
                                                            {
                                                                level3 = leftInd;
                                                                style = new XElement(w + "pStyle", new XAttribute(w + "val", "L3"));
                                                                goto applystyle1;
                                                            }
                                                        }

                                                        applystyle1:

                                                        leftInd = 0;
                                                        bBulletList = false;

                                                        if (style != null)
                                                        {
                                                            XElement xpPr = null;

                                                            xpPr = new XElement(w + "pPr");
                                                            xpPr.Add(style);

                                                            xee.AddFirst(xpPr);

                                                            book.InnerXml = ((System.Xml.XmlDocument)(xe.GetXmlNode())).DocumentElement.InnerXml;

                                                            if (xee.NextNode == null)
                                                                goto nextNode;
                                                        }

                                                        if (xee.NextNode == null)
                                                            goto nextNode;
                                                    }
                                                }
                                            }

                                            if (xpara.HasElements)
                                            {
                                                foreach (XElement xr in xpara.Elements())
                                                {
                                                    if (xr.HasElements)
                                                    {
                                                        if (xr.Name == W.rPr)
                                                        {
                                                            foreach (XElement xrPr in xr.Elements())
                                                            {
                                                                if (xrPr.HasElements)
                                                                {
                                                                    foreach (XElement xpr in xrPr.Elements())
                                                                    {
                                                                        if (xpr.Name == W.vertAlign)
                                                                        {
                                                                            bTableFootnote = false;
                                                                            //XrPrEle = null;
                                                                            if (xpr.Value == "superscript")
                                                                            {
                                                                                // Superscript then mark the table footnote style
                                                                                bTableFootnote = true;
                                                                                //style = new XElement(w + "pStyle", new XAttribute(w + "val", "TCH"));
                                                                                //XrPrEle = xrPr;
                                                                                break;
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        } // W.r
                                        else if (xpara.Name == W.pPr)
                                        {
                                            //XpEle = xpara;

                                            bParaPropertiesFound = true;

                                            if (xpara.HasElements)
                                            {
                                                List<XElement> xae = new List<XElement>();

                                                foreach (XElement xpp in xpara.Elements().ToList())
                                                {
                                                    xae.Add(xpp);
                                                }

                                                if (xae.Count < 0)
                                                    break;

                                                foreach (XElement xPpr in xae)  //foreach (XElement xPpr in xpara.Elements())
                                                {
                                                    if (xPpr.Name == W.numPr)
                                                    {
                                                        bBulletList = true;
                                                        continue;
                                                    }
                                                    else if (xPpr.Name == W.pStyle)
                                                    {
                                                        if (xPpr.HasAttributes)
                                                        {
                                                            List<XAttribute> xat = new List<XAttribute>();

                                                            foreach (XAttribute xaa in xPpr.Attributes().ToList())
                                                            {
                                                                xat.Add(xaa);
                                                            }

                                                            if (xat.Count < 0)
                                                                break;

                                                            foreach (XAttribute xa in xat)  //foreach (XAttribute xa in xPpr.Attributes())
                                                            {
                                                                strStyle = null;

                                                                if (xa.Name == W.val)
                                                                    strStyle = xa.Value;

                                                                if(strStyle == "ListBullet")
                                                                {
                                                                    strStyle = null;
                                                                    bBulletList = true;
                                                                    xPpr.Remove();
                                                                    continue;
                                                                }

                                                                if (strStyle != "")
                                                                {
                                                                    strStyle = null;
                                                                    //xa.Remove();
                                                                    xPpr.Remove();
                                                                    continue;
                                                                    //book.InnerXml = ((System.Xml.XmlDocument)(xe.GetXmlNode())).DocumentElement.InnerXml;
                                                                }

                                                                if (strStyle == "NoteText")
                                                                {
                                                                    strStyle = null;
                                                                    //xa.Remove();
                                                                    xPpr.Remove();
                                                                    continue;
                                                                    //book.InnerXml = ((System.Xml.XmlDocument)(xe.GetXmlNode())).DocumentElement.InnerXml;
                                                                }

                                                                if (strStyle == "Heading8")
                                                                {
                                                                    strStyle = null;
                                                                    //xa.Remove();
                                                                    xPpr.Remove();
                                                                    continue;
                                                                    //book.InnerXml = ((System.Xml.XmlDocument)(xe.GetXmlNode())).DocumentElement.InnerXml;
                                                                }

                                                                if (strStyle != null)
                                                                    continue;
                                                            }
                                                        }

                                                        if (strStyle != null)
                                                        {
                                                            strStyle = null;
                                                            continue;
                                                        }
                                                    }
                                                    else if (xPpr.Name == W.ind)
                                                    {
                                                        // Check if the text is indented //

                                                        if (xPpr.HasAttributes)
                                                        {
                                                            leftInd = 0;
                                                            foreach (XAttribute xa in xPpr.Attributes())
                                                            {
                                                                if (xa.Name == W.left)
                                                                {
                                                                    leftInd = Convert.ToSingle(xa.Value);
                                                                    //continue;
                                                                }

                                                                if (xa.Name == W.firstLine)
                                                                {
                                                                    if(leftInd <= 0)
                                                                    {
                                                                        leftInd = Convert.ToSingle(xa.Value);
                                                                    }

                                                                    continue;
                                                                }
                                                            }
                                                        }
                                                    }
                                                }

                                                // Check the style and update //

                                                if (strStyle == null)
                                                {
                                                    if(bColorFound == true)
                                                    {
                                                        level1 = 0;
                                                        level2 = 0;
                                                        level3 = 0;

                                                        // add TCH style
                                                        XNamespace w = @"http://schemas.openxmlformats.org/wordprocessingml/2006/main";

                                                        XElement style = null;
                                                        
                                                        if (bTextDirectionFound)
                                                        {
                                                            style = new XElement(w + "pStyle", new XAttribute(w + "val", "TCH-btLr"));
                                                        }
                                                        else
                                                        {
                                                            style = new XElement(w + "pStyle", new XAttribute(w + "val", "TCH"));
                                                        }

                                                        //"TCH-btLr"
                                                        xpara.AddFirst(style);

                                                        book.InnerXml = ((System.Xml.XmlDocument)(xe.GetXmlNode())).DocumentElement.InnerXml;

                                                        leftInd = 0;
                                                        bBulletList = false;
                                                        bTextDirectionFound = false;
                                                        //bColorFound = false;

                                                        if (xee.NextNode == null)
                                                            goto nextNode;
                                                    }
                                                    else
                                                    {
                                                        //bColorFound = false;

                                                        //Console.WriteLine(nodeParent.ParentNode.OuterXml);

                                                        // add TCH style
                                                        XNamespace w = @"http://schemas.openxmlformats.org/wordprocessingml/2006/main";

                                                        XElement style = null;
                                                        //leftInd

                                                        if (bBulletList == true)
                                                        {
                                                            style = new XElement(w + "pStyle", new XAttribute(w + "val", "BullList"));
                                                            goto applystyle;
                                                        }

                                                        if (leftInd == 0)
                                                        {
                                                            style = new XElement(w + "pStyle", new XAttribute(w + "val", "T-TXT"));
                                                            goto applystyle;
                                                        }

                                                        if (leftInd > 0)
                                                        {
                                                            if (leftInd < level1)
                                                            {
                                                                level1 = leftInd;
                                                                style = new XElement(w + "pStyle", new XAttribute(w + "val", "L1"));
                                                                goto applystyle;
                                                            }

                                                            if (level1 == 0)
                                                            {
                                                                level1 = leftInd;
                                                                style = new XElement(w + "pStyle", new XAttribute(w + "val", "L1"));
                                                                goto applystyle;
                                                            }

                                                            if (leftInd == level1)
                                                            {
                                                                level1 = leftInd;
                                                                style = new XElement(w + "pStyle", new XAttribute(w + "val", "L1"));
                                                                goto applystyle;
                                                            }

                                                            if (leftInd > level1)
                                                            {
                                                                if (leftInd < level2)
                                                                {
                                                                    level2 = leftInd;
                                                                    style = new XElement(w + "pStyle", new XAttribute(w + "val", "L2"));
                                                                    goto applystyle;
                                                                }

                                                                if (level2 == 0)
                                                                {
                                                                    level2 = leftInd;
                                                                    style = new XElement(w + "pStyle", new XAttribute(w + "val", "L2"));
                                                                    goto applystyle;
                                                                }

                                                                if (leftInd == level2)
                                                                {
                                                                    level2 = leftInd;
                                                                    style = new XElement(w + "pStyle", new XAttribute(w + "val", "L2"));
                                                                    goto applystyle;
                                                                }
                                                            }

                                                            if (leftInd > level2)
                                                            {
                                                                if (leftInd < level3)
                                                                {
                                                                    level3 = leftInd;
                                                                    style = new XElement(w + "pStyle", new XAttribute(w + "val", "L3"));
                                                                    goto applystyle;
                                                                }

                                                                if (level3 == 0)
                                                                {
                                                                    level3 = leftInd;
                                                                    style = new XElement(w + "pStyle", new XAttribute(w + "val", "L3"));
                                                                    goto applystyle;
                                                                }

                                                                if (leftInd == level3)
                                                                {
                                                                    level3 = leftInd;
                                                                    style = new XElement(w + "pStyle", new XAttribute(w + "val", "L3"));
                                                                    goto applystyle;
                                                                }
                                                            }

                                                            if (leftInd > level3)
                                                            {
                                                                level3 = leftInd;
                                                                style = new XElement(w + "pStyle", new XAttribute(w + "val", "L3"));
                                                                goto applystyle;
                                                            }
                                                        }

                                                        applystyle:

                                                        leftInd = 0;
                                                        bBulletList = false;

                                                        if (style != null)
                                                        {
                                                            xpara.AddFirst(style);

                                                            //nNodeIndex.Add(nIndex);

                                                            book.InnerXml = ((System.Xml.XmlDocument)(xe.GetXmlNode())).DocumentElement.InnerXml;

                                                            if (xee.NextNode == null)
                                                                goto nextNode;
                                                        }

                                                        if (xee.NextNode == null)
                                                            goto nextNode;
                                                    }
                                                }
                                            }
                                        } //rPr
                                        else
                                        {

                                        }
                                    }
                                }
                            }
                        } // foreach (XElement xee in xe.Elements())

                    }//if (xee.HasElements)
nextNode:
                    nIndex++;
                }

                wDoc.MainDocumentPart.PutXDocument(xd.GetXDocument());

            } // End of Word Processing
        }
        private static XElement RemoverPrProperties(XElement xe)
        {
            List<XElement> nNodeList = new List<XElement>();

            foreach (XElement xee in xe.Elements())
            {
                if (xee.Name == W.jc)
                {
                    nNodeList.Add(xee);
                }
                else if (xee.Name == W.rPr)
                {
                    if (xee.HasElements)
                    {
                        foreach (XElement xrPr in xee.Elements())
                        {
                            if (xrPr.Name != W.lang)
                                nNodeList.Add(xrPr);
                        }
                    }

                } // //else if (xee.Name == W.rPr)

            } // foreach (XElement xee in xe.Elements())

            foreach (var node in nNodeList)
            {
                node.Remove();
            }

            return xe;
        }
        private static XElement RemoverStyle(XElement xe, XAttribute xa)
        {
            List<XElement> nNodeList = new List<XElement>();

            foreach (XElement xee in xe.Elements())
            {
                if (xee.Name == W.jc)
                {
                    nNodeList.Add(xee);
                }
                else if (xee.Name == W.rPr)
                {
                    if (xee.HasElements)
                    {
                        foreach (XElement xrPr in xee.Elements())
                        {
                            if (xrPr.Name != W.lang)
                                nNodeList.Add(xrPr);
                        }
                    }

                } // //else if (xee.Name == W.rPr)

            } // foreach (XElement xee in xe.Elements())

            foreach (var node in nNodeList)
            {
                node.Remove();
            }

            return xe;
        }
        private static void ApplyTableCitation(string newDoc)
        {
            try
            {
                OpenXmlElement RunProp = null;
                bool bRunPropertiesFound = false;
                strTableFootnoteText.Clear();

                bool bStyleFound = false;

                bool bCaptureFootnote = false;

                using (WordprocessingDocument WPD = WordprocessingDocument
                                .Open(newDoc, true))
                {
                    SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                    {
                        RemoveComments = true,
                        RemoveContentControls = true,
                        RemoveEndAndFootNotes = false,
                        //RemoveFieldCodes = false,
                        RemoveLastRenderedPageBreak = true,
                        RemovePermissions = true,
                        RemoveProof = true,
                        RemoveRsidInfo = true,
                        RemoveSmartTags = true,
                        RemoveSoftHyphens = false,
                        ReplaceTabsWithSpaces = true,
                    };

                    MarkupSimplifier.SimplifyMarkup(WPD, settings);

                    MainDocumentPart MDP = WPD.MainDocumentPart;

                    Document D = MDP.Document;

                    bRunPropertiesFound = false;
                    foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                    {
                        try
                        {
                            if (P.ParagraphProperties != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId.Val != null)
                                    {
                                        if (P.ParagraphProperties.ParagraphStyleId.Val == "TT")
                                        {
                                            bRunPropertiesFound = false;
                                            strTableFootnoteText.Clear();
                                            bCaptureFootnote = true;
                                            strTableFootnoteText = ExtractTableLabelFootnoteText(P);
                                        }
                                        else if(P.ParagraphProperties.ParagraphStyleId.Val == "TCH" ||
                                                P.ParagraphProperties.ParagraphStyleId.Val == "TCH-btLr" ||
                                                P.ParagraphProperties.ParagraphStyleId.Val == "L1" ||
                                                P.ParagraphProperties.ParagraphStyleId.Val == "L2" ||
                                                P.ParagraphProperties.ParagraphStyleId.Val == "L3" ||
                                                P.ParagraphProperties.ParagraphStyleId.Val == "T-TXT")
                                        {
                                            bRunPropertiesFound = false;
                                            bCaptureFootnote = true;
                                        }
                                        else
                                        {
                                            bRunPropertiesFound = false;
                                            bCaptureFootnote = false;
                                        }

                                        if(bCaptureFootnote == true)
                                        {
                                            if (P.HasChildren == true)
                                            {
                                                try
                                                {
                                                    List<OpenXmlElement> RList = P.Descendants<OpenXmlElement>().ToList();

                                                    foreach (OpenXmlElement R in RList)
                                                    {
                                                        if (R.LocalName != null)
                                                        {
                                                            if(R.LocalName == "r")
                                                            {
                                                                if(R.HasChildren)
                                                                {
                                                                    foreach(OpenXmlElement el in R.Elements())
                                                                    {
                                                                        if (el.LocalName == "rPr")
                                                                        {
                                                                            bRunPropertiesFound = true;

                                                                            RunProp = el;

                                                                            if (el.HasChildren)
                                                                            {
                                                                                foreach (OpenXmlElement el1 in el.Elements())
                                                                                {
                                                                                    if (el1.LocalName == "rstyle")
                                                                                    {
                                                                                        string Style = ((DocumentFormat.OpenXml.Wordprocessing.String253Type)el1).Val;

                                                                                        if (Style != null)
                                                                                        {
                                                                                            if (Style == "citetfn")
                                                                                            {
                                                                                                bStyleFound = true;
                                                                                                break;
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                        else if (el.LocalName == "t")
                                                                        {
                                                                            if (bStyleFound == false)
                                                                            {
                                                                                string Value = ((DocumentFormat.OpenXml.OpenXmlLeafTextElement)el).Text;
                                                                                bStyleFound = false;
                                                                                if (Value != ".")
                                                                                {
                                                                                    if (strTableFootnoteText.Contains(Value) == true)
                                                                                    {
                                                                                        if(bRunPropertiesFound)
                                                                                        {
                                                                                            // Add to the existing Run Properties

                                                                                            if(RunProp != null)
                                                                                            {
                                                                                                Text TStart = null;
                                                                                                Text TEnd = null;
                                                                                                bool bRemoveCurrentNode = false;
                                                                                                if (Value.StartsWith(" "))
                                                                                                {
                                                                                                    TStart = new Text(" ") { Space = SpaceProcessingModeValues.Preserve };
                                                                                                    bRemoveCurrentNode = true;
                                                                                                }

                                                                                                if (Value.EndsWith(" "))
                                                                                                {
                                                                                                    TEnd = new Text(" ") { Space = SpaceProcessingModeValues.Preserve };
                                                                                                    bRemoveCurrentNode = true;
                                                                                                }

                                                                                                if (bRemoveCurrentNode)
                                                                                                    el.Remove();

                                                                                                if (TStart != null)
                                                                                                {
                                                                                                    Run run = new Run(new RunProperties());
                                                                                                    run.AppendChild(TStart);
                                                                                                    R.InsertBeforeSelf(run);
                                                                                                    bRemoveCurrentNode = true;
                                                                                                }

                                                                                                RunStyle rs = new RunStyle() { Val = "citetfn" };
                                                                                                RunProp.AppendChild(rs);
                                                                                                if (bRemoveCurrentNode)
                                                                                                {
                                                                                                    Text newText = new Text(Value.Trim());
                                                                                                    R.AppendChild(newText);
                                                                                                }

                                                                                                if (TEnd != null)
                                                                                                {
                                                                                                    Run run = new Run(new RunProperties());
                                                                                                    run.AppendChild(TEnd);
                                                                                                    R.InsertAfterSelf(run);
                                                                                                    bRemoveCurrentNode = true;
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                        else
                                                                                        {
                                                                                            // Create new Run Properties
                                                                                            Run run = new Run(new RunProperties(new RunStyle() { Val = "citetfn" }));
                                                                                            run.AppendChild(new Text(Value));
                                                                                            R.AppendChild(run);
                                                                                            el.Remove();
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                                catch (Exception ex)
                                                {
                                                    Console.WriteLine(ex.Message);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(ex.Message);
                        }
                    }

                    D.Save();
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static List<string> ExtractTableLabelFootnoteText(Paragraph ParentP)
        {
            List<string> strTableLabel = new List<string>();
            strTableLabel.Clear();

            bool bStyleFound = false;
            bool bTableFootnoteFound = false;
            string ParaStyle = null;
            string CharStyle = null;

            foreach (OpenXmlElement O in ParentP.ElementsAfter().ToList())
            {
                if (O.LocalName == "p")
                {
                    foreach (OpenXmlElement el in O.Elements())
                    {
                        if(el.HasChildren)
                        {
                            if(el.LocalName == "pPr")
                            {
                                foreach (OpenXmlElement el1 in el.Elements())
                                {
                                    if (el1.LocalName == "pStyle")
                                    {
                                        if(el1.HasAttributes)
                                        {
                                            foreach(OpenXmlAttribute oa in el1.GetAttributes())
                                            {
                                                if(oa.LocalName == "val")
                                                {
                                                    ParaStyle = oa.Value;

                                                    if(ParaStyle == "TFN")
                                                    {
                                                        bTableFootnoteFound = true;
                                                    }
                                                    else
                                                    {
                                                        if(bTableFootnoteFound == true)
                                                        {
                                                            bTableFootnoteFound = false;
                                                            return strTableFootnoteText;
                                                        }

                                                        continue;
                                                    }                                                    
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            else if (el.LocalName == "r")
                            {
                                if(el.HasChildren)
                                {
                                    foreach(OpenXmlElement el1 in el.Elements())
                                    {
                                        if (el1.LocalName == "rPr")
                                        {
                                            if(el1.HasChildren)
                                            {
                                                foreach(OpenXmlElement el2 in el1.Elements())
                                                {
                                                    if (el2.LocalName == "rStyle")
                                                    {
                                                        if (el2.HasAttributes)
                                                        {
                                                            foreach (OpenXmlAttribute oa in el2.GetAttributes())
                                                            {
                                                                if (oa.LocalName == "val")
                                                                {
                                                                    CharStyle = oa.Value;

                                                                    if (CharStyle == "label-tfn")
                                                                    {
                                                                        bStyleFound = true;
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        else if (el1.LocalName == "t")
                                        {
                                            if (bStyleFound)
                                            {
                                                string Value = ((DocumentFormat.OpenXml.OpenXmlLeafTextElement)el1).Text;

                                                bStyleFound = false;
                                                if (Value != ".")
                                                {
                                                    if (strTableFootnoteText.Contains(Value) == false)
                                                        strTableFootnoteText.Add(Value);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            return strTableFootnoteText;
        }

        private static List<string> ExtractBoxLabelFootnoteText(Paragraph ParentP)
        {
            List<string> strTableLabel = new List<string>();
            strTableLabel.Clear();

            bool bStyleFound = false;
            bool bTableFootnoteFound = false;
            string ParaStyle = null;
            string CharStyle = null;

            foreach (OpenXmlElement O in ParentP.ElementsAfter().ToList())
            {
                if (O.LocalName == "p")
                {
                    foreach (OpenXmlElement el in O.Elements())
                    {
                        if (el.HasChildren)
                        {
                            if (el.LocalName == "pPr")
                            {
                                foreach (OpenXmlElement el1 in el.Elements())
                                {
                                    if (el1.LocalName == "pStyle")
                                    {
                                        if (el1.HasAttributes)
                                        {
                                            foreach (OpenXmlAttribute oa in el1.GetAttributes())
                                            {
                                                if (oa.LocalName == "val")
                                                {
                                                    ParaStyle = oa.Value;

                                                    if (ParaStyle == "BX-FTN")
                                                    {
                                                        bTableFootnoteFound = true;
                                                    }
                                                    else
                                                    {
                                                        if (bTableFootnoteFound == true)
                                                        {
                                                            bTableFootnoteFound = false;
                                                            return strTableFootnoteText;
                                                        }

                                                        continue;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            else if (el.LocalName == "r")
                            {
                                if (el.HasChildren)
                                {
                                    foreach (OpenXmlElement el1 in el.Elements())
                                    {
                                        if (el1.LocalName == "rPr")
                                        {
                                            if (el1.HasChildren)
                                            {
                                                foreach (OpenXmlElement el2 in el1.Elements())
                                                {
                                                    if (el2.LocalName == "rStyle")
                                                    {
                                                        if (el2.HasAttributes)
                                                        {
                                                            foreach (OpenXmlAttribute oa in el2.GetAttributes())
                                                            {
                                                                if (oa.LocalName == "val")
                                                                {
                                                                    CharStyle = oa.Value;

                                                                    if (CharStyle == "label-bxftn")
                                                                    {
                                                                        bStyleFound = true;
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        else if (el1.LocalName == "t")
                                        {
                                            if (bStyleFound)
                                            {
                                                string Value = ((DocumentFormat.OpenXml.OpenXmlLeafTextElement)el1).Text;

                                                bStyleFound = false;
                                                if (Value != ".")
                                                {
                                                    if (strTableFootnoteText.Contains(Value) == false)
                                                        strTableFootnoteText.Add(Value);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            return strTableFootnoteText;
        }

        private static void ApplyTableStylingForGroupTables(string newDoc)
        {
            using (WordprocessingDocument wDoc = WordprocessingDocument.Open(newDoc, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    RemoveComments = true,
                    RemoveContentControls = true,
                    RemoveEndAndFootNotes = false,
                    RemoveFieldCodes = false,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = true,
                };

                MarkupSimplifier.SimplifyMarkup(wDoc, settings);

                var xDoc = wDoc.MainDocumentPart.GetXDocument();

                XmlDocument xd = xDoc.GetXmlDocument();

                xd.LoadXml(xd.InnerXml);

                XmlNodeList nodeList;
                XmlNamespaceManager ns = new XmlNamespaceManager(xd.NameTable);
                ns.AddNamespace("w", "http://schemas.openxmlformats.org/wordprocessingml/2006/main");

                XmlNode root = xd.DocumentElement;

                nodeList = root.SelectNodes("w:body//w:tbl//w:tbl//w:tr//w:tc", ns);

                //w:tcPr//w:shd

                int nIndex = 0;

                XElement xe = null;

                string strcolor = null;
                string strStyle = null;

                Single leftInd = 0;

                bool bColorFound = false;

                List<int> nNodeIndex = new List<int>();

                Single level1 = 0;
                Single level2 = 0;
                Single level3 = 0;

                bool bTextDirectionFound = false;

                XElement XpEle = null;
                XElement XrPrEle = null;

                bool bBulletList = false;
                bool bTableFootnote = false;

                bool bParaPropertiesFound = false;

                nNodeIndex.Clear();
                foreach (XmlNode book in nodeList)
                {
                    XmlNode nodeParent = book.ParentNode;

                    bBulletList = false;
                    bTextDirectionFound = false;

                    xe = book.GetXElement();

                    bColorFound = false;
                    bTextDirectionFound = false;

                    if (xe.HasElements) // Check if the TC has child elements
                    {
                        foreach (XElement xee in xe.Elements()) // loop through all TC child elements
                        {
                            if (xee.Name == W.tcPr) // Cell color will be obtained from this node
                            {
                                bColorFound = false;

                                if (xee.HasElements)
                                {
                                    foreach (XElement xTcPr in xee.Elements())
                                    {
                                        if (xTcPr.Name == W.shd)
                                        {
                                            if (xTcPr.HasAttributes)
                                            {
                                                foreach (XAttribute xa in xTcPr.Attributes())
                                                {
                                                    if (xa.Name == W.fill)
                                                    {
                                                        if (xa.Value == "006283")
                                                        {
                                                            bColorFound = true;
                                                            break;
                                                        }
                                                    }
                                                }
                                            }
                                        }

                                        else if (xTcPr.Name == W.textDirection)
                                        {
                                            if (xTcPr.HasAttributes)
                                            {
                                                foreach (XAttribute xa in xTcPr.Attributes())
                                                {
                                                    if (xa.Name == W.val)
                                                    {
                                                        if (xa.Value == "btLr")
                                                        {
                                                            bTextDirectionFound = true;
                                                            break;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            } // if(xee.Name == W.tcPr) // Cell color will be obtained from this node
                            if (xee.Name == W.p)
                            {
                                bParaPropertiesFound = false;

                                if (xee.HasElements) // Check if the paragraph has child elements
                                {
                                    foreach (XElement xpara in xee.Elements())
                                    {
                                        if (xpara.Name == W.r)
                                        {
                                            if (bParaPropertiesFound == false)
                                            {
                                                if (strStyle == null)
                                                {
                                                    if (bColorFound == true)
                                                    {
                                                        level1 = 0;
                                                        level2 = 0;
                                                        level3 = 0;

                                                        // add TCH style
                                                        XNamespace w = @"http://schemas.openxmlformats.org/wordprocessingml/2006/main";

                                                        XElement style = null;
                                                        XElement xpPr = null;

                                                        xpPr = new XElement(w + "pPr");

                                                        if (bTextDirectionFound)
                                                        {
                                                            style = new XElement(w + "pStyle", new XAttribute(w + "val", "TCH-btLr"));
                                                        }
                                                        else
                                                        {
                                                            style = new XElement(w + "pStyle", new XAttribute(w + "val", "TCH"));
                                                        }

                                                        //"TCH-btLr"
                                                        xpPr.Add(style);
                                                        xee.AddFirst(xpPr);

                                                        book.InnerXml = ((System.Xml.XmlDocument)(xe.GetXmlNode())).DocumentElement.InnerXml;

                                                        leftInd = 0;
                                                        bBulletList = false;
                                                        bTextDirectionFound = false;
                                                        //bColorFound = false;

                                                        if (xee.NextNode == null)
                                                            goto nextNode;
                                                    }
                                                    else
                                                    {
                                                        //bColorFound = false;

                                                        //Console.WriteLine(nodeParent.ParentNode.OuterXml);

                                                        // add TCH style
                                                        XNamespace w = @"http://schemas.openxmlformats.org/wordprocessingml/2006/main";

                                                        XElement style = null;
                                                        //leftInd

                                                        if (bBulletList == true)
                                                        {
                                                            style = new XElement(w + "pStyle", new XAttribute(w + "val", "BullList"));
                                                            goto applystyle1;
                                                        }

                                                        if (leftInd == 0)
                                                        {
                                                            style = new XElement(w + "pStyle", new XAttribute(w + "val", "T-TXT"));
                                                            goto applystyle1;
                                                        }

                                                        if (leftInd > 0)
                                                        {
                                                            if (leftInd < level1)
                                                            {
                                                                level1 = leftInd;
                                                                style = new XElement(w + "pStyle", new XAttribute(w + "val", "L1"));
                                                                goto applystyle1;
                                                            }

                                                            if (level1 == 0)
                                                            {
                                                                level1 = leftInd;
                                                                style = new XElement(w + "pStyle", new XAttribute(w + "val", "L1"));
                                                                goto applystyle1;
                                                            }

                                                            if (leftInd == level1)
                                                            {
                                                                level1 = leftInd;
                                                                style = new XElement(w + "pStyle", new XAttribute(w + "val", "L1"));
                                                                goto applystyle1;
                                                            }

                                                            if (leftInd > level1)
                                                            {
                                                                if (leftInd < level2)
                                                                {
                                                                    level2 = leftInd;
                                                                    style = new XElement(w + "pStyle", new XAttribute(w + "val", "L2"));
                                                                    goto applystyle1;
                                                                }

                                                                if (level2 == 0)
                                                                {
                                                                    level2 = leftInd;
                                                                    style = new XElement(w + "pStyle", new XAttribute(w + "val", "L2"));
                                                                    goto applystyle1;
                                                                }

                                                                if (leftInd == level2)
                                                                {
                                                                    level2 = leftInd;
                                                                    style = new XElement(w + "pStyle", new XAttribute(w + "val", "L2"));
                                                                    goto applystyle1;
                                                                }
                                                            }

                                                            if (leftInd > level2)
                                                            {
                                                                if (leftInd < level3)
                                                                {
                                                                    level3 = leftInd;
                                                                    style = new XElement(w + "pStyle", new XAttribute(w + "val", "L3"));
                                                                    goto applystyle1;
                                                                }

                                                                if (level3 == 0)
                                                                {
                                                                    level3 = leftInd;
                                                                    style = new XElement(w + "pStyle", new XAttribute(w + "val", "L3"));
                                                                    goto applystyle1;
                                                                }

                                                                if (leftInd == level3)
                                                                {
                                                                    level3 = leftInd;
                                                                    style = new XElement(w + "pStyle", new XAttribute(w + "val", "L3"));
                                                                    goto applystyle1;
                                                                }
                                                            }

                                                            if (leftInd > level3)
                                                            {
                                                                level3 = leftInd;
                                                                style = new XElement(w + "pStyle", new XAttribute(w + "val", "L3"));
                                                                goto applystyle1;
                                                            }
                                                        }

                                                        applystyle1:

                                                        leftInd = 0;
                                                        bBulletList = false;

                                                        if (style != null)
                                                        {
                                                            XElement xpPr = null;

                                                            xpPr = new XElement(w + "pPr");
                                                            xpPr.Add(style);

                                                            xee.AddFirst(xpPr);

                                                            book.InnerXml = ((System.Xml.XmlDocument)(xe.GetXmlNode())).DocumentElement.InnerXml;

                                                            if (xee.NextNode == null)
                                                                goto nextNode;
                                                        }

                                                        if (xee.NextNode == null)
                                                            goto nextNode;
                                                    }
                                                }
                                            }

                                            if (xpara.HasElements)
                                            {
                                                foreach (XElement xr in xpara.Elements())
                                                {
                                                    if (xr.HasElements)
                                                    {
                                                        if (xr.Name == W.rPr)
                                                        {
                                                            foreach (XElement xrPr in xr.Elements())
                                                            {
                                                                if (xrPr.HasElements)
                                                                {
                                                                    foreach (XElement xpr in xrPr.Elements())
                                                                    {
                                                                        if (xpr.Name == W.vertAlign)
                                                                        {
                                                                            bTableFootnote = false;
                                                                            //XrPrEle = null;
                                                                            if (xpr.Value == "superscript")
                                                                            {
                                                                                // Superscript then mark the table footnote style
                                                                                bTableFootnote = true;
                                                                                //style = new XElement(w + "pStyle", new XAttribute(w + "val", "TCH"));
                                                                                //XrPrEle = xrPr;
                                                                                break;
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        } // W.r
                                        else if (xpara.Name == W.pPr)
                                        {
                                            //XpEle = xpara;

                                            bParaPropertiesFound = true;

                                            if (xpara.HasElements)
                                            {
                                                foreach (XElement xPpr in xpara.Elements())
                                                {
                                                    if (xPpr.Name == W.numPr)
                                                    {
                                                        bBulletList = false;

                                                        if (xPpr.HasElements)
                                                        {
                                                            foreach (XElement xNum in xPpr.Elements())
                                                            {
                                                                if(xNum.Name == W.numId)
                                                                {
                                                                    if(xNum.HasAttributes)
                                                                    {
                                                                        foreach (XAttribute xa in xNum.Attributes())
                                                                        {
                                                                            if(xa.Name == W.val)
                                                                            {
                                                                                string strNumID = xa.Value;
                                                                                if(strNumID != null)
                                                                                {
                                                                                    int nNumID = Convert.ToInt16(strNumID);

                                                                                    if(nNumID > 0)
                                                                                        bBulletList = true;
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                        continue;
                                                    }
                                                    else if (xPpr.Name == W.pStyle)
                                                    {
                                                        if (xPpr.HasAttributes)
                                                        {
                                                            foreach (XAttribute xa in xPpr.Attributes())
                                                            {
                                                                strStyle = null;

                                                                if (xa.Name == W.val)
                                                                    strStyle = xa.Value;

                                                                if (strStyle != "")
                                                                {
                                                                    strStyle = null;
                                                                    //xa.Remove();
                                                                    xPpr.Remove();
                                                                    break;
                                                                    //book.InnerXml = ((System.Xml.XmlDocument)(xe.GetXmlNode())).DocumentElement.InnerXml;
                                                                }

                                                                if (strStyle == "BodyText")
                                                                {
                                                                    strStyle = null;
                                                                    xPpr.Remove();
                                                                    break;
                                                                }


                                                                if (strStyle == "NoteText")
                                                                {
                                                                    strStyle = null;
                                                                    //xa.Remove();
                                                                    xPpr.Remove();
                                                                    break;
                                                                    //book.InnerXml = ((System.Xml.XmlDocument)(xe.GetXmlNode())).DocumentElement.InnerXml;
                                                                }

                                                                if (strStyle == "Heading8")
                                                                {
                                                                    strStyle = null;
                                                                    //xa.Remove();
                                                                    xPpr.Remove();
                                                                    break;
                                                                    //book.InnerXml = ((System.Xml.XmlDocument)(xe.GetXmlNode())).DocumentElement.InnerXml;
                                                                }

                                                                if (strStyle != null)
                                                                    break;
                                                            }
                                                        }

                                                        if (strStyle != null)
                                                        {
                                                            strStyle = null;
                                                            continue;
                                                        }
                                                    }
                                                    else if (xPpr.Name == W.ind)
                                                    {
                                                        // Check if the text is indented //

                                                        if (xPpr.HasAttributes)
                                                        {
                                                            foreach (XAttribute xa in xPpr.Attributes())
                                                            {
                                                                leftInd = 0;
                                                                if (xa.Name == W.left)
                                                                {
                                                                    leftInd = Convert.ToSingle(xa.Value);
                                                                    break;
                                                                }

                                                                if (xa.Name == W.firstLine)
                                                                {
                                                                    leftInd = Convert.ToSingle(xa.Value);
                                                                    break;
                                                                }
                                                            }
                                                        }
                                                    }
                                                }

                                                // Check the style and update //

                                                if (strStyle == null)
                                                {
                                                    if (bColorFound == true)
                                                    {
                                                        level1 = 0;
                                                        level2 = 0;
                                                        level3 = 0;

                                                        // add TCH style
                                                        XNamespace w = @"http://schemas.openxmlformats.org/wordprocessingml/2006/main";

                                                        XElement style = null;

                                                        if (bTextDirectionFound)
                                                        {
                                                            style = new XElement(w + "pStyle", new XAttribute(w + "val", "TCH-btLr"));
                                                        }
                                                        else
                                                        {
                                                            style = new XElement(w + "pStyle", new XAttribute(w + "val", "TCH"));
                                                        }

                                                        //"TCH-btLr"
                                                        xpara.AddFirst(style);

                                                        book.InnerXml = ((System.Xml.XmlDocument)(xe.GetXmlNode())).DocumentElement.InnerXml;

                                                        leftInd = 0;
                                                        bBulletList = false;
                                                        bTextDirectionFound = false;
                                                        //bColorFound = false;

                                                        if (xee.NextNode == null)
                                                            goto nextNode;
                                                    }
                                                    else
                                                    {
                                                        //bColorFound = false;

                                                        //Console.WriteLine(nodeParent.ParentNode.OuterXml);

                                                        // add TCH style
                                                        XNamespace w = @"http://schemas.openxmlformats.org/wordprocessingml/2006/main";

                                                        XElement style = null;
                                                        //leftInd

                                                        if (bBulletList == true)
                                                        {
                                                            style = new XElement(w + "pStyle", new XAttribute(w + "val", "BullList"));
                                                            goto applystyle;
                                                        }

                                                        if (leftInd == 0)
                                                        {
                                                            style = new XElement(w + "pStyle", new XAttribute(w + "val", "T-TXT"));
                                                            goto applystyle;
                                                        }

                                                        if (leftInd > 0)
                                                        {
                                                            if (leftInd < level1)
                                                            {
                                                                level1 = leftInd;
                                                                style = new XElement(w + "pStyle", new XAttribute(w + "val", "L1"));
                                                                goto applystyle;
                                                            }

                                                            if (level1 == 0)
                                                            {
                                                                level1 = leftInd;
                                                                style = new XElement(w + "pStyle", new XAttribute(w + "val", "L1"));
                                                                goto applystyle;
                                                            }

                                                            if (leftInd == level1)
                                                            {
                                                                level1 = leftInd;
                                                                style = new XElement(w + "pStyle", new XAttribute(w + "val", "L1"));
                                                                goto applystyle;
                                                            }

                                                            if (leftInd > level1)
                                                            {
                                                                if (leftInd < level2)
                                                                {
                                                                    level2 = leftInd;
                                                                    style = new XElement(w + "pStyle", new XAttribute(w + "val", "L2"));
                                                                    goto applystyle;
                                                                }

                                                                if (level2 == 0)
                                                                {
                                                                    level2 = leftInd;
                                                                    style = new XElement(w + "pStyle", new XAttribute(w + "val", "L2"));
                                                                    goto applystyle;
                                                                }

                                                                if (leftInd == level2)
                                                                {
                                                                    level2 = leftInd;
                                                                    style = new XElement(w + "pStyle", new XAttribute(w + "val", "L2"));
                                                                    goto applystyle;
                                                                }
                                                            }

                                                            if (leftInd > level2)
                                                            {
                                                                if (leftInd < level3)
                                                                {
                                                                    level3 = leftInd;
                                                                    style = new XElement(w + "pStyle", new XAttribute(w + "val", "L3"));
                                                                    goto applystyle;
                                                                }

                                                                if (level3 == 0)
                                                                {
                                                                    level3 = leftInd;
                                                                    style = new XElement(w + "pStyle", new XAttribute(w + "val", "L3"));
                                                                    goto applystyle;
                                                                }

                                                                if (leftInd == level3)
                                                                {
                                                                    level3 = leftInd;
                                                                    style = new XElement(w + "pStyle", new XAttribute(w + "val", "L3"));
                                                                    goto applystyle;
                                                                }
                                                            }

                                                            if (leftInd > level3)
                                                            {
                                                                level3 = leftInd;
                                                                style = new XElement(w + "pStyle", new XAttribute(w + "val", "L3"));
                                                                goto applystyle;
                                                            }
                                                        }

                                                        applystyle:

                                                        leftInd = 0;
                                                        bBulletList = false;

                                                        if (style != null)
                                                        {
                                                            xpara.AddFirst(style);

                                                            //nNodeIndex.Add(nIndex);

                                                            book.InnerXml = ((System.Xml.XmlDocument)(xe.GetXmlNode())).DocumentElement.InnerXml;

                                                            if (xee.NextNode == null)
                                                                goto nextNode;
                                                        }

                                                        if (xee.NextNode == null)
                                                            goto nextNode;
                                                    }
                                                }
                                            }
                                        } //rPr
                                        else
                                        {

                                        }
                                    }
                                }
                            }
                        } // foreach (XElement xee in xe.Elements())

                    }//if (xee.HasElements)
                    nextNode:
                    nIndex++;
                }

                wDoc.MainDocumentPart.PutXDocument(xd.GetXDocument());

            } // End of Word Processing
        }

        public static void Tt_StyleApplied(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P != null && P.InnerText != "")
                    {
                        if ((P.InnerText.ToLower().TrimStart().StartsWith("table") && !P.InnerText.ToLower().TrimEnd().EndsWith("to come") )/* && P.Descendants<Run>().ToList().FirstOrDefault().Descendants().Any(x => x.LocalName == "b")*/)
                        {
                            if (P.ParagraphProperties != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null)
                                {
                                    P.ParagraphProperties.ParagraphStyleId.Val = "TT";
                                }
                                else
                                {
                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "TT" };
                                }
                            }
                            else
                            {
                                P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "TT" });
                            }
                        }
                        if (P.InnerText.ToLower().TrimStart().StartsWith("box ")/* && P.Descendants<Run>().ToList().FirstOrDefault().Descendants().Any(x => x.LocalName == "b")*/)
                        {
                            if (P.ParagraphProperties != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null)
                                {
                                    P.ParagraphProperties.ParagraphStyleId.Val = "BT";
                                }
                                else
                                {
                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "BT" };
                                }
                            }
                            else
                            {
                                P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "BT" });
                            }
                        }
                        if (P.InnerText.ToLower().TrimStart().StartsWith("chart ")/* && P.Descendants<Run>().ToList().FirstOrDefault().Descendants().Any(x => x.LocalName == "b")*/|| (P.InnerText.ToLower().TrimStart().StartsWith("table") && P.InnerText.ToLower().TrimEnd().EndsWith("to come"))|| (P.InnerText.ToLower().TrimStart().StartsWith("box") && P.InnerText.ToLower().TrimEnd().EndsWith("to come")))
                        {
                            if (P.ParagraphProperties != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null)
                                {
                                    P.ParagraphProperties.ParagraphStyleId.Val = "FIGC";
                                }
                                else
                                {
                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "FIGC" };
                                }
                            }
                            else
                            {
                                P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "FIGC" });
                            }
                        }
                    }
                }
                D.Save();
            }
        }
        public static void CheckAllPara(string newDoc)
        {
            
            List<string> LableStrongPatternsColl = new List<string>();
            LableStrongPatternsColl.Add(@"Table [0-9]+\.[0-9][A-Z] To Come");
            LableStrongPatternsColl.Add(@"Table [0-9]+\.[0-9] To Come");
            LableStrongPatternsColl.Add(@"Box [0-9]+\.[0-9][A-Z] To Come");
            LableStrongPatternsColl.Add(@"Box [0-9]+\.[0-9] To Come");
            LableStrongPatternsColl.Add(@"(Table [A-Z][0-9]+\.[0-9][A-Z] To Come)");
            LableStrongPatternsColl.Add(@"(Table [A-Z][0-9]+\.[0-9] To Come)");            
            LableStrongPatternsColl.Add(@"(Table [0-9]+\.[0-9]+)");
            LableStrongPatternsColl.Add(@"(Box [0-9]+\.[0-9]+)");
            LableStrongPatternsColl.Add(@"(Chart [0-9]+\.[0-9]+)");
            LableStrongPatternsColl.Add(@"(Table [A-Z][0-9]+\.[0-9]+)");
            LableStrongPatternsColl.Add(@"(Table [A-Z][0-9]+\.\s[0-9]+)");
            
           
            ///Configuration read from Supporting folder
            //LableStrongPatternsColl = GlobalMethods.ReadAndStoreFileValuesInArray(GlobalMethods.LableStrongStyle);

            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    bool labelStrongApply = false;  //Developer Name:Priyanka Vishwakarma. Date:17_10_2019 ,Requirement:apply label-strong character style when bold text contains comment ,Integrated by:Vikas sir.
                    if (P != null && P.InnerText != "")
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId.Val != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId.Val.Value == "FIGC" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "TT" ||  P.ParagraphProperties.ParagraphStyleId.Val.Value == "BT")
                                    {
                                        string paraText = P.InnerText;
                                        
                                        foreach (var figpattern in LableStrongPatternsColl.ToList())
                                        {
                                            string match = GlobalMethodsWTO.SearchRegEx(paraText, figpattern);

                                            if (match != "")
                                            {
                                                string runtext = null;
                                                List<Run> matchingrun = new List<Run>();
                                                foreach (Run R in P.Descendants<Run>().ToList())
                                                {
                                                    if (R.RunProperties != null && R.RunProperties.RunStyle != null && R.RunProperties.RunStyle.Val != null && R.RunProperties.RunStyle.Val.Value == "label-Strong")
                                                    {
                                                        break;
                                                    }
                                                    else if (R.RunProperties != null && R.RunProperties.Descendants().Any(x => x.XName.LocalName == "rStyle"))
                                                    {
                                                        var runstyle = (RunStyle)R.RunProperties.Descendants().Where(x => x.XName.LocalName == "rStyle").FirstOrDefault();  // 8_4_2019 Typecasting for check runstyle val not coming directly ..
                                                        if (runstyle.Val == "label-Strong")
                                                        {
                                                            break;
                                                        }
                                                    }
                                                    foreach (var item in R.Descendants<Text>().ToList())
                                                    {
                                                        foreach (var item1 in item.GetAttributes().ToList())
                                                        {
                                                            if (item1.XName.LocalName == "space")
                                                            {
                                                                var r = item1;
                                                                r.Value = SpaceProcessingModeValues.Default.ToString();
                                                            }
                                                        }
                                                    }
                                                    //runtext += R.InnerText.Trim();
                                                    runtext += R.InnerText; //Developer Name:Priyanka Vishwakarma. Date:17_10_2019 ,Requirement:apply label-strong character style when bold text contains comment ,Integrated by:Vikas sir.
                                                    string runmatch = GlobalMethodsWTO.SearchRegEx(runtext, figpattern);

                                                    if (runmatch == "")
                                                    {
                                                        matchingrun.Add(R);
                                                        continue;
                                                    }
                                                    else if (P.Descendants<Run>().Count() == 1)
                                                    {
                                                        string withoutlablestrongtxt = runtext.Replace(runmatch, "");

                                                        Run r1 = new Run(new RunProperties(new RunStyle { Val = "label-Strong" }));

                                                        Text t1 = new Text(runmatch);
                                                        r1.Append(t1);

                                                        Run r2 = new Run();
                                                        Text t2 = new Text(withoutlablestrongtxt);
                                                        r2.Append(t2);

                                                        R.Remove();

                                                        P.Append(r1);

                                                        P.Append(r2);
                                                        break;

                                                    }
                                                    else
                                                    {
                                                        matchingrun.Add(R);

                                                        foreach (Run run in matchingrun)
                                                        {
                                                            if (run.RunProperties != null)
                                                            {
                                                                if (run.RunProperties.RunStyle != null)
                                                                {
                                                                    ///Added by Karan on 01-09-2018 Start
                                                                    if (run.RunProperties.RunStyle.Val == "Strong")
                                                                    {
                                                                        Bold bold = new Bold();
                                                                        run.RunProperties.AppendChild(bold);
                                                                        run.RunProperties.RunStyle.Val = null;
                                                                    }
                                                                    ///Added by Karan on 01-09-2018 End
                                                                    if (run.RunProperties.RunStyle.Val == null)
                                                                    {
                                                                        run.RunProperties.RunStyle = new RunStyle() { Val = "label-Strong" };
                                                                    }
                                                                    else if (run.RunProperties.RunStyle.Val != "label-Strong")
                                                                    {
                                                                        run.RunProperties.RunStyle.Val.Value = "label-Strong";
                                                                    }
                                                                }
                                                                else
                                                                {
                                                                    //---Added  by Priyanka on 9_4_2019 for inserting rstyle in run property.
                                                                    //Run r1 = new Run(new RunProperties(new RunStyle { Val = "label-Strong" }));
                                                                    //Text t1 = new Text(runmatch);
                                                                    //r1.Append(t1);
                                                                    //P.ReplaceChild(r1, run);

                                                                    //---End by Priyanka on 9_4_2019 for inserting rstyle in run property.
                                                                    //---Added  by Priyanka on 9_4_2019 for inserting rstyle in run property.
                                                                    if (labelStrongApply == false)  //Developer Name:Priyanka Vishwakarma. Date:17_10_2019 ,Requirement:apply label-strong character style when bold text contains comment ,Integrated by:Vikas sir.
                                                                    {
                                                                        Run r1 = new Run(new RunProperties(new RunStyle { Val = "label-Strong" }));
                                                                        Text t1 = new Text(runmatch);
                                                                        r1.Append(t1);
                                                                        P.ReplaceChild(r1, run);
                                                                        labelStrongApply = true;
                                                                    }
                                                                    else
                                                                    {
                                                                        run.Remove();
                                                                    }
                                                                    //--------------END----------------------------------------

                                                                    //RunStyle rstyle = new RunStyle() { Val = "label-Strong" };  //Commented by Priyanka on 9_4_2019 for inserting rstyle in run property not Properly.
                                                                    // run.RunProperties.Append(rstyle.CloneNode(true));
                                                                }
                                                            }
                                                            else
                                                            {
                                                                RunProperties runprop = new RunProperties();
                                                                RunStyle rstyle = new RunStyle() { Val = "label-Strong" };
                                                                runprop.Append(rstyle.CloneNode(true));
                                                                run.Append(runprop.CloneNode(true));
                                                            }
                                                        }

                                                        break;
                                                    }
                                                    break;  //Added  by Priyanka on 8_4_2019
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                D.Save();
            }
        }


    }
}
