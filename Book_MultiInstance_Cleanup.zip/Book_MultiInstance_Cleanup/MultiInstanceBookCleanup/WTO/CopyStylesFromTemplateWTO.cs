﻿using DocumentFormat.OpenXml.Drawing;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;
using OpenXmlPowerTools;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;


namespace CleanupMarkup
{
    class CopyStylesFromTemplateWTO
    {
        public static void ExtractStyles(string sourceDoc, string WordTemplatePath)
        {
            try
            {
                using (WordprocessingDocument wSourceDoc = WordprocessingDocument.Open(sourceDoc, true))
                {
                    SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                    {
                        RemoveComments = true,
                        RemoveContentControls = true,
                        RemoveEndAndFootNotes = false,
                        RemoveFieldCodes = false,
                        RemoveLastRenderedPageBreak = true,
                        RemovePermissions = true,
                        RemoveProof = true,
                        RemoveRsidInfo = true,
                        RemoveSmartTags = true,
                        RemoveSoftHyphens = false,
                        ReplaceTabsWithSpaces = true,
                    };

                    MarkupSimplifier.SimplifyMarkup(wSourceDoc, settings);

                    byte[] byteArray = File.ReadAllBytes(WordTemplatePath);

                    using (MemoryStream ms = new MemoryStream())
                    {
                        ms.Write(byteArray, 0, byteArray.Length);

                        using (WordprocessingDocument doc = WordprocessingDocument.Open(ms, true))
                        {
                            XDocument xdd = doc.MainDocumentPart.StyleDefinitionsPart.GetXDocument();

                            XmlDocument xd = xdd.GetXmlDocument();

                            xd.LoadXml(xd.InnerXml);

                            XmlNodeList nodeList;

                            XmlNamespaceManager ns = new XmlNamespaceManager(xd.NameTable);
                            ns.AddNamespace("w", "http://schemas.openxmlformats.org/wordprocessingml/2006/main");

                            XmlNode root = xd.DocumentElement;
                            nodeList = root.SelectNodes("w:style", ns);

                            string strStyleID = null;
                            string strStyleName = null;

                            foreach (XmlNode book in nodeList)
                            {
                                XElement xe = book.GetXElement();

                                if (xe.HasAttributes)
                                {
                                    foreach (XAttribute xs in xe.Attributes())
                                    {
                                        if (xs.Name == W.styleId)
                                        {
                                            strStyleID = xs.Value;
                                            break;
                                        }
                                    }
                                }

                                if (xe.HasElements)
                                {
                                    foreach (XElement xee in xe.Elements())
                                    {
                                        if (xee.Name == W.name)
                                        {
                                            foreach (XAttribute xs in xee.Attributes())
                                            {
                                                if (xs.Name == W.val)
                                                {
                                                    strStyleName = xs.Value;
                                                    break;
                                                }
                                            }
                                        }
                                    }
                                }

                                if (strStyleID != null)
                                {
                                    // Check if the Style exist in the Target XML with the Style ID
                                    //CopyStyleFromTemplate(strStyleID, strStyleName, xe, xd.DocumentElement.Name);

                                    if (IsStyleIdInDocument(wSourceDoc, strStyleID) == false)
                                    {
                                        AddNewStyle(wSourceDoc.MainDocumentPart.StyleDefinitionsPart, strStyleID, strStyleName, xe);
                                    }

                                    // If the Style ID does not exist in the Target XML then check with the Style Name

                                    //if (strStyleName != null)
                                    //{

                                    //}
                                }

                                strStyleID = null;
                                strStyleName = null;

                            } // End of loop
                        }
                    }// Target Loop End
                } // Source Loop End
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        } // End function

        // Create a new style with the specified styleid and stylename and add it to the specified
        // style definitions part.
        private static void AddNewStyle(StyleDefinitionsPart styleDefinitionsPart,
            string styleid, string stylename, XElement xe)
        {
            // Get access to the root element of the styles part.
            Styles styles = styleDefinitionsPart.Styles;

            XmlNode xd = xe.GetXmlNode();

            Style sty = new Style(xd.OuterXml);
            styles.Append(sty);
        }


        // Return true if the style id is in the document, false otherwise.
        private static bool IsStyleIdInDocument(WordprocessingDocument doc,
            string styleid)
        {
            // Get access to the Styles element for this document.
            Styles s = doc.MainDocumentPart.StyleDefinitionsPart.Styles;

            // Check that there are styles and how many.
            int n = s.Elements<Style>().Count();
            if (n == 0)
                return false;

            //&& (st.Type == StyleValues.Paragraph)
            // Look for a match on styleid.
            Style style = s.Elements<Style>()
                .Where(st => (st.StyleId == styleid))
                .FirstOrDefault();
            if (style == null)
                return false;

            return true;
        }
    }
}
