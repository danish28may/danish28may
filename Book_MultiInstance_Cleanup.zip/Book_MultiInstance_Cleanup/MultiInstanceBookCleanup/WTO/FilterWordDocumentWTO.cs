﻿using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;
using OpenXmlPowerTools;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;

namespace CleanupMarkup
{
    class FilterWordDocumentWTO
    {
        public static object OpenPT { get; private set; }

        public static void CleanWordDocument(string strWordDocPath, string strRemoveCharStyleFilename)
        {
            RemovePageBreaks(strWordDocPath);

            ////////////////////RemoveSectionBreaks(strWordDocPath); // not requied now //

            RemoveEmptyPara(strWordDocPath);

            RemoveBlankPara(strWordDocPath);

            //ReplaceNoBreakHypenWithHypen(strWordDocPath); /////// not required now

            List<string> strCharacterStyleColl;

            strCharacterStyleColl = GlobalMethodsWTO.ReadAndStoreFileValuesInArray(strRemoveCharStyleFilename);

            RemoveUnwantedStylesFromDocument(strWordDocPath, strCharacterStyleColl);

            //RemoveSpacebeforeEnter(strWordDocPath); //// not required now

            RemoveUnwantedSpace(strWordDocPath);

        }

        private static void RemoveUnwantedSpace(string newDoc)
        {
            using (WordprocessingDocument wordDoc = WordprocessingDocument.Open(newDoc, true))
            {
                string docText = null;
                using (StreamReader sr = new StreamReader(wordDoc.MainDocumentPart.GetStream()))
                {
                    docText = sr.ReadToEnd();
                }

                Regex regexText = new Regex(@"(Cuadro )([A-Z][0-9]+)\. ([0-9]+)");
                docText = regexText.Replace(docText, "$1$2.$3");

                regexText = new Regex(@"\s+");
                docText = regexText.Replace(docText, " ");

                using (StreamWriter sw = new StreamWriter(wordDoc.MainDocumentPart.GetStream(FileMode.Create)))
                {
                    sw.Write(docText);
                }
            }
        }

        private static void RemoveSpacebeforeEnter(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                .Open(newDoc, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    RemoveComments = true,
                    RemoveContentControls = true,
                    RemoveEndAndFootNotes = false,
                    RemoveFieldCodes = false,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = true,
                };

                MarkupSimplifier.SimplifyMarkup(WPD, settings);

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                // Search all Paragraphs that is "TOC1 to TOC3" style.
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P.HasChildren == true)
                    {
                        //foreach (BookmarkStart B in P.Descendants<BookmarkStart>().ToList())
                        //{
                        //    B.Remove();
                        //}

                        //foreach (BookmarkEnd B in P.Descendants<BookmarkEnd>().ToList())
                        //{
                        //    B.Remove();
                        //}

                        if (P.Descendants<Run>().Count() > 0)
                        {
                            foreach (Run R in P.Descendants<Run>().ToList())
                            {
                                foreach (Text T in R.Descendants<Text>().ToList())
                                {
                                    if (T.Text.EndsWith(" "))
                                        T.Text = T.Text.TrimEnd();
                                }
                            }
                        }
                    }
                }

                D.Save();
            }
        }

        private static void RemoveUnwantedStylesFromDocument(string newDoc, List<string> strCharacterStyleColl)
        {
            if (strCharacterStyleColl.Count > 0)
            {
                using (WordprocessingDocument WPD = WordprocessingDocument
                    .Open(newDoc, true))
                {
                    SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                    {
                        RemoveComments = true,
                        RemoveContentControls = true,
                        RemoveEndAndFootNotes = false,
                        RemoveFieldCodes = false,
                        RemoveLastRenderedPageBreak = true,
                        RemovePermissions = true,
                        RemoveProof = true,
                        RemoveRsidInfo = true,
                        RemoveSmartTags = true,
                        RemoveSoftHyphens = false,
                        ReplaceTabsWithSpaces = true,
                    };

                    MarkupSimplifier.SimplifyMarkup(WPD, settings);

                    MainDocumentPart MDP = WPD.MainDocumentPart;

                    Document D = MDP.Document;

                    int counter = 0;

                    string prevStyleID = null;

                    for (counter = 0; counter < strCharacterStyleColl.Count; counter++)
                    {
                        foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                        {
                            if (P.HasChildren == true)
                            {
                                try
                                {
                                    if (P.ParagraphProperties != null)
                                    {
                                        if (P.ParagraphProperties.ParagraphStyleId != null)
                                        {
                                            if (P.ParagraphProperties.ParagraphStyleId.Val == "NoteText")
                                            {
                                                if (prevStyleID.ToLower() == "caption")
                                                {
                                                    P.ParagraphProperties.ParagraphStyleId.Val = "BodyA";
                                                }

                                                prevStyleID = P.ParagraphProperties.ParagraphStyleId.Val;
                                            }
                                            else
                                            {
                                                prevStyleID = P.ParagraphProperties.ParagraphStyleId.Val;
                                            }
                                        }
                                        else
                                        {
                                            prevStyleID = "";
                                        }
                                    }
                                    else
                                    {
                                        prevStyleID = "";
                                    }

                                    foreach (Run R in P.Descendants<Run>().ToList().
                                     Where(e => e.RunProperties != null
                                    && e.RunProperties.RunStyle.LocalName != null
                                    && e.RunProperties.RunStyle.Val == strCharacterStyleColl[counter]))
                                    {
                                        R.RunProperties.RunStyle.Val = "";
                                    }
                                }
                                catch (Exception ex)
                                {
                                    Console.WriteLine(ex.Message);
                                }
                            }
                        }
                    }

                    D.Save();
                }
            }
        }

        private static void ReplaceNoBreakHypenWithHypen(string newDoc)
        {
            using (WordprocessingDocument wDoc = WordprocessingDocument.Open(newDoc, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    RemoveComments = true,
                    RemoveContentControls = true,
                    RemoveEndAndFootNotes = false,
                    RemoveFieldCodes = false,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = true,
                };

                MarkupSimplifier.SimplifyMarkup(wDoc, settings);

                var xDoc = wDoc.MainDocumentPart.GetXDocument();

                XmlDocument xd = xDoc.GetXmlDocument();

                xd.LoadXml(xd.InnerXml);

                XmlNodeList nodeList;
                XmlNamespaceManager ns = new XmlNamespaceManager(xd.NameTable);
                ns.AddNamespace("w", "http://schemas.openxmlformats.org/wordprocessingml/2006/main");

                XmlNode root = xd.DocumentElement;

                nodeList = root.SelectNodes("w:body//w:p//w:r", ns);

                XElement xe = null;

                bool bNonBreakHypenFound = false;

                foreach (XmlNode book in nodeList)
                {
                    XmlNode nodeParent = book.ParentNode;

                    xe = book.GetXElement();

                    if (xe.HasElements)
                    {
                        //bNonBreakHypenFound = false;
                        foreach (XElement xee in xe.Elements().ToList())
                        {
                            if (xee.Name == W.noBreakHyphen)
                            {
                                bNonBreakHypenFound = true;
                                xe.Remove();
                                book.InnerXml = "";
                                continue;
                            }

                            if (xee.Name == W.t)
                            {
                                if (bNonBreakHypenFound == true)
                                {
                                    xee.Value = "-" + xee.Value;
                                    book.InnerXml = ((System.Xml.XmlDocument)(xe.GetXmlNode())).DocumentElement.InnerXml;
                                    bNonBreakHypenFound = false;
                                }
                                continue;
                            }
                        } // foreach (XElement xee in xe.Elements())

                    }//if (xee.HasElements)

                }

                wDoc.MainDocumentPart.PutXDocument(xd.GetXDocument());

            } // End of Word Processing

        }

        private static void RemoveBlankPara(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                .Open(newDoc, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    //NormalizeXml = true,
                    RemoveHyperlinks = true,
                    RemoveComments = true,
                    RemoveContentControls = true,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = true,

                    RemoveEndAndFootNotes = false,
                    RemoveFieldCodes = false,
                    AcceptRevisions = true,
                    RemoveBookmarks = true,
                    RemoveGoBackBookmark = true,
                    RemoveWebHidden = true,
                    RemoveMarkupForDocumentComparison = true,
                };

                MarkupSimplifier.SimplifyMarkup(WPD, settings);

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                // Search all Paragraphs that is "TOC1 to TOC3" style.
                foreach (Paragraph para in D.Descendants<Paragraph>().ToList().
                    Where(e => e.ParagraphProperties != null
                        && e.ParagraphProperties.ParagraphStyleId != null
                        && e.ParagraphProperties.ParagraphStyleId.Val == "TOC1"))
                {
                    para.Remove();
                }

                foreach (Paragraph para in D.Descendants<Paragraph>().ToList().
                    Where(e => e.ParagraphProperties != null
                        && e.ParagraphProperties.ParagraphStyleId != null
                        && e.ParagraphProperties.ParagraphStyleId.Val == "TOC2"))
                {
                    para.Remove();
                }

                foreach (Paragraph para in D.Descendants<Paragraph>().ToList().
                    Where(e => e.ParagraphProperties != null
                        && e.ParagraphProperties.ParagraphStyleId != null
                        && e.ParagraphProperties.ParagraphStyleId.Val == "TOC3"))
                {
                    para.Remove();
                }

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    //bool bContentsText = IsParaEmpty(P);

                    //if(bContentsText == false)
                    //{
                    //    P.Remove();
                    //}
                    //else
                    //{
                    //    if (P.HasChildren == true)
                    //    {
                    //        foreach (Run R in P.Descendants<Run>().ToList())
                    //        {
                    //            if (R.Descendants<Text>()
                    //                .Where(T => T.Text == "ÍNDICE").Count() > 0)
                    //            {
                    //                P.Remove();
                    //            }
                    //        }
                    //    }
                    //}

                    //if (P.HasChildren == false)
                    //{
                    //    try
                    //    {
                    //        P.Remove();
                    //    }
                    //    catch (Exception ex)
                    //    {
                    //        Console.WriteLine("Error");
                    //    }
                    //}
                    //else 
                    if (P.HasChildren == true)
                    {
                        foreach (Run R in P.Descendants<Run>().ToList())
                        {
                            if (R.Descendants<Text>()
                                .Where(T => T.Text == "ÍNDICE").Count() > 0)
                            {
                                P.Remove();
                            }
                        }
                    }
                }

                D.Save();
            }
        }

        private static bool IsParaEmpty(Paragraph P)
        {
            if (P.HasChildren == true)
            {
                foreach (Run R in P.Descendants<Run>().ToList())
                {
                    foreach (Text T in R.Descendants<Text>().ToList())
                    {
                        return true;
                    }
                }
            }

            return false;
        }

        private static void RemovePageBreaks(string filename)
        {

            using (WordprocessingDocument myDoc = WordprocessingDocument.Open(filename, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    //NormalizeXml = true,
                    RemoveComments = true,
                    RemoveContentControls = true,
                    RemoveEndAndFootNotes = false,
                    RemoveFieldCodes = false,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = true,
                    AcceptRevisions = true,
                    RemoveBookmarks = true,
                    RemoveGoBackBookmark = true,
                    RemoveWebHidden = true,
                };

                MarkupSimplifier.SimplifyMarkup(myDoc, settings);

                MainDocumentPart mainPart = myDoc.MainDocumentPart;

                //List<Break> breaks = mainPart.Document.Descendants<Break>().ToList();

                //foreach (Break b in breaks)
                //{
                //    b.Remove();
                //}

                List<Hyperlink> hlinks = mainPart.Document.Descendants<Hyperlink>().ToList();

                foreach (Hyperlink h in hlinks)
                {
                    h.Remove();
                }

                mainPart.Document.Save();
            }
        }

        private static void RemoveSectionBreaks(string filename)
        {
            using (WordprocessingDocument myDoc = WordprocessingDocument.Open(filename, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    RemoveComments = true,
                    RemoveContentControls = true,
                    RemoveEndAndFootNotes = false,
                    RemoveFieldCodes = false,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = true,
                };

                MarkupSimplifier.SimplifyMarkup(myDoc, settings);

                MainDocumentPart mainPart = myDoc.MainDocumentPart;

                List<ParagraphProperties> paraProps = mainPart.Document.Descendants<ParagraphProperties>()

                .Where(pPr => IsSectionProps(pPr)).ToList();

                foreach (ParagraphProperties pPr in paraProps)
                {
                    pPr.RemoveChild<SectionProperties>(pPr.GetFirstChild<SectionProperties>());
                }

                mainPart.Document.Save();
            }
        }

        private static bool IsSectionProps(ParagraphProperties pPr)
        {
            SectionProperties sectPr = pPr.GetFirstChild<SectionProperties>();

            if (sectPr == null)
                return false;
            else
                return true;
        }

        public static void RemoveEmptyPara(string newDoc)
        {
            string strParaText = null;

            using (WordprocessingDocument WPD = WordprocessingDocument
                                                .Open(newDoc, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    RemoveComments = true,
                    RemoveContentControls = true,
                    RemoveEndAndFootNotes = false,
                    RemoveFieldCodes = false,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = false,
                };

                MarkupSimplifier.SimplifyMarkup(WPD, settings);

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                bool bRemoveP = false;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P.Parent != null)
                    {
                        if (P.Parent.LocalName != null)
                        {
                            if (P.Parent.LocalName == "body" || P.Parent.LocalName == "sdtContent")
                            {
                                strParaText = null;
                                bRemoveP = false;

                                if (P.Descendants<Run>().Count() == 0)
                                {
                                    ///Check if the next and previous element is Table then do not remove the empty paragraph //
                                    if (P.NextSibling() != null && P.NextSibling().XName == W.tbl && P.PreviousSibling() != null && P.PreviousSibling().XName == W.tbl)
                                    {
                                        if (P.ParagraphProperties != null)
                                        {
                                            if (P.ParagraphProperties.ParagraphStyleId != null)
                                            {
                                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "TT";
                                            }
                                            else
                                            {
                                                P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "TT" };
                                            }
                                        }
                                        else
                                        {
                                            P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "TT" });
                                        }
                                        continue;
                                    }

                                    if (P.Descendants<SectionProperties>().Count() != 0)
                                    {
                                        continue;
                                    }
                                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null
                                        && P.ParagraphProperties.ParagraphStyleId.Val != null)
                                    {
                                        if (P.ParagraphProperties.ParagraphStyleId.Val == "TOC1" || P.ParagraphProperties.ParagraphStyleId.Val == "TOC2" ||
                                           P.ParagraphProperties.ParagraphStyleId.Val == "TOC3")
                                        {
                                            P.Remove();
                                        }
                                    }
                                    P.Remove();
                                }
                                else if (P.Descendants<Run>().Count() == 1)
                                {
                                    bRemoveP = true;

                                    foreach (Run R in P.Descendants<Run>().ToList())
                                    {
                                        foreach (Text T in R.Descendants<Text>().ToList())
                                        {
                                            strParaText += T.Text;
                                        }
                                    }

                                    if (strParaText != null)
                                    {
                                        if (strParaText.Trim() != "")
                                        {
                                            bRemoveP = false;
                                        }
                                    }

                                    foreach (Run R in P.Descendants<Run>().ToList())
                                    {
                                        foreach (Picture Pct in R.Descendants<Picture>().ToList())
                                        {
                                            if (Pct.HasChildren)
                                            {
                                                bRemoveP = false;
                                                break;
                                            }
                                        }

                                        foreach (Drawing Draw in R.Descendants<Drawing>().ToList())
                                        {
                                            if (Draw.HasChildren)
                                            {
                                                bRemoveP = false;
                                                break;
                                            }
                                        }

                                        foreach (Break br in R.Descendants<Break>().ToList())
                                        {
                                            if (br.HasAttributes)
                                            {
                                                bRemoveP = false;
                                                break;
                                            }
                                        }

                                        if (bRemoveP)
                                        {
                                            // Check if the next and previous element is Table then do not remove the empty paragraph //
                                            if (P.NextSibling() != null && P.NextSibling().XName == W.tbl && P.PreviousSibling() != null && P.PreviousSibling().XName == W.tbl)
                                                continue;

                                            if (P.ParagraphProperties != null)
                                            {
                                                if (P.ParagraphProperties.ParagraphStyleId != null)
                                                {
                                                    if (P.ParagraphProperties.ParagraphStyleId.Val == "TOC1" || P.ParagraphProperties.ParagraphStyleId.Val == "TOC2" ||
                                                        P.ParagraphProperties.ParagraphStyleId.Val == "TOC3")
                                                    {
                                                        P.Remove();
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                D.Save();
            }
        }
    }
}
