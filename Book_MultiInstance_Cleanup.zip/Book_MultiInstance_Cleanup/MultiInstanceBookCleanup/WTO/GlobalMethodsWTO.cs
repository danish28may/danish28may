﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Microsoft.Office.Interop.Word;
using System.Text.RegularExpressions;
using DocumentFormat.OpenXml.Packaging;
using OpenXmlPowerTools;
using System.Xml;
using System.Xml.Linq;
using System.Linq;

namespace CleanupMarkup
{
    class GlobalMethodsWTO
    {
        public static Microsoft.Office.Interop.Word.Application wordApp = null;
        static Microsoft.Office.Interop.Word.Document SourceDoc = null;
        static Microsoft.Office.Interop.Word.Document TargetDoc = null;

        public static string StrInFolder = null;
        public static string StrOutFolder = null;
        public static string StrProcessFolder = null;
        public static string str3CMWordTemplate = null;
        public static string strStyleMappingConfig = null;
        public static string strStyleMappingJSONConfig = null;
        public static string strCustomerID = null;

        public static List<string> ReadAndStoreFileValuesInArray(string StyleMappingConfigFile)
        {
            //string[] strStyleMapping = new string[1];
            List<string> strStyleMapping = new List<string>();

            int counter = 0;

            string strLine = null;

            StreamReader sr = new StreamReader(StyleMappingConfigFile);

            strStyleMapping.Clear();

            while ((strLine = sr.ReadLine()) != null)
            {
                if (strLine.StartsWith("//") == false)
                {
                    strStyleMapping.Add(strLine.Trim());
                    counter++;
                }
            }

            sr.Close();

            return strStyleMapping;
        }

        public static Microsoft.Office.Interop.Word.Document LoadWordDocument(string strDoc)
        {
            object oMissing = System.Reflection.Missing.Value;
            wordApp = new Microsoft.Office.Interop.Word.Application();

            try
            {
                wordApp.Visible = false;
                wordApp.ScreenUpdating = false;

                Object filename = (Object)strDoc;
                Microsoft.Office.Interop.Word.Document mdoc = wordApp.Documents.Open(ref filename, ref oMissing,
                                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing);

                return mdoc;

            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public static List<string> DocumentRegEx(string strDocContent, string strSearchRegEx)
        {
            List<string> strMatchText = new List<string>();

            strMatchText.Clear();

            Regex regexText = new Regex(strSearchRegEx);

            // Match the regular expression pattern against a text string.
            Match m = regexText.Match(strDocContent);

            while (m.Success)
            {
                if (strMatchText.Contains(m.Value) == false)
                    strMatchText.Add(m.Value);
                m = m.NextMatch();
            }

            return strMatchText;
        }

        public static bool SearchAndReplace(Microsoft.Office.Interop.Word.Document oActiveDoc, string strSearchText, string strReplaceText, string strSearchInParaStyle, string strReplaceCharStyle, string strReplaceParaStyle, bool bCharStyle, bool bParaStyle, bool bReplaceAll, bool bGeneralCrosslink)
        {
            // Clear Previous searched settings from Word Find dialog box
            //ClearFindAndReplaceParameters(oActiveDoc); // not required as of now //

            // get the range of the curent paragraph
            Range rngDoc = oActiveDoc.Range();

            // setup Microsoft Word Find based upon
            // Regular Expression Match
            rngDoc.Find.ClearFormatting();
            rngDoc.Find.Replacement.ClearFormatting();
            rngDoc.Find.Forward = true;

            if(strSearchText != "")
                rngDoc.Find.Text = strSearchText;

            if (strReplaceText != "")
                rngDoc.Find.Replacement.Text = strReplaceText;

            if (bReplaceAll == true && bGeneralCrosslink == true)
            {
                if (strSearchInParaStyle != "")
                    rngDoc.Find.set_Style(strSearchInParaStyle);

                if (bParaStyle == true)
                    rngDoc.Find.Replacement.set_Style(strReplaceParaStyle);

                if (bCharStyle == true)
                    rngDoc.Find.Replacement.set_Style(strReplaceCharStyle);
            }

            if (bGeneralCrosslink == false)
            {
                if (strSearchInParaStyle != "")
                    rngDoc.Find.set_Style(strSearchInParaStyle);

                if (bCharStyle == true)
                    rngDoc.Find.Replacement.set_Style(strReplaceCharStyle);

                if (bParaStyle == true)
                    rngDoc.Find.Replacement.set_Style(strReplaceParaStyle);
            }

            // make search case sensitive
            object caseSensitive = "0";
            object missingValue = Type.Missing;

            rngDoc.Find.Wrap = Microsoft.Office.Interop.Word.WdFindWrap.wdFindStop;

            // wild cards
            object matchWildCards = Type.Missing;

            object replaceAll = Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll;
            //object replaceOne = Microsoft.Office.Interop.Word.WdReplace.wdReplaceOne;


            if (bReplaceAll == true)
            {
                // find the text in the word document
                rngDoc.Find.Execute(ref missingValue, ref missingValue,
                    ref missingValue, ref missingValue, ref missingValue,
                    ref missingValue, ref missingValue, ref missingValue,
                    ref missingValue, ref missingValue, replaceAll,
                    ref missingValue, ref missingValue, ref missingValue,
                    ref missingValue);
            }
            else
            {
                rngDoc.Find.Execute(ref missingValue, ref caseSensitive,
                       ref missingValue, ref missingValue, ref missingValue,
                       ref missingValue, ref missingValue, ref missingValue,
                       ref missingValue, ref missingValue, missingValue,
                       ref missingValue, ref missingValue, ref missingValue,
                       ref missingValue);

                // we found the text
                if (rngDoc.Find.Found)
                {
                    do
                    {
                        if (rngDoc.ParagraphStyle.NameLocal != "TT" && rngDoc.ParagraphStyle.NameLocal != "BT" && rngDoc.ParagraphStyle.NameLocal != "FIGC")
                        {
                            if(strReplaceCharStyle!="")
                                rngDoc.set_Style(strReplaceCharStyle);
                        }

                        if (rngDoc.ParagraphStyle.NameLocal == "BullList")
                        {
                             rngDoc.ListFormat.RemoveNumbers(NumberType:WdNumberType.wdNumberParagraph);
                        }

                        rngDoc.Move();

                        rngDoc.Find.Execute(ref missingValue, ref caseSensitive,
                        ref missingValue, ref missingValue, ref missingValue,
                        ref missingValue, ref missingValue, ref missingValue,
                        ref missingValue, ref missingValue, missingValue,
                        ref missingValue, ref missingValue, ref missingValue,
                        ref missingValue);

                    } while (rngDoc.Find.Found);

                    return true;
                }
            }


            return false;

        }

        private static bool ClearFindAndReplaceParameters(Microsoft.Office.Interop.Word.Document oActiveDoc)
        {
            Range rngDoc = oActiveDoc.Range();

            // setup Microsoft Word Find based upon
            // Regular Expression Match
            rngDoc.Find.ClearFormatting();
            rngDoc.Find.Wrap = Microsoft.Office.Interop.Word.WdFindWrap.wdFindStop;
            rngDoc.Find.MatchWildcards = false;
            rngDoc.Find.set_Style("");
            rngDoc.Find.Replacement.set_Style("");
            rngDoc.Find.Text = "";
            rngDoc.Find.Replacement.Text = "";

            return true;
        }
        public static bool RemoveCharStyle(Microsoft.Office.Interop.Word.Document oActiveDoc, string strSearchText, string strReplaceText, string strSearchCharStyle)
        {
            // get the range of the curent paragraph
            Range rngDoc = oActiveDoc.Range();

            // setup Microsoft Word Find based upon
            // Regular Expression Match
            rngDoc.Find.ClearFormatting();
            rngDoc.Find.Forward = true;
            rngDoc.Find.Text = strSearchText;

            if (strReplaceText != "")
                rngDoc.Find.Replacement.Text = strReplaceText;

            rngDoc.Find.set_Style(strSearchCharStyle);
            rngDoc.Find.Replacement.set_Style("Default Paragraph Font");

            // make search case sensitive
            object caseSensitive = "0";
            object missingValue = Type.Missing;

            rngDoc.Find.Wrap = Microsoft.Office.Interop.Word.WdFindWrap.wdFindStop;

            // wild cards
            object matchWildCards = Type.Missing;

            object replaceAll = Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll;
            //object replaceOne = Microsoft.Office.Interop.Word.WdReplace.wdReplaceOne;


            // find the text in the word document
            rngDoc.Find.Execute(ref missingValue, ref missingValue,
                ref missingValue, ref missingValue, ref missingValue,
                ref missingValue, ref missingValue, ref missingValue,
                ref missingValue, ref missingValue, replaceAll,
                ref missingValue, ref missingValue, ref missingValue,
                ref missingValue);


            return true;

        }

        static bool bNormalParaFound = false;
        static bool bStyleParaFound = false;
        static string strCaptionText = null;
        public static void ApplyTableCaptionBetweenTwoTables(string newDoc)
        {
            bNormalParaFound = false;
            bStyleParaFound = false;


            using (WordprocessingDocument wDoc = WordprocessingDocument.Open(newDoc, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    RemoveComments = true,
                    RemoveContentControls = true,
                    RemoveEndAndFootNotes = false,
                    RemoveFieldCodes = false,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = true,
                };

                MarkupSimplifier.SimplifyMarkup(wDoc, settings);

                var xDoc = wDoc.MainDocumentPart.GetXDocument();

                XmlDocument xd = xDoc.GetXmlDocument();

                xd.LoadXml(xd.InnerXml);

                XmlNodeList nodeList;
                XmlNamespaceManager ns = new XmlNamespaceManager(xd.NameTable);
                ns.AddNamespace("w", "http://schemas.openxmlformats.org/wordprocessingml/2006/main");

                XNamespace w = @"http://schemas.openxmlformats.org/wordprocessingml/2006/main";

                XmlNode root = xd.DocumentElement;

                nodeList = root.SelectNodes("w:body", ns);

                XElement xe = null;

                List<int> nNodeIndex = new List<int>();

                nNodeIndex.Clear();

                foreach (XmlNode book in nodeList)
                {
                    XmlNode nodeParent = book.ParentNode;

                    xe = book.GetXElement();

                    if(xe.HasElements)
                    {
                        foreach(XElement node in xe.Elements())
                        {
                            if (node.Name == W.tbl)
                            {
                                if (CheckElementsAfter(node))
                                {
                                    if(bNormalParaFound)
                                    {
                                        XElement run = new XElement(w + "r");
                                        XElement txt = new XElement(w + "t", strCaptionText);
                                        run.Add(txt);

                                        ((System.Xml.Linq.XElement)node.NextNode).Add(run);

                                        book.InnerXml = ((System.Xml.XmlDocument)(xe.GetXmlNode())).DocumentElement.InnerXml;

                                        continue;
                                    }
                                    else if (bStyleParaFound)
                                    {
                                        // Add new Paragraph above the current paragraph

                                        XElement para = new XElement(w + "p");
                                        XElement run = new XElement(w + "r");
                                        XElement txt = new XElement(w + "t", strCaptionText);
                                        run.Add(txt);
                                        para.Add(run);

                                        ((System.Xml.Linq.XElement)node.NextNode).AddBeforeSelf(para);

                                        book.InnerXml = ((System.Xml.XmlDocument)(xe.GetXmlNode())).DocumentElement.InnerXml;

                                    }
                                    else
                                    {
                                        strCaptionText = null;
                                    }

                                    //strCaptionText = null;
                                }
                            }

                            if (node.Name == W.p)
                            {
                                if (bNormalParaFound == true)
                                {
                                    bNormalParaFound = false;
                                    continue;
                                }

                                if (node.GetParagraphInfo() == null)
                                    continue;

                                BlockContentInfo bki = node.GetParagraphInfo();

                                if (bki.ThisBlockContentElement.FirstNode != null)
                                {
                                    if (((System.Xml.Linq.XContainer)bki.ThisBlockContentElement.FirstNode).FirstNode != null)
                                    {
                                        if (((System.Xml.Linq.XElement)(((System.Xml.Linq.XContainer)bki.ThisBlockContentElement.FirstNode).FirstNode)).Name == W.pStyle)
                                        {
                                            if ((((System.Xml.Linq.XElement)(((System.Xml.Linq.XContainer)bki.ThisBlockContentElement.FirstNode).FirstNode))).FirstAttribute != null)
                                            {
                                                string strStyle = (((System.Xml.Linq.XElement)(((System.Xml.Linq.XContainer)bki.ThisBlockContentElement.FirstNode).FirstNode))).FirstAttribute.Value;

                                                if (strStyle == "Caption")
                                                {
                                                    strCaptionText = node.Value;

                                                    Regex regexText = new Regex(@"Cuadro [A-Z]?[0-9]+\.[0-9]+");
                                                    Match m = regexText.Match(strCaptionText);
                                                    if(m.Length > 0)
                                                    {
                                                        strCaptionText = m.Value + " (Continued...)";
                                                    }
                                                    continue;
                                                }
                                            }
                                        }
                                    }
                                }

                            }
                        }
                    }

                }

                wDoc.MainDocumentPart.PutXDocument(xd.GetXDocument());

            } // End of Word Processing
        }

        private static bool CheckElementsAfter(XElement wp)
        {
            try
            {
                bool bParaFound = false;
                if (wp.ElementsAfterSelf() != null)
                {
                    XNamespace w = @"http://schemas.openxmlformats.org/wordprocessingml/2006/main";

                    IEnumerable<XElement> elements = wp.ElementsAfterSelf();

                    foreach (XElement xe in elements) // all elements
                    {
                        if (xe.Name == W.p) // check if the immediate first element is paragraphs and is empty or style NoteText // Else return
                        {
                            if (xe.Value == "")
                            {
                                bNormalParaFound = true;
                                bStyleParaFound = false;
                                bParaFound = true;
                                continue;
                            }
                            else
                            {
                                if(bParaFound == false)
                                {
                                    BlockContentInfo bki = xe.GetParagraphInfo();

                                    if (bki.ThisBlockContentElement.FirstNode != null)
                                    {
                                        if (((System.Xml.Linq.XContainer)bki.ThisBlockContentElement.FirstNode).FirstNode != null)
                                        {
                                            if (((System.Xml.Linq.XElement)(((System.Xml.Linq.XContainer)bki.ThisBlockContentElement.FirstNode).FirstNode)).Name == W.pStyle)
                                            {
                                                if ((((System.Xml.Linq.XElement)(((System.Xml.Linq.XContainer)bki.ThisBlockContentElement.FirstNode).FirstNode))).FirstAttribute != null)
                                                {
                                                    string strStyle = (((System.Xml.Linq.XElement)(((System.Xml.Linq.XContainer)bki.ThisBlockContentElement.FirstNode).FirstNode))).FirstAttribute.Value;

                                                    if (strStyle == "NoteText")
                                                    {
                                                        bNormalParaFound = false;
                                                        bStyleParaFound = true;
                                                        bParaFound = true;
                                                        continue;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }

                                Console.WriteLine(xe.Value);
                            }
                        }

                        if (bParaFound == true && xe.Name == W.tbl)
                        {
                            // Need to enter the Table Caption Text in the previous paragraph

                            return true;
                        }

                        bStyleParaFound = false;
                        bParaFound = false;
                        bNormalParaFound = false;

                        return false;
                    }
                }

                return false;
            }
            catch (Exception ex)
            {
                return false ;
            }
        }

        public static object OpenWordDocumentAndCompare(string strSourceDoc, string strTargetDoc)
        {
            try
            {
                object CompareFileName = null;
                object oMissing = System.Reflection.Missing.Value;
                wordApp = new Microsoft.Office.Interop.Word.Application();

                try
                {
                    wordApp.Visible = false;
                    wordApp.ScreenUpdating = false;

                    Object Sourcefilename = (Object)strSourceDoc;
                    SourceDoc = wordApp.Documents.Open(ref Sourcefilename, ref oMissing,
                                                       ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                                                       ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                                                       ref oMissing, ref oMissing, ref oMissing, ref oMissing);

                    Object Targetfilename = (Object)strTargetDoc;
                    TargetDoc = wordApp.Documents.Open(ref Targetfilename, ref oMissing,
                                                       ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                                                       ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                                                       ref oMissing, ref oMissing, ref oMissing, ref oMissing);

                    try
                    {
                        DocumentCompare(SourceDoc, TargetDoc);
                    }
                    finally
                    {
                        object saveChanges = WdSaveOptions.wdSaveChanges;
                        ((_Document)SourceDoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                        SourceDoc = null;

                        ((_Document)TargetDoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                        TargetDoc = null;
                    }
                }
                finally
                {
                    wordApp.ScreenUpdating = true;
                    ((_Application)wordApp).Quit(ref oMissing, ref oMissing, ref oMissing);
                    wordApp = null;
                }

                return CompareFileName;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }
        }

        private static void DocumentCompare(Microsoft.Office.Interop.Word.Document strSourceDoc, Microsoft.Office.Interop.Word.Document strTargetDoc)
        {
            object compareTarget = Microsoft.Office.Interop.Word.WdCompareTarget.wdCompareTargetNew;
            object addToRecentFiles = false;
            object oMissing = System.Reflection.Missing.Value;

            wordApp.CompareDocuments(strSourceDoc, strTargetDoc, WdCompareDestination.wdCompareDestinationRevised, WdGranularity.wdGranularityWordLevel, false, true, true, true, false, true, false, false, false, false, "3ClicksMaster", true);
        }

        public static string SearchRegEx(string strDocContent, string strSearchRegEx)
        {
            string strSearchResult = "";

            Regex regexText = new Regex(strSearchRegEx);

            // Match the regular expression pattern against a text string.
            Match m = regexText.Match(strDocContent);

            if (m.Success)
            {
                strSearchResult = m.Value;
            }

            return strSearchResult;
        }

    }
}
