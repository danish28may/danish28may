﻿using DocumentFormat.OpenXml.Packaging;
using OpenXmlPowerTools;
using System;
using System.IO;
using System.Text.RegularExpressions;
using DocumentFormat.OpenXml.Wordprocessing;
using DocumentFormat.OpenXml;
using System.Linq;
using System.Collections.Generic;
using Microsoft.Office.Interop.Word;

namespace CleanupMarkup
{
    class SearchAndReplaceWTO
    {
        public static void GeneralSearchAndReplace(string strDocPath)
        {
            try
            {
                string strDocContent = null;

                // Read the Document Content from Word Document //
                //strDocContent = GlobalMethods.ReadDocumentContent(strDocPath);

                Microsoft.Office.Interop.Word.Document mdoc = null;

                // Load Word Document
                mdoc = GlobalMethodsWTO.LoadWordDocument(strDocPath);

                strDocContent = mdoc.Content.Text;

                if (strDocContent == null)
                    return;

                // Search the patterns in the document content using Regular Expression
                if (mdoc != null)
                {
                    List<string> strMatchText = new List<string>();
                    string strSearchRegEx = null;

                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"(Fig [0-9]+\.[0-9]+\-[0-9]+)";
                    strMatchText = GlobalMethodsWTO.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethodsWTO.SearchAndReplace(mdoc, strMatchText[counter], "", "FIGC", "label-Strong", "", true, false, true, true);
                        }
                    }

                   
                    // To be removed after the demo //
                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"(Cuadro [A-Z]?[0-9]+\.[0-9]+[a]?[0-9\.]+)";
                    strMatchText = GlobalMethodsWTO.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethodsWTO.SearchAndReplace(mdoc, strMatchText[counter], "", "TT", "label-Strong", "", true, false, true, true);
                        }
                    }


                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"(Cuadro [A-Z]?[0-9]+\.[0-9]+)";
                    strMatchText = GlobalMethodsWTO.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethodsWTO.SearchAndReplace(mdoc, strMatchText[counter], "", "TT", "label-Strong", "", true, false, true, true);
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"(Recuadro [A-Z]?[0-9]+\.[0-9]+)";
                    strMatchText = GlobalMethodsWTO.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethodsWTO.SearchAndReplace(mdoc, strMatchText[counter], "", "BT", "label-Strong", "", true, false, true, true);
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"(Gráfico [A-Z]?[0-9]+\.[0-9]+)";
                    strMatchText = GlobalMethodsWTO.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethodsWTO.SearchAndReplace(mdoc, strMatchText[counter], "", "FIGC", "label-Strong", "", true, false, true, true);
                        }
                    }

                    // Document Body Search ///


                    // Jugad for Merged Table //

                    // To be removed after the demo //

                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"([Cc]uadro[s]? [A-Z]?[0-9]+\.[0-9]+) y ([A-Z]?[0-9]+\.[0-9]+[a])";
                    strMatchText = GlobalMethodsWTO.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethodsWTO.SearchAndReplace(mdoc, strMatchText[counter], "", "TT", "cite_tbl", "", true, false, false, true);
                        }
                    }


                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"([Cc]uadro[s]? [A-Z]?[0-9]+\.[0-9]+) y ([A-Z]?[0-9]+\.[0-9\.]+)";
                    strMatchText = GlobalMethodsWTO.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethodsWTO.SearchAndReplace(mdoc, strMatchText[counter], "", "TT", "cite_tbl", "", true, false, false, true);
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"([Cc]uadro[s]? [A-Z]?[0-9]+\.[0-9\.]+)";
                    strMatchText = GlobalMethodsWTO.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethodsWTO.SearchAndReplace(mdoc, strMatchText[counter], "", "TT", "cite_tbl", "", true, false, false, true);
                        }
                    }



                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"([Rr]ecuadro [A-Z]?[0-9]+\.[0-9]+)";
                    strMatchText = GlobalMethodsWTO.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethodsWTO.SearchAndReplace(mdoc, strMatchText[counter], "", "BT", "cite_box", "", true, false, false, true);
                        }
                    }




                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"([Rr]ecuadro[s]? [A-Z]?[0-9]+\.[0-9]+) y ([A-Z]?[0-9]+\.[0-9]+)";
                    strMatchText = GlobalMethodsWTO.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethodsWTO.SearchAndReplace(mdoc, strMatchText[counter], "", "BT", "cite_box", "", true, false, false, true);
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"([Gg]ráfico[s]? [A-Z]?[0-9]+\.[0-9]+) y ([A-Z]?[0-9]+\.[0-9]+)";
                    strMatchText = GlobalMethodsWTO.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethodsWTO.SearchAndReplace(mdoc, strMatchText[counter], "", "FIGC", "cite_fig", "", true, false, false, true);
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"([Gg]ráfico [A-Z]?[0-9]+\.[0-9]+)";
                    strMatchText = GlobalMethodsWTO.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethodsWTO.SearchAndReplace(mdoc, strMatchText[counter], "", "FIGC", "cite_fig", "", true, false, false, true);
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"(Chart [0-9]+\.[0-9]+)";
                    strMatchText = GlobalMethodsWTO.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethodsWTO.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false);
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"\bsecci\u00F3n [0-9\.]+\b";
                    strMatchText = GlobalMethodsWTO.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethodsWTO.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_sec", "", true, false, false, true);
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"\bsecci\u00F3n[s]? [0-9\.]+ y [0-9\.]+\b";
                    strMatchText = GlobalMethodsWTO.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethodsWTO.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_sec", "", true, false, false, true);
                        }
                    }


                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"((Section|section) [0-9]+)";
                    strMatchText = GlobalMethodsWTO.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethodsWTO.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_sec", "", true, false, false, true);
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"((Section|section) [0-9]+\.[0-9]+\.[0-9]+)";
                    strMatchText = GlobalMethodsWTO.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethodsWTO.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_sec", "", true, false, false, true);
                        }
                    }
                    
                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"((Section|section) [0-9]+\.[0-9]+\.[0-9]+\.[0-9]+)";
                    strMatchText = GlobalMethodsWTO.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethodsWTO.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_sec", "", true, false, false, true);
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"((Section|section) [0-9]+\.[0-9]+)";
                    strMatchText = GlobalMethodsWTO.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethodsWTO.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_sec", "", true, false, false, true);
                        }
                    }

                   

                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"(Table [0-9]+\.[0-9]+)";
                    strMatchText = GlobalMethodsWTO.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethodsWTO.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, false);
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"(Table [A-Z][0-9]+\.[0-9]+)";
                    strMatchText = GlobalMethodsWTO.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethodsWTO.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, false);
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"(Table [A-Z][0-9]+\.\s[0-9]+)";
                    strMatchText = GlobalMethodsWTO.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethodsWTO.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, false);
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;
                   


                    strSearchRegEx = @"(Box [0-9]+\.[0-9]+)";
                    strMatchText = GlobalMethodsWTO.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethodsWTO.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_box", "", true, false, false, false);
                        }
                    }

                    //strMatchText.Clear();
                    //strSearchRegEx = null;

                    //strSearchRegEx = @"(Table [0-9]+\.[0-9][A-Z] To Come)";
                    //strMatchText = GlobalMethodsWTO.DocumentRegEx(strDocContent, strSearchRegEx);

                    //if (strMatchText.Count > 0)
                    //{
                    //    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //    {
                    //        GlobalMethodsWTO.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false);
                    //    }
                    //}
                    //strMatchText.Clear();
                    //strSearchRegEx = null;

                    //strSearchRegEx = @"(Table [0-9]+\.[0-9] To Come)";
                    //strMatchText = GlobalMethodsWTO.DocumentRegEx(strDocContent, strSearchRegEx);

                    //if (strMatchText.Count > 0)
                    //{
                    //    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //    {
                    //        GlobalMethodsWTO.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false);
                    //    }
                    //}


                    GlobalMethodsWTO.RemoveCharStyle(mdoc, " y ", " y ", "cite_tbl");
                    GlobalMethodsWTO.RemoveCharStyle(mdoc, " y ", " y ", "cite_box");
                    GlobalMethodsWTO.RemoveCharStyle(mdoc, " y ", " y ", "cite_fig");
                    GlobalMethodsWTO.RemoveCharStyle(mdoc, " y ", " y ", "cite_sec");

                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"\b(?:https?://|www\.)[^ \f\n\r\t\v\]]+\b(\/?)+";
                    strMatchText = GlobalMethodsWTO.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethodsWTO.SearchAndReplace(mdoc, strMatchText[counter], "", "", "weblinks", "", true, false, true, false);
                        }
                    }

                    
                    //strMatchText.Clear();
                    //strSearchRegEx = null;
                    //string strReplaceText = null;


                    //strSearchRegEx = @" \n";
                    //strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);
                    //strReplaceText = "\n";

                    //if (strMatchText.Count > 0)
                    //{
                    //    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //    {
                    //        GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], strReplaceText, "", "", "", false, false, true, false);
                    //    }
                    //}

                    GlobalMethodsWTO.SearchAndReplace(mdoc, "^p ", "^p", "", "", "", false, false, true, false);
                    GlobalMethodsWTO.SearchAndReplace(mdoc, " ^p", "^p", "", "", "", false, false, true, false);
                    GlobalMethodsWTO.SearchAndReplace(mdoc, "^g", "^&", "", "", "FIG", false, true, true, false);
                    GlobalMethodsWTO.SearchAndReplace(mdoc, "^~", "-", "", "", "", false, false, true, false);

                    GlobalMethodsWTO.SearchAndReplace(mdoc, "", "", "BullList", "", "", false, false, false, false);

                    object oMissing = System.Reflection.Missing.Value;

                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;

                }
            }
            catch(Exception ex)
            {

            }
            finally
            {
                if (GlobalMethodsWTO.wordApp != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    ((_Application)GlobalMethodsWTO.wordApp).Quit(ref oMissing, ref oMissing, ref oMissing);
                    GlobalMethodsWTO.wordApp = null;
                }
            }


        }

        //public static void ReadConfigFileAndReplace(string filePath, string jsonFile)
        //{
        //    try
        //    {
        //        string f = File.ReadAllText(jsonFile);

        //        dynamic json = Newtonsoft.Json.Linq.JObject.Parse(f);

        //        string Search = null;

        //        string Replace = null;
        //        string allowStyle = null;
        //        string restrictedStyle = null;
        //        bool MatchCase = false;
        //        bool paragraphStyle = false;
        //        bool characterStyle = false;


        //        //foreach (var data in json.aaData)
        //        //{
        //        //    Replace = null;
        //        //    allowStyle = null;
        //        //    restrictedStyle = null;
        //        //    MatchCase = false;
        //        //    paragraphStyle = false;
        //        //    characterStyle = false;

        //        //    Search = data.Search;
        //        //    Replace = data.Replace;
        //        //    allowStyle = data.allowStyle;
        //        //    restrictedStyle = data.restrictedStyle;
        //        //    MatchCase = data.MatchCase;
        //        //    paragraphStyle = data.paragraphStyle;
        //        //    characterStyle = data.characterStyle;
        //        //    SearchAndReplaceFromWord(filePath, Search, Replace, allowStyle, restrictedStyle, MatchCase, paragraphStyle, characterStyle);

        //        //}

        //        // Also search for the web URL and mark the pattern with character style //

        //        Replace = null;
        //        allowStyle = null;
        //        restrictedStyle = null;
        //        MatchCase = false;
        //        paragraphStyle = false;
        //        characterStyle = false;

        //        Search = @"\b(?:https?://|www\.)[^ \f\n\r\t\v\]]+\b(\/?)+";
        //        Replace = "weblinks";
        //        allowStyle = "";
        //        restrictedStyle = "";
        //        MatchCase = false;
        //        paragraphStyle = false;
        //        characterStyle = true;
        //        SearchAndReplaceFromWord(filePath, Search, Replace, allowStyle, restrictedStyle, MatchCase, paragraphStyle, characterStyle);

        //        Replace = null;
        //        allowStyle = null;
        //        restrictedStyle = null;
        //        MatchCase = false;
        //        paragraphStyle = false;
        //        characterStyle = false;

        //        Search = @"^[a-z\.]+\S?";
        //        Replace = "label-tfn";
        //        allowStyle = "TFN";
        //        restrictedStyle = "";
        //        MatchCase = false;
        //        paragraphStyle = false;
        //        characterStyle = true;
        //        SearchAndReplaceFromWord(filePath, Search, Replace, allowStyle, restrictedStyle, MatchCase, paragraphStyle, characterStyle);

        //        Replace = null;
        //        allowStyle = null;
        //        restrictedStyle = null;
        //        MatchCase = false;
        //        paragraphStyle = false;
        //        characterStyle = false;

        //        Search = @"\bsecci\u00F3n\u00A0[0-9\.]+\b";
        //        Replace = "citesec";
        //        allowStyle = "";
        //        restrictedStyle = "";
        //        MatchCase = false;
        //        paragraphStyle = false;
        //        characterStyle = true;
        //        SearchAndReplaceFromWord(filePath, Search, Replace, allowStyle, restrictedStyle, MatchCase, paragraphStyle, characterStyle);

        //        Replace = null;
        //        allowStyle = null;
        //        restrictedStyle = null;
        //        MatchCase = false;
        //        paragraphStyle = false;
        //        characterStyle = false;

        //        Search = @"\bsecci\u00F3n [0-9\.]+\b";
        //        Replace = "citesec";
        //        allowStyle = "";
        //        restrictedStyle = "";
        //        MatchCase = false;
        //        paragraphStyle = false;
        //        characterStyle = true;
        //        SearchAndReplaceFromWord(filePath, Search, Replace, allowStyle, restrictedStyle, MatchCase, paragraphStyle, characterStyle);

        //    }
        //    catch (Exception ex)
        //    {
        //        // Write into log file
        //    }
        //}

        //private static string ReplaceWord(string content, string strsearch, string replace, bool matchCase)
        //{

        //    if (matchCase)
        //    {
        //        Regex regex = new Regex(@"\b" + strsearch + @"\b");
        //        if (regex.IsMatch(content))
        //        {
        //            string pattern = @"\b" + strsearch + @"\b";
        //            content = Regex.Replace(content, pattern, replace, RegexOptions.None);
        //        }
        //    }
        //    else
        //    {
        //        Regex regex = new Regex(@"\b" + strsearch + @"\b");
        //        if (regex.IsMatch(content))
        //        {
        //            content = content.Replace(strsearch, replace);
        //        }
        //    }

        //    return content;
        //}

        //private static void AddReplaceCharacterStyle(Run run, string content, string styleName, string find, string replace)
        //{
        //    Regex regex = new Regex(@find);
        //    if (regex.IsMatch(content))
        //    {
        //        string[] strArray = Regex.Split(content, @"(" + find + ")");

        //        foreach (Text t in run.Elements<Text>())
        //        {
        //            if (strArray.Length > 1)
        //            {
        //                foreach (var i in strArray)
        //                {
        //                    if (regex.IsMatch(i))
        //                    {
        //                        Regex newregex = new Regex(@"[y][\\ ][0-9]+.[0-9]+");
        //                        if (newregex.IsMatch(i))
        //                        {
        //                            string[] strArray1 = Regex.Split(i, @"[\\ ](y)[\\ ]");
        //                            if (strArray1.Length > 0)
        //                            {
        //                                Run newrun1 = new Run(new RunProperties(new RunStyle() { Val = replace }));
        //                                newrun1.AppendChild(new Text(strArray1[0]) { Space = SpaceProcessingModeValues.Preserve });
        //                                run.InsertBeforeSelf(newrun1);
        //                                Run newrun2 = new Run(new Text(" "+strArray1[1]+" ") { Space = SpaceProcessingModeValues.Preserve });
        //                                run.InsertBeforeSelf(newrun2);
        //                                Run newrun3 = new Run(new RunProperties(new RunStyle() { Val = replace }));
        //                                newrun3.AppendChild(new Text(strArray1[2]) { Space = SpaceProcessingModeValues.Preserve });
        //                                run.InsertBeforeSelf(newrun3);

        //                            }
        //                        }
        //                        else
        //                        {
        //                            Run newrun = new Run();
        //                            RunProperties runPro = new RunProperties(new RunStyle() { Val = replace });
        //                            newrun.AppendChild(runPro);
        //                            newrun.AppendChild(new Text(i));
        //                            run.InsertBeforeSelf(newrun);

        //                        }


        //                }
        //                    else
        //                    {
        //                        if (i != "")
        //                        {
        //                            Run newrun = new Run(new Text(i));
        //                            run.InsertBeforeSelf(newrun);
        //                        }
        //                    }

        //                }

        //            }
        //            else
        //            {
        //                if (strArray[1] != "")
        //                {
        //                    Run newrun = new Run(new Text(strArray[1]));
        //                    run.InsertBeforeSelf(newrun);
        //                }

        //            }
        //        }
        //        run.Remove();
        //    }

        //}

        //private static Paragraph ReplaceParagraphStyleName(Paragraph p, string content, string search, string replaceStyleName)
        //{
        //    Regex regex = new Regex(@search);
        //    if (regex.IsMatch(content))
        //    {
        //        if ((p.ParagraphProperties != null) && (p.ParagraphProperties.ParagraphStyleId != null))
        //        {
        //            p.ParagraphProperties.ParagraphStyleId.Val.Value = replaceStyleName;
        //            return p;
        //        }
        //    }


        //    return null;
        //}

        //private static void SearchAndReplaceFromWord(string filePath, string strsearch, string replace, string allowstyle = "", string restrictstyle = "", bool matchCase = false, bool paraStyle = false, bool charStyle = false)
        //{
        //    using (WordprocessingDocument wDoc = WordprocessingDocument.Open(filePath, true))
        //    {
        //        RevisionAccepter.AcceptRevisions(wDoc);
        //        SimplifyMarkupSettings settings = new SimplifyMarkupSettings
        //        {
        //            NormalizeXml = true,
        //            RemoveHyperlinks = true,
        //            RemoveComments = true,
        //            RemoveContentControls = true,
        //            RemoveLastRenderedPageBreak = true,
        //            RemovePermissions = true,
        //            RemoveProof = true,
        //            RemoveRsidInfo = true,
        //            RemoveSmartTags = true,
        //            RemoveSoftHyphens = false,
        //            ReplaceTabsWithSpaces = true,

        //            RemoveEndAndFootNotes = false,
        //            RemoveFieldCodes = false,
        //            AcceptRevisions = true,
        //            RemoveBookmarks = true,
        //            RemoveGoBackBookmark = true,
        //            RemoveWebHidden = true,
        //            RemoveMarkupForDocumentComparison = true,
        //        };

        //        MarkupSimplifier.SimplifyMarkup(wDoc, settings);

        //        var xDoc = wDoc.MainDocumentPart.Document.Body;

        //        var para = xDoc.Elements<Paragraph>();


        //        var styleName = "";
        //        foreach (var p in para)
        //        {
        //            if ((p.ParagraphProperties != null) && (p.ParagraphProperties.ParagraphStyleId != null))
        //            {
        //                styleName = p.ParagraphProperties.ParagraphStyleId.Val.Value;
        //            }
        //            int runLength = p.Elements<Run>().Count();
        //            repeat:
        //            foreach (var r in p.Elements<Run>())
        //            {
        //                if (r.RunProperties == null)
        //                {
        //                    foreach (var t in r.Elements<Text>())
        //                    {

        //                        if (allowstyle != "")
        //                        {
        //                            if (styleName == allowstyle)
        //                            {
        //                                if (paraStyle)
        //                                    ReplaceParagraphStyleName(p, t.Text, strsearch, replace);
        //                                else if (charStyle)
        //                                {
        //                                    AddReplaceCharacterStyle(r, t.Text, styleName, strsearch, replace);
        //                                    //break;
        //                                }

        //                                else
        //                                    ReplaceWord(t.Text, strsearch, replace, matchCase);
        //                            }

        //                        }
        //                        else if (restrictstyle != "")
        //                        {
        //                            if (styleName != restrictstyle)
        //                            {
        //                                if (paraStyle)
        //                                    ReplaceParagraphStyleName(p, t.Text, strsearch, replace);
        //                                else if (charStyle)
        //                                {
        //                                    AddReplaceCharacterStyle(r, t.Text, styleName, strsearch, replace);
        //                                    //break;
        //                                }

        //                                else
        //                                    ReplaceWord(t.Text, strsearch, replace, matchCase);
        //                            }

        //                        }
        //                        else
        //                        {
        //                            if (paraStyle)
        //                                ReplaceParagraphStyleName(p, t.Text, strsearch, replace);
        //                            else if (charStyle)
        //                            {
        //                                AddReplaceCharacterStyle(r, t.Text, styleName, strsearch, replace);
        //                                //break;
        //                            }

        //                            else
        //                                ReplaceWord(t.Text, strsearch, replace, matchCase);
        //                        }
        //                    }
        //                }

        //            }
        //            /*
        //             * The below part will check the count of Elements<Run> in Paragraph and call the loop again
        //             */
        //            if (runLength < p.Elements<Run>().Count())
        //            {
        //                runLength = runLength + 1;
        //                goto repeat;
        //            }
        //        }

        //        wDoc.MainDocumentPart.PutXDocument();
        //    }
        //}
    }
}
