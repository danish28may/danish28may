﻿using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;
using OpenXmlPowerTools;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml;
using System.Xml.Linq;


namespace CleanupMarkup
{
    class MapStylesWithWordTemplateWTO
    {
        public static void ExecuteStyleMapping(string newDoc, string StyleMappingConfig)
        {
            // Read the StyleMappingConfing and store the values in array //
            List<string> strStyleMapping = new List<string>();

            strStyleMapping = GlobalMethodsWTO.ReadAndStoreFileValuesInArray(StyleMappingConfig);

            string SourceStyle = null;
            string TargetStyle = null;

            using (WordprocessingDocument wDoc = WordprocessingDocument.Open(newDoc, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    RemoveComments = true,
                    RemoveContentControls = true,
                    RemoveEndAndFootNotes = false,
                    RemoveFieldCodes = false,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = true,
                };

                MarkupSimplifier.SimplifyMarkup(wDoc, settings);

                var xDoc = wDoc.MainDocumentPart.GetXDocument();

                XmlDocument xd = xDoc.GetXmlDocument();

                xd.LoadXml(xd.InnerXml);

                XmlNodeList nodeList;


                XmlNamespaceManager ns = new XmlNamespaceManager(xd.NameTable);
                ns.AddNamespace("w", "http://schemas.openxmlformats.org/wordprocessingml/2006/main");

                XmlNode root = xd.DocumentElement;
                nodeList = root.SelectNodes("w:body[w:p/w:pPr]", ns);

                XElement xe;
                XAttribute xaCaption = null;

                XAttribute xPTStyleAttr = null;
               

                bool bTitlePublication = false;


                bool bCaptionFound = false;

                bool bTable = false, bFigure = false, bBox = false;

                foreach (XmlNode book in nodeList)
                {
                    xe = book.GetXElement();

                    if (xe.HasElements)
                    {
                        foreach (XElement xee in xe.Elements())
                        {
                            if (xee.HasElements)
                            {
                                    // Check if the paragraph has style element
                                if (CheckIfTheParaHasChildElement(xee) == false)
                                {
                                    // Create new Style element with Normal style

                                    foreach (string strStyle in strStyleMapping)
                                    {
                                        if (strStyle != null)
                                        {
                                            SourceStyle = null;
                                            TargetStyle = null;
                                            string[] t = strStyle.Split('|');

                                            if (t.Length > 0)
                                            {
                                                SourceStyle = t[0];
                                                TargetStyle = t[1];

                                                if (SourceStyle == "Normal")
                                                {
                                                    XNamespace w = @"http://schemas.openxmlformats.org/wordprocessingml/2006/main";
                                                    XElement style = new XElement(w + "pPr", "",
                                                        new XElement(w + "pStyle", new XAttribute(w + "val", TargetStyle)));
                                                    xee.AddFirst(style);
                                                }
                                            }
                                        }
                                    }
                                }
                                else
                                {
                                    foreach (XElement xec in xee.Elements())
                                    {
                                        if (xec.HasElements)
                                        {
                                            foreach (XElement xec1 in xec.Elements())
                                            {
                                                if (xec1.Name.LocalName == "t")
                                                {
                                                    if (bCaptionFound == true)
                                                    {
                                                        //if (xec1.Value.ToLower().StartsWith("fig ") == true)
                                                        //{
                                                        //    if (xaCaption != null)
                                                        //    {
                                                        //        bTable = false;
                                                        //        bFigure = false;
                                                        //        bBox = false;
                                                        //        bCaptionFound = false;
                                                        //        xaCaption.SetValue("FIGC");
                                                        //    }
                                                        //}

                                                        //if (xec1.Value.ToLower().StartsWith("part ") == true)
                                                        //{
                                                        //    if (xaCaption != null)
                                                        //    {
                                                        //        bTable = false;
                                                        //        bFigure = false;
                                                        //        bBox = false;
                                                        //        bCaptionFound = false;
                                                        //        xaCaption.SetValue("PT");
                                                        //    }
                                                        //}

                                                        if (xec1.Value.ToLower().StartsWith("cuadro") == true )
                                                        {
                                                            if (xaCaption != null)
                                                            {
                                                                bTable = true;
                                                                bFigure = false;
                                                                bBox = false;
                                                                bCaptionFound = false;
                                                                xaCaption.SetValue("TT");
                                                            }
                                                        }

                                                        if (xec1.Value.ToLower().StartsWith("gráfico") == true)
                                                        {
                                                            if (xaCaption != null)
                                                            {
                                                                bTable = false;
                                                                bFigure = true;
                                                                bBox = false;

                                                                bCaptionFound = false;
                                                                xaCaption.SetValue("FIGC");
                                                            }
                                                        }

                                                        if (xec1.Value.ToLower().StartsWith("recuadro") == true )
                                                        {
                                                            if (xaCaption != null)
                                                            {
                                                                bTable = false;
                                                                bFigure = false;
                                                                bBox = true;

                                                                bCaptionFound = false;
                                                                xaCaption.SetValue("TT");//xaCaption.SetValue("BT");
                                                            }
                                                        }
                                                    }
                                                    else
                                                    {
                                                        // Check if the text starts with Frontmatter or Part A or Part B or Part C
                                                        if (xec1.Value.ToLower().StartsWith("frontmatter") == true)
                                                        {
                                                            if (xPTStyleAttr != null)
                                                            {
                                                                xPTStyleAttr.SetValue("PT");
                                                                bTitlePublication = false;
                                                            }
                                                        }

                                                        else if (xec1.Value.ToLower().StartsWith("parte a") == true)
                                                        {
                                                            if (xPTStyleAttr != null)
                                                            {
                                                                xPTStyleAttr.SetValue("PT");
                                                                bTitlePublication = false;
                                                            }
                                                        }

                                                        else if (xec1.Value.ToLower().StartsWith("parte b") == true)
                                                        {
                                                            if (xPTStyleAttr != null)
                                                            {
                                                                xPTStyleAttr.SetValue("PT");
                                                                bTitlePublication = false;
                                                            }
                                                        }

                                                        else if (xec1.Value.ToLower().StartsWith("parte c") == true)
                                                        {
                                                            if (xPTStyleAttr != null)
                                                            {
                                                                xPTStyleAttr.SetValue("PT");
                                                                bTitlePublication = false;
                                                            }
                                                        }
                                                        else if (xPTStyleAttr != null)
                                                        {
                                                            if(bTitlePublication == true)
                                                                xPTStyleAttr.SetValue("CT");

                                                            bTitlePublication = false;
                                                        }
                                                        if (xec1.Value.ToLower().StartsWith("table"))
                                                        {                                                        
                                                                bTable = true;                                                              
                                                            
                                                        }
                                                    }
                                                }
                                                if (xec1.Name.LocalName == "pStyle")
                                                {
                                                    foreach (XAttribute xa1 in xec1.Attributes())
                                                    {
                                                        if (xa1.Name == W.val)
                                                        {
                                                            if (xa1.Value.ToLower() == "titlepublication")
                                                            {
                                                                bTitlePublication = true;
                                                                xPTStyleAttr = xa1;
                                                            }
                                                            else if (xa1.Value.ToLower() == "caption")
                                                            {
                                                                bCaptionFound = true;
                                                                xaCaption = xa1;
                                                            }
                                                            //else if (xa1.Value.ToLower() == "notetext" || xa1.Value.ToLower() == "bodya")
                                                            //{
                                                            //    if (bTable == true)
                                                            //    {
                                                            //        xa1.SetValue("TFN");
                                                            //    }

                                                            //    if (bFigure == true)
                                                            //    {
                                                            //        xa1.SetValue("FIGP");
                                                            //    }

                                                            //    if (bBox == true)
                                                            //    {
                                                            //        xa1.SetValue("TFN");
                                                            //    }
                                                            //}
                                                            else
                                                            {
                                                                foreach (string strStyle in strStyleMapping)
                                                                {
                                                                    if (strStyle != null)
                                                                    {
                                                                        SourceStyle = null;
                                                                        TargetStyle = null;
                                                                        string[] t = strStyle.Split('|');

                                                                        if (t.Length > 0)
                                                                        {
                                                                            SourceStyle = t[0];
                                                                            TargetStyle = t[1];

                                                                            if (xa1.Value.ToLower() == SourceStyle.ToLower())
                                                                            {
                                                                                bTitlePublication = false;
                                                                                //xAttrFIG = null;
                                                                                xaCaption = null;
                                                                                //xa1.Value = TargetStyle;
                                                                                xa1.SetValue(TargetStyle);
                                                                                //MessageBox.Show(SourceStyle + " To be replaced by " + TargetStyle);
                                                                            }
                                                                        }
                                                                    }
                                                                } // For Each
                                                            }
                                                        }
                                                    }
                                                }

                                                if (xec1.Name.LocalName == "numPr")
                                                {
                                                    xec1.RemoveAll();
                                                }
                                            }
                                        }
                                    } //For each
                                }

                            }//if (xee.HasElements)
                        }
                    }

                    //root.InnerXml = xe.GetXmlNode().InnerXml;
                    //xd.InnerXml = root.InnerXml;
                    xd.FirstChild.FirstChild.InnerXml = ((System.Xml.XmlDocument)(xe.GetXmlNode())).DocumentElement.InnerXml;
                    //xd.ReplaceChild(((System.Xml.XmlDocument)(xe.GetXmlNode())).DocumentElement, xd.FirstChild.FirstChild);
                }
                wDoc.MainDocumentPart.PutXDocument(xd.GetXDocument());
            } // End of Word Processing

            //CheckParaTextAndApplyStyle(newDoc);
        }

        public static bool CheckIfTheParaHasChildElement(XElement xee)
        {
            foreach (XElement xec in xee.Elements())
            {
                if (xec.HasElements)
                {
                    foreach (XElement xec1 in xec.Elements())
                    {
                        if (xec1.Name.LocalName == "pStyle")
                        {
                            return true;
                        }
                    }
                }
            }

            return false;
        }

        public static bool CheckParaTextAndApplyStyle(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    NormalizeXml = true,
                    RemoveHyperlinks = true,
                    RemoveComments = true,
                    RemoveContentControls = true,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = true,

                    RemoveEndAndFootNotes = false,
                    RemoveFieldCodes = false,
                    AcceptRevisions = true,
                    RemoveBookmarks = true,
                    RemoveGoBackBookmark = true,
                    RemoveWebHidden = true,
                    RemoveMarkupForDocumentComparison = true,
                };

                MarkupSimplifier.SimplifyMarkup(WPD, settings);

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                bool bBreakRun = false;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P.HasChildren == true)
                    {
                        if(P.ParagraphProperties != null)
                        {
                            if(P.ParagraphProperties.ParagraphStyleId != null)
                            {
                                foreach (Run R in P.Descendants<Run>().ToList())
                                {
                                    bBreakRun = false;
                                    foreach (Text T in R.Descendants<Text>().ToList())
                                    {
                                        if(T.Text.ToLower().StartsWith("fig "))
                                        {
                                            P.ParagraphProperties.ParagraphStyleId.Val = "FIGC";
                                        }
                                        else if (T.Text.ToLower().StartsWith("part "))
                                        {
                                            P.ParagraphProperties.ParagraphStyleId.Val = "PT";
                                        }

                                        bBreakRun = true;
                                        break;
                                    }

                                    if (bBreakRun == true)
                                        break;
                                }
                            }
                        }
                    }
                }

                D.Save();
            }

            return true;   
        }
    }
}
