﻿using DocumentFormat.OpenXml.Packaging;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using System.IO.Packaging;
using OpenXmlPowerTools;
using DocumentFormat.OpenXml.Wordprocessing;
using DocumentFormat.OpenXml;

namespace CleanupMarkup
{
    class ArrangeFootNotesWTO
    {
        private static Paragraph GetFootNoteContent(WordprocessingDocument wDoc, string footnoteRef)
        {
            Paragraph para = null;
            FootnotesPart footnotesPart = wDoc.MainDocumentPart.FootnotesPart;
            if (footnotesPart != null)
            {
                var footnotes = footnotesPart.Footnotes.Elements<Footnote>();
                foreach (var f in footnotes)
                {
                    if (f.Id == footnoteRef)
                    {
                        foreach (Paragraph p in f.Elements<Paragraph>())
                        {
                            foreach (Run r in p.Elements<Run>())
                            {
                                if (r.Elements<Text>().Count() == 0)
                                {
                                    if ((r.Elements<NoBreakHyphen>() != null) && (r.Elements<NoBreakHyphen>().Count() == 0))
                                    {
                                        if (r.FirstChild != null)
                                            r.FirstChild.Remove();
                                        if (r.LastChild != null)
                                            r.LastChild.Remove();
                                    }

                                }

                            }
                            para = p;
                            break;
                        }
                        break;
                    }
                }

            }

            return para;
        }
        public static void Footnotes(string filePath)
        {
            using (WordprocessingDocument wDoc = WordprocessingDocument.Open(filePath, true))
            {
                var xDoc = wDoc.MainDocumentPart.Document.Body;

                var para = xDoc.Elements<Paragraph>();
                bool hasCT = false;
                List<Paragraph> listofFootnotes = new List<Paragraph>();
                int footnoteCount = 0;
                foreach (Paragraph p in para)
                {
                    var styleName = "";
                    if ((p.ParagraphProperties != null) && (p.ParagraphProperties.ParagraphStyleId != null))
                    {
                        styleName = p.ParagraphProperties.ParagraphStyleId.Val.Value;
                        if (styleName == "CT") hasCT = true;
                    }

                    int runLength = p.Elements<Run>().Count();
                    repeat:
                    runLength = runLength - 1;

                    foreach (var r in p.Elements<Run>())
                    {
                        foreach (var f in r.Elements<FootnoteReference>())
                        {
                            Paragraph footnotecontent = GetFootNoteContent(wDoc, f.Id);
                            listofFootnotes.Add(footnotecontent);
                            footnoteCount = footnoteCount + 1;
                            //Run newrun = new Run(
                            //                new RunProperties(
                            //                    new RunStyle(){
                            //                        Val = "citefn"
                            //                    }
                            //                )
                            //    );
                            //newrun.AppendChild(new Text(footnoteCount.ToString()));
                            //r.InsertBeforeSelf(newrun);
                            //r.Remove();
                            Run newrun = new Run();
                            RunProperties newrpr = new RunProperties();
                            newrpr.VerticalTextAlignment = new VerticalTextAlignment { Val = VerticalPositionValues.Superscript };
                            newrpr.RunStyle = new RunStyle() { Val = "citefn" };

                            newrun.Append(newrpr.CloneNode(true));
                            newrun.AppendChild(new Text(footnoteCount.ToString()));
                            r.InsertBeforeSelf(newrun);
                            r.Remove();
                        }
                    }

                    if (runLength > 0)
                    {
                        goto repeat;
                    }

                    if (p.NextSibling<Paragraph>() != null)
                    {
                        var nextPara = p.NextSibling<Paragraph>();
                        if ((nextPara.ParagraphProperties != null) && (nextPara.ParagraphProperties.ParagraphStyleId != null))
                        {
                            var newstyleName = nextPara.ParagraphProperties.ParagraphStyleId.Val.Value;
                            if ((newstyleName == "CT") || (newstyleName == "PT"))
                            {
                                if (listofFootnotes.Count != 0)
                                {
                                    for (int i = listofFootnotes.Count; i > 0; i--)
                                    {
                                        Paragraph appendPara = new Paragraph(
                                                                    new ParagraphProperties(
                                                                        new ParagraphStyleId()
                                                                        {
                                                                            Val = "FTN"
                                                                        }
                                                                    )
                                                               );
                                        p.InsertAfterSelf(appendPara);

                                        Run appendRun = new Run(
                                                            new RunProperties(
                                                                new RunStyle()
                                                                {
                                                                    Val = "label-fn"
                                                                }
                                                            )
                                                        );
                                        appendPara.AppendChild(appendRun);
                                        
                                        appendRun.AppendChild(new Text(i + "") { Space = SpaceProcessingModeValues.Preserve });

                                        foreach (Run ir in listofFootnotes[i-1].Elements<Run>())
                                        {
                                            if (ir.HasChildren)
                                            {
                                                appendPara.AppendChild(ir.CloneNode(true));

                                            }
                                        }

                                    }
                                    listofFootnotes.Clear();
                                    footnoteCount = 0;
                                    hasCT = false;
                                }
                            }
                        }
                    }

                    //lastpara = p;
                }

                if (hasCT)
                {
                    if (listofFootnotes.Count != 0)
                    {
                        for (int i = 0; i < listofFootnotes.Count; i++)
                        {
                            Paragraph appendPara = xDoc.AppendChild(new Paragraph(new ParagraphProperties(new ParagraphStyleId() { Val = "FTN" })));
                            Run newrun = new Run(
                                                new RunProperties(
                                                    new RunStyle() {
                                                        Val = "label-fn"
                                                    }
                                                )
                                );
                            newrun.AppendChild(new Text(i+1 + "") { Space = SpaceProcessingModeValues.Preserve });
                            
                            appendPara.AppendChild(newrun);
                            
                            foreach (Run ir in listofFootnotes[i].Elements<Run>())
                            {
                                if (ir.HasChildren)
                                {
                                    appendPara.AppendChild(ir.CloneNode(true));
                                    
                                }

                            }
                            
                        }
                        listofFootnotes.Clear();
                    }
                }

                wDoc.MainDocumentPart.PutXDocument();
            }
        }
    }
}
