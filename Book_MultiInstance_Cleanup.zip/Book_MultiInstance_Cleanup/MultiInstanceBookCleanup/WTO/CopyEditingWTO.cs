﻿using CopyEditing;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;
using OpenXmlPowerTools;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;

namespace CleanupMarkup
{
    class CopyEditingWTO
    {
        public static void PerformCopyEditing(string newDoc)
        {
            try
            {
                using (WordprocessingDocument wDoc = WordprocessingDocument.Open(newDoc, true))
                {
                    RevisionAccepter.AcceptRevisions(wDoc);

                    SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                    {
                        RemoveComments = true,
                        RemoveContentControls = true,
                        RemoveFieldCodes = false,
                        RemoveLastRenderedPageBreak = true,
                        RemovePermissions = true,
                        RemoveProof = true,
                        RemoveRsidInfo = true,
                        RemoveSmartTags = true,
                        RemoveSoftHyphens = true,
                        ReplaceTabsWithSpaces = true,
                    };

                    MarkupSimplifier.SimplifyMarkup(wDoc, settings);
                    var xDoc = wDoc.MainDocumentPart.GetXDocument();
                    IEnumerable<XElement> content;
                    content = xDoc.Descendants(W.p);

                    DoubleOrMoreSpaceToSingleSpace(content);
                    SpacesBeforeAfterMathematicalSymbol(content);
                    IdentifyEllipses(content);
                    RemoveSpacesBeforePercentSymbol(content);
                    SpaceRequiredAfterComma(content);
                    CommaPeriodInsideQuotationMark(content);
                    AddCommaAfterEg(content);
                    AddCommaAfterIe(content);

                    SpaceRequiredAfterDot(content);
                    SpaceRequiredAfterSemicolon(content);
                    SpaceRequiredAfterQuestionMark(content);
                    SpaceRequiredAfterExclamation(content);
                    RemoveSpacesBeforeComma(content);
                    RemoveSpacesBeforeDot(content);
                    RemoveSpacesBeforeSemicolon(content);
                    RemoveSpacesBeforeQuestionMark(content);
                    RemoveSpacesBeforeExclamation(content);
                    SpacesBeforeAfterDegreeSymbol(content);
                    RemoveSpaceBetweenEg(content);
                    RemoveSpaceBetweenIe(content);

                    ConvertSIUnits(content);
                    SpacesBeforeAfterHyphen(content);
                    SpacesBeforeAfterEmDash(content);
                    SpacesBeforeAfterEnDash(content);
                    ReplaceFigureWithFigInParenthesis(content);
                    SpaceRequiredBeforeOpeningParenthesis(content);
                    NoSpaceAfterOpeningParenthesis(content);
                    SpaceRequiredAfterClosingParenthesis(content);
                    NoSpaceBeforeClosingParenthesis(content);
                    IdentifyEtAl(content);
                    DoubleOrMoreSpaceToSingleSpace(content);

                    wDoc.MainDocumentPart.PutXDocument();
                }
            }
            catch (Exception x)
            {

            }
        }

        private static void RemoveSpacesBeforeComma(IEnumerable<XElement> content)
        {
            Regex regex = new Regex("\x020+(,)");
            int count = OpenXmlRegexModified.Replace(content, regex, ",", null, false, "3ClicksMaster", "RemoveSpacesBeforeComma");
        }
        private static void RemoveSpacesBeforeDot(IEnumerable<XElement> content)
        {
            Regex regex = new Regex("\x020+(\\.)");
            int count = OpenXmlRegexModified.Replace(content, regex, ".", null, false, "3ClicksMaster", "RemoveSpacesBeforeDot");
        }
        private static void RemoveSpacesBeforeSemicolon(IEnumerable<XElement> content)
        {
            Regex regex = new Regex("\x020+(;)");
            int count = OpenXmlRegexModified.Replace(content, regex, ";", null, false, "3ClicksMaster", "RemoveSpacesBeforeSemicolon");
        }
        private static void RemoveSpacesBeforeQuestionMark(IEnumerable<XElement> content)
        {
            Regex regex = new Regex("\x020+(\\?)");
            int count = OpenXmlRegexModified.Replace(content, regex, "?", null, false, "3ClicksMaster", "RemoveSpacesBeforeQuestionMark");
        }
        private static void RemoveSpacesBeforeExclamation(IEnumerable<XElement> content)
        {
            Regex regex = new Regex("\x020+(!)");
            int count = OpenXmlRegexModified.Replace(content, regex, "!", null, false, "3ClicksMaster", "RemoveSpacesBeforeExclamation");
        }
        private static void SpaceRequiredAfterComma(IEnumerable<XElement> content)//updated
        {
            Regex regex = new Regex(@",([^\s\d])");
            var m = new List<string>(); int i = 0;
            int count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "SpaceRequiredAfterComma");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    if (mm == ",”") { }
                    else
                    {
                        string m1 = mm.Replace(",", ", ");
                        string mm1 = mm; bool skip = false;
                        //if (mm1.Contains("\u0001")) { skip = true; }
                        if (skip == false)
                        {
                            Regex r1 = new Regex(mm1);
                            int count1 = OpenXmlRegexModified.Replace(content, r1, m1, null, false, "3ClicksMaster", "SpaceRequiredAfterComma");
                        }
                    }
                }
            }
        }
        private static void SpaceRequiredAfterDot(IEnumerable<XElement> content)
        {
            Regex regex = new Regex(@"\.([^\s\d(com)])");
            var m = new List<string>(); int i = 0;
            int count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "SpaceRequiredAfterDot");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    if (mm == ".e") { }
                    else if (mm == ".g") { }
                    else if (mm == ".,") { }
                    else if (mm == ".)") { }
                    else if (mm == ".”") { }
                    else
                    {
                        string m1 = mm.Replace(".", ". ");
                        string mm1 = mm.Replace("(", "[(]");
                        mm1 = mm1.Replace(".", "\\.");
                        Regex r1 = new Regex(mm1);
                        int count1 = OpenXmlRegexModified.Replace(content, r1, m1, null, false, "3ClicksMaster", "SpaceRequiredAfterDot");
                    }
                }
            }
        }
        private static void SpaceRequiredAfterSemicolon(IEnumerable<XElement> content)
        {
            Regex regex = new Regex(@";([^\s])");
            var m = new List<string>(); int i = 0;
            int count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "SpaceRequiredAfterDot");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    string m1 = mm.Replace(";", "; ");
                    string mm1 = mm;
                    Regex r1 = new Regex(mm1);
                    int count1 = OpenXmlRegexModified.Replace(content, r1, m1, null, false, "3ClicksMaster", "SpaceRequiredAfterDot");
                }
            }
        }
        private static void SpaceRequiredAfterQuestionMark(IEnumerable<XElement> content)
        {
            Regex regex = new Regex(@"\?([^\s])");
            var m = new List<string>(); int i = 0;
            int count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "SpaceRequiredAfterQuestionMark");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    string m1 = mm.Replace("?", "? ");
                    string mm1 = mm;
                    mm1 = mm1.Replace("?", "\\?");
                    Regex r1 = new Regex(mm1);
                    int count1 = OpenXmlRegexModified.Replace(content, r1, m1, null, false, "3ClicksMaster", "SpaceRequiredAfterQuestionMark");
                }
            }
        }
        private static void SpaceRequiredAfterExclamation(IEnumerable<XElement> content)
        {
            Regex regex = new Regex(@"!([^\s])");
            var m = new List<string>(); int i = 0;
            int count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "SpaceRequiredAfterExclamation");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    string m1 = mm.Replace("!", "! ");
                    string mm1 = mm;
                    Regex r1 = new Regex(mm1);
                    int count1 = OpenXmlRegexModified.Replace(content, r1, m1, null, false, "3ClicksMaster", "SpaceRequiredAfterExclamation");
                }
            }
        }
        private static void SpacesBeforeAfterDegreeSymbol(IEnumerable<XElement> content)
        {
            Regex regex = new Regex("(°)\x020+");
            int count = OpenXmlRegexModified.Replace(content, regex, "°", null, false, "3ClicksMaster", "SpacesBeforeAfterDegreeSymbol");
            regex = new Regex("\x020+(°)");
            count = OpenXmlRegexModified.Replace(content, regex, "°", null, false, "3ClicksMaster", "SpacesBeforeAfterDegreeSymbol");
        }
        private static void AddCommaAfterEg(IEnumerable<XElement> content)//to be looked into
        {
            Regex regex = new Regex("(e\\.g\\.)[^,]");
            var m = new List<string>(); int i = 0;
            int count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "AddCommaAfterEg");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    string m1 = mm.Replace("e.g.", "e.g., ");
                    string mm1 = mm; bool skip = false;
                    if (skip == false)
                    {
                        Regex r1 = new Regex(mm1);
                        int count1 = OpenXmlRegexModified.Replace(content, r1, m1, null, false, "3ClicksMaster", "AddCommaAfterEg");
                    }
                }
            }
        }
        private static void RemoveSpaceBetweenEg(IEnumerable<XElement> content)
        {
            Regex regex = new Regex("(e\\.)[\\s](g\\.)[,]");
            int count = OpenXmlRegexModified.Replace(content, regex, "e.g.,", null, false, "3ClicksMaster", "RemoveSpaceBetweenEg");
        }
        private static void AddCommaAfterIe(IEnumerable<XElement> content)
        {
            Regex regex = new Regex("(i[\\.]e[\\.])[^,]");
            var m = new List<string>(); int i = 0;
            int count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "AddCommaAfterIe");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    string m1 = mm.Replace("i.e.", "i.e., ");
                    string mm1 = mm; bool skip = false;
                    mm1 = mm1.Replace("i.e.", "i\\.e\\.");
                    //if (mm1.Contains("\u0001")) { skip = true; }
                    if (skip == false)
                    {
                        Regex r1 = new Regex(mm1);
                        int count1 = OpenXmlRegexModified.Replace(content, r1, m1, null, false, "3ClicksMaster", "AddCommaAfterIe");
                    }
                }
            }
        }
        private static void RemoveSpaceBetweenIe(IEnumerable<XElement> content)
        {
            //Regex regex = new Regex("(i[\\.\\s]e[\\.,])");
            Regex regex = new Regex("(i\\.)[\\s](e\\.)[,]");
            int count = OpenXmlRegexModified.Replace(content, regex, "i.e.,", null, false, "3ClicksMaster", "RemoveSpaceBetweenIe");
        }
        private static void DoubleOrMoreSpaceToSingleSpace(IEnumerable<XElement> content)
        {
            Regex regex = new Regex("\x020+(\x020)");
            int count = OpenXmlRegexModified.Replace(content, regex, "\x020", null, false, "3ClicksMaster", "DoubleOrMoreSpaceToSingleSpace");
        }
        private static void ConvertSIUnits(IEnumerable<XElement> content)
        {
            Regex regex = new Regex(@"(\d)\s(millimeter)");
            var m = new List<string>(); int i = 0;
            int count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "ConvertSIUnits");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    string m1 = mm.Replace("millimeter", "mm");
                    Regex r1 = new Regex(mm);
                    int count1 = OpenXmlRegexModified.Replace(content, r1, m1, null, false, "3ClicksMaster", "ConvertSIUnits");
                }
            }
            regex = new Regex(@"(\d)(millimeter)");
            m = new List<string>(); i = 0;
            count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "ConvertSIUnits");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    string m1 = mm.Replace("millimeter", "\x020mm");
                    Regex r1 = new Regex(mm);
                    int count1 = OpenXmlRegexModified.Replace(content, r1, m1, null, false, "3ClicksMaster", "ConvertSIUnits");
                }
            }
            regex = new Regex(@"(\d)(mm)");
            m = new List<string>(); i = 0;
            count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "ConvertSIUnits");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    string m1 = mm.Replace("mm", "\x020mm");
                    Regex r1 = new Regex(mm);
                    int count1 = OpenXmlRegexModified.Replace(content, r1, m1, null, false, "3ClicksMaster", "ConvertSIUnits");
                }

            }

        }
        private static void SpacesBeforeAfterHyphen(IEnumerable<XElement> content)
        {
            Regex regex = new Regex("(-)\x020+");
            int count = OpenXmlRegexModified.Replace(content, regex, "-", null, false, "3ClicksMaster", "SpacesBeforeAfterHyphen");
            regex = new Regex("\x020+(-)");
            count = OpenXmlRegexModified.Replace(content, regex, "-", null, false, "3ClicksMaster", "SpacesBeforeAfterHyphen");
        }
        private static void SpacesBeforeAfterEmDash(IEnumerable<XElement> content)
        {
            Regex regex = new Regex("(—)\x020+");
            int count = OpenXmlRegexModified.Replace(content, regex, "—", null, false, "3ClicksMaster", "SpacesBeforeAfterEmDash");
            regex = new Regex("\x020+(—)");
            count = OpenXmlRegexModified.Replace(content, regex, "—", null, false, "3ClicksMaster", "SpacesBeforeAfterEmDash");
        }
        private static void SpacesBeforeAfterEnDash(IEnumerable<XElement> content)
        {
            Regex regex = new Regex("(–)\x020+");
            int count = OpenXmlRegexModified.Replace(content, regex, "–", null, false, "3ClicksMaster", "SpacesBeforeAfterEnDash");
            regex = new Regex("\x020+(–)");
            count = OpenXmlRegexModified.Replace(content, regex, "–", null, false, "3ClicksMaster", "SpacesBeforeAfterEnDash");
        }

        private static void SpaceRequiredAfterSingleQuote(IEnumerable<XElement> content)//not required
        {
            Regex regex = new Regex(@"’([^\s])");
            var m = new List<string>(); int i = 0;
            int count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "SpaceRequiredAfterSingleQuote");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    string m1 = mm.Replace("’", "’ ");
                    Regex r1 = new Regex(mm);
                    int count1 = OpenXmlRegexModified.Replace(content, r1, m1, null, false, "3ClicksMaster", "SpaceRequiredAfterSingleQuote");
                }
            }
        }
        private static void ReplaceFigureWithFigInParenthesis(IEnumerable<XElement> content)
        {
            Regex regex = new Regex(@"[(](Figure)");
            int count = OpenXmlRegexModified.Replace(content, regex, "(Fig", null, false, "3ClicksMaster", "ReplaceFigureWithFigInParenthesis");
        }
        private static void SpaceRequiredBeforeOpeningParenthesis(IEnumerable<XElement> content)//updated
        {
            Regex regex = new Regex("[^\\s][(][^s)]");
            var m = new List<string>(); int i = 0;
            int count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "SpaceRequiredBeforeOpeningParenthesis");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    string mm1 = mm.Replace("(", "[(]");
                    mm1 = mm1.Replace(")", "[)]");
                    mm1 = mm1.Replace(".", "\\.");
                    string m1 = mm.Replace("(", " (");
                    Regex r1 = new Regex(mm1);
                    int count1 = OpenXmlRegexModified.Replace(content, r1, m1, null, false, "3ClicksMaster", "SpaceRequiredBeforeOpeningParenthesis");
                }
            }
        }
        private static void NoSpaceAfterOpeningParenthesis(IEnumerable<XElement> content)
        {
            Regex regex = new Regex("[(]\x020+");
            int count1 = OpenXmlRegexModified.Replace(content, regex, "(", null, false, "3ClicksMaster", "NoSpaceAfterOpeningParenthesis");
        }//update not required
        private static void SpaceRequiredAfterClosingParenthesis(IEnumerable<XElement> content)
        {
            Regex regex = new Regex("[)][^\\s]");
            var m = new List<string>(); int i = 0;
            int count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "SpaceRequiredAfterClosingParenthesis");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    if (mm == "),") { }
                    else if (mm == ").") { }
                    else if (mm == ");") { }
                    else
                    {
                        string mm1 = mm.Replace(")", "[)]");
                        mm1 = mm1.Replace("(", "[(]");
                        mm1 = mm1.Replace(".", "\\.");
                        string s = mm.Replace(")", ")\x020");
                        Regex r1 = new Regex(mm1);
                        int count1 = OpenXmlRegexModified.Replace(content, r1, s, null, false, "3ClicksMaster", "SpaceRequiredAfterClosingParenthesis");
                    }
                }
            }
        }//updated
        private static void NoSpaceBeforeClosingParenthesis(IEnumerable<XElement> content)
        {
            Regex regex = new Regex("\x020+[)]");
            int count1 = OpenXmlRegexModified.Replace(content, regex, ")", null, false, "3ClicksMaster", "NoSpaceBeforeClosingParenthesis");
        }//update not required
        private static void IdentifyEtAl(IEnumerable<XElement> content)
        {
            Regex regex = new Regex("([^\\s]et[\\s]al[\\s])");
            var m = new List<string>(); int i = 0;
            int count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "NoSpaceBeforeClosingParenthesis");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    string m1 = mm.Replace("et al", " et al ");
                    string mm1 = mm; bool skip = false;
                    //if (mm1.Contains("\u0001")) { skip = true; }
                    if (skip == false)
                    {
                        Regex r1 = new Regex(mm1);
                        int count1 = OpenXmlRegexModified.Replace(content, r1, m1, null, false, "3ClicksMaster", "NoSpaceBeforeClosingParenthesis");
                    }
                }
            }
            regex = new Regex("([^\\s]et[\\s]al[\\.])");
            m = new List<string>(); i = 0;
            count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "NoSpaceBeforeClosingParenthesis");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    string m1 = mm.Replace("et al.", " et al ");
                    string mm1 = mm; bool skip = false;
                    //if (mm1.Contains("\u0001")) { skip = true; }
                    if (skip == false)
                    {
                        Regex r1 = new Regex(mm1);
                        int count1 = OpenXmlRegexModified.Replace(content, r1, m1, null, false, "3ClicksMaster", "NoSpaceBeforeClosingParenthesis");
                    }
                }
            }
            regex = new Regex("([^\\s]et[\\s]al)[^\\s]");
            m = new List<string>(); i = 0;
            content = content.Skip(1).Take(1);
            count = OpenXmlRegex.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; });
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    string m1 = mm.Replace("et al", " et al ");
                    string mm1 = mm; bool skip = false;
                    //if (mm1.Contains("\u0001")) { skip = true; }
                    if (skip == false)
                    {
                        Regex r1 = new Regex(mm1);
                        int count1 = OpenXmlRegexModified.Replace(content, r1, m1, null, false, "3ClicksMaster", "NoSpaceBeforeClosingParenthesis");
                    }
                }
            }
        }
        private static void IdentifyEllipses(IEnumerable<XElement> content)
        {
            Regex regex = new Regex("\x020+\\.\\.\\.\x020+");
            int count = OpenXmlRegexModified.Replace(content, regex, " \u2026 ", null, false, "3ClicksMaster", "IdentifyEllipses");
            regex = new Regex("\x020+\\.\\s\\.\\s\\.\x020+");
            count = OpenXmlRegexModified.Replace(content, regex, " \u2026 ", null, false, "3ClicksMaster", "IdentifyEllipses");
            regex = new Regex("\x020+(\u2026)\x020+");
            count = OpenXmlRegexModified.Replace(content, regex, " \u2026 ", null, false, "3ClicksMaster", "IdentifyEllipses");
        }
        private static void SpacesBeforeAfterMathematicalSymbol(IEnumerable<XElement> content)
        {
            Regex regex = new Regex("[\\+][^\\s]");
            var m = new List<string>(); int i = 0;
            int count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "SpacesBeforeAfterMathematicalSymbol");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    if (mm == "+)") { }
                    else if (mm == "(+") { }
                    else
                    {
                        string mm1 = mm.Replace("+", "\\+");
                        mm1 = mm1.Replace(".", "\\.");
                        string s = mm.Replace("+", "+\x020");
                        Regex r1 = new Regex(mm1);
                        int count1 = OpenXmlRegexModified.Replace(content, r1, s, null, false, "3ClicksMaster", "SpacesBeforeAfterMathematicalSymbol");
                    }
                }
            }
            regex = new Regex("[^\\s][\\+]");
            m = new List<string>(); i = 0;
            count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "SpacesBeforeAfterMathematicalSymbol");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    if (mm == "(+") { }
                    else
                    {
                        string mm1 = mm.Replace("+", "\\+");
                        mm1 = mm1.Replace(".", "\\.");
                        string s = mm.Replace("+", "\x020+");
                        Regex r1 = new Regex(mm1);
                        int count1 = OpenXmlRegexModified.Replace(content, r1, s, null, false, "3ClicksMaster", "SpacesBeforeAfterMathematicalSymbol");
                    }
                }
            }
            regex = new Regex("[=][^\\s]");
            m = new List<string>(); i = 0;
            count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "SpacesBeforeAfterMathematicalSymbol");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    if (mm == "=)") { }
                    else if (mm == "(=") { }
                    else
                    {
                        string mm1 = mm.Replace(".", "\\.");
                        string s = mm.Replace("=", "=\x020");
                        Regex r1 = new Regex(mm1);
                        int count1 = OpenXmlRegexModified.Replace(content, r1, s, null, false, "3ClicksMaster", "SpacesBeforeAfterMathematicalSymbol");
                    }
                }
            }
            regex = new Regex("[^\\s][=]");
            m = new List<string>(); i = 0;
            count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "SpacesBeforeAfterMathematicalSymbol");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    if (mm == "(=") { }
                    else
                    {
                        string mm1 = mm.Replace(".", "\\.");
                        string s = mm.Replace("=", "\x020=");
                        Regex r1 = new Regex(mm1);
                        int count1 = OpenXmlRegexModified.Replace(content, r1, s, null, false, "3ClicksMaster", "SpacesBeforeAfterMathematicalSymbol");
                    }
                }
            }
            regex = new Regex("[−][^\\s]");
            m = new List<string>(); i = 0;
            count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "SpacesBeforeAfterMathematicalSymbol");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    if (mm == "−)") { }
                    else if (mm == "(−") { }
                    else
                    {
                        string mm1 = mm.Replace(".", "\\.");
                        string s = mm.Replace("−", "−\x020");
                        Regex r1 = new Regex(mm1);
                        int count1 = OpenXmlRegexModified.Replace(content, r1, s, null, false, "3ClicksMaster", "SpacesBeforeAfterMathematicalSymbol");
                    }
                }
            }
            regex = new Regex("[^\\s][−]");
            m = new List<string>(); i = 0;
            count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "SpacesBeforeAfterMathematicalSymbol");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    if (mm == "(−") { }
                    else
                    {
                        string mm1 = mm.Replace(".", "\\.");
                        string s = mm.Replace("−", "\x020−");
                        Regex r1 = new Regex(mm1);
                        int count1 = OpenXmlRegexModified.Replace(content, r1, s, null, false, "3ClicksMaster", "SpacesBeforeAfterMathematicalSymbol");
                    }
                }
            }
            regex = new Regex("[±][^\\s]");
            m = new List<string>(); i = 0;
            count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "SpacesBeforeAfterMathematicalSymbol");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    if (mm == "±)") { }
                    else if (mm == "(±") { }
                    else
                    {
                        string mm1 = mm.Replace(".", "\\.");
                        string s = mm.Replace("±", "±\x020");
                        Regex r1 = new Regex(mm1);
                        int count1 = OpenXmlRegexModified.Replace(content, r1, s, null, false, "3ClicksMaster", "SpacesBeforeAfterMathematicalSymbol");
                    }
                }
            }
            regex = new Regex("[^\\s][±]");
            m = new List<string>(); i = 0;
            count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "SpacesBeforeAfterMathematicalSymbol");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    if (mm == "(±") { }
                    else
                    {
                        string mm1 = mm.Replace(".", "\\.");
                        string s = mm.Replace("±", "\x020±");
                        Regex r1 = new Regex(mm1);
                        int count1 = OpenXmlRegexModified.Replace(content, r1, s, null, false, "3ClicksMaster", "SpacesBeforeAfterMathematicalSymbol");
                    }
                }
            }
            regex = new Regex("[≥][^\\s]");
            m = new List<string>(); i = 0;
            count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "SpacesBeforeAfterMathematicalSymbol");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    if (mm == "≥)") { }
                    else if (mm == "(≥") { }
                    else
                    {
                        string mm1 = mm.Replace(".", "\\.");
                        string s = mm.Replace("≥", "≥\x020");
                        Regex r1 = new Regex(mm1);
                        int count1 = OpenXmlRegexModified.Replace(content, r1, s, null, false, "3ClicksMaster", "SpacesBeforeAfterMathematicalSymbol");
                    }
                }
            }
            regex = new Regex("[^\\s][≥]");
            m = new List<string>(); i = 0;
            count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "SpacesBeforeAfterMathematicalSymbol");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    if (mm == "(≥") { }
                    else
                    {
                        string mm1 = mm.Replace(".", "\\.");
                        string s = mm.Replace("≥", "\x020≥");
                        Regex r1 = new Regex(mm1);
                        int count1 = OpenXmlRegexModified.Replace(content, r1, s, null, false, "3ClicksMaster", "SpacesBeforeAfterMathematicalSymbol");
                    }
                }
            }
            regex = new Regex("[<][^\\s]");
            m = new List<string>(); i = 0;
            count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "SpacesBeforeAfterMathematicalSymbol");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    if (mm == "<)") { }
                    else if (mm == "(<") { }
                    else
                    {
                        string mm1 = mm.Replace(".", "\\.");
                        string s = mm.Replace("<", "<\x020");
                        Regex r1 = new Regex(mm1);
                        int count1 = OpenXmlRegexModified.Replace(content, r1, s, null, false, "3ClicksMaster", "SpacesBeforeAfterMathematicalSymbol");
                    }
                }
            }
            regex = new Regex("[^\\s][<]");
            m = new List<string>(); i = 0;
            count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "SpacesBeforeAfterMathematicalSymbol");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    if (mm == "(<") { }
                    else
                    {
                        string mm1 = mm.Replace(".", "\\.");
                        string s = mm.Replace("<", "\x020<");
                        Regex r1 = new Regex(mm1);
                        int count1 = OpenXmlRegexModified.Replace(content, r1, s, null, false, "3ClicksMaster", "SpacesBeforeAfterMathematicalSymbol");
                    }
                }
            }
            regex = new Regex("[>][^\\s]");
            m = new List<string>(); i = 0;
            count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "SpacesBeforeAfterMathematicalSymbol");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    if (mm == ">)") { }
                    else if (mm == "(>") { }
                    else
                    {
                        string mm1 = mm.Replace(".", "\\.");
                        string s = mm.Replace(">", ">\x020");
                        Regex r1 = new Regex(mm1);
                        int count1 = OpenXmlRegexModified.Replace(content, r1, s, null, false, "3ClicksMaster", "SpacesBeforeAfterMathematicalSymbol");
                    }
                }
            }
            regex = new Regex("[^\\s][>]");
            m = new List<string>(); i = 0;
            count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "SpacesBeforeAfterMathematicalSymbol");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    if (mm == "(>") { }
                    else
                    {
                        string mm1 = mm.Replace(".", "\\.");
                        string s = mm.Replace(">", "\x020>");
                        Regex r1 = new Regex(mm1);
                        int count1 = OpenXmlRegexModified.Replace(content, r1, s, null, false, "3ClicksMaster", "SpacesBeforeAfterMathematicalSymbol");
                    }
                }
            }
            regex = new Regex("[×][^\\s]");
            m = new List<string>(); i = 0;
            count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "SpacesBeforeAfterMathematicalSymbol");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    if (mm == "×)") { }
                    else if (mm == "(×") { }
                    else
                    {
                        string mm1 = mm.Replace(".", "\\.");
                        string s = mm.Replace("×", "×\x020");
                        Regex r1 = new Regex(mm1);
                        int count1 = OpenXmlRegexModified.Replace(content, r1, s, null, false, "3ClicksMaster", "SpacesBeforeAfterMathematicalSymbol");
                    }
                }
            }
            regex = new Regex("[^\\s][×]");
            m = new List<string>(); i = 0;
            count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "SpacesBeforeAfterMathematicalSymbol");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    if (mm == "(±") { }
                    else
                    {
                        string mm1 = mm.Replace(".", "\\.");
                        string s = mm.Replace("×", "\x020×");
                        Regex r1 = new Regex(mm1);
                        int count1 = OpenXmlRegexModified.Replace(content, r1, s, null, false, "3ClicksMaster", "SpacesBeforeAfterMathematicalSymbol");
                    }
                }
            }
            regex = new Regex("[÷][^\\s]");
            m = new List<string>(); i = 0;
            count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "SpacesBeforeAfterMathematicalSymbol");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    if (mm == "÷)") { }
                    else if (mm == "(÷") { }
                    else
                    {
                        string mm1 = mm.Replace(".", "\\.");
                        string s = mm.Replace("÷", "÷\x020");
                        Regex r1 = new Regex(mm1);
                        int count1 = OpenXmlRegexModified.Replace(content, r1, s, null, false, "3ClicksMaster", "SpacesBeforeAfterMathematicalSymbol");
                    }
                }
            }
            regex = new Regex("[^\\s][÷]");
            m = new List<string>(); i = 0;
            count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "SpacesBeforeAfterMathematicalSymbol");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    if (mm == "(÷") { }
                    else
                    {
                        string mm1 = mm.Replace(".", "\\.");
                        string s = mm.Replace("÷", "\x020÷");
                        Regex r1 = new Regex(mm1);
                        int count1 = OpenXmlRegexModified.Replace(content, r1, s, null, false, "3ClicksMaster", "SpacesBeforeAfterMathematicalSymbol");
                    }
                }
            }
            regex = new Regex("[~][^\\s]");
            m = new List<string>(); i = 0;
            count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "SpacesBeforeAfterMathematicalSymbol");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    if (mm == "~)") { }
                    else if (mm == "(~") { }
                    else
                    {
                        string mm1 = mm.Replace(".", "\\.");
                        string s = mm.Replace("~", "~\x020");
                        Regex r1 = new Regex(mm1);
                        int count1 = OpenXmlRegexModified.Replace(content, r1, s, null, false, "3ClicksMaster", "SpacesBeforeAfterMathematicalSymbol");
                    }
                }
            }
            regex = new Regex("[^\\s][~]");
            m = new List<string>(); i = 0;
            count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "SpacesBeforeAfterMathematicalSymbol");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    if (mm == "(~") { }
                    else
                    {
                        string mm1 = mm.Replace(".", "\\.");
                        string s = mm.Replace("~", "\x020~");
                        Regex r1 = new Regex(mm1);
                        int count1 = OpenXmlRegexModified.Replace(content, r1, s, null, false, "3ClicksMaster", "SpacesBeforeAfterMathematicalSymbol");
                    }
                }
            }
            regex = new Regex("[≈][^\\s]");
            m = new List<string>(); i = 0;
            count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "SpacesBeforeAfterMathematicalSymbol");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    if (mm == "≈)") { }
                    else if (mm == "(≈") { }
                    else
                    {
                        string mm1 = mm.Replace(".", "\\.");
                        string s = mm.Replace("≈", "≈\x020");
                        Regex r1 = new Regex(mm1);
                        int count1 = OpenXmlRegexModified.Replace(content, r1, s, null, false, "3ClicksMaster", "SpacesBeforeAfterMathematicalSymbol");
                    }
                }
            }
            regex = new Regex("[^\\s][≈]");
            m = new List<string>(); i = 0;
            count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "SpacesBeforeAfterMathematicalSymbol");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    if (mm == "(≈") { }
                    else
                    {
                        string mm1 = mm.Replace(".", "\\.");
                        string s = mm.Replace("≈", "\x020≈");
                        Regex r1 = new Regex(mm1);
                        int count1 = OpenXmlRegexModified.Replace(content, r1, s, null, false, "3ClicksMaster", "SpacesBeforeAfterMathematicalSymbol");
                    }
                }
            }
        }//updated
        private static void RemoveSpacesBeforePercentSymbol(IEnumerable<XElement> content)//update not required
        {
            Regex regex = new Regex("\x020+(%)");
            int count = OpenXmlRegexModified.Replace(content, regex, "%", null, false, "3ClicksMaster", "RemoveSpacesBeforePercentSymbol");
        }
        private static void CommaPeriodInsideQuotationMark(IEnumerable<XElement> content)//update not required
        {
            Regex regex = new Regex("\\”,");
            int count = OpenXmlRegexModified.Replace(content, regex, ",”", null, false, "3ClicksMaster", "CommaPeriodInsideQuotationMark");
            regex = new Regex("(”\\.)");
            count = OpenXmlRegexModified.Replace(content, regex, ".”", null, false, "3ClicksMaster", "CommaPeriodInsideQuotationMark");
            regex = new Regex("(;”)");
            count = OpenXmlRegexModified.Replace(content, regex, "”;", null, false, "3ClicksMaster", "CommaPeriodInsideQuotationMark");
        }
    }
}
