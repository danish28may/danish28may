﻿using DocumentFormat.OpenXml.Packaging;
using OpenXmlPowerTools;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MultiInstanceBookCleanup
{
    class NormalizeWordDocument
    {
        public static void NormalizeWord(string strFilePath)
        {
            using (WordprocessingDocument wDoc = WordprocessingDocument.Open(strFilePath, true))
            {
                RevisionAccepter.AcceptRevisions(wDoc);
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    NormalizeXml = true,
                    RemoveHyperlinks = false,
                    //RemoveComments = false,
                    RemoveContentControls = true,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = false,

                    RemoveEndAndFootNotes = false,
                    RemoveFieldCodes = false,
                    AcceptRevisions = true,
                    RemoveBookmarks = true,
                    RemoveGoBackBookmark = true,
                    RemoveWebHidden = true,
                    RemoveMarkupForDocumentComparison = true,
                };

                MarkupSimplifier.SimplifyMarkup(wDoc, settings);

                wDoc.MainDocumentPart.PutXDocument();
                wDoc.Close();
            }

            // Convert Special Font characters to Special Characters //


        }
    }
}
