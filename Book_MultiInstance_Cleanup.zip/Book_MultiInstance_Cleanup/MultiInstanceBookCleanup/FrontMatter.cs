﻿using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;
using OpenXmlPowerTools;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace MultiInstanceBookCleanup
{
    class FrontMatter
    {

        public static void ParaStyleApply(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                                               .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P != null)
                    {
                        if (P.ParagraphProperties != null)
                        {
                            P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "Para" });
                        }
                    }
                }
                D.Save();
            }
        }

        public static void Book_title_and_book_subtitle(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                                               .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                bool subtitle = false;

                string TitleName = GlobalMethods.BookTitle.Trim().ToLower();
                int count = 0;///Added on 15-01-2021
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P != null && P.InnerText.Trim() != "")
                    {
                        count++;
                        if (P.InnerText != null && P.InnerText != "" && (P.InnerText.Replace(" ", "").Trim().ToLower().Equals(TitleName.Replace(" ", "")) || count == 1) && subtitle == false) //Developer name Priyanka Vishwakarma ,Date:17-06-2020 ,Requirement :apply bktitile and subtitle style.///count condition added by vikas on 15-01-2021
                        {
                            if (P.ParagraphProperties != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId.Val.Value != null && P.ParagraphProperties.ParagraphStyleId.Val.Value != "")
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val.Value = "Book-Title";
                                        subtitle = true;
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "Book-Title" };
                                    subtitle = true;
                                }
                            }
                            else
                            {
                                P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "Book-Title" });
                                subtitle = true;
                            }
                        }
                        else if (subtitle == true && P.InnerText != null && P.InnerText != "")
                        {
                            if (P.ParagraphProperties != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId.Val.Value != null && P.ParagraphProperties.ParagraphStyleId.Val.Value != "")
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val.Value = "Book-Subtitle";
                                        subtitle = false;
                                        break;
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "Book-Subtitle" };
                                    subtitle = false;
                                    break;
                                }
                            }
                            else
                            {
                                P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "Book-Subtitle" });
                                subtitle = false;
                                break;
                            }
                        }
                    }
                }
                D.Save();
            }
        }

        public static void AuthorStyleApply(string newDoc, string DegreeDb)
        {
            List<string> strDegreesColl = new List<string>();
            strDegreesColl = GlobalMethods.ReadAndStoreFileValuesInArray(DegreeDb);
            strDegreesColl = GlobalMethods.SortStringListOnLength(strDegreesColl);

            using (WordprocessingDocument WPD = WordprocessingDocument
                                               .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                bool stylefound = false;
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    //if (P != null && P.InnerText != null && P.InnerText != "")
                    //{
                    //if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val.Value == "ListofcontributorsStart")
                    //{
                    //    stylefound = true;
                    //}
                    //else if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val.Value == "ListofcontributorsEnd")
                    //{
                    //    stylefound = false;
                    //}
                    //if (P.InnerText.ToLower().Replace(" ", "") == "listofcontributors")
                    //{
                    //    stylefound = true;
                    //}
                    if (P.InnerText.ToLower().Replace(" ", "") == "listofcontributors")
                    {
                        stylefound = true;
                    }
                    if (stylefound == false)
                    {
                        //foreach (var degree in strDegreesColl)
                        //{


                        if (strDegreesColl.Any(degree => P.InnerText.Replace(" ", "").EndsWith("," + degree)))
                        {
                            //if (P.ParagraphProperties != null)
                            //{
                            //    if (P.ParagraphProperties.ParagraphStyleId != null)
                            //    {
                            //        if (P.ParagraphProperties.ParagraphStyleId.Val.Value != null && P.ParagraphProperties.ParagraphStyleId.Val.Value != "")
                            //        {
                            //            P.ParagraphProperties.ParagraphStyleId.Val.Value = "Author";
                            //        }
                            //    }
                            //    else
                            //    {
                            //        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "Author" };
                            //    }
                            //}
                            //else
                            //{
                            P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "Author" });
                            //}
                        }
                        //}
                    }
                    //}
                }
                D.Save();
            }
        }
        public static void AuthorDetailsStyleApply(string newDoc, string DegreeDb)/////For FM automation author details after Book-Title Added by vikas on 16-01-2021
        {
            List<string> strDegreesColl = new List<string>();
            strDegreesColl = GlobalMethods.ReadAndStoreFileValuesInArray(DegreeDb);
            strDegreesColl = GlobalMethods.SortStringListOnLength(strDegreesColl);

            using (WordprocessingDocument WPD = WordprocessingDocument
                                               .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                bool stylefound = false;
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {

                    ////Added by vikas for identify Authordetails started
                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val.Value != null && (P.ParagraphProperties.ParagraphStyleId.Val.Value == "AuthorDetailsStart"))
                    {
                        stylefound = true;
                    }
                    ////Added by vikas for identify Authordetails ended
                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val.Value != null && (P.ParagraphProperties.ParagraphStyleId.Val.Value == "AuthorDetailsEnd" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "ArtInfo" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "CongressCataloging" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H1"|| P.InnerText.ToLower() == "thieme"))
                    {
                        stylefound = false;
                        break;
                    }
                    if (stylefound == true)
                    {
                        ///If all para text ends with degree then apply Author
                        if (strDegreesColl.Any(degree => P.InnerText.Replace(" ", "").EndsWith("," + degree)))
                        {
                            if (P.ParagraphProperties != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId.Val.Value != null && P.ParagraphProperties.ParagraphStyleId.Val.Value != "")
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val.Value = "Author";
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "Author" };
                                }
                            }
                            else
                            {
                                P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "Author" });
                            }
                        }
                        else///If all para not ends with degree then apply Author-Address
                        {
                            if (P.ParagraphProperties != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId.Val.Value != null && P.ParagraphProperties.ParagraphStyleId.Val.Value != "")
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val.Value = "Author-Address";
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "Author-Address" };
                                }
                            }
                            else
                            {
                                P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "Author-Address" });
                            }
                        }



                    }
                    else
                    {
                        if (strDegreesColl.Any(degree => P.InnerText.Replace(" ", "").EndsWith("," + degree)))
                        {
                            stylefound = true;
                            if (P.ParagraphProperties != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId.Val.Value != null && P.ParagraphProperties.ParagraphStyleId.Val.Value != "")
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val.Value = "Author";
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "Author" };
                                }
                            }
                            else
                            {
                                P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "Author" });
                            }
                        }
                    }
                    //}
                }
                D.Save();
            }
        }

        public static void Title1_Style_Apply(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                                              .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P != null && P.InnerText != null && P.InnerText != "")
                    {
                        if (P.InnerText.Trim().ToLower().Equals("preface") || P.InnerText.Trim().ToLower().Equals("contents")
                            || P.InnerText.Trim().ToLower().Equals("copyright") || P.InnerText.Trim().ToLower().Equals("list of contributors"))
                        {
                            if (P.ParagraphProperties != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId.Val.Value != null && P.ParagraphProperties.ParagraphStyleId.Val.Value != "")
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val.Value = "Title1";
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "Title1" };
                                }
                            }
                            else
                            {
                                P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "Title1" });
                            }
                        }
                    }
                }
                D.Save();
            }
        }

        public static void Heading_Style_Apply(string newDoc)////Added by vikas on 18-01-2021 for apply H1
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                                              .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P != null && P.InnerText != null && P.InnerText != "")
                    {
                        if (P.InnerText.Trim().ToLower().Equals("preface") || P.InnerText.Trim().ToLower().Equals("contents")
                            || P.InnerText.Trim().ToLower().Equals("copyright") || P.InnerText.Trim().ToLower().Equals("list of contributors") || P.InnerText.Trim().ToLower().Equals("contributors") || P.InnerText.Trim().ToLower().Equals("acknowledgments") || P.InnerText.Trim().ToLower().Equals("abbreviations") || P.InnerText.Trim().ToLower().Equals("videos") || P.InnerText.Trim().ToLower().Equals("audios") || P.InnerText.Trim().ToLower().Equals("video") || P.InnerText.Trim().ToLower().Equals("audio")|| P.InnerText.Trim().ToLower().Equals("foreword")) //condition Added by vikas for acknowledgments,abbreviations,videos,video,audios,audio on 15-01-2021
                        {
                            if (P.ParagraphProperties != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId.Val.Value != null && P.ParagraphProperties.ParagraphStyleId.Val.Value != "")
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val.Value = "H1";
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "H1" };
                                }
                            }
                            else
                            {
                                P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "H1" });
                            }
                        }
                    }
                }
                D.Save();
            }
        }
        public static void Media_Style_Apply(string newDoc)////Added by vikas on 18-01-2021 for apply FIG,VideoC for video and audio
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                                              .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P != null && P.InnerText != null && P.InnerText != "")
                    {
                        if(P.InnerText.ToLower().EndsWith(".jpg")|| P.InnerText.ToLower().EndsWith(".jpeg") || P.InnerText.ToLower().EndsWith(".png") || P.InnerText.ToLower().EndsWith(".tif")|| P.InnerText.ToLower().EndsWith(".tiff")|| P.InnerText.ToLower().EndsWith(".eps"))
                        {
                            if (P.ParagraphProperties != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId.Val.Value != null && P.ParagraphProperties.ParagraphStyleId.Val.Value != "")
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val.Value = "FIG";
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "FIG" };
                                }
                            }
                            else
                            {
                                P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "FIG" });
                            }
                        }                        
                        else if ((P.InnerText.Trim().ToLower().StartsWith("video")|| P.InnerText.Trim().ToLower().StartsWith("audio")) && !P.InnerText.Trim().ToLower().Equals("videos")&& !P.InnerText.ToLower().Equals("audios")&& !P.InnerText.Trim().ToLower().Equals("video") && !P.InnerText.ToLower().Equals("audio"))/////For check video or audio para then apply VIDEOC applied same style because single style requiered for indesign xml for FM Automation
                        {
                            if (Regex.Match(P.InnerText, @"((Video|video|Audio|audio)\s([0-9]+)\.([0-9]+))").Success)
                            {
                                if (P.ParagraphProperties != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId != null)
                                    {
                                        if (P.ParagraphProperties.ParagraphStyleId.Val.Value != null && P.ParagraphProperties.ParagraphStyleId.Val.Value != "")
                                        {
                                            P.ParagraphProperties.ParagraphStyleId.Val.Value = "VIDEOC";
                                        }
                                    }
                                    else
                                    {
                                        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "VIDEOC" };
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "VIDEOC" });
                                }
                            }
                        } 
                    }
                }
                D.Save();
            }
        }

        public static void ArtInfo_and_CongressCataloging_StyleApply(string newDoc)
        {
            ////Start Added by vikas on 15-01-2021 for CopyrightPara style apply//
            bool congresscatlogstart = false;
            bool newtitlestart = false;
            ///End/////
            using (WordprocessingDocument WPD = WordprocessingDocument
                                              .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P != null && P.InnerText != null && P.InnerText != "")
                    {
                        if (P.InnerText.Trim().ToLower().Contains("illustrations"))
                        {
                            if (P.ParagraphProperties != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId.Val.Value != null && P.ParagraphProperties.ParagraphStyleId.Val.Value != "")
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val.Value = "ArtInfo";
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "ArtInfo" };
                                }
                            }
                            else
                            {
                                P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "ArtInfo" });
                            }
                        }
                        else if (P.InnerText.Trim().ToLower().Contains("congress cataloging") && congresscatlogstart == false)
                        {
                            congresscatlogstart = true; //// Added by vikas on 15-01-2021 for CopyrightPara style apply//

                            if (P.ParagraphProperties != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId.Val.Value != null && P.ParagraphProperties.ParagraphStyleId.Val.Value != "")
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val.Value = "CongressCataloging";
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "CongressCataloging" };
                                }
                            }
                            else
                            {
                                P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "CongressCataloging" });
                            }
                        }
                        ////Start Added by vikas on 15-01-2021 for CopyrightPara style apply//
                        else if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val.Value != null && P.ParagraphProperties.ParagraphStyleId.Val.Value == "CopyrightStart")
                        {
                            congresscatlogstart = true;
                        }
                        else if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val.Value != null && (P.ParagraphProperties.ParagraphStyleId.Val.Value == "H1" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "CopyrightEnd" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "Dedication"))
                        {
                            newtitlestart = true;
                        }
                        else if (congresscatlogstart == true && newtitlestart == false)
                        {
                            if (P.ParagraphProperties != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId.Val.Value != null && P.ParagraphProperties.ParagraphStyleId.Val.Value != "")
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val.Value = "CopyrightPara";
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "CopyrightPara" };
                                }
                            }
                            else
                            {
                                P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "CopyrightPara" });
                            }
                        }
                        ////End Added by vikas on 15-01-2021 for CopyrightPara style apply//

                    }
                }
                D.Save();
            }
        }
        public static void Signature_StyleApply(string newDoc)
        {
            bool prefacestart = false;
            using (WordprocessingDocument WPD = WordprocessingDocument
                                              .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P != null && P.InnerText != null && P.InnerText != "")
                    {
                        if (P.InnerText.Trim().ToLower() == "preface")
                        {
                            prefacestart = true;////for check dedication para is finished
                        }
                        if (P.ParagraphProperties != null && P.ParagraphProperties.Justification != null && P.ParagraphProperties.Justification.Val != null
                            && P.ParagraphProperties.Justification.Val == "right")
                        {
                            if (P.ParagraphProperties != null)
                            {
                                var italic = false;
                                foreach(var run in P.Descendants<Run>().ToList()) //added on 18 - 01 - 221 by vikas for check paragraph is italic or not
                                {
                                    foreach (var ele in run.Descendants<RunProperties>().ToList())
                                    {
                                        if(ele.Italic!=null)
                                        {
                                            italic = true;
                                            goto nextpara;
                                        }
                                    }
                                }
                                nextpara:
                                { }
                                if (italic)///paragraph is italic then its signature para added by vikas on 18-01-2021
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId != null)
                                    {
                                        if (P.ParagraphProperties.ParagraphStyleId.Val.Value != null && P.ParagraphProperties.ParagraphStyleId.Val.Value != "")
                                        {
                                            P.ParagraphProperties.ParagraphStyleId.Val.Value = "Signature";
                                        }
                                    }
                                    else
                                    {
                                        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "Signature" };
                                    }
                                }
                                else////This for if not signature text and right align paragraph added on 18-01-221 by vikas
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId != null)
                                    {
                                        if (P.ParagraphProperties.ParagraphStyleId.Val.Value != null && P.ParagraphProperties.ParagraphStyleId.Val.Value != "")
                                        {
                                            P.ParagraphProperties.ParagraphStyleId.Val.Value = "BodyTextRight";
                                        }
                                    }
                                    else
                                    {
                                        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "BodyTextRight" };
                                    }
                                }
                            }
                            else
                            {
                                P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "Signature" });
                            }
                        }
                        else if (P.ParagraphProperties != null && P.ParagraphProperties.Justification != null && P.ParagraphProperties.Justification.Val != null
                             && P.ParagraphProperties.Justification.Val == "center" && prefacestart == false)
                        {
                            if (P.ParagraphProperties != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId.Val.Value != null && P.ParagraphProperties.ParagraphStyleId.Val.Value != "")
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val.Value = "Dedication";
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "Dedication" };
                                }
                            }
                            else
                            {
                                P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "Dedication" });
                            }
                        }
                    }
                }
                D.Save();
            }
        }
        //------Developer name:Priyanka Vishwakarma ,Date:17-06-2020 ,Requirement:Apply CT style to Frontmatter keywords.
        public static void FrontMatterKeywords(string newDoc)
        {
            //use tempervaory H1 style for logic.
            GlobalMethods.FrontMatterKeywords = ConfigurationManager.AppSettings.Get("3CMFrontMatterKeywords");

            List<string> FrontMatterKeywordsColl = new List<string>();
            ///Configuration read from Supporting folder
            FrontMatterKeywordsColl = GlobalMethods.ReadAndStoreFileValuesInArray(GlobalMethods.FrontMatterKeywords);
            using (WordprocessingDocument WPD = WordprocessingDocument
                .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P != null && P.InnerText != "")
                    {
                        string a = P.InnerText.ToLower();

                        for (int i = 0; i < FrontMatterKeywordsColl.Count; i++)
                        {
                            if (FrontMatterKeywordsColl[i].ToLower().Trim() == a.Trim())
                            {
                                if (P.ParagraphProperties != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId != null)
                                    {

                                        P.ParagraphProperties.ParagraphStyleId.Val = "CT";

                                    }
                                    else
                                    {
                                        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "CT" };
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "CT" });
                                }
                            }
                        }
                    }
                }
                D.Save();
            }
        }
        public static void applyCTStyleToBM(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
               .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val.Value == "H1")
                    {
                        if (P.InnerText != null)
                        {
                            if (P.InnerText.ToLower().Trim() == "index")
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "CT";
                            }
                        }

                    }

                }
                D.Save();
            }
            //Contributors
        }
        public static void applyContributeStyle(string newDoc)
        {
            bool foundContributePara = false;
            using (WordprocessingDocument WPD = WordprocessingDocument
               .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && (P.ParagraphProperties.ParagraphStyleId.Val.Value == "CT" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H1"))///H1 style condition added by vikas on 18-01-2021 for front matter automation
                    {
                        if (P.InnerText != null)
                        {
                            if (P.InnerText.ToLower().Trim() == "contributors"|| P.InnerText.ToLower().Trim() == "contributor")////Contributor added by vikas on 18-01-2021 for single contributor
                            {
                                foundContributePara = true;
                            }
                            else
                            {
                                foundContributePara = false;
                            }
                        }

                    }
                    if (foundContributePara)
                    {
                        if (P.InnerText.ToLower().Trim() == "contributors" || P.InnerText.ToLower().Trim() == "contributor")///Contributor added by vikas on 18-01-2021 for single contributor
                        {
                            continue;
                        }
                        else
                        {
                            if (P.ParagraphProperties != null)
                            {                                
                                if (P.ParagraphProperties.ParagraphStyleId != null)
                                {

                                    P.ParagraphProperties.ParagraphStyleId.Val.Value = "Contrib-author";

                                }
                                else
                                {
                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "Contrib-author" };
                                }
                            }
                            else
                            {
                                P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "Contrib-author" });
                            }
                        }

                    }

                }
                D.Save();
            }
            //Contributors
        }
        //---------------------End on 17-06-2020 by priyanka
        public static void applyFigStyleForEpub(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
               .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                    {
                        if (P.InnerText != null)
                        {
                            if (P.InnerText.ToLower().Trim() == "cover.jpg")
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "FIG";
                            }
                            else if (Regex.IsMatch(P.InnerText.Trim(), "^[0-9]+") && P.InnerText.Trim().ToLower().EndsWith(".jpg"))
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "FIG";
                            }
                        }

                    }

                }
                D.Save();
            }
            //Contributors
        }
    }
}
