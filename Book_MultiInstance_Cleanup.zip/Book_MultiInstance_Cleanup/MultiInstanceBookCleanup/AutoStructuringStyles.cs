﻿using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;
using OpenXmlPowerTools;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace MultiInstanceBookCleanup
{
    class AutoStructuringStyles
    {
        public static void EpubWordMarkup(string newDoc)
        {
            ChapterNumber_And_Name_Split(newDoc);

            H1_And_H2_StyleApplied(newDoc);

            Level_Style_Applied(newDoc);

            TXT1_Style_Applied(newDoc);

            Fig_StyleApplied(newDoc);
        }
        private static void H1_And_H2_StyleApplied(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                                     .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;
                Document D = MDP.Document;
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    bool bBold = false;
                    bool bItalic = false;
                    bool bUnderline = false;

                    int nBold = 0;
                    int nItalic = 0;
                    int nUnderline = 0;

                    string strParaText = null;
                    foreach (Run R in P.Descendants<Run>().ToList())
                    {
                        strParaText = null;
                        foreach (Run R1 in P.Descendants<Run>().ToList())
                        {
                            foreach (Text T in R1.Descendants<Text>().ToList())
                            {
                                strParaText += T.Text;
                            }
                        }

                        if (strParaText != null)
                        {
                            if (strParaText.StartsWith("●") || strParaText.StartsWith("·") || strParaText.StartsWith("•") ||
                                                    strParaText.StartsWith("▪") || strParaText.StartsWith("■") || strParaText.StartsWith("") ||
                                                    strParaText.StartsWith("●") || strParaText.StartsWith("*") || strParaText.ToLower().Trim().StartsWith("references"))
                                continue;
                        }

                        if (R.RunProperties != null)
                        {
                            if (R.RunProperties.Bold != null && nBold == 0 && R.RunProperties.Bold.Val != "0")
                            {
                                if (R.RunProperties.Bold.Val == null)
                                {
                                    bBold = true;
                                }

                                else if (R.RunProperties.Bold.Val != "0")
                                {
                                    bBold = true;
                                }
                                else if (R.RunProperties.Bold.Val == "0")
                                {
                                    bBold = false;
                                }

                            }
                            else
                            {
                                if (R.InnerText.Trim().Equals(".") || R.InnerText.Trim().Equals("-"))
                                {
                                    goto next;
                                }
                                if (R.InnerText.Trim() != "")
                                {
                                    bBold = false;
                                    nBold = 1;
                                }
                            }
                            if (R.RunProperties.Italic != null && nItalic == 0 && R.RunProperties.Italic.Val != "0")
                            {
                                bItalic = true;
                            }
                            else
                            {
                                if (R.InnerText.Trim().Equals(".") || R.InnerText.Trim().Equals("-"))
                                {
                                    goto next;
                                }
                                if (R.InnerText.Trim() != "")
                                {
                                    nItalic = 1;
                                    bItalic = false;
                                }
                            }
                            if (R.RunProperties.Underline != null && nUnderline == 0 && R.RunProperties.Underline.Val != null && R.RunProperties.Underline.Val != "0" &&
                                R.RunProperties.Underline.Val != "none")
                            {
                                bUnderline = true;
                            }
                            else
                            {
                                if (R.InnerText.Trim().Equals(".") || R.InnerText.Trim().Equals("-"))
                                {
                                    goto next;
                                }
                                if (R.InnerText.Trim() != "")
                                {
                                    nUnderline = 1;
                                    bUnderline = false;
                                }
                            }
                        }
                        next: { }
                    }
                    if (P.ParagraphProperties != null)
                    {
                        if (bBold == true && bUnderline == true)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null)
                            {
                                if (P.ParagraphProperties.Justification != null)
                                {
                                    if (P.ParagraphProperties.Justification.Val != null)
                                    {
                                        if (P.ParagraphProperties.Justification.Val != "center")
                                        {
                                            P.ParagraphProperties.ParagraphStyleId.Val = "H1";
                                        }
                                    }
                                }
                            }
                            else
                            {
                                if (P.ParagraphProperties.Justification != null)
                                {
                                    if (P.ParagraphProperties.Justification.Val != null)
                                    {
                                        if (P.ParagraphProperties.Justification.Val != "center")
                                        {
                                            P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId();
                                            P.ParagraphProperties.ParagraphStyleId.Val = "H1";
                                        }
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId() { Val = "H1" };
                                }
                            }
                        }
                        else if (bBold == true && bUnderline == false)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null)
                            {
                                if (P.ParagraphProperties.Justification != null)
                                {
                                    if (P.ParagraphProperties.Justification.Val != null)
                                    {
                                        if (P.ParagraphProperties.Justification.Val != "center")
                                        {
                                            P.ParagraphProperties.ParagraphStyleId.Val = "H2";
                                        }
                                    }
                                }
                            }
                            else
                            {
                                if (P.ParagraphProperties.Justification != null)
                                {
                                    if (P.ParagraphProperties.Justification.Val != null)
                                    {
                                        if (P.ParagraphProperties.Justification.Val != "center")
                                        {
                                            P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId();
                                            P.ParagraphProperties.ParagraphStyleId.Val = "H2";
                                        }
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId() { Val = "H2" };
                                }
                            }
                        }
                    }
                }
                D.Save();
            }
        }

        private static void TXT1_Style_Applied(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                                     .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;
                Document D = MDP.Document;
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P.ParagraphProperties != null && P.ParagraphProperties.Indentation != null && P.ParagraphProperties.Indentation.FirstLine != null && P.ParagraphProperties.Indentation.FirstLine.Value != "")
                    {
                        if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                        {
                            P.ParagraphProperties.ParagraphStyleId.Val.Value = "TXT";
                        }
                        else
                        {
                            P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId() { Val = "TXT" };
                        }
                    }
                }
                D.Save();
            }
        }

        private static void ChapterNumber_And_Name_Split(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                                     .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;
                Document D = MDP.Document;
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    string chaptertxt = null;
                    if (P.InnerText.ToLower().Trim().StartsWith("chapter") || P.InnerText.ToLower().Trim().StartsWith("part"))
                    {
                        if (P.ParagraphProperties != null && P.ParagraphProperties.Justification != null
                            && P.ParagraphProperties.Justification.Val != null && P.ParagraphProperties.Justification.Val == "center")
                        {
                            chaptertxt = P.InnerText;
                            string[] separators = { ":" };
                            string[] links = chaptertxt.Split(separators, StringSplitOptions.RemoveEmptyEntries);
                            Paragraph firstpara = new Paragraph();
                            Paragraph secondpara = new Paragraph();
                            for (int i = 0; i < links.Count(); i++)
                            {
                                if (links[i].ToLower().Trim().StartsWith("chapter") || links[i].ToUpper().Trim().StartsWith("CAPÍTULO") || links[i].ToLower().Trim().StartsWith("part"))
                                {
                                    ParagraphProperties firstpro = new ParagraphProperties();
                                    ParagraphStyleId firstpsid = firstpro.AppendChild(new ParagraphStyleId() { Val = "CN-FM" });

                                    Run firstrun = new Run();
                                    RunProperties firstRp = firstrun.AppendChild(new RunProperties(new Bold()));
                                    Text firstparatext = new Text();
                                    string chpname = links[i] + ":";

                                    firstparatext.Text = chpname;

                                    firstrun.Append(firstparatext);
                                    firstpara.Append(firstpro);
                                    firstpara.Append(firstrun);
                                    P.InsertBeforeSelf(firstpara);
                                }
                                else
                                {
                                    ParagraphProperties secondtpro = new ParagraphProperties();
                                    ParagraphStyleId secondpsid = secondtpro.AppendChild(new ParagraphStyleId() { Val = "CT" });

                                    Run secondtrun = new Run();
                                    RunProperties secondRp = secondtrun.AppendChild(new RunProperties(new Bold()));
                                    Text secondparatext = new Text();
                                    secondparatext.Text = links[i];
                                    secondtrun.Append(secondparatext);
                                    secondpara.Append(secondtpro);
                                    secondpara.Append(secondtrun);
                                    firstpara.InsertAfterSelf(secondpara);
                                }

                            }
                            P.Remove();
                        }
                    }
                }
                D.Save();
            }
        }

        private static void Level_Style_Applied(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                                     .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;
                Document D = MDP.Document;

                int counter = 0;
                string Firstlist = null, Secondlist = null;
                List<DocumentFormat.OpenXml.Wordprocessing.Indentation> ListInd = new List<DocumentFormat.OpenXml.Wordprocessing.Indentation>();
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    string strParaText = P.InnerText;
                    if (strParaText.StartsWith("●") || strParaText.StartsWith("·") || strParaText.StartsWith("•") ||
                           strParaText.StartsWith("▪") || strParaText.StartsWith("■") || strParaText.StartsWith("●") ||
                           strParaText.StartsWith("*") || strParaText.StartsWith("o") || strParaText.StartsWith("-"))
                    {
                        foreach (ParagraphProperties pr in P.Descendants<ParagraphProperties>().ToList())
                        {
                            foreach (OpenXmlElement ox in pr.Elements())
                            {
                                if (ox.XName == W.ind)
                                {
                                    if (ox.HasAttributes)
                                    {
                                        if (counter == 0)
                                        {
                                            foreach (var item in ox.GetAttributes())
                                            {
                                                if (item.LocalName == "left" && item.Value != null)
                                                {
                                                    Firstlist = item.Value;
                                                }
                                            }
                                            counter++;
                                        }
                                        else
                                        {
                                            foreach (var item in ox.GetAttributes())
                                            {
                                                if (item.LocalName == "left" && item.Value != null)
                                                {
                                                    Secondlist = item.Value;
                                                }
                                            }

                                        }
                                        if (Secondlist != null && Firstlist != null)
                                        {
                                            if (Firstlist == Secondlist)
                                            {
                                                if (P.ParagraphProperties.ParagraphStyleId != null)
                                                {

                                                    P.ParagraphProperties.ParagraphStyleId.Val = "L1";
                                                }
                                                else
                                                {
                                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "L1" };
                                                }
                                            }
                                            else
                                            {
                                                if (P.ParagraphProperties.ParagraphStyleId != null)
                                                {
                                                    P.ParagraphProperties.ParagraphStyleId.Val = "L2";
                                                }
                                                else
                                                {
                                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "L2" };
                                                }
                                            }
                                        }
                                        else if (Firstlist != null)
                                        {
                                            if (P.ParagraphProperties.ParagraphStyleId != null)
                                            {
                                                P.ParagraphProperties.ParagraphStyleId.Val = "L1";
                                            }
                                            else
                                            {
                                                P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "L1" };
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    ///for Nl Style
                    else if (strParaText != null)
                    {
                        string startwithno = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(strParaText, @"^[0-9\.]");
                        if (startwithno != null)
                        {
                            if (strParaText.StartsWith(startwithno))
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val = "Nl";
                            }
                        }
                        else
                        {
                            Firstlist = null;
                            Secondlist = null;
                            counter = 0;
                        }
                    }
                    ////else if(strParaText != null)
                    ////{
                    ////    if(P.PreviousSibling()!= null && P.PreviousSibling().LocalName=="p" && P.PreviousSibling().InnerText.StartsWith("•"))
                    ////    {

                    ////    }
                    ////}
                    else
                    {
                        Firstlist = null;
                        Secondlist = null;
                        counter = 0;
                    }
                }
                D.Save();
            }
        }

        public static void L1_Style_AppliedOLD(string newDoc)
        {
            List<KeyValuePair<string, string>> abc = new List<KeyValuePair<string, string>>();
            List<KeyValuePair<string, string>> abc1 = new List<KeyValuePair<string, string>>();
            using (WordprocessingDocument WPD = WordprocessingDocument
                                     .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;
                Document D = MDP.Document;
                int counter = 0;
                List<DocumentFormat.OpenXml.Wordprocessing.Indentation> ListInd = new List<DocumentFormat.OpenXml.Wordprocessing.Indentation>();
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {

                    string strParaText = P.InnerText;
                    if (strParaText != null)
                    {
                        if (strParaText.StartsWith("●") || strParaText.StartsWith("·") || strParaText.StartsWith("•") ||
                           strParaText.StartsWith("▪") || strParaText.StartsWith("■") || strParaText.StartsWith("●") ||
                           strParaText.StartsWith("*") || strParaText.StartsWith("o"))
                        {
                            if (P.ParagraphProperties != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null)
                                {
                                    foreach (ParagraphProperties pr in P.Descendants<ParagraphProperties>().ToList())
                                    {
                                        foreach (OpenXmlElement ox in pr.Elements())
                                        {
                                            if (ox.XName == W.ind)
                                            {
                                                #region oldlogic
                                                if (ox.HasAttributes)
                                                {
                                                    if (counter == 0)
                                                    {
                                                        string v = null, v1 = null;
                                                        foreach (var item in ox.GetAttributes())
                                                        {
                                                            if (item.LocalName != null && item.Value != null)
                                                            {
                                                                v = item.LocalName;
                                                                v1 = item.Value;
                                                            }
                                                            abc.Add(new KeyValuePair<string, string>(v, v1));
                                                        }
                                                        counter++;
                                                    }
                                                    else
                                                    {
                                                        string v = null, v1 = null;
                                                        foreach (var item in ox.GetAttributes())
                                                        {
                                                            if (item.LocalName != null && item.Value != null)
                                                            {
                                                                v = item.LocalName;
                                                                v1 = item.Value;
                                                            }
                                                            abc1.Add(new KeyValuePair<string, string>(v, v1));

                                                        }
                                                        counter--;
                                                    }
                                                    #endregion
                                                    /////ListInd.Add((DocumentFormat.OpenXml.Wordprocessing.Indentation)ox);
                                                }
                                            }

                                        }
                                    }
                                    P.ParagraphProperties.ParagraphStyleId.Val = "L1";
                                }
                                else
                                {
                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId();
                                    P.ParagraphProperties.ParagraphStyleId.Val = "L1";
                                }
                            }
                        }
                    }

                }
                #region left indentlist
                ////var newListLeftInd = ListInd.Select(x => x.Left.Value).Distinct().ToList();
                ////var newListRightInd = ListInd.Select(x => x.Right.Value).Distinct().ToList();

                ////foreach (var val in newListLeftInd)
                ////{
                ////    foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                ////    {

                ////        string strParaText = P.InnerText;
                ////        if (strParaText != null)
                ////        {
                ////            if (strParaText.StartsWith("●") || strParaText.StartsWith("·") || strParaText.StartsWith("•") ||
                ////               strParaText.StartsWith("▪") || strParaText.StartsWith("■") || strParaText.StartsWith("") ||
                ////               strParaText.StartsWith("●") || strParaText.StartsWith("*") || strParaText.StartsWith("o"))
                ////            {
                ////                if (P.ParagraphProperties != null)
                ////                {
                ////                    if (P.ParagraphProperties.ParagraphStyleId != null)
                ////                    {
                ////                        foreach (ParagraphProperties pr in P.Descendants<ParagraphProperties>().ToList())
                ////                        {
                ////                            foreach (OpenXmlElement ox in pr.Elements())
                ////                            {
                ////                                if (ox.XName == W.ind)
                ////                                {
                ////                                    if (ox.HasAttributes)
                ////                                    {
                ////                                        if (counter == 0)
                ////                                        {
                ////                                            foreach (var item in ox.GetAttributes())
                ////                                            {
                ////                                                if (item.LocalName != null && item.Value != null)
                ////                                                {
                ////                                                    if(val== item.Value)
                ////                                                    {
                ////                                                        if (counter == 0)
                ////                                                        {
                ////                                                            P.ParagraphProperties.ParagraphStyleId.Val = "L1";
                ////                                                        }
                ////                                                        else if (counter == 1)
                ////                                                        {
                ////                                                            P.ParagraphProperties.ParagraphStyleId.Val = "L2";
                ////                                                        }
                ////                                                        else 
                ////                                                        {
                ////                                                            P.ParagraphProperties.ParagraphStyleId.Val = "L3";
                ////                                                        }
                ////                                                    }
                ////                                                }
                ////                                            }
                ////                                        }
                ////                                    }
                ////                                }
                ////                            }
                ////                        }
                ////                    }
                ////                }
                ////            }
                ////        }
                ////    }
                ////    counter++;
                ////}
                #endregion

                D.Save();
            }
        }

        public static void NormalStyleApply(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                                    .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;
                Document D = MDP.Document;
                {
                    foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                    {
                        if (P != null)
                        {
                            if (P.ParagraphProperties != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId.Val != null)
                                    {
                                        if (P.ParagraphProperties.ParagraphStyleId.Val != "Normal")
                                        {
                                            P.ParagraphProperties.ParagraphStyleId.Val = "Normal";
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                D.Save();
            }

        }

        private static void Fig_StyleApplied(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P != null && P.InnerText != "")
                    {
                        if (P.InnerText.ToLower().TrimStart().StartsWith("fig"))
                        {
                            if (P.ParagraphProperties != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null)
                                {
                                    P.ParagraphProperties.ParagraphStyleId.Val = "FIG";
                                }
                                else
                                {
                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId() { Val = "FIG" };
                                }
                            }
                            else
                            {
                                P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId() { Val = "FIG" });
                            }
                        }
                    }
                }
                D.Save();
            }
        }
        public static void Tt_StyleApplied(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P != null && P.InnerText != "")
                    {
                        if (GlobalMethods.strClientName != "VTH" && P.InnerText.ToLower().TrimStart().StartsWith("table")/* && P.Descendants<Run>().ToList().FirstOrDefault().Descendants().Any(x => x.LocalName == "b")*/)
                        {
                            if (P.ParagraphProperties != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null)
                                {
                                    P.ParagraphProperties.ParagraphStyleId.Val = "TT";
                                }
                                else
                                {
                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "TT" };
                                }
                            }
                            else
                            {
                                P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "TT" });
                            }
                        }
                    }
                }
                D.Save();
            }
        }

        public static void Ref1_StyleApplied(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                bool refstratfound = false;
                bool refendfound = false;
                bool refFound = false;  ////Developer Name:priyanka Vishwakarma ,Date:15_5_2019 ,Requirement:Apply Ref1 Style to References when in document Ref_start and Ref_End style not apply ,Integrated By:Vikas sir

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(c => c.Parent.LocalName != W.tc).ToList())
                {
                    if (P.InnerText.Contains("Descriptive statistics, part II: Most commonly used descriptive statistics, Journal for Specialists in Pediatric "))
                    {

                    }
                    if (P.ParagraphProperties != null)
                    {
                        if (P.ParagraphProperties.ParagraphStyleId != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId.Val.Value == "Ref-Start")
                            {
                                refstratfound = true;
                                refendfound = false;
                                continue;
                            }
                            else if (P.ParagraphProperties.ParagraphStyleId.Val.Value == "Ref-End")
                            {
                                refendfound = true;
                                refstratfound = false;
                                break;
                            }
                            ////Developer Name:priyanka Vishwakarma ,Date:15_5_2019 ,Requirement:Apply Ref1 Style to References when in document Ref_start and Ref_End style not apply ,Integrated By:Vikas sir
                            if (P.ParagraphProperties.ParagraphStyleId.Val.Value == "REF")
                            {
                                refFound = true;
                            }
                            else if (P.ParagraphProperties.ParagraphStyleId.Val.Value == "FIGC" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "TT")  //Developer name:priyanka Vishwakarma ,Date:28092019 ,Requirement:for avoid the REF1 style apply to figc  paragraph. Integrated by:Vikas sir. 
                            {
                                refFound = false;
                            }
                            //
                            //-------------------------end by priyanka on 15_5_2019 -----------------------------------------------
                        }
                    }
                    if (refstratfound)
                    {
                        if (P != null && P.InnerText != null)
                        {
                            if (P.ParagraphProperties != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null)
                                {
                                    P.ParagraphProperties.ParagraphStyleId.Val = "REF1";
                                }
                                else
                                {
                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "REF1" };
                                }
                            }
                            else
                            {
                                P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "REF1" });
                            }
                        }
                    }
                    ////Developer Name:priyanka Vishwakarma ,Date:15_5_2019 ,Requirement:Apply Ref1 Style to References when in document Ref_start and Ref_End style not apply ,Integrated By:Vikas sir
                    if (refFound)
                    {
                        if (P.InnerText.ToLower().Trim() == "references" || P.InnerText.ToLower().Trim().Equals("reference") || P.InnerText.ToLower().Replace(" ", "").Equals("suggestedreading") || P.InnerText.Trim().ToLower() == "bibliografia" || P.InnerText.Trim().ToLower() == "further reading" || P.InnerText.ToLower().Replace(" ", "").Trim() == ("6.literatur") || P.InnerText.ToUpper() == "REFERÊNCIAS" || P.InnerText.ToUpper() == "REFERÊNCIAS BIBLIOGRÁFICAS" || P.InnerText.ToUpper() == "BIBLIOGRÁFICAS" || Regex.Replace(P.InnerText.ToLower().Trim(), @"^\<[A-Za-z0-9]+\>", "").ToString() == "references" || Regex.Replace(P.InnerText.ToLower().Trim(), @"^\<[A-Za-z0-9]+\>", "").ToString() == "reference" || Regex.Replace(P.InnerText.ToLower().Trim(), @"^\<[A-Za-z0-9]+\>", "").ToString() == "further reading" || Regex.Replace(P.InnerText.ToLower().Trim(), @"^\<[A-Za-z0-9]+\>", "").ToString() == "literaturverzeichnis" || Regex.Replace(P.InnerText.ToLower().Trim(), @"^\<[A-Za-z0-9]+\>", "").ToString() == "bibliografia" || Regex.Replace(P.InnerText.ToUpper().Trim(), @"^\<[A-Za-z0-9]+\>", "").ToString() == "REFERÊNCIAS" || Regex.Replace(P.InnerText.ToUpper().Trim(), @"^\<[A-Za-z0-9]+\>", "").ToString() == "REFERÊNCIAS BIBLIOGRÁFICAS" || Regex.Replace(P.InnerText.ToUpper().Trim(), @"^\<[A-Za-z0-9]+\>", "").ToString() == "BIBLIOGRÁFICAS" || Regex.Replace(P.InnerText.ToUpper().Trim(), @"^\<[A-Za-z0-9]+\>", "").ToString() == "LEITURAS SUGERIDAS")
                        {
                            continue;
                        }

                        //11022020 priyanka
                        //if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val != "FTN")
                        // {
                        //     refFound = false;
                        // }
                        //For copy edited MSS where refrences are already taged
                        if (P.InnerText.StartsWith("<") && P.InnerText.EndsWith(">"))
                        {
                            if (P != null && P.InnerText != null)
                            {
                                if (P.ParagraphProperties != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId != null)
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val = "REF1";
                                    }
                                    else
                                    {
                                        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "REF1" };
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "REF1" });
                                }

                            }
                        }
                        //For Non copy edited MSS where refrence needs to be taged added by vikas on 22-09-2019
                        else if (Regex.Match(P.InnerText, @"(\d+[(]+[\d]+[)])|(\d+[(]+[\d]+[)]|\d+[;]\d+[:]\d+[\-\–]\d+)|([\.]+\s{1,}[A-Za-z\s]+\s{1,}[0-9]+[\;])|(Vol\.\s[0-9]+\,\sNo\.\s[0-9]+\,\spp\.\s[0-9]+[\-\-][0-9]+)").Success)//For <jrn> ...</jrn> //10-02-2021
                        {
                            if (P != null && P.InnerText != null)
                            {
                                if (P.ParagraphProperties != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId != null)
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val = "REF1";
                                    }
                                    else
                                    {
                                        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "REF1" };
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "REF1" });
                                }

                                if (!P.InnerText.StartsWith("<jrn>"))
                                {
                                    P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().ForEach(t => t.ToList().ForEach(txt =>
                                    {

                                        if (txt == P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().FirstOrDefault().FirstOrDefault())
                                        {
                                            txt.Text = "<jrn>" + txt.Text;
                                        }
                                        if (txt == P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().LastOrDefault().LastOrDefault())
                                        {
                                            txt.Text = txt.Text + "</jrn>";
                                        }
                                    })
                                    );
                                }

                            }
                        }
                        else if (Regex.Match(P.InnerText, @"(\s[0-9]+th+\s+ed)|([A-Za-z]+[\,]+\s{1,}[A-Za-z]+[\:]\s{1,}[A-Za-z\:\’\–\-\&\s]+[\;]+\s+[0-9]+)|(In:|In;)", RegexOptions.IgnoreCase).Success)//For <bok> ...</bok>
                        {
                            if (P != null && P.InnerText != null)
                            {
                                if (P.ParagraphProperties != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId != null)
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val = "REF1";
                                    }
                                    else
                                    {
                                        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "REF1" };
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "REF1" });
                                }

                                if (!P.InnerText.StartsWith("<bok>"))
                                {
                                    P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().ForEach(t => t.ToList().ForEach(txt =>
                                    {

                                        if (txt == P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().FirstOrDefault().FirstOrDefault())
                                        {
                                            txt.Text = "<bok>" + txt.Text;
                                        }
                                        if (txt == P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().LastOrDefault().LastOrDefault())
                                        {
                                            txt.Text = txt.Text + "</bok>";
                                        }
                                    })
                                    );
                                }

                            }

                        }
                        else if (Regex.Match(P.InnerText, @"^\d+", RegexOptions.IgnoreCase).Success || (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val.Value == "REF1"))//For <other> ...</other>
                        {
                            if (P != null && P.InnerText != null)
                            {
                                if (P.ParagraphProperties != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId != null)
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val = "REF1";
                                    }
                                    else
                                    {
                                        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "REF1" };
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "REF1" });
                                }

                                if (!P.InnerText.StartsWith("<unknown>"))
                                {
                                    P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().ForEach(t => t.ToList().ForEach(txt =>
                                    {

                                        if (txt == P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().FirstOrDefault().FirstOrDefault())
                                        {
                                            txt.Text = "<unknown>" + txt.Text;
                                        }
                                        if (txt == P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().LastOrDefault().LastOrDefault())
                                        {
                                            txt.Text = txt.Text + "</unknown>";
                                        }
                                    })
                                    );
                                }

                            }

                        }
                        else if (!P.InnerText.StartsWith("<") && !P.InnerText.EndsWith(">"))
                        {
                            refFound = false;
                        }
                        else if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val != "FTN")
                        {
                            refFound = false;
                        }
                    }
                    //-------------------------End by Priyanka on 15_5_2019----------------------------------------------------------

                }
                D.Save();
            }
        }
        public static void Tfn_StyleApplied(string newDoc)
        {

            bool tableFound = false;   //Developer Name:Priyanka Vishwakarma ,Date:13_8_2019 ,Requirement:Apply Table Footnote when paraStart with superscript present in table.(ex, a,b, or (a,b)) ,Integrated by:Viksa sir.
            List<string> txtList = new List<string>();
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P.PreviousSibling() != null && P.PreviousSibling().LocalName == "tbl")
                    {
                        tableFound = true;
                        if (P.InnerText.Trim() != "" && !P.InnerText.ToLower().StartsWith("table") && !P.InnerText.ToLower().StartsWith("fig") && !P.InnerText.ToLower().StartsWith("supplementary table") && !P.InnerText.ToLower().TrimStart().StartsWith("list of abbreviations"))  //Developer Name :Priyanka Vishwakarma ,Date:16_08_2019 ,Requirement:Add Supplemetary Table in xml ,Integrated by:Vikas Sir, //Date:16_08_2019 Requirement:Add Supplementary table.////Developer Name:Priyanka Vishwakarma ,Date:22_5_2019 ,Requirement:for avoid blank tfoot avoid ,Integrated By:Vikas sir 
                        {
                            if (P.ParagraphProperties != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val != "H1")   //  Developer Name:Priyanka Vishwakarma ,Date:19_6_2019 ,Requirement:H1 Heading apply to Appendix Para  ,Integrated By:Vikas sir
                                {
                                    P.ParagraphProperties.ParagraphStyleId.Val = "TFN";
                                }
                                else
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val != "H1") //  Developer Name:Priyanka Vishwakarma ,Date:19_6_2019 ,Requirement:H1 Heading apply to Appendix Para  ,Integrated By:Vikas sir 
                                    {
                                        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "TFN" };
                                    }
                                    // P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "TFN" };
                                }
                            }
                            else
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val != "H1") //  Developer Name:Priyanka Vishwakarma ,Date:19_6_2019 ,Requirement:H1 Heading apply to Appendix Para  ,Integrated By:Vikas sir 
                                {
                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "TFN" };
                                }
                                //P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "TFN" });
                            }
                        }
                    }
                    else if (P.InnerText.ToLower().StartsWith("source:"))
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val != "H1")   //  Developer Name:Priyanka Vishwakarma ,Date:19_6_2019 ,Requirement:H1 Heading apply to Appendix Para  ,Integrated By:Vikas sir
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val = "TFN";
                            }
                            else
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val != "H1") //  Developer Name:Priyanka Vishwakarma ,Date:19_6_2019 ,Requirement:H1 Heading apply to Appendix Para  ,Integrated By:Vikas sir 
                                {
                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "TFN" };
                                }
                                // P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "TFN" };
                            }
                        }
                        else
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val != "H1") //  Developer Name:Priyanka Vishwakarma ,Date:19_6_2019 ,Requirement:H1 Heading apply to Appendix Para  ,Integrated By:Vikas sir 
                            {
                                P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "TFN" };
                            }
                            //P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "TFN" });
                        }
                    }
                    #region table foot note style
                    else   //----create list of superscript in table.   Added By Priyanka on 19_02_2019
                    {
                        txtList.Clear();
                        foreach (var para in D.Body.ChildElements.ToList())
                        {
                            if (para.LocalName == "tbl")
                            {
                                foreach (var table1 in para.ChildElements.ToList())
                                {
                                    if (table1 != null)
                                    {
                                        if (table1.Descendants<Run>().Count() != 0)
                                        {
                                            var R = table1.Descendants<Run>().ToList();
                                            foreach (var R1 in R)
                                            {
                                                if (R1 != null)
                                                {
                                                    foreach (OpenXmlElement ox in R1.ChildElements)
                                                    {
                                                        if (ox.XName == W.rPr)
                                                        {
                                                            if (ox.HasChildren)
                                                            {
                                                                foreach (OpenXmlElement ox1 in ox.ChildElements)
                                                                {
                                                                    if (ox1.XName == W.vertAlign)
                                                                    {
                                                                        if (ox1.HasAttributes)
                                                                        {
                                                                            foreach (var item in ox1.GetAttributes())
                                                                            {
                                                                                if (item.Value == "superscript")
                                                                                {
                                                                                    // txtList.Add(R1.InnerText);
                                                                                    //Developer Name:Priyanka Vishwakarma ,Date:13_8_2019 ,Requirement:Apply Table Footnote when paraStart with superscript present in table.(ex, a,b, or (a,b)) ,Integrated by:Viksa sir.
                                                                                    if (R1.InnerText.Contains(','))
                                                                                    {
                                                                                        string[] mulSup = R1.InnerText.Split(',');
                                                                                        foreach (var a in mulSup)
                                                                                        {
                                                                                            txtList.Add(a);
                                                                                        }
                                                                                    }
                                                                                    else
                                                                                    {
                                                                                        txtList.Add(R1.InnerText);
                                                                                    }

                                                                                    //---------------------End----------------------------------------------

                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                        }

                        //for check superscript inner text match with superscript within table

                        if (P != null && tableFound == true)    //Developer Name:Priyanka Vishwakarma ,Date:13_8_2019 ,Requirement:Apply Table Footnote when paraStart with superscript present in table.(ex, a,b, or (a,b)) ,Integrated by:Viksa sir.
                        {

                            if (P.Descendants<Run>().Count() != 0)
                            {
                                Run R = P.Descendants<Run>().First();
                                if (R != null)
                                {
                                    foreach (OpenXmlElement ox in R.Elements())
                                    {
                                        if (ox.XName == W.rPr)
                                        {
                                            if (ox.HasChildren)
                                            {
                                                foreach (OpenXmlElement ox1 in ox.Elements())
                                                {
                                                    if (ox1.XName == W.vertAlign)
                                                    {
                                                        if (ox1.HasAttributes)
                                                        {
                                                            foreach (var item in ox1.GetAttributes())
                                                            {
                                                                if (item.Value == "superscript")
                                                                {
                                                                    if (P.ParagraphProperties != null)
                                                                    {

                                                                        if (P.ParagraphProperties.ParagraphStyleId != null)
                                                                        {
                                                                            for (int i = 0; i < txtList.Count; i++)
                                                                            {
                                                                                if (P.InnerText.StartsWith(txtList[i]))
                                                                                {
                                                                                    P.ParagraphProperties.ParagraphStyleId.Val.Value = "TFN";
                                                                                }
                                                                                else
                                                                                {

                                                                                }
                                                                            }

                                                                        }

                                                                    }

                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                        }
                        //---End by Priyanka on 19_02_2019. 
                        #endregion
                    }

                }
                D.Save();
            }
        }

        public static void BoxStyleMapping(string newDoc)
        {



            List<string> BoxStyleColl = new List<string>();
            ///Configuration read from Supporting folder
            BoxStyleColl = GlobalMethods.ReadAndStoreFileValuesInArray(GlobalMethods.str3CMBoxStyle);
            using (WordprocessingDocument WPD = WordprocessingDocument
                .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P != null && P.InnerText != "")
                    {
                        string a = P.InnerText.ToLower();

                        for (int i = 0; i < BoxStyleColl.Count; i++)
                        {
                            string[] boxstyle = BoxStyleColl[i].Trim().Split('=');
                            if (boxstyle.Count() > 0)
                            {
                                if (P.InnerText.Trim() == boxstyle[0])
                                {
                                    if (P.ParagraphProperties != null)
                                    {
                                        if (P.ParagraphProperties.ParagraphStyleId != null)
                                        {

                                            P.ParagraphProperties.ParagraphStyleId.Val = boxstyle[1];

                                        }
                                        else
                                        {
                                            P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = boxstyle[1] };
                                        }
                                    }
                                    else
                                    {
                                        P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = boxstyle[1] });
                                    }

                                }

                            }

                        }
                    }
                }
                D.Save();
            }
        }
        public static void CN_StyleApplied(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().Take(1).ToList())
                {
                    if (P != null && P.InnerText != "")
                    {
                        if (P.InnerText.ToLower().TrimStart().StartsWith("chapter"))
                        {
                            if (P.ParagraphProperties != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null)
                                {
                                    P.ParagraphProperties.ParagraphStyleId.Val = "CN";
                                }
                                else
                                {
                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "CN" };
                                }
                            }
                            else
                            {
                                P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "CN" });
                            }
                        }
                    }
                }
                D.Save();
            }
        }
        public static void AUStyleApply(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P.PreviousSibling() != null && P.NextSibling() != null && P.PreviousSibling().LocalName == "p" && P.NextSibling().LocalName == "p")
                    {
                        Paragraph Prev = (Paragraph)P.PreviousSibling();
                        Paragraph Next = (Paragraph)P.NextSibling();


                        if (Prev != null && Next != null && Prev.ParagraphProperties != null && Prev.ParagraphProperties.ParagraphStyleId != null && Prev.ParagraphProperties.ParagraphStyleId.Val != null && Prev.ParagraphProperties.ParagraphStyleId.Val.Value == "CT"
                           && Next.ParagraphProperties != null && Next.ParagraphProperties.ParagraphStyleId != null && Next.ParagraphProperties.ParagraphStyleId.Val != null && Next.ParagraphProperties.ParagraphStyleId.Val.Value == "ABT")
                        {
                            if (P.ParagraphProperties != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null)
                                {
                                    P.ParagraphProperties.ParagraphStyleId.Val = "AU";
                                }
                                else
                                {
                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "AU" };
                                }
                                break;
                            }
                            else
                            {
                                P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "AU" });
                                break;
                            }
                        }


                    }
                }


                D.Save();
            }
        }
        public static void BodyTextIndendStyleApply(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                                     .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;
                Document D = MDP.Document;
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P.ParagraphProperties != null && P.ParagraphProperties.Indentation != null && P.ParagraphProperties.Indentation.FirstLine != null && P.ParagraphProperties.Indentation.FirstLine.Value != "")
                    {
                        if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId.Val == "BodyA")
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "BodyTextIndent";
                            }
                        }
                        else
                        {
                            P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId() { Val = "BodyTextIndent" };
                        }
                    }
                }
                D.Save();
            }
        }
        public static void ApplyTableStyletoUnstructuredInput(string newDoc)
        {
            int row_count = 0;
            using (WordprocessingDocument WPD = WordprocessingDocument
                .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (var xe1 in D.Descendants<DocumentFormat.OpenXml.Wordprocessing.Table>().ToList())
                {
                    row_count = 0;
                    foreach (var xe2 in xe1.Descendants<DocumentFormat.OpenXml.Wordprocessing.TableRow>().ToList())  //w:tr 
                    {
                        row_count++;

                        foreach (var xe3 in xe2.Descendants<DocumentFormat.OpenXml.Wordprocessing.TableCell>().ToList())  //w:tc 
                        {
                            foreach (var xe4 in xe3.Descendants<DocumentFormat.OpenXml.Wordprocessing.Paragraph>().ToList())
                            {

                                if (xe4.Descendants().Any(x => x.XName == W.b /*|| x.XName == W.bCs*/))
                                {
                                    if (xe4.ParagraphProperties != null)
                                    {
                                        if (xe4.ParagraphProperties.ParagraphStyleId != null)
                                        {
                                            if (xe4.ParagraphProperties.ParagraphStyleId.Val != null && xe4.ParagraphProperties.ParagraphStyleId.Val.Value != "T-TXT")   //Developer name:Priyanka vishwakarma ,Date:04-03-2020 ,Requirement:T-TXT style change to TCH style in Table . Integrated by:Vikas sir. 4537_THI_J_4530_IJCDW-20-0211.docx
                                            {
                                                xe4.ParagraphProperties.ParagraphStyleId.Val = "TCH";
                                            }
                                        }
                                        else
                                        {
                                            xe4.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "TCH" };
                                        }
                                    }
                                    else
                                    {
                                        xe4.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "TCH" });
                                    }
                                }
                                else
                                {
                                    if (xe4.ParagraphProperties != null)
                                    {
                                        if (xe4.ParagraphProperties.ParagraphStyleId != null)
                                        {
                                            if (xe4.ParagraphProperties.ParagraphStyleId.Val != null && xe4.ParagraphProperties.ParagraphStyleId.Val.Value != "TCH")
                                            {
                                                xe4.ParagraphProperties.ParagraphStyleId.Val = "T-TXT";
                                            }
                                        }
                                        else
                                        {
                                            xe4.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "T-TXT" };
                                        }
                                    }
                                    else
                                    {
                                        xe4.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "T-TXT" });
                                    }

                                }

                            }




                        }
                    }
                }

                D.Save();
                WPD.Save();
            }

        }
        public static void applyREF1StyleForEpub(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                bool refstratfound = false;
                bool refendfound = false;
                bool refFound = false;  ////Developer Name:priyanka Vishwakarma ,Date:15_5_2019 ,Requirement:Apply Ref1 Style to References when in document Ref_start and Ref_End style not apply ,Integrated By:Vikas sir

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(c => c.Parent.LocalName != W.tc).ToList())
                {

                    if (P.ParagraphProperties != null)
                    {

                        if (P.ParagraphProperties.ParagraphStyleId != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId.Val.Value == "Ref-Start")
                            {
                                refstratfound = true;
                                refendfound = false;
                                continue;
                            }
                            else if (P.ParagraphProperties.ParagraphStyleId.Val.Value == "Ref-End")
                            {
                                refendfound = true;
                                refstratfound = false;
                                break;
                            }
                            ////Developer Name:priyanka Vishwakarma ,Date:15_5_2019 ,Requirement:Apply Ref1 Style to References when in document Ref_start and Ref_End style not apply ,Integrated By:Vikas sir
                            if (P.ParagraphProperties.ParagraphStyleId.Val.Value == "REF")
                            {
                                refFound = true;
                            }
                            else if (P.ParagraphProperties.ParagraphStyleId.Val.Value == "FIGC" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "CN-FM")  //Developer name:priyanka Vishwakarma ,Date:23-07-2020 ,Requirement:for avoid the REF1 style apply to figc  paragraph. Integrated by:Vikas sir. 
                            {
                                refFound = false;
                            }
                            else if (P.ParagraphProperties.ParagraphStyleId.Val.Value == "H1" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H2" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "CT")
                            {
                                refFound = false;
                            }
                            //
                            //-------------------------end by priyanka on 15_5_2019 -----------------------------------------------
                        }
                    }
                    if (refFound)
                    {


                        if (P != null && P.InnerText != null)
                        {
                            if (P.InnerText.ToLower() == "references" || P.InnerText.ToLower() == "literatur" || P.InnerText.ToLower() == "bibliografia recomendada")//Developer Name:Priyanka Vishwakarma ,Date:09072020  ,Requirement:For portuguese language epub
                            {
                                continue;
                            }

                            else
                            {
                                if (P.InnerText.Length < 50)
                                {
                                    if (P.Descendants<Run>().ToList().FirstOrDefault().Descendants().Any(x => x.LocalName == "b"))
                                    {
                                        refFound = false;
                                        continue;
                                    }
                                }
                                if (P.Descendants<RunStyle>().ToList().Count > 0 && P.Descendants<RunStyle>().ToList().FirstOrDefault().Val.Value == "pageno")
                                {
                                    continue;
                                }


                                if (P.ParagraphProperties != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId != null)
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val = "REF1";
                                    }
                                    else
                                    {
                                        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "REF1" };
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "REF1" });
                                }
                            }
                        }
                    }


                }
                D.Save();
            }
        }
        public static void applyIndexmarkingbasedonpagenoEpub(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                bool indexfound = false;
                List<string> pagenumbers = new List<string>();
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(c => c.Parent.LocalName != W.tc).ToList())
                {
                    if (P.Descendants<RunStyle>().ToList().Count > 0 && P.Descendants<RunStyle>().ToList().FirstOrDefault().Val.Value == "pageno")
                    {
                        if (Regex.Match(P.InnerText.Trim(), @"[\d]").Success)
                            pagenumbers.Add(P.InnerText);
                    }
                }
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(c => c.Parent.LocalName != W.tc).ToList())
                {
                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && (P.ParagraphProperties.ParagraphStyleId.Val.Value == "CT" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H1" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H2") && P.InnerText.ToLower().Trim() == "index")
                    {
                        indexfound = true;
                        continue;
                    }
                    if (indexfound)
                    {
                        if (P != null && P.InnerText != null)
                        {
                            var paratext = "";
                            if (P.InnerText.Contains(","))
                            {
                                paratext = P.InnerText;
                                P.Descendants<Run>().ToList().ForEach(x => x.Remove());
                            }
                            else
                            {
                                continue;
                            }
                            int cnt = 0;
                            foreach (var run in paratext.Split(',').ToList())
                            {
                                if (cnt > 0)
                                {
                                    if (run.Contains("-"))
                                    {
                                        foreach (var txt in run.Split('-').Where(x => x != "").ToList())
                                        {
                                            if (txt.Trim() != run.Split('-').Where(x => x != "").ToList().LastOrDefault().Trim() && pagenumbers.Any(x => x == txt.Trim()))
                                            {

                                                var newrun = new Run(new RunProperties(new RunStyle { Val = "citepageno" }));
                                                newrun.Append(new Text { Text = txt });
                                                var newrun2 = new Run();
                                                newrun2.Append(new Text { Text = "-" });
                                                var newrun3 = new Run();
                                                newrun3.Append(new Text { Text = ", " });
                                                P.Append(newrun3);
                                                P.Append(newrun);
                                                P.Append(newrun2);
                                                //run.Remove();
                                            }
                                            else if (pagenumbers.Any(x => x == txt.Trim()))
                                            {
                                                var newrun = new Run(new RunProperties(new RunStyle { Val = "citepageno" }));
                                                newrun.Append(new Text { Text = txt });
                                                P.Append(newrun);

                                            }
                                            else if (txt.Trim() != run.Split('-').Where(x => x != "").ToList().LastOrDefault().Trim())
                                            {
                                                var newrun = new Run();
                                                newrun.Append(new Text { Text = txt });
                                                var newrun3 = new Run();
                                                newrun3.Append(new Text { Text = ", " });
                                                var newrun2 = new Run();
                                                newrun2.Append(new Text { Text = "-" });
                                                P.Append(newrun3);
                                                P.Append(newrun);
                                                P.Append(newrun2);
                                            }
                                            else
                                            {
                                                var newrun = new Run();
                                                newrun.Append(new Text { Text = txt });
                                                P.Append(newrun);
                                            }
                                        }
                                    }
                                    else if (pagenumbers.Any(x => x == run.Trim()) && paratext.Split(',').ToList().LastOrDefault() != run)
                                    {
                                        var newrun = new Run(new RunProperties(new RunStyle { Val = "citepageno" }));
                                        newrun.Append(new Text { Text = run });
                                        var newrun2 = new Run();
                                        newrun2.Append(new Text { Text = ", " });
                                        P.Append(newrun2);
                                        P.Append(newrun);

                                    }
                                    else if (pagenumbers.Any(x => x == run.Trim()))
                                    {
                                        var newrun = new Run(new RunProperties(new RunStyle { Val = "citepageno" }));
                                        newrun.Append(new Text { Text = run });
                                        var newrun2 = new Run();
                                        newrun2.Append(new Text { Text = ", " });
                                        P.Append(newrun2);
                                        P.Append(newrun);
                                    }
                                    else
                                    {
                                        var newrun = new Run();
                                        newrun.Append(new Text { Text = run });
                                        P.Append(newrun);
                                    }
                                }
                                else
                                {
                                    var newrun = new Run();
                                    newrun.Append(new Text { Text = run });
                                    P.Append(newrun);
                                }
                                cnt++;
                            }
                        }


                    }

                }
                D.Save();
            }
        }


        public static void checkForNummeredRef(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                bool numberedRef = false;
                OpenXmlElement newP = null;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(x => x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val != null && x.ParagraphProperties.ParagraphStyleId.Val.Value == "REF1").ToList())
                {

                    newP = P.CloneNode(true);
                    if (P != null && !string.IsNullOrEmpty(P.InnerText))
                    {
                        Regex startwithnumber = new Regex(@"^\d+\.\s");
                        if (startwithnumber.IsMatch(P.InnerText.Trim()))
                        {
                            numberedRef = true;
                        }

                        if (numberedRef)
                        {

                            string strrefnum = null;
                            string strReferenceText = P.InnerText.Trim();
                            strrefnum = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(P.InnerText, @"^[0-9]+.\s|^[0-9]+\.");
                            if (!string.IsNullOrEmpty(strrefnum))
                            {

                                strReferenceText = P.InnerText.Trim().Replace(strrefnum, "");
                            }
                            //---------------------------------------
                            P.RemoveAllChildren();

                            P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "REF1" });

                            Run refnum = new Run(new RunProperties(new RunStyle() { Val = "bibnumber" }));
                            P.AppendChild(refnum);
                            if (strrefnum != null)
                            {
                                refnum.AppendChild(new Text(strrefnum.Trim().TrimEnd('.').ToString()));
                                Run newrun4 = P.AppendChild(new Run());
                                // Add Text to the Run element.
                                newrun4.AppendChild(new Text(". ") { Space = SpaceProcessingModeValues.Preserve });
                                Run reftext = P.AppendChild(new Run());
                                // Add Text to the Run element.
                                reftext.AppendChild(new Text(strReferenceText.Trim()));
                            }






                        }







                    }


                }
                D.Save();
            }

        }

        public static void checkNormalParaorListingPara(string newDoc)    //Developer name : Priyanka Vishwakarma ,Date:22-02-2020 ,Requirement:Avoid to apply AlphaUpperList,AlphalowerList and RomanList when para start with A ot I in word.  ,Integrated by:Vikas sir.
        {
            List<string> ListofListingStyleinWord = new List<string>();


            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                string Listnumber = null;
                string gettxt = null;
                string TextwithoutListnumber = null;
                List<Paragraph> listingParagraph = D.Descendants<Paragraph>().ToList().Where(x => x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val != null && x.Parent != null && x.Parent.XName.LocalName != "tc" && (x.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower() == "nl" || x.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower() == "bl" || x.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower() == "ul" || x.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower().EndsWith("list"))).ToList();
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(x => x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val != null).ToList())
                {

                    if (P.Parent != null && P.Parent.XName.LocalName != "tc" && (P.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower() == "nl" || P.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower() == "bl" || P.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower() == "ul" || P.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower().EndsWith("list")))
                    {
                        ListofListingStyleinWord.Add(P.ParagraphProperties.ParagraphStyleId.Val.Value);
                    }

                }

                if (ListofListingStyleinWord.Count > 0)
                {
                    if (ListofListingStyleinWord.Contains("AlphaUpparList") || ListofListingStyleinWord.Contains("AlphaLowerList") || ListofListingStyleinWord.Contains("RomanList"))
                    {

                        foreach (Paragraph listPara in listingParagraph.ToList())
                        {

                            if (listPara.ParagraphProperties != null && listPara.ParagraphProperties.ParagraphStyleId != null && listPara.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                if (listPara.ParagraphProperties.ParagraphStyleId.Val.Value == "AlphaUpparList" || listPara.ParagraphProperties.ParagraphStyleId.Val.Value == "RomanList" || listPara.ParagraphProperties.ParagraphStyleId.Val.Value == "AlphaLowerList")
                                {

                                    if (listPara.NextSibling() != null && listPara.NextSibling().LocalName == W.p.LocalName)////condition added by vikas on 30-12-2020 for only check nexsibling is paragraph
                                    {
                                        Paragraph NextPara = (Paragraph)listPara.NextSibling();

                                        if (NextPara.ParagraphProperties != null && NextPara.ParagraphProperties.ParagraphStyleId != null && NextPara.ParagraphProperties.ParagraphStyleId.Val != null)
                                        {
                                            if (!NextPara.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower().EndsWith("list"))
                                            {
                                                listPara.ParagraphProperties.ParagraphStyleId.Val.Value = "BodyA";
                                            }
                                            else if (listPara.InnerText != null && NextPara.InnerText != null)
                                            {
                                                string curr_para = null;
                                                string next_para = null;
                                                curr_para = Regex.Replace(listPara.InnerText.Trim().Split()[0], @"[^0-9a-zA-Z\ ]+", "");
                                                next_para = Regex.Replace(NextPara.InnerText.Trim().Split()[0], @"[^0-9a-zA-Z\ ]+", "");
                                                if (curr_para.ToLower() == next_para.ToLower())
                                                {
                                                    listPara.ParagraphProperties.ParagraphStyleId.Val.Value = "BodyA";
                                                }
                                            }

                                        }


                                    }
                                }
                            }

                        }

                    }
                }
                D.Save();
            }
        }


        public static void ApplyChapterNumCharStyle(string newDoc) //Developer Name:Priyanka Vishwakarma ,Date:09072020  ,Requirement:For portuguese language epub
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                bool numberedRef = false;
                bool chapternumApply = false;
                OpenXmlElement newP = null;
                //Chapter	Kapitel	Capítulo	Capitolo

                Regex ChapterNO = new Regex(@"^(Kapitel\s{1,}[0-9]+)|^(KAPITEL\s{1,}[0-9]+)|^(Capítulo\s{1,}[0-9]+)|^(CAPÍTULO\s{1,}[0-9]+)|^(Capitolo\s{1,}[0-9]+)|^(CAPITOLO\s{1,}[0-9]+)|^(capítulo\s{1,}[0-9]+)|^(CHAPTER\s{1,}[0-9]+)|^(chapter\s{1,}[0-9]+)|^(Chapter\s{1,}[0-9]+)");////Developer Name:Priyanka Vishwakarma,Date:19-08-2020,Requirement:Add Condition for apply CT paragrapg style to chapter when CT paragraph not given.
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(x => x != null && ChapterNO.IsMatch(x.InnerText.Trim())).ToList())
                {
                    chapternumApply = true;
                    newP = P.CloneNode(true);
                    Paragraph Next = (Paragraph)P.NextSibling();
                    if (P != null && !string.IsNullOrEmpty(P.InnerText))
                    {

                        if (ChapterNO.IsMatch(P.InnerText.Trim()))
                        {
                            string[] Chapternum = P.InnerText.Trim().Split(' ');
                            if (Chapternum.Count() == 2)
                            {

                                //---------------------------------------
                                P.RemoveAllChildren();

                                P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "CN-FM" });
                                Run reftext = P.AppendChild(new Run());
                                reftext.AppendChild(new Text(Chapternum[0].Trim()));
                                Run newrun4 = P.AppendChild(new Run());
                                newrun4.AppendChild(new Text(" ") { Space = SpaceProcessingModeValues.Preserve });
                                Run refnum = new Run(new RunProperties(new RunStyle() { Val = "chapternumber" }));
                                refnum.AppendChild(new Text(Chapternum[1]));
                                P.AppendChild(refnum);

                                if (Next != null && Next.InnerText.Trim() != "" && Next.Parent.LocalName != "tc" && Next.Descendants<Run>().ToList().FirstOrDefault().Descendants().Any(x => x.LocalName == "b"))
                                {
                                    if (Next.ParagraphProperties != null)
                                    {
                                        if (Next.ParagraphProperties.ParagraphStyleId != null)
                                        {
                                            Next.ParagraphProperties.ParagraphStyleId.Val = "CT";
                                        }
                                        else
                                        {
                                            Next.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "CT" };
                                        }
                                    }
                                    else
                                    {
                                        Next.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "CT" });
                                    }
                                }
                                else if (P != null && P.InnerText.Trim() != "" && P.Parent.LocalName != "tc")  //Developer Name:Priyanka Vishwakarma,Date:19-08-2020,Requirement:Add Condition for apply CT paragrapg style to chapter when CT paragraph not given.
                                {
                                    if (P.ParagraphProperties != null)
                                    {
                                        if (P.ParagraphProperties.ParagraphStyleId != null)
                                        {
                                            P.ParagraphProperties.ParagraphStyleId.Val = "CT";
                                        }
                                        else
                                        {
                                            P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "CT" };
                                        }
                                    }
                                    else
                                    {
                                        P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "CT" });
                                    }
                                }

                            }
                        }






                    }


                }



                //Developer Name:Priyanka Vishwakarma ,Date: 23-07-2020 Requirement:apply chapter no character style in "CN-FM"  paragraph.(For English language epub)
                if (chapternumApply == false)
                {
                    Regex Chapno = new Regex(@"^([0-9]+)");
                    foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(x => x != null && x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val.Value == "CN-FM").ToList())
                    {
                        if (Chapno.IsMatch(P.InnerText.Trim()))
                        {
                            string no = P.InnerText.Trim();
                            P.RemoveAllChildren();

                            P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "CN-FM" });
                            Run refnum = new Run(new RunProperties(new RunStyle() { Val = "chapternumber" }));
                            refnum.AppendChild(new Text(no));
                            P.AppendChild(refnum);
                        }
                    }
                }

                D.Save();
            }

        }

        public static void ApplyBodyAStyle(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                                                .Open(newDoc, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    //RemoveComments = false,
                    RemoveContentControls = true,
                    RemoveEndAndFootNotes = false,
                    //RemoveFieldCodes = false,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = false,
                };

                MarkupSimplifier.SimplifyMarkup(WPD, settings);

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P.ParagraphProperties != null)
                    {
                        if (P.ParagraphProperties.ParagraphStyleId == null)
                        {
                            P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId();
                            P.ParagraphProperties.ParagraphStyleId.Val = "BodyA";
                        }
                    }
                    else if (P.ParagraphProperties == null)
                    {
                        P.ParagraphProperties = new ParagraphProperties();
                        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId();
                        P.ParagraphProperties.ParagraphStyleId.Val = "BodyA";
                    }
                }
                D.Save();
            }
        }

        public static void ApplyAlignmentStyles(string newDoc)/////added by vikas on 30-07-2020 for handle Align text para in ePub
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                                                .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && (P.ParagraphProperties.ParagraphStyleId.Val != "Book-Title" && P.ParagraphProperties.ParagraphStyleId.Val != "Book-Subtitle" && P.ParagraphProperties.ParagraphStyleId.Val != "EQ" && !P.ParagraphProperties.ParagraphStyleId.Val.Value.StartsWith("H"))) //Developer Name:Priyanka VIshwakarma,Date:15-01-2021,Requirement:Add for avoid to apply EQ paragraph style.
                    {
                        if (P.ParagraphProperties.Justification != null)
                        {
                            if (P.ParagraphProperties.Justification.Val != null && P.ParagraphProperties.Justification.Val.Value.ToString().ToLower() == "right")
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val = "BodyTextRight";
                            }
                            else if (P.ParagraphProperties.Justification.Val != null && P.ParagraphProperties.Justification.Val.Value.ToString().ToLower() == "center")
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val = "BodyTextCentered";
                            }
                            else if (P.ParagraphProperties.Justification.Val != null && P.ParagraphProperties.Justification.Val.Value.ToString().ToLower() == "justify")
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val = "BodyTextJustify";
                            }
                        }
                        if (P.ParagraphProperties.Indentation != null)
                        {
                            if (P.ParagraphProperties.Indentation.FirstLine != null || P.ParagraphProperties.Indentation.Left != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val = "BodyTextIndent";
                            }
                            else if (P.ParagraphProperties.Indentation.Hanging != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val = "BodyTextHanging";
                            }

                        }
                    }
                    else if (P.InnerText.Trim().ToLower().EndsWith(".jpg") || P.InnerText.Trim().ToLower().EndsWith(".jpeg") || P.InnerText.Trim().ToLower().EndsWith(".png"))////added on 03-09-2020 by vikas for unnumbered images
                    {
                        if (P.ParagraphProperties == null)
                        {
                            P.ParagraphProperties = new ParagraphProperties();
                            P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId();
                            P.ParagraphProperties.ParagraphStyleId.Val = "FIGC";
                        }
                        else if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && (P.ParagraphProperties.ParagraphStyleId.Val != "Book-Title" && P.ParagraphProperties.ParagraphStyleId.Val != "Book-Subtitle" && !P.ParagraphProperties.ParagraphStyleId.Val.Value.StartsWith("H")))
                        {
                            P.ParagraphProperties.ParagraphStyleId.Val = "FIGC";
                        }
                    }
                    else if (P.ParagraphProperties == null)
                    {
                        P.ParagraphProperties = new ParagraphProperties();
                        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId();
                        P.ParagraphProperties.ParagraphStyleId.Val = "BodyA";
                    }
                }
                D.Save();
            }
        }

        public static void ApplyLabelStrongStyle(string newDoc)//////Added for apply label string to Figure,Box,Table
        {
            var LableStrongStyle = ConfigurationManager.AppSettings.Get("LableStrongStyle");
            List<string> LableStrongPatternsColl = new List<string>();

            ///Configuration read from Supporting folder
            LableStrongPatternsColl = GlobalMethods.ReadAndStoreFileValuesInArray(LableStrongStyle);

            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    bool labelStrongApply = false;
                    if (P != null && P.InnerText != "")
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId.Val != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId.Val.Value == "FIGC" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "TT" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "BT")
                                    {
                                        string paraText = P.InnerText;

                                        foreach (var figpattern in LableStrongPatternsColl.ToList())
                                        {
                                            string match = GlobalMethods.SearchRegEx(paraText, figpattern);

                                            if (match != "")
                                            {
                                                string runtext = null;
                                                List<Run> matchingrun = new List<Run>();
                                                foreach (Run R in P.Descendants<Run>().ToList())
                                                {
                                                    if (R.RunProperties != null && R.RunProperties.RunStyle != null && R.RunProperties.RunStyle.Val != null && R.RunProperties.RunStyle.Val.Value == "label-Strong")
                                                    {
                                                        break;
                                                    }
                                                    else if (R.RunProperties != null && R.RunProperties.Descendants().Any(x => x.XName.LocalName == "rStyle"))
                                                    {
                                                        var runstyle = (RunStyle)R.RunProperties.Descendants().Where(x => x.XName.LocalName == "rStyle").FirstOrDefault();  // 8_4_2019 Typecasting for check runstyle val not coming directly ..
                                                        if (runstyle.Val == "label-Strong")
                                                        {
                                                            break;
                                                        }
                                                    }
                                                    foreach (var item in R.Descendants<Text>().ToList())
                                                    {
                                                        foreach (var item1 in item.GetAttributes().ToList())
                                                        {
                                                            if (item1.XName.LocalName == "space")
                                                            {
                                                                var r = item1;
                                                                r.Value = SpaceProcessingModeValues.Default.ToString();
                                                            }
                                                        }
                                                    }
                                                    //runtext += R.InnerText.Trim();
                                                    runtext += R.InnerText; //Developer Name:Priyanka Vishwakarma. Date:17_10_2019 ,Requirement:apply label-strong character style when bold text contains comment ,Integrated by:Vikas sir.
                                                    string runmatch = GlobalMethods.SearchRegEx(runtext, figpattern);

                                                    if (runmatch == "")
                                                    {
                                                        matchingrun.Add(R);
                                                        continue;
                                                    }
                                                    else if (P.Descendants<Run>().Count() == 1)
                                                    {
                                                        string withoutlablestrongtxt = runtext.Replace(runmatch, "");

                                                        Run r1 = new Run(new RunProperties(new RunStyle { Val = "label-Strong" }));

                                                        Text t1 = new Text(runmatch);
                                                        r1.Append(t1);

                                                        Run r2 = new Run();
                                                        Text t2 = new Text(withoutlablestrongtxt);
                                                        r2.Append(t2);

                                                        R.Remove();

                                                        P.Append(r1);

                                                        P.Append(r2);
                                                        break;

                                                    }
                                                    else
                                                    {
                                                        matchingrun.Add(R);

                                                        foreach (Run run in matchingrun)
                                                        {
                                                            if (run.RunProperties != null)
                                                            {
                                                                if (run.RunProperties.RunStyle != null)
                                                                {
                                                                    ///Added by Karan on 01-09-2018 Start
                                                                    if (run.RunProperties.RunStyle.Val == "Strong")
                                                                    {
                                                                        Bold bold = new Bold();
                                                                        run.RunProperties.AppendChild(bold);
                                                                        run.RunProperties.RunStyle.Val = null;
                                                                    }
                                                                    ///Added by Karan on 01-09-2018 End
                                                                    if (run.RunProperties.RunStyle.Val == null)
                                                                    {
                                                                        run.RunProperties.RunStyle = new RunStyle() { Val = "label-Strong" };
                                                                    }
                                                                    else if (run.RunProperties.RunStyle.Val != "label-Strong")
                                                                    {
                                                                        run.RunProperties.RunStyle.Val.Value = "label-Strong";
                                                                    }
                                                                }
                                                                else
                                                                {
                                                                    //---Added  by Priyanka on 9_4_2019 for inserting rstyle in run property.
                                                                    //Run r1 = new Run(new RunProperties(new RunStyle { Val = "label-Strong" }));
                                                                    //Text t1 = new Text(runmatch);
                                                                    //r1.Append(t1);
                                                                    //P.ReplaceChild(r1, run);

                                                                    //---End by Priyanka on 9_4_2019 for inserting rstyle in run property.
                                                                    //---Added  by Priyanka on 9_4_2019 for inserting rstyle in run property.
                                                                    if (labelStrongApply == false)  //Developer Name:Priyanka Vishwakarma. Date:17_10_2019 ,Requirement:apply label-strong character style when bold text contains comment ,Integrated by:Vikas sir.
                                                                    {
                                                                        Run r1 = new Run(new RunProperties(new RunStyle { Val = "label-Strong" }));
                                                                        ////Developer name:Priyanka Vishwakarma .Date:31-01-2020 ,Requirement:Table Caption comes without sapce within Table and number ex.Table1 ,Integrated by:Vikas sir.
                                                                        //string TableWithoutSpace = null;
                                                                        //TableWithoutSpace = MapStylesWithWordTemplate.SearchRegExPatternFirstSearchInstanceOnly(R.InnerText, @"^(Table[0-9a-zA-Z]{1,2})");
                                                                        //if (!string.IsNullOrEmpty(TableWithoutSpace))
                                                                        //{
                                                                        //    runmatch = runmatch.Replace("Table", "Table ");
                                                                        //}
                                                                        ////------------------------------End---------------------------------------------------------------------------------
                                                                        Text t1 = new Text(runmatch);
                                                                        r1.Append(t1);
                                                                        P.ReplaceChild(r1, run);
                                                                        labelStrongApply = true;
                                                                    }
                                                                    else
                                                                    {
                                                                        run.Remove();
                                                                    }
                                                                    //--------------END----------------------------------------

                                                                    //RunStyle rstyle = new RunStyle() { Val = "label-Strong" };  //Commented by Priyanka on 9_4_2019 for inserting rstyle in run property not Properly.
                                                                    // run.RunProperties.Append(rstyle.CloneNode(true));
                                                                }
                                                            }
                                                            else
                                                            {
                                                                RunProperties runprop = new RunProperties();
                                                                RunStyle rstyle = new RunStyle() { Val = "label-Strong" };
                                                                runprop.Append(rstyle.CloneNode(true));
                                                                run.Append(runprop.CloneNode(true));
                                                            }
                                                        }

                                                        break;
                                                    }
                                                    break;  //Added  by Priyanka on 8_4_2019
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                D.Save();
            }
        }

        public static void ApplyFIGCPara(string newDoc) //Developer Name:Priyanka Vishwakarma,Date:07-08-2020,Requirement:Apply Figc para for Figure caption only for VTH client.
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                                                .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                int cnt = 0;
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(x => x.Parent != null && x.Parent.LocalName != W.tc.LocalName))
                {
                    if (P.InnerText != null && P.InnerText.Trim() != "")
                    {
                        if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val.Value != null /*&& (P.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower() == "fl"|| P.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower() == "bild")*/)//bild 08-08-2020
                        {
                            if (P.InnerText.ToLower().Trim().StartsWith("bild "))
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val = "FIGC";
                            }
                            else if (P.PreviousSibling() != null && P.PreviousSibling().LocalName == W.p.LocalName && P.PreviousSibling().InnerText.ToLower().Trim().StartsWith("((bild"))
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val = "FIGC";
                            }
                            else if (P.NextSibling() != null && P.NextSibling().LocalName == W.table.LocalName && P.InnerText.ToLower().Trim().StartsWith("tabelle"))
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val = "TT";
                            }
                            else if (P.NextSibling() != null && P.NextSibling().NextSibling() != null && P.NextSibling().NextSibling().LocalName == W.table.LocalName && P.InnerText.ToLower().Trim().StartsWith("tabelle"))
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val = "TT";
                            }
                        }
                    }

                }
                D.Save();
            }
        }

        public static void ApplyFIGCParaJaypee(string newDoc) //Developer Name:Priyanka Vishwakarma,Date:07-08-2020,Requirement:Apply Figc para for Figure caption only for VTH client.
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                                                .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                int cnt = 0;
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(x => x.Parent != null && x.Parent.LocalName != W.tc.LocalName))
                {
                    if (P.InnerText != null && P.InnerText.Trim() != "")
                    {
                        if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val.Value != null /*&& (P.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower() == "fl"|| P.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower() == "bild")*/)//bild 08-08-2020
                        {
                            if (P.InnerText.ToLower().Trim().StartsWith("flowchart "))
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val = "FIGC";
                            }
                           
                        }
                    }

                }
                D.Save();
            }
        }

        public static void ApplyBodyAParaToEQ(string newDoc) //Developer Name:Priyanka Vishwakarma,Date:08-08-2020,Requirement:Apply Figc para for Figure caption only for VTH client.
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                                                .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(x =>
                x.ParagraphProperties != null
                && x.ParagraphProperties.ParagraphStyleId != null
                && x.ParagraphProperties.ParagraphStyleId.Val != null
                && x.ParagraphProperties.ParagraphStyleId.Val.Value == "EQ").ToList())
                {
                    if (P.InnerText != "")
                    {
                        string text = Regex.Replace(P.InnerText, @"(formula[_][0-9]+[_][0-9]+)", "");
                        if (text.Trim() != "")
                        {
                            P.ParagraphProperties.ParagraphStyleId.Val = "BodyA";
                        }




                    }
                }
                D.Save();
            }
        }
        public static void ApplyEqtoBodyA(string newDoc)//Developer Name:Priyanka Vishwakarma,Date:24-03-2021,Requirement:change eq para to bodyA if equation is inline equation
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P != null && P.InnerText.Trim() != "")
                    {
                        if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val.Value == "EQ" && !P.InnerText.StartsWith("formula_"))
                        {
                            P.ParagraphProperties.ParagraphStyleId.Val.Value = "BodyA";
                        }
                    }

                }
                D.Save();
            }
        }

        //Developer Name:Vikas , Date:05-07-2020 ,Requirement: Headig level style and CT style. client:VTH
        public static void ApplyheadingStyletoNumberedPara(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().Where(x => x.Parent != null && x.Parent.LocalName != W.tc.LocalName).ToList())
                {
                    if (P != null && P.InnerText.Trim() != "")
                    {

                        if (CheckifParaStartWithNumber(P.Descendants<Run>()) == "1")
                        {
                            if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "H1";
                            }
                        }
                        else if (CheckifParaStartWithNumber(P.Descendants<Run>()) == "2")
                        {
                            if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "H2";
                            }
                        }
                        else if (CheckifParaStartWithNumber(P.Descendants<Run>()) == "3")
                        {
                            if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "H3";
                            }
                        }
                    }

                }
                D.Save();
            }
        }

        private static string CheckifParaStartWithNumber(IEnumerable<Run> RunColl)
        {
            foreach (Run R in RunColl.ToList())
            {
                string strParaText = null;

                if (R.HasChildren == true)
                {
                    foreach (Text T in R.Descendants<Text>().ToList())
                    {
                        strParaText += T.Text;

                        string strSearchRegEx = null;
                        strSearchRegEx = null;

                        strSearchRegEx = @"^([0-9]+\.[0-9]+\.[0-9]+\.[0-9]+)\s";
                        if (GlobalMethods.ValidateRegEx(strParaText, strSearchRegEx) == true)
                        {
                            string strRetVal = GlobalMethods.RegExSearch(strParaText, strSearchRegEx);

                            if (T.Text.StartsWith(strRetVal.Trim()))
                            {
                                return "3";
                            }
                        }

                        strSearchRegEx = @"([0-9]+\.[0-9]+\.[0-9]+)\s";
                        if (GlobalMethods.ValidateRegEx(strParaText, strSearchRegEx) == true)
                        {
                            string strRetVal = GlobalMethods.RegExSearch(strParaText, strSearchRegEx);

                            if (T.Text.StartsWith(strRetVal.Trim()))
                            {
                                return "2";
                            }
                        }

                        strSearchRegEx = @"^([0-9]+\.[0-9]+)\s";
                        if (GlobalMethods.ValidateRegEx(strParaText, strSearchRegEx) == true)
                        {
                            string strRetVal = GlobalMethods.RegExSearch(strParaText, strSearchRegEx);

                            if (T.Text.StartsWith(strRetVal.Trim()) && CheckifCompleteParaIsBold(RunColl))
                            {
                                return "1";
                            }
                        }
                    }
                }
            }

            return "0";
        }
        private static bool CheckifCompleteParaIsBold(IEnumerable<Run> RunColl)
        {
            bool bcompleteParaIsBold = false;

            foreach (Run R in RunColl.ToList())
            {
                if (R.HasChildren == true)
                {
                    if (R.RunProperties != null)
                    {
                        if (R.RunProperties.Bold != null)
                        {
                            bcompleteParaIsBold = true;
                        }
                        else
                        {
                            bcompleteParaIsBold = false;
                            return false;
                        }
                    }
                    else
                    {
                        bcompleteParaIsBold = false;
                        return false;
                    }
                }
                else
                {
                    bcompleteParaIsBold = false;
                    return false;
                }
            }

            if (bcompleteParaIsBold)
                return true;

            return false;
        }

        public static void ApplyCTandCN_FM(string newDoc) //Added by vikas for CT and CN-FM style VTH client.
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                                                .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(x =>
                x.ParagraphProperties != null
                && x.ParagraphProperties.ParagraphStyleId != null
                && x.ParagraphProperties.ParagraphStyleId.Val != null
                && x.ParagraphProperties.ParagraphStyleId.Val.Value == "CN-FM").ToList())
                {
                    if (D.Descendants<Paragraph>().ToList().Where(x => x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val != null && x.ParagraphProperties.ParagraphStyleId.Val.Value == "CT").ToList().Count == 0)
                    {
                        if (P.NextSibling<Paragraph>() != null)
                        {
                            var nextP = P.NextSibling<Paragraph>();
                            if (nextP.ParagraphProperties != null
                    && nextP.ParagraphProperties.ParagraphStyleId != null
                    && nextP.ParagraphProperties.ParagraphStyleId.Val != null
                    && nextP.ParagraphProperties.ParagraphStyleId.Val.Value != "CT")
                            {
                                nextP.ParagraphProperties.ParagraphStyleId.Val = "CT";
                            }




                        }
                    }
                }
                D.Save();
            }
        }

        public static void ApplyBoxStartandEnd(string newDoc) //Added by vikas for BOX VTH client.
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                                                .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(x => x.InnerText.StartsWith("Box")).ToList())
                {

                    if (P.InnerText.Trim().StartsWith("Box Beginning"))
                    {

                        if (P.ParagraphProperties != null
                && P.ParagraphProperties.ParagraphStyleId != null
                && P.ParagraphProperties.ParagraphStyleId.Val != null)
                        {
                            P.ParagraphProperties.ParagraphStyleId.Val = "BoxStart";
                        }

                        if (P.NextSibling<Paragraph>() != null)
                        {
                            var nextP = P.NextSibling<Paragraph>();
                            if (nextP.ParagraphProperties != null
                    && nextP.ParagraphProperties.ParagraphStyleId != null
                    && nextP.ParagraphProperties.ParagraphStyleId.Val != null
                    && nextP.ParagraphProperties.ParagraphStyleId.Val.Value != "BX-TI")
                            {
                                nextP.ParagraphProperties.ParagraphStyleId.Val = "BX-TI";
                            }
                        }

                    }
                    else if (P.InnerText.Trim().StartsWith("Box Ending"))
                    {

                        if (P.ParagraphProperties != null
                && P.ParagraphProperties.ParagraphStyleId != null
                && P.ParagraphProperties.ParagraphStyleId.Val != null)
                        {
                            P.ParagraphProperties.ParagraphStyleId.Val = "BoxEnd";
                        }

                    }
                }
                    D.Save();
                }
            }

        }

    }

