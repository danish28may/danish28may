﻿using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;
using OpenXmlPowerTools;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace MultiInstanceBookCleanup
{
    class RandomHouseStructuring
    {

        /////////This code checked for certain point which mapped with 3CM style for Random-house Customer which will run for only random house customer
        public static void StartRandomHouseStructuring(string docPath)
        {
            ConvertSoftEnterToHardEnters(docPath);////For Convert all soft enters to hard Enter on 16-04-2020 by vikas
            ConditionalStyleMapping(docPath);
            CleanupfootnoteRefrenceExtraSpace(docPath);
        }

        public static void ConvertSoftEnterToHardEnters(string wordFilePath)
        {
            try
            {
                object outputFileName = null;
                object oMissing = System.Reflection.Missing.Value;
                Microsoft.Office.Interop.Word.Application word = new Microsoft.Office.Interop.Word.Application();
                try
                {
                    word.Visible = false;
                    word.ScreenUpdating = false;
                    word.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
                    Object filename = (Object)wordFilePath;
                    //Document doc = word.Documents.Open(ref filename, ref oMissing,
                    //                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                    //                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                    //                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing);
                    Microsoft.Office.Interop.Word.Document doc = word.Documents.Open(filename, false);
                    try
                    {
                        Microsoft.Office.Interop.Word.Range r = doc.Content;
                        r.WholeStory();
                        r.Find.Execute("^l", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "^p", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        doc.SaveAs(ref filename,
                                    ref oMissing, ref oMissing,
                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing);
                    }
                    finally
                    {
                        //object saveChanges = WdSaveOptions.wdDoNotSaveChanges;
                        //((_Document)doc).Close(ref saveChanges, ref oMissing, ref oMissing);
                        //doc = null;
                        doc.Close();
                    }
                }
                finally
                {
                    //((_Application)word).Quit(ref oMissing, ref oMissing, ref oMissing);
                    word.Quit();
                    word = null;
                }


            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);

            }
        }

        private static bool ConditionalStyleMapping(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {


                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                bool bBreakRun = false;

                bool secLevel = false;
                string secLevelNum = null;
                int nsecLevelNum = 0;

                bool bPartInfoFound = false;
                DocumentFormat.OpenXml.Wordprocessing.Paragraph PrevPara = null;
                DocumentFormat.OpenXml.Wordprocessing.Run PrevRun = null;
                DocumentFormat.OpenXml.OpenXmlElement ox = null;
                bool bReferenceSection = false;
                bool btocStart = false;

                bool bctapply = false;

                int cntintro = 0;
                int cntpara = 0;

                List<string> tocPara = new List<string>();
                var bhinstyle = false;
                var bhinsprestyle = false;
                var bhintipstyle = false;

                var bquotepara = false;

                var bquoteparaBrif = false;

                var body = D.Descendants<Body>().FirstOrDefault();

                var CTfound = false;

                foreach (DocumentFormat.OpenXml.Wordprocessing.Paragraph P in D.Descendants<DocumentFormat.OpenXml.Wordprocessing.Paragraph>().ToList())
                {

                    if (P.HasChildren == true)
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null)
                            {
                                if (/*cntpara == 1*/CTfound == false && P.InnerText.Trim() != "" && P.InnerText.TrimStart().StartsWith("Für"))
                                {
                                    CTfound = true;
                                    P.ParagraphProperties.ParagraphStyleId.Val = "CT";


                                }
                                if (P.InnerText == "Inhaltsverzeichnis")
                                {

                                    btocStart = true;

                                    P.ParagraphProperties.ParagraphStyleId.Val = "H1";
                                    goto NextPara;
                                }

                                if (P.InnerText == "Einleitung")
                                {
                                    cntintro++;

                                    if (cntintro == 1 && btocStart)
                                    {
                                        tocPara.Add(P.InnerText);
                                    }

                                    if (cntintro == 2)
                                    {
                                        btocStart = false;
                                        P.ParagraphProperties.ParagraphStyleId.Val = "H1";

                                    }
                                }

                                if (btocStart == true)
                                {

                                    P.ParagraphProperties.ParagraphStyleId.Val = "BodyA";
                                }

                                else if (btocStart == false)
                                {
                                    ////For random-House client by vikas on 16-04-2020


                                    if (P.InnerText.Replace(" ", "").StartsWith("((Ü1"))
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val = "H1";

                                    }
                                    else if (P.InnerText == "Inhaltsverzeichnis")/////toc heading
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val = "H1";
                                        goto NextPara;
                                    }
                                    else if (P.InnerText.Replace(" ", "").StartsWith("((Ü2"))
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val = "H2";
                                        goto NextPara;
                                    }
                                    else if (P.InnerText.Replace(" ", "").StartsWith("((Ü3"))
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val = "H3";
                                        goto NextPara;
                                    }
                                    else if (P.InnerText.Replace(" ", "").StartsWith("((Ü4") || P.InnerText.Replace(" ", "").StartsWith("((4))") || P.InnerText.Replace(" ", "").StartsWith("((U4))"))
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val = "H4";
                                        goto NextPara;
                                    }
                                   else if (P.InnerText.Replace(" ", "").StartsWith("((In")|| P.InnerText.Replace(" ", "").StartsWith("((Spre")|| P.InnerText.Replace(" ", "").StartsWith("((Tip")||P.InnerText.Replace(" ", "").StartsWith("((Abbildung"))
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val = "H4";
                                        goto NextPara;
                                    }
                                }
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId() { Val = "BodyA" });
                            }
                        }
                    }
                    NextPara: { };
                }

                D.Save();
            }

            return true;
        }


        private static void CleanupfootnoteRefrenceExtraSpace(string newDoc)
        {
            using (WordprocessingDocument myDoc = WordprocessingDocument
                .Open(newDoc, true))
            {
                MainDocumentPart mainPart = myDoc.MainDocumentPart;

                Document D = myDoc.MainDocumentPart.Document;
                foreach (DocumentFormat.OpenXml.Wordprocessing.Paragraph P in D.Descendants<DocumentFormat.OpenXml.Wordprocessing.Paragraph>().ToList())
                {
                    if (P.ParagraphProperties.ParagraphStyleId == null)
                    {
                        P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId() { Val = "BodyA" });

                    }
                    if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val=="Quote" && P.InnerText=="")////remove blank quote para
                    {
                        P.Remove();
                    }

                    if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val == "BodyA" && P.InnerText == ""&& P.NextSibling()!=null && P.NextSibling<Paragraph>().Count()!=0 && P.NextSibling<Paragraph>().ParagraphProperties!=null &&
                        P.NextSibling<Paragraph>().ParagraphProperties.ParagraphStyleId != null && P.NextSibling<Paragraph>().ParagraphProperties.ParagraphStyleId.Val != null && P.NextSibling<Paragraph>().ParagraphProperties.ParagraphStyleId.Val =="FTN")////remove blank quote para
                    {
                        P.Remove();
                    }
                    if (P.ParagraphProperties.ParagraphStyleId.Val == "FTN" && Regex.Match(P.InnerText, "^[0-9]+").Success)
                    {
                        if (P.NextSibling() != null && P.NextSibling<Paragraph>() != null && P.NextSibling<Paragraph>().ParagraphProperties.ParagraphStyleId.Val == "FTN" && !Regex.Match(P.NextSibling<Paragraph>().InnerText, "^[0-9]+").Success)
                        {
                            P.NextSibling<Paragraph>().Descendants<Run>().ToList().ForEach(x=> P.Append(x.CloneNode(true)));
                            P.NextSibling<Paragraph>().Remove();
                        }
                    }

                    foreach (Run R in P.Descendants<Run>().ToList())
                    {
                        if (R.RunProperties != null && R.RunProperties.RunStyle != null && R.RunProperties.RunStyle.Val != null && R.RunProperties.RunStyle.Val == "citefn")
                        {
                           

                            if (R.PreviousSibling() != null && R.PreviousSibling<Run>() != null && R.PreviousSibling<Run>().InnerText.Trim() == "")
                            {
                                R.PreviousSibling<Run>().Remove();
                            }
                            if (R.PreviousSibling() != null && R.PreviousSibling<Run>() != null && R.PreviousSibling<Run>().InnerText.EndsWith(" "))
                            {
                                R.PreviousSibling<Run>().Descendants<Text>().LastOrDefault().Text = R.PreviousSibling<Run>().Descendants<Text>().LastOrDefault().Text.TrimEnd();
                            }
                        }
                    }
                }
                D.Save();
            }
        }

    }
}
