﻿using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;
using OpenXmlPowerTools;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml;
using System.Xml.Linq;
using System.Configuration;
using DocumentFormat.OpenXml;
using System.Text;
using System.Text.RegularExpressions;

namespace MultiInstanceBookCleanup
{
    class MapStylesWithWordTemplate
    {
        static int nBookTitleParaNumber = 0;
        static int nAuthorInfoParaNumber = 0;
        static int nBookSubTitleParaNumber = 0;

        static List<string> strValidParagraphStyles;
        static List<string> strValidCharacterStyles;

        static List<string> strParagraphStylesMapping;
        static List<string> strCharacterStylesMapping;

        public static void StyleMapping(string newDoc, string StyleMappingConfig)
        {
            ExecuteStyleMapping(newDoc, StyleMappingConfig);

            strValidParagraphStyles = new List<string>();
            strValidParagraphStyles.Clear();

            strValidParagraphStyles = GlobalMethods.ReadAndStoreFileValuesInArray(GlobalMethods.str3CMValidParagraphStyleConfig);

            strValidCharacterStyles = new List<string>();
            strValidCharacterStyles.Clear();

            strValidCharacterStyles = GlobalMethods.ReadAndStoreFileValuesInArray(GlobalMethods.str3CMValidCharacterStyleConfig);

            strParagraphStylesMapping = new List<string>();
            strParagraphStylesMapping.Clear();

            strParagraphStylesMapping = GlobalMethods.ReadAndStoreFileValuesInArray(GlobalMethods.strParagraphStyleMappingConfig);

            strCharacterStylesMapping = new List<string>();
            strCharacterStylesMapping.Clear();

            strCharacterStylesMapping = GlobalMethods.ReadAndStoreFileValuesInArray(GlobalMethods.strCharacterStyleMappingConfig);

            // Start Mapping the styles //

            if (strParagraphStylesMapping.Count > 0)
                newParagraphStyleMapping(newDoc);

            if (strCharacterStylesMapping.Count > 0)
                newCharacterStyleMapping(newDoc);

            CheckParaTextAndApplyStyle(newDoc);

            // ID Generation and Crosslinking ///
            if (GlobalMethods.strClientName.Trim().ToLower() == "fm" || GlobalMethods.strClientName.ToLower() != "travelguide")
            {
                SearchAndReplace.GeneralSearchAndReplace(newDoc); // add full path of .docx file
            }
            System.Threading.Thread.Sleep(1000);

            ConditionalStyleMapping(newDoc);

            // Check the text present in the document required to be inserted and moved from current location //

            nBookTitleParaNumber = 0;
            if (!string.IsNullOrEmpty(GlobalMethods.BookTitle))///// Condition Added by vikas on 10-06-2020
                nBookTitleParaNumber = CheckIfTheParaTextInTheDocument(newDoc, GlobalMethods.BookTitle);

            nAuthorInfoParaNumber = 0;
            nAuthorInfoParaNumber = CheckIfTheParaTextInTheDocument(newDoc, GlobalMethods.AuthorInfo);

            nBookSubTitleParaNumber = 0;
            nBookSubTitleParaNumber = CheckIfTheParaTextInTheDocument(newDoc, GlobalMethods.BookSubTitle);

            // Check the text present in the document required to be inserted and moved from current location //

            ConditionalStyleMappingCont(newDoc);

            GlobalMethods.strReferncePatternFilename = null;
            if (GlobalMethods.strClientName.ToLower() == "sage")  //10-10-2020
            {
                GlobalMethods.strReferncePatternFilename = ConfigurationManager.AppSettings.Get("RefrencePatternFilenameForSage");
            }
            else
            {
                GlobalMethods.strReferncePatternFilename = ConfigurationManager.AppSettings.Get("RefrencePatternFilename");
            }
            GlobalMethods.strJournalDBFilename = null;
            GlobalMethods.strPublisherDBFilename = null;
            if (GlobalMethods.strClientName.ToLower() == "sage")  //10-10-2020
            {
                GlobalMethods.strJournalDBFilename = ConfigurationManager.AppSettings.Get("JournalNameDBSage");
                GlobalMethods.strPublisherDBFilename = ConfigurationManager.AppSettings.Get("PublisherNameDBSage");
            }
            else
            {
                GlobalMethods.strJournalDBFilename = ConfigurationManager.AppSettings.Get("JournalNameDB");
                GlobalMethods.strPublisherDBFilename = ConfigurationManager.AppSettings.Get("PublisherNameDB");
            }

            if (GlobalMethods.strXMLOutputrequired.Trim().ToLower() == "false")
            {
                References.MergeReferenceElements(newDoc, GlobalMethods.strReferncePatternFilename, GlobalMethods.strJournalDBFilename, GlobalMethods.strPublisherDBFilename);
            }
            else
            {
                References.MarkReferenceCitations(newDoc);////only citation of reference mark added by vikas on 19-05-2020
            }
            TableStyling.AdditionalWordMarkup(newDoc);

            ApplyAbstractHead(newDoc);

            ApplyRefToHead1(newDoc); // 28-1-2019 added by aarti for ref 

            ApplyKeywordStyle(newDoc);

            ApplyAbstractPara(newDoc);

            // Include Para and List immediately below the Figure Caption as Figure Para

            //IncludeParaListInsideFigure(newDoc);
        }

        public static void RemoveEmptyPara(string newDoc)
        {
            string strParaText = null;

            using (WordprocessingDocument WPD = WordprocessingDocument
                                                .Open(newDoc, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    //RemoveComments = false,
                    RemoveContentControls = true,
                    RemoveEndAndFootNotes = false,
                    //RemoveFieldCodes = false,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = false,
                };

                MarkupSimplifier.SimplifyMarkup(WPD, settings);

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                bool bRemoveP = false;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P.Parent != null)
                    {
                        if (P.Parent.LocalName != null)
                        {
                            if (P.Parent.LocalName == "body")
                            {
                                strParaText = null;
                                bRemoveP = false;

                                if (P.Descendants<Run>().Count() == 0)
                                {
                                    // Check if the next and previous element is Table then do not remove the empty paragraph //
                                    if (P.NextSibling() != null && P.NextSibling().XName == W.tbl && P.PreviousSibling() != null && P.PreviousSibling().XName == W.tbl)
                                        continue;

                                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null
                                        && P.ParagraphProperties.ParagraphStyleId.Val != null)
                                    {
                                        if (P.ParagraphProperties.ParagraphStyleId.Val == "NotesStart" || P.ParagraphProperties.ParagraphStyleId.Val == "NotesEnd"
                                           || P.ParagraphProperties.ParagraphStyleId.Val == "CoverBreak" || P.ParagraphProperties.ParagraphStyleId.Val == "GlossaryStart"
                                           || P.ParagraphProperties.ParagraphStyleId.Val == "GlossaryEnd" || P.ParagraphProperties.ParagraphStyleId.Val == "BoxStart"
                                           || P.ParagraphProperties.ParagraphStyleId.Val == "BoxEnd" || P.ParagraphProperties.ParagraphStyleId.Val == "EQ"
                                           || P.ParagraphProperties.ParagraphStyleId.Val == "PubBoxStart" || P.ParagraphProperties.ParagraphStyleId.Val == "PubBoxEnd"
                                           || P.ParagraphProperties.ParagraphStyleId.Val == "FourColStart" || P.ParagraphProperties.ParagraphStyleId.Val == "FourColEnd"
                                           || P.ParagraphProperties.ParagraphStyleId.Val == "QuoteStart" || P.ParagraphProperties.ParagraphStyleId.Val == "QuoteEnd"
                                           || P.ParagraphProperties.ParagraphStyleId.Val == "CopyrightStart" || P.ParagraphProperties.ParagraphStyleId.Val == "CopyrightEnd"
                                           || P.ParagraphProperties.ParagraphStyleId.Val == "PrefaceStart" || P.ParagraphProperties.ParagraphStyleId.Val == "PrefaceEnd"
                                           || P.ParagraphProperties.ParagraphStyleId.Val == "ListofcontributorsStart" || P.ParagraphProperties.ParagraphStyleId.Val == "ListofcontributorsEnd"
                                           || P.ParagraphProperties.ParagraphStyleId.Val == "TGScreenStart" || P.ParagraphProperties.ParagraphStyleId.Val == "TGScreenEnd"
                                           || P.ParagraphProperties.ParagraphStyleId.Val == "TGWithoutScreenStart" || P.ParagraphProperties.ParagraphStyleId.Val == "TGWithoutScreenEnd"
                                           || P.ParagraphProperties.ParagraphStyleId.Val == "ThreeColStart" || P.ParagraphProperties.ParagraphStyleId.Val == "ThreeColEnd"
                                           || P.ParagraphProperties.ParagraphStyleId.Val == "MarginalTextStart" || P.ParagraphProperties.ParagraphStyleId.Val == "MarginalTextEnd"
                                           || P.ParagraphProperties.ParagraphStyleId.Val == "CaptionStart" || P.ParagraphProperties.ParagraphStyleId.Val == "CaptionEnd") //Developer Name:Priyanka Vishwakarma,Date:16-02-2021,Requirement:Add condition for avoid to remove captionstart,captionend.margintextstart,margintextend for content xml
                                        {
                                            continue;
                                        }
                                    }

                                    P.Remove();
                                }
                                else if (P.Descendants<Run>().Count() == 1)
                                {
                                    bRemoveP = true;

                                    foreach (Run R in P.Descendants<Run>().ToList())
                                    {
                                        foreach (Text T in R.Descendants<Text>().ToList())
                                        {
                                            strParaText += T.Text;
                                        }
                                    }

                                    if (strParaText != null)
                                    {
                                        if (strParaText.Trim() != "")
                                        {
                                            bRemoveP = false;
                                        }
                                    }

                                    foreach (Run R in P.Descendants<Run>().ToList())
                                    {
                                        foreach (Picture Pct in R.Descendants<Picture>().ToList())
                                        {
                                            if (Pct.HasChildren)
                                            {
                                                bRemoveP = false;
                                                break;
                                            }
                                        }

                                        foreach (Drawing Draw in R.Descendants<Drawing>().ToList())
                                        {
                                            if (Draw.HasChildren)
                                            {
                                                bRemoveP = false;
                                                break;
                                            }
                                        }

                                        foreach (Break br in R.Descendants<Break>().ToList())
                                        {
                                            if (br.HasAttributes)
                                            {
                                                bRemoveP = false;
                                                break;
                                            }
                                        }

                                        if (bRemoveP)
                                        {
                                            // Check if the next and previous element is Table then do not remove the empty paragraph //
                                            if (P.NextSibling() != null && P.NextSibling().XName == W.tbl && P.PreviousSibling() != null && P.PreviousSibling().XName == W.tbl)
                                                continue;

                                            if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null &&
                                                P.ParagraphProperties.ParagraphStyleId.Val != null &&
                                                (P.ParagraphProperties.ParagraphStyleId.Val == "NotesStart" || P.ParagraphProperties.ParagraphStyleId.Val == "NotesEnd" ||
                                                P.ParagraphProperties.ParagraphStyleId.Val == "CoverBreak" || P.ParagraphProperties.ParagraphStyleId.Val == "GlossaryStart"
                                                || P.ParagraphProperties.ParagraphStyleId.Val == "GlossaryEnd" || P.ParagraphProperties.ParagraphStyleId.Val == "BoxStart"
                                                || P.ParagraphProperties.ParagraphStyleId.Val == "BoxEnd" || P.ParagraphProperties.ParagraphStyleId.Val == "EQ"
                                                || P.ParagraphProperties.ParagraphStyleId.Val == "PubBoxStart" || P.ParagraphProperties.ParagraphStyleId.Val == "PubBoxEnd"
                                                || P.ParagraphProperties.ParagraphStyleId.Val == "FourColStart" || P.ParagraphProperties.ParagraphStyleId.Val == "FourColEnd"
                                                || P.ParagraphProperties.ParagraphStyleId.Val == "QuoteStart" || P.ParagraphProperties.ParagraphStyleId.Val == "QuoteEnd"
                                                || P.ParagraphProperties.ParagraphStyleId.Val == "CopyrightStart" || P.ParagraphProperties.ParagraphStyleId.Val == "CopyrightEnd"
                                                || P.ParagraphProperties.ParagraphStyleId.Val == "PrefaceStart" || P.ParagraphProperties.ParagraphStyleId.Val == "PrefaceEnd"
                                                || P.ParagraphProperties.ParagraphStyleId.Val == "ListofcontributorsStart" || P.ParagraphProperties.ParagraphStyleId.Val == "ListofcontributorsEnd"
                                                || P.ParagraphProperties.ParagraphStyleId.Val == "TGScreenStart" || P.ParagraphProperties.ParagraphStyleId.Val == "TGScreenEnd"
                                                || P.ParagraphProperties.ParagraphStyleId.Val == "TGWithoutScreenStart" || P.ParagraphProperties.ParagraphStyleId.Val == "TGWithoutScreenEnd" ///Not added by Karan
                                                || P.ParagraphProperties.ParagraphStyleId.Val == "ThreeColStart" || P.ParagraphProperties.ParagraphStyleId.Val == "ThreeColEnd"
                                                || P.ParagraphProperties.ParagraphStyleId.Val == "MarginalTextStart" || P.ParagraphProperties.ParagraphStyleId.Val == "MarginalTextEnd"
                                                || P.ParagraphProperties.ParagraphStyleId.Val == "CaptionStart" || P.ParagraphProperties.ParagraphStyleId.Val == "CaptionEnd")) //Developer Name:Priyanka Vishwakarma,Date:16-02-2021,Requirement:Add condition for avoid to remove captionstart,captionend.margintextstart,margintextend for content xml
                                            {
                                                continue;
                                            }

                                            P.Remove();
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                D.Save();
            }
        }

        private static void newParagraphStyleMapping(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                                     .Open(newDoc, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    //RemoveComments = false,
                    RemoveContentControls = true,
                    RemoveEndAndFootNotes = false,
                    //RemoveFieldCodes = false,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = false,
                };

                MarkupSimplifier.SimplifyMarkup(WPD, settings);

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                List<ParagraphStyleId> S = D.Descendants<ParagraphStyleId>()
                                        .Where(c => c.Val != null).ToList();

                foreach (ParagraphStyleId PS in S)
                {
                    if (strParagraphStylesMapping.Any(str => str.Contains(PS.Val)))
                    {
                        int nIndex = -1;

                        foreach (var item in strParagraphStylesMapping)
                        {
                            nIndex++;

                            if (item.StartsWith(PS.Val))
                                break;
                        }

                        if (nIndex >= 0)
                        {
                            string strStyle = null;

                            strStyle = strParagraphStylesMapping[nIndex];

                            string[] t = strStyle.Split('|');

                            if (t.Length > 0)
                            {
                                if (PS.Val == t[0])
                                {
                                    PS.Val = t[1];
                                }
                            }
                        }
                    }
                }
                D.Save();
            }

            ApplyParaStyleToNormalParagraph(newDoc);
        }

        private static void newCharacterStyleMapping(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                                    .Open(newDoc, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    //RemoveComments = false,
                    RemoveContentControls = true,
                    RemoveEndAndFootNotes = false,
                    //RemoveFieldCodes = false,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = false,
                };

                MarkupSimplifier.SimplifyMarkup(WPD, settings);

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                List<RunStyle> S = D.Descendants<RunStyle>()
                                        .Where(c => c.Val != null).ToList();

                foreach (RunStyle RS in S)
                {
                    if (strCharacterStylesMapping.Any(str => str.Contains(RS.Val)))
                    {
                        int nIndex = -1;

                        foreach (var item in strCharacterStylesMapping)
                        {
                            nIndex++;

                            if (item.StartsWith(RS.Val))
                                break;
                        }

                        if (nIndex >= 0)
                        {
                            string strStyle = null;

                            strStyle = strCharacterStylesMapping[nIndex];

                            string[] t = strStyle.Split('|');

                            if (t.Length > 0)
                            {
                                if (RS.Val == t[0])
                                {
                                    RS.Val = t[1];
                                }
                            }
                        }
                    }
                }
                D.Save();
            }


        }

        public static void ApplyParaStyleToNormalParagraph(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                                                .Open(newDoc, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    //RemoveComments = false,
                    RemoveContentControls = true,
                    RemoveEndAndFootNotes = false,
                    //RemoveFieldCodes = false,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = false,
                };

                MarkupSimplifier.SimplifyMarkup(WPD, settings);

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    //if (P.ParagraphProperties != null)
                    //{
                    //    if (P.ParagraphProperties.ParagraphStyleId == null)
                    //    {
                    //        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId();
                    //        P.ParagraphProperties.ParagraphStyleId.Val = "BodyA";
                    //    }
                    //}
                    if (P.ParagraphProperties == null)
                    {
                        P.ParagraphProperties = new ParagraphProperties();
                        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId();
                        P.ParagraphProperties.ParagraphStyleId.Val = "BodyA";
                    }
                }
                D.Save();
            }
        }

        private static void ApplyKeywordStyle(string newDoc)
        {
            string strParaText = null;

            using (WordprocessingDocument WPD = WordprocessingDocument
                                                .Open(newDoc, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    //RemoveComments = false,
                    RemoveContentControls = true,
                    RemoveEndAndFootNotes = false,
                    //RemoveFieldCodes = false,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = false,
                };

                MarkupSimplifier.SimplifyMarkup(WPD, settings);

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P.Descendants<Run>().Count() > 0)
                    {
                        if (P.Parent != null)
                        {
                            if (P.Parent.LocalName != null)
                            {
                                if (P.Parent.LocalName == "body")
                                {
                                    strParaText = null;

                                    foreach (Run R in P.Descendants<Run>().ToList())
                                    {
                                        foreach (Text T in R.Descendants<Text>().ToList())
                                        {
                                            strParaText += T.Text;
                                        }
                                    }

                                    if (strParaText != null)
                                    {
                                        if (strParaText.ToLower().StartsWith("keyword"))
                                        {
                                            if (P.ParagraphProperties != null)
                                            {
                                                if (P.ParagraphProperties.ParagraphStyleId == null)
                                                {
                                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId();
                                                }
                                            }
                                            else
                                            {
                                                P.ParagraphProperties = new ParagraphProperties();
                                                P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId();
                                            }

                                            P.ParagraphProperties.ParagraphStyleId.Val = "KYWD";
                                            strParaText = null;
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                D.Save();
            }
        }

        private static void ApplyAbstractHead(string newDoc)
        {
            string strParaText = null;

            using (WordprocessingDocument WPD = WordprocessingDocument
                                                .Open(newDoc, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    //RemoveComments = false,
                    RemoveContentControls = true,
                    RemoveEndAndFootNotes = false,
                    //RemoveFieldCodes = false,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = false,
                };

                MarkupSimplifier.SimplifyMarkup(WPD, settings);

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P.Descendants<Run>().Count() > 0)
                    {
                        if (P.Parent != null)
                        {
                            if (P.Parent.LocalName != null)
                            {
                                if (P.Parent.LocalName == "body")
                                {
                                    strParaText = null;

                                    foreach (Run R in P.Descendants<Run>().ToList())
                                    {
                                        foreach (Text T in R.Descendants<Text>().ToList())
                                        {
                                            strParaText += T.Text;
                                        }
                                    }

                                    if (strParaText != null)
                                    {
                                        if ((strParaText.ToLower() == "abstract" /*&& !GlobalMethods.checkValidStyle(XElement.Parse(P.OuterXml)) */) || (strParaText.ToLower() == "summary" /*&& !GlobalMethods.checkValidStyle(XElement.Parse(P.OuterXml))*/)) //added by bhavesh on 21-01-2019 ////checkValidStyle condition added by vikas
                                        {
                                            if (P.ParagraphProperties != null)
                                            {
                                                if (P.ParagraphProperties.ParagraphStyleId == null)
                                                {
                                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId();
                                                }
                                            }
                                            else
                                            {
                                                P.ParagraphProperties = new ParagraphProperties();
                                                P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId();
                                            }

                                            P.ParagraphProperties.ParagraphStyleId.Val = "ABT";

                                            strParaText = null;
                                            //break;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                D.Save();
            }
        }
        // 28/1/2019 added by aarti for REF TO H1 conversion start 
        private static void ApplyRefToHead1(string newDoc)
        {
            string strParaText = null;

            using (WordprocessingDocument WPD = WordprocessingDocument
                                                .Open(newDoc, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    //RemoveComments = false,
                    RemoveContentControls = true,
                    RemoveEndAndFootNotes = false,
                    //RemoveFieldCodes = false,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = false,
                };

                MarkupSimplifier.SimplifyMarkup(WPD, settings);

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P.Descendants<Run>().Count() > 0)
                    {
                        if (P.Parent != null)
                        {
                            if (P.Parent.LocalName != null)
                            {
                                if (P.Parent.LocalName == "body")
                                {
                                    strParaText = null;

                                    foreach (Run R in P.Descendants<Run>().ToList())
                                    {
                                        foreach (Text T in R.Descendants<Text>().ToList())
                                        {
                                            strParaText += T.Text;
                                        }
                                    }

                                    if (strParaText != null)
                                    {
                                        if (strParaText.ToLower() == "references" || strParaText.ToLower() == "reference" || strParaText.ToLower() == "further reading" || strParaText.ToLower() == "literaturverzeichnis" || strParaText.ToLower() == "bibliografia" || strParaText.ToUpper() == "REFERÊNCIAS" || strParaText.ToUpper() == "REFERÊNCIAS BIBLIOGRÁFICAS" || strParaText.ToUpper() == "BIBLIOGRÁFICAS" || strParaText.ToUpper() == "LEITURAS SUGERIDAS") //added by aarti on 28-01-2019////added by vikas for german references Literaturverzeichnis on 18-06-2019
                                        {
                                            if (P.ParagraphProperties != null)
                                            {
                                                if (P.ParagraphProperties.ParagraphStyleId == null)
                                                {
                                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId();
                                                }
                                            }
                                            else
                                            {
                                                P.ParagraphProperties = new ParagraphProperties();
                                                P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId();
                                            }

                                            P.ParagraphProperties.ParagraphStyleId.Val = "H1";
                                            strParaText = null;
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                D.Save();
            }
        }
        // 28/1/2019 added by aarti for REF TO H1 conversion end
        private static void ApplyAbstractPara(string newDoc)
        {
            bool bAbstractHeadStart = false;

            using (WordprocessingDocument WPD = WordprocessingDocument
                                                .Open(newDoc, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    //RemoveComments = false,
                    RemoveContentControls = true,
                    RemoveEndAndFootNotes = false,
                    //RemoveFieldCodes = false,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = false,
                };

                MarkupSimplifier.SimplifyMarkup(WPD, settings);

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null)
                    {
                        if (P.ParagraphProperties.ParagraphStyleId.Val == "ABT")
                        {
                            bAbstractHeadStart = true;
                            continue;
                        }

                        if (P.ParagraphProperties.ParagraphStyleId.Val == "KYWD")
                        {
                            bAbstractHeadStart = false;
                            continue;
                        }

                        if (P.ParagraphProperties.ParagraphStyleId.Val == "L1" || P.ParagraphProperties.ParagraphStyleId.Val == "L2" || P.ParagraphProperties.ParagraphStyleId.Val == "UL")
                        {
                            bAbstractHeadStart = false;
                            continue;
                        }
                    }

                    if (bAbstractHeadStart == true)
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId == null)
                            {
                                P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId();
                            }
                        }
                        else
                        {
                            P.ParagraphProperties = new ParagraphProperties();
                            P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId();
                        }

                        P.ParagraphProperties.ParagraphStyleId.Val = "AbstractPara";
                        break;
                    }
                }
                D.Save();
            }
        }

        public static void RemoveCharStyleFromParagraphMarkRunProperties(string newDoc)
        {
            try
            {
                using (WordprocessingDocument WPD = WordprocessingDocument
                                                    .Open(newDoc, true))
                {
                    SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                    {
                        //RemoveComments = false,
                        RemoveContentControls = true,
                        RemoveEndAndFootNotes = false,
                        //RemoveFieldCodes = false,
                        RemoveLastRenderedPageBreak = true,
                        RemovePermissions = true,
                        RemoveProof = true,
                        RemoveRsidInfo = true,
                        RemoveSmartTags = true,
                        RemoveSoftHyphens = false,
                        ReplaceTabsWithSpaces = false,
                    };

                    MarkupSimplifier.SimplifyMarkup(WPD, settings);

                    MainDocumentPart MDP = WPD.MainDocumentPart;

                    Document D = MDP.Document;

                    List<RunStyle> S = D.Descendants<RunStyle>()
                                            .Where(c => c.Val != null).ToList();

                    foreach (RunStyle PS in S)
                    {
                        if (PS.Parent != null)
                        {
                            if (PS.Parent.LocalName == "rPr")
                            {
                                if (PS.Parent.Parent != null)
                                {
                                    if (PS.Parent.Parent.LocalName == "pPr")
                                    {
                                        PS.Remove();
                                    }
                                }
                            }
                        }
                    }
                    D.Save();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void NewExtractAndStoreParaStylePropertiesInDocument(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                                     .Open(newDoc, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    //RemoveComments = false,
                    RemoveContentControls = true,
                    RemoveEndAndFootNotes = false,
                    //RemoveFieldCodes = false,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = false,
                };

                MarkupSimplifier.SimplifyMarkup(WPD, settings);

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                List<ParagraphStyleId> S = D.Descendants<ParagraphStyleId>()
                                        .Where(c => c.Val != null).ToList();

                GlobalMethods.bIndentation = false;
                GlobalMethods.bLeftIndentation = false;
                GlobalMethods.bHangingIndentation = false;
                GlobalMethods.bFirstLineIndentation = false;

                GlobalMethods.bTextAlignment = false;
                GlobalMethods.bJustification = false;


                GlobalMethods.bParagraphBorders = false;
                GlobalMethods.bLeftBorder = false;
                GlobalMethods.bTopBorder = false;
                GlobalMethods.bRightBorder = false;
                GlobalMethods.bBottomBorder = false;
                GlobalMethods.bBetweenBorder = false;
                GlobalMethods.bBarBorder = false;

                GlobalMethods.bBold = false;
                GlobalMethods.bCaps = false;
                GlobalMethods.bEmphasis = false;
                GlobalMethods.bItalic = false;
                GlobalMethods.bSmallCaps = false;
                GlobalMethods.bUnderline = false;
                GlobalMethods.bStrike = false;
                GlobalMethods.bDoubleStrike = false;

                foreach (ParagraphStyleId PS in S)
                {
                    if (GlobalMethods.StyleList.Count > 0)
                    {
                        string key = PS.Val;
                        List<Style> mystyle = (from kvp in GlobalMethods.StyleList where kvp.Key == key select kvp.Value).ToList();

                        if (mystyle.Count > 0)
                        {

                            GlobalMethods.bIndentation = false;
                            GlobalMethods.bLeftIndentation = false;
                            GlobalMethods.bHangingIndentation = false;
                            GlobalMethods.bFirstLineIndentation = false;

                            GlobalMethods.bTextAlignment = false;
                            GlobalMethods.bJustification = false;


                            GlobalMethods.bParagraphBorders = false;
                            GlobalMethods.bLeftBorder = false;
                            GlobalMethods.bTopBorder = false;
                            GlobalMethods.bRightBorder = false;
                            GlobalMethods.bBottomBorder = false;
                            GlobalMethods.bBetweenBorder = false;
                            GlobalMethods.bBarBorder = false;

                            GlobalMethods.bBold = false;
                            GlobalMethods.bCaps = false;
                            GlobalMethods.bEmphasis = false;
                            GlobalMethods.bItalic = false;
                            GlobalMethods.bSmallCaps = false;
                            GlobalMethods.bUnderline = false;
                            GlobalMethods.bStrike = false;
                            GlobalMethods.bDoubleStrike = false;


                            ParagraphProperties Pp;

                            if (((ParagraphProperties)PS.Parent) == null)
                            {
                                Pp = new ParagraphProperties();
                            }
                            else
                            {
                                Pp = ((ParagraphProperties)PS.Parent);
                            }

                            if (mystyle[0].BasedOn != null && mystyle[0].BasedOn.Val != null)
                            {
                                if ((mystyle[0].BasedOn.Val != "Normal") && (mystyle[0].BasedOn.Val != "NoParagraphStyle"))
                                {
                                    string mykey = mystyle[0].BasedOn.Val;
                                    List<Style> myBasestyle = (from kvp in GlobalMethods.StyleList where kvp.Key == mykey select kvp.Value).ToList();
                                    List<Style> strBasedOnStyleCollection = new List<Style>();
                                    strBasedOnStyleCollection.Clear();

                                    do
                                    {
                                        strBasedOnStyleCollection.Add(myBasestyle[0]);

                                        if (myBasestyle[0].BasedOn != null)
                                        {
                                            mykey = myBasestyle[0].BasedOn.Val;
                                            myBasestyle.Clear();

                                            myBasestyle = (from kvp in GlobalMethods.StyleList where kvp.Key == mykey select kvp.Value).ToList();
                                        }

                                    } while ((myBasestyle[0].BasedOn != null) && (myBasestyle[0].BasedOn.Val != null) && (myBasestyle[0].BasedOn.Val != "Normal") && (myBasestyle[0].BasedOn.Val != "NoParagraphStyle"));

                                    if (myBasestyle != null)
                                    {
                                        if (strBasedOnStyleCollection.Count > 0)
                                        {
                                            strBasedOnStyleCollection.Add(myBasestyle[0]);
                                        }
                                    }

                                    if (strBasedOnStyleCollection.Count > 0)
                                    {
                                        for (int nCounter = 0; nCounter < strBasedOnStyleCollection.Count; nCounter++)
                                        {
                                            updateParaPropertiesWithBasedOnStyle(PS, Pp, strBasedOnStyleCollection[nCounter].StyleId.Value);
                                        }
                                    }
                                }
                            }

                            if (mystyle[0].StyleParagraphProperties != null)
                            {
                                if (mystyle[0].StyleParagraphProperties.Indentation != null)
                                {
                                    if (((ParagraphProperties)PS.Parent).Indentation == null)
                                    {
                                        GlobalMethods.bIndentation = true;
                                        GlobalMethods.bLeftIndentation = true;
                                        GlobalMethods.bHangingIndentation = true;
                                        GlobalMethods.bFirstLineIndentation = true;
                                        Pp.Indentation = new Indentation();
                                    }

                                    if (mystyle[0].StyleParagraphProperties.Indentation.Left != null)
                                    {
                                        if ((Pp.Indentation.Left == null)) //  || Pp.Indentation.Left == ""
                                        {
                                            Pp.Indentation.Left = mystyle[0].StyleParagraphProperties.Indentation.Left.Value;
                                        }
                                        else
                                        {
                                            if (GlobalMethods.bLeftIndentation == true)
                                            {
                                                Pp.Indentation.Left = mystyle[0].StyleParagraphProperties.Indentation.Left.Value;
                                            }
                                        }
                                    }

                                    if (mystyle[0].StyleParagraphProperties.Indentation.Hanging != null)
                                    {
                                        if ((Pp.Indentation.Hanging == null && Pp.Indentation.FirstLine == null)) //  || Pp.Indentation.Hanging == ""
                                        {
                                            Pp.Indentation.Hanging = mystyle[0].StyleParagraphProperties.Indentation.Hanging.Value;
                                        }
                                        else
                                        {
                                            if (GlobalMethods.bHangingIndentation == true)
                                            {
                                                Pp.Indentation.Hanging = mystyle[0].StyleParagraphProperties.Indentation.Hanging.Value;
                                            }
                                        }
                                    }

                                    if (mystyle[0].StyleParagraphProperties.Indentation.FirstLine != null)
                                    {
                                        if ((Pp.Indentation.FirstLine == null && Pp.Indentation.Hanging == null)) // || Pp.Indentation.FirstLine == ""
                                        {
                                            Pp.Indentation.FirstLine = mystyle[0].StyleParagraphProperties.Indentation.FirstLine.Value;
                                        }
                                        else
                                        {
                                            if (GlobalMethods.bFirstLineIndentation == true)
                                            {
                                                Pp.Indentation.FirstLine = mystyle[0].StyleParagraphProperties.Indentation.FirstLine.Value;
                                            }
                                        }
                                    }
                                }

                                if (mystyle[0].StyleParagraphProperties.TextAlignment != null)
                                {
                                    if ((Pp.TextAlignment == null))
                                    {
                                        Pp.TextAlignment = new TextAlignment();
                                        Pp.TextAlignment.Val = mystyle[0].StyleParagraphProperties.TextAlignment.Val;
                                    }
                                    else
                                    {
                                        if (GlobalMethods.bTextAlignment == true)
                                        {
                                            //Pp.TextAlignment = new TextAlignment();
                                            Pp.TextAlignment.Val = mystyle[0].StyleParagraphProperties.TextAlignment.Val;
                                        }
                                    }
                                }

                                if (mystyle[0].StyleParagraphProperties.Justification != null)
                                {
                                    if ((((ParagraphProperties)PS.Parent).Justification == null))
                                    {
                                        Pp.Justification = new Justification();
                                        Pp.Justification.Val = mystyle[0].StyleParagraphProperties.Justification.Val;
                                    }
                                    else
                                    {
                                        if (GlobalMethods.bJustification == true)
                                        {
                                            Pp.Justification.Val = mystyle[0].StyleParagraphProperties.Justification.Val;
                                        }
                                    }
                                }
                                else
                                {
                                    if ((((ParagraphProperties)PS.Parent).Justification == null))
                                    {
                                        Pp.Justification = new Justification();
                                        Pp.Justification.Val = DocumentFormat.OpenXml.Wordprocessing.JustificationValues.Left;
                                    }
                                    else
                                    {
                                        if (GlobalMethods.bJustification == true && mystyle[0].StyleParagraphProperties.Justification != null)
                                        {
                                            Pp.Justification.Val = DocumentFormat.OpenXml.Wordprocessing.JustificationValues.Left;
                                        }
                                    }
                                }

                                if (mystyle[0].StyleParagraphProperties.ParagraphBorders != null)
                                {
                                    if (Pp.ParagraphBorders == null)
                                    {
                                        GlobalMethods.bParagraphBorders = true;
                                        GlobalMethods.bLeftBorder = true;
                                        GlobalMethods.bTopBorder = true;
                                        GlobalMethods.bRightBorder = true;
                                        GlobalMethods.bBottomBorder = true;
                                        GlobalMethods.bBetweenBorder = true;
                                        GlobalMethods.bBarBorder = true;
                                        Pp.ParagraphBorders = new ParagraphBorders();
                                    }

                                    if (mystyle[0].StyleParagraphProperties.ParagraphBorders.LeftBorder != null)
                                    {
                                        if (Pp.ParagraphBorders.LeftBorder == null)
                                        {
                                            Pp.ParagraphBorders.LeftBorder = new LeftBorder();
                                        }

                                        if (Pp.ParagraphBorders.LeftBorder.Val == null || Pp.ParagraphBorders.LeftBorder.Val == "")
                                        {
                                            Pp.ParagraphBorders.LeftBorder.Val = mystyle[0].StyleParagraphProperties.ParagraphBorders.LeftBorder.Val;
                                        }
                                        else
                                        {
                                            if (GlobalMethods.bLeftBorder == true)
                                            {
                                                Pp.ParagraphBorders.LeftBorder.Val = mystyle[0].StyleParagraphProperties.ParagraphBorders.LeftBorder.Val;
                                            }
                                        }
                                    }

                                    if (mystyle[0].StyleParagraphProperties.ParagraphBorders.TopBorder != null)
                                    {
                                        if (Pp.ParagraphBorders.TopBorder == null)
                                        {
                                            Pp.ParagraphBorders.TopBorder = new TopBorder();
                                        }


                                        if (Pp.ParagraphBorders.TopBorder.Val == null || Pp.ParagraphBorders.TopBorder.Val == "")
                                        {
                                            Pp.ParagraphBorders.TopBorder.Val = mystyle[0].StyleParagraphProperties.ParagraphBorders.TopBorder.Val;
                                        }
                                        else
                                        {
                                            if (GlobalMethods.bTopBorder == true)
                                            {
                                                Pp.ParagraphBorders.TopBorder.Val = mystyle[0].StyleParagraphProperties.ParagraphBorders.TopBorder.Val;
                                            }
                                        }
                                    }

                                    if (mystyle[0].StyleParagraphProperties.ParagraphBorders.RightBorder != null)
                                    {
                                        if (Pp.ParagraphBorders.RightBorder == null)
                                        {
                                            Pp.ParagraphBorders.RightBorder = new RightBorder();
                                        }

                                        if (Pp.ParagraphBorders.RightBorder.Val == null || Pp.ParagraphBorders.RightBorder.Val == "")
                                        {
                                            Pp.ParagraphBorders.RightBorder.Val = mystyle[0].StyleParagraphProperties.ParagraphBorders.RightBorder.Val;
                                        }
                                        else
                                        {
                                            if (GlobalMethods.bRightBorder == true)
                                            {
                                                Pp.ParagraphBorders.RightBorder.Val = mystyle[0].StyleParagraphProperties.ParagraphBorders.RightBorder.Val;
                                            }
                                        }
                                    }

                                    if (mystyle[0].StyleParagraphProperties.ParagraphBorders.BottomBorder != null)
                                    {
                                        if (Pp.ParagraphBorders.BottomBorder == null)
                                        {
                                            Pp.ParagraphBorders.BottomBorder = new BottomBorder();
                                        }

                                        if (Pp.ParagraphBorders.BottomBorder.Val == null || Pp.ParagraphBorders.BottomBorder.Val == "")
                                        {
                                            Pp.ParagraphBorders.BottomBorder.Val = mystyle[0].StyleParagraphProperties.ParagraphBorders.BottomBorder.Val;
                                        }
                                        else
                                        {
                                            if (GlobalMethods.bBottomBorder == true)
                                            {
                                                Pp.ParagraphBorders.BottomBorder.Val = mystyle[0].StyleParagraphProperties.ParagraphBorders.BottomBorder.Val;
                                            }
                                        }
                                    }

                                    if (mystyle[0].StyleParagraphProperties.ParagraphBorders.BetweenBorder != null)
                                    {
                                        if (Pp.ParagraphBorders.BetweenBorder == null)
                                        {
                                            Pp.ParagraphBorders.BetweenBorder = new BetweenBorder();
                                        }

                                        if (Pp.ParagraphBorders.BetweenBorder.Val == null || Pp.ParagraphBorders.BetweenBorder.Val == "")
                                        {
                                            Pp.ParagraphBorders.BetweenBorder.Val = mystyle[0].StyleParagraphProperties.ParagraphBorders.BetweenBorder.Val;
                                        }
                                        else
                                        {
                                            if (GlobalMethods.bBetweenBorder == true)
                                            {
                                                Pp.ParagraphBorders.BetweenBorder.Val = mystyle[0].StyleParagraphProperties.ParagraphBorders.BetweenBorder.Val;
                                            }
                                        }
                                    }

                                    if (mystyle[0].StyleParagraphProperties.ParagraphBorders.BarBorder != null)
                                    {
                                        if (Pp.ParagraphBorders.BarBorder == null)
                                        {
                                            Pp.ParagraphBorders.BarBorder = new BarBorder();
                                        }

                                        if (Pp.ParagraphBorders.BarBorder.Val == null || Pp.ParagraphBorders.BarBorder.Val == "")
                                        {
                                            Pp.ParagraphBorders.BarBorder.Val = mystyle[0].StyleParagraphProperties.ParagraphBorders.BarBorder.Val;
                                        }
                                        else
                                        {
                                            if (GlobalMethods.bBarBorder == true)
                                            {
                                                Pp.ParagraphBorders.BarBorder.Val = mystyle[0].StyleParagraphProperties.ParagraphBorders.BarBorder.Val;
                                            }
                                        }
                                    }
                                }
                            }

                            if (mystyle[0].StyleRunProperties != null)
                            {
                                if (PS.Parent.Parent != null)
                                {
                                    foreach (Run R in PS.Parent.Parent.Descendants<Run>().ToList())
                                    {
                                        if (R.RunProperties == null)
                                        {
                                            // Create a new Run Properties
                                            R.RunProperties = new RunProperties();

                                            GlobalMethods.bBold = true;
                                            GlobalMethods.bCaps = true;
                                            GlobalMethods.bEmphasis = true;
                                            GlobalMethods.bItalic = true;
                                            GlobalMethods.bSmallCaps = true;
                                            GlobalMethods.bUnderline = true;
                                            GlobalMethods.bStrike = true;
                                            GlobalMethods.bDoubleStrike = true;

                                        }

                                        if (R.RunProperties.Bold == null)
                                        {
                                            if (mystyle[0].StyleRunProperties.Bold != null)
                                            {
                                                R.RunProperties.Bold = new Bold();
                                                R.RunProperties.Bold.Val = mystyle[0].StyleRunProperties.Bold.Val;
                                            }
                                        }
                                        else
                                        {
                                            if (GlobalMethods.bBold == true)
                                            {
                                                if (mystyle[0].StyleRunProperties.Bold != null)
                                                {
                                                    R.RunProperties.Bold.Val = mystyle[0].StyleRunProperties.Bold.Val;
                                                }
                                            }
                                        }

                                        if (R.RunProperties.Caps == null)
                                        {
                                            if (mystyle[0].StyleRunProperties.Caps != null)
                                            {
                                                R.RunProperties.Caps = new Caps();
                                                R.RunProperties.Caps.Val = mystyle[0].StyleRunProperties.Caps.Val;
                                            }
                                        }
                                        else
                                        {
                                            if (GlobalMethods.bCaps == true)
                                            {
                                                if (mystyle[0].StyleRunProperties.Caps != null)
                                                {
                                                    R.RunProperties.Caps.Val = mystyle[0].StyleRunProperties.Caps.Val;
                                                }
                                            }
                                        }

                                        if (R.RunProperties.Emphasis == null)
                                        {
                                            if (mystyle[0].StyleRunProperties.Emphasis != null)
                                            {
                                                R.RunProperties.Emphasis = new Emphasis();
                                                R.RunProperties.Emphasis.Val = mystyle[0].StyleRunProperties.Emphasis.Val;
                                            }
                                        }
                                        else
                                        {
                                            if (GlobalMethods.bEmphasis == true)
                                            {
                                                if (mystyle[0].StyleRunProperties.Emphasis != null)
                                                    R.RunProperties.Emphasis.Val = mystyle[0].StyleRunProperties.Emphasis.Val;
                                            }
                                        }

                                        if (R.RunProperties.Italic == null)
                                        {
                                            if (mystyle[0].StyleRunProperties.Italic != null)
                                            {
                                                R.RunProperties.Italic = new Italic();
                                                R.RunProperties.Italic.Val = mystyle[0].StyleRunProperties.Italic.Val;
                                            }
                                        }
                                        else
                                        {
                                            if (GlobalMethods.bItalic == true)
                                            {
                                                if (mystyle[0].StyleRunProperties.Italic != null)
                                                    R.RunProperties.Italic.Val = mystyle[0].StyleRunProperties.Italic.Val;
                                            }
                                        }

                                        if (R.RunProperties.SmallCaps == null)
                                        {
                                            if (mystyle[0].StyleRunProperties.SmallCaps != null)
                                            {
                                                R.RunProperties.SmallCaps = new SmallCaps();
                                                R.RunProperties.SmallCaps.Val = mystyle[0].StyleRunProperties.SmallCaps.Val;
                                            }
                                        }
                                        else
                                        {
                                            if (GlobalMethods.bSmallCaps == true)
                                            {
                                                if (mystyle[0].StyleRunProperties.SmallCaps != null)
                                                    R.RunProperties.SmallCaps.Val = mystyle[0].StyleRunProperties.SmallCaps.Val;
                                            }
                                        }

                                        if (R.RunProperties.Underline == null)
                                        {
                                            if (mystyle[0].StyleRunProperties.Underline != null)
                                            {
                                                R.RunProperties.Underline = new Underline();
                                                R.RunProperties.Underline.Val = mystyle[0].StyleRunProperties.Underline.Val;
                                            }
                                        }
                                        else
                                        {
                                            if (GlobalMethods.bUnderline == true)
                                            {
                                                if (mystyle[0].StyleRunProperties.Underline != null)
                                                    R.RunProperties.Underline.Val = mystyle[0].StyleRunProperties.Underline.Val;
                                            }
                                        }

                                        if (R.RunProperties.Strike == null)
                                        {
                                            if (mystyle[0].StyleRunProperties.Strike != null)
                                            {
                                                R.RunProperties.Strike = new Strike();
                                                R.RunProperties.Strike.Val = mystyle[0].StyleRunProperties.Strike.Val;
                                            }
                                        }
                                        else
                                        {
                                            if (GlobalMethods.bStrike == true)
                                            {
                                                if (mystyle[0].StyleRunProperties.Strike != null)
                                                    R.RunProperties.Strike.Val = mystyle[0].StyleRunProperties.Strike.Val;
                                            }
                                        }

                                        if (R.RunProperties.DoubleStrike == null)
                                        {
                                            if (mystyle[0].StyleRunProperties.DoubleStrike != null)
                                            {
                                                R.RunProperties.DoubleStrike = new DoubleStrike();
                                                R.RunProperties.DoubleStrike.Val = mystyle[0].StyleRunProperties.DoubleStrike.Val;
                                            }
                                        }
                                        else
                                        {
                                            if (GlobalMethods.bDoubleStrike == true)
                                            {
                                                if (mystyle[0].StyleRunProperties.DoubleStrike != null)
                                                    R.RunProperties.DoubleStrike.Val = mystyle[0].StyleRunProperties.DoubleStrike.Val;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                D.Save();
                WPD.Close();
            }
        }

        private static void updateParaPropertiesWithBasedOnStyle(ParagraphStyleId PS, ParagraphProperties Pp, string strBasedOnStyle)
        {
            if (GlobalMethods.StyleList.Count > 0)
            {
                string key = strBasedOnStyle;
                List<Style> mystyle = (from kvp in GlobalMethods.StyleList where kvp.Key == key select kvp.Value).ToList();

                if (mystyle.Count > 0)
                {
                    if (mystyle[0].StyleParagraphProperties != null)
                    {
                        if (mystyle[0].StyleParagraphProperties.Indentation != null)
                        {
                            if (((ParagraphProperties)PS.Parent).Indentation == null)
                            {
                                GlobalMethods.bIndentation = true;
                                GlobalMethods.bLeftIndentation = true;
                                GlobalMethods.bHangingIndentation = true;
                                GlobalMethods.bFirstLineIndentation = true;

                                Pp.Indentation = new Indentation();
                            }

                            if (mystyle[0].StyleParagraphProperties.Indentation.Left != null)
                            {
                                if (Pp.Indentation.Left == null) // || Pp.Indentation.Left == ""
                                {
                                    GlobalMethods.bLeftIndentation = true;
                                    Pp.Indentation.Left = mystyle[0].StyleParagraphProperties.Indentation.Left.Value;
                                }
                            }

                            if (mystyle[0].StyleParagraphProperties.Indentation.Hanging != null)
                            {
                                if (Pp.Indentation.Hanging == null) //  || Pp.Indentation.Hanging == ""
                                {
                                    GlobalMethods.bHangingIndentation = true;
                                    Pp.Indentation.Hanging = mystyle[0].StyleParagraphProperties.Indentation.Hanging.Value;
                                }
                            }

                            if (mystyle[0].StyleParagraphProperties.Indentation.FirstLine != null)
                            {
                                if (Pp.Indentation.FirstLine == null) //  || Pp.Indentation.FirstLine == ""
                                {
                                    GlobalMethods.bFirstLineIndentation = true;
                                    Pp.Indentation.FirstLine = mystyle[0].StyleParagraphProperties.Indentation.FirstLine.Value;
                                }
                            }
                        }

                        if (mystyle[0].StyleParagraphProperties.TextAlignment != null)
                        {
                            if (Pp.TextAlignment == null)
                            {
                                GlobalMethods.bTextAlignment = true;
                                Pp.TextAlignment = new TextAlignment();
                                Pp.TextAlignment.Val = mystyle[0].StyleParagraphProperties.TextAlignment.Val;
                            }
                        }

                        if (mystyle[0].StyleParagraphProperties.Justification != null)
                        {
                            if (((ParagraphProperties)PS.Parent).Justification == null)
                            {
                                GlobalMethods.bJustification = true;
                                Pp.Justification = new Justification();
                                Pp.Justification.Val = mystyle[0].StyleParagraphProperties.Justification.Val;
                            }
                        }


                        GlobalMethods.bParagraphBorders = false;
                        GlobalMethods.bLeftBorder = false;
                        GlobalMethods.bTopBorder = false;
                        GlobalMethods.bRightBorder = false;
                        GlobalMethods.bBottomBorder = false;
                        GlobalMethods.bBetweenBorder = false;
                        GlobalMethods.bBarBorder = false;

                        if (mystyle[0].StyleParagraphProperties.ParagraphBorders != null)
                        {
                            if (Pp.ParagraphBorders == null)
                            {
                                GlobalMethods.bParagraphBorders = true;
                                GlobalMethods.bLeftBorder = true;
                                GlobalMethods.bTopBorder = true;
                                GlobalMethods.bRightBorder = true;
                                GlobalMethods.bBottomBorder = true;
                                GlobalMethods.bBetweenBorder = true;
                                GlobalMethods.bBarBorder = true;
                                Pp.ParagraphBorders = new ParagraphBorders();
                            }

                            if (mystyle[0].StyleParagraphProperties.ParagraphBorders.LeftBorder != null)
                            {
                                if (Pp.ParagraphBorders.LeftBorder == null)
                                {
                                    Pp.ParagraphBorders.LeftBorder = new LeftBorder();
                                }

                                if (Pp.ParagraphBorders.LeftBorder.Val == null || Pp.ParagraphBorders.LeftBorder.Val == "")
                                {
                                    GlobalMethods.bLeftBorder = true;
                                    Pp.ParagraphBorders.LeftBorder.Val = mystyle[0].StyleParagraphProperties.ParagraphBorders.LeftBorder.Val;
                                }
                            }

                            if (mystyle[0].StyleParagraphProperties.ParagraphBorders.TopBorder != null)
                            {
                                if (Pp.ParagraphBorders.TopBorder == null)
                                {
                                    Pp.ParagraphBorders.TopBorder = new TopBorder();
                                }

                                if (Pp.ParagraphBorders.TopBorder.Val == null || Pp.ParagraphBorders.TopBorder.Val == "")
                                {
                                    GlobalMethods.bTopBorder = true;

                                    Pp.ParagraphBorders.TopBorder.Val = mystyle[0].StyleParagraphProperties.ParagraphBorders.TopBorder.Val;
                                }
                            }

                            if (mystyle[0].StyleParagraphProperties.ParagraphBorders.RightBorder != null)
                            {
                                if (Pp.ParagraphBorders.RightBorder == null)
                                {
                                    Pp.ParagraphBorders.RightBorder = new RightBorder();
                                }

                                if (Pp.ParagraphBorders.RightBorder.Val == null || Pp.ParagraphBorders.RightBorder.Val == "")
                                {
                                    GlobalMethods.bRightBorder = true;
                                    Pp.ParagraphBorders.RightBorder.Val = mystyle[0].StyleParagraphProperties.ParagraphBorders.RightBorder.Val;
                                }
                            }

                            if (mystyle[0].StyleParagraphProperties.ParagraphBorders.BottomBorder != null)
                            {
                                if (Pp.ParagraphBorders.BottomBorder == null)
                                {
                                    Pp.ParagraphBorders.BottomBorder = new BottomBorder();
                                }

                                if (Pp.ParagraphBorders.BottomBorder.Val == null || Pp.ParagraphBorders.BottomBorder.Val == "")
                                {
                                    GlobalMethods.bBottomBorder = true;

                                    Pp.ParagraphBorders.BottomBorder.Val = mystyle[0].StyleParagraphProperties.ParagraphBorders.BottomBorder.Val;
                                }
                            }

                            if (mystyle[0].StyleParagraphProperties.ParagraphBorders.BetweenBorder != null)
                            {
                                if (Pp.ParagraphBorders.BetweenBorder == null)
                                {
                                    Pp.ParagraphBorders.BetweenBorder = new BetweenBorder();
                                }

                                if (Pp.ParagraphBorders.BetweenBorder.Val == null || Pp.ParagraphBorders.BetweenBorder.Val == "")
                                {
                                    GlobalMethods.bBetweenBorder = true;

                                    Pp.ParagraphBorders.BetweenBorder.Val = mystyle[0].StyleParagraphProperties.ParagraphBorders.BetweenBorder.Val;
                                }
                            }

                            if (mystyle[0].StyleParagraphProperties.ParagraphBorders.BarBorder != null)
                            {
                                if (Pp.ParagraphBorders.BarBorder == null)
                                {
                                    Pp.ParagraphBorders.BarBorder = new BarBorder();
                                }

                                if (Pp.ParagraphBorders.BarBorder.Val == null || Pp.ParagraphBorders.BarBorder.Val == "")
                                {
                                    GlobalMethods.bBarBorder = true;

                                    Pp.ParagraphBorders.BarBorder.Val = mystyle[0].StyleParagraphProperties.ParagraphBorders.BarBorder.Val;
                                }
                            }
                        }
                    }

                    if (mystyle[0].StyleRunProperties != null)
                    {
                        if (PS.Parent.Parent != null)
                        {
                            foreach (Run R in PS.Parent.Parent.Descendants<Run>().ToList())
                            {
                                if (R.RunProperties == null)
                                {
                                    // Create a new Run Properties
                                    R.RunProperties = new RunProperties();

                                    GlobalMethods.bBold = true;
                                    GlobalMethods.bCaps = true;
                                    GlobalMethods.bEmphasis = true;
                                    GlobalMethods.bItalic = true;
                                    GlobalMethods.bSmallCaps = true;
                                    GlobalMethods.bUnderline = true;
                                    GlobalMethods.bStrike = true;
                                    GlobalMethods.bDoubleStrike = true;
                                }

                                if (R.RunProperties.Bold == null)
                                {
                                    GlobalMethods.bBold = true;

                                    if (mystyle[0].StyleRunProperties.Bold != null)
                                    {
                                        R.RunProperties.Bold = new Bold();
                                        R.RunProperties.Bold.Val = mystyle[0].StyleRunProperties.Bold.Val;
                                    }
                                }

                                if (R.RunProperties.Caps == null)
                                {
                                    GlobalMethods.bCaps = true;

                                    if (mystyle[0].StyleRunProperties.Caps != null)
                                    {
                                        R.RunProperties.Caps = new Caps();
                                        R.RunProperties.Caps.Val = mystyle[0].StyleRunProperties.Caps.Val;
                                    }
                                }

                                if (R.RunProperties.Emphasis == null)
                                {
                                    GlobalMethods.bEmphasis = true;

                                    if (mystyle[0].StyleRunProperties.Emphasis != null)
                                    {
                                        R.RunProperties.Emphasis = new Emphasis();
                                        R.RunProperties.Emphasis.Val = mystyle[0].StyleRunProperties.Emphasis.Val;
                                    }
                                }

                                if (R.RunProperties.Italic == null)
                                {
                                    GlobalMethods.bItalic = true;

                                    if (mystyle[0].StyleRunProperties.Italic != null)
                                    {
                                        R.RunProperties.Italic = new Italic();
                                        R.RunProperties.Italic.Val = mystyle[0].StyleRunProperties.Italic.Val;
                                    }
                                }

                                if (R.RunProperties.SmallCaps == null)
                                {
                                    GlobalMethods.bSmallCaps = true;

                                    if (mystyle[0].StyleRunProperties.SmallCaps != null)
                                    {
                                        R.RunProperties.SmallCaps = new SmallCaps();
                                        R.RunProperties.SmallCaps.Val = mystyle[0].StyleRunProperties.SmallCaps.Val;
                                    }
                                }

                                if (R.RunProperties.Underline == null)
                                {
                                    GlobalMethods.bUnderline = true;

                                    if (mystyle[0].StyleRunProperties.Underline != null)
                                    {
                                        R.RunProperties.Underline = new Underline();
                                        R.RunProperties.Underline.Val = mystyle[0].StyleRunProperties.Underline.Val;
                                    }
                                }

                                if (R.RunProperties.Strike == null)
                                {
                                    GlobalMethods.bStrike = true;

                                    if (mystyle[0].StyleRunProperties.Strike != null)
                                    {
                                        R.RunProperties.Strike = new Strike();
                                        R.RunProperties.Strike.Val = mystyle[0].StyleRunProperties.Strike.Val;
                                    }
                                }

                                if (R.RunProperties.DoubleStrike == null)
                                {
                                    GlobalMethods.bDoubleStrike = true;
                                    if (mystyle[0].StyleRunProperties.DoubleStrike != null)
                                    {
                                        R.RunProperties.DoubleStrike = new DoubleStrike();
                                        R.RunProperties.DoubleStrike.Val = mystyle[0].StyleRunProperties.DoubleStrike.Val;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        private static void updateCharPropertiesWithBasedOnStyle(RunStyle PS, RunProperties Rp, string strBasedOnStyle)
        {
            if (GlobalMethods.StyleList.Count > 0)
            {
                string key = strBasedOnStyle;
                List<Style> mystyle = (from kvp in GlobalMethods.StyleList where kvp.Key == key select kvp.Value).ToList();

                if (mystyle.Count > 0)
                {
                    if (mystyle[0].StyleRunProperties != null)
                    {
                        if (PS.Parent.Parent != null)
                        {
                            if (Rp == null)
                            {
                                // Create a new Run Properties
                                Rp = new RunProperties();
                            }


                            if (Rp.VerticalTextAlignment == null)
                            {
                                GlobalMethods.bVertAlignment = true;
                                if (mystyle[0].StyleRunProperties.VerticalTextAlignment != null)
                                {
                                    Rp.VerticalTextAlignment = new VerticalTextAlignment();
                                    Rp.VerticalTextAlignment.Val = mystyle[0].StyleRunProperties.VerticalTextAlignment.Val;
                                }
                            }


                            if (Rp.Bold == null)
                            {
                                GlobalMethods.bBold = true;

                                if (mystyle[0].StyleRunProperties.Bold != null)
                                {
                                    if (mystyle[0].StyleRunProperties.Bold.Val != null)
                                    {
                                        Rp.Bold = new Bold();
                                        Rp.Bold.Val = mystyle[0].StyleRunProperties.Bold.Val;
                                    }
                                    else
                                    {
                                        Rp.Bold = new Bold();
                                    }
                                }
                            }

                            if (Rp.Caps == null)
                            {
                                GlobalMethods.bCaps = true;

                                if (mystyle[0].StyleRunProperties.Caps != null)
                                {
                                    Rp.Caps = new Caps();
                                    Rp.Caps.Val = mystyle[0].StyleRunProperties.Caps.Val;
                                }
                            }

                            if (Rp.Emphasis == null)
                            {
                                GlobalMethods.bEmphasis = true;

                                if (mystyle[0].StyleRunProperties.Emphasis != null)
                                {
                                    Rp.Emphasis = new Emphasis();
                                    Rp.Emphasis.Val = mystyle[0].StyleRunProperties.Emphasis.Val;
                                }
                            }

                            if (Rp.Italic == null)
                            {
                                GlobalMethods.bItalic = true;

                                if (mystyle[0].StyleRunProperties.Italic != null)
                                {
                                    Rp.Italic = new Italic();
                                    Rp.Italic.Val = mystyle[0].StyleRunProperties.Italic.Val;
                                }
                            }

                            if (Rp.SmallCaps == null)
                            {
                                GlobalMethods.bSmallCaps = true;

                                if (mystyle[0].StyleRunProperties.SmallCaps != null)
                                {
                                    Rp.SmallCaps = new SmallCaps();
                                    Rp.SmallCaps.Val = mystyle[0].StyleRunProperties.SmallCaps.Val;
                                }
                            }

                            if (Rp.Underline == null)
                            {
                                GlobalMethods.bUnderline = true;

                                if (mystyle[0].StyleRunProperties.Underline != null)
                                {
                                    Rp.Underline = new Underline();
                                    Rp.Underline.Val = mystyle[0].StyleRunProperties.Underline.Val;
                                }
                            }

                            if (Rp.Strike == null)
                            {
                                GlobalMethods.bStrike = true;

                                if (mystyle[0].StyleRunProperties.Strike != null)
                                {
                                    Rp.Strike = new Strike();
                                    Rp.Strike.Val = mystyle[0].StyleRunProperties.Strike.Val;
                                }
                            }

                            if (Rp.DoubleStrike == null)
                            {
                                GlobalMethods.bDoubleStrike = true;
                                if (mystyle[0].StyleRunProperties.DoubleStrike != null)
                                {
                                    Rp.DoubleStrike = new DoubleStrike();
                                    Rp.DoubleStrike.Val = mystyle[0].StyleRunProperties.DoubleStrike.Val;
                                }
                            }

                            if (Rp.Border == null)
                            {
                                GlobalMethods.bCharBorder = true;
                                if (mystyle[0].StyleRunProperties.Border != null)
                                {
                                    Rp.Border = new Border();
                                    Rp.Border.Val = mystyle[0].StyleRunProperties.Border.Val;
                                }
                            }

                            if (Rp.Color == null)
                            {
                                GlobalMethods.bCharColor = true;
                                if (mystyle[0].StyleRunProperties.Color != null)
                                {
                                    Rp.Color = new Color();
                                    Rp.Color.Val = mystyle[0].StyleRunProperties.Color.Val;
                                }
                            }

                        }
                    }
                }
            }
        }

        public static void ExtractAndStoreCharStylePropertiesInDocument(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                                     .Open(newDoc, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    //RemoveComments = false,
                    RemoveContentControls = true,
                    RemoveEndAndFootNotes = false,
                    //RemoveFieldCodes = false,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = false,
                };

                MarkupSimplifier.SimplifyMarkup(WPD, settings);

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                List<RunStyle> S = D.Descendants<RunStyle>()
                                        .Where(c => c.Val != null).ToList();

                foreach (RunStyle PS in S)
                {
                    if (GlobalMethods.StyleList.Count > 0)
                    {
                        string key = PS.Val;
                        List<Style> mystyle = (from kvp in GlobalMethods.StyleList where kvp.Key == key select kvp.Value).ToList();

                        if (mystyle.Count > 0)
                        {
                            GlobalMethods.bBold = false;
                            GlobalMethods.bCaps = false;
                            GlobalMethods.bEmphasis = false;
                            GlobalMethods.bItalic = false;
                            GlobalMethods.bSmallCaps = false;
                            GlobalMethods.bUnderline = false;
                            GlobalMethods.bStrike = false;
                            GlobalMethods.bDoubleStrike = false;
                            GlobalMethods.bVertAlignment = false;
                            GlobalMethods.bCharBorder = false;

                            if (mystyle[0].StyleRunProperties != null)
                            {
                                if (mystyle[0].Type == "character")
                                {
                                    if (PS.Parent != null)
                                    {
                                        if (PS.Parent.LocalName == "rPr")
                                        {
                                            RunProperties rP;

                                            if (((RunProperties)PS.Parent) == null)
                                            {
                                                GlobalMethods.bBold = true;
                                                GlobalMethods.bCaps = true;
                                                GlobalMethods.bEmphasis = true;
                                                GlobalMethods.bItalic = true;
                                                GlobalMethods.bSmallCaps = true;
                                                GlobalMethods.bUnderline = true;
                                                GlobalMethods.bStrike = true;
                                                GlobalMethods.bDoubleStrike = true;
                                                GlobalMethods.bVertAlignment = true;
                                                GlobalMethods.bCharBorder = true;
                                                GlobalMethods.bCharColor = true;

                                                rP = new RunProperties();
                                            }
                                            else
                                            {
                                                rP = ((RunProperties)PS.Parent);

                                                GlobalMethods.bBold = false;
                                                GlobalMethods.bCaps = false;
                                                GlobalMethods.bEmphasis = false;
                                                GlobalMethods.bItalic = false;
                                                GlobalMethods.bSmallCaps = false;
                                                GlobalMethods.bUnderline = false;
                                                GlobalMethods.bStrike = false;
                                                GlobalMethods.bDoubleStrike = false;
                                                GlobalMethods.bVertAlignment = false;
                                                GlobalMethods.bCharBorder = false;
                                                GlobalMethods.bCharColor = false;
                                            }

                                            if (mystyle[0].BasedOn != null && mystyle[0].BasedOn.Val != null)
                                            {
                                                if ((mystyle[0].BasedOn.Val != "Default Paragraph Font"))
                                                {
                                                    //GlobalMethods.swriter.WriteLine(mystyle[0].BasedOn.Val);
                                                    updateCharPropertiesWithBasedOnStyle(PS, rP, mystyle[0].BasedOn.Val);
                                                }
                                            }

                                            if (mystyle[0].StyleRunProperties.VerticalTextAlignment != null)
                                            {
                                                if (rP.VerticalTextAlignment == null)
                                                {
                                                    rP.VerticalTextAlignment = new VerticalTextAlignment();
                                                    rP.VerticalTextAlignment.Val = mystyle[0].StyleRunProperties.VerticalTextAlignment.Val;
                                                }
                                                else
                                                {
                                                    if (GlobalMethods.bVertAlignment == true)
                                                    {
                                                        rP.VerticalTextAlignment.Val = mystyle[0].StyleRunProperties.VerticalTextAlignment.Val;
                                                    }
                                                }
                                            }

                                            if (mystyle[0].StyleRunProperties.Italic != null)
                                            {
                                                if (rP.Italic == null)
                                                {
                                                    rP.Italic = new Italic();
                                                    rP.Italic.Val = mystyle[0].StyleRunProperties.Italic.Val;
                                                }
                                                else
                                                {
                                                    if (GlobalMethods.bItalic == true)
                                                    {
                                                        rP.Italic.Val = mystyle[0].StyleRunProperties.Italic.Val;
                                                    }
                                                }
                                            }

                                            if (mystyle[0].StyleRunProperties.Bold != null)
                                            {
                                                if (rP.Bold == null)
                                                {
                                                    rP.Bold = new Bold();
                                                    rP.Bold.Val = mystyle[0].StyleRunProperties.Bold.Val;
                                                }
                                                else
                                                {
                                                    if (GlobalMethods.bBold == true)
                                                    {
                                                        rP.Bold.Val = mystyle[0].StyleRunProperties.Bold.Val;
                                                    }
                                                }
                                            }

                                            if (mystyle[0].StyleRunProperties.Underline != null)
                                            {
                                                if (rP.Underline == null)
                                                {
                                                    rP.Underline = new Underline();
                                                    rP.Underline.Val = mystyle[0].StyleRunProperties.Underline.Val;
                                                }
                                                else
                                                {
                                                    if (GlobalMethods.bUnderline == true)
                                                    {
                                                        rP.Underline.Val = mystyle[0].StyleRunProperties.Underline.Val;
                                                    }
                                                }
                                            }

                                            if (mystyle[0].StyleRunProperties.Border != null)
                                            {
                                                if (rP.Border == null)
                                                {
                                                    rP.Border = new Border();
                                                    rP.Border.Val = mystyle[0].StyleRunProperties.Border.Val;
                                                }
                                                else
                                                {
                                                    if (GlobalMethods.bCharBorder == true)
                                                    {
                                                        rP.Border.Val = mystyle[0].StyleRunProperties.Border.Val;
                                                    }
                                                }
                                            }

                                            if (mystyle[0].StyleRunProperties.Caps != null)
                                            {
                                                if (rP.Caps == null)
                                                {
                                                    rP.Caps = new Caps();
                                                    rP.Caps.Val = mystyle[0].StyleRunProperties.Caps.Val;
                                                }
                                                else
                                                {
                                                    if (GlobalMethods.bCaps == true)
                                                    {
                                                        rP.Caps.Val = mystyle[0].StyleRunProperties.Caps.Val;
                                                    }
                                                }
                                            }

                                            if (mystyle[0].StyleRunProperties.Color != null)
                                            {
                                                if (rP.Color == null)
                                                {
                                                    rP.Color = new Color();
                                                    rP.Color.Val = mystyle[0].StyleRunProperties.Color.Val;
                                                }
                                                else
                                                {
                                                    if (GlobalMethods.bCharColor == true)
                                                    {
                                                        rP.Color.Val = mystyle[0].StyleRunProperties.Color.Val;
                                                    }
                                                }
                                            }

                                            if (mystyle[0].StyleRunProperties.DoubleStrike != null)
                                            {
                                                if (rP.DoubleStrike == null)
                                                {
                                                    rP.DoubleStrike = new DoubleStrike();
                                                    rP.DoubleStrike.Val = mystyle[0].StyleRunProperties.DoubleStrike.Val;
                                                }
                                                else
                                                {
                                                    if (GlobalMethods.bDoubleStrike == true)
                                                    {
                                                        rP.DoubleStrike.Val = mystyle[0].StyleRunProperties.DoubleStrike.Val;
                                                    }
                                                }

                                            }

                                            if (mystyle[0].StyleRunProperties.Emphasis != null)
                                            {
                                                if (rP.Emphasis == null)
                                                {
                                                    rP.Emphasis = new Emphasis();
                                                    rP.Emphasis.Val = mystyle[0].StyleRunProperties.Emphasis.Val;
                                                }
                                                else
                                                {
                                                    if (GlobalMethods.bEmphasis == true)
                                                    {
                                                        rP.Emphasis.Val = mystyle[0].StyleRunProperties.Emphasis.Val;
                                                    }
                                                }
                                            }

                                            if (mystyle[0].StyleRunProperties.SmallCaps != null)
                                            {
                                                if (rP.SmallCaps == null)
                                                {
                                                    rP.SmallCaps = new SmallCaps();
                                                    rP.SmallCaps.Val = mystyle[0].StyleRunProperties.SmallCaps.Val;
                                                }
                                                else
                                                {
                                                    if (GlobalMethods.bSmallCaps == true)
                                                    {
                                                        rP.SmallCaps.Val = mystyle[0].StyleRunProperties.SmallCaps.Val;
                                                    }
                                                }
                                            }

                                            if (mystyle[0].StyleRunProperties.Strike != null)
                                            {
                                                if (rP.Strike == null)
                                                {
                                                    rP.Strike = new Strike();
                                                    rP.Strike.Val = mystyle[0].StyleRunProperties.Strike.Val;
                                                }
                                                else
                                                {
                                                    if (GlobalMethods.bStrike == true)
                                                    {
                                                        rP.Strike.Val = mystyle[0].StyleRunProperties.Strike.Val;
                                                    }
                                                }
                                            }
                                        }
                                    }

                                    PS.Remove();
                                }
                            }
                        }
                    }
                }

                D.Save();
            }
        }

        public static void RemoveCustomerSpecificParaStylesFromDocumentStyles(string newDoc)
        {
            List<string> strRemoveParaStyles = new List<string>();
            strRemoveParaStyles.Clear();

            strRemoveParaStyles = GlobalMethods.ReadAndStoreFileValuesInArray(GlobalMethods.str3CMRemoveCustomerParaStyleFileName);

            if (strRemoveParaStyles.Count > 0)
            {
                using (WordprocessingDocument WPD = WordprocessingDocument
                                                    .Open(newDoc, true))
                {
                    SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                    {
                        //RemoveComments = false,
                        RemoveContentControls = true,
                        RemoveEndAndFootNotes = false,
                        //RemoveFieldCodes = false,
                        RemoveLastRenderedPageBreak = true,
                        RemovePermissions = true,
                        RemoveProof = true,
                        RemoveRsidInfo = true,
                        RemoveSmartTags = true,
                        RemoveSoftHyphens = false,
                        ReplaceTabsWithSpaces = false,
                    };

                    MarkupSimplifier.SimplifyMarkup(WPD, settings);

                    StyleDefinitionsPart MDP = WPD.MainDocumentPart.StyleDefinitionsPart;

                    Styles D = MDP.Styles;

                    foreach (Style S in D.Descendants<Style>().ToList())
                    {
                        if (S != null)
                        {
                            if (S.StyleId != null)
                            {
                                if (GlobalMethods.CheckTheExistanceOfStringInList(strRemoveParaStyles, S.StyleId) == true)
                                {
                                    S.Remove();
                                }
                            }
                        }
                    }

                    D.Save();
                }
            }
        }

        public static void RemoveCustomerSpecificParaStylesFromTheDocument(string newDoc)
        {
            List<string> strRemoveParaStyles = new List<string>();
            strRemoveParaStyles.Clear();

            strRemoveParaStyles = GlobalMethods.ReadAndStoreFileValuesInArray(GlobalMethods.str3CMRemoveCustomerParaStyleFileName);

            if (strRemoveParaStyles.Count > 0)
            {
                using (WordprocessingDocument WPD = WordprocessingDocument
                                                    .Open(newDoc, true))
                {
                    SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                    {
                        //RemoveComments = false,
                        RemoveContentControls = true,
                        RemoveEndAndFootNotes = false,
                        //RemoveFieldCodes = false,
                        RemoveLastRenderedPageBreak = true,
                        RemovePermissions = true,
                        RemoveProof = true,
                        RemoveRsidInfo = true,
                        RemoveSmartTags = true,
                        RemoveSoftHyphens = false,
                        ReplaceTabsWithSpaces = false,
                    };

                    MarkupSimplifier.SimplifyMarkup(WPD, settings);

                    MainDocumentPart MDP = WPD.MainDocumentPart;

                    Document D = MDP.Document;

                    foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null)
                            {
                                if (GlobalMethods.CheckTheExistanceOfStringInList(strRemoveParaStyles, P.ParagraphProperties.ParagraphStyleId.Val.Value) == true)
                                {
                                    P.ParagraphProperties.ParagraphStyleId.Remove();
                                }
                            }
                        }
                    }
                    D.Save();
                }
            }
        }

        public static void ExecuteStyleMapping(string newDoc, string StyleMappingConfig)
        {
            // Read the StyleMappingConfing and store the values in array //
            List<string> strStyleMapping = new List<string>();

            strStyleMapping = GlobalMethods.ReadAndStoreFileValuesInArray(StyleMappingConfig);

            string SourceStyle = null;
            string TargetStyle = null;

            using (WordprocessingDocument wDoc = WordprocessingDocument.Open(newDoc, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    //RemoveComments = false,
                    RemoveContentControls = true,
                    RemoveEndAndFootNotes = false,
                    //RemoveFieldCodes = false,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = false,
                };

                MarkupSimplifier.SimplifyMarkup(wDoc, settings);

                var xDoc = wDoc.MainDocumentPart.GetXDocument();

                XmlDocument xd = xDoc.GetXmlDocument();

                xd.LoadXml(xd.InnerXml);

                XmlNodeList nodeList;


                XmlNamespaceManager ns = new XmlNamespaceManager(xd.NameTable);
                ns.AddNamespace("w", "http://schemas.openxmlformats.org/wordprocessingml/2006/main");

                XmlNode root = xd.DocumentElement;
                nodeList = root.SelectNodes("w:body[w:p/w:pPr]", ns);

                XElement xe;
                foreach (XmlNode book in nodeList)
                {
                    xe = book.GetXElement();

                    if (xe.HasElements)
                    {
                        foreach (XElement xee in xe.Elements())
                        {

                            if (xee.HasElements)
                            {
                                // Check if the paragraph has style element
                                if (CheckIfTheParaHasChildElement(xee) == false)
                                {
                                    // Create new Style element with Normal style

                                    foreach (string strStyle in strStyleMapping)
                                    {
                                        if (strStyle != null && strStyle.Trim() != "")
                                        {
                                            SourceStyle = null;
                                            TargetStyle = null;
                                            string[] t = strStyle.Split('=');

                                            if (t.Length > 0)
                                            {
                                                SourceStyle = t[0];
                                                TargetStyle = t[1];
                                                GlobalMethods.ValidStyleList.Add(TargetStyle);
                                                GlobalMethods.ValidStyleList = GlobalMethods.ValidStyleList.Distinct().ToList();
                                                if (SourceStyle.ToLower().Contains("normal|"))
                                                {
                                                    XNamespace w = @"http://schemas.openxmlformats.org/wordprocessingml/2006/main";
                                                    XElement style = new XElement(w + "pPr", "",
                                                        new XElement(w + "pStyle", new XAttribute(w + "val", TargetStyle)));
                                                    xee.AddFirst(style);
                                                }
                                            }
                                        }
                                    }
                                }
                                else
                                {
                                    //Developer name :Priyanka Vishwakarma,Date:01_10_2019,Requirement:Mapping style from Configuration file for table ,Integrated by:Vikas sir,
                                    if (xee.Name.LocalName == "tbl")
                                    {
                                        foreach (XElement xec in xee.Elements())
                                        {
                                            if (xec.HasElements)
                                            {
                                                foreach (XElement xec1 in xec.Elements())
                                                {
                                                    if (xec1.HasElements)
                                                    {
                                                        foreach (XElement xec2 in xec1.Elements())
                                                        {

                                                            if (xec2.Name.LocalName == "p")
                                                            {
                                                                foreach (XElement xec3 in xec2.Descendants())
                                                                {
                                                                    if (xec3.Name.LocalName == "pStyle")
                                                                    {
                                                                        foreach (XAttribute xa4 in xec3.Attributes())
                                                                        {
                                                                            if (xa4.Name == W.val)
                                                                            {

                                                                                foreach (string strStyle in strStyleMapping)
                                                                                {
                                                                                    if (strStyle != null && strStyle.Trim() != "")//s 03102019
                                                                                    {
                                                                                        SourceStyle = null;
                                                                                        TargetStyle = null;
                                                                                        string[] t = strStyle.Split('=');

                                                                                        if (t.Length > 0)
                                                                                        {
                                                                                            SourceStyle = t[0];
                                                                                            TargetStyle = t[1];
                                                                                            GlobalMethods.ValidStyleList.Add(TargetStyle);
                                                                                            GlobalMethods.ValidStyleList = GlobalMethods.ValidStyleList.Distinct().ToList();
                                                                                            if (SourceStyle.Contains("|"))
                                                                                            {
                                                                                                if (SourceStyle.Split('|').ToList().Any(x => x.ToLower() == xa4.Value.ToLower()))
                                                                                                {
                                                                                                    //if (xa1.Value == SourceStyle)
                                                                                                    //{
                                                                                                    xa4.SetValue(TargetStyle);
                                                                                                    break;
                                                                                                    //}
                                                                                                }
                                                                                            }
                                                                                            else
                                                                                            {
                                                                                                if (xa4.Value.ToLower() == SourceStyle.ToLower())
                                                                                                {
                                                                                                    xa4.SetValue(TargetStyle);
                                                                                                    break;
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                } // For Each
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }

                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    //---------------------------End----------------------------------------------
                                    else
                                    {
                                        foreach (XElement xec in xee.Elements())
                                        {
                                            if (xec.HasElements)
                                            {
                                                foreach (XElement xec1 in xec.Elements())
                                                {
                                                    if (xec1.Name.LocalName == "pStyle")
                                                    {
                                                        foreach (XAttribute xa1 in xec1.Attributes())
                                                        {
                                                            if (xa1.Name == W.val)
                                                            {
                                                                if (xa1.Value.ToLower().StartsWith("end"))
                                                                {

                                                                }
                                                                foreach (string strStyle in strStyleMapping)
                                                                {
                                                                    if (strStyle != null && strStyle.Trim() != "")  //03102019
                                                                    {
                                                                        SourceStyle = null;
                                                                        TargetStyle = null;
                                                                        string[] t = strStyle.Split('=');

                                                                        if (t.Length > 0)
                                                                        {
                                                                            SourceStyle = t[0];
                                                                            TargetStyle = t[1];
                                                                            GlobalMethods.ValidStyleList.Add(TargetStyle);
                                                                            GlobalMethods.ValidStyleList = GlobalMethods.ValidStyleList.Distinct().ToList();
                                                                            if (SourceStyle.Contains("|"))
                                                                            {
                                                                                if (SourceStyle.Split('|').ToList().Any(x => x.ToLower() == xa1.Value.ToLower()))
                                                                                {
                                                                                    //if (xa1.Value == SourceStyle)
                                                                                    //{
                                                                                    xa1.SetValue(TargetStyle);
                                                                                    break;
                                                                                    //}
                                                                                }
                                                                            }
                                                                            else
                                                                            {
                                                                                if (xa1.Value.ToLower() == SourceStyle.ToLower())
                                                                                {
                                                                                    xa1.SetValue(TargetStyle);
                                                                                    break;
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                } // For Each
                                                            }
                                                        }
                                                    }
                                                    else if (xec1.Name.LocalName == "rPr")//////for character style mapping integreted on 16-11-2019 by priyanka
                                                    {
                                                        if (xec1.HasElements)
                                                        {
                                                            foreach (var xec3 in xec1.Elements())
                                                            {
                                                                if (xec3.Name.LocalName == "rStyle")
                                                                {
                                                                    foreach (XAttribute xa4 in xec3.Attributes())
                                                                    {
                                                                        if (xa4.Name == W.val)
                                                                        {
                                                                            foreach (string strStyle in strStyleMapping)
                                                                            {
                                                                                if (strStyle != null && strStyle.Trim() != "")//s 03102019
                                                                                {
                                                                                    SourceStyle = null;
                                                                                    TargetStyle = null;
                                                                                    string[] t = strStyle.Split('=');

                                                                                    if (t.Length > 0)
                                                                                    {
                                                                                        SourceStyle = t[0];
                                                                                        TargetStyle = t[1];
                                                                                        GlobalMethods.ValidStyleList.Add(TargetStyle);
                                                                                        GlobalMethods.ValidStyleList = GlobalMethods.ValidStyleList.Distinct().ToList();
                                                                                        if (SourceStyle.Contains("|"))
                                                                                        {
                                                                                            if (SourceStyle.Split('|').ToList().Any(x => x.ToLower() == xa4.Value.ToLower()))
                                                                                            {
                                                                                                //if (xa1.Value == SourceStyle)
                                                                                                //{
                                                                                                xa4.SetValue(TargetStyle);
                                                                                                break;
                                                                                                //}
                                                                                            }
                                                                                        }
                                                                                        else
                                                                                        {
                                                                                            if (xa4.Value.ToLower() == SourceStyle.ToLower())
                                                                                            {
                                                                                                xa4.SetValue(TargetStyle);
                                                                                                break;
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                }
                                                                            } // For Each
                                                                        }
                                                                    }
                                                                }

                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        } //For each
                                    }
                                }

                            }//if (xee.HasElements)
                        }
                    }

                    //root.InnerXml = xe.GetXmlNode().InnerXml;
                    //xd.InnerXml = root.InnerXml;
                    xd.FirstChild.FirstChild.InnerXml = ((System.Xml.XmlDocument)(xe.GetXmlNode())).DocumentElement.InnerXml;
                    //xd.ReplaceChild(((System.Xml.XmlDocument)(xe.GetXmlNode())).DocumentElement, xd.FirstChild.FirstChild);
                }
                wDoc.MainDocumentPart.PutXDocument(xd.GetXDocument());
            } // End of Word Processing
        }


        private static void ExecuteStyleMappingOld(string newDoc, string StyleMappingConfig)
        {
            // Read the StyleMappingConfing and store the values in array //
            List<string> strStyleMapping = new List<string>();

            strStyleMapping = GlobalMethods.ReadAndStoreFileValuesInArray(StyleMappingConfig);

            string SourceStyle = null;
            string TargetStyle = null;

            using (WordprocessingDocument wDoc = WordprocessingDocument.Open(newDoc, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    //RemoveComments = false,
                    RemoveContentControls = true,
                    RemoveEndAndFootNotes = false,
                    //RemoveFieldCodes = false,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = false,
                };

                MarkupSimplifier.SimplifyMarkup(wDoc, settings);

                var xDoc = wDoc.MainDocumentPart.GetXDocument();

                XmlDocument xd = xDoc.GetXmlDocument();

                xd.LoadXml(xd.InnerXml);

                XmlNodeList nodeList;


                XmlNamespaceManager ns = new XmlNamespaceManager(xd.NameTable);
                ns.AddNamespace("w", "http://schemas.openxmlformats.org/wordprocessingml/2006/main");

                XmlNode root = xd.DocumentElement;
                nodeList = root.SelectNodes("w:body[w:p/w:pPr]", ns);

                XElement xe;
                foreach (XmlNode book in nodeList)
                {
                    xe = book.GetXElement();

                    if (xe.HasElements)
                    {
                        foreach (XElement xee in xe.Elements())
                        {
                            if (xee.HasElements)
                            {
                                // Check if the paragraph has style element
                                if (CheckIfTheParaHasChildElement(xee) == false)
                                {
                                    // Create new Style element with Normal style

                                    foreach (string strStyle in strStyleMapping)
                                    {
                                        if (strStyle != null)
                                        {
                                            SourceStyle = null;
                                            TargetStyle = null;
                                            string[] t = strStyle.Split('|');

                                            if (t.Length > 0)
                                            {
                                                SourceStyle = t[0];
                                                TargetStyle = t[1];

                                                if (SourceStyle == "Normal")
                                                {
                                                    XNamespace w = @"http://schemas.openxmlformats.org/wordprocessingml/2006/main";
                                                    XElement style = new XElement(w + "pPr", "",
                                                        new XElement(w + "pStyle", new XAttribute(w + "val", TargetStyle)));
                                                    xee.AddFirst(style);
                                                }
                                            }
                                        }
                                    }
                                }
                                else
                                {
                                    if (xee.Name.LocalName == "tbl")
                                    {
                                        foreach (XElement xec in xee.Elements())
                                        {
                                            if (xec.HasElements)
                                            {
                                                foreach (XElement xec1 in xec.Elements())
                                                {
                                                    if (xec1.HasElements)
                                                    {
                                                        foreach (XElement xec2 in xec1.Elements())
                                                        {

                                                            if (xec2.Name.LocalName == "p")
                                                            {
                                                                foreach (XElement xec3 in xec2.Descendants())
                                                                {
                                                                    if (xec3.Name.LocalName == "pStyle")
                                                                    {
                                                                        foreach (XAttribute xa4 in xec3.Attributes())
                                                                        {
                                                                            if (xa4.Name == W.val)
                                                                            {
                                                                                foreach (string strStyle in strStyleMapping)
                                                                                {
                                                                                    if (strStyle != null)
                                                                                    {
                                                                                        SourceStyle = null;
                                                                                        TargetStyle = null;
                                                                                        string[] t = strStyle.Split('|');

                                                                                        if (t.Length > 0)
                                                                                        {
                                                                                            SourceStyle = t[0];
                                                                                            TargetStyle = t[1];

                                                                                            if (xa4.Value == SourceStyle)
                                                                                            {
                                                                                                xa4.SetValue(TargetStyle);
                                                                                                break;
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                } // For Each
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }

                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    else
                                    {
                                        foreach (XElement xec in xee.Elements())
                                        {
                                            if (xec.HasElements)
                                            {
                                                foreach (XElement xec1 in xec.Elements())
                                                {
                                                    if (xec1.Name.LocalName == "pStyle")
                                                    {
                                                        foreach (XAttribute xa1 in xec1.Attributes())
                                                        {
                                                            if (xa1.Name == W.val)
                                                            {
                                                                foreach (string strStyle in strStyleMapping)
                                                                {
                                                                    if (strStyle != null)
                                                                    {
                                                                        SourceStyle = null;
                                                                        TargetStyle = null;
                                                                        string[] t = strStyle.Split('|');

                                                                        if (t.Length > 0)
                                                                        {
                                                                            SourceStyle = t[0];
                                                                            TargetStyle = t[1];

                                                                            if (xa1.Value == SourceStyle)
                                                                            {
                                                                                xa1.SetValue(TargetStyle);
                                                                                break;
                                                                            }
                                                                        }
                                                                    }
                                                                } // For Each
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        } //For each
                                    }
                                }

                            }//if (xee.HasElements)
                        }
                    }

                    //root.InnerXml = xe.GetXmlNode().InnerXml;
                    //xd.InnerXml = root.InnerXml;
                    xd.FirstChild.FirstChild.InnerXml = ((System.Xml.XmlDocument)(xe.GetXmlNode())).DocumentElement.InnerXml;
                    //xd.ReplaceChild(((System.Xml.XmlDocument)(xe.GetXmlNode())).DocumentElement, xd.FirstChild.FirstChild);
                }
                wDoc.MainDocumentPart.PutXDocument(xd.GetXDocument());
            } // End of Word Processing
        }

        private static bool CheckIfTheParaHasChildElement(XElement xee)
        {
            //Developer name :Priyanka Vishwakarma,Date:01_10_2019,Requirement:Mapping style from Configuration file for table ,Integrated by:Vikas sir,
            if (xee.Name.LocalName == "tbl")
            {
                foreach (XElement xec in xee.Elements())
                {
                    if (xec.HasElements)
                    {
                        foreach (XElement xec1 in xec.Elements())
                        {
                            if (xec1.HasElements)
                            {
                                foreach (XElement xec2 in xec1.Elements())
                                {

                                    if (xec2.Name.LocalName == "p")
                                    {
                                        foreach (XElement xec3 in xec2.Descendants())
                                        {
                                            if (xec3.Name.LocalName == "pStyle")
                                            {
                                                return true;
                                            }
                                        }
                                    }

                                }
                            }
                        }
                    }
                }
            }
            //---------------End----------------------------------------------
            else
            {
                foreach (XElement xec in xee.Elements())
                {
                    if (xec.HasElements)
                    {
                        foreach (XElement xec1 in xec.Elements())
                        {
                            if (xec1.Name.LocalName == "pStyle")
                            {
                                return true;
                            }
                        }
                    }
                }
            }

            return false;
        }

        private static bool CheckParaTextAndApplyStyle(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    //NormalizeXml = true,
                    RemoveHyperlinks = false,
                    //RemoveComments = false,
                    RemoveContentControls = true,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = false,

                    RemoveEndAndFootNotes = false,
                    //RemoveFieldCodes = false,
                    AcceptRevisions = true,
                    RemoveBookmarks = true,
                    RemoveGoBackBookmark = true,
                    RemoveWebHidden = true,
                    RemoveMarkupForDocumentComparison = true,
                };

                MarkupSimplifier.SimplifyMarkup(WPD, settings);

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                bool bBreakRun = false;
                bool bFigCaptionStarts = false;
                bool FindFigcParaAfterReference = false;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && (P.ParagraphProperties.ParagraphStyleId.Val.Value == "H1" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "CT" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H2") && (P.InnerText.ToLower().Trim() == "references" || P.InnerText.ToLower().Replace(" ", "") == "furtherreading"))
                    {
                        FindFigcParaAfterReference = true;
                    }
                    if (FindFigcParaAfterReference)
                    {
                        if (P.HasChildren == true)
                        {
                            if (P.ParagraphProperties != null)
                            {
                                bool bListFound = false;
                                //foreach (ParagraphProperties Pr in P.Descendants<ParagraphProperties>().ToList())
                                //{
                                //    bListFound = false;
                                //    if (Pr.NumberingProperties != null)
                                //    {
                                //        bListFound = true;
                                //        P.ParagraphProperties.ParagraphStyleId.Val = "BullList";
                                //        break;
                                //    }
                                //}

                                if (bListFound == true)
                                {
                                    bListFound = false;
                                    continue;
                                }

                                if (P.ParagraphProperties.ParagraphStyleId != null)
                                {
                                    foreach (Run R in P.Descendants<Run>().ToList())
                                    {
                                        bBreakRun = false;

                                        var rstyle = "";

                                        if (R.RunProperties != null && R.RunProperties.RunStyle != null && R.RunProperties.RunStyle.Val != null)
                                        {
                                            rstyle = R.RunProperties.RunStyle.Val.Value;
                                        }

                                        int tcnt = 0;

                                        foreach (Text T in R.Descendants<Text>().ToList())
                                        {
                                            tcnt++;
                                            string strSearchRegEx = null;
                                            strSearchRegEx = null;
                                            var para = XElement.Parse(P.OuterXml);
                                            //// 28-1-2019 added by aarti for videoc start \\\\commented by aarti 07-02-2019
                                            //strSearchRegEx = @"^Video [0-9]+\.[0-9]+\-[0-9]+";
                                            //if (GlobalMethods.ValidateRegEx(T.Text, strSearchRegEx) == true)
                                            //{
                                            //    P.ParagraphProperties.ParagraphStyleId.Val = "VIDEOC";
                                            //    bFigCaptionStarts = true;
                                            //    goto NextPara;
                                            //}
                                            //strSearchRegEx = null;
                                            //strSearchRegEx = @"^Video [0-9]+\.[0-9]+";
                                            //if (GlobalMethods.ValidateRegEx(T.Text, strSearchRegEx) == true)
                                            //{
                                            //    P.ParagraphProperties.ParagraphStyleId.Val = "VIDEOC";
                                            //    bFigCaptionStarts = true;
                                            //    goto NextPara;
                                            //}
                                            //// 28-1-2019 added by aarti for videoc end \\\\commented by aarti 07-02-2019
                                            if (T.Text.ToLower().StartsWith("fig") && rstyle != "citefig")
                                            {
                                                P.ParagraphProperties.ParagraphStyleId.Val = "FIGC";
                                                bFigCaptionStarts = true;
                                                goto NextPara;
                                            }
                                           else if ((T.Text.ToLower().StartsWith("box")|| T.Text.ToLower().StartsWith("flowchart")) && rstyle != "citefig")
                                            {
                                                P.ParagraphProperties.ParagraphStyleId.Val = "FIGC";
                                                bFigCaptionStarts = true;
                                                goto NextPara;
                                            }
                                            else if (P.InnerText.ToLower().StartsWith("page_") && P.InnerText.ToLower().EndsWith(".eps"))  //Developer name :Priyanka Vishwakarma ,Date:05112019 ,Requirement:apply Figc paragraph style in  Protuguese file for image placement.
                                            {
                                                P.ParagraphProperties.ParagraphStyleId.Val = "FIGC";
                                                bFigCaptionStarts = true;
                                                goto NextPara;
                                            }
                                            //Developer name:Priyanka Vishwakarma ,Date:11_12_2019, Requirement:Apply FIGC Paragraph style for figure placement.
                                            else if (P.InnerText.ToLower().Replace("/", "").StartsWith("foto") && P.InnerText.ToLower().Replace("/", "").EndsWith(".eps"))
                                            {
                                                P.ParagraphProperties.ParagraphStyleId.Val = "FIGC";
                                                bFigCaptionStarts = true;
                                                goto NextPara;
                                            }
                                            //else if (T.Text.ToLower().StartsWith("video"))///added by aarti on 07-02-2019
                                            else if (P.InnerText.ToLower().StartsWith("video"))///added by aarti on 07-02-2019
                                            {
                                                P.ParagraphProperties.ParagraphStyleId.Val = "FIGC";
                                                bFigCaptionStarts = true;
                                                goto NextPara;
                                            }
                                            else if (P.InnerText.Trim().ToLower().StartsWith("exhibit "))//Developer Name:Priyanka Vishwakarma,Date:18-03-2021,Requirement:Add condition for apply BT paragraph style to exhibit caption.
                                            {
                                                P.ParagraphProperties.ParagraphStyleId.Val = "BT";
                                                goto NextPara;
                                            }
                                            else if (T.Text.ToLower().StartsWith("part ") && !GlobalMethods.checkValidStyle(para))
                                            {
                                                P.ParagraphProperties.ParagraphStyleId.Val = "PT";
                                            }
                                            else
                                            {
                                                strSearchRegEx = null;

                                                strSearchRegEx = @"^Video [0-9]+\.[0-9]+\-[0-9]+";
                                                if (GlobalMethods.ValidateRegEx(T.Text, strSearchRegEx) == true)
                                                {
                                                    // Apply list style //
                                                    //if (bFigCaptionStarts == true)
                                                    //    P.ParagraphProperties.ParagraphStyleId.Val = "FIGP";
                                                    //else
                                                    //    P.ParagraphProperties.ParagraphStyleId.Val = "lower-alpha-list";

                                                    P.ParagraphProperties.ParagraphStyleId.Val = "FIGC";

                                                    goto NextPara;

                                                }




                                                //if (T.Text.ToLower().StartsWith("") || T.Text.ToLower().StartsWith("•"))
                                                //{
                                                //    bFigCaptionStarts = false;
                                                //    T.Text = T.Text.Replace("", "");
                                                //    T.Text = T.Text.Replace("•", "");

                                                //    P.ParagraphProperties.ParagraphStyleId.Val = "BullList";
                                                //}
                                                else
                                                {
                                                    bFigCaptionStarts = false;
                                                }
                                            }


                                            //bFigCaptionStarts = false;
                                            bBreakRun = true;
                                            break;
                                        }

                                        if (bBreakRun == true)
                                            break;
                                    }
                                }
                            }
                        }
                        NextPara: { };
                    }
                    else if (P.InnerText.ToLower().StartsWith("page_") && P.InnerText.ToLower().EndsWith(".eps"))  ///Added on 14-09-2020 by vikas for portuguese job
                    {
                        P.ParagraphProperties.ParagraphStyleId.Val = "FIGC";
                    }
                }

                D.Save();
            }
            ApplyTextbasedStyle(newDoc);//////called on 07-05-2020 by vikas
            return true;
        }

        public static bool ApplyTextbasedStyle(string newDoc)
        {
            var cnfmApplied = false;
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {

                    if (P.HasChildren == true)
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if(P.ParagraphProperties!=null && P.ParagraphProperties.ParagraphStyleId!=null && P.ParagraphProperties.ParagraphStyleId.Val!=null && P.ParagraphProperties.ParagraphStyleId.Val.Value!=null && P.ParagraphProperties.ParagraphStyleId.Val.Value=="CN-FM")
                            {
                                cnfmApplied = true;
                            }
                            if ((P.InnerText.ToLower().StartsWith("figura") || P.InnerText.ToLower().StartsWith("fig") || P.InnerText.ToLower().StartsWith("feige") || P.InnerText.ToLower().StartsWith("abb.") || P.InnerText.ToLower().StartsWith("abbildung") || P.InnerText.ToLower().StartsWith("zahl")) && P.ParagraphProperties.ParagraphStyleId != null)/////For brazil project on 07-05-2020 by vikas
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val = "FIGC";
                                goto NextPara;
                            }
                            else if (P.InnerText.ToLower().Trim() != "tabelas" && (P.InnerText.ToLower().StartsWith("tabela") || P.InnerText.ToLower().StartsWith("quadro") || P.InnerText.ToLower().StartsWith("tabelle") || P.InnerText.ToLower().StartsWith("tabella")) && P.ParagraphProperties.ParagraphStyleId != null)/////For brazil project on 07-05-2020 by vikas
                            {
                                if (GlobalMethods.strClientName != "VTH")  //08-08-2020
                                {
                                    P.ParagraphProperties.ParagraphStyleId.Val = "TT";
                                }
                                goto NextPara;
                            }
                            else if (P.InnerText.ToLower().StartsWith("vídeo"))///added by vikas on 08-05-2020 for Brazil-project
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val = "FIGC";
                                goto NextPara;
                            }
                            else if ((P.InnerText.ToUpper().StartsWith("CAPÍTULO") || P.InnerText.ToLower().StartsWith("kapitel") || P.InnerText.ToLower().StartsWith("capitolo") || P.InnerText.ToLower().StartsWith("chapter")) && cnfmApplied == false && GlobalMethods.strOutputRequired.ToLower() != "epub") //Developer name:Priyanka vishwakarma,Date:19-08-2020,Requirement:Add condition for epub not apply CN-FM paragraph style
                            {
                                ////added by vikas on 26-05-2021 for not apply CN-FM if already applied
                                if (P.PreviousSibling<Paragraph>()!=null && P.PreviousSibling<Paragraph>().Count() > 0 && P.PreviousSibling<Paragraph>().ParagraphProperties != null && P.PreviousSibling<Paragraph>().ParagraphProperties.ParagraphStyleId != null && P.PreviousSibling<Paragraph>().ParagraphProperties.ParagraphStyleId.Val.Value == "CN-FM")
                                {
                                    cnfmApplied = true;
                                    continue;
                                }
                                P.ParagraphProperties.ParagraphStyleId.Val = "CN-FM";
                                cnfmApplied = true;

                            }
                            else if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != "H1" && P.ParagraphProperties.ParagraphStyleId.Val != "H2" && (P.InnerText.ToLower().StartsWith("box ") || P.InnerText.ToLower().StartsWith("caixa ") || P.InnerText.ToLower().StartsWith("scatola ")))///added by vikas on 08-05-2020 for Brazil-project P.ParagraphProperties.ParagraphStyleId for null check condition added on 15-07-2020
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val = "BT";
                                goto NextPara;
                            }
                            if (P.InnerText.Trim().ToLower().StartsWith("exhibit "))//Developer Name:Priyanka Vishwakarma,Date:18-03-2021,Requirement:Add condition for apply BT paragraph style to exhibit caption.
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val = "BT";
                                goto NextPara;
                            }
                        }
                    }
                    NextPara: { };

                }

                D.Save();
            }

            return true;
        }

        public static void CheckParacitationStyle(string newDoc)/////added for correct the citation and label strong style by vikas on 08-05-2020
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;


                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    var bciteFound = false;
                    if (P.HasChildren == true)
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null)
                            {
                                var runcnt = 0;
                                foreach (Run R in P.Descendants<Run>().ToList())
                                {
                                    runcnt++;
                                    var rstyle = "";

                                    if (R.RunProperties != null && R.RunProperties.RunStyle != null && R.RunProperties.RunStyle.Val != null)
                                    {
                                        rstyle = R.RunProperties.RunStyle.Val.Value;
                                        if (rstyle == "label-Strong" && runcnt == 1)
                                        {
                                            bciteFound = true;
                                        }
                                        else if (rstyle == "label-Strong" && runcnt > 1 && bciteFound == true)
                                        {
                                            R.RunProperties.RunStyle.Val.Value = "citefig";
                                        }
                                        if (P.InnerText.StartsWith("Tabela"))
                                        {
                                            if (rstyle == "citetbl" && runcnt == 1)
                                            {
                                                R.RunProperties.RunStyle.Val.Value = "label-Strong";
                                            }
                                        }
                                    }
                                }
                            }
                        }

                    }
                    NextPara: { };
                }
                D.Save();
            }
        }

        private static bool ConditionalStyleMapping(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    //NormalizeXml = true,
                    RemoveHyperlinks = false,
                    //RemoveComments = false,
                    RemoveContentControls = true,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = false,

                    RemoveEndAndFootNotes = false,
                    //RemoveFieldCodes = false,
                    AcceptRevisions = true,
                    RemoveBookmarks = true,
                    RemoveGoBackBookmark = true,
                    RemoveWebHidden = true,
                    RemoveMarkupForDocumentComparison = true,
                };

                MarkupSimplifier.SimplifyMarkup(WPD, settings);

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                bool bBreakRun = false;

                bool secLevel = false;
                string secLevelNum = null;
                int nsecLevelNum = 0;

                bool bPartInfoFound = false;
                Paragraph PrevPara = null;
                Run PrevRun = null;
                DocumentFormat.OpenXml.OpenXmlElement ox = null;
                bool bReferenceSection = false;


                bool bctapply = false;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P.InnerText.Contains("4. ACEI and ARBs are to be used with caution in unilateral cases and contraindicated in bilateral lesions"))
                    {

                    }
                    if (P.HasChildren == true)
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null)
                            {
                                //Added by Karan on 01-10-2018 Start
                                if (P.ParagraphProperties.ParagraphStyleId.Val == "FIGC")
                                {
                                    bReferenceSection = false;
                                    goto NextPara;
                                }
                                //Added by Karan on 01-10-2018 End

                                //// added by aarti 23-1-2019 start \\\commente by aarti 07-02-2019
                                //if (P.ParagraphProperties.ParagraphStyleId.Val == "VIDEOC")
                                //{
                                //    bReferenceSection = false;
                                //    goto NextPara;
                                //}
                                ////added by aarti 23-1-2019 end

                                if (P.ParagraphProperties.ParagraphStyleId.Val == "Ref-Start")
                                {
                                    bReferenceSection = true;
                                    goto NextPara;
                                }
                                if (P.ParagraphProperties.ParagraphStyleId.Val == "CN-FM")//Developer Name:Priyanka Vishwakarma,Date:23-03-2021,Requirement:Add condition for avoid to apply CT para style if already CT paragraph style present.
                                {
                                    bctapply = true;
                                    goto NextPara;
                                }

                                if (P.ParagraphProperties.ParagraphStyleId.Val == "REF" || (P.InnerText.ToLower().Trim() == "references" || P.InnerText.ToLower() == "reference" || P.InnerText.ToLower() == "further reading" || P.InnerText.ToLower() == "literaturverzeichnis" || P.InnerText.ToLower() == "bibliografia" || P.InnerText.ToUpper() == "REFERÊNCIAS" || P.InnerText.ToUpper() == "REFERÊNCIAS BIBLIOGRÁFICAS" || P.InnerText.ToUpper() == "BIBLIOGRÁFICAS" || P.InnerText.ToUpper().ToUpper() == "LEITURAS SUGERIDAS")) //added by vikas for german references Literaturverzeichnis on 18-06-2019 and for Ref1 style mark after this para))
                                {
                                    bReferenceSection = true;
                                    goto NextPara;
                                }
                                if(Regex.Replace(P.InnerText.ToLower().Trim(),@"^\<[A-Za-z0-9]+\>","").ToString() == "references" || Regex.Replace(P.InnerText.ToLower().Trim(), @"^\<[A-Za-z0-9]+\>", "").ToString() == "reference" || Regex.Replace(P.InnerText.ToLower().Trim(), @"^\<[A-Za-z0-9]+\>", "").ToString() == "further reading" || Regex.Replace(P.InnerText.ToLower().Trim(), @"^\<[A-Za-z0-9]+\>", "").ToString() == "literaturverzeichnis" || Regex.Replace(P.InnerText.ToLower().Trim(), @"^\<[A-Za-z0-9]+\>", "").ToString() == "bibliografia" || Regex.Replace(P.InnerText.ToUpper().Trim(), @"^\<[A-Za-z0-9]+\>", "").ToString() == "REFERÊNCIAS" || Regex.Replace(P.InnerText.ToUpper().Trim(), @"^\<[A-Za-z0-9]+\>", "").ToString() == "REFERÊNCIAS BIBLIOGRÁFICAS" || Regex.Replace(P.InnerText.ToUpper().Trim(), @"^\<[A-Za-z0-9]+\>", "").ToString() == "BIBLIOGRÁFICAS" || Regex.Replace(P.InnerText.ToUpper().Trim(), @"^\<[A-Za-z0-9]+\>", "").ToString() == "LEITURAS SUGERIDAS")
                                {
                                    bReferenceSection = true;
                                    goto NextPara;
                                }

                                if (P.ParagraphProperties.ParagraphStyleId.Val == "Ref-End")
                                {
                                    bReferenceSection = false;
                                    goto NextPara;
                                }

                                if (P.ParagraphProperties.ParagraphStyleId.Val == "REF1")
                                {
                                    //bReferenceSection = false;
                                    goto NextPara;
                                }
                                if ((P.ParagraphProperties.ParagraphStyleId.Val == "H1" || P.ParagraphProperties.ParagraphStyleId.Val == "BodyA" || P.ParagraphProperties.ParagraphStyleId.Val == "FTN" || P.ParagraphProperties.ParagraphStyleId.Val == "FIGC" || P.ParagraphProperties.ParagraphStyleId.Val == "TT") && GlobalMethods.strXMLOutputrequired.ToLower() == "false")  //Developer name :Priyanka Vishwakarma ,Date:30_09_2019,Requirement:Break REF1 Paragraph after at section . Integrated by:Vikas sir.
                                {
                                    bReferenceSection = false;
                                }
                                if ((P.ParagraphProperties.ParagraphStyleId.Val == "H1" || P.ParagraphProperties.ParagraphStyleId.Val == "FTN") && GlobalMethods.strXMLOutputrequired.ToLower() == "true") ////Added by vikas for xml output required only
                                {
                                    bReferenceSection = false;
                                }

                                if (bReferenceSection == true)
                                {
                                    P.ParagraphProperties.ParagraphStyleId.Val = "REF1";
                                    goto NextPara;
                                }



                                // Check if the current paragraph is section // 
                                // If yes then extract the section level number // 
                                if (P.ParagraphProperties.ParagraphStyleId.Val == "H1" || P.ParagraphProperties.ParagraphStyleId.Val == "H2"
                                || P.ParagraphProperties.ParagraphStyleId.Val == "H3" || P.ParagraphProperties.ParagraphStyleId.Val == "H4" ||
                                P.ParagraphProperties.ParagraphStyleId.Val == "H5")
                                {
                                    secLevel = false;

                                    secLevelNum = P.ParagraphProperties.ParagraphStyleId.Val;
                                    secLevelNum = secLevelNum.Replace("H", "");

                                    int n;
                                    bool isnumeric = int.TryParse(secLevelNum, out n);

                                    if (isnumeric)
                                    {
                                        secLevel = true;
                                        nsecLevelNum = n;

                                        // Need to check if next Section level is greater then available section then what has to be done //
                                    }

                                    //continue;
                                }

                                if (secLevel == true)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId.Val == "BodyA")
                                    {
                                        //Developer name:Priyanka vishwakarma ,Date:30_09_2019 ,requirement:apply BodyA paragraph to Figcitation for acadamic document ,Integrated by:Vikas sir
                                        var runstyle = P.Descendants().Where(x => x.LocalName == "rStyle").ToList();

                                        var citefig = false;

                                        if (runstyle.Count > 0)
                                        {
                                            citefig = runstyle.Any(k => k.GetAttributes().Any(l => l.Value == "citefig"));

                                        }
                                        //-----------------------End---------------
                                        // Check if the complete Paragraph is bold //
                                        if (CheckifCompleteParaIsBold(P.Descendants<Run>()) == true && citefig != true && GlobalMethods.strJobCategory.ToLower() != "frontmatter")   //Developer name:Priyanka vishwakarma ,Date:30_09_2019 ,requirement:apply BodyA paragraph to Figcitation for acadamic document ,Integrated by:Vikas sir////frontmatter condition added by vikas on 11-02-2021
                                        {
                                            int nStyleIndex = 0; // nsecLevelNum + 1;

                                            if (CheckifParaStartWithNumber(P.Descendants<Run>()))
                                            {
                                                nStyleIndex = nsecLevelNum;
                                            }
                                            else
                                            {
                                                nStyleIndex = nsecLevelNum + 1;
                                            }
                                            if (P.Parent != null && P.Parent.XName.LocalName == "tc")///if table text bold
                                            {
                                                P.ParagraphProperties.ParagraphStyleId.Val = "TCH";
                                            }
                                            else if (nStyleIndex == 1)
                                                P.ParagraphProperties.ParagraphStyleId.Val = "H1";
                                            else if (nStyleIndex == 2)
                                                P.ParagraphProperties.ParagraphStyleId.Val = "H2";
                                            else if (nStyleIndex == 3)
                                                P.ParagraphProperties.ParagraphStyleId.Val = "H3";
                                            else if (nStyleIndex == 4)
                                                P.ParagraphProperties.ParagraphStyleId.Val = "H4";
                                            else if (nStyleIndex == 5)
                                                P.ParagraphProperties.ParagraphStyleId.Val = "H5";
                                            else if (nStyleIndex == 6)
                                                P.ParagraphProperties.ParagraphStyleId.Val = "H6";
                                        }
                                        else if (P.Parent != null && P.Parent.XName.LocalName == "tc")///if table text not bold
                                        {
                                            P.ParagraphProperties.ParagraphStyleId.Val = "T-TXT";
                                        }
                                    }

                                }

                                bool bOneRound = false;

                                string strParaText = null;
                                strParaText = "";

                                foreach (Run R in P.Descendants<Run>().ToList())
                                {
                                    bBreakRun = false;

                                    //if (bPartInfoFound)
                                    //{
                                    //    if (PrevPara != null)
                                    //    {
                                    //        ox = R.CloneNode(true);
                                    //        R.Remove();
                                    //        //P.Remove();

                                    //        if (bOneRound == false)
                                    //        {
                                    //            Run r = new Run(new Text(": "));
                                    //            PrevPara.Append(r);
                                    //            bOneRound = true;
                                    //        }

                                    //        PrevPara.Append(ox);

                                    //        continue;
                                    //    }
                                    //}

                                    bPartInfoFound = false;

                                    bool bFirstT = false;

                                    foreach (Text T in R.Descendants<Text>().ToList())
                                    {
                                        strParaText += T.Text;

                                        if (P.ParagraphProperties.ParagraphStyleId.Val == "Ref-Start")
                                        {
                                            goto NextPara;
                                        }

                                        if (P.ParagraphProperties.ParagraphStyleId.Val == "Ref-End")
                                        {
                                            goto NextPara;
                                        }

                                        if (P.ParagraphProperties.ParagraphStyleId.Val == "REF1")
                                        {
                                            goto NextPara;
                                        }

                                        if (P.ParagraphProperties.ParagraphStyleId.Val == "H1" || P.ParagraphProperties.ParagraphStyleId.Val == "H2" ||
                                            P.ParagraphProperties.ParagraphStyleId.Val == "H3" || P.ParagraphProperties.ParagraphStyleId.Val == "H4" || P.ParagraphProperties.ParagraphStyleId.Val == "H5" ||
                                            P.ParagraphProperties.ParagraphStyleId.Val == "H6" && bFirstT == false)
                                        {
                                            //// This code will delete the Heading Numbers from the document //
                                            // This code is commented on 18 Dec as this is no longer required //
                                            // Heading number to be commented in the XML //

                                            // ============== Comment Start =================== //

                                            //bFirstT = true;

                                            //string strSearchRegEx = null;
                                            //strSearchRegEx = null;

                                            //strSearchRegEx = @"^[0-9]{1,}\.?[0-9]{1,}?\s";
                                            //if (GlobalMethods.ValidateRegEx(T.Text, strSearchRegEx) == true)
                                            //{
                                            //    string strRetVal = GlobalMethods.RegExSearch(strParaText, strSearchRegEx);

                                            //    if (T.Text.StartsWith(strRetVal.Trim()))
                                            //    {
                                            //        //T.Text = T.Text.Replace(strRetVal, "");
                                            //        goto NextPara;
                                            //    }
                                            //}

                                            //strSearchRegEx = @"^[0-9]{1,}\s";
                                            //if (GlobalMethods.ValidateRegEx(T.Text, strSearchRegEx) == true)
                                            //{
                                            //    string strRetVal = GlobalMethods.RegExSearch(strParaText, strSearchRegEx);

                                            //    if (T.Text.StartsWith(strRetVal.Trim()))
                                            //    {
                                            //        //T.Text = T.Text.Replace(strRetVal, "");
                                            //        goto NextPara;
                                            //    }
                                            //}

                                            // ==================== Comment End ========================= //

                                        }
                                    }

                                    if (strParaText.ToLower().StartsWith("part ") && (P.ParagraphProperties.ParagraphStyleId.Val != "PN" || P.ParagraphProperties.ParagraphStyleId.Val != "PT"))/////PN condition added by vikas on 26-03-2020
                                    {
                                        PrevRun = R;
                                        PrevPara = P;
                                        bPartInfoFound = true;
                                        goto NextPara;
                                    }

                                    if (GlobalMethods.AuthorInfo != null)
                                    {
                                        if (strParaText.Contains(GlobalMethods.AuthorInfo))
                                        {
                                            //P.ParagraphProperties.ParagraphStyleId.Val = "AU";
                                        }
                                    }

                                    if (GlobalMethods.BookTitle != null)
                                    {
                                        if (strParaText == GlobalMethods.BookTitle)
                                        {
                                            P.ParagraphProperties.ParagraphStyleId.Val = "CT";
                                        }
                                    }

                                    if (GlobalMethods.ChapterNumber != null)
                                    {
                                        try
                                        {
                                            if (strParaText.Trim() == Convert.ToInt32(GlobalMethods.ChapterNumber).ToString().Trim() && P.Parent != null && P.Parent.LocalName != W.tc.LocalName)
                                            {
                                                if (bctapply == false)
                                                {
                                                    if (P.PreviousSibling<Paragraph>()!=null && P.PreviousSibling<Paragraph>().Count()>0 && P.PreviousSibling<Paragraph>().ParagraphProperties.ParagraphStyleId.Val.Value != "CN-FM")///condition added by vikas on 26-05-2021
                                                        P.ParagraphProperties.ParagraphStyleId.Val = "CN-FM";

                                                    if (P.NextSibling<Paragraph>().ParagraphProperties.ParagraphStyleId.Val.Value != "CT")
                                                        P.NextSibling<Paragraph>().ParagraphProperties.ParagraphStyleId.Val = "CT";

                                                    if (P.NextSibling<Paragraph>().NextSibling<Paragraph>().ParagraphProperties.ParagraphStyleId.Val.Value != "AU")
                                                    {
                                                        int cnt = 0;
                                                        P.NextSibling<Paragraph>().NextSibling<Paragraph>().Descendants<Run>().ToList().ForEach(c =>
                                                        {
                                                            cnt++;
                                                            if (c.RunProperties != null && c.RunProperties.Bold != null && cnt == 1)/////if text is bold then it will mark AU
                                                            {
                                                                P.NextSibling<Paragraph>().NextSibling<Paragraph>().ParagraphProperties.ParagraphStyleId.Val = "AU";
                                                            }
                                                        });
                                                    }

                                                    bctapply = true;
                                                }


                                            }
                                        }
                                        catch (Exception e)
                                        {

                                        }
                                    }

                                    if (GlobalMethods.ChapterTitle != null)
                                    {
                                        if (strParaText == GlobalMethods.ChapterTitle)
                                        {
                                            P.ParagraphProperties.ParagraphStyleId.Val = "CT";
                                        }
                                    }

                                    if (GlobalMethods.BookSubTitle != null)
                                    {
                                        if (strParaText == GlobalMethods.BookSubTitle)
                                        {
                                            P.ParagraphProperties.ParagraphStyleId.Val = "CT";
                                        }
                                    }

                                    if (strParaText != null)
                                    {
                                        if (strParaText.ToLower() == "foreword")
                                        {
                                            P.ParagraphProperties.ParagraphStyleId.Val = "CT";
                                        }

                                        if (strParaText.ToLower() == "preface")
                                        {
                                            P.ParagraphProperties.ParagraphStyleId.Val = "CT";
                                        }

                                        if (strParaText.ToLower() == "acknowledgments")
                                        {
                                            P.ParagraphProperties.ParagraphStyleId.Val = "CT";
                                        }
                                        if (strParaText.ToUpper() == "PREFÁCIO")//////Brazil_project on 12-05-2020 by vikas
                                        {
                                            P.ParagraphProperties.ParagraphStyleId.Val = "H1";/////due to single frontmatter document which include all frontmatter content
                                        }

                                        if (strParaText.ToUpper() == "AGRADECIMENTOS")//////Brazil_project on 12-05-2020 by vikas
                                        {
                                            P.ParagraphProperties.ParagraphStyleId.Val = "H1";/////due to single frontmatter document which include all frontmatter content
                                        }
                                        if (strParaText.ToLower() == "contributors")
                                        {
                                            P.ParagraphProperties.ParagraphStyleId.Val = "CT";
                                        }

                                        if (strParaText.ToLower() == "abbreviations")
                                        {
                                            P.ParagraphProperties.ParagraphStyleId.Val = "CT";
                                        }

                                        if (strParaText.ToLower() == "appendix")
                                        {
                                            P.ParagraphProperties.ParagraphStyleId.Val = "CT";
                                        }

                                        if (strParaText == "Chapter " + GlobalMethods.ChapterNumber + ". " + GlobalMethods.ChapterTitle)
                                        {
                                                // break the Paragraph into two Paragraphs, Chapter Number & Chapter Title //
                                                Paragraph pp = new Paragraph(new ParagraphProperties());
                                            pp.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId();

                                            pp.ParagraphProperties.ParagraphStyleId.Val = "CN-FM";

                                            Run r = new Run(new Text(GlobalMethods.ChapterNumber));

                                            pp.Append(r);

                                            P.InsertBeforeSelf<Paragraph>(pp);

                                            // Remove Chapter Number from the Current Paragraph from the start of the paragraph //

                                            foreach (Text T in R.Descendants<Text>().ToList())
                                            {
                                                if (GlobalMethods.ChapterNumber != null)
                                                {
                                                    if (T.Text.StartsWith("Chapter " + GlobalMethods.ChapterNumber + "."))
                                                    {
                                                        T.Text = T.Text.Replace("Chapter ", "");
                                                        T.Text = T.Text.Replace(GlobalMethods.ChapterNumber + ". ", "");
                                                        break;
                                                    }
                                                }
                                            }
                                        }
                                    }

                                    if (bBreakRun == true)
                                        break;
                                }

                                if (bPartInfoFound == true)
                                {
                                    P.Remove();
                                }

                                bPartInfoFound = false;
                            }
                            else
                            {
                                if (bReferenceSection == true)
                                {
                                    // Since the paragraph style property does not exist then create the new and attach it to the paragraph //

                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId();
                                    P.ParagraphProperties.ParagraphStyleId.Val = "REF1";

                                    goto NextPara;
                                }
                            }
                        }
                    }
                    NextPara: { };
                }

                D.Save();
            }

            return true;
        }

        private static bool ConditionalStyleMappingCont(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    //NormalizeXml = true,
                    RemoveHyperlinks = false,
                    //RemoveComments = false,
                    RemoveContentControls = true,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = false,

                    RemoveEndAndFootNotes = false,
                    //RemoveFieldCodes = false,
                    AcceptRevisions = true,
                    RemoveBookmarks = true,
                    RemoveGoBackBookmark = true,
                    RemoveWebHidden = true,
                    RemoveMarkupForDocumentComparison = true,
                };

                MarkupSimplifier.SimplifyMarkup(WPD, settings);

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                string strParaText = null;
                bool bApplyFrontMatter = false;
                int nParaNumber = 0;
                bool bMoveChapterTitleUp = false;
                bool bAutInfoFound = false;

                DocumentFormat.OpenXml.OpenXmlElement ox = null;

                if (nBookTitleParaNumber > 0)
                {
                    bApplyFrontMatter = true;
                }


                if (nBookTitleParaNumber > nAuthorInfoParaNumber)
                {
                    bMoveChapterTitleUp = true;
                }

                Paragraph AuPara = null;


                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    nParaNumber++;

                    if (P.HasChildren == true)
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null)
                            {
                                strParaText = "";

                                foreach (Run R in P.Descendants<Run>().ToList())
                                {
                                    foreach (Text T in R.Descendants<Text>().ToList())
                                    {
                                        strParaText += T.Text;
                                    }
                                }

                                if (strParaText == null)
                                    goto NextPara;


                                if (bMoveChapterTitleUp == true)
                                {
                                    if (GlobalMethods.AuthorInfo != null)
                                    {
                                        if (strParaText.ToLower() == GlobalMethods.AuthorInfo.ToLower())
                                        {
                                            // Reset the flag to move Chapter title up //
                                            bMoveChapterTitleUp = false;

                                            // We will move Author info after chapter Title and Chapter Sub Title //
                                            AuPara = P;

                                            goto NextPara;
                                        }
                                    }
                                }

                                if (GlobalMethods.BookTitle != null)
                                {
                                    if (strParaText.ToLower() == GlobalMethods.BookTitle.ToLower())
                                    {
                                        // We will move Author info after chapter Title and Chapter Sub Title //

                                        if (AuPara != null)
                                        {
                                            ox = P.CloneNode(true);
                                            P.Remove();
                                            AuPara.InsertBeforeSelf(ox);
                                            goto NextPara;
                                        }
                                    }
                                }

                                if (GlobalMethods.BookSubTitle != null)
                                {
                                    if (strParaText.ToLower() == GlobalMethods.BookSubTitle.ToLower())
                                    {
                                        // We will move Author info after chapter Title and Chapter Sub Title //

                                        if (AuPara != null)
                                        {
                                            ox = P.CloneNode(true);
                                            P.Remove();
                                            AuPara.InsertBeforeSelf(ox);

                                            AuPara = null;

                                            goto NextPara;
                                        }
                                    }
                                }


                                if (nParaNumber == 1)
                                {
                                    if (strParaText.ToLower() != "frontmatter" && bApplyFrontMatter == true && GlobalMethods.strServiceType != "Content")
                                    {
                                        // Insert new Para and add Front Matter text to it //

                                        Paragraph pp = new Paragraph(new ParagraphProperties());
                                        pp.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId();

                                        pp.ParagraphProperties.ParagraphStyleId.Val = "PT";

                                        Run r = new Run(new Text("Frontmatter"));

                                        pp.Append(r);

                                        P.InsertBeforeSelf<Paragraph>(pp);

                                        goto NextPara;
                                    }
                                }
                            }
                            else
                            {
                                // In this block Paragraph style is not applied and hence need to create new para style before applying any para style //
                                // Para properties exist only need to create new style property //

                                strParaText = "";

                                foreach (Run R in P.Descendants<Run>().ToList())
                                {
                                    foreach (Text T in R.Descendants<Text>().ToList())
                                    {
                                        strParaText += T.Text;

                                    }
                                }

                                if (nParaNumber == 1)
                                {
                                    if (strParaText.ToLower() != "frontmatter" && bApplyFrontMatter == true)
                                    {
                                        // Insert new Para and add Front Matter text to it //

                                        Paragraph pp = new Paragraph(new ParagraphProperties());
                                        pp.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId();

                                        pp.ParagraphProperties.ParagraphStyleId.Val = "PT";

                                        Run r = new Run(new Text("Frontmatter"));

                                        pp.Append(r);

                                        P.InsertBeforeSelf<Paragraph>(pp);

                                        goto NextPara;
                                    }
                                }
                            }
                        }
                    }
                    NextPara: { };
                }

                D.Save();
            }

            return true;
        }

        private static int CheckIfTheParaTextInTheDocument(string newDoc, string strLookupText)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    //NormalizeXml = true,
                    RemoveHyperlinks = false,
                    //RemoveComments = false,
                    RemoveContentControls = true,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = false,

                    RemoveEndAndFootNotes = false,
                    //RemoveFieldCodes = false,
                    AcceptRevisions = true,
                    RemoveBookmarks = true,
                    RemoveGoBackBookmark = true,
                    RemoveWebHidden = true,
                    RemoveMarkupForDocumentComparison = true,
                };

                MarkupSimplifier.SimplifyMarkup(WPD, settings);

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                string strParaText = null;
                int nParaIndex = 0;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    nParaIndex++;

                    if (P.HasChildren == true)
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null)
                            {
                                strParaText = "";

                                foreach (Run R in P.Descendants<Run>().ToList())
                                {
                                    foreach (Text T in R.Descendants<Text>().ToList())
                                    {
                                        strParaText += T.Text;
                                    }
                                }

                                if (strParaText == strLookupText)
                                {
                                    return nParaIndex;
                                }
                            }
                            else
                            {
                                // In this block Paragraph style is not applied and hence need to create new para style before applying any para style //
                                // Para properties exist only need to create new style property //

                                strParaText = "";

                                foreach (Run R in P.Descendants<Run>().ToList())
                                {
                                    foreach (Text T in R.Descendants<Text>().ToList())
                                    {
                                        strParaText += T.Text;
                                    }
                                }

                                if (strParaText == strLookupText)
                                {
                                    return nParaIndex;
                                }
                            }
                        }
                    }
                }
            }

            return 0;
        }

        private static bool CheckifParaStartWithNumber(IEnumerable<Run> RunColl)
        {
            foreach (Run R in RunColl.ToList())
            {
                string strParaText = null;

                if (R.HasChildren == true)
                {
                    foreach (Text T in R.Descendants<Text>().ToList())
                    {
                        strParaText += T.Text;

                        string strSearchRegEx = null;
                        strSearchRegEx = null;

                        strSearchRegEx = @"^[0-9]{1,}\.?[0-9]{1,}?\s";
                        if (GlobalMethods.ValidateRegEx(strParaText, strSearchRegEx) == true)
                        {
                            string strRetVal = GlobalMethods.RegExSearch(strParaText, strSearchRegEx);

                            if (T.Text.StartsWith(strRetVal.Trim()))
                            {
                                return true;
                            }
                        }

                        strSearchRegEx = @"^[0-9]{1,}\s";
                        if (GlobalMethods.ValidateRegEx(strParaText, strSearchRegEx) == true)
                        {
                            string strRetVal = GlobalMethods.RegExSearch(strParaText, strSearchRegEx);

                            if (T.Text.StartsWith(strRetVal.Trim()))
                            {
                                return true;
                            }
                        }
                    }
                }
            }

            return false;
        }

        private static bool CheckifCompleteParaIsBold(IEnumerable<Run> RunColl)
        {
            bool bcompleteParaIsBold = false;

            foreach (Run R in RunColl.ToList())
            {
                if (R.HasChildren == true)
                {
                    if (R.RunProperties != null)
                    {
                        if (R.RunProperties.Bold != null)
                        {
                            bcompleteParaIsBold = true;
                        }
                        else
                        {
                            bcompleteParaIsBold = false;
                            return false;
                        }
                    }
                    else
                    {
                        bcompleteParaIsBold = false;
                        return false;
                    }
                }
                else
                {
                    bcompleteParaIsBold = false;
                    return false;
                }
            }

            if (bcompleteParaIsBold)
                return true;

            return false;
        }
        private static bool CheckifCompleteParaIsBoldandItalic(IEnumerable<Run> RunColl)
        {
            bool bcompleteParaIsBoldItalic = false;

            foreach (Run R in RunColl.ToList())
            {
                if (R.HasChildren == true)
                {
                    if (R.RunProperties != null)
                    {
                        if (R.RunProperties.Bold != null && R.RunProperties.Italic != null)  //19-10-2020
                        {
                            bcompleteParaIsBoldItalic = true;
                        }

                        else
                        {
                            bcompleteParaIsBoldItalic = false;
                            return false;
                        }
                    }
                    else
                    {
                        bcompleteParaIsBoldItalic = false;
                        return false;
                    }
                }
                else
                {
                    bcompleteParaIsBoldItalic = false;
                    return false;
                }
            }

            if (bcompleteParaIsBoldItalic)
                return true;

            return false;
        }
        private static bool CheckifCompleteParaIsItalic(IEnumerable<Run> RunColl)
        {
            bool bcompleteParaIsItalic = false;

            foreach (Run R in RunColl.ToList())
            {
                if (R.HasChildren == true)
                {
                    if (R.RunProperties != null)
                    {
                        if (R.RunProperties.Italic != null)
                        {
                            bcompleteParaIsItalic = true;
                        }
                        else
                        {
                            bcompleteParaIsItalic = false;
                            return false;
                        }
                    }
                    else
                    {
                        bcompleteParaIsItalic = false;
                        return false;
                    }
                }
                else
                {
                    bcompleteParaIsItalic = false;
                    return false;
                }
            }

            if (bcompleteParaIsItalic)
                return true;

            return false;
        }

        private static void CreateFigParaAfterFigCaption(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    //NormalizeXml = true,
                    RemoveHyperlinks = false,
                    //RemoveComments = false,
                    RemoveContentControls = true,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = false,

                    RemoveEndAndFootNotes = false,
                    //RemoveFieldCodes = false,
                    AcceptRevisions = true,
                    RemoveBookmarks = true,
                    RemoveGoBackBookmark = true,
                    RemoveWebHidden = true,
                    RemoveMarkupForDocumentComparison = true,
                };

                MarkupSimplifier.SimplifyMarkup(WPD, settings);

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P.HasChildren == true)
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId.Val == "FIGC")//commentd by aarti 07-02-2019 /*|| P.ParagraphProperties.ParagraphStyleId.Val == "VIDEOC"*/ // ADDED BY AARTI 23-1-2019 P.ParagraphProperties.ParagraphStyleId.Val == "VIDEOC" condition
                                {
                                    //Paragraph pp = new Paragraph(new ParagraphProperties());
                                    //pp.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId();

                                    //pp.ParagraphProperties.ParagraphStyleId.Val = "FIG";

                                    //P.InsertAfterSelf<Paragraph>(pp);

                                    continue;
                                }
                            }
                        }
                    }
                }

                D.Save();
            }
        }

        public static void Removecolor(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                                               .Open(newDoc, true))
            {
                var eleAllRprofHighlight = WPD.MainDocumentPart.Document.Body.Descendants<Highlight>().ToList();

                foreach (var i in eleAllRprofHighlight)
                {
                    if (i.Val != null)
                    {
                        i.Remove();
                    }
                }
            }
        }

        public static void ListStyleApply(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                                               .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                string strUpparAlpha = null;
                string strLowerAlpha = null;
                string strNum = null;
                string strStar = null;
                string strDash = null;
                string strRoman = null;
                string strBull1 = null;
                string strBull2 = null;
                string strBull3 = null;
                string strBull4 = null;
                string strBull5 = null;
                string strBull6 = null;
                string strBull7 = null;
                string strBull8 = null;
                string strBull9 = null;
                string strBull10 = null;
                string strNumWithBracket = null;
                string strNumWithBracketDot = null;
                string strNumWithoutSpace = null;
                string strAlphaNum = null;
                string strSquare = null;

                string strRomanWithtDot = null;//05-02-2020
                string strBull11 = null;//04-02-2020
                string strBull12 = null;//04-02-2020
                string strBull13 = null;//04-02-2020
                string strBull14 = null;//04-02-2020
                string strBull15 = null;//04-02-2020
                string strBull16 = null;//04-02-2020
                string strBull17 = null;//04-02-2020
                string strBull18 = null;//04-02-2020
                string strBull19 = null;//04-02-2020
                string strBull20 = null;//04-02-2020


                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P != null && P.InnerText.Trim() != null)
                    {
                        SymbolToText(P);

                        string gettxt = P.InnerText;


                        strRoman = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt.TrimStart(), @"^\(?\[?\{?([ivxIVX]{1,})[\.\}\)\]]{1,2}\s"); //////New pattern added for roman numerals 09/12/2017

                        strUpparAlpha = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt.TrimStart(), @"^\(?\[?\{?([A-Z]{1,2})[\.|)\}\)\]]{1,2}\s");
                        strLowerAlpha = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt.TrimStart(), @"^\(?\[?\{?([a-z]{1,2})[\.|)\}\)\]]{1,2}\s");

                        strNum = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt, @"^[0-9]{1,2}\.\s");/// new patten added by manish for number with dot 16-12-2017
                        strStar = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt, @"^[*]{1,}\s?");
                        strDash = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt.TrimStart(), @"^[-|–]{1,}\s?");
                        strNumWithBracket = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt, @"^\(?\[?\{?[0-9]{1,2}\.\}?\)?\]?\s");
                        // strNumWithBracketDot = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt, @"^\(?\[?\{?[0-9]{1,2}\.[0-9]{1,2}\.?\}?\)?\]?\s");
                        //strNumWithoutSpace = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt, @"^[0-9]{1,2}\.?\s?");
                        //strAlphaNum = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt, @"^\(?\[?\{?([a-zA-Z\.]{1,2})\}?\]?\)?\(?\[?\{?([0-9\.]{1,2})\}?\]?\)?\s");
                        strBull1 = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt.TrimStart(), @"^[•]{1,}\s?");
                        strBull2 = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt.TrimStart(), @"^[●]{1,}\s?");
                        strBull3 = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt.TrimStart(), @"^[■]{1,}\s?");
                        strBull4 = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt.TrimStart(), @"^[▪]{1,}\s?");
                        strBull5 = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt, @"^[†]{1,}\s");
                        strBull6 = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt, @"^[#]{1,}\s");
                        strBull7 = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt, @"^[]{1,}\s");
                        strBull8 = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt, @"^[+]{1,}\s");
                        strBull9 = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt, @"^[\^]{1,}\s");
                        //strBull10 = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt, @"^[o]{1,}\s");  //03102019
                        strBull10 = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt.TrimStart(), @"^[o|○]{1,}\s?");  //03102019
                        if (strBull10 != null && !checklistisCircleList(P, strBull10))////Check is actually circle list or o text added by vikas on 15-07-2020
                        {
                            strBull10 = null;
                        }

                        strBull11 = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt, @"^[❖]{1,}\s?");//04-02-2020 Added by ashwini for BlackDiomandMinusWhiteXList
                        strBull12 = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt.TrimStart(), @"^[◇]{1,}");//04-02-2020 Added by ashwini for EmptyDiamondList                      
                        strBull13 = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt.TrimStart(), @"^[◊]{1,}\s?");//04-02-2020 Added by ashwini for EmptyDiamondList
                        strBull14 = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt, @"^[]{1,}\s?");//04-02-2020 Added by ashwini for EmptyDiamondList
                        strBull15 = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt.TrimStart(), @"^[◆|]{1,}");//04-02-2020 Added by ashwini for SolidDiamondList
                        strBull16 = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt.TrimStart(), @"^[♦]{1,}\s?");//04-02-2020 Added by ashwini for SolidDiamondList
                        strBull17 = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt.TrimStart(), @"^[•]{1,}\s?");//04-02-2020 Added by ashwini for SolidDiamondList
                        //strBull18 = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt, @"^[A-Z]{1}\s");//04-02-2020 Added by ashwini AlphaUpparList
                        //strBull19 = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt, @"^[a-z]{1}\s");//04-02-2020  Added by ashwini for AlphaLowerList

                        //strBull20 = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt, @"^[0-9]{1}\s");

                        //strRomanWithtDot = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt.TrimStart(), @"^[ivxIVX]{1,4}\s"); //05-02-2020\\commented by vikas on 08-02-2021

                        strSquare = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt.TrimStart(), @"^[□]{1,}\s?");


                        if (strLowerAlpha == null)
                        {
                            strLowerAlpha = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt.TrimStart(), @"^\(?\[?\{?([a-z]{1,2})[)|\.\}\)\]]{1,2}");//////only for e.g. a)text any
                        }
                        if (strRoman == null)
                        {
                            strRoman = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt.TrimStart(), @"^\(?\[?\{?([ivxIVX]{1,})[\.\}\)\]]{1,2}"); //////New pattern added for roman numerals 01/05/2020
                        }
                        if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && (P.ParagraphProperties.ParagraphStyleId.Val.Value != "H1" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "H2" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "H3" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "H4" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "H5" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "H6" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "H7" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "CT"))
                        {
                            if (strRoman != null || strRomanWithtDot != null)
                            {
                                if (P.ParagraphProperties != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val.Value != "FTN" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "TFN")
                                    {
                                        var styleid = P.ParagraphProperties.ParagraphStyleId.Val.Value;

                                        P.ParagraphProperties.ParagraphStyleId.Val.Value = "RomanList";

                                        ExtractStylesPart(WPD, P, styleid);

                                    }
                                }
                            }
                            else if (strUpparAlpha != null || strBull18 != null)
                            {
                                if (P.ParagraphProperties != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val != "AU" && P.ParagraphProperties.ParagraphStyleId.Val != "SummaryPara" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "FTN" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "TFN" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "Author" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "AU")// 29-1-2019added by aarti for AU && P.ParagraphProperties.ParagraphStyleId.Val !="AU" condition
                                    {
                                        var styleid = P.ParagraphProperties.ParagraphStyleId.Val.Value;

                                        P.ParagraphProperties.ParagraphStyleId.Val.Value = "AlphaUpparList";

                                        ExtractStylesPart(WPD, P, styleid);
                                    }
                                }

                            }
                            else if (strBull11 != null)//04-02-2020 Added by ashwini for BlackDiomandMinusWhiteXList intigrated by vikas sir
                            {
                                if (P.ParagraphProperties != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val != "AU" && P.ParagraphProperties.ParagraphStyleId.Val != "SummaryPara")// 29-1-2019added by aarti for AU && P.ParagraphProperties.ParagraphStyleId.Val !="AU" condition
                                    {
                                        var styleid = P.ParagraphProperties.ParagraphStyleId.Val.Value;

                                        P.ParagraphProperties.ParagraphStyleId.Val.Value = "BlackDiomandMinusWhiteXList";

                                        ExtractStylesPart(WPD, P, styleid);
                                    }
                                }
                            }
                            else if (strBull12 != null || strBull13 != null || strBull14 != null)//04-02-2020 Added by ashwini for EmptyDiamondList intigrated by vikas sir
                            {
                                if (P.ParagraphProperties != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val != "AU" && P.ParagraphProperties.ParagraphStyleId.Val != "SummaryPara")// 29-1-2019added by aarti for AU && P.ParagraphProperties.ParagraphStyleId.Val !="AU" condition
                                    {
                                        var styleid = P.ParagraphProperties.ParagraphStyleId.Val.Value;

                                        P.ParagraphProperties.ParagraphStyleId.Val.Value = "EmptyDiamondList";

                                        ExtractStylesPart(WPD, P, styleid);
                                    }
                                }
                            }
                            else if (strBull15 != null || strBull16 != null)//04-02-2020 Added by ashwini for SolidDiamondList intigrated by vikas sir
                            {
                                if (P.ParagraphProperties != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val != "AU" && P.ParagraphProperties.ParagraphStyleId.Val != "SummaryPara")// 29-1-2019added by aarti for AU && P.ParagraphProperties.ParagraphStyleId.Val !="AU" condition
                                    {
                                        var styleid = P.ParagraphProperties.ParagraphStyleId.Val.Value;

                                        P.ParagraphProperties.ParagraphStyleId.Val.Value = "SolidDiamondList";

                                        ExtractStylesPart(WPD, P, styleid);
                                    }
                                }
                            }
                            else if (strLowerAlpha != null || strBull19 != null)
                            {
                                if (P.ParagraphProperties != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val.Value != "FTN" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "TFN" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "Author" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "AU")
                                    {
                                        var styleid = P.ParagraphProperties.ParagraphStyleId.Val.Value;

                                        P.ParagraphProperties.ParagraphStyleId.Val.Value = "AlphaLowerList";

                                        ExtractStylesPart(WPD, P, styleid);
                                    }
                                }
                            }
                            else if (strNum != null)
                            {
                                if (P.ParagraphProperties != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val.Value != "CN-FM" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "BoxCTONumList" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "H1" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "TCH" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "REF1" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "FTN" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "TFN")
                                    {
                                        var styleid = P.ParagraphProperties.ParagraphStyleId.Val.Value;
                                        if (P.InnerText.Replace(strNum, "").Trim() != "")//////added by vikas for only number is there not apply numlist style on para on 15-04-2020
                                            P.ParagraphProperties.ParagraphStyleId.Val.Value = "NumList";

                                        ExtractStylesPart(WPD, P, styleid);
                                    }
                                }
                            }
                            else if (strNumWithBracket != null)
                            {
                                if (P.ParagraphProperties != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val.Value != "TFN" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "CN-FM" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "BoxCTONumList" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "TCH" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "REF1" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "FTN" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "TFN")
                                    {
                                        var styleid = P.ParagraphProperties.ParagraphStyleId.Val.Value;
                                        P.ParagraphProperties.ParagraphStyleId.Val.Value = "NumList";

                                        ExtractStylesPart(WPD, P, styleid);
                                    }
                                }
                            }
                            else if (strNumWithBracketDot != null)
                            {
                                if (P.ParagraphProperties != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val.Value != "CN-FM" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "BoxCTONumList" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "TCH" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "REF1" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "FTN" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "TFN")
                                    {
                                        var styleid = P.ParagraphProperties.ParagraphStyleId.Val.Value;
                                        P.ParagraphProperties.ParagraphStyleId.Val.Value = "NumList";

                                        ExtractStylesPart(WPD, P, styleid); P.ParagraphProperties.ParagraphStyleId.Val.Value = "NumList";
                                    }
                                }
                            }
                            else if (strNumWithoutSpace != null)
                            {
                                if (P.ParagraphProperties != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val != "CT" && P.ParagraphProperties.ParagraphStyleId.Val != "H1" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "CN-FM" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "BoxCTONumList" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "H2" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "TCH" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "REF1" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "FTN" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "TFN")//Developer name :Priyanka Vishwakarma .Date:03_10_2019 ,Requirement:avoid to apply list style to h2 paragraph,Integrated by:Vikas sir.///ct condtion added by aarti on 26-02-2019
                                    {
                                        var styleid = P.ParagraphProperties.ParagraphStyleId.Val.Value;

                                        if (P.InnerText.Replace(strNumWithoutSpace, "").Trim() != "")//////added by vikas for only number is there not apply numlist style on para on 15-04-2020
                                            P.ParagraphProperties.ParagraphStyleId.Val.Value = "NumList";

                                        ExtractStylesPart(WPD, P, styleid);

                                    }
                                }
                            }
                            else if (strAlphaNum != null)
                            {
                                if (P.ParagraphProperties != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val != "REF1" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "FTN" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "TFN")   //Developer name:Priyanka vishwakarma ,Date:30_09_2019 ,requirement:Avoid to apply listing to REF1 paragraph. ,Integrated by:Vikas sir
                                    {
                                        var styleid = P.ParagraphProperties.ParagraphStyleId.Val.Value;

                                        P.ParagraphProperties.ParagraphStyleId.Val.Value = "AlphaList";

                                        ExtractStylesPart(WPD, P, styleid);
                                    }
                                }
                            }
                            else if (strStar != null)
                            {
                                if (P.ParagraphProperties != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val.Value != "FTN" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "TFN")
                                    {

                                        var styleid = P.ParagraphProperties.ParagraphStyleId.Val.Value;

                                        P.ParagraphProperties.ParagraphStyleId.Val.Value = "StarList";

                                        ExtractStylesPart(WPD, P, styleid);
                                    }
                                }
                            }
                            else if (strDash != null)
                            {
                                if (P.ParagraphProperties != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val != "Quote" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "FTN" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "TFN")
                                    {
                                        var styleid = P.ParagraphProperties.ParagraphStyleId.Val.Value;

                                        P.ParagraphProperties.ParagraphStyleId.Val.Value = "DashList";

                                        ExtractStylesPart(WPD, P, styleid);
                                    }
                                }
                            }
                            else if (strBull1 != null)
                            {
                                if (P.ParagraphProperties != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                                    {

                                        var styleid = P.ParagraphProperties.ParagraphStyleId.Val.Value;

                                        P.ParagraphProperties.ParagraphStyleId.Val.Value = "SmallBullList";

                                        ExtractStylesPart(WPD, P, styleid);
                                    }
                                }
                            }
                            else if (strBull2 != null)
                            {
                                if (P.ParagraphProperties != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                                    {

                                        var styleid = P.ParagraphProperties.ParagraphStyleId.Val.Value;

                                        P.ParagraphProperties.ParagraphStyleId.Val.Value = "LargeBullList";

                                        ExtractStylesPart(WPD, P, styleid);
                                    }
                                }
                            }
                            else if (strBull3 != null)
                            {
                                if (P.ParagraphProperties != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                                    {
                                        var styleid = P.ParagraphProperties.ParagraphStyleId.Val.Value;

                                        P.ParagraphProperties.ParagraphStyleId.Val.Value = "LargeSquareList";

                                        ExtractStylesPart(WPD, P, styleid);
                                    }
                                }
                            }
                            else if (strBull4 != null)
                            {
                                if (P.ParagraphProperties != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                                    {
                                        var styleid = P.ParagraphProperties.ParagraphStyleId.Val.Value;

                                        P.ParagraphProperties.ParagraphStyleId.Val.Value = "SmallSquareList";

                                        ExtractStylesPart(WPD, P, styleid);
                                    }
                                }
                            }
                            else if (strBull5 != null)
                            {
                                if (P.ParagraphProperties != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                                    {
                                        var styleid = P.ParagraphProperties.ParagraphStyleId.Val.Value;

                                        P.ParagraphProperties.ParagraphStyleId.Val.Value = "BullList";

                                        ExtractStylesPart(WPD, P, styleid);
                                    }
                                }
                            }
                            else if (strBull6 != null)
                            {
                                if (P.ParagraphProperties != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                                    {
                                        var styleid = P.ParagraphProperties.ParagraphStyleId.Val.Value;

                                        P.ParagraphProperties.ParagraphStyleId.Val.Value = "BullList";

                                        ExtractStylesPart(WPD, P, styleid);
                                    }
                                }
                            }
                            else if (strBull7 != null)
                            {
                                if (P.ParagraphProperties != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                                    {
                                        var styleid = P.ParagraphProperties.ParagraphStyleId.Val.Value;

                                        P.ParagraphProperties.ParagraphStyleId.Val.Value = "BullList";

                                        ExtractStylesPart(WPD, P, styleid);
                                    }
                                }
                            }
                            else if (strBull8 != null)
                            {
                                if (P.ParagraphProperties != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                                    {
                                        var styleid = P.ParagraphProperties.ParagraphStyleId.Val.Value;

                                        P.ParagraphProperties.ParagraphStyleId.Val.Value = "BullList";

                                        ExtractStylesPart(WPD, P, styleid);
                                    }
                                }
                            }
                            else if (strBull9 != null)
                            {
                                if (P.ParagraphProperties != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                                    {
                                        var styleid = P.ParagraphProperties.ParagraphStyleId.Val.Value;

                                        P.ParagraphProperties.ParagraphStyleId.Val.Value = "BullList";

                                        ExtractStylesPart(WPD, P, styleid);
                                    }
                                }
                            }
                            else if (strBull10 != null)
                            {
                                if (P.ParagraphProperties != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                                    {
                                        var styleid = P.ParagraphProperties.ParagraphStyleId.Val.Value;

                                        P.ParagraphProperties.ParagraphStyleId.Val.Value = "CircList";

                                        ExtractStylesPart(WPD, P, styleid);
                                    }
                                }
                            }
                            else if (strSquare != null)
                            {
                                if (P.ParagraphProperties != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                                    {
                                        var styleid = P.ParagraphProperties.ParagraphStyleId.Val.Value;

                                        P.ParagraphProperties.ParagraphStyleId.Val.Value = "EmptySquareList";

                                        ExtractStylesPart(WPD, P, styleid);
                                    }
                                }
                            }

                            //if (P.InnerText.Trim().StartsWith("●") || P.InnerText.Trim().StartsWith("•"))
                            //{
                            //    if(P.ParagraphProperties != null)
                            //    {
                            //        if(P.ParagraphProperties.ParagraphStyleId.Val != null)
                            //        {
                            //            P.ParagraphProperties.ParagraphStyleId.Val.Value = "BullList";
                            //        }
                            //    }
                            //    //BullList
                            //}
                            //else if(P.InnerText.Trim().StartsWith("–"))
                            //{
                            //    if (P.ParagraphProperties != null)
                            //    {
                            //        if (P.ParagraphProperties.ParagraphStyleId.Val != null)
                            //        {
                            //            P.ParagraphProperties.ParagraphStyleId.Val.Value = "DashList";
                            //        }
                            //    }
                            //    //DashList
                            //}
                            //else if (P.InnerText.TrimStart().StartsWith("o "))
                            //{
                            //    if (P.ParagraphProperties != null)
                            //    {
                            //        if (P.ParagraphProperties.ParagraphStyleId.Val != null)
                            //        {
                            //            P.ParagraphProperties.ParagraphStyleId.Val.Value = "CircList";
                            //        }
                            //    }
                            //    //CircList
                            //}
                            //else if (P.InnerText.Trim().StartsWith("▪"))
                            //{
                            //    if (P.ParagraphProperties != null)
                            //    {
                            //        if (P.ParagraphProperties.ParagraphStyleId.Val != null)
                            //        {
                            //            P.ParagraphProperties.ParagraphStyleId.Val.Value = "SquareList";
                            //        }
                            //    }
                            //}
                            //else if (P.InnerText.Trim().StartsWith("□"))
                            //{
                            //    if (P.ParagraphProperties != null)
                            //    {
                            //        if (P.ParagraphProperties.ParagraphStyleId.Val != null)
                            //        {
                            //            P.ParagraphProperties.ParagraphStyleId.Val.Value = "EmptySquareList";
                            //        }
                            //    }
                            //}
                        }
                    }
                }
                D.Save();
            }
        }

        public static void SymbolToText(Paragraph P)
        {
            bool sym = false;////check symbol w:sym present before text node w:t
            foreach (var R in P.Descendants<Run>().ToList())
            {
                foreach (var ele in R.Elements().ToList())
                {
                    if (ele.LocalName == W.sym.LocalName)
                    {
                        sym = true;
                    }
                    if (ele.LocalName == W.t.LocalName)
                    {
                        goto next;
                    }
                }
                next: { }

                foreach (var ele in R.Elements().ToList())
                {
                    if (ele.LocalName == W.sym.LocalName && sym == true)
                    {
                        sym = false;

                        var charcode = ele.GetAttributes().Where(c => c.LocalName == "char").FirstOrDefault().Value;// ("char", W.namespaceuri.ToString()).Value;

                        UnicodeEncoding unicode = new UnicodeEncoding();
                        Byte[] encodedBytes = unicode.GetBytes(System.Uri.UnescapeDataString(@"\u" + charcode));


                        // Decode bytes back to string.
                        // Notice Pi and Sigma characters are still present.
                        String decodedString = unicode.GetString(encodedBytes);
                        if (decodedString.Contains(@"\uF0E0") || decodedString.Contains(@"\uF0A8"))
                        {
                            decodedString = decodedString.Replace(@"\uF0E0", "◇").Replace(@"\uF0A8", "◆");

                            Text T = new Text();
                            T.Text = decodedString;

                            ele.InsertBeforeSelf(T);
                            ele.Remove();
                        }
                    }
                }

            }

            var UpparAlphaText = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(P.InnerText.TrimStart(), @"^\(?\[?\{?([A-Z]{1,2})[\.\}\)\]]{1,2}\s");
            var LowerAlphaText = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(P.InnerText.TrimStart(), @"^\(?\[?\{?([a-z]{1,2})[\.\}\)\]]{1,2}\s");
            var AlphaNumText = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(P.InnerText, @"^\(?\[?\{?([a-zA-Z\.]{1,2})\}?\]?\)?\(?\[?\{?([0-9\.]{1,2})\}?\]?\)?\s");

            if (P.InnerText.TrimStart().StartsWith("• ") || P.InnerText.TrimStart().StartsWith("– ") || P.InnerText.TrimStart().StartsWith("○ ") || P.InnerText.TrimStart().StartsWith("▪ ") || P.InnerText.TrimStart().StartsWith("• ") || P.InnerText.TrimStart().StartsWith("◆ ") || P.InnerText.TrimStart().StartsWith("◇ ") || string.IsNullOrEmpty(UpparAlphaText) || string.IsNullOrEmpty(LowerAlphaText) || string.IsNullOrEmpty(AlphaNumText))
            {
                if (P.Descendants<InsertedRun>().Count() > 0)
                {
                    P.Descendants<InsertedRun>().ToList().ForEach(x => x.Remove());
                }
                if (P.Descendants<DeletedRun>().Count() > 0)
                {
                    P.Descendants<DeletedRun>().ToList().ForEach(x => x.Remove());
                }
            }
        }

        public static void MovetoFigurecallout(string newDoc)////for VTH client project added on 11-06-2020
        {

            using (WordprocessingDocument WPD = WordprocessingDocument.Open(newDoc, true))
            {


                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                List<Paragraph> FIGCPara = new List<Paragraph>();

                foreach (var para in D.Descendants<Paragraph>().ToList().Where(x => x.InnerText.Replace(" ", "").Contains(",groß") || x.InnerText.Replace(" ", "").Contains(";groß") || x.InnerText.Replace(" ", "").Contains(",gemeinsameLegende") || x.InnerText.Replace(" ", "").Contains("groß")))////Added on vikas on 15-10-2020 for VTH job juncchar remove
                {
                    foreach (var run in para.Descendants<Run>().ToList())
                    {
                        foreach (var text in para.Descendants<Text>().ToList())
                        {
                            text.Text = text.Text.Replace(", groß", "").Replace("; groß", "").Replace(", gemeinsame Legende", "").Replace(" groß", "");
                        }
                    }
                }

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(x => x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null
                                        && x.ParagraphProperties.ParagraphStyleId.Val != null && x.ParagraphProperties.ParagraphStyleId.Val == "FIGC"))
                {
                    FIGCPara.Add(P);
                }

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(x => Regex.Match(x.InnerText, "([[((]+Bild [0-9]{3}[))]+)|([[((]+Bild [0-9]{3}[a-zA-Z][))]+)").Success))
                {

                    if (FIGCPara.Any(x => x.InnerText.StartsWith(P.InnerText.ToLower().Replace("(", "").Replace(")", "").Replace("bild", "").Replace(" ", "") + " ") || x.InnerText.Contains("-" + P.InnerText.ToLower().Replace("(", "").Replace(")", "").Replace("bild", "").Replace(" ", "") + "((") || x.InnerText.Contains(P.InnerText.ToLower().Replace("(", "").Replace(")", "").Replace("bild", "").Replace(" ", "") + "((") || x.InnerText.Contains("-" + P.InnerText.ToLower().Replace("(", "").Replace(")", "").Replace("bild", "").Replace(" ", "") + " ")))
                    {

                        var para = FIGCPara.Where(x => x.InnerText.StartsWith(P.InnerText.ToLower().Replace("(", "").Replace(")", "").Replace("bild", "").Replace(" ", "") + " ") || x.InnerText.Contains("-" + P.InnerText.ToLower().Replace("(", "").Replace(")", "").Replace("bild", "").Replace(" ", "") + "((") || x.InnerText.Contains(P.InnerText.ToLower().Replace("(", "").Replace(")", "").Replace("bild", "").Replace(" ", "") + "((") || x.InnerText.Contains("-" + P.InnerText.ToLower().Replace("(", "").Replace(")", "").Replace("bild", "").Replace(" ", "") + " "));
                        if (para.Count() > 0)
                        {
                            P.InsertAfterSelf(para.FirstOrDefault().CloneNode(true));

                            para.FirstOrDefault().Remove();

                            FIGCPara.Remove(para.FirstOrDefault());

                        }
                    }
                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null
                                        && P.ParagraphProperties.ParagraphStyleId.Val != null)
                    {
                        P.ParagraphProperties.ParagraphStyleId.Val = "FIGP";
                    }
                }
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(x => Regex.Match(x.InnerText, "([[((]+Bild [0-9]{3}[))]+)").Success))
                {

                    if (FIGCPara.Any(x => x.InnerText.StartsWith(P.InnerText.ToLower().Replace("(", "").Replace(")", "").Replace("bild", "").Replace(" ", "") + " ") || x.InnerText.Contains("-" + P.InnerText.ToLower().Replace("(", "").Replace(")", "").Replace("bild", "").Replace(" ", "") + "((") || x.InnerText.Contains(P.InnerText.ToLower().Replace("(", "").Replace(")", "").Replace("bild", "").Replace(" ", "") + "((") || x.InnerText.Contains("-" + P.InnerText.ToLower().Replace("(", "").Replace(")", "").Replace("bild", "").Replace(" ", "") + " ")))
                    {

                        var para = FIGCPara.Where(x => x.InnerText.StartsWith(P.InnerText.ToLower().Replace("(", "").Replace(")", "").Replace("bild", "").Replace(" ", "") + " ") || x.InnerText.Contains("-" + P.InnerText.ToLower().Replace("(", "").Replace(")", "").Replace("bild", "").Replace(" ", "") + "((") || x.InnerText.Contains(P.InnerText.ToLower().Replace("(", "").Replace(")", "").Replace("bild", "").Replace(" ", "") + "((") || x.InnerText.Contains("-" + P.InnerText.ToLower().Replace("(", "").Replace(")", "").Replace("bild", "").Replace(" ", "") + " "));
                        if (para.Count() > 0)
                        {
                            if (para.FirstOrDefault().CloneNode(true).LocalName == "p")
                            {
                                var newpara = (Paragraph)para.FirstOrDefault().CloneNode(true);

                                P.InsertAfterSelf(newpara);
                            }



                            para.FirstOrDefault().Remove();

                            FIGCPara.Remove(para.FirstOrDefault());

                        }
                    }
                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null
                                        && P.ParagraphProperties.ParagraphStyleId.Val != null)
                    {
                        P.ParagraphProperties.ParagraphStyleId.Val = "FIG";
                    }
                }
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(x => Regex.Match(x.InnerText, @"([[((]+Bild [0-9]{3}\.([0-9]+)[))]+)").Success))//Added by vikas on 05-07-2021 for pattern for text like ((Bild 100.1))
                {
                    if (FIGCPara.Any(x => x.InnerText.StartsWith(P.InnerText.ToLower().Replace("(", "").Replace(")", "").Replace("bild", "").Replace(" ", "") + " ") || x.InnerText.Contains("-" + P.InnerText.ToLower().Replace("(", "").Replace(")", "").Replace("bild", "").Replace(" ", "") + "((") || x.InnerText.Contains(P.InnerText.ToLower().Replace("(", "").Replace(")", "").Replace("bild", "").Replace(" ", "") + "((") || x.InnerText.Contains("-" + P.InnerText.ToLower().Replace("(", "").Replace(")", "").Replace("bild", "").Replace(" ", "") + " ")))
                    {

                        var para = FIGCPara.Where(x => x.InnerText.StartsWith(P.InnerText.ToLower().Replace("(", "").Replace(")", "").Replace("bild", "").Replace(" ", "") + " ") || x.InnerText.Contains("-" + P.InnerText.ToLower().Replace("(", "").Replace(")", "").Replace("bild", "").Replace(" ", "") + "((") || x.InnerText.Contains(P.InnerText.ToLower().Replace("(", "").Replace(")", "").Replace("bild", "").Replace(" ", "") + "((") || x.InnerText.Contains("-" + P.InnerText.ToLower().Replace("(", "").Replace(")", "").Replace("bild", "").Replace(" ", "") + " "));
                        if (para.Count() > 0)
                        {
                            if (para.FirstOrDefault().CloneNode(true).LocalName == "p")
                            {
                                var newpara = (Paragraph)para.FirstOrDefault().CloneNode(true);

                                P.InsertAfterSelf(newpara);
                            }



                            para.FirstOrDefault().Remove();

                            FIGCPara.Remove(para.FirstOrDefault());

                        }
                    }
                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null
                                        && P.ParagraphProperties.ParagraphStyleId.Val != null)
                    {
                        P.ParagraphProperties.ParagraphStyleId.Val = "FIG";
                    }
                }
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(x => Regex.Match(x.InnerText, "([[((]+Bild [0-9]{3}[a-zA-Z][))]+)").Success))
                {

                    if (FIGCPara.Any(x => x.InnerText.StartsWith(P.InnerText.ToLower().Replace("(", "").Replace(")", "").Replace("bild", "").Replace(" ", "") + " ") || x.InnerText.Contains("-" + P.InnerText.ToLower().Replace("(", "").Replace(")", "").Replace("bild", "").Replace(" ", "") + "((") || x.InnerText.Contains(P.InnerText.ToLower().Replace("(", "").Replace(")", "").Replace("bild", "").Replace(" ", "") + "((") || x.InnerText.Contains("-" + P.InnerText.ToLower().Replace("(", "").Replace(")", "").Replace("bild", "").Replace(" ", "") + " ")))
                    {

                        var para = FIGCPara.Where(x => x.InnerText.StartsWith(P.InnerText.ToLower().Replace("(", "").Replace(")", "").Replace("bild", "").Replace(" ", "") + " ") || x.InnerText.Contains("-" + P.InnerText.ToLower().Replace("(", "").Replace(")", "").Replace("bild", "").Replace(" ", "") + "((") || x.InnerText.Contains(P.InnerText.ToLower().Replace("(", "").Replace(")", "").Replace("bild", "").Replace(" ", "") + "((") || x.InnerText.Contains("-" + P.InnerText.ToLower().Replace("(", "").Replace(")", "").Replace("bild", "").Replace(" ", "") + " "));
                        if (para.Count() > 0)
                        {
                            if (para.FirstOrDefault().CloneNode(true).LocalName == "p")
                            {
                                var newpara = (Paragraph)para.FirstOrDefault().CloneNode(true);

                                P.InsertAfterSelf(newpara);
                            }



                            para.FirstOrDefault().Remove();

                            FIGCPara.Remove(para.FirstOrDefault());

                        }
                    }
                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null
                                        && P.ParagraphProperties.ParagraphStyleId.Val != null)
                    {
                        P.ParagraphProperties.ParagraphStyleId.Val = "FIG";
                    }
                }
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(x => Regex.Match(x.InnerText, @"([[((]+Tabelle [0-9]{2}[))]+)|([((]+Tabelle\s{1,}[0-9]+[_][0-9]+[))]+)").Success))  //08-08-2020
                {
                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null
                                        && P.ParagraphProperties.ParagraphStyleId.Val != null)
                    {
                        P.ParagraphProperties.ParagraphStyleId.Val = "FIG";
                    }
                }
                if (D.Descendants<Paragraph>().ToList().Any(x => Regex.Match(x.InnerText, "([[((]+Bild [0-9]{3}[))]+)").Success))
                {

                    foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(x => x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null
                                        && x.ParagraphProperties.ParagraphStyleId.Val != null && x.ParagraphProperties.ParagraphStyleId.Val == "FIGC" || x.ParagraphProperties.ParagraphStyleId.Val == "TT"))
                    {
                        P.ParagraphProperties.ParagraphStyleId.Val = "FIGP";

                    }
                }
                D.Save();
            }
            CheckCTStyle(newDoc);
        }
        public static void CheckCTStyle(string newDoc)////for VTH client project added on 11-06-2020
        {

            using (WordprocessingDocument WPD = WordprocessingDocument.Open(newDoc, true))
            {


                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                int CTCnt = 0;
                if (D.Descendants<Paragraph>().ToList().Any(x => Regex.Match(x.InnerText, "([[((]+Bild [0-9]{3}[))]+)").Success))
                {
                    foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(x => x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null
                                        && x.ParagraphProperties.ParagraphStyleId.Val != null && x.ParagraphProperties.ParagraphStyleId.Val == "CT"))
                    {
                        CTCnt++;
                        if (CTCnt != 1)
                        {
                            P.ParagraphProperties.ParagraphStyleId.Val = "H1";
                        }
                    }
                }

                D.Save();
            }
        }
        public static void TableStructuring(string newDoc)////for frontmatter tables content job added by vikas 24-06-2020
        {
            using (WordprocessingDocument WPD = WordprocessingDocument.Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (CheckifCompleteParaIsBold(P.Descendants<Run>()) == true)
                    {
                        if (P.Parent != null && P.Parent.XName.LocalName == "tc")///if table text bold
                        {
                            P.ParagraphProperties.ParagraphStyleId.Val = "TCH";
                        }
                    }
                    else if (P.Parent != null && P.Parent.XName.LocalName == "tc")
                    {
                        P.ParagraphProperties.ParagraphStyleId.Val = "T-TXT";/////For table text without bold
                    }
                }
                D.Save();
            }

        }
        public static void CaptionStyleCorrection(string newDoc)////for check caption style is proper applied or not
        {
            using (WordprocessingDocument WPD = WordprocessingDocument.Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().Where(x => x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && (x.ParagraphProperties.ParagraphStyleId.Val == "FIGC" || x.ParagraphProperties.ParagraphStyleId.Val == "TT")).ToList())
                {
                    if (!P.OuterXml.ToLower().Contains("label-strong"))
                    {
                        P.ParagraphProperties.ParagraphStyleId.Val.Value = "BodyA";
                    }
                }
                D.Save();
            }

        }
        public static void ExtractStylesPart(WordprocessingDocument document, Paragraph P, string stylename)/////Apply para indent from manuscript list style to 3cm applied para style added by vikas on 10-07-2020
        {
            // Declare a variable to hold the XDocument.
            //XDocument styles = null;
            Dictionary<string, DocumentFormat.OpenXml.Wordprocessing.Style> StyleList = new Dictionary<string, DocumentFormat.OpenXml.Wordprocessing.Style>();

            // Open the document for read access and get a reference.

            // Get a reference to the main document part.
            var docPart = document.MainDocumentPart;

            StyleList = document.MainDocumentPart.StyleDefinitionsPart.Styles.OfType<DocumentFormat.OpenXml.Wordprocessing.Style>().Select(p => p).ToDictionary(d => d.StyleId.Value);


            string key = stylename;
            List<Style> mystyle = (from kvp in StyleList where kvp.Key == key select kvp.Value).ToList();

            if (mystyle.Count > 0)
            {
                if (mystyle.FirstOrDefault().StyleParagraphProperties != null && mystyle.FirstOrDefault().StyleParagraphProperties.Count() > 0)
                {
                    mystyle.FirstOrDefault().StyleParagraphProperties.ToList().ForEach(x =>
                    {
                        if (x.LocalName != "pstyle")
                        {
                            P.ParagraphProperties.Append(x.CloneNode(true));
                        }
                    });
                }
            }

        }
        public static bool checklistisCircleList(Paragraph p, string listText)
        {
            if (listText.EndsWith(" "))
            {
                return true;
            }
            if (p.Descendants<Run>().Any(x => x.InnerText == listText))
            {
                var runfirst = p.Descendants<Run>().Where(x => x.InnerText == listText).FirstOrDefault();
                if (runfirst.NextSibling().Count() > 0)
                {
                    var checktab = runfirst.NextSibling().Any(x => x.LocalName == W.tab.LocalName);
                    if (checktab)
                    {
                        foreach (var tx in runfirst.NextSibling())
                        {
                            if (tx.LocalName == W.tab.LocalName)
                            {
                                tx.Remove();
                            }

                        }
                        if (runfirst.NextSibling().Any(x => x.LocalName == W.t.LocalName))
                        {
                            foreach (var tx in runfirst.NextSibling().Descendants())
                            {
                                if (tx.LocalName == W.t.LocalName)
                                {
                                    ((Text)tx).Text = ((Text)tx).Text + "\u00A0";////tab replace with space
                                }

                            }
                        }
                        else
                        {
                            if (runfirst.NextSibling().FirstOrDefault().Parent != null && runfirst.NextSibling().FirstOrDefault().Parent.LocalName == W.r.LocalName)
                                runfirst.NextSibling().FirstOrDefault().Parent.Append(new Text() { Text = "\u00A0" });////tab replace with space
                        }
                        return true;
                    }
                }
            }

            return false;
        }
        public static void ApplyBodyAtoNot3CMStyles(string newDoc)////forapply BodyA which are not 3cm styles added on 24-07-2020
        {

            using (WordprocessingDocument WPD = WordprocessingDocument.Open(newDoc, true))
            {

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(x => x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null
                                        && x.ParagraphProperties.ParagraphStyleId.Val != null && x.ParagraphProperties.ParagraphStyleId.Val.ToString().All(xy => char.IsLower(xy) || xy == '-' || char.IsDigit(xy))))
                {
                    P.ParagraphProperties.ParagraphStyleId.Val.Value = "BodyA";
                }
                if (GlobalMethods.strServiceType == "Content")
                {
                    foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(x => x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null
                                       && x.ParagraphProperties.ParagraphStyleId.Val != null && x.ParagraphProperties.ParagraphStyleId.Val == "Signature"))
                    {
                        P.ParagraphProperties.ParagraphStyleId.Val.Value = "BodyA";
                    }
                }

                D.Save();
            }

        }
        public static void CiteFIGStyleRemoveVTHFIGStyle(string strProcessDoc)
        {
            using (WordprocessingDocument docx = WordprocessingDocument.Open(strProcessDoc, true))
            {
                try
                {

                    var FigCPara = docx.MainDocumentPart.Document.Body.Descendants<Paragraph>().
                    Where(rStyle => rStyle != null && rStyle.ParagraphProperties != null && rStyle.ParagraphProperties.ParagraphStyleId != null && rStyle.ParagraphProperties.ParagraphStyleId.Val == "FIG").ToList();

                    foreach (var figpara in FigCPara)
                    {
                        foreach (var figR in figpara.Descendants<RunStyle>().ToList().Where(rStyle => rStyle != null && rStyle.Val == "citefig").ToList())
                        {
                            figR.Remove();
                        }
                    }

                }
                catch (Exception ex)
                {

                }

                docx.Save();
            }
        }

        public static void SageChapterMappinngBasedonText(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().Where(x => x.Parent != null && x.Parent.LocalName != W.tc.LocalName).ToList())
                {
                    if (P.InnerText.Trim().StartsWith("*****"))////not required this text in structured word
                    {
                        P.Remove();
                        continue;
                    }
                    if (Regex.Match(P.InnerText, @"^(Exhibit ([0-9]+\.[0-9]+))").Success)
                    {
                        continue;
                    }
                    if (P.InnerText.ToLower().Trim() == "by")////skip para
                    {
                        continue;
                    }
                    else if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val.Value == "AU")
                    {
                        continue;
                    }
                    else if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val.Value == "CN-FM" && P.NextSibling() != null && P.NextSibling().XName.LocalName == "p")
                    {
                        if (P.NextSibling().InnerText.Trim().ToLower() != "by")
                        {
                            if (((Paragraph)P.NextSibling()).ParagraphProperties != null)
                            {
                                if (((Paragraph)P.NextSibling()).ParagraphProperties.ParagraphStyleId != null && ((Paragraph)P.NextSibling()).ParagraphProperties.ParagraphStyleId.Val != null)
                                {
                                    ((Paragraph)P.NextSibling()).ParagraphProperties.ParagraphStyleId.Val.Value = "CT";
                                }
                                else
                                {
                                    ((Paragraph)P.NextSibling()).ParagraphProperties.Append(new ParagraphStyleId { Val = "CT" });
                                }
                            }
                            else
                            {
                                ((Paragraph)P.NextSibling()).Append(new ParagraphProperties(new ParagraphStyleId { Val = "CT" }));
                            }
                        }

                    }
                    else if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val.Value == "CT" && P.NextSibling() != null && P.NextSibling().XName.LocalName == "p")
                    {
                        if (P.NextSibling().InnerText.Trim().ToLower() == "learning objectives")
                        {
                            continue;
                        }
                        if (P.NextSibling().InnerText.Trim().ToLower() != "by")
                        {
                            if (((Paragraph)P.NextSibling()).ParagraphProperties != null)
                            {
                                if (((Paragraph)P.NextSibling()).ParagraphProperties.ParagraphStyleId != null && ((Paragraph)P.NextSibling()).ParagraphProperties.ParagraphStyleId.Val != null)
                                {
                                    ((Paragraph)P.NextSibling()).ParagraphProperties.ParagraphStyleId.Val.Value = "AU";
                                }
                                else
                                {
                                    ((Paragraph)P.NextSibling()).ParagraphProperties.Append(new ParagraphStyleId { Val = "AU" });
                                }
                            }
                            else
                            {
                                ((Paragraph)P.NextSibling()).Append(new ParagraphProperties(new ParagraphStyleId { Val = "AU" }));
                            }
                        }
                        else if (P.NextSibling().InnerText.Trim().ToLower() == "by" && P.NextSibling().NextSibling() != null && P.NextSibling().NextSibling().XName.LocalName == "p")
                        {
                            if (((Paragraph)P.NextSibling().NextSibling()).ParagraphProperties != null)
                            {
                                if (((Paragraph)P.NextSibling().NextSibling()).ParagraphProperties.ParagraphStyleId != null && ((Paragraph)P.NextSibling().NextSibling()).ParagraphProperties.ParagraphStyleId.Val != null)
                                {
                                    ((Paragraph)P.NextSibling()).ParagraphProperties.ParagraphStyleId.Val.Value = "BodyA";

                                    ((Paragraph)P.NextSibling().NextSibling()).ParagraphProperties.ParagraphStyleId.Val.Value = "AU";
                                }
                                else
                                {
                                    ((Paragraph)P.NextSibling().NextSibling()).ParagraphProperties.Append(new ParagraphStyleId { Val = "AU" });
                                }
                            }
                            else
                            {
                                ((Paragraph)P.NextSibling().NextSibling()).ParagraphProperties.Append(new ParagraphProperties(new ParagraphStyleId { Val = "AU" }));
                            }
                        }
                    }
                    else if (CheckifCompleteParaIsBold(P.Descendants<Run>().Where(x => x.InnerText.Trim() != "")) == true && CheckifCompleteParaIsItalic(P.Descendants<Run>().Where(x => x.InnerText.Trim() != "")) == true)
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "H2";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "H2" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "H2" }));
                        }

                    }
                    else if (CheckifCompleteParaIsBold(P.Descendants<Run>().Where(x => x.InnerText.Trim() != "")) == true)
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId.Val.Value != "BoxStart" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "BoxEnd")//Developer Name:Priyanka Vishwakarma,Date:13-07-2021 ,Add condition for avoid BoxStart and BoxEnd paragraph.
                                {
                                    P.ParagraphProperties.ParagraphStyleId.Val.Value = "H1";
                                }
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "H1" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "H1" }));
                        }

                    }
                    else if (CheckifCompleteParaIsItalic(P.Descendants<Run>().Where(x => x.InnerText.Trim() != "")) == true)
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "H3";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "H3" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "H3" }));
                        }
                    }
                    else if (P.ParagraphProperties != null && P.ParagraphProperties.Indentation != null && P.ParagraphProperties.Indentation.Left != null && P.ParagraphProperties.Indentation.Left.Value != null)
                    {
                        if (P.InnerText == "")
                        {
                            P.Remove();
                            continue;
                        }
                        if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && (P.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower() == "ref1" || P.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower() == "tt" || P.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower() == "figc" || P.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower() == "ref"))
                        {
                            continue;
                        }
                        if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && !P.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower().EndsWith("list"))
                        {
                            if (P.ParagraphProperties != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                                {
                                    P.ParagraphProperties.ParagraphStyleId.Val.Value = "Quote";
                                }
                                else
                                {
                                    P.ParagraphProperties.Append(new ParagraphStyleId { Val = "Quote" });
                                }
                            }
                            else
                            {
                                P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "Quote" }));
                            }
                        }
                    }
                    else if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val.Value.Replace(" ", "").ToLower() == "footnotetext")
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "BodyA";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "BodyA" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "BodyA" }));
                        }

                    }

                }
                Nxt: { }
                D.Save();
            }
            doublecommaspacetocommaspace(newDoc);
        }
        public static void doublecommaspacetocommaspace(string wordFilePath)/////In comma double space and double dot remove text
        {
            try
            {
                object outputFileName = null;
                object oMissing = System.Reflection.Missing.Value;
                Microsoft.Office.Interop.Word.Application word = new Microsoft.Office.Interop.Word.Application();
                try
                {
                    word.Visible = false;
                    word.ScreenUpdating = false;
                    word.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
                    Object filename = (Object)wordFilePath;
                    //Document doc = word.Documents.Open(ref filename, ref oMissing,
                    //                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                    //                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                    //                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing);
                    Microsoft.Office.Interop.Word.Document doc = word.Documents.Open(filename, false);
                    try
                    {
                        Microsoft.Office.Interop.Word.Range r = doc.Content;
                        r.WholeStory();

                        r.Find.Execute(", ,  (", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, " (", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute(",  ", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ", ", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll); //Change comma double space to single space
                        r.Find.Execute("...", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "\u2026", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute(". . .", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "\u2026", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute("..", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ".", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute("\t", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, " ", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute(@" \ ", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, @"\", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute("---", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "—", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute("--", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "–", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute(" - ", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "-", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute("- ", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "-", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute(" -", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "-", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute(" – ", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "–", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute("– ", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "–", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute(" –", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "–", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute(" — ", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "—", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute("— ", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "—", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute(" —", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "—", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute("! ’", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "!’", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        if (GlobalMethods.strClientName.ToLower() != "csiro")
                        {
                            r.Find.Execute(",1", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ", 1", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        }
                        r.Find.Execute(", ’", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ",’", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute(",(", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "(", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        /////Added by vikas on 07-01-2020 for semicolon and opening paranthesis remove semiclon
                        r.Find.Execute(";(", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "(", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute(", (", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, " (", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        /////Added by vikas on 07-01-2020 for semicolon and opening paranthesis remove semiclon
                        r.Find.Execute("; (", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, " (", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute("( ", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "(", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute("[ ", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "[", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute("{ ", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "{", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute(" )", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ")", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute(" ]", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "]", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute(" }", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "}", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute(", ,", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ",", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute("\u00A0", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, " ", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute("  ", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, " ", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute(" ?", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "?", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute(" ,", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ",", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute(";;", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ";", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute(" / ", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "/", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute(" /", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "/", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute("/ ", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "/", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute(" \u0022", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, " \u201C", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);///stright quote to smart quote opening quote
                        r.Find.Execute("\u0022 ", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "\u201D ", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);///stright quote to smart quote closing quote



                        doc.SaveAs(ref filename,
                                    ref oMissing, ref oMissing,
                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing);
                    }
                    finally
                    {
                        //object saveChanges = WdSaveOptions.wdDoNotSaveChanges;
                        //((_Document)doc).Close(ref saveChanges, ref oMissing, ref oMissing);
                        //doc = null;
                        doc.Close();
                    }
                }
                finally
                {
                    //((_Application)word).Quit(ref oMissing, ref oMissing, ref oMissing);
                    word.Quit();
                    word = null;
                }


            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);

            }
        }


    }
}

