﻿using System;
using System.IO;
using System.Text.RegularExpressions;
using System.Linq;
using System.Collections.Generic;
using Microsoft.Office.Interop.Word;
using System.Configuration;
using System.Runtime.InteropServices;

namespace MultiInstanceBookCleanup
{
    class SearchAndReplace
    {
        public static void GeneralSearchAndReplace(string strDocPath)
        {
            Microsoft.Office.Interop.Word.Document mdoc = null;
            try
            {
                string strDocContent = null;

                // Read the Document Content from Word Document //
                //strDocContent = GlobalMethods.ReadDocumentContent(strDocPath);
                var CitationStyle = ConfigurationManager.AppSettings.Get("CitationStyle");
                List<string> CitationPatternsColl = new List<string>();

                CitationPatternsColl = GlobalMethods.ReadAndStoreFileValuesInArray(CitationStyle);
                // Load Word Document Content
                mdoc = GlobalMethods.LoadWordDocument(strDocPath);

                strDocContent = mdoc.Content.Text;

                if (strDocContent == null)
                    return;

                // Search the patterns in the document content using Regular Expression
                if (mdoc != null)
                {
                    List<string> strMatchText = new List<string>();
                    string strSearchRegEx = null;

                    strMatchText.Clear();
                    strSearchRegEx = null;


                    ///configuration added by Karan Start
                    foreach (var item in CitationPatternsColl)
                    {

                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, item);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                if (strMatchText[counter].ToLower().Contains("fig"))
                                {
                                    GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                                }
                                if (strMatchText[counter].ToLower().Contains("[foto"))
                                {
                                    GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                                }
                                else if (strMatchText[counter].ToLower().Contains(".tif") || strMatchText[counter].ToLower().Contains(".eps"))  //Developer name:Priyanka Vishwakarma ,Date:30_09_2019,Requirement:Apply cite_fig character style to .tif and .eps extension figure for academic ,Integrated by:Vikas sir.
                                {
                                    GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                                }
                                else if (strMatchText[counter].ToLower().Contains("bild") || strMatchText[counter].ToLower().Contains("tabelle"))  //Developer name:Priyanka Vishwakarma ,Date:02_07_2020,Requirement:Apply Citefig Charstyle for Fig.
                                {
                                    GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                                }
                                if (strMatchText[counter].ToLower().Contains("abb.")|| strMatchText[counter].ToLower().Contains("flowchart"))
                                {
                                    GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                                }
                                if (strMatchText[counter].ToLower().Contains("tab") || strMatchText[counter].ToLower().Contains("quadro"))
                                {
                                    GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, false, false);
                                }
                                if (strMatchText[counter].ToLower().Contains("box") || strMatchText[counter].ToLower().Contains("caixa") || strMatchText[counter].ToLower().Contains("scatola"))
                                {
                                    GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_box", "", true, false, false, false, false);
                                }
                                if (strMatchText[counter].ToLower().Contains("chapter") || strMatchText[counter].ToLower().Contains("kapitel") || strMatchText[counter].ToLower().Contains("capitolo") || strMatchText[counter].ToLower().Contains("chaps.") || strMatchText[counter].ToLower().Contains("kap.") || strMatchText[counter].ToLower().Contains("chap.") || strMatchText[counter].ToLower().Contains("indivíduo.") || strMatchText[counter].ToLower().Contains("Kerl."))  //Developer Name:Priyanka Vishwakarma,Date:03-08-2020 ,Requirement:Apply citesec charstyle to Chapter link.
                                {
                                    GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_sec", "", true, false, false, false, false);
                                }
                                if (strMatchText[counter].ToLower().Contains("exhibit"))//Developer Name:Priyanka Vishwakarma,Date:18-03-2021,Requirement:Add condition for apply cite_box to exhibit callout.
                                {
                                    GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_box", "", true, false, false, false, false);
                                }
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;
                    }
                    ///configuration added by Karan End
                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"(Fig [0-9]+\.[0-9]+\-[0-9]+)";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "FIGC", "label-Strong", "", true, false, true, true, false);
                        }
                    }

                    strSearchRegEx = @"(Box\s[0-9]+)";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "BT", "label-Strong", "", true, false, true, true, false);
                        }
                    }



                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"(Figura [0-9]+\.[0-9]+)";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "FIGC", "label-Strong", "", true, false, true, true, false);
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"(Fig\. [0-9]+\.[0-9]+\-[0-9]+)";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "FIGC", "label-Strong", "", true, false, true, true, false);
                        }
                    }
                    //// ADDED BY AARTI 23-1-2019 FOR cite_video start ///commented by aarti 07-02-2019
                    //strMatchText.Clear();
                    //strSearchRegEx = null;

                    //strSearchRegEx = @"(Video\. [0-9]+\.[0-9]+)";
                    //strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    //if (strMatchText.Count > 0)
                    //{
                    //    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //    {
                    //        GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_video", "", true, false, false, false, false);
                    //    }
                    //}
                    //// ..................ADDED BY AARTI 23-1-2019 FOR cite_video end

                    //// ADDED BY AARTI 23-1-2019 FOR cite_video start
                    //strMatchText.Clear();
                    //strSearchRegEx = null;

                    //// strSearchRegEx = @"(Video\. [0-9]+)";
                    //strSearchRegEx = @"(Video [0-9]+\.[0-9]+\-[0-9]+)";
                    //strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    //if (strMatchText.Count > 0)
                    //{
                    //    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //    {
                    //        GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_video", "", true, false, false, false, false);
                    //    }
                    //}
                    ////........... ADDED BY AARTI 23-1-2019 FOR cite_video end 

                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"(Fig\. [0-9]+)";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "FIGC", "label-Strong", "", true, false, true, true, false);
                        }
                    }

                    //21-10-2018
                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"((Fig\. [0-9]+\.[0-9]+))";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "FIGC", "label-Strong", "", true, false, true, true, false);
                        }
                    }
                    //21-10-2018

                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"(Fig\. [0-9]+[\-|\–|\–|\.][0-9]+)";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "FIGC", "label-Strong", "", true, false, true, true, false);
                        }
                    }


                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strSearchRegEx = @"(Flowchart\s[0-9]+)";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "FIGC", "label-Strong", "", true, false, true, true, false);
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strSearchRegEx = @"(Figure|FIGURA|Figura|Feige|Feige.)\s([0-9]+)[\-|\–|\–|\.]([0-9]+)"; //Develper Name:Priyanka Vishwakarma Date:08-08-2020 Requirement:Regex change it select only numbers /////FIGURA added on 02-07-2020 for brazil project by vikas For hypen regex updated by vikas on 13-07-2020
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "FIGC", "label-Strong", "", true, false, true, true, false);
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"(Abb. ([0-9]+))";////////added by vikas for random-house sample 28-03-2020
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "FIGC", "label-Strong", "", true, false, true, true, false);
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"(Bild ([0-9]+))";////////added by vikas for VTH sample 15-08-2020
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "FIGC", "label-Strong", "", true, false, true, true, false);
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"(Bild ([0-9]+)([a-zA-Z]))";////////added by vikas for VTH sample 15-08-2020
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "FIGC", "label-Strong", "", true, false, true, true, false);
                        }
                    }

                    //strMatchText.Clear();
                    //strSearchRegEx = null;

                    //strSearchRegEx = @"(Fig\. [0-9]+\.[0-9]+)";
                    //strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    //if (strMatchText.Count > 0)
                    //{
                    //    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //    {
                    //        GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                    //    }
                    //}


                    //strMatchText.Clear();
                    //strSearchRegEx = null;

                    //strSearchRegEx = @"(Fig\. [0-9]+)";
                    //strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    //if (strMatchText.Count > 0)
                    //{
                    //    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //    {
                    //        GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                    //    }
                    //}

                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"(Table [0-9]+\.[0-9]+)";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, false, false);
                        }
                    }

                    //new pattern update by Karan on 06-11-2018 For Cap5 document start
                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"(Tab [0-9]+\.[0-9]+)";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, false, false);
                        }
                    }


                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"(Tab. [0-9]+\.[0-9]+)";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, false, false);
                        }
                    }

                    //new pattern update by Karan on 06-11-2018 For Cap5 document End

                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"(Table [1-9]+)";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, false, false);
                        }
                    }

                    //////////////////// For Video ////////////////////////////////////

                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"(Video [0-9]+\.[0-9]+\-[0-9]+)";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "FIGC", "label-Strong", "", true, false, true, true, false);
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"(Vídeo [0-9]+\.[0-9]+)";//////For Brazil-project on 08-05-2020 by vikas
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "FIGC", "label-Strong", "", true, false, true, true, false);
                        }
                    }

                    /////////////////// For Video ////////////////////////////////////


                    //new pattern update by Karan on 06-11-2018 For Cap5 document start
                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"((Tabella|Tabella.) [0-9]+[\-|\–|\–|\.][0-9]+)";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "TT", "label-Strong", "", true, false, false, true, false);
                        }
                    }
                    //new pattern update by Karan on 06-11-2018 For Cap5 document End

                    //new pattern update by Vikas on 06-05-2020 For Brazil-project start
                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"((Tabela|Tabela.) [0-9]+[\-|\–|\–|\.][0-9]+)";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "TT", "label-Strong", "", true, false, true, true, false);
                        }
                    }
                    //new pattern update by Vikas on 06-05-2020 For Brazil-project End


                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"((Table|Quadro|Tabela|TABELA) [0-9]+[\-|\–|\–|\.][0-9]+)";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "TT", "label-Strong", "", true, false, true, true, false);
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"(Table [0-9]+\.[0-9]+\-[0-9]+)";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "TT", "label-Strong", "", true, false, true, true, false);
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"((Table|Tabelle) [1-9]+)";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "TT", "label-Strong", "", true, false, true, true, false);
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strSearchRegEx = @"^(Table\s{1,}[0-9]+\.[0-9])";   //04102019
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "TT", "label-Strong", "", true, false, true, true, false);
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"(Tab. [0-9])";////////added by vikas for random-house sample 28-03-2020
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "TT", "label-Strong", "", true, false, true, true, false);
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"(Capítulo [0-9]+)";////Portuguese Chapter
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_sec", "", true, false, false, true, false);
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"((Caixa|Scatola) ([0-9]+)[\-|\–|\–|\.]+([0-9]+))";////////Portuguese and italian Box
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_box", "", true, false, false, true, false);
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"((Boxes|Boxes.|Boxen|Boxen.|Caixas|Caixas.|Scatole|Scatole.) ([0-9]+)[\-|\–|\–|\.]+([0-9]+)\s+(and\s|e\s|a\s|und\s|bis\s|to\s)+([0-9]+)[\-|\–|\–|\.]+([0-9]+))";////////Portuguese,German,English and italian Boxes
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_box", "", true, false, false, true, false);
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"((Caixa.|Scatola.) ([0-9]+)[\-|\–|\–|\.]+([0-9]+))";////Portuguese and italian Box
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_box", "", true, false, false, true, false);
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;
                    //Developer Name:Priyanka Vishwakarma,Date:24-07-2020,Requirement:regex change .
                    strSearchRegEx = @"(Caixa. ([0-9]+)[\-|\–|\–|\.]+([0-9]+) (e|a) [0-9]+)[\-|\–|\–|\.]+([0-9]+)";////Portuguese Box for to & for and
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_box", "", true, false, false, true, false);
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"(Caixa ([0-9]+)[\-|\–|\–|\.]+([0-9]+) (e|a) [0-9]+)[\-|\–|\–|\.]+([0-9]+)";////Portuguese Box for to & for and
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_box", "", true, false, false, true, false);
                        }
                    }
                    strSearchRegEx = @"\b(?:https?:|http?://|www\.)[^ \f\n\r\t\v\]]+\b(\/?)+";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            if (GlobalMethods.strXMLOutputrequired.ToLower() == "false")
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "weblinks", "", true, false, true, false, false);
                            else
                                GlobalMethods.FindAndapplyweblinkstyle(GlobalMethods.wordApp, strMatchText[counter]);///////Added by vikas for brazil-project  on 20-05-2020

                        }
                    }
                    strSearchRegEx = @"(https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|www\.[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s][a-zA-Z0-9]{2,}|https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9]+\.[^\s]{2,}|www\.[a-zA-Z0-9]+\.[^\s]{2,})";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            if (GlobalMethods.strXMLOutputrequired.ToLower() == "false")
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "weblinks", "", true, false, true, false, false);
                            else
                                GlobalMethods.FindAndapplyweblinkstyle(GlobalMethods.wordApp, strMatchText[counter]); ///////Added by vikas for brazil-project  on 20-05-2020
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;
                    if (GlobalMethods.strClientName.ToLower() == "vth")
                    {
                        /////for VTH client added by  vikas on 05-07-2021                    
                        strSearchRegEx = @"(Abb\.\s([0-9]+))";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "FIGC", "label-Strong", "", true, false, true, true, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;
                    }
                    //////Added for email by vikas on 20-06-2020
                    strSearchRegEx = @"[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            if (GlobalMethods.strXMLOutputrequired.ToLower() == "false")
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "weblinks", "", true, false, true, false, false);
                            else
                                GlobalMethods.FindAndapplyweblinkstyle(GlobalMethods.wordApp, strMatchText[counter]);///////Added by vikas for brazil-project  on 20-05-2020

                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;
                    ////-------------09-06-2020 
                    strSearchRegEx = @"(Abb\.\s[0-9]+\.[0-9]+)";////////09-06-2020
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "FIGC", "label-Strong", "", true, false, true, true, false);
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"(Abb\.[0-9]+\s\.[0-9]+)";////////09-06-2020
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "FIGC", "label-Strong", "", true, false, true, true, false);
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"(Abb\.\s[0-9]+\.[0-9]+[a-z][\-\–][a-z])";////////09-06-2020
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "FIGC", "label-Strong", "", true, false, true, true, false);
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"(Abb\.\s[0-9]+\.[0-9]+[\-\–][0-9]+\.[0-9]+)";////////09-06-2020
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "FIGC", "label-Strong", "", true, false, true, true, false);
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"(Abb\.\s[0-9]+\.[0-9]+\,\s[0-9]+\.[0-9]+)";////////09-06-2020
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "FIGC", "label-Strong", "", true, false, true, true, false);
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"(Fig.\s[0-9]+[\-\-][0-9]+)";////////09-06-2020
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "FIGC", "label-Strong", "", true, false, true, true, false);
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"(Table.\s[0-9]+[\-\-][0-9]+)";////////09-06-2020
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "TT", "label-Strong", "", true, false, true, true, false);
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"(Fig\s[0-9]+[\-\-][0-9]+)";////////09-06-2020
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "FIGC", "label-Strong", "", true, false, true, true, false);
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"(Table\s[0-9]+[\-\-][0-9]+)";////////09-06-2020
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "FIGC", "label-Strong", "", true, false, true, true, false);
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"(TABLE.\s[0-9]+[\-\-][0-9]+)";////////09-06-2020
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "TT", "label-Strong", "", true, false, true, true, false);
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"(Table\.\s[0-9]+[\-\-][0-9]+)";////////09-06-2020
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "TT", "label-Strong", "", true, false, true, true, false);
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"(TABLE\s[0-9]+[\-\-][0-9]+)";////////09-06-2020
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "TT", "label-Strong", "", true, false, true, true, false);
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"((Caixa|Scatola)\s[0-9]+[\-\-][0-9]+)";////////Portuguese
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "BT", "label-Strong", "", true, false, true, true, false);
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"(Caixa.\s[0-9]+[\-\-][0-9]+)";////////Portuguese
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "BT", "label-Strong", "", true, false, true, true, false);
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"(Box\s[0-9]+[\-\-][0-9]+)";////////09-06-2020
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "BT", "label-Strong", "", true, false, true, true, false);
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"(Bild\s{1,}[0-9]+[a-z][\.][0-9]+)";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "FIGC", "label-Strong", "", true, false, true, true, false);
                        }
                    }
                    ////Developer name:Priyanka ,Date:02-07-2020 ,Requirement :Apply label-strong for Figure and table caption.
                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"(Bild\s{1,}[0-9]+\s{1,}[0-9]+[a-z])";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "FIGC", "label-Strong", "", true, false, true, true, false);
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"(Tabelle\s{1,}[0-9]+[\-][0-9]+)";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "FIGC", "label-Strong", "", true, false, true, true, false);
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"(Bild\s{1,}[0-9]+[\-][0-9]+)";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "FIGC", "label-Strong", "", true, false, true, true, false);
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"(Tabelle\s{ 1,}[0-9]+\s{1,}[0-9])|(Tabelle\s[0-9]+\s[0-9]+)";   //Add Regex for Tabelle 2 6  Date:07-08-2020
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "TT", "label-Strong", "", true, false, true, true, false);
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"(Tabelle\s{1,}[0-9]+[\-][0-9]+)";  //08-08-2020
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "TT", "label-Strong", "", true, false, true, true, false);
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"(Tabelle\s{1,}[0-9]+[\-][0-9]+[a-z])";  //08-08-2020
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "TT", "label-Strong", "", true, false, true, true, false);
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"(Bild\s{1,}[0-9]+[\-][0-9]+[a-z])|(Legende\s{1,}[0-9]+)|(Schaltplan\s{1,}[0-9]+)";   //07-08-2020
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "FIGC", "label-Strong", "", true, false, true, true, false);
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"(Bild\s{1,}[0-9]+[a-z][\-|\–|\–][0-9]+)";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "FIGC", "label-Strong", "", true, false, true, true, false);
                        }
                    }
                    if(GlobalMethods.strClientName=="VTH")////Added on 09-09-2020 For VTH 
                    {
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Tabelle [1-9]+)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "FIGC", "label-Strong", "", true, false, true, true, false);
                            }
                        }
                    }
                    //------------------------------End on  02-07-2020--------------------------------
                    ///Developer Name:Priyanka Vishwakarma,Date:15-01-2021,Requirement:Add pattern for apply cite_sec to section in epub input.
                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strSearchRegEx = @"((Section|section) ([0-9]+) |(Section|section) ([0-9]+)\.([0-9]+))|((Section|section)\s[0-9]+\.[0-9]+\.[0-9]+)|((Section|section)\s[0-9]+\.[0-9]+\.[0-9]+)|(section\s[0-9]+\.[0-9]+)|((Section|section)\s[0-9]+\.[0-9]+)|(section\s[0-9]+)|((Section|section)\s[0-9]+)";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0 && (GlobalMethods.strOutputRequired.ToLower() == "epub"|| GlobalMethods.strOutputRequired.ToLower() == "xml"))////xml condition added by vikas on 02-06-2021
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_sec", "", true, false, false, false, false);
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strSearchRegEx = @"(\(([0-9]+){3}\))|(\([0-9]+\))";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0 && GlobalMethods.strOutputRequired.ToLower() == "epub")
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_eq", "", true, false, false, false, false);
                        }
                    }
                    ///////Label strong style apply
                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strSearchRegEx = @"(\(([0-9]+)\))";/////For eqution number linking
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0 && GlobalMethods.strOutputRequired.ToLower() == "epub")
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "EQ", "label-Strong", "", true, false, true, true, false);
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;
                    ////-----------End on 14-01-2021

                    //Developer Name:Priyanka Vishwakarma,Date:18-03-2021,Requirement:Add condition for apply label-strong in BT paragraph style to exhibit caption.
                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strSearchRegEx = @"(Exhibit\s{1,}[0-9]+\.[0-9]+)";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "BT", "label-Strong", "", true, false, true, true, false);
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;

                    GlobalMethods.SearchAndReplace(mdoc, "^p ^t", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.SearchAndReplace(mdoc, "^p^t", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.SearchAndReplace(mdoc, "^t^t", "^t", "", "", "", false, false, true, false, false);

                    GlobalMethods.SearchAndReplace(mdoc, "^p ", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.SearchAndReplace(mdoc, " ^p", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.SearchAndReplace(mdoc, "<jrn> ^p", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.SearchAndReplace(mdoc, "<jrn> </jrn>", "", "", "", "", false, false, true, false, false);
                    //GlobalMethods.SearchAndReplace(mdoc, "^p^p", "^p", "", "", "", false, false, true, false, false);///commented on 13-03-2020 for boxstart and boxend removed due to blank para by priyanka
                    //GlobalMethods.SearchAndReplace(mdoc, "^g", "^&", "", "", "FIG", false, true, true, false, false);
                    GlobalMethods.SearchAndReplace(mdoc, "^~", "-", "", "", "", false, false, true, false, false);
                    GlobalMethods.SearchAndReplace(mdoc, "", "", "", "", "", false, false, true, false, false);
                    if (GlobalMethods.strJobCategory.ToLower() != "frontmatter")////added by vikas for not requiered for frontmatter on 10-05-2019 integrated by vikas       
                    {
                        GlobalMethods.SearchAndReplace(mdoc, "", "", "BullList", "", "", false, false, false, false, false);
                    }

                    ////for temparvary commented start 21-11-2018
                    //GlobalMethods.SearchAndReplaceAtStartOfParagraph(mdoc, @"([0-9]{1,}\.) ", @"\1^t", "L1", "", "", false, false, false, false, true);
                    //GlobalMethods.SearchAndReplaceAtStartOfParagraph(mdoc, @"([0-9]{1,}\.) ", @"\1^t", "L2", "", "", false, false, false, false, true);
                    ////GlobalMethods.SearchAndReplaceAtStartOfParagraph(mdoc, @"([0-9]{1,}\.) ", @"\1^t", "L3", "", "", false, false, false, false, true);
                    //GlobalMethods.SearchAndReplaceAtStartOfParagraph(mdoc, @"([0-9]{1,}\.) ", @"\1^t", "UL", "", "", false, false, false, false, true);

                    //GlobalMethods.SearchAndReplaceAtStartOfParagraph(mdoc, @"([a-z]{1}\.) ", @"\1^t", "L1", "", "", false, false, false, false, true);
                    //GlobalMethods.SearchAndReplaceAtStartOfParagraph(mdoc, @"([a-z]{1}\.) ", @"\1^t", "L2", "", "", false, false, false, false, true);
                    //GlobalMethods.SearchAndReplaceAtStartOfParagraph(mdoc, @"([iVXxv\.]{1,}) ", @"\1^t", "L3", "", "", false, false, false, false, true);
                    //GlobalMethods.SearchAndReplaceAtStartOfParagraph(mdoc, @"([a-z]{1}\.) ", @"\1^t", "UL", "", "", false, false, false, false, true);
                    ////for temparvary commented end 21-11-2018

                    object oMissing = System.Reflection.Missing.Value;

                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    if (mdoc != null) Marshal.ReleaseComObject(mdoc);
                    mdoc = null;

                }
            }
            catch (Exception ex)
            {
                mdoc.Close();
            }
            finally
            {
                if (GlobalMethods.wordApp != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    ((_Application)GlobalMethods.wordApp).Quit(ref oMissing, ref oMissing, ref oMissing);
                    if (GlobalMethods.wordApp != null) Marshal.ReleaseComObject(GlobalMethods.wordApp);
                    //((_Document)mdoc).Close(WdSaveOptions.wdSaveChanges, ref oMissing, ref oMissing);
                    GlobalMethods.wordApp = null;
                }
            }
        }


        public static void ReplaceMultipleTabsWithSingleTab(string strDocPath)
        {
            try
            {
                string strDocContent = null;

                // Read the Document Content from Word Document //
                //strDocContent = GlobalMethods.ReadDocumentContent(strDocPath);

                Microsoft.Office.Interop.Word.Document mdoc = null;

                // Load Word Document Content
                mdoc = GlobalMethods.LoadWordDocument(strDocPath);

                strDocContent = mdoc.Content.Text;

                if (strDocContent == null)
                    return;

                // Search the patterns in the document content using Regular Expression
                if (mdoc != null)
                {
                    GlobalMethods.SearchAndReplace(mdoc, "^t^t", "^t", "", "", "", false, false, true, false, false);

                    object oMissing = System.Reflection.Missing.Value;

                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;

                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                if (GlobalMethods.wordApp != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    ((_Application)GlobalMethods.wordApp).Quit(ref oMissing, ref oMissing, ref oMissing);
                    GlobalMethods.wordApp = null;
                }
            }
        }

        public static void GenerateListLabels(string strDocPath)
        {
            Microsoft.Office.Interop.Word.Document mdoc = null;

            try
            {
                GlobalMethods.strListNumbers.Clear();


                // Load Word Document
                mdoc = GlobalMethods.LoadWordDocument(strDocPath);

                // Search the patterns in the document content using Regular Expression
                if (mdoc != null)
                {
                    foreach (Paragraph P in GlobalMethods.wordApp.ActiveDocument.Paragraphs)
                    {
                        P.Range.Select();

                        string strListVal = null;
                        strListVal = GlobalMethods.wordApp.Selection.Range.ListFormat.ListString;

                        if (strListVal != "")
                        {
                            if (GlobalMethods.wordApp.Selection.Range.ListFormat.ListType == WdListType.wdListBullet)
                            {
                                if (strListVal == "-")
                                {
                                    GlobalMethods.wordApp.Selection.InsertBefore("-" + "\t");
                                    if (GlobalMethods.strListNumbers.Contains("-" + "\t") == false)
                                        GlobalMethods.strListNumbers.Add("-" + "\t");
                                }
                                else
                                {
                                    GlobalMethods.wordApp.Selection.InsertBefore("•" + "\t");
                                    if (GlobalMethods.strListNumbers.Contains("•" + "\t") == false)
                                        GlobalMethods.strListNumbers.Add("•" + "\t");

                                }
                            }
                            else
                            {
                                GlobalMethods.wordApp.Selection.InsertBefore(strListVal + "\t");

                                if (GlobalMethods.strListNumbers.Contains(strListVal + "\t") == false)
                                    GlobalMethods.strListNumbers.Add(strListVal + "\t");
                            }
                        }
                    }

                    object oMissing = System.Reflection.Missing.Value;

                    //if (GlobalMethods.wordApp != null)
                    //{
                    //    mdoc = GlobalMethods.wordApp.ActiveDocument;
                    //}

                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;

                }

            }
            catch (Exception ex)
            {
                //GlobalMethods.DisposeCOMObject();
                if (mdoc != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;
                }

            }
            finally
            {
                if (GlobalMethods.wordApp != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    ((_Application)GlobalMethods.wordApp).Quit(ref oMissing, ref oMissing, ref oMissing);
                    GlobalMethods.wordApp = null;
                }
            }
        }

        public static void ApplyListNumStyle(string strDocPath)
        {
            try
            {
                //string strDocContent = null;

                // Read the Document Content from Word Document //
                //strDocContent = GlobalMethods.ReadDocumentContent(strDocPath);

                Microsoft.Office.Interop.Word.Document mdoc = null;

                // Load Word Document
                mdoc = GlobalMethods.LoadWordDocument(strDocPath);

                GlobalMethods.ApplyNumListCharStyle(mdoc, "[0-9a-zA-z\\.\\:]{1,}^t", "ListNum", true, true);

                GlobalMethods.ApplyNumListCharStyle(mdoc, "\\([0-9a-zA-z\\.\\:]{1,}\\)^t", "ListNum", true, true);

                GlobalMethods.ApplyNumListCharStyle(mdoc, "[0-9a-zA-z\\.\\:]{1,}\\)^t", "ListNum", true, true);

                GlobalMethods.ApplyNumListCharStyle(mdoc, "•^t", "ListNum", true, false);

                GlobalMethods.ApplyNumListCharStyle(mdoc, "*^t", "ListNum", true, false);

                GlobalMethods.ApplyNumListCharStyle(mdoc, "-^t", "ListNum", true, false);

                GlobalMethods.ApplyNumListCharStyle(mdoc, "-^t", "ListNum", true, false);

                // Search the patterns in the document content using Regular Expression
                if (mdoc != null)
                {
                    object oMissing = System.Reflection.Missing.Value;

                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;
                }
            }
            catch (Exception ex)
            {
                GlobalMethods.DisposeCOMObject();
            }
            finally
            {
                if (GlobalMethods.wordApp != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    ((_Application)GlobalMethods.wordApp).Quit(ref oMissing, ref oMissing, ref oMissing);
                    GlobalMethods.wordApp = null;
                }

            }
        }
        public static void ReferenceSearchAndReplaceVolumeIssue(string strDocPath)
        {
            Microsoft.Office.Interop.Word.Document mdoc = null;

            try
            {
                ///configuration added by Karan Start
                string strDocContent = null;

                // Read the Document Content from Word Document //
                //strDocContent = GlobalMethods.ReadDocumentContent(strDocPath);


                // Load Word Document Content
                mdoc = GlobalMethods.LoadWordDocument(strDocPath);

                strDocContent = mdoc.Content.Text;

                if (strDocContent == null)
                    return;

                // Search the patterns in the document content using Regular Expression
                if (mdoc != null)
                {

                    //GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    List<string> strMatchText = new List<string>();
                    string strSearchRegEx = null;


                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"(pp[\.]\s[0-9]+\s{0,1}[\-\–\−\–]\s{0,1}[0-9]+)");
                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter], "", "REF1", "bib_fpage", "", true, false, true, true, false);
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"([0-9]+\([0-9]+\)\,\s{1,}[0-9]+\s{1,}[\-\–\−]\s{1,}[0-9]+\.)|([0-9]+\([0-9A-Za-z\.]+\)\,\s{1,}[0-9]+[\-\–\−][0-9]+\.)|([0-9]+\([0-9A-Za-z\.]+\)\,\s{1,}[0-9]+[\-\–\−][0-9]+[\.|\,])|([0-9]+\([0-9]+\)\,\s{1,}[0-9]+\s{0,1}[\-\–\−]\s{0,1}[0-9]+\.)|([0-9]+\([0-9]+\)\,\spp\.\s{0,1}[0-9]+\s{0,1}[\-\–\−]\s{0,1}[0-9]+\.)|([0-9]+\([A-Za-z]+\s[A-Za-z]+\)\,\s{1,}[0-9]+\s{0,1}[\-\–\−]\s{0,1}[0-9]+\.)|([0-9]+\([A-Za-z]+\)\,\s{1,}[0-9]+\s{0,1}[\-\–\−]\s{0,1}[0-9]+\.)|([0-9]+\([0-9]+\)\:\s[0-9]+[\-\–]{1}[0-9]+)|([0-9]+\([0-9]+[\-\–\–][0-9]+\)\,\s[0-9]+[\-|\–][0-9]+)|([0-9]+\([0-9]+[\/][0-9]+\)\,\s[0-9]+[\-|\–][0-9]+)|([0-9]+\([0-9]+\)\,\s[0-9]+)|([0-9]+\([0-9]+\)\,\s[A-Za-z0-9]+)|([0-9]+\,\s[0-9]+[\-|\–][0-9]+)");// //Developer Name:Priyanka Vishwakarma,Date:02-04-2021,Requirement:Add condiiton for apply bibvolume for sage india input.
                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter], "", "REF1", "bib_volume", "", true, false, true, true, false);
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"([0-9]+\s{0,}\([0-9]\)\:\s{0,}[0-9]+[\-\–\−][0-9]+\.)");// //Developer Name:Priyanka Vishwakarma,Date:02-04-2021,Requirement:Add condiiton for apply bibvolume for sage india input.
                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter], "", "REF1", "bib_volume", "", true, false, true, true, false);
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"([0-9]+\s{0,1}\([0-9]+\)\,[\s\ ]{0,1}[0-9]+[\-\–\−][0-9]+)");
                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter], "", "REF1", "bib_volume", "", true, false, true, true, false);
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;
                    if (GlobalMethods.strClientName.ToLower() == "jaypee" || GlobalMethods.strClientName.ToLower() == "ssllc")
                    {
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"([0-9]+\s{0,1}\;\s{0,1}[0-9]+\s{0,1}\:\s{0,1}[A-Z0-9]+\-[A-Z0-9]+)");
                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter], "", "REF1", "bib_volume", "", true, false, true, true, false);
                            }
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;

                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    GlobalMethods.SearchAndReplace(mdoc, "^p ", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, " ^p", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "<jrn> ^p", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "<jrn> </jrn>", "", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    // GlobalMethods.SearchAndReplace(mdoc, "^p^p", "^p", "", "", "", false, false, true, false, false);//commented on 11020202 For boxstart and BoxEnd style remove. 
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    //GlobalMethods.SearchAndReplace(mdoc, "^g", "^&", "", "", "FIG", false, true, true, false);
                    GlobalMethods.SearchAndReplace(mdoc, "^~", "-", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "", "", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    //GlobalMethods.SearchAndReplace(mdoc, "", "", "BullList", "", "", false, false, false, false, false);//19022020 comment for indend remove.
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    object oMissing = System.Reflection.Missing.Value;

                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;

                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                if (mdoc != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;
                }
                if (GlobalMethods.wordApp != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    ((_Application)GlobalMethods.wordApp).Quit(ref oMissing, ref oMissing, ref oMissing);
                    GlobalMethods.wordApp = null;
                }
            }


        }
        public static void ReferenceSearchAndReplaceSurnameFname(string strDocPath)
        {
            Microsoft.Office.Interop.Word.Document mdoc = null;

            try
            {

                string strDocContent = null;

                // Read the Document Content from Word Document //
                //strDocContent = GlobalMethods.ReadDocumentContent(strDocPath);


                // Load Word Document Content
                mdoc = GlobalMethods.LoadWordDocument(strDocPath);

                strDocContent = mdoc.Content.Text;

                if (strDocContent == null)
                    return;

                // Search the patterns in the document content using Regular Expression
                if (mdoc != null)
                {

                    //GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    List<string> strMatchText = new List<string>();
                    string strSearchRegEx = null;



                    strMatchText.Clear();
                    strSearchRegEx = null;

                    ///configuration added by Karan Start


                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"(\([0-9]{4}\)\.)|([18|19|20|21]{2}[0-9]{2}\.)"); //Developer Name:Priyanka Vishwakarma,Date:02-04-2021,Requirement:Add condiiton for apply bibyear for sage india input.

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter].Replace("(", "").Replace(")", "").Replace(".", ""), "", "REF1", "bib_year", "", true, false, true, true, false);
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"(\([0-9]{4}\,\s(January|February|March|April|May|June|July|August|September|October|November|December)\))");

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter].Replace("(", "").Replace(")", "").Replace(".", ""), "", "REF1", "bib_year", "", true, false, true, true, false);
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"(\([0-9]{4}\,\s(January|February|March|April|May|June|July|August|September|October|November|December)\s[0-9]{1,2}\))");

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter].Replace("(", "").Replace(")", "").Replace(".", ""), "", "REF1", "bib_year", "", true, false, true, true, false);
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"(\([0-9]{4}\,\s(January|February|March|April|May|June|July|August|September|October|November|December)\s[0-9]{1,2}[\-\-][0-9]{2}\))");

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter].Replace("(", "").Replace(")", "").Replace(".", ""), "", "REF1", "bib_year", "", true, false, true, true, false);
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"([A-Za-záňíüøðjóóÓóóåöüÇğłêé\'\-\–\‐]+\,\s{1,}[A-Z]\.\s[A-Za-zzáňíüøðjóóÓóóåöüÇğłêé]+\.\s[A-Z]\.)|([A-Za-záňíüøðjóóÓóóåöüÇğłêé\'\-\–\‐]+\,\s{1,}[A-Z]\.\s[A-Z]\.\s[A-Z]\.)|([A-Za-záňíüøðjóóÓóóåöüÇğłêé\'\-\–\‐]+\,\s{1,}[A-Z]\.\s[A-Z]\.)|([A-Za-záňíüøðjóóÓóóåöüÇğłêé\'\-\–\‐]+\,\s{1,}[A-Z]\.)|([A-Za-záňíüøðjóóÓóóåöüÇğłêé\'\-\–\‐]+\s[A-Za-záňíüöüÇğłêé\-\–\‐]+\,\s[A-Z]\.)|([A-Za-záňíüøðjóóÓóóåöüÇğłêé\'\-\–\‐]+\s[A-Za-záňíüøðjóóÓóóåöüÇğłêé\'\-\–\‐]+\s[A-Za-záňíüøðjóóÓóóåöüÇğłêé\'\-\–\‐]+\,\s[A-Z]\.)");  //02-04-2021
                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter], "", "REF1", "bib_surname", "", true, false, true, true, false);
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;

                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    GlobalMethods.SearchAndReplace(mdoc, "^p ", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, " ^p", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "<jrn> ^p", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "<jrn> </jrn>", "", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    // GlobalMethods.SearchAndReplace(mdoc, "^p^p", "^p", "", "", "", false, false, true, false, false);//commented on 11020202 For boxstart and BoxEnd style remove. 
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    //GlobalMethods.SearchAndReplace(mdoc, "^g", "^&", "", "", "FIG", false, true, true, false);
                    GlobalMethods.SearchAndReplace(mdoc, "^~", "-", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "", "", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    //GlobalMethods.SearchAndReplace(mdoc, "", "", "BullList", "", "", false, false, false, false, false);//19022020 comment for indend remove.
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    object oMissing = System.Reflection.Missing.Value;

                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;

                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                if (mdoc != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;
                }
                if (GlobalMethods.wordApp != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    ((_Application)GlobalMethods.wordApp).Quit(ref oMissing, ref oMissing, ref oMissing);
                    GlobalMethods.wordApp = null;
                }
            }


        }
        public static void ReferenceSearchAndReplace(string strDocPath)
        {
            Microsoft.Office.Interop.Word.Document mdoc = null;

            try
            {
                ///configuration added by Karan Start
                GlobalMethods.strPublisherDBFilename = ConfigurationManager.AppSettings.Get("PublisherNameDBSage");
                List<string> BokCitationPatternsColl = new List<string>();

                ///Configuration read from Supporting folder
                BokCitationPatternsColl = GlobalMethods.ReadAndStoreFileValuesInArray(GlobalMethods.strPublisherDBFilename);
                ///configuration added by Karan End

                GlobalMethods.strJournalDBFilename = ConfigurationManager.AppSettings.Get("JournalNameDBSage");
                List<string> JrnCitationPatternsColl = new List<string>();

                ///Configuration read from Supporting folder
                JrnCitationPatternsColl = GlobalMethods.ReadAndStoreFileValuesInArray(GlobalMethods.strJournalDBFilename);
                ///configuration added by Karan End
                string strDocContent = null;


                var strOrganizationDBsage = ConfigurationManager.AppSettings.Get("OrganizationDBsage");
                List<string> OrganizationDBsageCol = new List<string>();

                ///Configuration read from Supporting folder
                OrganizationDBsageCol = GlobalMethods.ReadAndStoreFileValuesInArray(strOrganizationDBsage);

                var strArticleTitleDBsage = ConfigurationManager.AppSettings.Get("ArticleTitleDBsage");
                List<string> ArticleTitleDBsageDBsageCol = new List<string>();

                ///Configuration read from Supporting folder
                ArticleTitleDBsageDBsageCol = GlobalMethods.ReadAndStoreFileValuesInArray(strArticleTitleDBsage);

                // Read the Document Content from Word Document //
                //strDocContent = GlobalMethods.ReadDocumentContent(strDocPath);



                // Load Word Document Content
                mdoc = GlobalMethods.LoadWordDocument(strDocPath);

                strDocContent = mdoc.Content.Text;

                if (strDocContent == null)
                    return;

                // Search the patterns in the document content using Regular Expression
                if (mdoc != null)
                {

                    //GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    List<string> strMatchText = new List<string>();
                    string strSearchRegEx = null;



                    strMatchText.Clear();
                    strSearchRegEx = null;

                    ///configuration added by Karan Start
                    foreach (var item in JrnCitationPatternsColl)
                    {
                        if (item.Trim().Split(' ').Count() > 1)
                        {
                            strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"(" + item + ")");

                            if (strMatchText.Count > 0)
                            {
                                
                                for (int counter = 0; counter < strMatchText.Count; counter++)
                                {
                                    if (strMatchText[counter].Trim() != "")
                                    {
                                        GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter], "", "REF1", "bib_journal", "", true, false, true, true, false);
                                    }
                                }
                            }
                            strMatchText.Clear();
                            strSearchRegEx = null;
                        }
                    }

                    foreach (var item in BokCitationPatternsColl)
                    {
                        //if (item.Trim().Split(' ').Count() > 1)
                        //{


                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"(" + item + ")");


                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                if (strMatchText[counter].Trim() != "")
                                {
                                    GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter], "", "REF1", "bibpubname", "", true, false, true, true, false);
                                }
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;
                        // }
                    }

                    foreach (var item in OrganizationDBsageCol)
                    {
                        if (item.Trim().Split(' ').Count() > 1)
                        {
                            strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"(" + item + ")");

                            if (strMatchText.Count > 0)
                            {
                                for (int counter = 0; counter < strMatchText.Count; counter++)
                                {
                                    if (strMatchText[counter].Trim() != "")
                                    {
                                        GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter], "", "REF1", "bib_organization", "", true, false, true, true, false);
                                    }
                                }
                            }
                            strMatchText.Clear();
                            strSearchRegEx = null;
                        }
                    }


                    foreach (var item in ArticleTitleDBsageDBsageCol)
                    {
                        if (item.Trim().Split(' ').Count() > 1)
                        {
                            strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"(" + item + ")");

                            if (strMatchText.Count > 0)
                            {
                                for (int counter = 0; counter < strMatchText.Count; counter++)
                                {
                                    GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter], "", "REF1", "bib_article", "", true, false, true, true, false);

                                }
                            }
                            strMatchText.Clear();
                            strSearchRegEx = null;
                        }
                    }



                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"((doi\:)[A-Za-z0-9\.\/]+)|((doi\:\s)[A-Za-z0-9\.\/]+)|((DOI\:)[A-Za-z0-9\.\/]+)|((DOI\:\s)[A-Za-z0-9\.\/]+)");
                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter].Trim().TrimStart(')').TrimStart('.').TrimEnd('.').Trim(), "", "REF1", "bib_doi", "", true, false, true, true, false);
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"((doi\:)[A-Za-z0-9\.\-\/\(\)\:]+)|((doi\:\s)[A-Za-z0-9\-\.\/\(\)\:]+)|((DOI\:)[A-Za-z0-9\.\-\/\(\)\:]+)|((DOI\:\s)[A-Za-z0-9\-\.\/\(\)\:]+)");
                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter].Trim().TrimStart(')').TrimStart('.').TrimEnd('.').Trim(), "", "REF1", "bib_doi", "", true, false, true, true, false);
                        }
                    }


                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"(\([0-9]+th\sed\.\))|(\([0-9]+rd\sed\.\))|(\([0-9]+st\sed\.\))|(\([0-9]+nd\sed\.\))");
                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter].Trim().TrimStart('(').TrimEnd(')'), "", "REF1", "bibedition", "", true, false, true, true, false);
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"(\(Ed[\.]\))|(\(Eds[\.]\))");
                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter].Trim(), "", "REF1", "bibtxt", "", true, false, true, true, false);
                        }
                    }


                    //strMatchText.Clear();
                    //strSearchRegEx = null;

                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    GlobalMethods.SearchAndReplace(mdoc, "^p ", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, " ^p", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "<jrn> ^p", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "<jrn> </jrn>", "", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    // GlobalMethods.SearchAndReplace(mdoc, "^p^p", "^p", "", "", "", false, false, true, false, false);//commented on 11020202 For boxstart and BoxEnd style remove. 
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    //GlobalMethods.SearchAndReplace(mdoc, "^g", "^&", "", "", "FIG", false, true, true, false);
                    GlobalMethods.SearchAndReplace(mdoc, "^~", "-", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "", "", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    //GlobalMethods.SearchAndReplace(mdoc, "", "", "BullList", "", "", false, false, false, false, false);//19022020 comment for indend remove.
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    object oMissing = System.Reflection.Missing.Value;

                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;

                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                if (mdoc != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;
                }
                if (GlobalMethods.wordApp != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    ((_Application)GlobalMethods.wordApp).Quit(ref oMissing, ref oMissing, ref oMissing);
                    GlobalMethods.wordApp = null;
                }
            }


        }

        public static void applyCitebibcharSage(string strDocPath, List<string> strMatchText, List<string> singleAuthorWithYear)   //09-09-2020
        {
            Microsoft.Office.Interop.Word.Document mdoc = null;

            try
            {


                string strDocContent = null;

                // Read the Document Content from Word Document //
                //strDocContent = GlobalMethods.ReadDocumentContent(strDocPath);


                // Load Word Document Content
                mdoc = GlobalMethods.LoadWordDocument(strDocPath);

                strDocContent = mdoc.Content.Text;

                if (strDocContent == null)
                    return;

                // Search the patterns in the document content using Regular Expression
                if (mdoc != null)
                {

                    //GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);


                    string strSearchRegEx = null;




                    strSearchRegEx = null;

                    ///configuration added by Karan Start

                    // strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"(\[\d+\])");

                    //if (strMatchText.Count > 0)
                    //{
                    //    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //    {

                    //        //  FindandApplycitebibforINF(mdoc, strMatchText[counter], "", "", "cite_bib", "", true, false, false, false, false);


                    //    }
                    //}
                    //strMatchText.Clear();
                    //strSearchRegEx = null;

                    //strMatchText.Clear();
                    //strSearchRegEx = null;
                    //strSearchRegEx = @"([A-Za-z]{2,}\set\sal\.\s\([0-9]{4}\))";
                    //strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    //if (strMatchText.Count > 0)
                    //{
                    //    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //    {
                    //        if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                    //        {
                    //            FindandApplycitebibforINF(mdoc, strMatchText[counter], "", "", "cite_bib", "", true, false, false, false, false);
                    //        }
                    //    }
                    //}

                    //strMatchText.Clear();
                    //strSearchRegEx = null;
                    //strSearchRegEx = @"([A-Za-zÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÑÒÓÔÕÖÙÚÛÜÝáâãäåçèéêëìíîïðñòóôõöùúûüýÿĀāĂăąĄĆćĈĉĊċČčĎďđĒēĔĕĖėĘęĚěĜĝįĮĭĬīĪĩħħĥĤģĢġĠğĞĴĵĶķĸĹĺĻļĽľĿŀŁłŃńŅņŇňŉŊŋŌōŎŏŐőŔŕŖŗŘřŭŬūŪũŨŦťŤţŢšŠşŞŝŜśŚŮůŰűŲųŴŵŶŷŸŹźŻżŽǍșȘǻǺǺǐǏǎ\-]+\s\&\s[A-Za-zÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÑÒÓÔÕÖÙÚÛÜÝáâãäåçèéêëìíîïðñòóôõöùúûüýÿĀāĂăąĄĆćĈĉĊċČčĎďđĒēĔĕĖėĘęĚěĜĝįĮĭĬīĪĩħħĥĤģĢġĠğĞĴĵĶķĸĹĺĻļĽľĿŀŁłŃńŅņŇňŉŊŋŌōŎŏŐőŔŕŖŗŘřŭŬūŪũŨŦťŤţŢšŠşŞŝŜśŚŮůŰűŲųŴŵŶŷŸŹźŻżŽǍșȘǻǺǺǐǏǎ\-]+\,[\s\ ]{1}[0-9]{4})|([A-Za-z\-\–]+\set al\.\,\s[0-9]{4})|([A-Za-z\–\-]+\,\s[A-Za-z]+\,\s[&]\s[A-Za-z]+\,\s[0-9]{4})";
                    //strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    //if (strMatchText.Count > 0)
                    //{
                    //    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //    {
                    //        FindandApplycitebibforINF(mdoc, strMatchText[counter], "", "", "cite_bib", "", true, false, false, false, false);
                    //    }
                    //}


                    //strMatchText.Clear();
                    //strSearchRegEx = null;
                    //strSearchRegEx = @"([A-Za-z\-\–]+\set al\.\,\s[0-9]{4})";
                    //strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    //if (strMatchText.Count > 0)
                    //{
                    //    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //    {
                    //        //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                    //        //{
                    //        FindandApplycitebibforINF(mdoc, strMatchText[counter], "", "", "cite_bib", "", true, false, false, false, false);
                    //        //}
                    //    }
                    //}

                    //strMatchText.Clear();
                    //strSearchRegEx = null;

                    //strSearchRegEx = @"(\([A-Za-z]+\,\s[0-9]{4}\))";
                    //strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    //if (strMatchText.Count > 0)
                    //{
                    //    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //    {
                    //        //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                    //        //{
                    //        FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart('(').TrimEnd(')'), "", "", "cite_bib", "", true, false, false, false, false);
                    //        //}                            
                    //    }
                    //}

                    //strMatchText.Clear();
                    //strSearchRegEx = null;

                    //strSearchRegEx = @"([A-Za-zá\-\–]+\s[&]\s[A-Za-zá\-]+\,\s[0-9]{4})";
                    //strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    //if (strMatchText.Count > 0)
                    //{
                    //    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //    {
                    //        //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                    //        //{
                    //        FindandApplycitebibforINF(mdoc, strMatchText[counter], "", "", "cite_bib", "", true, false, false, false, false);
                    //        //}
                    //    }
                    //}
                    //strMatchText.Clear();
                    //strSearchRegEx = null;

                    //strSearchRegEx = @"([A-Za-z\-\–]+\,\s[0-9]{4})";
                    //strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    //if (strMatchText.Count > 0)
                    //{
                    //    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //    {
                    //        //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                    //        //{
                    //        FindandApplycitebibforINF(mdoc, strMatchText[counter], "", "", "cite_bib", "", true, false, false, false, false);
                    //        //}
                    //    }
                    //}
                    //strMatchText.Clear();
                    //strSearchRegEx = null;
                    //strSearchRegEx = @"(\([A-Za-z\-\–\s]+\,\s[0-9]{4}\))";
                    //strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    //if (strMatchText.Count > 0)
                    //{
                    //    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //    {
                    //        //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                    //        //{
                    //        FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart('(').TrimEnd(')'), "", "", "cite_bib", "", true, false, false, false, false);
                    //        //}
                    //    }
                    //}


                    //strMatchText.Clear();
                    //strSearchRegEx = null;
                    //strSearchRegEx = @"([A-Za-z]+\,\s[&]\s[A-Za-z]+\,\s[0-9]{4})";
                    //strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    //if (strMatchText.Count > 0)
                    //{
                    //    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //    {
                    //        //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                    //        //{
                    //        FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart('(').TrimEnd(')'), "", "", "cite_bib", "", true, false, false, false, false);
                    //        //}
                    //    }
                    //}
                    //strMatchText.Clear();
                    //strSearchRegEx = null;
                    //strSearchRegEx = @"([A-Za-z\–\-]+\,\s[A-Za-z]+\,\s[&]\s[A-Za-z]+\,\s[0-9]{4})";
                    //strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    //if (strMatchText.Count > 0)
                    //{
                    //    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //    {
                    //        //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                    //        //{
                    //        FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart('(').TrimEnd(')'), "", "", "cite_bib", "", true, false, false, false, false);
                    //        //}
                    //    }
                    //}
                    //strMatchText.Clear();
                    //strSearchRegEx = null;

                    ////Developer Name:Priyanka Vishwakarma,Date:13-10-2020.Requirement:Add Pattern for citebib for sage sample.
                    //strSearchRegEx = @"([A-Za-z\-]{2,}\sand\s[A-Za-z\-]{2,}\s\([0-9]{4}\))|([A-Za-z]{2,}\s\([0-9]{4}\))";
                    //strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    //if (strMatchText.Count > 0)
                    //{
                    //    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //    {
                    //        //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                    //        //{
                    //        FindandApplycitebibforINF(mdoc, strMatchText[counter], "", "", "cite_bib", "", true, false, false, false, false);
                    //        //}
                    //    }
                    //}
                    //strMatchText.Clear();
                    //strSearchRegEx = null;



                    ////-----
                    //strMatchText.Clear();
                    //strSearchRegEx = null;


                    //strSearchRegEx = @"([A-Za-zÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÑÒÓÔÕÖÙÚÛÜÝáâãäåçèéêëìíîïðñòóôõöùúûüýÿĀāĂăąĄĆćĈĉĊċČčĎďđĒēĔĕĖėĘęĚěĜĝįĮĭĬīĪĩħħĥĤģĢġĠğĞĴĵĶķĸĹĺĻļĽľĿŀŁłŃńŅņŇňŉŊŋŌōŎŏŐőŔŕŖŗŘřŭŬūŪũŨŦťŤţŢšŠşŞŝŜśŚŮůŰűŲųŴŵŶŷŸŹźŻżŽǍșȘǻǺǺǐǏǎ\-\–]+\set al\.\,\s[0-9]{4})";
                    //strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    //if (strMatchText.Count > 0)
                    //{
                    //    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //    {
                    //        //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                    //        //{
                    //        FindandApplycitebibforINF(mdoc, strMatchText[counter], "", "", "cite_bib", "", true, false, false, false, false);
                    //        //}
                    //    }
                    //}




                    //strMatchText.Clear();
                    //strSearchRegEx = null;

                    //strSearchRegEx = @"(\([A-Za-zÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÑÒÓÔÕÖÙÚÛÜÝáâãäåçèéêëìíîïðñòóôõöùúûüýÿĀāĂăąĄĆćĈĉĊċČčĎďđĒēĔĕĖėĘęĚěĜĝįĮĭĬīĪĩħħĥĤģĢġĠğĞĴĵĶķĸĹĺĻļĽľĿŀŁłŃńŅņŇňŉŊŋŌōŎŏŐőŔŕŖŗŘřŭŬūŪũŨŦťŤţŢšŠşŞŝŜśŚŮůŰűŲųŴŵŶŷŸŹźŻżŽǍșȘǻǺǺǐǏǎ\-]+\,\s[0-9]{4}\))";
                    //strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    //if (strMatchText.Count > 0)
                    //{
                    //    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //    {
                    //        //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                    //        //{
                    //        FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart('(').TrimEnd(')'), "", "", "cite_bib", "", true, false, false, false, false);
                    //        //}
                    //    }
                    //}
                    //strMatchText.Clear();
                    //strSearchRegEx = null;

                    //strSearchRegEx = @"([A-Za-zÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÑÒÓÔÕÖÙÚÛÜÝáâãäåçèéêëìíîïðñòóôõöùúûüýÿĀāĂăąĄĆćĈĉĊċČčĎďđĒēĔĕĖėĘęĚěĜĝįĮĭĬīĪĩħħĥĤģĢġĠğĞĴĵĶķĸĹĺĻļĽľĿŀŁłŃńŅņŇňŉŊŋŌōŎŏŐőŔŕŖŗŘřŭŬūŪũŨŦťŤţŢšŠşŞŝŜśŚŮůŰűŲųŴŵŶŷŸŹźŻżŽǍșȘǻǺǺǐǏǎ\-\–]+\s[&]\s[A-Za-zÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÑÒÓÔÕÖÙÚÛÜÝáâãäåçèéêëìíîïðñòóôõöùúûüýÿĀāĂăąĄĆćĈĉĊċČčĎďđĒēĔĕĖėĘęĚěĜĝįĮĭĬīĪĩħħĥĤģĢġĠğĞĴĵĶķĸĹĺĻļĽľĿŀŁłŃńŅņŇňŉŊŋŌōŎŏŐőŔŕŖŗŘřŭŬūŪũŨŦťŤţŢšŠşŞŝŜśŚŮůŰűŲųŴŵŶŷŸŹźŻżŽǍșȘǻǺǺǐǏǎ\-]+\,\s[0-9]{4})";
                    //strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    //if (strMatchText.Count > 0)
                    //{
                    //    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //    {
                    //        //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                    //        //{
                    //        FindandApplycitebibforINF(mdoc, strMatchText[counter], "", "", "cite_bib", "", true, false, false, false, false);
                    //        //}
                    //    }
                    //}
                    //strMatchText.Clear();
                    //strSearchRegEx = null;

                    //strSearchRegEx = @"([A-Za-zÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÑÒÓÔÕÖÙÚÛÜÝáâãäåçèéêëìíîïðñòóôõöùúûüýÿĀāĂăąĄĆćĈĉĊċČčĎďđĒēĔĕĖėĘęĚěĜĝįĮĭĬīĪĩħħĥĤģĢġĠğĞĴĵĶķĸĹĺĻļĽľĿŀŁłŃńŅņŇňŉŊŋŌōŎŏŐőŔŕŖŗŘřŭŬūŪũŨŦťŤţŢšŠşŞŝŜśŚŮůŰűŲųŴŵŶŷŸŹźŻżŽǍșȘǻǺǺǐǏǎ\-\–]+\,\s[0-9]{4})";
                    //strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    //if (strMatchText.Count > 0)
                    //{
                    //    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //    {
                    //        //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                    //        //{
                    //        FindandApplycitebibforINF(mdoc, strMatchText[counter], "", "", "cite_bib", "", true, false, false, false, false);
                    //        //}
                    //    }
                    //}
                    //strMatchText.Clear();
                    //strSearchRegEx = null;
                    //strSearchRegEx = @"(\([A-Za-zÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÑÒÓÔÕÖÙÚÛÜÝáâãäåçèéêëìíîïðñòóôõöùúûüýÿĀāĂăąĄĆćĈĉĊċČčĎďđĒēĔĕĖėĘęĚěĜĝįĮĭĬīĪĩħħĥĤģĢġĠğĞĴĵĶķĸĹĺĻļĽľĿŀŁłŃńŅņŇňŉŊŋŌōŎŏŐőŔŕŖŗŘřŭŬūŪũŨŦťŤţŢšŠşŞŝŜśŚŮůŰűŲųŴŵŶŷŸŹźŻżŽǍșȘǻǺǺǐǏǎ\-\–\s]+\,\s[0-9]{4}\))";
                    //strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    //if (strMatchText.Count > 0)
                    //{
                    //    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //    {
                    //        //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                    //        //{
                    //        FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart('(').TrimEnd(')'), "", "", "cite_bib", "", true, false, false, false, false);
                    //        //}
                    //    }
                    //}


                    //strMatchText.Clear();
                    //strSearchRegEx = null;
                    //strSearchRegEx = @"([A-Za-zÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÑÒÓÔÕÖÙÚÛÜÝáâãäåçèéêëìíîïðñòóôõöùúûüýÿĀāĂăąĄĆćĈĉĊċČčĎďđĒēĔĕĖėĘęĚěĜĝįĮĭĬīĪĩħħĥĤģĢġĠğĞĴĵĶķĸĹĺĻļĽľĿŀŁłŃńŅņŇňŉŊŋŌōŎŏŐőŔŕŖŗŘřŭŬūŪũŨŦťŤţŢšŠşŞŝŜśŚŮůŰűŲųŴŵŶŷŸŹźŻżŽǍșȘǻǺǺǐǏǎ\-]+\,\s[&]\s[A-Za-zÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÑÒÓÔÕÖÙÚÛÜÝáâãäåçèéêëìíîïðñòóôõöùúûüýÿĀāĂăąĄĆćĈĉĊċČčĎďđĒēĔĕĖėĘęĚěĜĝįĮĭĬīĪĩħħĥĤģĢġĠğĞĴĵĶķĸĹĺĻļĽľĿŀŁłŃńŅņŇňŉŊŋŌōŎŏŐőŔŕŖŗŘřŭŬūŪũŨŦťŤţŢšŠşŞŝŜśŚŮůŰűŲųŴŵŶŷŸŹźŻżŽǍșȘǻǺǺǐǏǎ\-]+\,\s[0-9]{4})";
                    //strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    //if (strMatchText.Count > 0)
                    //{
                    //    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //    {
                    //        //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                    //        //{
                    //        FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart('(').TrimEnd(')'), "", "", "cite_bib", "", true, false, false, false, false);
                    //        //}
                    //    }
                    //}
                    //strMatchText.Clear();
                    //strSearchRegEx = null;
                    //strSearchRegEx = @"([A-Za-zÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÑÒÓÔÕÖÙÚÛÜÝáâãäåçèéêëìíîïðñòóôõöùúûüýÿĀāĂăąĄĆćĈĉĊċČčĎďđĒēĔĕĖėĘęĚěĜĝįĮĭĬīĪĩħħĥĤģĢġĠğĞĴĵĶķĸĹĺĻļĽľĿŀŁłŃńŅņŇňŉŊŋŌōŎŏŐőŔŕŖŗŘřŭŬūŪũŨŦťŤţŢšŠşŞŝŜśŚŮůŰűŲųŴŵŶŷŸŹźŻżŽǍșȘǻǺǺǐǏǎ\–\-]+\,\s[A-Za-zÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÑÒÓÔÕÖÙÚÛÜÝáâãäåçèéêëìíîïðñòóôõöùúûüýÿĀāĂăąĄĆćĈĉĊċČčĎďđĒēĔĕĖėĘęĚěĜĝįĮĭĬīĪĩħħĥĤģĢġĠğĞĴĵĶķĸĹĺĻļĽľĿŀŁłŃńŅņŇňŉŊŋŌōŎŏŐőŔŕŖŗŘřŭŬūŪũŨŦťŤţŢšŠşŞŝŜśŚŮůŰűŲųŴŵŶŷŸŹźŻżŽǍșȘǻǺǺǐǏǎ\-]+\,\s[&]\s[A-Za-zÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÑÒÓÔÕÖÙÚÛÜÝáâãäåçèéêëìíîïðñòóôõöùúûüýÿĀāĂăąĄĆćĈĉĊċČčĎďđĒēĔĕĖėĘęĚěĜĝįĮĭĬīĪĩħħĥĤģĢġĠğĞĴĵĶķĸĹĺĻļĽľĿŀŁłŃńŅņŇňŉŊŋŌōŎŏŐőŔŕŖŗŘřŭŬūŪũŨŦťŤţŢšŠşŞŝŜśŚŮůŰűŲųŴŵŶŷŸŹźŻżŽǍșȘǻǺǺǐǏǎ\-]+\,\s[0-9]{4})";
                    //strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    //if (strMatchText.Count > 0)
                    //{
                    //    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //    {
                    //        //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                    //        //{
                    //        FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart('(').TrimEnd(')'), "", "", "cite_bib", "", true, false, false, false, false);
                    //        //}
                    //    }
                    //}
                    //strMatchText.Clear();
                    //strSearchRegEx = null;

                    ////Developer Name:Priyanka Vishwakarma,Date:13-10-2020.Requirement:Add Pattern for citebib for sage sample.
                    //strSearchRegEx = @"([A-Za-zÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÑÒÓÔÕÖÙÚÛÜÝáâãäåçèéêëìíîïðñòóôõöùúûüýÿĀāĂăąĄĆćĈĉĊċČčĎďđĒēĔĕĖėĘęĚěĜĝįĮĭĬīĪĩħħĥĤģĢġĠğĞĴĵĶķĸĹĺĻļĽľĿŀŁłŃńŅņŇňŉŊŋŌōŎŏŐőŔŕŖŗŘřŭŬūŪũŨŦťŤţŢšŠşŞŝŜśŚŮůŰűŲųŴŵŶŷŸŹźŻżŽǍșȘǻǺǺǐǏǎ\-]{2,}\sand\s[A-Za-zÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÑÒÓÔÕÖÙÚÛÜÝáâãäåçèéêëìíîïðñòóôõöùúûüýÿĀāĂăąĄĆćĈĉĊċČčĎďđĒēĔĕĖėĘęĚěĜĝįĮĭĬīĪĩħħĥĤģĢġĠğĞĴĵĶķĸĹĺĻļĽľĿŀŁłŃńŅņŇňŉŊŋŌōŎŏŐőŔŕŖŗŘřŭŬūŪũŨŦťŤţŢšŠşŞŝŜśŚŮůŰűŲųŴŵŶŷŸŹźŻżŽǍșȘǻǺǺǐǏǎ\-]{2,}\s\([0-9]{4}\))|([A-Za-zÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÑÒÓÔÕÖÙÚÛÜÝáâãäåçèéêëìíîïðñòóôõöùúûüýÿĀāĂăąĄĆćĈĉĊċČčĎďđĒēĔĕĖėĘęĚěĜĝįĮĭĬīĪĩħħĥĤģĢġĠğĞĴĵĶķĸĹĺĻļĽľĿŀŁłŃńŅņŇňŉŊŋŌōŎŏŐőŔŕŖŗŘřŭŬūŪũŨŦťŤţŢšŠşŞŝŜśŚŮůŰűŲųŴŵŶŷŸŹźŻżŽǍșȘǻǺǺǐǏǎ\-]{2,}\s\([0-9]{4}\))";
                    //strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    //if (strMatchText.Count > 0)
                    //{
                    //    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //    {
                    //        //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                    //        //{
                    //        FindandApplycitebibforINF(mdoc, strMatchText[counter], "", "", "cite_bib", "", true, false, false, false, false);
                    //        // }
                    //    }
                    //}
                    //strMatchText.Clear();
                    //strSearchRegEx = null;
                    //strSearchRegEx = @"([A-Za-z]+\s[\&]\s[A-Za-z]+\s\([0-9]{4}\))";
                    //strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    //if (strMatchText.Count > 0)
                    //{
                    //    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //    {
                    //        //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                    //        //{
                    //        FindandApplycitebibforINF(mdoc, strMatchText[counter], "", "", "cite_bib", "", true, false, false, false, false);
                    //        //}
                    //    }
                    //}
                    //strMatchText.Clear();
                    //strSearchRegEx = null;
                    //strSearchRegEx = @"([A-Za-z]+\s[A-Za-z]+\,\s[0-9]{4}\))";
                    //strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    //if (strMatchText.Count > 0)
                    //{
                    //    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //    {
                    //        //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                    //        //{
                    //        FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimEnd(')'), "", "", "cite_bib", "", true, false, false, false, false);
                    //        //}
                    //    }
                    //}
                    //strMatchText.Clear();
                    //strSearchRegEx = null;
                    //strSearchRegEx = @"([A-Za-z\'\-]+\s\([0-9]{4}\))";
                    //strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    //if (strMatchText.Count > 0)
                    //{
                    //    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //    {
                    //        //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                    //        //{
                    //        FindandApplycitebibforINF(mdoc, strMatchText[counter], "", "", "cite_bib", "", true, false, false, false, false);
                    //        // }
                    //    }
                    //}

                    //strMatchText.Clear();
                    //strSearchRegEx = null;
                    //strSearchRegEx = @"((Tuhiwai)\s[A-Za-z\'\-]+\s\([0-9]{4}\))|(International\sMonetary\sFund\,\s[0-9]{4})";
                    //strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    //if (strMatchText.Count > 0)
                    //{
                    //    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //    {
                    //        //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                    //        //{
                    //        FindandApplycitebibforINF(mdoc, strMatchText[counter], "", "", "cite_bib", "", true, false, false, false, false);
                    //        //}
                    //    }
                    //}

                    //strMatchText.Clear();
                    //strSearchRegEx = null;
                    //strSearchRegEx = @"(\([A-Za-z]+\,\s[A-Za-z]+\,\s[A-Za-z]+\,\s[A-Za-z]+\,\s[\&]\s[A-Za-z]+\,\s[0-9]{4}\))";
                    //strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    //if (strMatchText.Count > 0)
                    //{
                    //    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //    {
                    //        //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                    //        //{
                    //        FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart('(').TrimEnd(')'), "", "", "cite_bib", "", true, false, false, false, false);
                    //        //}
                    //    }
                    //}

                    //strMatchText.Clear();
                    //strSearchRegEx = null;
                    //strSearchRegEx = @"(\([A-Za-z]+\,\s[A-Za-z]+\,\s[A-Za-z]+\,\s[\&]\s[A-Za-z]+\,\s[0-9]{4}\))";
                    //strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    //if (strMatchText.Count > 0)
                    //{
                    //    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //    {
                    //        //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                    //        //{
                    //        FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart('(').TrimEnd(')'), "", "", "cite_bib", "", true, false, false, false, false);
                    //        //}
                    //    }
                    //}

                    //strMatchText.Clear();
                    //strSearchRegEx = null;
                    //strSearchRegEx = @"(\([A-Za-z]+\,\s[A-Za-z]+\,\s[A-Za-z]+\,\s[A-Za-z]+\,\s[A-Za-z]+\,\s[\&]\s[A-Za-z]+\,\s[0-9]{4}\))";
                    //strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    //if (strMatchText.Count > 0)
                    //{
                    //    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //    {
                    //        //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                    //        //{
                    //        FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart('(').TrimEnd(')'), "", "", "cite_bib", "", true, false, false, false, false);
                    //        //}
                    //    }
                    //}

                    //strMatchText.Clear();
                    //strSearchRegEx = null;
                    //strSearchRegEx = @"(\([A-Za-z]+\s[\&][A-Za-z]+\,\s[0-9]{4})";
                    //strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    //if (strMatchText.Count > 0)
                    //{
                    //    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //    {
                    //        //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                    //        //{
                    //        FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart('('), "", "", "cite_bib", "", true, false, false, false, false);
                    //        // }
                    //    }
                    //}

                    //strMatchText.Clear();
                    //strSearchRegEx = null;
                    //strSearchRegEx = @"(OECD\s[A-Za-z]+\s\([0-9]{4}\))";
                    //strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    //if (strMatchText.Count > 0)
                    //{
                    //    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //    {
                    //        //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                    //        //{
                    //        FindandApplycitebibforINF(mdoc, strMatchText[counter], "", "", "cite_bib", "", true, false, false, false, false);
                    //        // }
                    //    }
                    //}



                    //strMatchText.Clear();
                    //strSearchRegEx = null;
                    //strSearchRegEx = @"(\([A-Za-zā\[\]\s]+\,\s[0-9]{4}\))";
                    //strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    //if (strMatchText.Count > 0)
                    //{
                    //    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //    {
                    //        //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                    //        //{
                    //        FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart('(').TrimEnd(')'), "", "", "cite_bib", "", true, false, false, false, false);
                    //        //}
                    //    }
                    //}

                    //strMatchText.Clear();
                    //strSearchRegEx = null;
                    //strSearchRegEx = @"(\([A-Za-z\s\,]+[\&]\s[A-Za-z]+\,\s[0-9]{4}\,)";
                    //strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    //if (strMatchText.Count > 0)
                    //{
                    //    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //    {
                    //        //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                    //        //{
                    //        FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart('(').TrimEnd(','), "", "", "cite_bib", "", true, false, false, false, false);
                    //        //}
                    //    }
                    //}

                    //strMatchText.Clear();
                    //strSearchRegEx = null;
                    //strSearchRegEx = @"(\([A-Za-z\s\,]+[\&]\s[A-Za-z]+\,\s[0-9]{4}\;)";
                    //strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    //if (strMatchText.Count > 0)
                    //{
                    //    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //    {
                    //        //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                    //        //{
                    //        FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart('(').TrimEnd(';'), "", "", "cite_bib", "", true, false, false, false, false);
                    //        //}
                    //    }
                    //}

                    //strMatchText.Clear();
                    //strSearchRegEx = null;
                    //strSearchRegEx = @"(\([A-Za-z]+\,[0-9]{4}\))";
                    //strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    //if (strMatchText.Count > 0)
                    //{
                    //    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //    {
                    //        //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                    //        //{
                    //        FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart('(').TrimEnd(')'), "", "", "cite_bib", "", true, false, false, false, false);
                    //        //}
                    //    }
                    //}

                    //strMatchText.Clear();
                    //strSearchRegEx = null;
                    //strSearchRegEx = @"([A-Za-z\s\,]+[\&]\s[A-Za-z]+\,\s\([0-9]{4}\))";
                    //strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    //if (strMatchText.Count > 0)
                    //{
                    //    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //    {
                    //        //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                    //        //{
                    //        FindandApplycitebibforINF(mdoc, strMatchText[counter], "", "", "cite_bib", "", true, false, false, false, false);
                    //        //}
                    //    }
                    //}

                    //strMatchText.Clear();
                    //strSearchRegEx = null;
                    //strSearchRegEx = @"(\;[A-Za-z\s]+\,\s[0-9]{4}\;)";
                    //strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    //if (strMatchText.Count > 0)
                    //{
                    //    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //    {
                    //        //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                    //        //{
                    //        FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart(';').TrimEnd(';').Trim(), "", "", "cite_bib", "", true, false, false, false, false);
                    //        //}
                    //    }
                    //}

                    //strMatchText.Clear();
                    //strSearchRegEx = null;
                    //strSearchRegEx = @"(\;\s[A-Za-z\,\s]+[\&]\s[A-Za-z]+\,\s[0-9]{4})";
                    //strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    //if (strMatchText.Count > 0)
                    //{
                    //    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //    {
                    //        //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                    //        //{
                    //        FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart(';').Trim(), "", "", "cite_bib", "", true, false, false, false, false);
                    //        //}
                    //    }
                    //}

                    //strMatchText.Clear();
                    //strSearchRegEx = null;
                    //strSearchRegEx = @"([A-Za-z]+\sand\s[A-Za-z]+\s\([0-9]{4}\))"; //Developer Name:Priyanka Vishwakarma,Date:26-03-2021,Requirement:Add pattern for apply citebib char style
                    //strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    //if (strMatchText.Count > 0)
                    //{
                    //    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //    {
                    //        //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                    //        //{
                    //        FindandApplycitebibforINF(mdoc, strMatchText[counter], "", "", "cite_bib", "", true, false, false, false, false);
                    //        //}
                    //    }
                    //}

                    //strMatchText.Clear();
                    //strSearchRegEx = null;
                    //strSearchRegEx = @"(\([A-Za-z]+\s[\&]\s[A-Za-z]+\s[A-Za-z]+\,\s[0-9]{4})";
                    //strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    //if (strMatchText.Count > 0)
                    //{
                    //    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //    {
                    //        //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                    //        //{
                    //        FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart('('), "", "", "cite_bib", "", true, false, false, false, false);
                    //        //}
                    //    }
                    //}

                    //strMatchText.Clear();
                    //strSearchRegEx = null;
                    //strSearchRegEx = @"(\([A-Za-z]+\s[\&][A-Za-z]+\s[0-9]{4}\))";
                    //strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    //if (strMatchText.Count > 0)
                    //{
                    //    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //    {
                    //        //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                    //        //{
                    //        FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart('(').TrimEnd(')'), "", "", "cite_bib", "", true, false, false, false, false);
                    //        // }
                    //    }
                    //}
                    //strMatchText.Clear();
                    //strSearchRegEx = null;
                    //strSearchRegEx = @"(\([A-Za-z\,\s]+[\&]\s[A-Za-z]+\s[0-9]{4}\))";
                    //strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    //if (strMatchText.Count > 0)
                    //{
                    //    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //    {
                    //        //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                    //        //{
                    //        FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart('(').TrimEnd(')'), "", "", "cite_bib", "", true, false, false, false, false);
                    //        //}
                    //    }
                    //}

                    //strMatchText.Clear();
                    //strSearchRegEx = null;
                    //strSearchRegEx = @"(\([A-Za-z\s]+[\&]\s[A-Za-z]+\,\s[0-9]{4}\))";
                    //strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    //if (strMatchText.Count > 0)
                    //{
                    //    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //    {
                    //        //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                    //        //{
                    //        FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart('(').TrimEnd(')'), "", "", "cite_bib", "", true, false, false, false, false);
                    //        //}
                    //    }
                    //}
                    //strMatchText.Clear();
                    //strSearchRegEx = null;
                    //strSearchRegEx = @"([A-Za-zō\-\‘\’]+\s\([0-9]{4}\))";
                    //strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    //if (strMatchText.Count > 0)
                    //{
                    //    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //    {
                    //        if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                    //        {
                    //            if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                    //            {
                    //                FindandApplycitebibforINF(mdoc, strMatchText[counter], "", "", "cite_bib", "", true, false, false, false, false);
                    //            }
                    //        }
                    //    }
                    //}
                    //strMatchText.Clear();
                    //strSearchRegEx = null;

                    //strSearchRegEx = @"([A-Za-z]+\s[\&]\s[A-Za-z]+\,\s[0-9]{4}[a-z])";
                    //strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    //if (strMatchText.Count > 0)
                    //{
                    //    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //    {
                    //        if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                    //        {
                    //            FindandApplycitebibforINF(mdoc, strMatchText[counter], "", "", "cite_bib", "", true, false, false, false, false);
                    //        }
                    //    }
                    //}
                    //strMatchText.Clear();
                    //strSearchRegEx = null;

                    //strSearchRegEx = @"([A-Za-z]+\s(and)\s[A-Za-z]+\s\([0-9]{4}\,\s[A-Z][a-z\.]+\s[0-9]{2}\))";
                    //strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    //if (strMatchText.Count > 0)
                    //{
                    //    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //    {
                    //        if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                    //        {
                    //            FindandApplycitebibforINF(mdoc, strMatchText[counter], "", "", "cite_bib", "", true, false, false, false, false);
                    //        }
                    //    }
                    //}
                    //strMatchText.Clear();
                    //strSearchRegEx = null;

                    //strSearchRegEx = @"([A-Za-z]+\s(and)\s[A-Za-z\’]+\s\([0-9]{4}\))";
                    //strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    //if (strMatchText.Count > 0)
                    //{
                    //    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //    {
                    //        if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                    //        {
                    //            FindandApplycitebibforINF(mdoc, strMatchText[counter], "", "", "cite_bib", "", true, false, false, false, false);
                    //        }
                    //    }
                    //}
                    //strMatchText.Clear();
                    //strSearchRegEx = null;

                    //strSearchRegEx = @"(\([A-Z]+\,\s[A-Za-z\s]+\,\s[0-9]{4}\;)";
                    //strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    //if (strMatchText.Count > 0)
                    //{
                    //    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //    {
                    //        if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                    //        {
                    //            FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart('(').TrimEnd(';').Trim(), "", "", "cite_bib", "", true, false, false, false, false);
                    //        }
                    //    }
                    //}
                    //strMatchText.Clear();
                    //strSearchRegEx = null;
                    //strSearchRegEx = @"(\;\s[A-Za-z\-\s]+\,\s[0-9]{4}\))";
                    //strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    //if (strMatchText.Count > 0)
                    //{
                    //    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //    {
                    //        if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                    //        {
                    //            FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart(';').TrimEnd(')').Trim(), "", "", "cite_bib", "", true, false, false, false, false);
                    //        }
                    //    }
                    //}
                    //strMatchText.Clear();
                    //strSearchRegEx = null;

                    //strSearchRegEx = @"(\([A-Za-z\s]+\,\s[0-9]{4}\;)";
                    //strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    //if (strMatchText.Count > 0)
                    //{
                    //    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //    {
                    //        if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                    //        {
                    //            FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart('(').TrimEnd(';'), "", "", "cite_bib", "", true, false, false, false, false);
                    //        }
                    //    }
                    //}
                    //strMatchText.Clear();
                    //strSearchRegEx = null;


                    //strMatchText.Clear();
                    //strSearchRegEx = null;

                    //strSearchRegEx = @"(\([A-Za-z\.]+\s[\&]\s[A-Za-z]+\,\s[0-9]{4}\))";
                    //strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    //if (strMatchText.Count > 0)
                    //{
                    //    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //    {
                    //        if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                    //        {
                    //            FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart('(').TrimEnd(')'), "", "", "cite_bib", "", true, false, false, false, false);
                    //        }
                    //    }
                    //}
                    //strMatchText.Clear();
                    //strSearchRegEx = null;

                    //strMatchText.Clear();
                    //strSearchRegEx = null;

                    //strSearchRegEx = @"(\([A-Za-z]+\.\s[\&]\s{1,}[A-Za-z]+\,\s[0-9]{4}\))";
                    //strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    //if (strMatchText.Count > 0)
                    //{
                    //    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //    {
                    //        if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                    //        {
                    //            FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart('(').TrimEnd(')'), "", "", "cite_bib", "", true, false, false, false, false);
                    //        }
                    //    }
                    //}
                    //strMatchText.Clear();
                    //strSearchRegEx = null;
                    ////Developer Name:Priyanka Vishwakarma,Date:02-04-2021,Requiremnt add pattern for mark citebib for sageindia input
                    //strSearchRegEx = @"([A-Za-zÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÑÒÓÔÕÖÙÚÛÜÝáâãäåçèéêëìíîïðñòóôõöùúûüýÿĀāĂăąĄĆćĈĉĊċČčĎďđĒēĔĕĖėĘęĚěĜĝįĮĭĬīĪĩħħĥĤģĢġĠğĞĴĵĶķĸĹĺĻļĽľĿŀŁłŃńŅņŇňŉŊŋŌōŎŏŐőŔŕŖŗŘřŭŬūŪũŨŦťŤţŢšŠşŞŝŜśŚŮůŰűŲųŴŵŶŷŸŹźŻżŽǍșȘǻǺǺǐǏǎ\-\–\’]+\sand\s[A-Za-zÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÑÒÓÔÕÖÙÚÛÜÝáâãäåçèéêëìíîïðñòóôõöùúûüýÿĀāĂăąĄĆćĈĉĊċČčĎďđĒēĔĕĖėĘęĚěĜĝįĮĭĬīĪĩħħĥĤģĢġĠğĞĴĵĶķĸĹĺĻļĽľĿŀŁłŃńŅņŇňŉŊŋŌōŎŏŐőŔŕŖŗŘřŭŬūŪũŨŦťŤţŢšŠşŞŝŜśŚŮůŰűŲųŴŵŶŷŸŹźŻżŽǍșȘǻǺǺǐǏǎ\-\–\’]+\s\([0-9]{4})|([A-Za-zÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÑÒÓÔÕÖÙÚÛÜÝáâãäåçèéêëìíîïðñòóôõöùúûüýÿĀāĂăąĄĆćĈĉĊċČčĎďđĒēĔĕĖėĘęĚěĜĝįĮĭĬīĪĩħħĥĤģĢġĠğĞĴĵĶķĸĹĺĻļĽľĿŀŁłŃńŅņŇňŉŊŋŌōŎŏŐőŔŕŖŗŘřŭŬūŪũŨŦťŤţŢšŠşŞŝŜśŚŮůŰűŲųŴŵŶŷŸŹźŻżŽǍșȘǻǺǺǐǏǎ\-\–\’]+\s\([0-9]{4})";
                    //strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    //if (strMatchText.Count > 0)
                    //{
                    //    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //    {
                    //        if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                    //        {
                    //            FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart('(').TrimEnd(')'), "", "", "cite_bib", "", true, false, false, false, false);
                    //        }
                    //    }
                    //}
                    //strMatchText.Clear();
                    //strSearchRegEx = null;

                    //strSearchRegEx = @"((de|van|De|Van)\s[A-Za-zÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÑÒÓÔÕÖÙÚÛÜÝáâãäåçèéêëìíîïðñòóôõöùúûüýÿĀāĂăąĄĆćĈĉĊċČčĎďđĒēĔĕĖėĘęĚěĜĝįĮĭĬīĪĩħħĥĤģĢġĠğĞĴĵĶķĸĹĺĻļĽľĿŀŁłŃńŅņŇňŉŊŋŌōŎŏŐőŔŕŖŗŘřŭŬūŪũŨŦťŤţŢšŠşŞŝŜśŚŮůŰűŲųŴŵŶŷŸŹźŻżŽǍșȘǻǺǺǐǏǎ\-\–\’]+\s\([0-9]{4})|([A-Za-zÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÑÒÓÔÕÖÙÚÛÜÝáâãäåçèéêëìíîïðñòóôõöùúûüýÿĀāĂăąĄĆćĈĉĊċČčĎďđĒēĔĕĖėĘęĚěĜĝįĮĭĬīĪĩħħĥĤģĢġĠğĞĴĵĶķĸĹĺĻļĽľĿŀŁłŃńŅņŇňŉŊŋŌōŎŏŐőŔŕŖŗŘřŭŬūŪũŨŦťŤţŢšŠşŞŝŜśŚŮůŰűŲųŴŵŶŷŸŹźŻżŽǍșȘǻǺǺǐǏǎ\-\–\’]+\,\s[0-9]{4}\,\s[0-9]{4})";
                    //strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    //if (strMatchText.Count > 0)
                    //{
                    //    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //    {
                    //        if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                    //        {
                    //            FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart('(').TrimEnd(')'), "", "", "cite_bib", "", true, false, false, false, false);
                    //        }
                    //    }
                    //}
                    //strMatchText.Clear();
                    //strSearchRegEx = null;
                    //strSearchRegEx = @"([A-Za-zÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÑÒÓÔÕÖÙÚÛÜÝáâãäåçèéêëìíîïðñòóôõöùúûüýÿĀāĂăąĄĆćĈĉĊċČčĎďđĒēĔĕĖėĘęĚěĜĝįĮĭĬīĪĩħħĥĤģĢġĠğĞĴĵĶķĸĹĺĻļĽľĿŀŁłŃńŅņŇňŉŊŋŌōŎŏŐőŔŕŖŗŘřŭŬūŪũŨŦťŤţŢšŠşŞŝŜśŚŮůŰűŲųŴŵŶŷŸŹźŻżŽǍșȘǻǺǺǐǏǎ\–\-\’]+\s[0-9]{4}(\;|\)))";
                    //strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    //if (strMatchText.Count > 0)
                    //{
                    //    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //    {
                    //        if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                    //        {
                    //            FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart('(').TrimEnd(')').TrimEnd(';'), "", "", "cite_bib", "", true, false, false, false, false);
                    //        }
                    //    }
                    //}
                    //strMatchText.Clear();
                    //strSearchRegEx = null;
                    //strSearchRegEx = @"([A-Za-zÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÑÒÓÔÕÖÙÚÛÜÝáâãäåçèéêëìíîïðñòóôõöùúûüýÿĀāĂăąĄĆćĈĉĊċČčĎďđĒēĔĕĖėĘęĚěĜĝįĮĭĬīĪĩħħĥĤģĢġĠğĞĴĵĶķĸĹĺĻļĽľĿŀŁłŃńŅņŇňŉŊŋŌōŎŏŐőŔŕŖŗŘřŭŬūŪũŨŦťŤţŢšŠşŞŝŜśŚŮůŰűŲųŴŵŶŷŸŹźŻżŽǍșȘǻǺǺǐǏǎ\–\-\’]+\,\s[A-Za-zÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÑÒÓÔÕÖÙÚÛÜÝáâãäåçèéêëìíîïðñòóôõöùúûüýÿĀāĂăąĄĆćĈĉĊċČčĎďđĒēĔĕĖėĘęĚěĜĝįĮĭĬīĪĩħħĥĤģĢġĠğĞĴĵĶķĸĹĺĻļĽľĿŀŁłŃńŅņŇňŉŊŋŌōŎŏŐőŔŕŖŗŘřŭŬūŪũŨŦťŤţŢšŠşŞŝŜśŚŮůŰűŲųŴŵŶŷŸŹźŻżŽǍșȘǻǺǺǐǏǎ\–\-\’]+\,\sand\s[A-Za-zÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÑÒÓÔÕÖÙÚÛÜÝáâãäåçèéêëìíîïðñòóôõöùúûüýÿĀāĂăąĄĆćĈĉĊċČčĎďđĒēĔĕĖėĘęĚěĜĝįĮĭĬīĪĩħħĥĤģĢġĠğĞĴĵĶķĸĹĺĻļĽľĿŀŁłŃńŅņŇňŉŊŋŌōŎŏŐőŔŕŖŗŘřŭŬūŪũŨŦťŤţŢšŠşŞŝŜśŚŮůŰűŲųŴŵŶŷŸŹźŻżŽǍșȘǻǺǺǐǏǎ\–\-\’]+\s\([0-9]{4}\))";
                    //strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    //if (strMatchText.Count > 0)
                    //{
                    //    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //    {
                    //        if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                    //        {
                    //            FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart('(').TrimEnd(')').TrimEnd(';'), "", "", "cite_bib", "", true, false, false, false, false);
                    //        }
                    //    }
                    //}
                    //strMatchText.Clear();
                    //strSearchRegEx = null;
                    //strSearchRegEx = @"(\([A-Za-zÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÑÒÓÔÕÖÙÚÛÜÝáâãäåçèéêëìíîïðñòóôõöùúûüýÿĀāĂăąĄĆćĈĉĊċČčĎďđĒēĔĕĖėĘęĚěĜĝįĮĭĬīĪĩħħĥĤģĢġĠğĞĴĵĶķĸĹĺĻļĽľĿŀŁłŃńŅņŇňŉŊŋŌōŎŏŐőŔŕŖŗŘřŭŬūŪũŨŦťŤţŢšŠşŞŝŜśŚŮůŰűŲųŴŵŶŷŸŹźŻżŽǍșȘǻǺǺǐǏǎ\–\-\’]+\sand\s[A-Za-zÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÑÒÓÔÕÖÙÚÛÜÝáâãäåçèéêëìíîïðñòóôõöùúûüýÿĀāĂăąĄĆćĈĉĊċČčĎďđĒēĔĕĖėĘęĚěĜĝįĮĭĬīĪĩħħĥĤģĢġĠğĞĴĵĶķĸĹĺĻļĽľĿŀŁłŃńŅņŇňŉŊŋŌōŎŏŐőŔŕŖŗŘřŭŬūŪũŨŦťŤţŢšŠşŞŝŜśŚŮůŰűŲųŴŵŶŷŸŹźŻżŽǍșȘǻǺǺǐǏǎ\–\-\’]+\s[0-9]{4}\))";
                    //strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    //if (strMatchText.Count > 0)
                    //{
                    //    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //    {
                    //        if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                    //        {
                    //            FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart('(').TrimEnd(')').TrimEnd(';'), "", "", "cite_bib", "", true, false, false, false, false);
                    //        }
                    //    }
                    //}
                    //strMatchText.Clear();
                    //strSearchRegEx = null;

                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strSearchRegEx = @"([A-Za-z]+\,\s[A-Za-z]+\,\sand\s[A-Za-z]+\s\([0-9]{4}\))";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                            {
                                FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart('(').TrimEnd(')').TrimEnd(';'), "", "", "cite_bib", "", true, false, false, false, false);
                            }
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strSearchRegEx = @"(\;\s[A-Za-z]+\sand\s[A-Za-z\s\-]+[0-9]{4})\)";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                            {
                                FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart('(').TrimEnd(')').TrimEnd(';'), "", "", "cite_bib", "", true, false, false, false, false);
                            }
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strSearchRegEx = @"(\([A-Za-z]+\s[0-9]{4}\))";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                            {
                                FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart('(').TrimEnd(')').TrimEnd(';'), "", "", "cite_bib", "", true, false, false, false, false);
                            }
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strSearchRegEx = @"(\([A-Za-z]+\s[0-9]{4}\;)";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                            {
                                FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart('(').TrimEnd(')').TrimEnd(';'), "", "", "cite_bib", "", true, false, false, false, false);
                            }
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strSearchRegEx = @"(\([A-Za-z]+\set al\.\s[0-9]{4}\))";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                            {
                                FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart('(').TrimEnd(')').TrimEnd(';'), "", "", "cite_bib", "", true, false, false, false, false);
                            }
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strSearchRegEx = @"(\([A-Za-z]+\set al\.\s[0-9]{4}\))";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                            {
                                FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart('(').TrimEnd(')').TrimEnd(';'), "", "", "cite_bib", "", true, false, false, false, false);
                            }
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strSearchRegEx = @"([A-Za-z]+\set\sal\.\s\([0-9]{4}\))";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                            {
                                FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart('(').TrimEnd(')').TrimEnd(';'), "", "", "cite_bib", "", true, false, false, false, false);
                            }
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strSearchRegEx = @"([A-Za-z]+\sand\s[A-Za-z]+\s\([0-9]{4}\))";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                            {
                                FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart('(').TrimEnd(')').TrimEnd(';'), "", "", "cite_bib", "", true, false, false, false, false);
                            }
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;
                   
                    GlobalMethods.wordApp.Selection.HomeKey(Microsoft.Office.Interop.Word.WdUnits.wdStory);

                    GlobalMethods.SearchAndReplace(mdoc, "^p ", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(Microsoft.Office.Interop.Word.WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, " ^p", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(Microsoft.Office.Interop.Word.WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "<jrn> ^p", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(Microsoft.Office.Interop.Word.WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "<jrn> </jrn>", "", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(Microsoft.Office.Interop.Word.WdUnits.wdStory);
                    // GlobalMethods.SearchAndReplace(mdoc, "^p^p", "^p", "", "", "", false, false, true, false, false);//commented on 11020202 For boxstart and BoxEnd style remove. 
                    GlobalMethods.wordApp.Selection.HomeKey(Microsoft.Office.Interop.Word.WdUnits.wdStory);
                    //GlobalMethods.SearchAndReplace(mdoc, "^g", "^&", "", "", "FIG", false, true, true, false);
                    GlobalMethods.SearchAndReplace(mdoc, "^~", "-", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(Microsoft.Office.Interop.Word.WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "", "", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(Microsoft.Office.Interop.Word.WdUnits.wdStory);
                    //GlobalMethods.SearchAndReplace(mdoc, "", "", "BullList", "", "", false, false, false, false, false);//19022020 comment for indend remove.
                    GlobalMethods.wordApp.Selection.HomeKey(Microsoft.Office.Interop.Word.WdUnits.wdStory);

                    object oMissing = System.Reflection.Missing.Value;

                    object saveChanges = Microsoft.Office.Interop.Word.WdSaveOptions.wdSaveChanges;
                    ((Microsoft.Office.Interop.Word._Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;

                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                if (mdoc != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    object saveChanges = Microsoft.Office.Interop.Word.WdSaveOptions.wdSaveChanges;
                    ((Microsoft.Office.Interop.Word._Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;
                }
                if (GlobalMethods.wordApp != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    ((Microsoft.Office.Interop.Word._Application)GlobalMethods.wordApp).Quit(ref oMissing, ref oMissing, ref oMissing);
                    GlobalMethods.wordApp = null;
                }
            }


        }
        public static bool FindandApplycitebibforINF(Microsoft.Office.Interop.Word.Document oActiveDoc, string strSearchText, string strReplaceText, string strSearchInParaStyle, string strReplaceCharStyle, string strReplaceParaStyle, bool bCharStyle, bool bParaStyle, bool bReplaceAll, bool bGeneralCrosslink, bool bMatchWildCard)
        {
            // Clear Previous searched settings from Word Find dialog box
            //ClearFindAndReplaceParameters(oActiveDoc); // not required as of now //

            // get the range of the curent paragraph
            Range rngDoc = oActiveDoc.Range();

            // setup Microsoft Word Find based upon
            // Regular Expression Match
            rngDoc.Find.ClearFormatting();
            rngDoc.Find.Replacement.ClearFormatting();
            rngDoc.Find.Forward = true;
            rngDoc.Find.MatchWildcards = bMatchWildCard;
            List<string> strList = new List<string>();

            if (strSearchText != "")
                rngDoc.Find.Text = strSearchText;

            if (strReplaceText != "")
                rngDoc.Find.Replacement.Text = strReplaceText;

            if (bReplaceAll == true && bGeneralCrosslink == true)
            {
                if (strSearchInParaStyle != "")
                    rngDoc.Find.set_Style(strSearchInParaStyle);

                if (bParaStyle == true)
                    rngDoc.Find.Replacement.set_Style(strReplaceParaStyle);

                if (bCharStyle == true)
                    rngDoc.Find.Replacement.set_Style(strReplaceCharStyle);
            }

            if (bGeneralCrosslink == false)
            {
                if (strSearchInParaStyle != "")
                    rngDoc.Find.set_Style(strSearchInParaStyle);

                if (bCharStyle == true)
                    rngDoc.Find.Replacement.set_Style(strReplaceCharStyle);

                if (bParaStyle == true)
                    rngDoc.Find.Replacement.set_Style(strReplaceParaStyle);
            }

            if (bReplaceAll == false)
            {
                if (strSearchInParaStyle != "")
                    rngDoc.Find.set_Style(strSearchInParaStyle);

                if (bParaStyle == true)
                    rngDoc.Find.Replacement.set_Style(strReplaceParaStyle);

                if (bCharStyle == true)
                    rngDoc.Find.Replacement.set_Style(strReplaceCharStyle);
            }

            // make search case sensitive
            object caseSensitive = "0";
            object missingValue = Type.Missing;

            rngDoc.Find.Wrap = Microsoft.Office.Interop.Word.WdFindWrap.wdFindStop;

            // wild cards
            object matchWildCards = Type.Missing;

            object replaceAll = Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll;
            //object replaceOne = Microsoft.Office.Interop.Word.WdReplace.wdReplaceOne;


            bool bBold = false;
            bool bItalic = false;

            if (bReplaceAll == true)
            {
                // find the text in the word document
                rngDoc.Find.Execute(ref missingValue, ref missingValue,
                    ref missingValue, ref missingValue, ref missingValue,
                    ref missingValue, ref missingValue, ref missingValue,
                    ref missingValue, ref missingValue, replaceAll,
                    ref missingValue, ref missingValue, ref missingValue,
                    ref missingValue);
            }
            else
            {
                rngDoc.Find.Execute(ref missingValue, ref caseSensitive,
                       ref missingValue, ref missingValue, ref missingValue,
                       ref missingValue, ref missingValue, ref missingValue,
                       ref missingValue, ref missingValue, missingValue,
                       ref missingValue, ref missingValue, ref missingValue,
                       ref missingValue);

                // we found the text
                if (rngDoc.Find.Found)
                {
                    do
                    {
                        bBold = false;
                        bItalic = false;

                        if (rngDoc.Bold == -1)
                        {
                            bBold = true;
                        }

                        if (rngDoc.Italic == -1)
                        {
                            bItalic = true;
                        }

                        if (rngDoc.ParagraphStyle.NameLocal != "REF1" && rngDoc.ParagraphStyle.NameLocal != "CORR" && rngDoc.ParagraphStyle.NameLocal != "AU" && rngDoc.ParagraphStyle.NameLocal != "AFFL" && rngDoc.ParagraphStyle.NameLocal != "FTN")
                        {
                            if (strReplaceCharStyle != "")
                            {
                                rngDoc.set_Style(strReplaceCharStyle);
                            }
                        }

                        if (strSearchInParaStyle == rngDoc.ParagraphStyle.NameLocal)
                        {
                            if (strReplaceCharStyle != "")
                            {
                                rngDoc.set_Style(strReplaceCharStyle);
                            }
                        }

                        if (rngDoc.ParagraphStyle.NameLocal == "BullList")
                        {
                            rngDoc.ListFormat.RemoveNumbers(NumberType: WdNumberType.wdNumberParagraph);
                        }

                        if (bBold)
                        {
                            rngDoc.Bold = -1;
                            bBold = false;
                        }

                        if (bItalic)
                        {
                            rngDoc.Italic = -1;
                            bItalic = false;
                        }

                        rngDoc.Move();

                        rngDoc.Find.Execute(ref missingValue, ref caseSensitive,
                        ref missingValue, ref missingValue, ref missingValue,
                        ref missingValue, ref missingValue, ref missingValue,
                        ref missingValue, ref missingValue, missingValue,
                        ref missingValue, ref missingValue, ref missingValue,
                        ref missingValue);

                    } while (rngDoc.Find.Found);

                    return true;
                }
            }


            return false;


        }
        public static void GeneralSearchAndReplaceInRef(string strDocPath)
        {
            Microsoft.Office.Interop.Word.Document mdoc = null;

            try
            {

                string strDocContent = null;
                mdoc = GlobalMethods.LoadWordDocument(strDocPath);

                strDocContent = mdoc.Content.Text;

                if (strDocContent == null)
                    return;

                // Search the patterns in the document content using Regular Expression
                if (mdoc != null)
                {

                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "Available from: 10.", "DOI: 10.", "REF1", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "Available from:10.", "DOI: 10.", "REF1", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "Availablefrom:10.", "DOI: 10.", "REF1", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "Available from: https://doi.org/", "DOI: ", "REF1", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "Available from:https://doi.org/", "DOI: ", "REF1", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "Availablefrom:https://doi.org/", "DOI: ", "REF1", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "Available from: http://doi.org/", "DOI: ", "REF1", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "Available from:http://doi.org/", "DOI: ", "REF1", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "Availablefrom:http://doi.org/10.", "DOI: 10.", "REF1", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "Available from:h", "Available from: h", "REF1", "", "", false, false, true, false, false);

                    object oMissing = System.Reflection.Missing.Value;

                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;

                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                if (mdoc != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;
                }
                if (GlobalMethods.wordApp != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    ((_Application)GlobalMethods.wordApp).Quit(ref oMissing, ref oMissing, ref oMissing);
                    GlobalMethods.wordApp = null;
                }
            }


        }
        public static void ReferenceSearchAndReplaceVolumeIssueForJaypeeBasisOftextfile(string strDocPath)
        {
            Microsoft.Office.Interop.Word.Document mdoc = null;
            try
            {
                var strVolumeIssuePagerangeDBFilename = ConfigurationManager.AppSettings.Get("ListOfVolumeIssuePageRangePatternWithStyles");
                var JrnPatternsColl = GlobalMethods.ReadAndStoreFileValuesInArray(strVolumeIssuePagerangeDBFilename);
                string strDocContent = null;
                mdoc = GlobalMethods.LoadWordDocument(strDocPath);

                strDocContent = mdoc.Content.Text;

                if (strDocContent == null)
                    return;

                // Search the patterns in the document content using Regular Expression
                if (mdoc != null)
                {

                    //GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    List<string> strMatchText = new List<string>();
                    string strSearchRegEx = null;



                    foreach (var item in JrnPatternsColl)
                    {
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, Regex.Split(item, "<S>").FirstOrDefault());//Developer Name:Priyanka Vishwakarma,Dayte:12-10-2021, Requirement:add condiiton for read pattern from  file

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                if (strMatchText[counter].TrimStart().ToLower().Trim().StartsWith("doi:"))
                                {
                                    if (strMatchText[counter].TrimStart().Contains("/"))
                                    {
                                        GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter].TrimStart().TrimStart(')').TrimStart('.').TrimEnd('.').Trim().Replace("doi: ", "").Replace("doi:", "").Replace("DOI: ", "").Replace("DOI:", ""), "", "REF1", "bib_doi", "", true, false, true, true, false);
                                    }
                                }
                                else
                                {
                                    GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter].TrimStart(), "", "REF1", "bib_volume", "", true, false, true, true, false);
                                }
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;
                    }

                    //strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"((doi\:)[A-Za-z0-9\.\-\/\(\)\:]+)|((doi\:\s)[A-Za-z0-9\-\.\/\(\)\:]+)|((DOI\:)[A-Za-z0-9\.\-\/\(\)\:]+)|((DOI\:\s)[A-Za-z0-9\-\.\/\(\)\:]+)");

                    //if (strMatchText.Count > 0)
                    //{
                    //    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //    {
                    //        GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter].TrimStart(), "", "REF1", "bib_doi", "", true, false, true, true, false);
                    //    }
                    //}
                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strMatchText.Clear();
                    strSearchRegEx = null;


                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    GlobalMethods.SearchAndReplace(mdoc, "^p ", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, " ^p", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "<jrn> ^p", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "<jrn> </jrn>", "", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    // GlobalMethods.SearchAndReplace(mdoc, "^p^p", "^p", "", "", "", false, false, true, false, false);//commented on 11020202 For boxstart and BoxEnd style remove. 
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    //GlobalMethods.SearchAndReplace(mdoc, "^g", "^&", "", "", "FIG", false, true, true, false);
                    GlobalMethods.SearchAndReplace(mdoc, "^~", "-", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "", "", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    //GlobalMethods.SearchAndReplace(mdoc, "", "", "BullList", "", "", false, false, false, false, false);//19022020 comment for indend remove.
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    object oMissing = System.Reflection.Missing.Value;

                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;

                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                if (mdoc != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;
                }
                if (GlobalMethods.wordApp != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    ((_Application)GlobalMethods.wordApp).Quit(ref oMissing, ref oMissing, ref oMissing);
                    GlobalMethods.wordApp = null;
                }
            }


        }
        public static void ReferenceSearchAndReplaceSurnameFnameForJaypee(string strDocPath)
        {
            Microsoft.Office.Interop.Word.Document mdoc = null;
            try
            {
                string RefPatternSunameFnameFile = "";
                var strSurnameFnameFilename = ConfigurationManager.AppSettings.Get("ListOfSunameFnamePattern");
                var JrnPatternsColl = GlobalMethods.ReadAndStoreFileValuesInArray(strSurnameFnameFilename);

                string strDocContent = null;
                mdoc = GlobalMethods.LoadWordDocument(strDocPath);

                strDocContent = mdoc.Content.Text;

                if (strDocContent == null)
                    return;

                // Search the patterns in the document content using Regular Expression
                if (mdoc != null)
                {

                    //GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    List<string> strMatchText = new List<string>();
                    string strSearchRegEx = null;



                    foreach (var item in JrnPatternsColl)
                    {
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, Regex.Split(item, "<S>").FirstOrDefault());//Developer Name:Priyanka Vishwakarma,Dayte:12-10-2021, Requirement:add condiiton for read pattern from  file

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                if (strMatchText[counter].TrimStart().Trim() == "et al." || strMatchText[counter].TrimStart().Trim() == "et al," || strMatchText[counter].TrimStart().Trim() == "et al;")
                                {
                                    GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter].TrimStart(), "", "REF1", "bib_etal", "", true, false, true, true, false);
                                }
                                else
                                {
                                    GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter].TrimStart(), "", "REF1", "bib_surname", "", true, false, true, true, false);
                                }
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;
                    }



                    strMatchText.Clear();
                    strSearchRegEx = null;


                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    GlobalMethods.SearchAndReplace(mdoc, "^p ", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, " ^p", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "<jrn> ^p", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "<jrn> </jrn>", "", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    // GlobalMethods.SearchAndReplace(mdoc, "^p^p", "^p", "", "", "", false, false, true, false, false);//commented on 11020202 For boxstart and BoxEnd style remove. 
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    //GlobalMethods.SearchAndReplace(mdoc, "^g", "^&", "", "", "FIG", false, true, true, false);
                    GlobalMethods.SearchAndReplace(mdoc, "^~", "-", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "", "", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    //GlobalMethods.SearchAndReplace(mdoc, "", "", "BullList", "", "", false, false, false, false, false);//19022020 comment for indend remove.
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    object oMissing = System.Reflection.Missing.Value;

                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;

                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                if (mdoc != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;
                }
                if (GlobalMethods.wordApp != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    ((_Application)GlobalMethods.wordApp).Quit(ref oMissing, ref oMissing, ref oMissing);
                    GlobalMethods.wordApp = null;
                }
            }


        }
        public static void ApplyJournalTitleForJaypee(string strDocPath)
        {
            Microsoft.Office.Interop.Word.Document mdoc = null;

            try
            {
                GlobalMethods.strJournalDBFilename = ConfigurationManager.AppSettings.Get("JournalNameDBJaypee");
                List<string> JrnCitationPatternsColl = new List<string>();

                ///Configuration read from Supporting folder
                JrnCitationPatternsColl = GlobalMethods.ReadAndStoreFileValuesInArray(GlobalMethods.strJournalDBFilename);
                JrnCitationPatternsColl = JrnCitationPatternsColl.OrderBy(x => x.Length).ToList();
                string strDocContent = null;
                mdoc = GlobalMethods.LoadWordDocument(strDocPath);

                strDocContent = mdoc.Content.Text;

                if (strDocContent == null)
                    return;

                // Search the patterns in the document content using Regular Expression
                if (mdoc != null)
                {

                    //GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    List<string> strMatchText = new List<string>();
                    string strSearchRegEx = null;



                    strMatchText.Clear();
                    strSearchRegEx = null;

                    ///configuration added by Karan Start
                    foreach (var item in JrnCitationPatternsColl)
                    {
                        if (item.Trim().Split(' ').Count() > 1 && !item.Trim().Contains("(") && !item.Trim().Contains(")"))
                        {
                            strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"(" + item + ")");
                            if (strMatchText.Count > 0)
                            {
                                for (int counter = 0; counter < strMatchText.Count; counter++)
                                {
                                    GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter], "", "REF1", "bib_journal", "", true, false, true, true, false);

                                }
                            }
                            strMatchText.Clear();
                            strSearchRegEx = null;
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"(\set\sal\.)");

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter].TrimStart(), "", "REF1", "bib_etal", "", true, false, true, true, false);

                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    GlobalMethods.SearchAndReplace(mdoc, "^p ", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, " ^p", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "<jrn> ^p", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "<jrn> </jrn>", "", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    // GlobalMethods.SearchAndReplace(mdoc, "^p^p", "^p", "", "", "", false, false, true, false, false);//commented on 11020202 For boxstart and BoxEnd style remove. 
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    //GlobalMethods.SearchAndReplace(mdoc, "^g", "^&", "", "", "FIG", false, true, true, false);
                    GlobalMethods.SearchAndReplace(mdoc, "^~", "-", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "", "", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    //GlobalMethods.SearchAndReplace(mdoc, "", "", "BullList", "", "", false, false, false, false, false);//19022020 comment for indend remove.
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    object oMissing = System.Reflection.Missing.Value;

                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;

                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                if (mdoc != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;
                }
                if (GlobalMethods.wordApp != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    ((_Application)GlobalMethods.wordApp).Quit(ref oMissing, ref oMissing, ref oMissing);
                    GlobalMethods.wordApp = null;
                }
            }


        }

        public static void ApplyPMIDAndPMCIDForJaypee(string strDocPath)
        {
            Microsoft.Office.Interop.Word.Document mdoc = null;

            try
            {
                string strDocContent = null;
                mdoc = GlobalMethods.LoadWordDocument(strDocPath);

                strDocContent = mdoc.Content.Text;

                if (strDocContent == null)
                    return;

                // Search the patterns in the document content using Regular Expression
                if (mdoc != null)
                {

                    //GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    List<string> strMatchText = new List<string>();
                    string strSearchRegEx = null;


                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"(PMID\:\s{1,}[A-Za-z0-9]+)");

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter].TrimStart(), "", "REF1", "bib_pmid", "", true, false, true, true, false);

                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"(PMCID\:\s{1,}[A-Za-z0-9]+)");

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter].TrimStart(), "", "REF1", "bib_pmcid", "", true, false, true, true, false);

                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    GlobalMethods.SearchAndReplace(mdoc, "^p ", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, " ^p", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "<jrn> ^p", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "<jrn> </jrn>", "", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    // GlobalMethods.SearchAndReplace(mdoc, "^p^p", "^p", "", "", "", false, false, true, false, false);//commented on 11020202 For boxstart and BoxEnd style remove. 
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    //GlobalMethods.SearchAndReplace(mdoc, "^g", "^&", "", "", "FIG", false, true, true, false);
                    GlobalMethods.SearchAndReplace(mdoc, "^~", "-", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "", "", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    //GlobalMethods.SearchAndReplace(mdoc, "", "", "BullList", "", "", false, false, false, false, false);//19022020 comment for indend remove.
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    object oMissing = System.Reflection.Missing.Value;

                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;

                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                if (mdoc != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;
                }
                if (GlobalMethods.wordApp != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    ((_Application)GlobalMethods.wordApp).Quit(ref oMissing, ref oMissing, ref oMissing);
                    GlobalMethods.wordApp = null;
                }
            }


        }
        public static void ApplyJournalTitleForJaypeeSingle(string strDocPath)
        {
            Microsoft.Office.Interop.Word.Document mdoc = null;

            try
            {
                GlobalMethods.strPublisherDBFilename = ConfigurationManager.AppSettings.Get("PublisherNameDBSage");
                List<string> BokCitationPatternsColl = new List<string>();


                GlobalMethods.strJournalDBFilename = ConfigurationManager.AppSettings.Get("JournalNameDBJaypee").Replace(".txt", "Single.txt");
                List<string> JrnCitationPatternsColl = new List<string>();

                ///Configuration read from Supporting folder
                JrnCitationPatternsColl = GlobalMethods.ReadAndStoreFileValuesInArray(GlobalMethods.strJournalDBFilename);
                JrnCitationPatternsColl = JrnCitationPatternsColl.OrderBy(x => x.Length).ToList();
                string strDocContent = null;
                mdoc = GlobalMethods.LoadWordDocument(strDocPath);

                strDocContent = mdoc.Content.Text;

                if (strDocContent == null)
                    return;

                // Search the patterns in the document content using Regular Expression
                if (mdoc != null)
                {

                    //GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    List<string> strMatchText = new List<string>();
                    string strSearchRegEx = null;



                    strMatchText.Clear();
                    strSearchRegEx = null;

                    ///configuration added by Karan Start
                    foreach (var item in JrnCitationPatternsColl)
                    {

                        if (item.Trim().Length >= 4)
                        {
                            strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"(" + item + ")");
                            if (strMatchText.Count > 0)
                            {
                                for (int counter = 0; counter < strMatchText.Count; counter++)
                                {
                                    GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter], "", "REF1", "bib_journal", "", true, false, true, true, true);

                                }
                            }
                            strMatchText.Clear();
                            strSearchRegEx = null;
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"(\set\sal\.)");

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter].TrimStart(), "", "REF1", "bib_etal", "", true, false, true, true, false);

                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    GlobalMethods.SearchAndReplace(mdoc, "^p ", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, " ^p", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "<jrn> ^p", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "<jrn> </jrn>", "", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    // GlobalMethods.SearchAndReplace(mdoc, "^p^p", "^p", "", "", "", false, false, true, false, false);//commented on 11020202 For boxstart and BoxEnd style remove. 
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    //GlobalMethods.SearchAndReplace(mdoc, "^g", "^&", "", "", "FIG", false, true, true, false);
                    GlobalMethods.SearchAndReplace(mdoc, "^~", "-", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "", "", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    //GlobalMethods.SearchAndReplace(mdoc, "", "", "BullList", "", "", false, false, false, false, false);//19022020 comment for indend remove.
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    object oMissing = System.Reflection.Missing.Value;

                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;

                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                if (mdoc != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;
                }
                if (GlobalMethods.wordApp != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    ((_Application)GlobalMethods.wordApp).Quit(ref oMissing, ref oMissing, ref oMissing);
                    GlobalMethods.wordApp = null;
                }
            }


        }
        public static void ApplyPublisherNameForJaypee(string strDocPath)
        {
            Microsoft.Office.Interop.Word.Document mdoc = null;

            try
            {
                GlobalMethods.strPublisherDBFilename = ConfigurationManager.AppSettings.Get("PublisherNameDBSage");
                List<string> BokCitationPatternsColl = new List<string>();


                //  GlobalMethods.strJournalDBFilename = ConfigurationManager.AppSettings.Get("JournalNameDBJaypee").Replace(".txt", "Single.txt");
                //  List<string> JrnCitationPatternsColl = new List<string>();

                ///Configuration read from Supporting folder
                BokCitationPatternsColl = GlobalMethods.ReadAndStoreFileValuesInArray(GlobalMethods.strPublisherDBFilename);
                BokCitationPatternsColl = BokCitationPatternsColl.OrderBy(x => x.Length).ToList();
                string strDocContent = null;
                mdoc = GlobalMethods.LoadWordDocument(strDocPath);

                strDocContent = mdoc.Content.Text;

                if (strDocContent == null)
                    return;

                // Search the patterns in the document content using Regular Expression
                if (mdoc != null)
                {

                    //GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    List<string> strMatchText = new List<string>();
                    string strSearchRegEx = null;



                    strMatchText.Clear();
                    strSearchRegEx = null;

                    ///configuration added by Karan Start
                    foreach (var item in BokCitationPatternsColl)
                    {

                        if (item.Trim().Length >= 4)
                        {
                            strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"(" + item + ")");
                            if (strMatchText.Count > 0)
                            {
                                for (int counter = 0; counter < strMatchText.Count; counter++)
                                {
                                    GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter], "", "REF1", "bibpubname", "", true, false, true, true, true);

                                }
                            }
                            strMatchText.Clear();
                            strSearchRegEx = null;
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"(\set\sal\.)");

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter].TrimStart(), "", "REF1", "bib_etal", "", true, false, true, true, false);

                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    GlobalMethods.SearchAndReplace(mdoc, "^p ", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, " ^p", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "<jrn> ^p", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "<jrn> </jrn>", "", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    // GlobalMethods.SearchAndReplace(mdoc, "^p^p", "^p", "", "", "", false, false, true, false, false);//commented on 11020202 For boxstart and BoxEnd style remove. 
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    //GlobalMethods.SearchAndReplace(mdoc, "^g", "^&", "", "", "FIG", false, true, true, false);
                    GlobalMethods.SearchAndReplace(mdoc, "^~", "-", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "", "", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    //GlobalMethods.SearchAndReplace(mdoc, "", "", "BullList", "", "", false, false, false, false, false);//19022020 comment for indend remove.
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    object oMissing = System.Reflection.Missing.Value;

                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;

                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                if (mdoc != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;
                }
                if (GlobalMethods.wordApp != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    ((_Application)GlobalMethods.wordApp).Quit(ref oMissing, ref oMissing, ref oMissing);
                    GlobalMethods.wordApp = null;
                }
            }


        }

        public static void ApplyPublisherLocForJaypee(string strDocPath)
        {
            Microsoft.Office.Interop.Word.Document mdoc = null;

            try
            {
                GlobalMethods.strPublisherDBFilename = ConfigurationManager.AppSettings.Get("PublisherLocationDB");
                List<string> BokCitationPatternsColl = new List<string>();


                //  GlobalMethods.strJournalDBFilename = ConfigurationManager.AppSettings.Get("JournalNameDBJaypee").Replace(".txt", "Single.txt");
                //  List<string> JrnCitationPatternsColl = new List<string>();

                ///Configuration read from Supporting folder
                BokCitationPatternsColl = GlobalMethods.ReadAndStoreFileValuesInArray(GlobalMethods.strPublisherDBFilename);
                BokCitationPatternsColl = BokCitationPatternsColl.OrderBy(x => x.Length).ToList();
                string strDocContent = null;
                mdoc = GlobalMethods.LoadWordDocument(strDocPath);

                strDocContent = mdoc.Content.Text;

                if (strDocContent == null)
                    return;

                // Search the patterns in the document content using Regular Expression
                if (mdoc != null)
                {

                    //GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    List<string> strMatchText = new List<string>();
                    string strSearchRegEx = null;



                    strMatchText.Clear();
                    strSearchRegEx = null;

                    ///configuration added by Karan Start
                    foreach (var item in BokCitationPatternsColl)
                    {

                        if (item.Trim().Length >= 4)
                        {
                            strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"(" + item + ")");
                            if (strMatchText.Count > 0)
                            {
                                for (int counter = 0; counter < strMatchText.Count; counter++)
                                {
                                    GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter], "", "REF1", "publisher-loc", "", true, false, true, true, true);

                                }
                            }
                            strMatchText.Clear();
                            strSearchRegEx = null;
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"(\set\sal\.)");

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter].TrimStart(), "", "REF1", "bib_etal", "", true, false, true, true, false);

                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    GlobalMethods.SearchAndReplace(mdoc, "^p ", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, " ^p", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "<jrn> ^p", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "<jrn> </jrn>", "", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    // GlobalMethods.SearchAndReplace(mdoc, "^p^p", "^p", "", "", "", false, false, true, false, false);//commented on 11020202 For boxstart and BoxEnd style remove. 
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    //GlobalMethods.SearchAndReplace(mdoc, "^g", "^&", "", "", "FIG", false, true, true, false);
                    GlobalMethods.SearchAndReplace(mdoc, "^~", "-", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "", "", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    //GlobalMethods.SearchAndReplace(mdoc, "", "", "BullList", "", "", false, false, false, false, false);//19022020 comment for indend remove.
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    object oMissing = System.Reflection.Missing.Value;

                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;

                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                if (mdoc != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;
                }
                if (GlobalMethods.wordApp != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    ((_Application)GlobalMethods.wordApp).Quit(ref oMissing, ref oMissing, ref oMissing);
                    GlobalMethods.wordApp = null;
                }
            }


        }

        public static void ReferenceSearchAndReplaceYearPattern(string strDocPath)
        {
            Microsoft.Office.Interop.Word.Document mdoc = null;
            try
            {

                string strDocContent = null;
                mdoc = GlobalMethods.LoadWordDocument(strDocPath);

                strDocContent = mdoc.Content.Text;

                if (strDocContent == null)
                    return;

                // Search the patterns in the document content using Regular Expression
                if (mdoc != null)
                {

                    //GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    List<string> strMatchText = new List<string>();
                    string strSearchRegEx = null;


                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"( 19[0-9][0-9][.; ])|( 20[0-9][0-9][.; ])");

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            if (strMatchText[counter].Length == 6)
                            {
                                GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter].TrimStart(), "", "REF1", "bib_year", "", true, false, true, true, false);
                            }

                        }
                    }


                    strMatchText.Clear();
                    strSearchRegEx = null;


                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    GlobalMethods.SearchAndReplace(mdoc, "^p ", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, " ^p", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "<jrn> ^p", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "<jrn> </jrn>", "", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    // GlobalMethods.SearchAndReplace(mdoc, "^p^p", "^p", "", "", "", false, false, true, false, false);//commented on 11020202 For boxstart and BoxEnd style remove. 
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    //GlobalMethods.SearchAndReplace(mdoc, "^g", "^&", "", "", "FIG", false, true, true, false);
                    GlobalMethods.SearchAndReplace(mdoc, "^~", "-", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "", "", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    //GlobalMethods.SearchAndReplace(mdoc, "", "", "BullList", "", "", false, false, false, false, false);//19022020 comment for indend remove.
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    object oMissing = System.Reflection.Missing.Value;

                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;

                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                if (mdoc != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;
                }
                if (GlobalMethods.wordApp != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    ((_Application)GlobalMethods.wordApp).Quit(ref oMissing, ref oMissing, ref oMissing);
                    GlobalMethods.wordApp = null;
                }
            }


        }


    }
}
