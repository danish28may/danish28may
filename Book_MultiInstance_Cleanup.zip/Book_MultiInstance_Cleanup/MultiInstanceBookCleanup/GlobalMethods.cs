﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Microsoft.Office.Interop.Word;
using System.Text.RegularExpressions;
using DocumentFormat.OpenXml.Packaging;
using OpenXmlPowerTools;
using System.Xml;
using System.Xml.Linq;
using System.Linq;
using DocumentFormat.OpenXml.Validation;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace MultiInstanceBookCleanup
{
    class GlobalMethods
    {
        public static Microsoft.Office.Interop.Word.Application wordApp = null;
        static Microsoft.Office.Interop.Word.Document SourceDoc = null;
        static Microsoft.Office.Interop.Word.Document TargetDoc = null;

        public static string StrEntityFile = null;
        public static string StrInFolder = null;
        public static string StrOutFolder = null;
        public static string StrProcessFolder = null;
        public static string str3CMWordTemplate = null;
        public static string strStyleMappingConfig = null;
        public static string strRefNum = null;
        public static string strStyleMappingJSONConfig = null;
        public static string strCustomerID = null;
        public static string strReferncePatternFilename = null;
        public static string strJournalDBFilename = null;
        public static string strPublisherDBFilename = null;
        public static bool refStructureDone = false;
        public static bool bCleanupRequired;
        public static string strReferenceStyleDB = null;

        public static string strParagraphStyleMappingConfig = null;
        public static string strCharacterStyleMappingConfig = null;
        public static string str3CMValidParagraphStyleConfig = null;
        public static string str3CMValidCharacterStyleConfig = null;
        public static string str3CMBoxStyle = null;  //04_10_2019
                                                    
        //Developer name:Priyanka Vishwakarma ,Date:17-06-2020 ,Requirement:epub structuring ,
        public static string strOutputRequired = null;
        public static string FrontMatterKeywords = null;   //10-06-2020
        //-------End on 17-06-2020




        // Metadata Fields Variables //
        public static string DOI;
        public static string ISBN;
        public static string eISBN;
        public static string VolumeTitle;
        public static string SeriesTitle;
        public static string BookTitle;
        public static string BookSubTitle;
        public static string CopyrightNote;
        public static string CopyrightYear;
        public static string Publisher;
        public static string AuthorInfo;
        public static string EditorInfo;
        public static string ChapterTitle;
        public static string ChapterNumber;
        public static string strCleanup;
        public static string ChapterPath;
        public static string ChapterImagePath;
        public static string str3CMIgnoreStyleConfig = null;
        public static string str3CMRemoveCustomerParaStyleFileName = null;


        public static bool bIndentation = false;
        public static bool bLeftIndentation = false;
        public static bool bHangingIndentation = false;
        public static bool bFirstLineIndentation = false;
        public static bool bTextAlignment = false;
        public static bool bJustification = false;
        public static bool bParagraphBorders = false;
        public static bool bLeftBorder = false;
        public static bool bTopBorder = false;
        public static bool bRightBorder = false;
        public static bool bBottomBorder = false;
        public static bool bBetweenBorder = false;
        public static bool bBarBorder = false;
        public static bool bBold = false;
        public static bool bCaps = false;
        public static bool bEmphasis = false;
        public static bool bItalic = false;
        public static bool bSmallCaps = false;
        public static bool bUnderline = false;
        public static bool bStrike = false;
        public static bool bDoubleStrike = false;

        public static bool bVertAlignment = false;
        public static bool bCharBorder = false;
        public static bool bCharColor = false;

        public static List<string> strListNumbers = new List<string>();
        public static List<string> ValidStyleList = new List<string>();  //Developer name:PRiyanka Vishwakarma ,Date:18-11-2019 ,Requirement:FOr chech if Paragraph already structure then does not change. Integrated by:Vikas sir.
        public static Dictionary<string, DocumentFormat.OpenXml.Wordprocessing.Style> StyleList;

        ///New string added by Karan on 09-07-2017 For MultiInstance xml data Start
        public static string strJobTransId = null;
        public static string strDocumentType = null;
        public static string strServiceType = null;
        public static string strTitleName = null;
        public static string strClientName = null;
        ///New string added by Karan on 09-07-2017 For MultiInstance xml data End
        ///
        public static string strJobCategory = null;

        public static string strDegree = null;//for Fm document Author style. Added by Karan on 16-07-2018

        public static string strStyleMappingNew = null;

        public static string strXMLOutputrequired = null;

        public static List<string> CleanupReport = new List<string>();///add by vikas on 18-10-2020 sage client

        // Extract the styles or stylesWithEffects part from a 
        // word processing document as an XDocument instance.
        public static Dictionary<string, DocumentFormat.OpenXml.Wordprocessing.Style> ExtractStylesPart(
          string fileName,
          bool getStylesWithEffectsPart = true)
        {
            // Declare a variable to hold the XDocument.
            //XDocument styles = null;
            Dictionary<string, DocumentFormat.OpenXml.Wordprocessing.Style> StyleList = new Dictionary<string, DocumentFormat.OpenXml.Wordprocessing.Style>();

            // Open the document for read access and get a reference.
            using (var document =
                WordprocessingDocument.Open(fileName, false))
            {
                // Get a reference to the main document part.
                var docPart = document.MainDocumentPart;

                StyleList = document.MainDocumentPart.StyleDefinitionsPart.Styles.OfType<DocumentFormat.OpenXml.Wordprocessing.Style>().Select(p => p).ToDictionary(d => d.StyleId.Value);
            }
            // Return the XDocument instance.
            return StyleList;
        }

        public static bool CheckTheExistanceOfStringInList(List<string> strList, string strCheckValue)
        {
            int nIndex = 0;

            if (strList.Count > 0)
            {
                for (nIndex = 0; nIndex < strList.Count; nIndex++)
                {
                    if (strList[nIndex] == strCheckValue)
                        return true;
                }
            }

            return false;
        }

        public static bool ApplyNumListCharStyle(Microsoft.Office.Interop.Word.Document oActiveDoc, string strSearchText, string strReplaceCharStyle, bool bCharStyle, bool bMatchWildCard)
        {
            // Clear Previous searched settings from Word Find dialog box
            //ClearFindAndReplaceParameters(oActiveDoc); // not required as of now //

            // get the range of the curent paragraph
            Range rngDoc = oActiveDoc.Range();

            // setup Microsoft Word Find based upon
            // Regular Expression Match
            rngDoc.Find.ClearFormatting();
            rngDoc.Find.Replacement.ClearFormatting();
            rngDoc.Find.Forward = true;
            rngDoc.Find.MatchWildcards = bMatchWildCard;

            if (strSearchText != "")
                rngDoc.Find.Text = strSearchText;

            // make search case sensitive
            object caseSensitive = "0";
            object missingValue = Type.Missing;

            rngDoc.Find.Wrap = Microsoft.Office.Interop.Word.WdFindWrap.wdFindStop;

            // wild cards
            object matchWildCards = Type.Missing;

            object replaceOne = Microsoft.Office.Interop.Word.WdReplace.wdReplaceOne;


            rngDoc.Find.Execute(ref missingValue, ref caseSensitive,
           ref missingValue, ref missingValue, ref missingValue,
           ref missingValue, ref missingValue, ref missingValue,
           ref missingValue, ref missingValue, missingValue,
           ref missingValue, ref missingValue, ref missingValue,
           ref missingValue);

            // we found the text
            if (rngDoc.Find.Found)
            {
                do
                {
                    if (rngDoc.ParagraphStyle.NameLocal == "L1" ||
                        rngDoc.ParagraphStyle.NameLocal == "L2" ||
                        rngDoc.ParagraphStyle.NameLocal == "L3" ||
                        rngDoc.ParagraphStyle.NameLocal == "L4" ||
                        rngDoc.ParagraphStyle.NameLocal == "UL" ||
                        rngDoc.ParagraphStyle.NameLocal == "Question" ||
                        rngDoc.ParagraphStyle.NameLocal == "Answer")
                    {
                        if (rngDoc.Start == rngDoc.Paragraphs[1].Range.Start)
                        {
                            if (strReplaceCharStyle != "")
                            {
                                int nBold = rngDoc.Bold;
                                int nItalic = rngDoc.Italic;

                                rngDoc.set_Style(strReplaceCharStyle);

                                rngDoc.Bold = nBold;
                                rngDoc.Italic = nItalic;
                            }
                        }
                    }

                    rngDoc.Move();

                    rngDoc.Find.Execute(ref missingValue, ref caseSensitive,
                    ref missingValue, ref missingValue, ref missingValue,
                    ref missingValue, ref missingValue, ref missingValue,
                    ref missingValue, ref missingValue, missingValue,
                    ref missingValue, ref missingValue, ref missingValue,
                    ref missingValue);

                } while (rngDoc.Find.Found);

                return true;
            }

            return false;

        }

        public static string SearchRegExPatternFirstSearchInstanceOnly(string strParaContent, string strSearchRegEx)
        {
            Regex regexText = new Regex(strSearchRegEx);

            // Match the regular expression pattern against a text string.
            Match m = regexText.Match(strParaContent);

            if (m.Success)
            {
                return m.Value;
            }

            return null;
        }
        public static void DisposeCOMObject()
        {
            //GlobalMethods.wordApp = null;
            //var process = Process.GetProcessesByName("winword.exe").FirstOrDefault();

            //if (process != null)
            //{
            //    process.Kill();
            //}
        }

        public static List<string> ReadAndStoreFileValuesInArray(string StyleMappingConfigFile)
        {
            List<string> strStyleMapping = new List<string>();
            strStyleMapping.Clear();

            if (StyleMappingConfigFile == null)
                return strStyleMapping;

            if (StyleMappingConfigFile == "")
                return strStyleMapping;

            int counter = 0;

            string strLine = null;

            StreamReader sr = new StreamReader(StyleMappingConfigFile);

            strStyleMapping.Clear();

            while ((strLine = sr.ReadLine()) != null)
            {
                if (strLine.StartsWith("//") == false)
                {
                    strStyleMapping.Add(strLine.Trim());
                    counter++;
                }
            }

            sr.Close();

            return strStyleMapping;
        }

        public static Microsoft.Office.Interop.Word.Document LoadWordDocument(string strDoc)
        {
            object oMissing = System.Reflection.Missing.Value;
            wordApp = new Microsoft.Office.Interop.Word.Application();

            try
            {
                wordApp.Visible = false;
                wordApp.ScreenUpdating = false;

                Object filename = (Object)strDoc;
                Microsoft.Office.Interop.Word.Document mdoc = wordApp.Documents.Open(ref filename, ref oMissing,
                                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing);

                return mdoc;

            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public static List<string> DocumentRegEx(string strDocContent, string strSearchRegEx)
        {
            List<string> strMatchText = new List<string>();

            strMatchText.Clear();

            Regex regexText = new Regex(strSearchRegEx, RegexOptions.Multiline);

            // Match the regular expression pattern against a text string.
            Match m = regexText.Match(strDocContent);

            //MatchCollection m = regexText.Matches(strDocContent);

            while (m.Success)
            {
                if (strMatchText.Contains(m.Value) == false)
                    strMatchText.Add(m.Value);
                m = m.NextMatch();
            }

            return strMatchText;
        }

        public static bool ValidateRegEx(string strDocContent, string strSearchRegEx)
        {
            List<string> strMatchText = new List<string>();

            strMatchText.Clear();

            Regex regexText = new Regex(strSearchRegEx);

            // Match the regular expression pattern against a text string.
            Match m = regexText.Match(strDocContent);

            if (m.Success)
            {
                return true;
            }

            return false;
        }


        public static string RegExSearch(string strDocContent, string strSearchRegEx)
        {
            List<string> strMatchText = new List<string>();

            strMatchText.Clear();

            Regex regexText = new Regex(strSearchRegEx);

            // Match the regular expression pattern against a text string.
            Match m = regexText.Match(strDocContent);

            if (m.Success)
            {
                return m.Value;
            }

            return "";
        }

        //public static bool SearchAndReplace(Microsoft.Office.Interop.Word.Document oActiveDoc, string strSearchText, string strReplaceText, string strSearchInParaStyle, string strReplaceCharStyle, string strReplaceParaStyle, bool bCharStyle, bool bParaStyle, bool bReplaceAll, bool bGeneralCrosslink, bool bWildCard)
        //{
        //    // Clear Previous searched settings from Word Find dialog box
        //    //ClearFindAndReplaceParameters(oActiveDoc); // not required as of now //

        //    // get the range of the curent paragraph
        //    Range rngDoc = oActiveDoc.Range();

        //    // setup Microsoft Word Find based upon
        //    // Regular Expression Match
        //    rngDoc.Find.ClearFormatting();
        //    rngDoc.Find.Replacement.ClearFormatting();
        //    rngDoc.Find.Forward = true;
        //    rngDoc.Find.MatchWildcards = bWildCard;

        //    if (strSearchText != "")
        //        rngDoc.Find.Text = strSearchText;

        //    if (strReplaceText != "")
        //        rngDoc.Find.Replacement.Text = strReplaceText;

        //    if (bReplaceAll == true && bGeneralCrosslink == true)
        //    {
        //        if (strSearchInParaStyle != "")
        //            rngDoc.Find.set_Style(strSearchInParaStyle);

        //        if (bParaStyle == true)
        //            rngDoc.Find.Replacement.set_Style(strReplaceParaStyle);

        //        if (bCharStyle == true)
        //            rngDoc.Find.Replacement.set_Style(strReplaceCharStyle);
        //    }

        //    if (bGeneralCrosslink == false)
        //    {
        //        if (strSearchInParaStyle != "")
        //            rngDoc.Find.set_Style(strSearchInParaStyle);

        //        if (bCharStyle == true)
        //            rngDoc.Find.Replacement.set_Style(strReplaceCharStyle);

        //        if (bParaStyle == true)
        //            rngDoc.Find.Replacement.set_Style(strReplaceParaStyle);
        //    }

        //    // make search case sensitive
        //    object caseSensitive = "0";
        //    object missingValue = Type.Missing;

        //    rngDoc.Find.Wrap = Microsoft.Office.Interop.Word.WdFindWrap.wdFindStop;

        //    // wild cards
        //    object matchWildCards = Type.Missing;

        //    object replaceAll = Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll;
        //    //object replaceOne = Microsoft.Office.Interop.Word.WdReplace.wdReplaceOne;

        //    if (bReplaceAll == true)
        //    {
        //        // find the text in the word document
        //        rngDoc.Find.Execute(ref missingValue, ref missingValue,
        //            ref missingValue, ref missingValue, ref missingValue,
        //            ref missingValue, ref missingValue, ref missingValue,
        //            ref missingValue, ref missingValue, replaceAll,
        //            ref missingValue, ref missingValue, ref missingValue,
        //            ref missingValue);
        //    }
        //    else
        //    {
        //        rngDoc.Find.Execute(ref missingValue, ref caseSensitive,
        //               ref missingValue, ref missingValue, ref missingValue,
        //               ref missingValue, ref missingValue, ref missingValue,
        //               ref missingValue, ref missingValue, missingValue,
        //               ref missingValue, ref missingValue, ref missingValue,
        //               ref missingValue);

        //        // we found the text
        //        if (rngDoc.Find.Found)
        //        {
        //            do
        //            {
        //                if (rngDoc.ParagraphStyle.NameLocal != "TT" && rngDoc.ParagraphStyle.NameLocal != "BT" && rngDoc.ParagraphStyle.NameLocal != "FIGC")
        //                {
        //                    if(strReplaceCharStyle!="")
        //                        rngDoc.set_Style(strReplaceCharStyle);
        //                }

        //                if (rngDoc.ParagraphStyle.NameLocal == "BullList")
        //                {
        //                     rngDoc.ListFormat.RemoveNumbers(NumberType:WdNumberType.wdNumberParagraph);
        //                }

        //                rngDoc.Move();

        //                rngDoc.Find.Execute(ref missingValue, ref caseSensitive,
        //                ref missingValue, ref missingValue, ref missingValue,
        //                ref missingValue, ref missingValue, ref missingValue,
        //                ref missingValue, ref missingValue, missingValue,
        //                ref missingValue, ref missingValue, ref missingValue,
        //                ref missingValue);

        //            } while (rngDoc.Find.Found);

        //            return true;
        //        }
        //    }
        //    return false;

        //}

        public static bool SearchAndReplace(Microsoft.Office.Interop.Word.Document oActiveDoc, string strSearchText, string strReplaceText, string strSearchInParaStyle, string strReplaceCharStyle, string strReplaceParaStyle, bool bCharStyle, bool bParaStyle, bool bReplaceAll, bool bGeneralCrosslink, bool bMatchWildCard)
        {
            // Clear Previous searched settings from Word Find dialog box
            //ClearFindAndReplaceParameters(oActiveDoc); // not required as of now //

            // get the range of the curent paragraph
            Range rngDoc = oActiveDoc.Range();
            // setup Microsoft Word Find based upon
            // Regular Expression Match
            rngDoc.Find.ClearFormatting();
            rngDoc.Find.Replacement.ClearFormatting();
            rngDoc.Find.Forward = true;
            rngDoc.Find.MatchWildcards = bMatchWildCard;

            if (strSearchText != "")
                rngDoc.Find.Text = strSearchText;

            if (strReplaceText != "")
                rngDoc.Find.Replacement.Text = strReplaceText;

            if (bReplaceAll == true && bGeneralCrosslink == true)
            {
                if (strSearchInParaStyle != "")
                    rngDoc.Find.set_Style(strSearchInParaStyle);

                if (bParaStyle == true)
                    rngDoc.Find.Replacement.set_Style(strReplaceParaStyle);

                if (bCharStyle == true)
                    rngDoc.Find.Replacement.set_Style(strReplaceCharStyle);
            }

            if (bGeneralCrosslink == false)
            {
                if (strSearchInParaStyle != "")
                    rngDoc.Find.set_Style(strSearchInParaStyle);

                if (bCharStyle == true)
                    rngDoc.Find.Replacement.set_Style(strReplaceCharStyle);

                if (bParaStyle == true)
                    rngDoc.Find.Replacement.set_Style(strReplaceParaStyle);
            }

            // make search case sensitive
            object caseSensitive = "0";
            object missingValue = Type.Missing;

            rngDoc.Find.Wrap = Microsoft.Office.Interop.Word.WdFindWrap.wdFindStop;

            // wild cards
            object matchWildCards = Type.Missing;

            object replaceAll = Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll;
            object replaceOne = Microsoft.Office.Interop.Word.WdReplace.wdReplaceOne;


            if (bReplaceAll == true)
            {
                // find the text in the word document
                rngDoc.Find.Execute(ref missingValue, ref missingValue,
                    ref missingValue, ref missingValue, ref missingValue,
                    ref missingValue, ref missingValue, ref missingValue,
                    ref missingValue, ref missingValue, replaceAll,
                    ref missingValue, ref missingValue, ref missingValue,
                    ref missingValue);
            }
            else
            {
                rngDoc.Find.Execute(ref missingValue, ref caseSensitive,
                       ref missingValue, ref missingValue, ref missingValue,
                       ref missingValue, ref missingValue, ref missingValue,
                       ref missingValue, ref missingValue, missingValue,
                       ref missingValue, ref missingValue, ref missingValue,
                       ref missingValue);

                // we found the text
                if (rngDoc.Find.Found)
                {
                    var count = 0;
                    do
                    {
                        count++;
                        if (rngDoc.ParagraphStyle != null)
                        {
                            if (rngDoc.ParagraphStyle.NameLocal != "TT" && rngDoc.ParagraphStyle.NameLocal != "BT" && rngDoc.ParagraphStyle.NameLocal != "FIGC" && rngDoc.ParagraphStyle.NameLocal != "BoxStart" && rngDoc.ParagraphStyle.NameLocal != "FIGP")  //Developer Name :Priyanka Vishwakarma ,Date:08-08-2020 ,Requirement:Avoid to apply citefig charstyle in FIGP paragraph.
                            {
                                if (strReplaceCharStyle != "")
                                {
                                    int nBold = rngDoc.Bold;
                                    int nItalic = rngDoc.Italic;

                                    rngDoc.set_Style(strReplaceCharStyle);

                                    rngDoc.Bold = nBold;
                                    rngDoc.Italic = nItalic;

                                    if (strReplaceText != "")
                                        rngDoc.Find.Execute(Replace: replaceOne);
                                }
                            }

                            //if (rngDoc.ParagraphStyle.NameLocal == "BullList")
                            //{
                            //    rngDoc.ListFormat.RemoveNumbers(NumberType: WdNumberType.wdNumberParagraph);
                            //}
                        }


                        if (strReplaceText != "")
                            rngDoc.Find.Execute(Replace: replaceOne);


                        rngDoc.Move();

                        rngDoc.Find.Execute(ref missingValue, ref caseSensitive,
                        ref missingValue, ref missingValue, ref missingValue,
                        ref missingValue, ref missingValue, ref missingValue,
                        ref missingValue, ref missingValue, missingValue,
                        ref missingValue, ref missingValue, ref missingValue,
                        ref missingValue);
                        if(count>100)/////this codition added for if loop goes in infinite looping then it should break added on 19-08-2020 by vikas
                        {
                            goto next;
                        }

                    } while (rngDoc.Find.Found);
                    next:
                    {
                    }
                    return true;
                }
            }


            return false;

        }
        public static void FindAndapplyweblinkstyle(Microsoft.Office.Interop.Word.Application doc, object findText)
        {
            var rng = doc.Selection.Range;
            var checkbold = false;
            var checkitalic = false;
            while (rng.Find.Execute(findText))
            {
                if (rng.Font.Bold == -1)
                {
                    checkbold=true;
                }
                if (rng.Font.Italic == -1)
                {
                    checkitalic = true;
                }
                
                rng.set_Style("weblinks");
                if (checkbold)
                {
                    rng.Font.Bold = 1;
                }
                if (checkitalic)
                {
                    rng.Font.Italic = 1;
                }
            }
        }
        public static bool SearchAndReplaceAtStartOfParagraph(Microsoft.Office.Interop.Word.Document oActiveDoc, string strSearchText, string strReplaceText, string strSearchInParaStyle, string strReplaceCharStyle, string strReplaceParaStyle, bool bCharStyle, bool bParaStyle, bool bReplaceAll, bool bGeneralCrosslink, bool bMatchWildCard)
        {
            // Clear Previous searched settings from Word Find dialog box
            //ClearFindAndReplaceParameters(oActiveDoc); // not required as of now //

            // get the range of the curent paragraph
            Range rngDoc = oActiveDoc.Range();

            // setup Microsoft Word Find based upon
            // Regular Expression Match
            rngDoc.Find.ClearFormatting();
            rngDoc.Find.Replacement.ClearFormatting();
            rngDoc.Find.Forward = true;
            rngDoc.Find.MatchWildcards = bMatchWildCard;

            if (strSearchText != "")
                rngDoc.Find.Text = strSearchText;

            if (strReplaceText != "")
                rngDoc.Find.Replacement.Text = strReplaceText;

            if (bReplaceAll == true && bGeneralCrosslink == true)
            {
                if (strSearchInParaStyle != "")
                    rngDoc.Find.set_Style(strSearchInParaStyle);

                if (bParaStyle == true)
                    rngDoc.Find.Replacement.set_Style(strReplaceParaStyle);

                if (bCharStyle == true)
                    rngDoc.Find.Replacement.set_Style(strReplaceCharStyle);
            }

            if (bGeneralCrosslink == false)
            {
                if (strSearchInParaStyle != "")
                    rngDoc.Find.set_Style(strSearchInParaStyle);

                if (bCharStyle == true)
                    rngDoc.Find.Replacement.set_Style(strReplaceCharStyle);

                if (bParaStyle == true)
                    rngDoc.Find.Replacement.set_Style(strReplaceParaStyle);
            }

            // make search case sensitive
            object caseSensitive = "0";
            object missingValue = Type.Missing;

            rngDoc.Find.Wrap = Microsoft.Office.Interop.Word.WdFindWrap.wdFindStop;

            // wild cards
            object matchWildCards = Type.Missing;

            object replaceAll = Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll;
            object replaceOne = Microsoft.Office.Interop.Word.WdReplace.wdReplaceOne;


            if (bReplaceAll == true)
            {
                // find the text in the word document
                rngDoc.Find.Execute(ref missingValue, ref missingValue,
                    ref missingValue, ref missingValue, ref missingValue,
                    ref missingValue, ref missingValue, ref missingValue,
                    ref missingValue, ref missingValue, replaceAll,
                    ref missingValue, ref missingValue, ref missingValue,
                    ref missingValue);
            }
            else
            {
                rngDoc.Find.Execute(ref missingValue, ref caseSensitive,
                       ref missingValue, ref missingValue, ref missingValue,
                       ref missingValue, ref missingValue, ref missingValue,
                       ref missingValue, ref missingValue, missingValue,
                       ref missingValue, ref missingValue, ref missingValue,
                       ref missingValue);

                // we found the text
                if (rngDoc.Find.Found)
                {
                    do
                    {
                        //if (rngDoc.ParagraphStyle.NameLocal != "TT" && rngDoc.ParagraphStyle.NameLocal != "BT" && rngDoc.ParagraphStyle.NameLocal != "FIGC")
                        //{
                        //    if (strReplaceCharStyle != "")
                        //    {
                        //        int nBold = rngDoc.Bold;
                        //        int nItalic = rngDoc.Italic;

                        //        rngDoc.set_Style(strReplaceCharStyle);

                        //        rngDoc.Bold = nBold;
                        //        rngDoc.Italic = nItalic;

                        //        if (strReplaceText != "")
                        //            rngDoc.Find.Execute(Replace: replaceOne);
                        //    }
                        //}

                        //if (rngDoc.ParagraphStyle.NameLocal == "BullList")
                        //{
                        //    rngDoc.ListFormat.RemoveNumbers(NumberType: WdNumberType.wdNumberParagraph);
                        //}

                        if (strReplaceCharStyle != null && strReplaceCharStyle != "")
                        {
                            if (rngDoc.Start == rngDoc.Paragraphs[1].Range.Start)
                            {
                                if (rngDoc.ParagraphStyle.NameLocal == "BullList" ||
                                    rngDoc.ParagraphStyle.NameLocal == "AlphaLowerList" ||
                                    rngDoc.ParagraphStyle.NameLocal == "NumList" ||
                                    rngDoc.ParagraphStyle.NameLocal == "DashList" ||
                                    rngDoc.ParagraphStyle.NameLocal == "TableFoot" ||
                                    rngDoc.ParagraphStyle.NameLocal == "Question" ||
                                    rngDoc.ParagraphStyle.NameLocal == "Answer")
                                {
                                    int nBold = rngDoc.Bold;
                                    int nItalic = rngDoc.Italic;

                                    rngDoc.set_Style(strReplaceCharStyle);

                                    rngDoc.Bold = nBold;
                                    rngDoc.Italic = nItalic;
                                }
                            }
                        }
                        else
                        {
                            if (rngDoc.Start == rngDoc.Paragraphs[1].Range.Start)
                            {
                                rngDoc.Find.Execute(ref missingValue, ref caseSensitive,
                                ref missingValue, ref missingValue, ref missingValue,
                                ref missingValue, ref missingValue, ref missingValue,
                                ref missingValue, ref missingValue, replaceOne,
                                ref missingValue, ref missingValue, ref missingValue,
                                ref missingValue);
                            }
                        }

                        rngDoc.Move();

                        rngDoc.Find.Execute(ref missingValue, ref caseSensitive,
                        ref missingValue, ref missingValue, ref missingValue,
                        ref missingValue, ref missingValue, ref missingValue,
                        ref missingValue, ref missingValue, missingValue,
                        ref missingValue, ref missingValue, ref missingValue,
                        ref missingValue);

                    } while (rngDoc.Find.Found);

                    return true;
                }
            }


            return false;

        }


        private static bool ClearFindAndReplaceParameters(Microsoft.Office.Interop.Word.Document oActiveDoc)
        {
            Range rngDoc = oActiveDoc.Range();

            // setup Microsoft Word Find based upon
            // Regular Expression Match
            rngDoc.Find.ClearFormatting();
            rngDoc.Find.Wrap = Microsoft.Office.Interop.Word.WdFindWrap.wdFindStop;
            rngDoc.Find.MatchWildcards = false;
            rngDoc.Find.set_Style("");
            rngDoc.Find.Replacement.set_Style("");
            rngDoc.Find.Text = "";
            rngDoc.Find.Replacement.Text = "";

            return true;
        }
        public static bool RemoveCharStyle(Microsoft.Office.Interop.Word.Document oActiveDoc, string strSearchText, string strReplaceText, string strSearchCharStyle)
        {
            // get the range of the curent paragraph
            Range rngDoc = oActiveDoc.Range();

            // setup Microsoft Word Find based upon
            // Regular Expression Match
            rngDoc.Find.ClearFormatting();
            rngDoc.Find.Forward = true;
            rngDoc.Find.Text = strSearchText;

            if (strReplaceText != "")
                rngDoc.Find.Replacement.Text = strReplaceText;

            rngDoc.Find.set_Style(strSearchCharStyle);
            rngDoc.Find.Replacement.set_Style("Default Paragraph Font");

            // make search case sensitive
            object caseSensitive = "0";
            object missingValue = Type.Missing;

            rngDoc.Find.Wrap = Microsoft.Office.Interop.Word.WdFindWrap.wdFindStop;

            // wild cards
            object matchWildCards = Type.Missing;

            object replaceAll = Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll;
            //object replaceOne = Microsoft.Office.Interop.Word.WdReplace.wdReplaceOne;


            // find the text in the word document
            rngDoc.Find.Execute(ref missingValue, ref missingValue,
                ref missingValue, ref missingValue, ref missingValue,
                ref missingValue, ref missingValue, ref missingValue,
                ref missingValue, ref missingValue, replaceAll,
                ref missingValue, ref missingValue, ref missingValue,
                ref missingValue);


            return true;

        }

        static bool bNormalParaFound = false;
        static bool bStyleParaFound = false;
        static string strCaptionText = null;
        public static void ApplyTableCaptionBetweenTwoTables(string newDoc)
        {
            bNormalParaFound = false;
            bStyleParaFound = false;


            using (WordprocessingDocument wDoc = WordprocessingDocument.Open(newDoc, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    //RemoveComments = false,
                    RemoveContentControls = true,
                    RemoveEndAndFootNotes = false,
                    RemoveFieldCodes = false,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = false,
                };

                MarkupSimplifier.SimplifyMarkup(wDoc, settings);

                var xDoc = wDoc.MainDocumentPart.GetXDocument();

                XmlDocument xd = xDoc.GetXmlDocument();

                xd.LoadXml(xd.InnerXml);

                XmlNodeList nodeList;
                XmlNamespaceManager ns = new XmlNamespaceManager(xd.NameTable);
                ns.AddNamespace("w", "http://schemas.openxmlformats.org/wordprocessingml/2006/main");

                XNamespace w = @"http://schemas.openxmlformats.org/wordprocessingml/2006/main";

                XmlNode root = xd.DocumentElement;

                nodeList = root.SelectNodes("w:body", ns);

                XElement xe = null;

                List<int> nNodeIndex = new List<int>();

                nNodeIndex.Clear();

                foreach (XmlNode book in nodeList)
                {
                    XmlNode nodeParent = book.ParentNode;

                    xe = book.GetXElement();

                    if (xe.HasElements)
                    {
                        foreach (XElement node in xe.Elements())
                        {
                            if (node.Name == W.tbl)
                            {
                                if (CheckElementsAfter(node))
                                {
                                    if (bNormalParaFound)
                                    {
                                        XElement run = new XElement(w + "r");
                                        XElement txt = new XElement(w + "t", strCaptionText);
                                        run.Add(txt);

                                        ((System.Xml.Linq.XElement)node.NextNode).Add(run);

                                        book.InnerXml = ((System.Xml.XmlDocument)(xe.GetXmlNode())).DocumentElement.InnerXml;

                                        continue;
                                    }
                                    else if (bStyleParaFound)
                                    {
                                        // Add new Paragraph above the current paragraph

                                        XElement para = new XElement(w + "p");
                                        XElement run = new XElement(w + "r");
                                        XElement txt = new XElement(w + "t", strCaptionText);
                                        run.Add(txt);
                                        para.Add(run);

                                        ((System.Xml.Linq.XElement)node.NextNode).AddBeforeSelf(para);

                                        book.InnerXml = ((System.Xml.XmlDocument)(xe.GetXmlNode())).DocumentElement.InnerXml;

                                    }
                                    else
                                    {
                                        strCaptionText = null;
                                    }

                                    //strCaptionText = null;
                                }
                            }

                            if (node.Name == W.p)
                            {
                                if (bNormalParaFound == true)
                                {
                                    bNormalParaFound = false;
                                    continue;
                                }

                                if (node.GetParagraphInfo() == null)
                                    continue;

                                BlockContentInfo bki = node.GetParagraphInfo();

                                if (bki.ThisBlockContentElement.FirstNode != null)
                                {
                                    if (((System.Xml.Linq.XContainer)bki.ThisBlockContentElement.FirstNode).FirstNode != null)
                                    {
                                        if (((System.Xml.Linq.XElement)(((System.Xml.Linq.XContainer)bki.ThisBlockContentElement.FirstNode).FirstNode)).Name == W.pStyle)
                                        {
                                            if ((((System.Xml.Linq.XElement)(((System.Xml.Linq.XContainer)bki.ThisBlockContentElement.FirstNode).FirstNode))).FirstAttribute != null)
                                            {
                                                string strStyle = (((System.Xml.Linq.XElement)(((System.Xml.Linq.XContainer)bki.ThisBlockContentElement.FirstNode).FirstNode))).FirstAttribute.Value;

                                                if (strStyle == "Caption")
                                                {
                                                    strCaptionText = node.Value;

                                                    Regex regexText = new Regex(@"Cuadro [A-Z]?[0-9]+\.[0-9]+");
                                                    Match m = regexText.Match(strCaptionText);
                                                    if (m.Length > 0)
                                                    {
                                                        strCaptionText = m.Value + " (Continued...)";
                                                    }
                                                    continue;
                                                }
                                            }
                                        }
                                    }
                                }

                            }
                        }
                    }

                }

                wDoc.MainDocumentPart.PutXDocument(xd.GetXDocument());

            } // End of Word Processing
        }

        private static bool CheckElementsAfter(XElement wp)
        {
            try
            {
                bool bParaFound = false;
                if (wp.ElementsAfterSelf() != null)
                {
                    XNamespace w = @"http://schemas.openxmlformats.org/wordprocessingml/2006/main";

                    IEnumerable<XElement> elements = wp.ElementsAfterSelf();

                    foreach (XElement xe in elements) // all elements
                    {
                        if (xe.Name == W.p) // check if the immediate first element is paragraphs and is empty or style NoteText // Else return
                        {
                            if (xe.Value == "")
                            {
                                bNormalParaFound = true;
                                bStyleParaFound = false;
                                bParaFound = true;
                                continue;
                            }
                            else
                            {
                                if (bParaFound == false)
                                {
                                    BlockContentInfo bki = xe.GetParagraphInfo();

                                    if (bki.ThisBlockContentElement.FirstNode != null)
                                    {
                                        if (((System.Xml.Linq.XContainer)bki.ThisBlockContentElement.FirstNode).FirstNode != null)
                                        {
                                            if (((System.Xml.Linq.XElement)(((System.Xml.Linq.XContainer)bki.ThisBlockContentElement.FirstNode).FirstNode)).Name == W.pStyle)
                                            {
                                                if ((((System.Xml.Linq.XElement)(((System.Xml.Linq.XContainer)bki.ThisBlockContentElement.FirstNode).FirstNode))).FirstAttribute != null)
                                                {
                                                    string strStyle = (((System.Xml.Linq.XElement)(((System.Xml.Linq.XContainer)bki.ThisBlockContentElement.FirstNode).FirstNode))).FirstAttribute.Value;

                                                    if (strStyle == "NoteText")
                                                    {
                                                        bNormalParaFound = false;
                                                        bStyleParaFound = true;
                                                        bParaFound = true;
                                                        continue;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }

                                Console.WriteLine(xe.Value);
                            }
                        }

                        if (bParaFound == true && xe.Name == W.tbl)
                        {
                            // Need to enter the Table Caption Text in the previous paragraph

                            return true;
                        }

                        bStyleParaFound = false;
                        bParaFound = false;
                        bNormalParaFound = false;

                        return false;
                    }
                }

                return false;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public static object OpenWordDocumentAndCompare(string strSourceDoc, string strTargetDoc)
        {
            try
            {
                object CompareFileName = null;
                object oMissing = System.Reflection.Missing.Value;
                wordApp = new Microsoft.Office.Interop.Word.Application();

                try
                {
                    wordApp.Visible = false;
                    wordApp.ScreenUpdating = false;

                    Object Sourcefilename = (Object)strSourceDoc;
                    SourceDoc = wordApp.Documents.Open(ref Sourcefilename, ref oMissing,
                                                       ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                                                       ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                                                       ref oMissing, ref oMissing, ref oMissing, ref oMissing);

                    Object Targetfilename = (Object)strTargetDoc;
                    TargetDoc = wordApp.Documents.Open(ref Targetfilename, ref oMissing,
                                                       ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                                                       ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                                                       ref oMissing, ref oMissing, ref oMissing, ref oMissing);

                    try
                    {
                        DocumentCompare(SourceDoc, TargetDoc);
                    }
                    finally
                    {
                        object saveChanges = WdSaveOptions.wdSaveChanges;
                        ((_Document)SourceDoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                        SourceDoc = null;

                        ((_Document)TargetDoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                        TargetDoc = null;
                    }
                }
                finally
                {
                    wordApp.ScreenUpdating = true;
                    ((_Application)wordApp).Quit(ref oMissing, ref oMissing, ref oMissing);
                    wordApp = null;
                }

                return CompareFileName;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }
        }

        private static void DocumentCompare(Microsoft.Office.Interop.Word.Document strSourceDoc, Microsoft.Office.Interop.Word.Document strTargetDoc)
        {
            object compareTarget = Microsoft.Office.Interop.Word.WdCompareTarget.wdCompareTargetNew;
            object addToRecentFiles = false;
            object oMissing = System.Reflection.Missing.Value;

            wordApp.CompareDocuments(strSourceDoc, strTargetDoc, WdCompareDestination.wdCompareDestinationRevised, WdGranularity.wdGranularityWordLevel, false, true, true, true, false, true, false, false, false, false, "3ClicksMaster", true);
        }

        public static String ReplaceWholeWord(String s, String word, String bywhat)
        {
            char firstLetter = word[0];
            StringBuilder sb = new StringBuilder();
            bool previousWasLetterOrDigit = false;
            int i = 0;
            while (i < s.Length - word.Length + 1)
            {
                bool wordFound = false;
                char c = s[i];
                if (c == firstLetter)
                    if (!previousWasLetterOrDigit)
                        if (s.Substring(i, word.Length).Equals(word))
                        {
                            wordFound = true;
                            bool wholeWordFound = true;
                            if (s.Length > i + word.Length)
                            {
                                if (Char.IsLetterOrDigit(s[i + word.Length]))
                                    wholeWordFound = false;
                            }

                            if (wholeWordFound)
                                sb.Append(bywhat);
                            else
                                sb.Append(word);

                            i += word.Length;
                        }

                if (!wordFound)
                {
                    previousWasLetterOrDigit = Char.IsLetterOrDigit(c);
                    sb.Append(c);
                    i++;
                }
            }

            if (s.Length - i > 0)
                sb.Append(s.Substring(i));

            return sb.ToString();
        }

        public static List<string> SortStringListOnLength(List<string> strStringColl)
        {
            List<string> strTmp = new List<string>();
            int nIndex = 0;
            int nCounter = 0;

            string strMid = null;

            strTmp = strStringColl;

            for (nIndex = 0; nIndex < strStringColl.Count; nIndex++)
            {
                for (nCounter = nIndex + 1; nCounter < strTmp.Count; nCounter++)
                {
                    if (strStringColl[nIndex].Length < strTmp[nCounter].Length)
                    {
                        strMid = strStringColl[nIndex];
                        strStringColl[nIndex] = strTmp[nCounter];
                        strTmp[nCounter] = strMid;
                        strMid = "";
                    }
                }
            }

            return strStringColl;
        }

        public static string SearchRegEx(string strDocContent, string strSearchRegEx)
        {
            string strSearchResult = "";

            Regex regexText = new Regex(strSearchRegEx,RegexOptions.IgnoreCase);

            // Match the regular expression pattern against a text string.
            Match m = regexText.Match(strDocContent);

            if (m.Success)
            {
                strSearchResult = m.Value;
            }

            return strSearchResult;
        }

        public static string TrimStart(string target, string trimString)
        {
            string result = target;
            while (result.StartsWith(trimString))
            {
                result = result.Substring(trimString.Length);
            }

            return result;
        }

        public static string TrimEnd(string input, string suffixToRemove)
        {
            while (input != null && suffixToRemove != null && input.EndsWith(suffixToRemove))
            {
                input = input.Substring(0, input.Length - suffixToRemove.Length);
            }
            return input;
        }

        internal static void funcSaveAsInputFile(string strDocPath)
        {
            Microsoft.Office.Interop.Word.Document mdoc = null;

            try
            {
                // Load Word Document Content
                mdoc = LoadWordDocument(strDocPath);

                mdoc.SaveAs2(strDocPath, WdSaveFormat.wdFormatXMLDocument,
                                 CompatibilityMode: WdCompatibilityMode.wdWord2010);

                mdoc.Close();

            }
            catch (Exception ex)
            {
                mdoc.Close();
            }
            finally
            {
                if (GlobalMethods.wordApp != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    ((_Application)GlobalMethods.wordApp).Quit(ref oMissing, ref oMissing, ref oMissing);
                    GlobalMethods.wordApp = null;
                }
            }
        }

        public static void ReadCustomPropertiesXML(string strXMLPath)
        {
            var customProperties = from custProp in XElement.Load(strXMLPath).Elements() select custProp;

            foreach (var property in customProperties)
            {
                if (property.Name.LocalName == "TransactionID")
                {
                    strJobTransId = property.Value;
                    continue;
                }
                else if (property.Name.LocalName == "DocumentType")
                {
                    strDocumentType = property.Value;
                    continue;
                }
                else if (property.Name.LocalName == "ServiceType")
                {
                    strServiceType = property.Value;
                    continue;
                }
                else if (property.Name.LocalName == "TitleName")
                {
                    strTitleName = property.Value;
                    continue;
                }
                else if (property.Name.LocalName == "ClientName")
                {
                    strClientName = property.Value;
                    continue;
                }
                else if (property.Name.LocalName == "JobCategory")
                {
                    strJobCategory = property.Value;
                    continue;
                }
                else if (property.Name.LocalName == "ChapterNumber")
                {
                    ChapterNumber = property.Value;
                    continue;
                }
                else if (property.Name.LocalName == "ChapterTitle")
                {
                    ChapterTitle = property.Value;
                    continue;
                }
                else if (property.Name.LocalName == "BookTitle")
                {
                    BookTitle = property.Value;
                    continue;
                }
                else if (property.Name.LocalName == "XMLOutputRequired")
                {
                    strXMLOutputrequired = property.Value;
                    continue;
                }
                //--Developer name:priyanka vishwakarma ,date:17-06-2020 ,requirement :read output require for epub or xml.
                else if (property.Name.LocalName == "OutputRequired")
                {
                    strOutputRequired = property.Value;
                    continue;
                }
                else if (property.Name.LocalName == "RefType")
                {
                    strRefNum = property.Value;
                    continue;
                }
            }
        }

        public static bool checkValidStyle(XElement P)
        {
            string validsty = "";
            foreach (var style in P.Descendants().Where(x => x.Name.LocalName == "pStyle"))
            {
                if (style.HasAttributes)
                    validsty = style.FirstAttribute.Value;
            }

            if (ValidStyleList.Distinct().ToList().Any(x => x.ToLower() == validsty.ToLower()))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public static void CleanupAnalysisReport(string strDocPath)////Added for Sage client
        {

            var strb = new StringBuilder();
            strb.AppendLine("***********Start - Input Cleanup Report***********<E>");
            strb.AppendLine("Job Name:" + new FileInfo(strDocPath).Name.Replace(".docx", "") + "<E>");
            strb.AppendLine("Start Time:" + DateTime.Now.ToString("dd-MM-yyyy") + "(" + DateTime.Now.ToString("HH:mm") + ")" + "<E>");
            strb.AppendLine("****************************************************<E>");
            foreach (var str in CleanupReport.Distinct().ToList())
            {
                strb.AppendLine(str);
            }
            strb.AppendLine("***********End - Input Cleanup Report*************");


            ////Here input analysis will update to Database added by vikas on 18-05-2020
            UpdateAnlysisReportInDBSage(strb.ToString());
        }
        public static void UpdateAnlysisReportInDBSage(string Reportdata)
        {
            try
            {
                string jobTransID = GlobalMethods.strJobTransId;
                string jobID = "";
                if (jobTransID != "" && jobTransID != null)
                {
                    // jobID = SqlHelper.ExecuteNonQuery(ConfigurationManager.ConnectionStrings["con"].ToString(), "select * from Job_Transaction where jobtransid='" + jobTransID + "'");
                    var jobData = SqlHelper.ExecuteDataset(ConfigurationManager.ConnectionStrings["con"].ToString(), CommandType.StoredProcedure, "Usp_Get_JobID", new SqlParameter("@jobtransid", jobTransID));

                    if (jobData.Tables.Count > 0 && jobData.Tables[0].Rows.Count > 0)
                    {
                        jobID = jobData.Tables[0].Rows[0]["JobID"].ToString();
                    }
                }
                if (jobID != "" && jobID != null)
                {
                    SqlParameter[] parj = new SqlParameter[2];
                    parj[0] = new SqlParameter("@jobid", jobID);
                    parj[1] = new SqlParameter("@cleanupreport", Reportdata);

                    SqlHelper.ExecuteDataset(ConfigurationManager.ConnectionStrings["con"].ToString(), CommandType.StoredProcedure, "Usp_Update_CleanupReport", parj);
                }
            }
            catch (Exception ex)
            {

            }
        }

        //internal static bool funcCheckIfFileIsCourrupted(string fullName)
        //{
        //    try
        //    {
        //        using (WordprocessingDocument docx= WordprocessingDocument.Open(fullName, false))
        //        {
        //        }
        //    }
        //    catch (Exception)
        //    {
        //        return false;
        //    }
        //}
        public static bool RefSearchAndReplace(Microsoft.Office.Interop.Word.Document oActiveDoc, string strSearchText, string strReplaceText, string strSearchInParaStyle, string strReplaceCharStyle, string strReplaceParaStyle, bool bCharStyle, bool bParaStyle, bool bReplaceAll, bool bGeneralCrosslink, bool bMatchWildCard)
        {
            // Clear Previous searched settings from Word Find dialog box
            //ClearFindAndReplaceParameters(oActiveDoc); // not required as of now //

            // get the range of the curent paragraph
            Range rngDoc = oActiveDoc.Range();

            // setup Microsoft Word Find based upon
            // Regular Expression Match
            rngDoc.Find.ClearFormatting();
            rngDoc.Find.Replacement.ClearFormatting();
            rngDoc.Find.Forward = true;
            rngDoc.Find.MatchWildcards = bMatchWildCard;
            List<string> strList = new List<string>();
            if (strSearchText.Length > 255 && strReplaceCharStyle == "weblinks")
            {
                bool replaceTrue = false;
                string first255Chars = strSearchText.Substring(0, 255);
                string next255chars = strSearchText.Substring(255);
                strList.Add(first255Chars);
                strList.Add(next255chars);
                foreach (string i in strList)
                {
                    strSearchText = i;
                    if (strSearchText != "" /*&& strSearchText.Length <= 255*/)

                        rngDoc.Find.Text = strSearchText;

                    if (strReplaceText != "")
                        rngDoc.Find.Replacement.Text = strReplaceText;

                    if (bReplaceAll == true && bGeneralCrosslink == true)
                    {
                        if (strSearchInParaStyle != "")
                            rngDoc.Find.set_Style(strSearchInParaStyle);

                        if (bParaStyle == true)
                            rngDoc.Find.Replacement.set_Style(strReplaceParaStyle);

                        if (bCharStyle == true)
                            rngDoc.Find.Replacement.set_Style(strReplaceCharStyle);
                    }

                    if (bGeneralCrosslink == false)
                    {
                        if (strSearchInParaStyle != "")
                            rngDoc.Find.set_Style(strSearchInParaStyle);

                        if (bCharStyle == true)
                            rngDoc.Find.Replacement.set_Style(strReplaceCharStyle);

                        if (bParaStyle == true)
                            rngDoc.Find.Replacement.set_Style(strReplaceParaStyle);
                    }

                    if (bReplaceAll == false)
                    {
                        if (strSearchInParaStyle != "")
                            rngDoc.Find.set_Style(strSearchInParaStyle);

                        if (bParaStyle == true)
                            rngDoc.Find.Replacement.set_Style(strReplaceParaStyle);

                        if (bCharStyle == true)
                            rngDoc.Find.Replacement.set_Style(strReplaceCharStyle);
                    }
                    replaceTrue = replaceReg(rngDoc, bReplaceAll, strReplaceCharStyle, strSearchInParaStyle);

                }
                return replaceTrue;

            }
            else
            {
                if (strSearchText != "")
                    rngDoc.Find.Text = strSearchText;

                if (strReplaceText != "")
                    rngDoc.Find.Replacement.Text = strReplaceText;

                if (bReplaceAll == true && bGeneralCrosslink == true)
                {
                    if (strSearchInParaStyle != "")
                        rngDoc.Find.set_Style(strSearchInParaStyle);

                    if (bParaStyle == true)
                        rngDoc.Find.Replacement.set_Style(strReplaceParaStyle);

                    if (bCharStyle == true)
                        rngDoc.Find.Replacement.set_Style(strReplaceCharStyle);
                }

                if (bGeneralCrosslink == false)
                {
                    if (strSearchInParaStyle != "")
                        rngDoc.Find.set_Style(strSearchInParaStyle);

                    if (bCharStyle == true)
                        rngDoc.Find.Replacement.set_Style(strReplaceCharStyle);

                    if (bParaStyle == true)
                        rngDoc.Find.Replacement.set_Style(strReplaceParaStyle);
                }

                if (bReplaceAll == false)
                {
                    if (strSearchInParaStyle != "")
                        rngDoc.Find.set_Style(strSearchInParaStyle);

                    if (bParaStyle == true)
                        rngDoc.Find.Replacement.set_Style(strReplaceParaStyle);

                    if (bCharStyle == true)
                        rngDoc.Find.Replacement.set_Style(strReplaceCharStyle);
                }

                // make search case sensitive
                object caseSensitive = "0";
                object missingValue = Type.Missing;

                rngDoc.Find.Wrap = Microsoft.Office.Interop.Word.WdFindWrap.wdFindStop;

                // wild cards
                object matchWildCards = Type.Missing;

                object replaceAll = Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll;
                //object replaceOne = Microsoft.Office.Interop.Word.WdReplace.wdReplaceOne;


                bool bBold = false;
                bool bItalic = false;

                if (bReplaceAll == true)
                {
                    // find the text in the word document
                    rngDoc.Find.Execute(ref missingValue, ref missingValue,
                        ref missingValue, ref missingValue, ref missingValue,
                        ref missingValue, ref missingValue, ref missingValue,
                        ref missingValue, ref missingValue, replaceAll,
                        ref missingValue, ref missingValue, ref missingValue,
                        ref missingValue);
                }
                else
                {
                    rngDoc.Find.Execute(ref missingValue, ref caseSensitive,
                           ref missingValue, ref missingValue, ref missingValue,
                           ref missingValue, ref missingValue, ref missingValue,
                           ref missingValue, ref missingValue, missingValue,
                           ref missingValue, ref missingValue, ref missingValue,
                           ref missingValue);

                    // we found the text
                    if (rngDoc.Find.Found)
                    {
                        do
                        {
                            bBold = false;
                            bItalic = false;

                            if (rngDoc.Bold == -1)
                            {
                                bBold = true;
                            }

                            if (rngDoc.Italic == -1)
                            {
                                bItalic = true;
                            }

                            if (rngDoc.ParagraphStyle.NameLocal != "TT" && rngDoc.ParagraphStyle.NameLocal != "BT" && rngDoc.ParagraphStyle.NameLocal != "FIGC" && rngDoc.ParagraphStyle.NameLocal != "REF1")
                            {
                                if (strReplaceCharStyle != "")
                                {
                                    rngDoc.set_Style(strReplaceCharStyle);
                                }
                            }

                            if (strSearchInParaStyle == rngDoc.ParagraphStyle.NameLocal)
                            {
                                if (strReplaceCharStyle != "")
                                {
                                    rngDoc.set_Style(strReplaceCharStyle);
                                }
                            }

                            if (rngDoc.ParagraphStyle.NameLocal == "BullList")
                            {
                                rngDoc.ListFormat.RemoveNumbers(NumberType: WdNumberType.wdNumberParagraph);
                            }

                            if (bBold)
                            {
                                rngDoc.Bold = -1;
                                bBold = false;
                            }

                            if (bItalic)
                            {
                                rngDoc.Italic = -1;
                                bItalic = false;
                            }

                            rngDoc.Move();

                            rngDoc.Find.Execute(ref missingValue, ref caseSensitive,
                            ref missingValue, ref missingValue, ref missingValue,
                            ref missingValue, ref missingValue, ref missingValue,
                            ref missingValue, ref missingValue, missingValue,
                            ref missingValue, ref missingValue, ref missingValue,
                            ref missingValue);

                        } while (rngDoc.Find.Found);

                        return true;
                    }
                }


                return false;
            }

        }

        private static bool replaceReg(Range rngDoc, bool bReplaceAll, string strReplaceCharStyle, string strSearchInParaStyle)
        {
            // make search case sensitive
            object caseSensitive = "0";
            object missingValue = Type.Missing;

            rngDoc.Find.Wrap = Microsoft.Office.Interop.Word.WdFindWrap.wdFindStop;

            // wild cards
            object matchWildCards = Type.Missing;

            object replaceAll = Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll;
            //object replaceOne = Microsoft.Office.Interop.Word.WdReplace.wdReplaceOne;


            bool bBold = false;
            bool bItalic = false;

            if (bReplaceAll == true)
            {
                // find the text in the word document
                rngDoc.Find.Execute(ref missingValue, ref missingValue,
                    ref missingValue, ref missingValue, ref missingValue,
                    ref missingValue, ref missingValue, ref missingValue,
                    ref missingValue, ref missingValue, replaceAll,
                    ref missingValue, ref missingValue, ref missingValue,
                    ref missingValue);
            }
            else
            {
                rngDoc.Find.Execute(ref missingValue, ref caseSensitive,
                       ref missingValue, ref missingValue, ref missingValue,
                       ref missingValue, ref missingValue, ref missingValue,
                       ref missingValue, ref missingValue, missingValue,
                       ref missingValue, ref missingValue, ref missingValue,
                       ref missingValue);

                // we found the text
                if (rngDoc.Find.Found)
                {
                    do
                    {
                        bBold = false;
                        bItalic = false;

                        if (rngDoc.Bold == -1)
                        {
                            bBold = true;
                        }

                        if (rngDoc.Italic == -1)
                        {
                            bItalic = true;
                        }

                        if (rngDoc.ParagraphStyle.NameLocal != "TT" && rngDoc.ParagraphStyle.NameLocal != "BT" && rngDoc.ParagraphStyle.NameLocal != "FIGC")
                        {
                            if (strReplaceCharStyle != "")
                            {
                                rngDoc.set_Style(strReplaceCharStyle);
                            }
                        }

                        if (strSearchInParaStyle == rngDoc.ParagraphStyle.NameLocal)
                        {
                            if (strReplaceCharStyle != "")
                            {
                                rngDoc.set_Style(strReplaceCharStyle);
                            }
                        }

                        if (rngDoc.ParagraphStyle.NameLocal == "BullList")
                        {
                            rngDoc.ListFormat.RemoveNumbers(NumberType: WdNumberType.wdNumberParagraph);
                        }

                        if (bBold)
                        {
                            rngDoc.Bold = -1;
                            bBold = false;
                        }

                        if (bItalic)
                        {
                            rngDoc.Italic = -1;
                            bItalic = false;
                        }

                        rngDoc.Move();

                        rngDoc.Find.Execute(ref missingValue, ref caseSensitive,
                        ref missingValue, ref missingValue, ref missingValue,
                        ref missingValue, ref missingValue, ref missingValue,
                        ref missingValue, ref missingValue, missingValue,
                        ref missingValue, ref missingValue, ref missingValue,
                        ref missingValue);

                    } while (rngDoc.Find.Found);

                    return true;
                }
            }


            return false;
        }


    }
}
