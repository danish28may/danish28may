﻿using DocumentFormat.OpenXml.Packaging;
using OpenXmlPowerTools;
using System;
using System.IO;
using System.Text.RegularExpressions;
using DocumentFormat.OpenXml.Wordprocessing;
using DocumentFormat.OpenXml;
using System.Linq;
using System.Collections.Generic;
using Microsoft.Office.Interop.Word;
using System.Configuration;

namespace MultiInstanceJournalCleanup
{
    class SearchAndReplace
    {
        public static void GeneralSearchAndReplace(string strDocPath)
        {
            Microsoft.Office.Interop.Word.Document mdoc = null;

            try
            {
                ///configuration added by Karan Start
                GlobalMethods.CitationStyle = ConfigurationManager.AppSettings.Get("CitationStyle");
                List<string> CitationPatternsColl = new List<string>();

                ///Configuration read from Supporting folder
                CitationPatternsColl = GlobalMethods.ReadAndStoreFileValuesInArray(GlobalMethods.CitationStyle);
                ///configuration added by Karan End

                string strDocContent = null;

                // Read the Document Content from Word Document //
                //strDocContent = GlobalMethods.ReadDocumentContent(strDocPath);


                // Load Word Document Content
                mdoc = GlobalMethods.LoadWordDocument(strDocPath);

                strDocContent = mdoc.Content.Text;

                if (strDocContent == null)
                    return;

                // Search the patterns in the document content using Regular Expression
                if (mdoc != null)
                {

                    //Set all table alignment left and textwrapping false added by vikas on 05-10-2021
                    var tables = mdoc.Tables;
                    foreach (Microsoft.Office.Interop.Word.Table table in tables)
                    {
                        table.Rows.Alignment = WdRowAlignment.wdAlignRowLeft;
                        table.Rows.WrapAroundText = 0;/////0 value for none textwraping
                    }


                    //GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    List<string> strMatchText = new List<string>();
                    string strSearchRegEx = null;

                    #region below logic implemeted in ChekAllPara Function.
                    /////21-06-2018 commneted by Karan Start
                    ////Table lable strong style handle in MapStylesWithWordTemplate.CheckAllPara(ff.FullName); function
                    ////////strMatchText.Clear();
                    ////////strSearchRegEx = null;

                    ////////strSearchRegEx = @"(Fig [0-9]+\.[0-9]+\-[0-9]+)";
                    ////////strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    ////////if (strMatchText.Count > 0)
                    ////////{
                    ////////    for (int counter = 0; counter < strMatchText.Count; counter++)
                    ////////    {
                    ////////        GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "FIGC", "label-Strong", "", true, false, false, true,false);
                    ////////    }
                    ////////}

                    //////////GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    ////////strMatchText.Clear();
                    ////////strSearchRegEx = null;

                    ////////strSearchRegEx = @"(Fig\. [0-9]+\.[0-9]+\-[0-9]+)";
                    ////////strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    ////////if (strMatchText.Count > 0)
                    ////////{
                    ////////    for (int counter = 0; counter < strMatchText.Count; counter++)
                    ////////    {
                    ////////        GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "FIGC", "label-Strong", "", true, false, false, true, false);
                    ////////    }
                    ////////}


                    //////////GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    ////////strMatchText.Clear();
                    ////////strSearchRegEx = null;

                    ////////strSearchRegEx = @"(Fig\. [0-9]+)";
                    ////////strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    ////////if (strMatchText.Count > 0)
                    ////////{
                    ////////    for (int counter = 0; counter < strMatchText.Count; counter++)
                    ////////    {
                    ////////        GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "FIGC", "label-Strong", "", true, false, false, true, false);
                    ////////    }
                    ////////}

                    //////////GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    ////////strMatchText.Clear();
                    ////////strSearchRegEx = null;

                    ////////strSearchRegEx = @"(Fig\. [0-9]+\.[0-9]+)";
                    ////////strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    ////////if (strMatchText.Count > 0)
                    ////////{
                    ////////    for (int counter = 0; counter < strMatchText.Count; counter++)
                    ////////    {
                    ////////        GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "FIGC", "label-Strong", "", true, false, false, true, false);
                    ////////    }
                    ////////}
                    //////temp21-06-2018 End
                    #endregion

                    //GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    strMatchText.Clear();
                    strSearchRegEx = null;

                    ///configuration added by Karan Start
                    foreach (var item in CitationPatternsColl)
                    {
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, item);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                if (strMatchText[counter].ToLower().Contains("fig") || strMatchText[counter].ToLower().Contains("video") || strMatchText[counter].ToLower().Contains("graph") || (strMatchText[counter].ToLower().Contains("appendi") && GlobalMethods.strClientName.ToLower() != "informs"))  // Developer Name: Priyanka Vishwakarma, Date:12 - 02 - 2020 Requirement: for appendix para apply AppendixHead paragraph style., Integrated by:Vikas sir.
                                {
                                    GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                                }
                                if (strMatchText[counter].ToLower().Contains("tab"))
                                {
                                    GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, false, false);
                                }
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;
                    }
                    ///configuration added by Karan End

                    #region 2times
                    ////22-06-2018
                    //////cover
                    ////strSearchRegEx = @"(Fig\. [0-9]+\.[0-9]+)";
                    ////strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    ////if (strMatchText.Count > 0)
                    ////{
                    ////    for (int counter = 0; counter < strMatchText.Count; counter++)
                    ////    {
                    ////        GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                    ////    }
                    ////}

                    //////cover
                    ////strMatchText.Clear();
                    ////strSearchRegEx = null;

                    ////strSearchRegEx = @"(Figs\. [0-9]+\, [0-9]+)";
                    ////strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    ////if (strMatchText.Count > 0)
                    ////{
                    ////    for (int counter = 0; counter < strMatchText.Count; counter++)
                    ////    {
                    ////        GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                    ////    }
                    ////}


                    ////strMatchText.Clear();
                    ////strSearchRegEx = null;
                    //////changes by Karan on 30-4-2018

                    //////cover
                    //////1)**********start for Figs. 1–3 and tables*****************//
                    ////strSearchRegEx = @"(Figs.\s+([0-9]\–)+([0-9]))";
                    ////strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    ////if (strMatchText.Count > 0)
                    ////{
                    ////    for (int counter = 0; counter < strMatchText.Count; counter++)
                    ////    {
                    ////        GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                    ////    }
                    ////}
                    ////strMatchText.Clear();
                    ////strSearchRegEx = null;

                    ////strSearchRegEx = @"(Tables.\s+([0-9]\–)+([0-9]))";
                    ////strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    ////if (strMatchText.Count > 0)
                    ////{
                    ////    for (int counter = 0; counter < strMatchText.Count; counter++)
                    ////    {
                    ////        GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, false, false);
                    ////    }
                    ////}
                    ////strMatchText.Clear();
                    ////strSearchRegEx = null;
                    //////**********end for Figs. 1–3 and tables*****************//

                    ///////cover
                    //////2)**********start for Figs 1 and 2 and tables*****************//
                    ////strSearchRegEx = @"(Figs\s+([0-9])\s+(and\s)+([0-9]))";
                    ////strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    ////if (strMatchText.Count > 0)
                    ////{
                    ////    for (int counter = 0; counter < strMatchText.Count; counter++)
                    ////    {
                    ////        GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                    ////    }
                    ////}
                    ////strMatchText.Clear();
                    ////strSearchRegEx = null;

                    ////strSearchRegEx = @"(Tables\s+([0-9])\s+(and\s)+([0-9]))";
                    ////strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    ////if (strMatchText.Count > 0)
                    ////{
                    ////    for (int counter = 0; counter < strMatchText.Count; counter++)
                    ////    {
                    ////        GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, false, false);
                    ////    }
                    ////}
                    ////strMatchText.Clear();
                    ////strSearchRegEx = null;
                    //////**********end for Figs 1 and 2 and tables*****************//

                    ///////cover
                    //////3)**********start for Figs 1 to 2 and tables*****************//
                    ////strSearchRegEx = @"(Figs\s+([0-9])\s+(to\s)+([0-9]))";
                    ////strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    ////if (strMatchText.Count > 0)
                    ////{
                    ////    for (int counter = 0; counter < strMatchText.Count; counter++)
                    ////    {
                    ////        GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                    ////    }
                    ////}
                    ////strMatchText.Clear();
                    ////strSearchRegEx = null;

                    ////strSearchRegEx = @"(Tables\s+([0-9])\s+(to\s)+([0-9]))";
                    ////strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    ////if (strMatchText.Count > 0)
                    ////{
                    ////    for (int counter = 0; counter < strMatchText.Count; counter++)
                    ////    {
                    ////        GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, false, false);
                    ////    }
                    ////}
                    ////strMatchText.Clear();
                    ////strSearchRegEx = null;
                    //////**********end for Figs 1 to 2 and tables*****************//

                    ///////cover
                    //////4)**********start for Figs 1 & 2 and tables*****************//
                    ////strSearchRegEx = @"(Figs\s+([0-9])\s+(&\s)+([0-9]))";
                    ////strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    ////if (strMatchText.Count > 0)
                    ////{
                    ////    for (int counter = 0; counter < strMatchText.Count; counter++)
                    ////    {
                    ////        GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                    ////    }
                    ////}
                    ////strMatchText.Clear();
                    ////strSearchRegEx = null;

                    ////strSearchRegEx = @"(Tables\s+([0-9])\s+(&\s)+([0-9]))";
                    ////strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    ////if (strMatchText.Count > 0)
                    ////{
                    ////    for (int counter = 0; counter < strMatchText.Count; counter++)
                    ////    {
                    ////        GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, false, false);
                    ////    }
                    ////}
                    ////strMatchText.Clear();
                    ////strSearchRegEx = null;
                    //////**********end for Figs 1 & 2 and tables*****************//

                    ///////cover
                    //////5)**********start for Fig 1 and Fig 2 and tables*****************//
                    ////strSearchRegEx = @"(Fig\s+([0-9])\s+(and\s)+Fig\s+([0-9]))";
                    ////strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    ////if (strMatchText.Count > 0)
                    ////{
                    ////    for (int counter = 0; counter < strMatchText.Count; counter++)
                    ////    {
                    ////        GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                    ////    }
                    ////}
                    ////strMatchText.Clear();
                    ////strSearchRegEx = null;

                    ////strSearchRegEx = @"(Table\s+([0-9])\s+(and\s)+Table\s+([0-9]))";
                    ////strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    ////if (strMatchText.Count > 0)
                    ////{
                    ////    for (int counter = 0; counter < strMatchText.Count; counter++)
                    ////    {
                    ////        GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, false, false);
                    ////    }
                    ////}
                    ////strMatchText.Clear();
                    ////strSearchRegEx = null;

                    //////6)*************start for "Figs. 1B and C, and 2" and Tables*************************//
                    ///////19-6-2018 Start                   
                    //////strSearchRegEx = @"([Figs.\s]+)+([0-9?A-Za-z]+)\s+([and]+)\s+([0-9?A-Za-z\,]+)\s+([and]+)\s([0-9])";
                    //////strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    //////foreach (var item in strMatchText)
                    //////{
                    //////    string[] separators = { "," };
                    //////    string[] links = item.Split(separators, StringSplitOptions.RemoveEmptyEntries);
                    //////    if(links[0] != null && links[0] != "")
                    //////    {
                    //////        string str1 = links[0];
                    //////        strSearchRegEx = @"(Figs\. [0-9]+)";
                    //////        strMatchText = GlobalMethods.DocumentRegEx(str1, strSearchRegEx);
                    //////        if (strMatchText.Count > 0)
                    //////        {
                    //////            for (int counter = 0; counter < strMatchText.Count; counter++)
                    //////            {
                    //////                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                    //////            }
                    //////        }
                    //////    }
                    //////    if (links[1] != null && links[1] != "")
                    //////    {
                    //////        string str2 = links[1];
                    //////        strSearchRegEx = @"([0-9]+)";
                    //////        strMatchText = GlobalMethods.DocumentRegEx(str2, strSearchRegEx);
                    //////        if (strMatchText.Count > 0)
                    //////        {
                    //////            for (int counter = 0; counter < strMatchText.Count; counter++)
                    //////            {
                    //////                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                    //////            }
                    //////        }
                    //////    }
                    //////    strMatchText.Clear();
                    //////    strSearchRegEx = null;
                    //////}

                    //////strMatchText.Clear();
                    //////strSearchRegEx = null;
                    ///////19-06-2018 End
                    //////**********end for Figs 1 & 2 and tables*****************//

                    //////*************start for Table2******************** //
                    ////strSearchRegEx = @"(Table+([0-9]))";
                    ////strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    ////if (strMatchText.Count > 0)
                    ////{
                    ////    for (int counter = 0; counter < strMatchText.Count; counter++)
                    ////    {
                    ////        GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, false, false);
                    ////    }
                    ////}
                    ////strMatchText.Clear();
                    ////strSearchRegEx = null;
                    //////**************** end for Table2**************//
                    //////end condition by Karan on 30-4-2018

                    //////cover
                    ////////new condition added by Karan on 21Feb,2018
                    ////strSearchRegEx = @"(Figs\. [0-9]+ and [0-9]+)";
                    ////strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    ////if (strMatchText.Count > 0)
                    ////{
                    ////    for (int counter = 0; counter < strMatchText.Count; counter++)
                    ////    {
                    ////        GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                    ////    }
                    ////}
                    ///////condition ended by Karan on 21Feb,2018

                    //////GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    ////#region pattern allready covered Start
                    ///////commented by Karan on 21-06-2018 pattern allready covered Start
                    ///////pattern allready covered
                    //////////strMatchText.Clear();
                    //////////strSearchRegEx = null;

                    //////////strSearchRegEx = @"(Fig\. [0-9]+)";
                    //////////strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    //////////if (strMatchText.Count > 0)
                    //////////{
                    //////////    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //////////    {
                    //////////        GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                    //////////    }
                    //////////}

                    //////////strMatchText.Clear();
                    //////////strSearchRegEx = null;

                    //////////strSearchRegEx = @"(Fig\.[0-9]+)";
                    //////////strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    //////////if (strMatchText.Count > 0)
                    //////////{
                    //////////    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //////////    {
                    //////////        GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                    //////////    }
                    //////////}

                    ////////////GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    //////////strMatchText.Clear();
                    //////////strSearchRegEx = null;

                    //////////strSearchRegEx = @"(Table [0-9]+\.[0-9]+)";
                    //////////strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    //////////if (strMatchText.Count > 0)
                    //////////{
                    //////////    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //////////    {
                    //////////        GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, false, false);
                    //////////    }
                    //////////}

                    ////////////GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    //////////strMatchText.Clear();
                    //////////strSearchRegEx = null;

                    //////////strSearchRegEx = @"(Table [0-9]+)";
                    //////////strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    //////////if (strMatchText.Count > 0)
                    //////////{
                    //////////    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //////////    {
                    //////////        GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, false, false);
                    //////////    }
                    //////////}
                    ///////commented by Karan on 21-06-2018 pattern allready covered End
                    ////#endregion pattern allready covered End


                    //////GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    //////////////////////// For Video ////////////////////////////////////
                    ////22-06-2018
                    #endregion

                    ///special character regex
                    //strMatchText.Clear();
                    //strSearchRegEx = null;
                    //strSearchRegEx = @"(Figs.\s+([0-9]\–)+([0-9]))";
                    //strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    //if (strMatchText.Count > 0)
                    //{
                    //    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //    {
                    //        GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                    //    }
                    //}
                    //strMatchText.Clear();
                    //strSearchRegEx = null;

                    //strSearchRegEx = @"(Tables.\s+([0-9]\–)+([0-9]))";
                    //strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    //if (strMatchText.Count > 0)
                    //{
                    //    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //    {
                    //        GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, false, false);
                    //    }
                    //}
                    ///special character regex
                    ///
                    if (GlobalMethods.strClientName.ToLower() == "ssllc")
                    {
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Fig\. [0-9]+[\-|\–|\—][0-9]+)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);
                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                            }
                        }
                    }
                    if (GlobalMethods.strClientName.ToLower() == "ufl")
                    {
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Figure ([0-9]+))";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "FIGC", "label-Strong", "", true, false, true, true, false);
                            }
                        }

                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(FIG\.\s{1,}[0-9]+)"; //Developer NAme:Priyanka vishwakarma,Date:19-03-2021,Requirement:Add pattren for apply label strong char style 
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "FIGC", "label-Strong", "", true, false, true, true, false);
                            }
                        }

                       
                        //Developer Name:Priyanka Vishwakarma ,Date:07-09-2020 ,Requirement:Add Label strong to Fig. 1 in FIGc paragaraph
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Fig.\s{1,}[0-9])";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "FIGC", "label-Strong", "", true, false, true, true, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Table [0-9]+\.)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "TT", "label-Strong", "", true, false, true, true, false);
                            }
                        }
                        //---------End on 07-09-2020
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Table ([0-9]+))";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "TT", "label-Strong", "", true, false, true, true, false);
                            }
                        }
                    }

                    if (GlobalMethods.strClientName.ToLower() == "informs")///Added for informs client by vikas on 05-09-2020
                    {

                        //Citation style Apply

                        strMatchText.Clear();
                        strSearchRegEx = null;
                        strSearchRegEx = @"(Lemma ([0-9]+))";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_lemma", "", true, false, false, false, false);
                            }
                        }

                        strMatchText.Clear();
                        strSearchRegEx = null;
                        strSearchRegEx = @"(Theorem ([0-9]+))";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_theoram", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;
                        strSearchRegEx = @"(Example ([0-9]+))";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_example", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;
                        strSearchRegEx = @"(Proposition ([0-9]+))";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_proposition", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;
                        strSearchRegEx = @"(Assumption ([0-9]+))";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_assumption", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;
                        strSearchRegEx = @"(Remark ([0-9]+))";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_remark", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;
                        strSearchRegEx = @"(Defination ([0-9]+))";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_defination", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;
                        strSearchRegEx = @"(Section ([0-9]+) |Section ([0-9]+)\.([0-9]+))";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_sec", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;
                        strSearchRegEx = @"(\(([0-9]+){3}\))|(\([0-9]+\))";  //Developer Name:Priyanka Vishwakarma ,Date:17-09-2020 ,add pattern Apply citeeq to equation callout
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0 && GlobalMethods.bEqcheck)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_eq", "", true, false, false, false, false);
                            }
                        }
                        ///////Label strong style apply
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Lemma ([0-9]+))";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "LemmaT", "label-Strong", "", true, false, true, true, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Theorem ([0-9]+))";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "TheoramT", "label-Strong", "", true, false, true, true, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;
                        strSearchRegEx = @"(Example ([0-9]+))";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "ExampleT", "label-Strong", "", true, false, true, true, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;
                        strSearchRegEx = @"(Proposition ([0-9]+))";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "PropositionT", "label-Strong", "", true, false, true, true, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;
                        strSearchRegEx = @"(Assumption ([0-9]+))";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "AssumptionT", "label-Strong", "", true, false, true, true, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;
                        strSearchRegEx = @"(Remark ([0-9]+))";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "RemarkT", "label-Strong", "", true, false, true, true, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;
                        strSearchRegEx = @"(Defination ([0-9]+))";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "DefinationT", "label-Strong", "", true, false, true, true, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;
                        strSearchRegEx = @"(\(([0-9]+)\))";/////For eqution number linking
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "EQ", "label-Strong", "", true, false, true, true, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;
                        strSearchRegEx = @"(Figure (A[0-9]+))";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0 && GlobalMethods.bEqcheck)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;
                        strSearchRegEx = @"(Table (A[0-9]+))";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0 && GlobalMethods.bEqcheck)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Table (A[0-9]+))";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "TT", "label-Strong", "", true, false, true, true, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Figure (A[0-9]+))";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "FIGC", "label-Strong", "", true, false, true, true, false);
                            }
                        }

                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"(Figure\s{1,}[0-9]+\.)"; //Developer NAme:Priyanka vishwakarma,Date:19-03-2021,Requirement:Add pattren for apply label strong char style 
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "FIGC", "label-Strong", "", true, false, true, true, false);
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"(Video [0-9]+\.[0-9]+\-[0-9]+)";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "FIGC", "label-Strong", "", true, false, true, true, false);
                        }
                    }


                    if (GlobalMethods.strClientName.ToLower() == "informs")   //added by priyanka for informs 15-09-2020 for apply hyperlink in affl tag.
                    {
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"([A-Za-z]+[\@][A-Za-z]+\.[A-Za-z]{2}\.[A-Za-z]{2})";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "AFFL", "Hyperlink", "", true, false, true, true, false);
                            }
                        }
                    }

                    //Developer Name:Priyanka Vishwakarma, Date:20-04-2021, Requirement:Add pattern for apply labelstrong in TT paragraph
                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"(Table[0-9]+\s)";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "TT", "label-Strong", "", true, false, true, true, false);
                        }
                    }


                    //08-05-2021
                    if (GlobalMethods.strCopyediting == "false" && GlobalMethods.strJournalArticlePath.Contains("\\India\\"))
                    {
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Appendix\s[0-9]+\.)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "TT", "label-Strong", "", true, false, true, true, false);
                            }
                        }
                    }
                    //end in 08-05-2021
                    //GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    /////////////////// For Video ////////////////////////////////////

                    strMatchText.Clear();
                    strSearchRegEx = null;

                    #region below logic implemeted in ChekAllPara Function.
                    /////21-06-2018 commneted by Karan Start
                    ////Table lable strong style handle in MapStylesWithWordTemplate.CheckAllPara(ff.FullName); function
                    ////////strSearchRegEx = @"(Table [0-9]+\.[0-9]+)";
                    ////////strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    ////////if (strMatchText.Count > 0)
                    ////////{
                    ////////    for (int counter = 0; counter < strMatchText.Count; counter++)
                    ////////    {
                    ////////        GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "TT", "label-Strong", "", true, false, true, true, false);
                    ////////    }
                    ////////}

                    //////////GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    ////////strMatchText.Clear();
                    ////////strSearchRegEx = null;

                    ////////strSearchRegEx = @"(Table [0-9]+\.[0-9]+\-[0-9]+)";
                    ////////strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    ////////if (strMatchText.Count > 0)
                    ////////{
                    ////////    for (int counter = 0; counter < strMatchText.Count; counter++)
                    ////////    {
                    ////////        GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "TT", "label-Strong", "", true, false, true, true, false);
                    ////////    }
                    ////////}

                    //////////GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    ////////strMatchText.Clear();
                    ////////strSearchRegEx = null;


                    ////////strSearchRegEx = @"(Table [0-9]+)";
                    ////////strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    ////////if (strMatchText.Count > 0)
                    ////////{
                    ////////    for (int counter = 0; counter < strMatchText.Count; counter++)
                    ////////    {
                    ////////        GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "TT", "label-Strong", "", true, false, true, true, false);
                    ////////    }
                    ////////}

                    //////////GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    ////////strMatchText.Clear();
                    ////////strSearchRegEx = null;
                    //////temp21-06-2018 End
                    #endregion


                    strSearchRegEx = @"\b(?:https?://|www\.)[^ \f\n\r\t\v\]]+\b(\/?)+";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    //if (strMatchText.Count > 0)
                    //{
                    //    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //    {
                    //        GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "weblinks", "", true, false, true, false, false);
                    //    }
                    //}



                    if (strMatchText.Count > 0)////Added by priyanka on 09-09-2020 integrated by vikas
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            if (strMatchText[counter].Contains('<'))/////Checked for refernce link</erf>
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter].Split('<').FirstOrDefault(), "", "", "weblinks", "", true, false, true, false, false);
                            }
                            else
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "weblinks", "", true, false, true, false, false);
                            }
                        }
                    }
                    //GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "Hyperlink", "", true, false, true, false, false);
                        }
                    }

                    if (GlobalMethods.strJournalArticlePath.ToLower().Contains(@"\journal\ilo\"))/////Specific to ILO journal only
                    {
                        //////For ILO journal only
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(\*)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "AU", "cite_fn", "", true, false, true, true, false);
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "FTN", "label-fn", "", true, false, true, true, false);

                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Table ([0-9]+))";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "TT", "label-Strong", "", true, false, true, true, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Figure ([0-9]+))";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "FIGC", "label-Strong", "", true, false, true, true, false);
                            }
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;


                    if (GlobalMethods.strClientName.ToLower() == "ufl")//Developer Name:Priyanka Vishwakarma,Date:11-05-2021,Requirement:Add condiiton for apply label-strong in figc paragraph.
                    {
                        strMatchText.Clear();
                        strSearchRegEx = null;
                        strSearchRegEx = @"(FIG\s[0-9]+)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "FIGC", "label-Strong", "", true, false, true, true, false);
                            }
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;
                    if (GlobalMethods.strClientName.ToLower() == "sage")//Developer Name:Priyanka Vishwakarma,Date:01-06-2021,Requirement:Add condiiton for apply label-strong in figc paragraph.
                    {
                        strSearchRegEx = @"(Table\s[0-9]+[A-Z]\.)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "TT", "label-Strong", "", true, false, true, true, false);
                            }
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;

                    if (GlobalMethods.strClientName.ToLower() == "sage")
                    {
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Figure\s[0-9]+\.)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "FIGC", "label-Strong", "", true, false, true, true, false);
                            }
                        }

                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Table\s[A-Z][0-9]+\.?)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "TT", "label-Strong", "", true, false, true, true, false);
                            }
                        }
                    }

                    strSearchRegEx = @"(Figure\s[A-Z][0-9]+\.?)";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "FIGC", "label-Strong", "", true, false, true, true, false);
                        }
                    }
                    strSearchRegEx = @"(Table\s[0-9]+\.)";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "TT", "label-Strong", "", true, false, true, true, false);
                        }
                    }

                    if (GlobalMethods.strClientName.ToLower() == "ssllc")
                    {
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"^(Figure\s[0-9]+\s{0,}[A-Za-z\,\s]+[\:|\.|\-])|^(Figure\s[0-9]+\s{0,}[A-Za-z]\s{0,}[\-|\—|\–][A-Za-z][\:|\.|\-])";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "FIGC", "label-Strong", "", true, false, true, true, false);
                            }
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;
                    if (GlobalMethods.strClientName.ToLower() == "jaypee" || GlobalMethods.strClientName.ToLower() == "ssllc") //Developer Name:Priyanka Vishwakarma, Date:5-10-2021, Add pattern for marr label-strong in table and figure
                      {

                        strSearchRegEx = @"(Figure\s[0-9]+\:)|(Fig\.\s[0-9]+\:)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "FIGC", "label-Strong", "", true, false, true, true, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Table\s[0-9]+\:)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "TT", "label-Strong", "", true, false, true, true, false);
                            }
                        }
                    }

                    //Relace single Quote
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "”.", ".”", "", "", "", false, false, true, false, false);
                    GlobalMethods.SearchAndReplace(mdoc, "\".", ".\"", "", "", "", false, false, true, false, false);


                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "^p ", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, " ^p", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "<jrn> ^p", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "<jrn> </jrn>", "", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    // GlobalMethods.SearchAndReplace(mdoc, "^p^p", "^p", "", "", "", false, false, true, false, false);//commented on 11020202 For boxstart and BoxEnd style remove. 
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    //GlobalMethods.SearchAndReplace(mdoc, "^g", "^&", "", "", "FIG", false, true, true, false);
                    GlobalMethods.SearchAndReplace(mdoc, "^~", "-", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "", "", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    //GlobalMethods.SearchAndReplace(mdoc, "", "", "BullList", "", "", false, false, false, false, false);//19022020 comment for indend remove.
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    object oMissing = System.Reflection.Missing.Value;

                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;

                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                if (mdoc != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;
                }
                if (GlobalMethods.wordApp != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    ((_Application)GlobalMethods.wordApp).Quit(ref oMissing, ref oMissing, ref oMissing);
                    GlobalMethods.wordApp = null;
                }
            }


        }
        public static void GeneralSearchAndReplaceInRef(string strDocPath)
        {
            Microsoft.Office.Interop.Word.Document mdoc = null;

            try
            {

                string strDocContent = null;
                mdoc = GlobalMethods.LoadWordDocument(strDocPath);

                strDocContent = mdoc.Content.Text;

                if (strDocContent == null)
                    return;

                // Search the patterns in the document content using Regular Expression
                if (mdoc != null)
                {
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, " ", " ", "REF1", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "http://dx.doi.org/10.", "http://doi.org/10.", "REF1", "", "", false, false, true, false, false);

                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "Available from: 10.", "DOI: 10.", "REF1", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "Available from:10.", "DOI: 10.", "REF1", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "Availablefrom:10.", "DOI: 10.", "REF1", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "Available from: https://doi.org/", "DOI: ", "REF1", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "Available from:https://doi.org/", "DOI: ", "REF1", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "Availablefrom:https://doi.org/", "DOI: ", "REF1", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "Available from: http://doi.org/", "DOI: ", "REF1", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "Available from:http://doi.org/", "DOI: ", "REF1", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "Availablefrom:http://doi.org/10.", "DOI: 10.", "REF1", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "Available from:h", "Available from: h", "REF1", "", "", false, false, true, false, false);


                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "Available from: 10.", "DOI: 10.", "REF1", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "Available from:10.", "DOI: 10.", "REF1", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "Availablefrom:10.", "DOI: 10.", "REF1", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "Available from: https://doi.org/10.", "DOI: 10.", "REF1", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "Available from:https://doi.org/10.", "DOI: 10.", "REF1", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory); ;
                    GlobalMethods.SearchAndReplace(mdoc, "Availablefrom:https://doi.org/10.", "DOI: 10.", "REF1", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory); ;
                    GlobalMethods.SearchAndReplace(mdoc, "Available from: http://doi.org/10.", "DOI: 10.", "REF1", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory); ;
                    GlobalMethods.SearchAndReplace(mdoc, "Available from:http://doi.org/10.", "DOI: 10.", "REF1", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory); ;
                    GlobalMethods.SearchAndReplace(mdoc, "Availablefrom:http://doi.org/10.", "DOI: 10.", "REF1", "", "", false, false, true, false, false);

                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory); ;
                    GlobalMethods.SearchAndReplace(mdoc, "Availablefrom:http://dx.doi.org/10.", "DOI: 10.", "REF1", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory); ;
                    GlobalMethods.SearchAndReplace(mdoc, "Availablefrom:https://dx.doi.org/10.", "DOI: 10.", "REF1", "", "", false, false, true, false, false);

                    GlobalMethods.SearchAndReplace(mdoc, "https://doi.org/10.", "DOI: 10.", "REF1", "", "", false, false, true, false, false);
                    GlobalMethods.SearchAndReplace(mdoc, "http://doi.org/10.", "DOI: 10.", "REF1", "", "", false, false, true, false, false);
                    GlobalMethods.SearchAndReplace(mdoc, "https://dx.doi.org/10.", "DOI: 10.", "REF1", "", "", false, false, true, false, false);
                    GlobalMethods.SearchAndReplace(mdoc, "http://dx.doi.org/10.", "DOI: 10.", "REF1", "", "", false, false, true, false, false);



                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "Available from: doi: ", "DOI: ", "REF1", "", "", false, false, true, false, false);



                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "Available from:h", "Available from: h", "REF1", "", "", false, false, true, false, false);

                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "doi: ", "DOI: ", "REF1", "", "", false, false, true, false, false);

                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, " 10.5005/", " DOI: 10.5005/", "REF1", "", "", false, false, true, false, false);

                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, " DOI: DOI:", " DOI:", "REF1", "", "", false, false, true, false, false);

                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "http://doi.org/10.", "DOI: 10.", "REF1", "", "", false, false, true, false, false);

                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, " et al: ", "  et al. ", "REF1", "", "", false, false, true, false, false);

                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, " DOI10", " DOI: 10", "REF1", "", "", false, false, true, false, false);

                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, " DOI 10", " DOI: 10", "REF1", "", "", false, false, true, false, false);

                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, ".; ", ". ", "REF1", "", "", false, false, true, false, false);


                    //    GlobalMethods.SearchAndReplace(mdoc, "([A-Z])([. ]+)([A-Z])([. ]+)([A-Z])([. ]+)([A-Z])([. ]+)", "\\1\\3\\5\\7\\8", "REF1", "", "", false, false, true, false, true);
                    //     GlobalMethods.SearchAndReplace(mdoc, "([A-Z])([. ]+)([A-Z])([. ]+)([A-Z])([. ]+)", "\\1\\3\\5\\6", "REF1", "", "", false, false, true, false, true);
                    //      GlobalMethods.SearchAndReplace(mdoc, "([A-Z])([. ]+)([A-Z])([. ]+)", "\\1\\3\\4", "REF1", "", "", false, false, true, false, true);


                    object oMissing = System.Reflection.Missing.Value;

                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;

                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                if (mdoc != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;
                }
                if (GlobalMethods.wordApp != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    ((_Application)GlobalMethods.wordApp).Quit(ref oMissing, ref oMissing, ref oMissing);
                    GlobalMethods.wordApp = null;
                }
            }


        }

        public static void SearchAndReplacecitation(string strDocPath)
        {
            Microsoft.Office.Interop.Word.Application mywordApp = null;

            try
            {
                string strDocContent = null;

                // Read the Document Content from Word Document //
                //strDocContent = GlobalMethods.ReadDocumentContent(strDocPath);

                Microsoft.Office.Interop.Word.Document mdoc = null;

                // Load Word Document
                mdoc = GlobalMethods.LoadWordDocument(strDocPath);

                mywordApp = mdoc.Application;
                strDocContent = mdoc.Content.Text;
                //strDocContent = mdoc.Content.Text;

                //if (strDocContent == null)
                //    return;

                // Search the patterns in the document content using Regular Expression
                if (mdoc != null)
                {

                    List<string> CitationPatternsColl = new List<string>();

                    ///Configuration read from Supporting folder
                    CitationPatternsColl = GlobalMethods.ReadAndStoreFileValuesInArray(GlobalMethods.CitationStyle);

                    if (CitationPatternsColl.Count > 0)
                    {
                        for (int nIndex = 0; nIndex < CitationPatternsColl.Count; nIndex++)
                        {
                            string[] t = CitationPatternsColl[nIndex].Split('|');

                            bool bMatchWildCard = false;
                            if (t.Length > 3)
                            {
                                if (t[2] == "true")
                                    bMatchWildCard = true;
                                else
                                    bMatchWildCard = false;

                                List<string> strMatchText = new List<string>();
                                ///
                                string i = t[0];
                                string style = t[3];
                                strMatchText = GlobalMethods.DocumentRegEx(strDocContent, i);




                                for (int counter = 0; counter < strMatchText.Count; counter++)
                                {
                                    string matchgrp = groupmatchword(strMatchText[counter], i, t[1]);
                                    if (style == "cite_fig")
                                    {
                                        GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "t[1]", "", "cite_fig", "", true, false, false, false, bMatchWildCard);
                                    }
                                    if (style == "cite_tbl")
                                    {
                                        GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, false, bMatchWildCard);
                                    }
                                    matchgrp = null;
                                }

                                strMatchText.Clear();

                                ///

                                // GlobalMethods.SearchAndReplace(mdoc, t[0], t[1], "", "", "", false, false, true, false, bMatchWildCard);
                            }
                        }
                    }

                    object oMissing = System.Reflection.Missing.Value;

                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;
                }
            }
            catch (Exception ex)
            {
                // GlobalMethods.DisposeCOMObject();
            }
            finally
            {
                //if (GlobalMethods.wordApp != null)
                //{
                //    object oMissing = System.Reflection.Missing.Value;
                //    ((_Application)GlobalMethods.wordApp).Quit(ref oMissing, ref oMissing, ref oMissing);
                //    GlobalMethods.wordApp = null;
                //}

                if (mywordApp != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    ((_Application)mywordApp).Quit(ref oMissing, ref oMissing, ref oMissing);
                    mywordApp = null;
                }

            }
        }

        public static string groupmatchword(string strMatchText, string strSearchRegEx, string groupnumber)
        {
            string searchstring = null;


            int totalgroupcount = Convert.ToInt32(groupnumber.Substring(groupnumber.Length - 1));

            string[] separators = { "\\" };
            var totalgroupcount1 = groupnumber.Split(separators, StringSplitOptions.RemoveEmptyEntries);
            ////string text = "One car red car blue car";
            ////string pat = @"(\w+)\s+(car)";

            // Instantiate the regular expression object.
            Regex r = new Regex(strSearchRegEx, RegexOptions.IgnoreCase);

            // Match the regular expression pattern against a text string.
            Match m = r.Match(strMatchText);
            ///int matchCount = 0;
            while (m.Success)
            {
                //Console.WriteLine("Match" + (++matchCount));
                for (int i = 1; i <= totalgroupcount; i++)
                {
                    Group g = m.Groups[i];

                    var anytrue = totalgroupcount1.ToList().Any(e => e == i.ToString());
                    if (anytrue)
                    {
                        searchstring += g.ToString();
                    }
                    ///Console.WriteLine("Group" + i + "='" + g + "'");

                    //CaptureCollection cc = g.Captures;
                    //for (int j = 0; j < cc.Count; j++)
                    //{
                    //    Capture c = cc[j];
                    //    System.Console.WriteLine("Capture" + j + "='" + c + "', Position=" + c.Index);
                    //}
                }
                m = m.NextMatch();
            }
            Console.ReadLine();
            ///
            return searchstring;
        }

        public static void SearchAndReplaceNonBreakingSpace(string strDocPath)
        {
            GlobalMethods.strNonBreakingSpacePattern = ConfigurationManager.AppSettings.Get("strNonbreakingSpace");


            Microsoft.Office.Interop.Word.Application mywordApp = null;
            Microsoft.Office.Interop.Word.Document mdoc = null;

            try
            {
                string strDocContent = null;

                // Read the Document Content from Word Document //
                //strDocContent = GlobalMethods.ReadDocumentContent(strDocPath);


                // Load Word Document
                mdoc = GlobalMethods.LoadWordDocument(strDocPath);

                mywordApp = mdoc.Application;

                //strDocContent = mdoc.Content.Text;

                //if (strDocContent == null)
                //    return;

                // Search the patterns in the document content using Regular Expression
                if (mdoc != null)
                {
                    List<string> strValidPatterns = new List<string>();
                    strValidPatterns = GlobalMethods.ReadAndStoreFileValuesInArray(GlobalMethods.strNonBreakingSpacePattern);

                    if (strValidPatterns.Count > 0)
                    {
                        for (int nIndex = 0; nIndex < strValidPatterns.Count; nIndex++)
                        {
                            string[] t = strValidPatterns[nIndex].Split('|');

                            bool bMatchWildCard = false;
                            if (t.Length > 2)
                            {
                                if (t[2] == "true")
                                    bMatchWildCard = true;
                                else
                                    bMatchWildCard = false;

                                GlobalMethods.SearchAndReplace(mdoc, t[0], t[1], "", "", "", false, false, true, false, bMatchWildCard);
                            }
                        }
                    }

                    object oMissing = System.Reflection.Missing.Value;

                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;
                }
            }
            catch (Exception ex)
            {
                if (mdoc != null)
                {
                    object oMissing = System.Reflection.Missing.Value;

                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;
                }
            }
            finally
            {
                //if (GlobalMethods.wordApp != null)
                //{
                //    object oMissing = System.Reflection.Missing.Value;
                //    ((_Application)GlobalMethods.wordApp).Quit(ref oMissing, ref oMissing, ref oMissing);
                //    GlobalMethods.wordApp = null;
                //}

                if (mywordApp != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    ((_Application)mywordApp).Quit(ref oMissing, ref oMissing, ref oMissing);
                    mywordApp = null;
                }

            }
        }


        public static void applyCitebibcharINF(string strDocPath, List<string> strMatchText)   //09-09-2020
        {
            Microsoft.Office.Interop.Word.Document mdoc = null;

            try
            {


                string strDocContent = null;

                // Read the Document Content from Word Document //
                //strDocContent = GlobalMethods.ReadDocumentContent(strDocPath);


                // Load Word Document Content
                mdoc = GlobalMethods.LoadWordDocument(strDocPath);

                strDocContent = mdoc.Content.Text;

                if (strDocContent == null)
                    return;

                // Search the patterns in the document content using Regular Expression
                if (mdoc != null)
                {

                    //GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);


                    string strSearchRegEx = null;




                    strSearchRegEx = null;

                    ///configuration added by Karan Start

                    // strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"(\[\d+\])");

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {

                            FindandApplycitebibforINF(mdoc, strMatchText[counter], "", "", "cite_bib", "", true, false, false, false, false);


                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;



                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"(\[[0-9]+\,\s[0-9]+\,\s[0-9]+\])";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            FindandApplycitebibforINF(mdoc, strMatchText[counter], "", "", "cite_bib", "", true, false, false, false, false);
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"(\[[0-9]+\,\s[0-9]+\])";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            FindandApplycitebibforINF(mdoc, strMatchText[counter], "", "", "cite_bib", "", true, false, false, false, false);
                        }
                    }



                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"(\[[0-9]+\,)";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            FindandApplycitebibforINF(mdoc, strMatchText[counter], "", "", "cite_bib", "", true, false, false, false, false);
                        }
                    }

                    if (GlobalMethods.strRefNum == "UnNumbered")  //Developer name:Priyanka Vishwakarma,Date:11-09-2020,Requirement:Apply citebib style to authorname with year.
                    {
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(\([A-Za-z]+\s[0-9]{4}\))";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                FindandApplycitebibforINF(mdoc, strMatchText[counter], "", "", "cite_bib", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"([A-Za-z]+\s[&]\s[A-Za-z]+\s[0-9]{4})";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                FindandApplycitebibforINF(mdoc, strMatchText[counter], "", "", "cite_bib", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"([A-Za-z]+\set al\.\s[0-9]{4})";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                FindandApplycitebibforINF(mdoc, strMatchText[counter], "", "", "cite_bib", "", true, false, false, false, false);
                            }
                        }



                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"([A-Za-z]+\s\([0-9]+\))";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                FindandApplycitebibforINF(mdoc, strMatchText[counter], "", "", "cite_bib", "", true, false, false, false, false);
                            }
                        }
                    }
                    GlobalMethods.wordApp.Selection.HomeKey(Microsoft.Office.Interop.Word.WdUnits.wdStory);

                    GlobalMethods.SearchAndReplace(mdoc, "^p ", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(Microsoft.Office.Interop.Word.WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, " ^p", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(Microsoft.Office.Interop.Word.WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "<jrn> ^p", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(Microsoft.Office.Interop.Word.WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "<jrn> </jrn>", "", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(Microsoft.Office.Interop.Word.WdUnits.wdStory);
                    // GlobalMethods.SearchAndReplace(mdoc, "^p^p", "^p", "", "", "", false, false, true, false, false);//commented on 11020202 For boxstart and BoxEnd style remove. 
                    GlobalMethods.wordApp.Selection.HomeKey(Microsoft.Office.Interop.Word.WdUnits.wdStory);
                    //GlobalMethods.SearchAndReplace(mdoc, "^g", "^&", "", "", "FIG", false, true, true, false);
                    GlobalMethods.SearchAndReplace(mdoc, "^~", "-", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(Microsoft.Office.Interop.Word.WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "", "", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(Microsoft.Office.Interop.Word.WdUnits.wdStory);
                    //GlobalMethods.SearchAndReplace(mdoc, "", "", "BullList", "", "", false, false, false, false, false);//19022020 comment for indend remove.
                    GlobalMethods.wordApp.Selection.HomeKey(Microsoft.Office.Interop.Word.WdUnits.wdStory);

                    object oMissing = System.Reflection.Missing.Value;

                    object saveChanges = Microsoft.Office.Interop.Word.WdSaveOptions.wdSaveChanges;
                    ((Microsoft.Office.Interop.Word._Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;

                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                if (mdoc != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    object saveChanges = Microsoft.Office.Interop.Word.WdSaveOptions.wdSaveChanges;
                    ((Microsoft.Office.Interop.Word._Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;
                }
                if (GlobalMethods.wordApp != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    ((Microsoft.Office.Interop.Word._Application)GlobalMethods.wordApp).Quit(ref oMissing, ref oMissing, ref oMissing);
                    GlobalMethods.wordApp = null;
                }
            }


        }
        public static bool FindandApplycitebibforINF(Microsoft.Office.Interop.Word.Document oActiveDoc, string strSearchText, string strReplaceText, string strSearchInParaStyle, string strReplaceCharStyle, string strReplaceParaStyle, bool bCharStyle, bool bParaStyle, bool bReplaceAll, bool bGeneralCrosslink, bool bMatchWildCard)
        {
            // Clear Previous searched settings from Word Find dialog box
            //ClearFindAndReplaceParameters(oActiveDoc); // not required as of now //

            // get the range of the curent paragraph
            Range rngDoc = oActiveDoc.Range();

            // setup Microsoft Word Find based upon
            // Regular Expression Match
            rngDoc.Find.ClearFormatting();
            rngDoc.Find.Replacement.ClearFormatting();
            rngDoc.Find.Forward = true;
            rngDoc.Find.MatchWildcards = bMatchWildCard;
            List<string> strList = new List<string>();

            if (strSearchText != "")
                rngDoc.Find.Text = strSearchText;

            if (strReplaceText != "")
                rngDoc.Find.Replacement.Text = strReplaceText;

            if (bReplaceAll == true && bGeneralCrosslink == true)
            {
                if (strSearchInParaStyle != "")
                    rngDoc.Find.set_Style(strSearchInParaStyle);

                if (bParaStyle == true)
                    rngDoc.Find.Replacement.set_Style(strReplaceParaStyle);

                if (bCharStyle == true)
                    rngDoc.Find.Replacement.set_Style(strReplaceCharStyle);
            }

            if (bGeneralCrosslink == false)
            {
                if (strSearchInParaStyle != "")
                    rngDoc.Find.set_Style(strSearchInParaStyle);

                if (bCharStyle == true)
                    rngDoc.Find.Replacement.set_Style(strReplaceCharStyle);

                if (bParaStyle == true)
                    rngDoc.Find.Replacement.set_Style(strReplaceParaStyle);
            }

            if (bReplaceAll == false)
            {
                if (strSearchInParaStyle != "")
                    rngDoc.Find.set_Style(strSearchInParaStyle);

                if (bParaStyle == true)
                    rngDoc.Find.Replacement.set_Style(strReplaceParaStyle);

                if (bCharStyle == true)
                    rngDoc.Find.Replacement.set_Style(strReplaceCharStyle);
            }

            // make search case sensitive
            object caseSensitive = "0";
            object missingValue = Type.Missing;

            rngDoc.Find.Wrap = Microsoft.Office.Interop.Word.WdFindWrap.wdFindStop;

            // wild cards
            object matchWildCards = Type.Missing;

            object replaceAll = Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll;
            //object replaceOne = Microsoft.Office.Interop.Word.WdReplace.wdReplaceOne;


            bool bBold = false;
            bool bItalic = false;

            if (bReplaceAll == true)
            {
                // find the text in the word document
                rngDoc.Find.Execute(ref missingValue, ref missingValue,
                    ref missingValue, ref missingValue, ref missingValue,
                    ref missingValue, ref missingValue, ref missingValue,
                    ref missingValue, ref missingValue, replaceAll,
                    ref missingValue, ref missingValue, ref missingValue,
                    ref missingValue);
            }
            else
            {
                rngDoc.Find.Execute(ref missingValue, ref caseSensitive,
                       ref missingValue, ref missingValue, ref missingValue,
                       ref missingValue, ref missingValue, ref missingValue,
                       ref missingValue, ref missingValue, missingValue,
                       ref missingValue, ref missingValue, ref missingValue,
                       ref missingValue);

                // we found the text
                if (rngDoc.Find.Found)
                {
                    do
                    {
                        bBold = false;
                        bItalic = false;

                        if (rngDoc.Bold == -1)
                        {
                            bBold = true;
                        }

                        if (rngDoc.Italic == -1)
                        {
                            bItalic = true;
                        }

                        if (rngDoc.ParagraphStyle.NameLocal != "REF1" && rngDoc.ParagraphStyle.NameLocal != "CORR" && rngDoc.ParagraphStyle.NameLocal != "AU" && rngDoc.ParagraphStyle.NameLocal != "AFFL" && rngDoc.ParagraphStyle.NameLocal != "FTN")
                        {
                            if (strReplaceCharStyle != "")
                            {
                                rngDoc.set_Style(strReplaceCharStyle);
                            }
                        }

                        if (strSearchInParaStyle == rngDoc.ParagraphStyle.NameLocal)
                        {
                            if (strReplaceCharStyle != "")
                            {
                                rngDoc.set_Style(strReplaceCharStyle);
                            }
                        }

                        if (rngDoc.ParagraphStyle.NameLocal == "BullList")
                        {
                            rngDoc.ListFormat.RemoveNumbers(NumberType: WdNumberType.wdNumberParagraph);
                        }

                        if (bBold)
                        {
                            rngDoc.Bold = -1;
                            bBold = false;
                        }

                        if (bItalic)
                        {
                            rngDoc.Italic = -1;
                            bItalic = false;
                        }

                        rngDoc.Move();

                        rngDoc.Find.Execute(ref missingValue, ref caseSensitive,
                        ref missingValue, ref missingValue, ref missingValue,
                        ref missingValue, ref missingValue, ref missingValue,
                        ref missingValue, ref missingValue, missingValue,
                        ref missingValue, ref missingValue, ref missingValue,
                        ref missingValue);

                    } while (rngDoc.Find.Found);

                    return true;
                }
            }


            return false;


        }

        public static void applyCitebibcharSage(string strDocPath, List<string> strMatchText, List<string> singleAuthorWithYear)   //09-09-2020
        {
            Microsoft.Office.Interop.Word.Document mdoc = null;

            try
            {


                string strDocContent = null;

                // Read the Document Content from Word Document //
                //strDocContent = GlobalMethods.ReadDocumentContent(strDocPath);


                // Load Word Document Content
                mdoc = GlobalMethods.LoadWordDocument(strDocPath);

                strDocContent = mdoc.Content.Text;

                if (strDocContent == null)
                    return;

                // Search the patterns in the document content using Regular Expression
                if (mdoc != null)
                {

                    //GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);


                    string strSearchRegEx = null;




                    strSearchRegEx = null;

                    ///configuration added by Karan Start

                    // strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"(\[\d+\])");

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {

                            //  FindandApplycitebibforINF(mdoc, strMatchText[counter], "", "", "cite_bib", "", true, false, false, false, false);


                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strSearchRegEx = @"([A-Za-z]{2,}\set\sal\.\s\([0-9]{4}\))";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                            {
                                FindandApplycitebibforINF(mdoc, strMatchText[counter], "", "", "cite_bib", "", true, false, false, false, false);
                            }
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strSearchRegEx = @"([A-Za-zÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÑÒÓÔÕÖÙÚÛÜÝáâãäåçèéêëìíîïðñòóôõöùúûüýÿĀāĂăąĄĆćĈĉĊċČčĎďđĒēĔĕĖėĘęĚěĜĝįĮĭĬīĪĩħħĥĤģĢġĠğĞĴĵĶķĸĹĺĻļĽľĿŀŁłŃńŅņŇňŉŊŋŌōŎŏŐőŔŕŖŗŘřŭŬūŪũŨŦťŤţŢšŠşŞŝŜśŚŮůŰűŲųŴŵŶŷŸŹźŻżŽǍșȘǻǺǺǐǏǎ\-]+\s\&\s[A-Za-zÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÑÒÓÔÕÖÙÚÛÜÝáâãäåçèéêëìíîïðñòóôõöùúûüýÿĀāĂăąĄĆćĈĉĊċČčĎďđĒēĔĕĖėĘęĚěĜĝįĮĭĬīĪĩħħĥĤģĢġĠğĞĴĵĶķĸĹĺĻļĽľĿŀŁłŃńŅņŇňŉŊŋŌōŎŏŐőŔŕŖŗŘřŭŬūŪũŨŦťŤţŢšŠşŞŝŜśŚŮůŰűŲųŴŵŶŷŸŹźŻżŽǍșȘǻǺǺǐǏǎ\-]+\,[\s\ ]{1}[0-9]{4})|([A-Za-z\-\–]+\set al\.\,\s[0-9]{4})|([A-Za-z\–\-]+\,\s[A-Za-z]+\,\s[&]\s[A-Za-z]+\,\s[0-9]{4})";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            FindandApplycitebibforINF(mdoc, strMatchText[counter], "", "", "cite_bib", "", true, false, false, false, false);
                        }
                    }


                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strSearchRegEx = @"([A-Za-z\-\–]+\set al\.\,\s[0-9]{4})";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                            //{
                            FindandApplycitebibforINF(mdoc, strMatchText[counter], "", "", "cite_bib", "", true, false, false, false, false);
                            //}
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"(\([A-Za-z]+\,\s[0-9]{4}\))";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                            //{
                            FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart('(').TrimEnd(')'), "", "", "cite_bib", "", true, false, false, false, false);
                            //}                            
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"([A-Za-zá\-\–]+\s[&]\s[A-Za-zá\-]+\,\s[0-9]{4})";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                            //{
                            FindandApplycitebibforINF(mdoc, strMatchText[counter], "", "", "cite_bib", "", true, false, false, false, false);
                            //}
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"([A-Za-z\-\–]+\,\s[0-9]{4})";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                            //{
                            FindandApplycitebibforINF(mdoc, strMatchText[counter], "", "", "cite_bib", "", true, false, false, false, false);
                            //}
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strSearchRegEx = @"(\([A-Za-z\-\–\s]+\,\s[0-9]{4}\))";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                            //{
                            FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart('(').TrimEnd(')'), "", "", "cite_bib", "", true, false, false, false, false);
                            //}
                        }
                    }


                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strSearchRegEx = @"([A-Za-z]+\,\s[&]\s[A-Za-z]+\,\s[0-9]{4})";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                            //{
                            FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart('(').TrimEnd(')'), "", "", "cite_bib", "", true, false, false, false, false);
                            //}
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strSearchRegEx = @"([A-Za-z\–\-]+\,\s[A-Za-z]+\,\s[&]\s[A-Za-z]+\,\s[0-9]{4})";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                            //{
                            FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart('(').TrimEnd(')'), "", "", "cite_bib", "", true, false, false, false, false);
                            //}
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;

                    //Developer Name:Priyanka Vishwakarma,Date:13-10-2020.Requirement:Add Pattern for citebib for sage sample.
                    strSearchRegEx = @"([A-Za-z\-]{2,}\sand\s[A-Za-z\-]{2,}\s\([0-9]{4}\))|([A-Za-z]{2,}\s\([0-9]{4}\))";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                            //{
                            FindandApplycitebibforINF(mdoc, strMatchText[counter], "", "", "cite_bib", "", true, false, false, false, false);
                            //}
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;



                    //-----
                    strMatchText.Clear();
                    strSearchRegEx = null;


                    strSearchRegEx = @"([A-Za-zÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÑÒÓÔÕÖÙÚÛÜÝáâãäåçèéêëìíîïðñòóôõöùúûüýÿĀāĂăąĄĆćĈĉĊċČčĎďđĒēĔĕĖėĘęĚěĜĝįĮĭĬīĪĩħħĥĤģĢġĠğĞĴĵĶķĸĹĺĻļĽľĿŀŁłŃńŅņŇňŉŊŋŌōŎŏŐőŔŕŖŗŘřŭŬūŪũŨŦťŤţŢšŠşŞŝŜśŚŮůŰűŲųŴŵŶŷŸŹźŻżŽǍșȘǻǺǺǐǏǎ\-\–]+\set al\.\,\s[0-9]{4})";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                            //{
                            FindandApplycitebibforINF(mdoc, strMatchText[counter], "", "", "cite_bib", "", true, false, false, false, false);
                            //}
                        }
                    }




                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"(\([A-Za-zÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÑÒÓÔÕÖÙÚÛÜÝáâãäåçèéêëìíîïðñòóôõöùúûüýÿĀāĂăąĄĆćĈĉĊċČčĎďđĒēĔĕĖėĘęĚěĜĝįĮĭĬīĪĩħħĥĤģĢġĠğĞĴĵĶķĸĹĺĻļĽľĿŀŁłŃńŅņŇňŉŊŋŌōŎŏŐőŔŕŖŗŘřŭŬūŪũŨŦťŤţŢšŠşŞŝŜśŚŮůŰűŲųŴŵŶŷŸŹźŻżŽǍșȘǻǺǺǐǏǎ\-]+\,\s[0-9]{4}\))";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                            //{
                            FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart('(').TrimEnd(')'), "", "", "cite_bib", "", true, false, false, false, false);
                            //}
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"([A-Za-zÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÑÒÓÔÕÖÙÚÛÜÝáâãäåçèéêëìíîïðñòóôõöùúûüýÿĀāĂăąĄĆćĈĉĊċČčĎďđĒēĔĕĖėĘęĚěĜĝįĮĭĬīĪĩħħĥĤģĢġĠğĞĴĵĶķĸĹĺĻļĽľĿŀŁłŃńŅņŇňŉŊŋŌōŎŏŐőŔŕŖŗŘřŭŬūŪũŨŦťŤţŢšŠşŞŝŜśŚŮůŰűŲųŴŵŶŷŸŹźŻżŽǍșȘǻǺǺǐǏǎ\-\–]+\s[&]\s[A-Za-zÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÑÒÓÔÕÖÙÚÛÜÝáâãäåçèéêëìíîïðñòóôõöùúûüýÿĀāĂăąĄĆćĈĉĊċČčĎďđĒēĔĕĖėĘęĚěĜĝįĮĭĬīĪĩħħĥĤģĢġĠğĞĴĵĶķĸĹĺĻļĽľĿŀŁłŃńŅņŇňŉŊŋŌōŎŏŐőŔŕŖŗŘřŭŬūŪũŨŦťŤţŢšŠşŞŝŜśŚŮůŰűŲųŴŵŶŷŸŹźŻżŽǍșȘǻǺǺǐǏǎ\-]+\,\s[0-9]{4})";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                            //{
                            FindandApplycitebibforINF(mdoc, strMatchText[counter], "", "", "cite_bib", "", true, false, false, false, false);
                            //}
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"([A-Za-zÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÑÒÓÔÕÖÙÚÛÜÝáâãäåçèéêëìíîïðñòóôõöùúûüýÿĀāĂăąĄĆćĈĉĊċČčĎďđĒēĔĕĖėĘęĚěĜĝįĮĭĬīĪĩħħĥĤģĢġĠğĞĴĵĶķĸĹĺĻļĽľĿŀŁłŃńŅņŇňŉŊŋŌōŎŏŐőŔŕŖŗŘřŭŬūŪũŨŦťŤţŢšŠşŞŝŜśŚŮůŰűŲųŴŵŶŷŸŹźŻżŽǍșȘǻǺǺǐǏǎ\-\–]+\,\s[0-9]{4})";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                            //{
                            FindandApplycitebibforINF(mdoc, strMatchText[counter], "", "", "cite_bib", "", true, false, false, false, false);
                            //}
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strSearchRegEx = @"(\([A-Za-zÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÑÒÓÔÕÖÙÚÛÜÝáâãäåçèéêëìíîïðñòóôõöùúûüýÿĀāĂăąĄĆćĈĉĊċČčĎďđĒēĔĕĖėĘęĚěĜĝįĮĭĬīĪĩħħĥĤģĢġĠğĞĴĵĶķĸĹĺĻļĽľĿŀŁłŃńŅņŇňŉŊŋŌōŎŏŐőŔŕŖŗŘřŭŬūŪũŨŦťŤţŢšŠşŞŝŜśŚŮůŰűŲųŴŵŶŷŸŹźŻżŽǍșȘǻǺǺǐǏǎ\-\–\s]+\,\s[0-9]{4}\))";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                            //{
                            FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart('(').TrimEnd(')'), "", "", "cite_bib", "", true, false, false, false, false);
                            //}
                        }
                    }


                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strSearchRegEx = @"([A-Za-zÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÑÒÓÔÕÖÙÚÛÜÝáâãäåçèéêëìíîïðñòóôõöùúûüýÿĀāĂăąĄĆćĈĉĊċČčĎďđĒēĔĕĖėĘęĚěĜĝįĮĭĬīĪĩħħĥĤģĢġĠğĞĴĵĶķĸĹĺĻļĽľĿŀŁłŃńŅņŇňŉŊŋŌōŎŏŐőŔŕŖŗŘřŭŬūŪũŨŦťŤţŢšŠşŞŝŜśŚŮůŰűŲųŴŵŶŷŸŹźŻżŽǍșȘǻǺǺǐǏǎ\-]+\,\s[&]\s[A-Za-zÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÑÒÓÔÕÖÙÚÛÜÝáâãäåçèéêëìíîïðñòóôõöùúûüýÿĀāĂăąĄĆćĈĉĊċČčĎďđĒēĔĕĖėĘęĚěĜĝįĮĭĬīĪĩħħĥĤģĢġĠğĞĴĵĶķĸĹĺĻļĽľĿŀŁłŃńŅņŇňŉŊŋŌōŎŏŐőŔŕŖŗŘřŭŬūŪũŨŦťŤţŢšŠşŞŝŜśŚŮůŰűŲųŴŵŶŷŸŹźŻżŽǍșȘǻǺǺǐǏǎ\-]+\,\s[0-9]{4})";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                            //{
                            FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart('(').TrimEnd(')'), "", "", "cite_bib", "", true, false, false, false, false);
                            //}
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strSearchRegEx = @"([A-Za-zÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÑÒÓÔÕÖÙÚÛÜÝáâãäåçèéêëìíîïðñòóôõöùúûüýÿĀāĂăąĄĆćĈĉĊċČčĎďđĒēĔĕĖėĘęĚěĜĝįĮĭĬīĪĩħħĥĤģĢġĠğĞĴĵĶķĸĹĺĻļĽľĿŀŁłŃńŅņŇňŉŊŋŌōŎŏŐőŔŕŖŗŘřŭŬūŪũŨŦťŤţŢšŠşŞŝŜśŚŮůŰűŲųŴŵŶŷŸŹźŻżŽǍșȘǻǺǺǐǏǎ\–\-]+\,\s[A-Za-zÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÑÒÓÔÕÖÙÚÛÜÝáâãäåçèéêëìíîïðñòóôõöùúûüýÿĀāĂăąĄĆćĈĉĊċČčĎďđĒēĔĕĖėĘęĚěĜĝįĮĭĬīĪĩħħĥĤģĢġĠğĞĴĵĶķĸĹĺĻļĽľĿŀŁłŃńŅņŇňŉŊŋŌōŎŏŐőŔŕŖŗŘřŭŬūŪũŨŦťŤţŢšŠşŞŝŜśŚŮůŰűŲųŴŵŶŷŸŹźŻżŽǍșȘǻǺǺǐǏǎ\-]+\,\s[&]\s[A-Za-zÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÑÒÓÔÕÖÙÚÛÜÝáâãäåçèéêëìíîïðñòóôõöùúûüýÿĀāĂăąĄĆćĈĉĊċČčĎďđĒēĔĕĖėĘęĚěĜĝįĮĭĬīĪĩħħĥĤģĢġĠğĞĴĵĶķĸĹĺĻļĽľĿŀŁłŃńŅņŇňŉŊŋŌōŎŏŐőŔŕŖŗŘřŭŬūŪũŨŦťŤţŢšŠşŞŝŜśŚŮůŰűŲųŴŵŶŷŸŹźŻżŽǍșȘǻǺǺǐǏǎ\-]+\,\s[0-9]{4})";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                            //{
                            FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart('(').TrimEnd(')'), "", "", "cite_bib", "", true, false, false, false, false);
                            //}
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;

                    //Developer Name:Priyanka Vishwakarma,Date:13-10-2020.Requirement:Add Pattern for citebib for sage sample.
                    strSearchRegEx = @"([A-Za-zÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÑÒÓÔÕÖÙÚÛÜÝáâãäåçèéêëìíîïðñòóôõöùúûüýÿĀāĂăąĄĆćĈĉĊċČčĎďđĒēĔĕĖėĘęĚěĜĝįĮĭĬīĪĩħħĥĤģĢġĠğĞĴĵĶķĸĹĺĻļĽľĿŀŁłŃńŅņŇňŉŊŋŌōŎŏŐőŔŕŖŗŘřŭŬūŪũŨŦťŤţŢšŠşŞŝŜśŚŮůŰűŲųŴŵŶŷŸŹźŻżŽǍșȘǻǺǺǐǏǎ\-]{2,}\sand\s[A-Za-zÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÑÒÓÔÕÖÙÚÛÜÝáâãäåçèéêëìíîïðñòóôõöùúûüýÿĀāĂăąĄĆćĈĉĊċČčĎďđĒēĔĕĖėĘęĚěĜĝįĮĭĬīĪĩħħĥĤģĢġĠğĞĴĵĶķĸĹĺĻļĽľĿŀŁłŃńŅņŇňŉŊŋŌōŎŏŐőŔŕŖŗŘřŭŬūŪũŨŦťŤţŢšŠşŞŝŜśŚŮůŰűŲųŴŵŶŷŸŹźŻżŽǍșȘǻǺǺǐǏǎ\-]{2,}\s\([0-9]{4}\))|([A-Za-zÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÑÒÓÔÕÖÙÚÛÜÝáâãäåçèéêëìíîïðñòóôõöùúûüýÿĀāĂăąĄĆćĈĉĊċČčĎďđĒēĔĕĖėĘęĚěĜĝįĮĭĬīĪĩħħĥĤģĢġĠğĞĴĵĶķĸĹĺĻļĽľĿŀŁłŃńŅņŇňŉŊŋŌōŎŏŐőŔŕŖŗŘřŭŬūŪũŨŦťŤţŢšŠşŞŝŜśŚŮůŰűŲųŴŵŶŷŸŹźŻżŽǍșȘǻǺǺǐǏǎ\-]{2,}\s\([0-9]{4}\))";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                            //{
                            FindandApplycitebibforINF(mdoc, strMatchText[counter], "", "", "cite_bib", "", true, false, false, false, false);
                            // }
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strSearchRegEx = @"([A-Za-z]+\s[\&]\s[A-Za-z]+\s\([0-9]{4}\))";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                            //{
                            FindandApplycitebibforINF(mdoc, strMatchText[counter], "", "", "cite_bib", "", true, false, false, false, false);
                            //}
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strSearchRegEx = @"([A-Za-z]+\s[A-Za-z]+\,\s[0-9]{4}\))";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                            //{
                            FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimEnd(')'), "", "", "cite_bib", "", true, false, false, false, false);
                            //}
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strSearchRegEx = @"([A-Za-z\'\-]+\s\([0-9]{4}\))";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                            //{
                            FindandApplycitebibforINF(mdoc, strMatchText[counter], "", "", "cite_bib", "", true, false, false, false, false);
                            // }
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strSearchRegEx = @"((Tuhiwai)\s[A-Za-z\'\-]+\s\([0-9]{4}\))|(International\sMonetary\sFund\,\s[0-9]{4})";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                            //{
                            FindandApplycitebibforINF(mdoc, strMatchText[counter], "", "", "cite_bib", "", true, false, false, false, false);
                            //}
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strSearchRegEx = @"(\([A-Za-z]+\,\s[A-Za-z]+\,\s[A-Za-z]+\,\s[A-Za-z]+\,\s[\&]\s[A-Za-z]+\,\s[0-9]{4}\))";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                            //{
                            FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart('(').TrimEnd(')'), "", "", "cite_bib", "", true, false, false, false, false);
                            //}
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strSearchRegEx = @"(\([A-Za-z]+\,\s[A-Za-z]+\,\s[A-Za-z]+\,\s[\&]\s[A-Za-z]+\,\s[0-9]{4}\))";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                            //{
                            FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart('(').TrimEnd(')'), "", "", "cite_bib", "", true, false, false, false, false);
                            //}
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strSearchRegEx = @"(\([A-Za-z]+\,\s[A-Za-z]+\,\s[A-Za-z]+\,\s[A-Za-z]+\,\s[A-Za-z]+\,\s[\&]\s[A-Za-z]+\,\s[0-9]{4}\))";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                            //{
                            FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart('(').TrimEnd(')'), "", "", "cite_bib", "", true, false, false, false, false);
                            //}
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strSearchRegEx = @"(\([A-Za-z]+\s[\&][A-Za-z]+\,\s[0-9]{4})";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                            //{
                            FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart('('), "", "", "cite_bib", "", true, false, false, false, false);
                            // }
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strSearchRegEx = @"(OECD\s[A-Za-z]+\s\([0-9]{4}\))";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                            //{
                            FindandApplycitebibforINF(mdoc, strMatchText[counter], "", "", "cite_bib", "", true, false, false, false, false);
                            // }
                        }
                    }



                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strSearchRegEx = @"(\([A-Za-zā\[\]\s]+\,\s[0-9]{4}\))";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                            //{
                            FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart('(').TrimEnd(')'), "", "", "cite_bib", "", true, false, false, false, false);
                            //}
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strSearchRegEx = @"(\([A-Za-z\s\,]+[\&]\s[A-Za-z]+\,\s[0-9]{4}\,)";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                            //{
                            FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart('(').TrimEnd(','), "", "", "cite_bib", "", true, false, false, false, false);
                            //}
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strSearchRegEx = @"(\([A-Za-z\s\,]+[\&]\s[A-Za-z]+\,\s[0-9]{4}\;)";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                            //{
                            FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart('(').TrimEnd(';'), "", "", "cite_bib", "", true, false, false, false, false);
                            //}
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strSearchRegEx = @"(\([A-Za-z]+\,[0-9]{4}\))";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                            //{
                            FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart('(').TrimEnd(')'), "", "", "cite_bib", "", true, false, false, false, false);
                            //}
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strSearchRegEx = @"([A-Za-z\s\,]+[\&]\s[A-Za-z]+\,\s\([0-9]{4}\))";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                            //{
                            FindandApplycitebibforINF(mdoc, strMatchText[counter], "", "", "cite_bib", "", true, false, false, false, false);
                            //}
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strSearchRegEx = @"(\;[A-Za-z\s]+\,\s[0-9]{4}\;)";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                            //{
                            FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart(';').TrimEnd(';').Trim(), "", "", "cite_bib", "", true, false, false, false, false);
                            //}
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strSearchRegEx = @"(\;\s[A-Za-z\,\s]+[\&]\s[A-Za-z]+\,\s[0-9]{4})";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                            //{
                            FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart(';').Trim(), "", "", "cite_bib", "", true, false, false, false, false);
                            //}
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strSearchRegEx = @"([A-Za-z]+\sand\s[A-Za-z]+\s\([0-9]{4}\))"; //Developer Name:Priyanka Vishwakarma,Date:26-03-2021,Requirement:Add pattern for apply citebib char style
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                            //{
                            FindandApplycitebibforINF(mdoc, strMatchText[counter], "", "", "cite_bib", "", true, false, false, false, false);
                            //}
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strSearchRegEx = @"(\([A-Za-z]+\s[\&]\s[A-Za-z]+\s[A-Za-z]+\,\s[0-9]{4})";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                            //{
                            FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart('('), "", "", "cite_bib", "", true, false, false, false, false);
                            //}
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strSearchRegEx = @"(\([A-Za-z]+\s[\&][A-Za-z]+\s[0-9]{4}\))";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                            //{
                            FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart('(').TrimEnd(')'), "", "", "cite_bib", "", true, false, false, false, false);
                            // }
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strSearchRegEx = @"(\([A-Za-z\,\s]+[\&]\s[A-Za-z]+\s[0-9]{4}\))";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                            //{
                            FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart('(').TrimEnd(')'), "", "", "cite_bib", "", true, false, false, false, false);
                            //}
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strSearchRegEx = @"(\([A-Za-z\s]+[\&]\s[A-Za-z]+\,\s[0-9]{4}\))";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            //if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                            //{
                            FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart('(').TrimEnd(')'), "", "", "cite_bib", "", true, false, false, false, false);
                            //}
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strSearchRegEx = @"([A-Za-zō\-\‘\’]+\s\([0-9]{4}\))";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                            {
                                if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                                {
                                    FindandApplycitebibforINF(mdoc, strMatchText[counter], "", "", "cite_bib", "", true, false, false, false, false);
                                }
                            }
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"([A-Za-z]+\s[\&]\s[A-Za-z]+\,\s[0-9]{4}[a-z])";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                            {
                                FindandApplycitebibforINF(mdoc, strMatchText[counter], "", "", "cite_bib", "", true, false, false, false, false);
                            }
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"([A-Za-z]+\s(and)\s[A-Za-z]+\s\([0-9]{4}\,\s[A-Z][a-z\.]+\s[0-9]{2}\))";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                            {
                                FindandApplycitebibforINF(mdoc, strMatchText[counter], "", "", "cite_bib", "", true, false, false, false, false);
                            }
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"([A-Za-z]+\s(and)\s[A-Za-z\’]+\s\([0-9]{4}\))";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                            {
                                FindandApplycitebibforINF(mdoc, strMatchText[counter], "", "", "cite_bib", "", true, false, false, false, false);
                            }
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"(\([A-Z]+\,\s[A-Za-z\s]+\,\s[0-9]{4}\;)";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                            {
                                FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart('(').TrimEnd(';').Trim(), "", "", "cite_bib", "", true, false, false, false, false);
                            }
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strSearchRegEx = @"(\;\s[A-Za-z\-\s]+\,\s[0-9]{4}\))";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                            {
                                FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart(';').TrimEnd(')').Trim(), "", "", "cite_bib", "", true, false, false, false, false);
                            }
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"(\([A-Za-z\s]+\,\s[0-9]{4}\;)";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                            {
                                FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart('(').TrimEnd(';'), "", "", "cite_bib", "", true, false, false, false, false);
                            }
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;


                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"(\([A-Za-z\.]+\s[\&]\s[A-Za-z]+\,\s[0-9]{4}\))";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                            {
                                FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart('(').TrimEnd(')'), "", "", "cite_bib", "", true, false, false, false, false);
                            }
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"(\([A-Za-z]+\.\s[\&]\s{1,}[A-Za-z]+\,\s[0-9]{4}\))";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                            {
                                FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart('(').TrimEnd(')'), "", "", "cite_bib", "", true, false, false, false, false);
                            }
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;
                    //Developer Name:Priyanka Vishwakarma,Date:02-04-2021,Requiremnt add pattern for mark citebib for sageindia input
                    strSearchRegEx = @"([A-Za-zÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÑÒÓÔÕÖÙÚÛÜÝáâãäåçèéêëìíîïðñòóôõöùúûüýÿĀāĂăąĄĆćĈĉĊċČčĎďđĒēĔĕĖėĘęĚěĜĝįĮĭĬīĪĩħħĥĤģĢġĠğĞĴĵĶķĸĹĺĻļĽľĿŀŁłŃńŅņŇňŉŊŋŌōŎŏŐőŔŕŖŗŘřŭŬūŪũŨŦťŤţŢšŠşŞŝŜśŚŮůŰűŲųŴŵŶŷŸŹźŻżŽǍșȘǻǺǺǐǏǎ\-\–\’]+\sand\s[A-Za-zÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÑÒÓÔÕÖÙÚÛÜÝáâãäåçèéêëìíîïðñòóôõöùúûüýÿĀāĂăąĄĆćĈĉĊċČčĎďđĒēĔĕĖėĘęĚěĜĝįĮĭĬīĪĩħħĥĤģĢġĠğĞĴĵĶķĸĹĺĻļĽľĿŀŁłŃńŅņŇňŉŊŋŌōŎŏŐőŔŕŖŗŘřŭŬūŪũŨŦťŤţŢšŠşŞŝŜśŚŮůŰűŲųŴŵŶŷŸŹźŻżŽǍșȘǻǺǺǐǏǎ\-\–\’]+\s\([0-9]{4})|([A-Za-zÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÑÒÓÔÕÖÙÚÛÜÝáâãäåçèéêëìíîïðñòóôõöùúûüýÿĀāĂăąĄĆćĈĉĊċČčĎďđĒēĔĕĖėĘęĚěĜĝįĮĭĬīĪĩħħĥĤģĢġĠğĞĴĵĶķĸĹĺĻļĽľĿŀŁłŃńŅņŇňŉŊŋŌōŎŏŐőŔŕŖŗŘřŭŬūŪũŨŦťŤţŢšŠşŞŝŜśŚŮůŰűŲųŴŵŶŷŸŹźŻżŽǍșȘǻǺǺǐǏǎ\-\–\’]+\s\([0-9]{4})";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                            {
                                FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart('(').TrimEnd(')'), "", "", "cite_bib", "", true, false, false, false, false);
                            }
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"((de|van|De|Van)\s[A-Za-zÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÑÒÓÔÕÖÙÚÛÜÝáâãäåçèéêëìíîïðñòóôõöùúûüýÿĀāĂăąĄĆćĈĉĊċČčĎďđĒēĔĕĖėĘęĚěĜĝįĮĭĬīĪĩħħĥĤģĢġĠğĞĴĵĶķĸĹĺĻļĽľĿŀŁłŃńŅņŇňŉŊŋŌōŎŏŐőŔŕŖŗŘřŭŬūŪũŨŦťŤţŢšŠşŞŝŜśŚŮůŰűŲųŴŵŶŷŸŹźŻżŽǍșȘǻǺǺǐǏǎ\-\–\’]+\s\([0-9]{4})|([A-Za-zÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÑÒÓÔÕÖÙÚÛÜÝáâãäåçèéêëìíîïðñòóôõöùúûüýÿĀāĂăąĄĆćĈĉĊċČčĎďđĒēĔĕĖėĘęĚěĜĝįĮĭĬīĪĩħħĥĤģĢġĠğĞĴĵĶķĸĹĺĻļĽľĿŀŁłŃńŅņŇňŉŊŋŌōŎŏŐőŔŕŖŗŘřŭŬūŪũŨŦťŤţŢšŠşŞŝŜśŚŮůŰűŲųŴŵŶŷŸŹźŻżŽǍșȘǻǺǺǐǏǎ\-\–\’]+\,\s[0-9]{4}\,\s[0-9]{4})";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                            {
                                FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart('(').TrimEnd(')'), "", "", "cite_bib", "", true, false, false, false, false);
                            }
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strSearchRegEx = @"([A-Za-zÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÑÒÓÔÕÖÙÚÛÜÝáâãäåçèéêëìíîïðñòóôõöùúûüýÿĀāĂăąĄĆćĈĉĊċČčĎďđĒēĔĕĖėĘęĚěĜĝįĮĭĬīĪĩħħĥĤģĢġĠğĞĴĵĶķĸĹĺĻļĽľĿŀŁłŃńŅņŇňŉŊŋŌōŎŏŐőŔŕŖŗŘřŭŬūŪũŨŦťŤţŢšŠşŞŝŜśŚŮůŰűŲųŴŵŶŷŸŹźŻżŽǍșȘǻǺǺǐǏǎ\–\-\’]+\s[0-9]{4}(\;|\)))";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                            {
                                FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart('(').TrimEnd(')').TrimEnd(';'), "", "", "cite_bib", "", true, false, false, false, false);
                            }
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strSearchRegEx = @"([A-Za-zÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÑÒÓÔÕÖÙÚÛÜÝáâãäåçèéêëìíîïðñòóôõöùúûüýÿĀāĂăąĄĆćĈĉĊċČčĎďđĒēĔĕĖėĘęĚěĜĝįĮĭĬīĪĩħħĥĤģĢġĠğĞĴĵĶķĸĹĺĻļĽľĿŀŁłŃńŅņŇňŉŊŋŌōŎŏŐőŔŕŖŗŘřŭŬūŪũŨŦťŤţŢšŠşŞŝŜśŚŮůŰűŲųŴŵŶŷŸŹźŻżŽǍșȘǻǺǺǐǏǎ\–\-\’]+\,\s[A-Za-zÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÑÒÓÔÕÖÙÚÛÜÝáâãäåçèéêëìíîïðñòóôõöùúûüýÿĀāĂăąĄĆćĈĉĊċČčĎďđĒēĔĕĖėĘęĚěĜĝįĮĭĬīĪĩħħĥĤģĢġĠğĞĴĵĶķĸĹĺĻļĽľĿŀŁłŃńŅņŇňŉŊŋŌōŎŏŐőŔŕŖŗŘřŭŬūŪũŨŦťŤţŢšŠşŞŝŜśŚŮůŰűŲųŴŵŶŷŸŹźŻżŽǍșȘǻǺǺǐǏǎ\–\-\’]+\,\sand\s[A-Za-zÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÑÒÓÔÕÖÙÚÛÜÝáâãäåçèéêëìíîïðñòóôõöùúûüýÿĀāĂăąĄĆćĈĉĊċČčĎďđĒēĔĕĖėĘęĚěĜĝįĮĭĬīĪĩħħĥĤģĢġĠğĞĴĵĶķĸĹĺĻļĽľĿŀŁłŃńŅņŇňŉŊŋŌōŎŏŐőŔŕŖŗŘřŭŬūŪũŨŦťŤţŢšŠşŞŝŜśŚŮůŰűŲųŴŵŶŷŸŹźŻżŽǍșȘǻǺǺǐǏǎ\–\-\’]+\s\([0-9]{4}\))";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                            {
                                FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart('(').TrimEnd(')').TrimEnd(';'), "", "", "cite_bib", "", true, false, false, false, false);
                            }
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strSearchRegEx = @"(\([A-Za-zÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÑÒÓÔÕÖÙÚÛÜÝáâãäåçèéêëìíîïðñòóôõöùúûüýÿĀāĂăąĄĆćĈĉĊċČčĎďđĒēĔĕĖėĘęĚěĜĝįĮĭĬīĪĩħħĥĤģĢġĠğĞĴĵĶķĸĹĺĻļĽľĿŀŁłŃńŅņŇňŉŊŋŌōŎŏŐőŔŕŖŗŘřŭŬūŪũŨŦťŤţŢšŠşŞŝŜśŚŮůŰűŲųŴŵŶŷŸŹźŻżŽǍșȘǻǺǺǐǏǎ\–\-\’]+\sand\s[A-Za-zÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÑÒÓÔÕÖÙÚÛÜÝáâãäåçèéêëìíîïðñòóôõöùúûüýÿĀāĂăąĄĆćĈĉĊċČčĎďđĒēĔĕĖėĘęĚěĜĝįĮĭĬīĪĩħħĥĤģĢġĠğĞĴĵĶķĸĹĺĻļĽľĿŀŁłŃńŅņŇňŉŊŋŌōŎŏŐőŔŕŖŗŘřŭŬūŪũŨŦťŤţŢšŠşŞŝŜśŚŮůŰűŲųŴŵŶŷŸŹźŻżŽǍșȘǻǺǺǐǏǎ\–\-\’]+\s[0-9]{4}\))";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            if (singleAuthorWithYear.Any(str => strMatchText[counter].Contains(str.Split(',').FirstOrDefault()) && strMatchText[counter].Contains(str.Split(',').LastOrDefault())))
                            {
                                FindandApplycitebibforINF(mdoc, strMatchText[counter].TrimStart('(').TrimEnd(')').TrimEnd(';'), "", "", "cite_bib", "", true, false, false, false, false);
                            }
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;

                    GlobalMethods.wordApp.Selection.HomeKey(Microsoft.Office.Interop.Word.WdUnits.wdStory);

                    GlobalMethods.SearchAndReplace(mdoc, "^p ", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(Microsoft.Office.Interop.Word.WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, " ^p", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(Microsoft.Office.Interop.Word.WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "<jrn> ^p", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(Microsoft.Office.Interop.Word.WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "<jrn> </jrn>", "", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(Microsoft.Office.Interop.Word.WdUnits.wdStory);
                    // GlobalMethods.SearchAndReplace(mdoc, "^p^p", "^p", "", "", "", false, false, true, false, false);//commented on 11020202 For boxstart and BoxEnd style remove. 
                    GlobalMethods.wordApp.Selection.HomeKey(Microsoft.Office.Interop.Word.WdUnits.wdStory);
                    //GlobalMethods.SearchAndReplace(mdoc, "^g", "^&", "", "", "FIG", false, true, true, false);
                    GlobalMethods.SearchAndReplace(mdoc, "^~", "-", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(Microsoft.Office.Interop.Word.WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "", "", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(Microsoft.Office.Interop.Word.WdUnits.wdStory);
                    //GlobalMethods.SearchAndReplace(mdoc, "", "", "BullList", "", "", false, false, false, false, false);//19022020 comment for indend remove.
                    GlobalMethods.wordApp.Selection.HomeKey(Microsoft.Office.Interop.Word.WdUnits.wdStory);

                    object oMissing = System.Reflection.Missing.Value;

                    object saveChanges = Microsoft.Office.Interop.Word.WdSaveOptions.wdSaveChanges;
                    ((Microsoft.Office.Interop.Word._Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;

                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                if (mdoc != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    object saveChanges = Microsoft.Office.Interop.Word.WdSaveOptions.wdSaveChanges;
                    ((Microsoft.Office.Interop.Word._Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;
                }
                if (GlobalMethods.wordApp != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    ((Microsoft.Office.Interop.Word._Application)GlobalMethods.wordApp).Quit(ref oMissing, ref oMissing, ref oMissing);
                    GlobalMethods.wordApp = null;
                }
            }


        }

        public static void ReferenceSearchAndReplaceVolumeIssue(string strDocPath)
        {
            Microsoft.Office.Interop.Word.Document mdoc = null;

            try
            {
                ///configuration added by Karan Start
                string strDocContent = null;

                // Read the Document Content from Word Document //
                //strDocContent = GlobalMethods.ReadDocumentContent(strDocPath);


                // Load Word Document Content
                mdoc = GlobalMethods.LoadWordDocument(strDocPath);

                strDocContent = mdoc.Content.Text;

                if (strDocContent == null)
                    return;

                // Search the patterns in the document content using Regular Expression
                if (mdoc != null)
                {

                    //GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    List<string> strMatchText = new List<string>();
                    string strSearchRegEx = null;


                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"(pp[\.]\s[0-9]+\s{0,1}[\-\–\−\–]\s{0,1}[0-9]+)");
                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter], "", "REF1", "bib_fpage", "", true, false, true, true, false);
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"([0-9]+\([0-9]+\)\,\s{1,}[0-9]+\s{1,}[\-\–\−]\s{1,}[0-9]+\.)|([0-9]+\([0-9A-Za-z\.]+\)\,\s{1,}[0-9]+[\-\–\−][0-9]+\.)|([0-9]+\([0-9A-Za-z\.]+\)\,\s{1,}[0-9]+[\-\–\−][0-9]+[\.|\,])|([0-9]+\([0-9]+\)\,\s{1,}[0-9]+\s{0,1}[\-\–\−]\s{0,1}[0-9]+\.)|([0-9]+\([0-9]+\)\,\spp\.\s{0,1}[0-9]+\s{0,1}[\-\–\−]\s{0,1}[0-9]+\.)|([0-9]+\([A-Za-z]+\s[A-Za-z]+\)\,\s{1,}[0-9]+\s{0,1}[\-\–\−]\s{0,1}[0-9]+\.)|([0-9]+\([A-Za-z]+\)\,\s{1,}[0-9]+\s{0,1}[\-\–\−]\s{0,1}[0-9]+\.)|([0-9]+\([0-9]+\)\:\s[0-9]+[\-\–]{1}[0-9]+)|([0-9]+\([0-9]+[\-\–\–][0-9]+\)\,\s[0-9]+[\-|\–][0-9]+)|([0-9]+\([0-9]+[\/][0-9]+\)\,\s[0-9]+[\-|\–][0-9]+)|([0-9]+\([0-9]+\)\,\s[0-9]+)|([0-9]+\([0-9]+\)\,\s[A-Za-z0-9]+)|([0-9]+\,\s[0-9]+[\-|\–][0-9]+)");// //Developer Name:Priyanka Vishwakarma,Date:02-04-2021,Requirement:Add condiiton for apply bibvolume for sage india input.
                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter], "", "REF1", "bib_volume", "", true, false, true, true, false);
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"([0-9]+\s{0,1}\([0-9]+\)\,[\s\ ]{0,1}[0-9]+[\-\–\−][0-9]+)");
                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter], "", "REF1", "bib_volume", "", true, false, true, true, false);
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;
                    if (GlobalMethods.strClientName.ToLower() == "jaypee" || GlobalMethods.strClientName.ToLower() == "ssllc")
                    {
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"([0-9]+\s{0,1}\;\s{0,1}[0-9]+\s{0,1}\:\s{0,1}[A-Z0-9]+\-[A-Z0-9]+)");
                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter], "", "REF1", "bib_volume", "", true, false, true, true, false);
                            }
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;

                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    GlobalMethods.SearchAndReplace(mdoc, "^p ", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, " ^p", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "<jrn> ^p", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "<jrn> </jrn>", "", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    // GlobalMethods.SearchAndReplace(mdoc, "^p^p", "^p", "", "", "", false, false, true, false, false);//commented on 11020202 For boxstart and BoxEnd style remove. 
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    //GlobalMethods.SearchAndReplace(mdoc, "^g", "^&", "", "", "FIG", false, true, true, false);
                    GlobalMethods.SearchAndReplace(mdoc, "^~", "-", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "", "", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    //GlobalMethods.SearchAndReplace(mdoc, "", "", "BullList", "", "", false, false, false, false, false);//19022020 comment for indend remove.
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    object oMissing = System.Reflection.Missing.Value;

                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;

                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                if (mdoc != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;
                }
                if (GlobalMethods.wordApp != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    ((_Application)GlobalMethods.wordApp).Quit(ref oMissing, ref oMissing, ref oMissing);
                    GlobalMethods.wordApp = null;
                }
            }


        }

        public static void ReferenceSearchAndReplaceVolumeIssueForJaypee(string strDocPath)
        {
            Microsoft.Office.Interop.Word.Document mdoc = null;
            try
            {
                var strVolumeIssuePagerangeDBFilename = ConfigurationManager.AppSettings.Get("ListOfVolumeIssuePageRangePatternWithStyles");
                GlobalMethods.strJournalDBFilename = ConfigurationManager.AppSettings.Get("JournalNameDBJaypee");
                List<string> JrnCitationPatternsColl = new List<string>();

                ///Configuration read from Supporting folder
                JrnCitationPatternsColl = GlobalMethods.ReadAndStoreFileValuesInArray(GlobalMethods.strJournalDBFilename);

                ///Configuration read from Supporting folder
                var JrnPatternsColl = GlobalMethods.ReadAndStoreFileValuesInArray(strVolumeIssuePagerangeDBFilename);
                string strDocContent = null;
                mdoc = GlobalMethods.LoadWordDocument(strDocPath);

                strDocContent = mdoc.Content.Text;

                if (strDocContent == null)
                    return;

                // Search the patterns in the document content using Regular Expression
                if (mdoc != null)
                {

                    //GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    List<string> strMatchText = new List<string>();
                    string strSearchRegEx = null;



                    foreach (var item in JrnPatternsColl)
                    {
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, Regex.Split(item, "<S>").FirstOrDefault());//Developer Name:Priyanka Vishwakarma,Dayte:12-10-2021, Requirement:add condiiton for read pattern from  file

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter].TrimStart(), "", "REF1", "bib_volume", "", true, false, true, true, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;
                    }


                    //strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"([0-9]{4}\;[0-9]+\([0-9]+\)\:[0-9]+[\-|\-|\–][0-9]+)|([0-9]+\s{0,1}\;\s{0,1}[0-9]+\s{0,1}\:\s{0,1}[A-Z0-9]+\-[A-Z0-9]+)|([0-9]+\([0-9]+\)\:[0-9]+[\-|\-|\–][0-9]+)|([0-9]{4}\;[0-9]+\:\s[0-9]+[\-|\-|\–][0-9]+)|([0-9]{4}\;[0-9]+\:[0-9]+[\-|\-|\–][0-9]+)|([0-9]{4}\s\;\(\s[0-9]+\)\:[A-Z0-9]+)|([0-9]{4}\;[0-9]+\:[a-zA-Z0-9]+)|([0-9]{4}\;\s[0-9]+\([0-9]\)\:\s[0-9]+[\-|\-|\–][0-9]+)|([0-9]+\.\sp\.\s[0-9]+[\-|\-|\–][0-9]+)|([0-9]+\:[0-9]+[\-|\-|\–][0-9]+)|([0-9]+\.\s[0-9]+[\-|\-|\–][0-9]+)|([0-9]{4}\;[0-9]+\([0-9]+\)\,\s[0-9]+[\-|\-|\–][0-9]+)|([0-9]{4}\;\([0-9]+\)\:[0-9]+[\-|\-|\–][0-9]+)");
                    //    if (strMatchText.Count > 0)
                    //    {
                    //        for (int counter = 0; counter < strMatchText.Count; counter++)
                    //        {
                    //            GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter], "", "REF1", "bib_volume", "", true, false, true, true, false);
                    //        }
                    //    }

                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"([A-Z][A-Za-záňíüøðjóóÓóóåñöüÇğłêéãÖÜüÖŠćä\'\-\-]+\s[A-ZãÖÜüÖŠćä]{1,4}\,)|([A-Z][A-Za-záňíüøðjóóÓóóåñöüÇğłêéãÖÜüÖŠćä\'\-\-]+\s[A-ZãÖÜüÖŠćä]{1,4}\.)");
                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter], "", "REF1", "bib_surname", "", true, false, true, true, false);
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"([A-Z][A-Za-záňíüøðjóóÓóóåñöüÇğłêéãÖÜüÖŠćä\'\-\-]+\s[A-Z]\.\s[A-Z][\.|\,])");
                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter], "", "REF1", "bib_surname", "", true, false, true, true, false);
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"(Van\s[A-Za-zñáňíüøðjóóÓóóåñöüÇğłêéãÖÜüÖŠćä\'\-\-]+\s[A-ZãÖÜüÖŠćä\s]{1,4})|(De\s[A-Za-zñáňíüøðjóóÓóóåñöüÇğłêéãÖÜüÖŠćä\'\-\-]+\s[A-ZãÖÜüÖŠćä\s]{1,4})");
                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter], "", "REF1", "bib_surname", "", true, false, true, true, false);
                        }
                    }


                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"(\set al\.)");
                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter], "", "REF1", "bib_etal", "", true, false, true, true, false);
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;
                    foreach (var item in JrnCitationPatternsColl)
                    {
                        if (item.Trim().Split(' ').Count() > 1)
                        {
                            strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"(" + item + ")");

                            if (strMatchText.Count > 0)
                            {
                                for (int counter = 0; counter < strMatchText.Count; counter++)
                                {
                                    GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter], "", "REF1", "bib_journal", "", true, false, true, true, false);

                                }
                            }
                            strMatchText.Clear();
                            strSearchRegEx = null;
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;


                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    GlobalMethods.SearchAndReplace(mdoc, "^p ", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, " ^p", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "<jrn> ^p", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "<jrn> </jrn>", "", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    // GlobalMethods.SearchAndReplace(mdoc, "^p^p", "^p", "", "", "", false, false, true, false, false);//commented on 11020202 For boxstart and BoxEnd style remove. 
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    //GlobalMethods.SearchAndReplace(mdoc, "^g", "^&", "", "", "FIG", false, true, true, false);
                    GlobalMethods.SearchAndReplace(mdoc, "^~", "-", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "", "", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    //GlobalMethods.SearchAndReplace(mdoc, "", "", "BullList", "", "", false, false, false, false, false);//19022020 comment for indend remove.
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    object oMissing = System.Reflection.Missing.Value;

                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;

                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                if (mdoc != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;
                }
                if (GlobalMethods.wordApp != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    ((_Application)GlobalMethods.wordApp).Quit(ref oMissing, ref oMissing, ref oMissing);
                    GlobalMethods.wordApp = null;
                }
            }


        }

        public static void ReferenceSearchAndReplaceSurnameFname(string strDocPath)
        {
            Microsoft.Office.Interop.Word.Document mdoc = null;

            try
            {

                string strDocContent = null;

                // Read the Document Content from Word Document //
                //strDocContent = GlobalMethods.ReadDocumentContent(strDocPath);


                // Load Word Document Content
                mdoc = GlobalMethods.LoadWordDocument(strDocPath);

                strDocContent = mdoc.Content.Text;

                if (strDocContent == null)
                    return;

                // Search the patterns in the document content using Regular Expression
                if (mdoc != null)
                {

                    //GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    List<string> strMatchText = new List<string>();
                    string strSearchRegEx = null;



                    strMatchText.Clear();
                    strSearchRegEx = null;

                    ///configuration added by Karan Start


                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"(\([0-9]{4}\)\.)|([18|19|20|21]{2}[0-9]{2}\.)"); //Developer Name:Priyanka Vishwakarma,Date:02-04-2021,Requirement:Add condiiton for apply bibyear for sage india input.

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter].Replace("(", "").Replace(")", "").Replace(".", ""), "", "REF1", "bib_year", "", true, false, true, true, false);
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"(\([0-9]{4}\,\s(January|February|March|April|May|June|July|August|September|October|November|December)\))");

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter].Replace("(", "").Replace(")", "").Replace(".", ""), "", "REF1", "bib_year", "", true, false, true, true, false);
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"(\([0-9]{4}\,\s(January|February|March|April|May|June|July|August|September|October|November|December)\s[0-9]{1,2}\))");

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter].Replace("(", "").Replace(")", "").Replace(".", ""), "", "REF1", "bib_year", "", true, false, true, true, false);
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"(\([0-9]{4}\,\s(January|February|March|April|May|June|July|August|September|October|November|December)\s[0-9]{1,2}[\-\-][0-9]{2}\))");

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter].Replace("(", "").Replace(")", "").Replace(".", ""), "", "REF1", "bib_year", "", true, false, true, true, false);
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"([A-Za-záňíúüøðjóóÓóóåöüÇğłêéñ’\'\-\–\‐]+\,\s{1,}[A-Z]\.\s[A-Za-zzáňíúüøðjóóÓóóåöüÇğłêéñ’]+\.\s[A-Z]\.)|([A-Za-záňíúüøðjóóÓóóåöüÇğłêéñ’\'\-\–\‐]+\,\s{1,}[A-Z]\.\s[A-Z]\.\s[A-Z]\.)|([A-Za-záňíúüøðjóóÓóóåöüÇğłêéñ’\'\-\–\‐]+\,\s{1,}[A-Z]\.\s[A-Z]\.)|([A-Za-záňíúüøðjóóÓóóåöüÇğłêéñ’\'\-\–\‐]+\,\s{1,}[A-Z]\.)|([A-Za-záňíúüøðjóóÓóóåöüÇğłêéñ’\'\-\–\‐]+\s[A-Za-záňíúüöüÇğłêéñ’\-\–\‐]+\,\s[A-Z]\.)|([A-Za-záňíúüøðjóóÓóóåöüÇğłêéñ’\'\-\–\‐]+\s[A-Za-záňíúüøðjóóÓóóåöüÇğłêéñ’\'\-\–\‐]+\s[A-Za-záňíúüøðjóóÓóóåöüÇğłêéñ’\'\-\–\‐]+\,\s[A-Z]\.)");  //02-04-2021
                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter], "", "REF1", "bib_surname", "", true, false, true, true, false);
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;

                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    GlobalMethods.SearchAndReplace(mdoc, "^p ", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, " ^p", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "<jrn> ^p", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "<jrn> </jrn>", "", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    // GlobalMethods.SearchAndReplace(mdoc, "^p^p", "^p", "", "", "", false, false, true, false, false);//commented on 11020202 For boxstart and BoxEnd style remove. 
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    //GlobalMethods.SearchAndReplace(mdoc, "^g", "^&", "", "", "FIG", false, true, true, false);
                    GlobalMethods.SearchAndReplace(mdoc, "^~", "-", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "", "", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    //GlobalMethods.SearchAndReplace(mdoc, "", "", "BullList", "", "", false, false, false, false, false);//19022020 comment for indend remove.
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    object oMissing = System.Reflection.Missing.Value;

                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;

                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                if (mdoc != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;
                }
                if (GlobalMethods.wordApp != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    ((_Application)GlobalMethods.wordApp).Quit(ref oMissing, ref oMissing, ref oMissing);
                    GlobalMethods.wordApp = null;
                }
            }


        }
        public static void ReferenceSearchAndReplace(string strDocPath)
        {
            Microsoft.Office.Interop.Word.Document mdoc = null;

            try
            {
                ///configuration added by Karan Start
                GlobalMethods.strPublisherDBFilename = ConfigurationManager.AppSettings.Get("PublisherNameDBSage");
                List<string> BokCitationPatternsColl = new List<string>();

                ///Configuration read from Supporting folder
                BokCitationPatternsColl = GlobalMethods.ReadAndStoreFileValuesInArray(GlobalMethods.strPublisherDBFilename);
                ///configuration added by Karan End

                GlobalMethods.strJournalDBFilename = ConfigurationManager.AppSettings.Get("JournalNameDBJaypee");
                List<string> JrnCitationPatternsColl = new List<string>();

                ///Configuration read from Supporting folder
                JrnCitationPatternsColl = GlobalMethods.ReadAndStoreFileValuesInArray(GlobalMethods.strJournalDBFilename);
                ///configuration added by Karan End
                string strDocContent = null;


                var strOrganizationDBsage = ConfigurationManager.AppSettings.Get("OrganizationDBsage");
                List<string> OrganizationDBsageCol = new List<string>();

                ///Configuration read from Supporting folder
                OrganizationDBsageCol = GlobalMethods.ReadAndStoreFileValuesInArray(strOrganizationDBsage);

                var strArticleTitleDBsage = ConfigurationManager.AppSettings.Get("ArticleTitleDBsage");
                List<string> ArticleTitleDBsageDBsageCol = new List<string>();

                ///Configuration read from Supporting folder
                ArticleTitleDBsageDBsageCol = GlobalMethods.ReadAndStoreFileValuesInArray(strArticleTitleDBsage);

                // Read the Document Content from Word Document //
                //strDocContent = GlobalMethods.ReadDocumentContent(strDocPath);



                // Load Word Document Content
                mdoc = GlobalMethods.LoadWordDocument(strDocPath);

                strDocContent = mdoc.Content.Text;

                if (strDocContent == null)
                    return;

                // Search the patterns in the document content using Regular Expression
                if (mdoc != null)
                {

                    //GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    List<string> strMatchText = new List<string>();
                    string strSearchRegEx = null;



                    strMatchText.Clear();
                    strSearchRegEx = null;

                    ///configuration added by Karan Start
                    foreach (var item in JrnCitationPatternsColl)
                    {
                        if (item.Trim().Split(' ').Count() > 1)
                        {
                            strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"(" + item + ")");

                            if (strMatchText.Count > 0)
                            {
                                for (int counter = 0; counter < strMatchText.Count; counter++)
                                {
                                    GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter], "", "REF1", "bib_journal", "", true, false, true, true, false);

                                }
                            }
                            strMatchText.Clear();
                            strSearchRegEx = null;
                        }
                    }

                    foreach (var item in BokCitationPatternsColl)
                    {
                        //if (item.Trim().Split(' ').Count() > 1)
                        //{


                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"(" + item + ")");


                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter], "", "REF1", "bibpubname", "", true, false, true, true, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;
                        // }
                    }

                    foreach (var item in OrganizationDBsageCol)
                    {
                        if (item.Trim().Split(' ').Count() > 1)
                        {
                            strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"(" + item + ")");

                            if (strMatchText.Count > 0)
                            {
                                for (int counter = 0; counter < strMatchText.Count; counter++)
                                {
                                    GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter], "", "REF1", "bib_organization", "", true, false, true, true, false);

                                }
                            }
                            strMatchText.Clear();
                            strSearchRegEx = null;
                        }
                    }


                    foreach (var item in ArticleTitleDBsageDBsageCol)
                    {
                        if (item.Trim().Split(' ').Count() > 1)
                        {
                            strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"(" + item + ")");

                            if (strMatchText.Count > 0)
                            {
                                for (int counter = 0; counter < strMatchText.Count; counter++)
                                {
                                    GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter], "", "REF1", "bib_article", "", true, false, true, true, false);

                                }
                            }
                            strMatchText.Clear();
                            strSearchRegEx = null;
                        }
                    }



                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"((doi\:)[A-Za-z0-9\.\/]+)|((doi\:\s)[A-Za-z0-9\.\/]+)|((DOI\:)[A-Za-z0-9\.\/]+)|((DOI\:\s)[A-Za-z0-9\.\/]+)");
                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter].Trim().TrimStart(')').TrimStart('.').TrimEnd('.').Trim(), "", "REF1", "bib_doi", "", true, false, true, true, false);
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"((doi\:)[A-Za-z0-9\.\-\/\(\)\:]+)|((doi\:\s)[A-Za-z0-9\-\.\/\(\)\:]+)|((DOI\:)[A-Za-z0-9\.\-\/\(\)\:]+)|((DOI\:\s)[A-Za-z0-9\-\.\/\(\)\:]+)");
                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter].Trim().TrimStart(')').TrimStart('.').TrimEnd('.').Trim(), "", "REF1", "bib_doi", "", true, false, true, true, false);
                        }
                    }


                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"(\([0-9]+th\sed\.\))|(\([0-9]+rd\sed\.\))|(\([0-9]+st\sed\.\))|(\([0-9]+nd\sed\.\))");
                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter].Trim().TrimStart('(').TrimEnd(')'), "", "REF1", "bibedition", "", true, false, true, true, false);
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"(\(Ed[\.]\))|(\(Eds[\.]\))");
                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter].Trim(), "", "REF1", "bibtxt", "", true, false, true, true, false);
                        }
                    }


                    //strMatchText.Clear();
                    //strSearchRegEx = null;

                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    GlobalMethods.SearchAndReplace(mdoc, "^p ", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, " ^p", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "<jrn> ^p", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "<jrn> </jrn>", "", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    // GlobalMethods.SearchAndReplace(mdoc, "^p^p", "^p", "", "", "", false, false, true, false, false);//commented on 11020202 For boxstart and BoxEnd style remove. 
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    //GlobalMethods.SearchAndReplace(mdoc, "^g", "^&", "", "", "FIG", false, true, true, false);
                    GlobalMethods.SearchAndReplace(mdoc, "^~", "-", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "", "", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    //GlobalMethods.SearchAndReplace(mdoc, "", "", "BullList", "", "", false, false, false, false, false);//19022020 comment for indend remove.
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    object oMissing = System.Reflection.Missing.Value;

                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;

                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                if (mdoc != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;
                }
                if (GlobalMethods.wordApp != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    ((_Application)GlobalMethods.wordApp).Quit(ref oMissing, ref oMissing, ref oMissing);
                    GlobalMethods.wordApp = null;
                }
            }


        }

        public static void ReferenceSearchAndReplaceJaypee(string strDocPath)
        {
            Microsoft.Office.Interop.Word.Document mdoc = null;

            try
            {
                ///configuration added by Karan Start
                string strDocContent = null;

                mdoc = GlobalMethods.LoadWordDocument(strDocPath);

                strDocContent = mdoc.Content.Text;

                if (strDocContent == null)
                    return;

                // Search the patterns in the document content using Regular Expression
                if (mdoc != null)
                {

                    //GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    List<string> strMatchText = new List<string>();
                    string strSearchRegEx = null;

                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"((doi\:)[A-Za-z0-9\.\/]+)|((doi\:\s)[A-Za-z0-9\.\/]+)|((DOI\:)[A-Za-z0-9\.\/]+)|((DOI\:\s)[A-Za-z0-9\.\/]+)");
                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter].Trim().TrimStart(')').TrimStart('.').TrimEnd('.').Trim().Replace("doi: ", "").Replace("doi:", "").Replace("DOI: ", "").Replace("DOI:", ""), "", "REF1", "bib_doi", "", true, false, true, true, false);
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"((doi\:)[A-Za-z0-9\.\-\/\(\)\:]+)|((doi\:\s)[A-Za-z0-9\-\.\/\(\)\:]+)|((DOI\:)[A-Za-z0-9\.\-\/\(\)\:]+)|((DOI\:\s)[A-Za-z0-9\-\.\/\(\)\:]+)");
                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter].Trim().TrimStart(')').TrimStart('.').TrimEnd('.').Trim().Replace("doi: ", "").Replace("doi:", "").Replace("DOI: ", "").Replace("DOI:", ""), "", "REF1", "bib_doi", "", true, false, true, true, false);
                        }
                    }


                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"(\([0-9]+th\sed\.\))|(\([0-9]+rd\sed\.\))|(\([0-9]+st\sed\.\))|(\([0-9]+nd\sed\.\))");
                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter].Trim().TrimStart('(').TrimEnd(')'), "", "REF1", "bibedition", "", true, false, true, true, false);
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"(\(Ed[\.]\))|(\(Eds[\.]\))");
                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter].Trim(), "", "REF1", "bibtxt", "", true, false, true, true, false);
                        }
                    }


                    //strMatchText.Clear();
                    //strSearchRegEx = null;

                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    GlobalMethods.SearchAndReplace(mdoc, "^p ", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, " ^p", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "<jrn> ^p", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "<jrn> </jrn>", "", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    // GlobalMethods.SearchAndReplace(mdoc, "^p^p", "^p", "", "", "", false, false, true, false, false);//commented on 11020202 For boxstart and BoxEnd style remove. 
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    //GlobalMethods.SearchAndReplace(mdoc, "^g", "^&", "", "", "FIG", false, true, true, false);
                    GlobalMethods.SearchAndReplace(mdoc, "^~", "-", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "", "", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    //GlobalMethods.SearchAndReplace(mdoc, "", "", "BullList", "", "", false, false, false, false, false);//19022020 comment for indend remove.
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    object oMissing = System.Reflection.Missing.Value;

                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;

                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                if (mdoc != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;
                }
                if (GlobalMethods.wordApp != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    ((_Application)GlobalMethods.wordApp).Quit(ref oMissing, ref oMissing, ref oMissing);
                    GlobalMethods.wordApp = null;
                }
            }


        }
        public static void ApplyCitebibForJaypee(string strDocPath)
        {
            Microsoft.Office.Interop.Word.Document mdoc = null;

            try
            {
                ///configuration added by Karan Start


                string strDocContent = null;

                // Read the Document Content from Word Document //
                //strDocContent = GlobalMethods.ReadDocumentContent(strDocPath);


                // Load Word Document Content
                mdoc = GlobalMethods.LoadWordDocument(strDocPath);

                strDocContent = mdoc.Content.Text;

                if (strDocContent == null)
                    return;

                // Search the patterns in the document content using Regular Expression
                if (mdoc != null)
                {

                    //GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    List<string> strMatchText = new List<string>();
                    string strSearchRegEx = null;


                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"(\[[0-9]{1,3}\,\s{0,}[0-9]{1,3}\])|(\[[0-9]{1,3}\,\s{0,}[0-9]{1,3}\,\s{0,}[0-9]{1,3}\])|(\[[0-9]{1,3}\,\s{0,}[0-9]{1,3}\,\s{0,}[0-9]{1,3}\,\s{0,}[0-9]{1,3}\])|(\[[0-9]{1,3}\,\s{0,}[0-9]{1,3}\,\s{0,}[0-9]{1,3}\,\s{0,}[0-9]{1,3}\,\s{0,}[0-9]{1,3}\])|(\[[0-9]{1,3}\,\s{0,}[0-9]{1,3}\,\s{0,}[0-9]{1,3}\,\s{0,}[0-9]{1,3}\,\s{0,}[0-9]{1,3}\,\s{0,}[0-9]{1,3}\])|(\[[0-9]{1,3}\,\s{0,}[0-9]{1,3}\,\s{0,}[0-9]{1,3}\,\s{0,}[0-9]{1,3}\,\s{0,}[0-9]{1,3}\,\s{0,}[0-9]{1,3}\,\s{0,}[0-9]{1,3}\])|(\[[0-9]{1,3}\,\s{0,}[0-9]{1,3}\,\s{0,}[0-9]{1,3}\,\s{0,}[0-9]{1,3}\,\s{0,}[0-9]{1,3}\,\s{0,}[0-9]{1,3}\,\s{0,}[0-9]{1,3}\,\s{0,}[0-9]{1,3}\])|(\[[0-9]{1,3}\,\s{0,}[0-9]{1,3}\,\s{0,}[0-9]{1,3}\,\s{0,}[0-9]{1,3}\,\s{0,}[0-9]{1,3}\,\s{0,}[0-9]{1,3}\,\s{0,}[0-9]{1,3}\,\s{0,}[0-9]{1,3}\,\s{0,}[0-9]{1,3}\])|(\[[0-9]{1,3}\,\s{0,}[0-9]{1,3}\,\s{0,}[0-9]{1,3}\,\s{0,}[0-9]{1,3}\,\s{0,}[0-9]{1,3}\,\s{0,}[0-9]{1,3}\,\s{0,}[0-9]{1,3}\,\s{0,}[0-9]{1,3}\,\s{0,}[0-9]{1,3}\,\s{0,}[0-9]{1,3}\])|(\[[0-9]{1,3}\])|(\[[0-9]{1,3}\,[0-9]{1,3}\])|(\[[0-9]{1,3}\,[0-9]{1,3}\,[0-9]{1,3}\])|(\[[0-9]{1,3}\,[0-9]{1,3}\,[0-9]{1,3}\,[0-9]{1,3}\])|(\[[0-9]{1,3}\,[0-9]{1,3}\,[0-9]{1,3}\,[0-9]{1,3}\,[0-9]{1,3}\])|(\[[0-9]{1,3}\,[0-9]{1,3}\,[0-9]{1,3}\,[0-9]{1,3}\,[0-9]{1,3}\,[0-9]{1,3}\])|(\[[0-9]{1,3}\,[0-9]{1,3}\,[0-9]{1,3}\,[0-9]{1,3}\,[0-9]{1,3}\,[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\])|(\[[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\])|(\[[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\])|(\[[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\])|(\[[0-9]{1,3}\s{0,}[\-|\—|\–]\s{0,}[0-9]{1,3}\])";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_bib", "", true, false, false, true, false);
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"(\([0-9]{1,3}\))|(\([0-9]{1,3}\,\s{0,1}[0-9]{1,3}\))|(\([0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\))|(\([0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\))|(\([0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\))|(\([0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\))|(\([0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\))|(\([0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\))|(\([0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\))|(\([0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\))|(\([0-9]{1,3}\s{0,}[\-|\—|\–]\s{0,}[0-9]{1,3}\))";  //Developer Name:Priyanka Vishwakarma, Date:4-12-2021, Requirement: add pattern for handling reference callout with Brackets (,{,[
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_bib", "", true, false, false, true, false);
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"(\([0-9]{1,3}\))|(\([0-9]{1,3}\,\s{0,}[0-9]{1,3}\))||(\([0-9]{1,3}\,\s{0,}[0-9]{1,3}\,\s{0,}[0-9]{1,3}\))|(\([0-9]{1,3}\,\s{0,}[0-9]{1,3}\,\s{0,}[0-9]{1,3}\,\s{0,}[0-9]{1,3}\))|(\([0-9]{1,3}\,\s{0,}[0-9]{1,3}\,\s{0,}[0-9]{1,3}\,\s{0,}[0-9]{1,3}\,\s{0,}[0-9]{1,3}\))|(\([0-9]{1,3}\,\s{0,}[0-9]{1,3}\,\s{0,}[0-9]{1,3}\,\s{0,}[0-9]{1,3}\,\s{0,}[0-9]{1,3}\,\s{0,}[0-9]{1,3}\))|(\([0-9]{1,3}\,\s{0,}[0-9]{1,3}\,\s{0,}[0-9]{1,3}\,\s{0,}[0-9]{1,3}\,\s{0,}[0-9]{1,3}\,\s{0,}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\))|(\([0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\))|(\([0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\))|(\([0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\))|(\([0-9]{1,3}\s{0,}[\-|\—|\–]\s{0,}[0-9]{1,3}\))";  //Developer Name:Priyanka Vishwakarma, Date:4-12-2021, Requirement: add pattern for handling reference callout with Brackets (,{,[
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_bib", "", true, false, false, true, false);
                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"(\{[0-9]{1,3}\})|(\{[0-9]{1,3}\,[0-9]{1,3}\})|(\{[0-9]{1,3}\,[0-9]{1,3}\,[0-9]{1,3}\})|(\{[0-9]{1,3}\,[0-9]{1,3}\,[0-9]{1,3}\,[0-9]{1,3}\})|(\{[0-9]{1,3}\,[0-9]{1,3}\,[0-9]{1,3}\,[0-9]{1,3}\,[0-9]{1,3}\})|(\{[0-9]{1,3}\,[0-9]{1,3}\,[0-9]{1,3}\,[0-9]{1,3}\,[0-9]{1,3}\,[0-9]{1,3}\})|(\{[0-9]{1,3}\,[0-9]{1,3}\,[0-9]{1,3}\,[0-9]{1,3}\,[0-9]{1,3}\,[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\})|(\{[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\})|(\{[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\})|(\{[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\,\s{0,1}[0-9]{1,3}\})|(\{[0-9]{1,3}\s{0,}[\-|\—|\–]\s{0,}[0-9]{1,3}\})";  //Developer Name:Priyanka Vishwakarma, Date:4-12-2021, Requirement: add pattern for handling reference callout with Brackets (,{,[
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_bib", "", true, false, false, true, false);
                        }
                    }
                    object oMissing = System.Reflection.Missing.Value;

                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;

                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                if (mdoc != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;
                }
                if (GlobalMethods.wordApp != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    ((_Application)GlobalMethods.wordApp).Quit(ref oMissing, ref oMissing, ref oMissing);
                    GlobalMethods.wordApp = null;
                }
            }


        }
        public static void ApplyJournalTitleForJaypee(string strDocPath)
        {
            Microsoft.Office.Interop.Word.Document mdoc = null;

            try
            {
                GlobalMethods.strJournalDBFilename = ConfigurationManager.AppSettings.Get("JournalNameDBJaypee");
                List<string> JrnCitationPatternsColl = new List<string>();

                ///Configuration read from Supporting folder
                JrnCitationPatternsColl = GlobalMethods.ReadAndStoreFileValuesInArray(GlobalMethods.strJournalDBFilename);
                JrnCitationPatternsColl = JrnCitationPatternsColl.OrderBy(x => x.Length).ToList();
                string strDocContent = null;
                mdoc = GlobalMethods.LoadWordDocument(strDocPath);

                strDocContent = mdoc.Content.Text;

                if (strDocContent == null)
                    return;

                // Search the patterns in the document content using Regular Expression
                if (mdoc != null)
                {

                    //GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    List<string> strMatchText = new List<string>();
                    string strSearchRegEx = null;



                    strMatchText.Clear();
                    strSearchRegEx = null;

                    ///configuration added by Karan Start
                    foreach (var item in JrnCitationPatternsColl)
                    {

                        //  if (item.Trim().Split(' ').Count() > 1 && !item.Trim().Contains("(") && !item.Trim().Contains(")"))
                        if (item.Trim().Split(' ').Count() > 1)
                        {
                            if (item.Contains("Cell J (Yakhteh)") || item.Contains("Clin Biomech (Bristol, Avon)"))
                            {
                                Console.WriteLine("yyy");
                            }
                                          
                            strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"(?i)" + "(" + item + ")");
                            if (strMatchText.Count > 0)
                            {
                                for (int counter = 0; counter < strMatchText.Count; counter++)
                                {
                                    GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter], "", "REF1", "bib_journal", "", true, false, true, true, false);

                                }
                            }
                            strMatchText.Clear();
                            strSearchRegEx = null;
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"(\set\sal\.)");

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter].TrimStart(), "", "REF1", "bib_etal", "", true, false, true, true, false);

                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    GlobalMethods.SearchAndReplace(mdoc, "^p ", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, " ^p", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "<jrn> ^p", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "<jrn> </jrn>", "", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    // GlobalMethods.SearchAndReplace(mdoc, "^p^p", "^p", "", "", "", false, false, true, false, false);//commented on 11020202 For boxstart and BoxEnd style remove. 
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    //GlobalMethods.SearchAndReplace(mdoc, "^g", "^&", "", "", "FIG", false, true, true, false);
                    GlobalMethods.SearchAndReplace(mdoc, "^~", "-", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "", "", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    //GlobalMethods.SearchAndReplace(mdoc, "", "", "BullList", "", "", false, false, false, false, false);//19022020 comment for indend remove.
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    object oMissing = System.Reflection.Missing.Value;

                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;

                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                if (mdoc != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;
                }
                if (GlobalMethods.wordApp != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    ((_Application)GlobalMethods.wordApp).Quit(ref oMissing, ref oMissing, ref oMissing);
                    GlobalMethods.wordApp = null;
                }
            }


        }
        public static void ApplyPMIDAndPMCIDForJaypee(string strDocPath)
        {
            Microsoft.Office.Interop.Word.Document mdoc = null;

            try
            {
                string strDocContent = null;
                mdoc = GlobalMethods.LoadWordDocument(strDocPath);

                strDocContent = mdoc.Content.Text;

                if (strDocContent == null)
                    return;

                // Search the patterns in the document content using Regular Expression
                if (mdoc != null)
                {

                    //GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    List<string> strMatchText = new List<string>();
                    string strSearchRegEx = null;


                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"(PMID\:\s{1,}[A-Za-z0-9]+)");

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter].TrimStart(), "", "REF1", "bib_pmid", "", true, false, true, true, false);

                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"(PMCID\:\s{1,}[A-Za-z0-9]+)");

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter].TrimStart(), "", "REF1", "bib_pmcid", "", true, false, true, true, false);

                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    GlobalMethods.SearchAndReplace(mdoc, "^p ", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, " ^p", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "<jrn> ^p", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "<jrn> </jrn>", "", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    // GlobalMethods.SearchAndReplace(mdoc, "^p^p", "^p", "", "", "", false, false, true, false, false);//commented on 11020202 For boxstart and BoxEnd style remove. 
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    //GlobalMethods.SearchAndReplace(mdoc, "^g", "^&", "", "", "FIG", false, true, true, false);
                    GlobalMethods.SearchAndReplace(mdoc, "^~", "-", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "", "", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    //GlobalMethods.SearchAndReplace(mdoc, "", "", "BullList", "", "", false, false, false, false, false);//19022020 comment for indend remove.
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    object oMissing = System.Reflection.Missing.Value;

                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;

                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                if (mdoc != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;
                }
                if (GlobalMethods.wordApp != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    ((_Application)GlobalMethods.wordApp).Quit(ref oMissing, ref oMissing, ref oMissing);
                    GlobalMethods.wordApp = null;
                }
            }


        }

        public static void ReferenceSearchAndReplaceVolumeIssueForJaypeeBasisOftextfile(string strDocPath)
        {
            Microsoft.Office.Interop.Word.Document mdoc = null;
            try
            {
                var strVolumeIssuePagerangeDBFilename = ConfigurationManager.AppSettings.Get("ListOfVolumeIssuePageRangePatternWithStyles");
                var JrnPatternsColl = GlobalMethods.ReadAndStoreFileValuesInArray(strVolumeIssuePagerangeDBFilename);
                string strDocContent = null;
                mdoc = GlobalMethods.LoadWordDocument(strDocPath);

                strDocContent = mdoc.Content.Text;

                if (strDocContent == null)
                    return;

                // Search the patterns in the document content using Regular Expression
                if (mdoc != null)
                {

                    //GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    List<string> strMatchText = new List<string>();
                    string strSearchRegEx = null;



                    foreach (var item in JrnPatternsColl)
                    {
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, Regex.Split(item, "<S>").FirstOrDefault());//Developer Name:Priyanka Vishwakarma,Dayte:12-10-2021, Requirement:add condiiton for read pattern from  file

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                if (strMatchText[counter].TrimStart().ToLower().Trim().StartsWith("doi:"))
                                {
                                    if (strMatchText[counter].TrimStart().Contains("/"))
                                    {
                                        GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter].TrimStart().TrimStart(')').TrimStart('.').TrimEnd('.').Trim().Replace("doi: ", "").Replace("doi:", "").Replace("DOI: ", "").Replace("DOI:", ""), "", "REF1", "bib_doi", "", true, false, true, true, false);
                                    }
                                }
                                else
                                {
                                    GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter].TrimStart(), "", "REF1", "bib_volume", "", true, false, true, true, false);
                                }
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;
                    }

                    //strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"((doi\:)[A-Za-z0-9\.\-\/\(\)\:]+)|((doi\:\s)[A-Za-z0-9\-\.\/\(\)\:]+)|((DOI\:)[A-Za-z0-9\.\-\/\(\)\:]+)|((DOI\:\s)[A-Za-z0-9\-\.\/\(\)\:]+)");

                    //if (strMatchText.Count > 0)
                    //{
                    //    for (int counter = 0; counter < strMatchText.Count; counter++)
                    //    {
                    //        GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter].TrimStart(), "", "REF1", "bib_doi", "", true, false, true, true, false);
                    //    }
                    //}
                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strMatchText.Clear();
                    strSearchRegEx = null;


                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    GlobalMethods.SearchAndReplace(mdoc, "^p ", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, " ^p", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "<jrn> ^p", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "<jrn> </jrn>", "", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    // GlobalMethods.SearchAndReplace(mdoc, "^p^p", "^p", "", "", "", false, false, true, false, false);//commented on 11020202 For boxstart and BoxEnd style remove. 
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    //GlobalMethods.SearchAndReplace(mdoc, "^g", "^&", "", "", "FIG", false, true, true, false);
                    GlobalMethods.SearchAndReplace(mdoc, "^~", "-", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "", "", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    //GlobalMethods.SearchAndReplace(mdoc, "", "", "BullList", "", "", false, false, false, false, false);//19022020 comment for indend remove.
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    object oMissing = System.Reflection.Missing.Value;

                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;

                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                if (mdoc != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;
                }
                if (GlobalMethods.wordApp != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    ((_Application)GlobalMethods.wordApp).Quit(ref oMissing, ref oMissing, ref oMissing);
                    GlobalMethods.wordApp = null;
                }
            }


        }

        public static void ReferenceSearchAndReplaceSurnameFnameForJaypee(string strDocPath)
        {
            Microsoft.Office.Interop.Word.Document mdoc = null;
            try
            {
                string RefPatternSunameFnameFile = "";
                var strSurnameFnameFilename = ConfigurationManager.AppSettings.Get("ListOfSunameFnamePattern");
                var JrnPatternsColl = GlobalMethods.ReadAndStoreFileValuesInArray(strSurnameFnameFilename);

                string strDocContent = null;
                mdoc = GlobalMethods.LoadWordDocument(strDocPath);

                strDocContent = mdoc.Content.Text;

                if (strDocContent == null)
                    return;

                // Search the patterns in the document content using Regular Expression
                if (mdoc != null)
                {

                    //GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    List<string> strMatchText = new List<string>();
                    string strSearchRegEx = null;



                    foreach (var item in JrnPatternsColl)
                    {
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, Regex.Split(item, "<S>").FirstOrDefault());//Developer Name:Priyanka Vishwakarma,Dayte:12-10-2021, Requirement:add condiiton for read pattern from  file

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                if (strMatchText[counter].TrimStart().Trim() == "et al." || strMatchText[counter].TrimStart().Trim() == "et al," || strMatchText[counter].TrimStart().Trim() == "et al;")
                                {
                                    GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter].TrimStart(), "", "REF1", "bib_etal", "", true, false, true, true, false);
                                }
                                else
                                {
                                    GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter].TrimStart(), "", "REF1", "bib_surname", "", true, false, true, true, false);
                                }
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;
                    }



                    strMatchText.Clear();
                    strSearchRegEx = null;


                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    GlobalMethods.SearchAndReplace(mdoc, "^p ", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, " ^p", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "<jrn> ^p", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "<jrn> </jrn>", "", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    // GlobalMethods.SearchAndReplace(mdoc, "^p^p", "^p", "", "", "", false, false, true, false, false);//commented on 11020202 For boxstart and BoxEnd style remove. 
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    //GlobalMethods.SearchAndReplace(mdoc, "^g", "^&", "", "", "FIG", false, true, true, false);
                    GlobalMethods.SearchAndReplace(mdoc, "^~", "-", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "", "", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    //GlobalMethods.SearchAndReplace(mdoc, "", "", "BullList", "", "", false, false, false, false, false);//19022020 comment for indend remove.
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    object oMissing = System.Reflection.Missing.Value;

                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;

                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                if (mdoc != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;
                }
                if (GlobalMethods.wordApp != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    ((_Application)GlobalMethods.wordApp).Quit(ref oMissing, ref oMissing, ref oMissing);
                    GlobalMethods.wordApp = null;
                }
            }


        }

        public static void ApplyJournalTitleForJaypeeSingle(string strDocPath)
        {
            Microsoft.Office.Interop.Word.Document mdoc = null;

            try
            {
                GlobalMethods.strPublisherDBFilename = ConfigurationManager.AppSettings.Get("PublisherNameDBSage");
                List<string> BokCitationPatternsColl = new List<string>();


                GlobalMethods.strJournalDBFilename = ConfigurationManager.AppSettings.Get("JournalNameDBJaypee").Replace(".txt", "Single.txt");
                List<string> JrnCitationPatternsColl = new List<string>();

                ///Configuration read from Supporting folder
                JrnCitationPatternsColl = GlobalMethods.ReadAndStoreFileValuesInArray(GlobalMethods.strJournalDBFilename);
                JrnCitationPatternsColl = JrnCitationPatternsColl.OrderBy(x => x.Length).ToList();
                string strDocContent = null;
                mdoc = GlobalMethods.LoadWordDocument(strDocPath);

                strDocContent = mdoc.Content.Text;

                if (strDocContent == null)
                    return;

                // Search the patterns in the document content using Regular Expression
                if (mdoc != null)
                {

                    //GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    List<string> strMatchText = new List<string>();
                    string strSearchRegEx = null;



                    strMatchText.Clear();
                    strSearchRegEx = null;

                    ///configuration added by Karan Start
                    foreach (var item in JrnCitationPatternsColl)
                    {

                        if (item.Trim().Length >= 4)
                        {
                            if (item.Contains("Radiology") || item.Contains("RadioGraphics"))
                            {
                                Console.WriteLine("xxx");
                            }
                            strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"(" + item + ")");
                            if (strMatchText.Count > 0)
                            {
                                for (int counter = 0; counter < strMatchText.Count; counter++)
                                {
                                    GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter], "", "REF1", "bib_journal", "", true, false, true, true, true);

                                }
                            }
                            strMatchText.Clear();
                            strSearchRegEx = null;
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"(\set\sal\.)");

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter].TrimStart(), "", "REF1", "bib_etal", "", true, false, true, true, false);

                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    GlobalMethods.SearchAndReplace(mdoc, "^p ", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, " ^p", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "<jrn> ^p", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "<jrn> </jrn>", "", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    // GlobalMethods.SearchAndReplace(mdoc, "^p^p", "^p", "", "", "", false, false, true, false, false);//commented on 11020202 For boxstart and BoxEnd style remove. 
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    //GlobalMethods.SearchAndReplace(mdoc, "^g", "^&", "", "", "FIG", false, true, true, false);
                    GlobalMethods.SearchAndReplace(mdoc, "^~", "-", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "", "", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    //GlobalMethods.SearchAndReplace(mdoc, "", "", "BullList", "", "", false, false, false, false, false);//19022020 comment for indend remove.
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    object oMissing = System.Reflection.Missing.Value;

                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;

                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                if (mdoc != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;
                }
                if (GlobalMethods.wordApp != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    ((_Application)GlobalMethods.wordApp).Quit(ref oMissing, ref oMissing, ref oMissing);
                    GlobalMethods.wordApp = null;
                }
            }


        }
        public static void ApplyPublisherNameForJaypee(string strDocPath)
        {
            Microsoft.Office.Interop.Word.Document mdoc = null;

            try
            {
                GlobalMethods.strPublisherDBFilename = ConfigurationManager.AppSettings.Get("PublisherNameDBSage");
                List<string> BokCitationPatternsColl = new List<string>();


                //  GlobalMethods.strJournalDBFilename = ConfigurationManager.AppSettings.Get("JournalNameDBJaypee").Replace(".txt", "Single.txt");
                //  List<string> JrnCitationPatternsColl = new List<string>();

                ///Configuration read from Supporting folder
                BokCitationPatternsColl = GlobalMethods.ReadAndStoreFileValuesInArray(GlobalMethods.strPublisherDBFilename);
                BokCitationPatternsColl = BokCitationPatternsColl.OrderBy(x => x.Length).ToList();
                string strDocContent = null;
                mdoc = GlobalMethods.LoadWordDocument(strDocPath);

                strDocContent = mdoc.Content.Text;

                if (strDocContent == null)
                    return;

                // Search the patterns in the document content using Regular Expression
                if (mdoc != null)
                {

                    //GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    List<string> strMatchText = new List<string>();
                    string strSearchRegEx = null;



                    strMatchText.Clear();
                    strSearchRegEx = null;

                    ///configuration added by Karan Start
                    foreach (var item in BokCitationPatternsColl)
                    {

                        if (item.Trim().Length >= 4)
                        {
                            strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"(" + item + ")");
                            if (strMatchText.Count > 0)
                            {
                                for (int counter = 0; counter < strMatchText.Count; counter++)
                                {
                                    GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter], "", "REF1", "bibpubname", "", true, false, true, true, true);

                                }
                            }
                            strMatchText.Clear();
                            strSearchRegEx = null;
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"(\set\sal\.)");

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter].TrimStart(), "", "REF1", "bib_etal", "", true, false, true, true, false);

                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    GlobalMethods.SearchAndReplace(mdoc, "^p ", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, " ^p", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "<jrn> ^p", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "<jrn> </jrn>", "", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    // GlobalMethods.SearchAndReplace(mdoc, "^p^p", "^p", "", "", "", false, false, true, false, false);//commented on 11020202 For boxstart and BoxEnd style remove. 
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    //GlobalMethods.SearchAndReplace(mdoc, "^g", "^&", "", "", "FIG", false, true, true, false);
                    GlobalMethods.SearchAndReplace(mdoc, "^~", "-", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "", "", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    //GlobalMethods.SearchAndReplace(mdoc, "", "", "BullList", "", "", false, false, false, false, false);//19022020 comment for indend remove.
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    object oMissing = System.Reflection.Missing.Value;

                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;

                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                if (mdoc != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;
                }
                if (GlobalMethods.wordApp != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    ((_Application)GlobalMethods.wordApp).Quit(ref oMissing, ref oMissing, ref oMissing);
                    GlobalMethods.wordApp = null;
                }
            }


        }

        public static void ApplyPublisherLocForJaypee(string strDocPath)
        {
            Microsoft.Office.Interop.Word.Document mdoc = null;

            try
            {
                GlobalMethods.strPublisherDBFilename = ConfigurationManager.AppSettings.Get("PublisherLocationDB");
                List<string> BokCitationPatternsColl = new List<string>();


                //  GlobalMethods.strJournalDBFilename = ConfigurationManager.AppSettings.Get("JournalNameDBJaypee").Replace(".txt", "Single.txt");
                //  List<string> JrnCitationPatternsColl = new List<string>();

                ///Configuration read from Supporting folder
                BokCitationPatternsColl = GlobalMethods.ReadAndStoreFileValuesInArray(GlobalMethods.strPublisherDBFilename);
                BokCitationPatternsColl = BokCitationPatternsColl.OrderBy(x => x.Length).ToList();
                string strDocContent = null;
                mdoc = GlobalMethods.LoadWordDocument(strDocPath);

                strDocContent = mdoc.Content.Text;

                if (strDocContent == null)
                    return;

                // Search the patterns in the document content using Regular Expression
                if (mdoc != null)
                {

                    //GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    List<string> strMatchText = new List<string>();
                    string strSearchRegEx = null;



                    strMatchText.Clear();
                    strSearchRegEx = null;

                    ///configuration added by Karan Start
                    foreach (var item in BokCitationPatternsColl)
                    {

                        if (item.Trim().Length >= 4)
                        {
                            strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"(" + item + ")");
                            if (strMatchText.Count > 0)
                            {
                                for (int counter = 0; counter < strMatchText.Count; counter++)
                                {
                                    GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter], "", "REF1", "publisher-loc", "", true, false, true, true, true);

                                }
                            }
                            strMatchText.Clear();
                            strSearchRegEx = null;
                        }
                    }

                    strMatchText.Clear();
                    strSearchRegEx = null;
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"(\set\sal\.)");

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter].TrimStart(), "", "REF1", "bib_etal", "", true, false, true, true, false);

                        }
                    }
                    strMatchText.Clear();
                    strSearchRegEx = null;
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    GlobalMethods.SearchAndReplace(mdoc, "^p ", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, " ^p", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "<jrn> ^p", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "<jrn> </jrn>", "", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    // GlobalMethods.SearchAndReplace(mdoc, "^p^p", "^p", "", "", "", false, false, true, false, false);//commented on 11020202 For boxstart and BoxEnd style remove. 
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    //GlobalMethods.SearchAndReplace(mdoc, "^g", "^&", "", "", "FIG", false, true, true, false);
                    GlobalMethods.SearchAndReplace(mdoc, "^~", "-", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "", "", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    //GlobalMethods.SearchAndReplace(mdoc, "", "", "BullList", "", "", false, false, false, false, false);//19022020 comment for indend remove.
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    object oMissing = System.Reflection.Missing.Value;

                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;

                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                if (mdoc != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;
                }
                if (GlobalMethods.wordApp != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    ((_Application)GlobalMethods.wordApp).Quit(ref oMissing, ref oMissing, ref oMissing);
                    GlobalMethods.wordApp = null;
                }
            }


        }

        public static void ReferenceSearchAndReplaceYearPattern(string strDocPath)
        {
            Microsoft.Office.Interop.Word.Document mdoc = null;
            try
            {

                string strDocContent = null;
                mdoc = GlobalMethods.LoadWordDocument(strDocPath);

                strDocContent = mdoc.Content.Text;

                if (strDocContent == null)
                    return;

                // Search the patterns in the document content using Regular Expression
                if (mdoc != null)
                {

                    //GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    List<string> strMatchText = new List<string>();
                    string strSearchRegEx = null;


                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"(\()(19[0-9][0-9])(\))|(\()(20[0-9][0-9])(\))");

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            if (strMatchText[counter].Length == 6)
                            {
                                GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter].TrimStart(), "", "REF1", "bib_year", "", true, false, true, true, false);
                            }
                        }
                    }

                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, @"(\(19[0-9][0-9]\))|(\(20[0-9][0-9]\))");
                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            if (strMatchText[counter].Length == 6)
                            {
                                GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter].TrimStart(), "", "REF1", "bib_year", "", true, false, true, true, false);
                            }

                        }
                    }


                    strMatchText.Clear();
                    strSearchRegEx = null;


                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    GlobalMethods.SearchAndReplace(mdoc, "^p ", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, " ^p", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "<jrn> ^p", "^p", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "<jrn> </jrn>", "", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    // GlobalMethods.SearchAndReplace(mdoc, "^p^p", "^p", "", "", "", false, false, true, false, false);//commented on 11020202 For boxstart and BoxEnd style remove. 
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    //GlobalMethods.SearchAndReplace(mdoc, "^g", "^&", "", "", "FIG", false, true, true, false);
                    GlobalMethods.SearchAndReplace(mdoc, "^~", "-", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    GlobalMethods.SearchAndReplace(mdoc, "", "", "", "", "", false, false, true, false, false);
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);
                    //GlobalMethods.SearchAndReplace(mdoc, "", "", "BullList", "", "", false, false, false, false, false);//19022020 comment for indend remove.
                    GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    object oMissing = System.Reflection.Missing.Value;

                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;

                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                if (mdoc != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;
                }
                if (GlobalMethods.wordApp != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    ((_Application)GlobalMethods.wordApp).Quit(ref oMissing, ref oMissing, ref oMissing);
                    GlobalMethods.wordApp = null;
                }
            }


        }
        public static void ApplyEditionForRefernces(string strDocPath)
        {
            Microsoft.Office.Interop.Word.Document mdoc = null;

            try
            {


                string strDocContent = null;
                mdoc = GlobalMethods.LoadWordDocument(strDocPath);

                strDocContent = mdoc.Content.Text;

                if (strDocContent == null)
                    return;

                // Search the patterns in the document content using Regular Expression
                if (mdoc != null)
                {

                    //GlobalMethods.wordApp.Selection.HomeKey(WdUnits.wdStory);

                    List<string> strMatchText = new List<string>();
                    string strSearchRegEx = null;


                    strMatchText.Clear();
                    strSearchRegEx = null;

                    strSearchRegEx = @"([0-9]{1,2})(st|nd|rd|th)\s(ed. |eds. |edition)";
                    strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                    if (strMatchText.Count > 0)
                    {
                        for (int counter = 0; counter < strMatchText.Count; counter++)
                        {
                            GlobalMethods.RefSearchAndReplace(mdoc, strMatchText[counter], "", "REF1", "bibedition", "", true, false, true, true, true);

                        }
                    }




                    object oMissing = System.Reflection.Missing.Value;

                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;

                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                if (mdoc != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;
                }
                if (GlobalMethods.wordApp != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    ((_Application)GlobalMethods.wordApp).Quit(ref oMissing, ref oMissing, ref oMissing);
                    GlobalMethods.wordApp = null;
                }
            }


        }



    }
}
