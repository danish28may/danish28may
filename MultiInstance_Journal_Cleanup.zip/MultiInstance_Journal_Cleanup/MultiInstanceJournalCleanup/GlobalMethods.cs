﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Microsoft.Office.Interop.Word;
using System.Text.RegularExpressions;
using DocumentFormat.OpenXml.Packaging;
using OpenXmlPowerTools;
using System.Xml;
using System.Xml.Linq;
using System.Linq;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace MultiInstanceJournalCleanup
{
    class GlobalMethods
    {
        public static Microsoft.Office.Interop.Word.Application wordApp = null;
        static Microsoft.Office.Interop.Word.Document SourceDoc = null;
        static Microsoft.Office.Interop.Word.Document TargetDoc = null;
       
        public static string strClientName = null;   //14-08-2020
        public static string StrEntityFile = null;
        public static string StrInFolder = null;
        public static string StrOutFolder = null;
        public static string StrProcessFolder = null;
        public static string str3CMWordTemplate = null;
        public static string strStyleMappingConfig = null;
        public static string strCharStyleMappingConfig = null;
        public static string strStyleMappingJSONConfig = null;
        public static string strCustomerID = null;
        public static string strReferncePatternFilename = null;
        public static string strProjectName = null;
        public static string strJournalDBFilename = null;
        public static string strPublisherDBFilename = null;
        public static bool bCleanupRequired;
        public static string strReferenceStyleDB = null;
        public static string strAuthorStyleDB = null;
        public static bool refStructureDone = false;

        ///added new configuration 18-05-2018
        public static string strCorrespondenPatternFilename = null;
        public static string strAddressForCorresspondencetxt = null;
        
        public static string strAddressDetails = null;
        public static string strDegreeDBFilename = null;
        public static string strAddressCorresspondenStyleDB = null;
        public static string strCopyEditingRequired = null;
        ///ended new configuration 18-05-2018

        ///added new configuration 13-06-2018 
        public static string AutoStructringstyles = null;
        public static string DTStyle = null;
        public static string H1Style = null;
        ///added new configuration 13-06-2018

        ////added new variable by Karan on 21-06-2018 For generic patterns Start
        public static string LableStrongStyle = null;
        public static string CitationStyle = null;
        public static string strJournalId = null;
        ////added new variable by Karan on 21-06-2018 For generic patterns End.

        // Metadata Fields Variables //

        ////public static string DOI;
        ////public static string ISBN;
        ////public static string eISBN;
        //public static string VolumeTitle;
        //public static string SeriesTitle;
        //public static string JournalTitle;
        //public static string JournalSubTitle;

        //public static string CopyrightNote;
        //public static string CopyrightYear;

        //public static string Publisher;
        //public static string AuthorInfo;
        //public static string EditorInfo;

        //public static string ArticleTitle;
        //public static string ArticleNumber;

        public static string strCleanup;

        public static string ArticlePath;
        public static string ArticleImagePath;


        public static string ArticleId;
        public static string ManuscriptId;
        public static string ManuscriptNumber;
        public static string VolumeNo;
        public static string IssueNo;
        public static string FirstPage;
        public static string LastPage;
        public static string OpenAccess;
        public static string EduProg;
        public static string ArticleType;
        public static string TransactionID;
        public static string ArticleLanguage;


        public static string strAbsractFilePath;
        public static string strKeywordSeperatorFilePath;

        ///New string added by Karan on 09-07-2017 For MultiInstance xml data Start
        public static string strJobTransId = null;
        public static string strDocumentType = null;
        public static string strServiceType = null;

        public static string strRefNum = null;
        ///New string added by Karan on 09-07-2017 For MultiInstance xml data End

        ///if Address for correspondence not structured by pattern that time new logic implemeted invoke start
        public static bool AddressCorStructured = false;
        ///if Address for correspondence not structured by pattern that time new logic implemeted invoke end

        ///Second logic for Address for correspondence Added by Karan on 18-08-2018 Start
        public static string strCountryDBFilename = null;
        public static string strPincodeDBFilename = null;
        public static string strCityDBFilename = null;
        public static string strStatesDBFilename = null;
        public static string strInstitutionDBFilename = null;
        public static string strAddressLineDB = null;
        ///Second logic for Address for correspondence Added by Karan on 18-08-2018 End

        public static string strNonBreakingSpacePattern = null; //Added by Karan on 06-09-2018 for non-breaking space.

        public static string strUnNoRefAuthorPattern = null;
        public static List<string> beforecmt = new List<string>();//Developer Name:Priyanka Vishwakarma, Date:31_12_2019 ,Requirement:Add all comments in list before cleanup completed,Integrated by:Vikas sir.                              
        public static List<string> Aftercmt = new List<string>();//Developer Name:Priyanka Vishwakarma, Date:31_12_2019 ,Requirement:Add all comments in list after cleanup completed,Integrated by:Vikas sir. 
        public static string strJournalArticlePath = null;///Added by vikas on 18-07-2020
        public static bool bEqcheck = false;///Added by vikas on for informs client on 05-09-2020
        public static string strCopyediting = "";///Added by vikas on for copyediting check on 24-03-2021
        public static string strArticleType = null; //Developer Name:Priyanka Vishwakarma, Date:15-09-2021, Requirement:read Article type for adding DT para style.

        public static List<string> CleanupReport = new List<string>();///add by vikas on 18-10-2020 sage client
        public static void UpdateReferencePatternIndex(List<string> strRefPatterns, string strRefPatternFilename)
        {
            string strPatternGroup = null;
            bool bPatternStart = false;

            List<string> strReferencePattern = new List<string>();
            List<string> strRefPatternGrp = new List<string>();

            strReferencePattern.Clear();
            strRefPatternGrp.Clear();

            for (int i = 0; i < strRefPatterns.Count; i++)
            {
                if (strRefPatterns[i].ToLower().StartsWith("[pattern start]") == true)
                {
                    strPatternGroup = "";
                    strPatternGroup = strRefPatterns[i];
                    bPatternStart = true;
                    continue;
                }
                else if (strRefPatterns[i].ToLower().StartsWith("[pattern end]") == true)
                {
                    strPatternGroup = strPatternGroup + System.Environment.NewLine + strRefPatterns[i];

                    // Add the complete Pattern Group String in List array
                    strRefPatternGrp.Add(strPatternGroup);
                    strPatternGroup = "";
                    bPatternStart = false;
                }
                else
                {
                    if (bPatternStart == true)
                    {
                        if (strRefPatterns[i].ToLower().StartsWith("searchpattern:") == true)
                        {
                            strReferencePattern.Add(strRefPatterns[i].Replace("SearchPattern:", "SearchPattern" + i + ":"));
                            strPatternGroup = strPatternGroup + System.Environment.NewLine + strRefPatterns[i].Replace("SearchPattern:", "SearchPattern" + i + ":");
                        }
                        else
                        {
                            strPatternGroup = strPatternGroup + System.Environment.NewLine + strRefPatterns[i];
                        }
                    }
                }
            }

            // Sort the pattern array on length //
            strReferencePattern = GlobalMethods.SortStringListOnLength(strReferencePattern);

            // Sort the master list array as per the sorted pattern list

            strRefPatterns.Clear();

            for (int i = 0; i < strReferencePattern.Count; i++)
            {
                for (int j = 0; j < strRefPatternGrp.Count; j++)
                {
                    if (strRefPatternGrp[j].Contains(strReferencePattern[i]))
                    {
                        string strSearchText = "";
                        strReferencePattern[i] = "";
                        strSearchText = GlobalMethods.SearchRegEx(strRefPatternGrp[j], @"SearchPattern[0-9]+\:");

                        if (strSearchText != null)
                        {
                            if (strSearchText.ToLower().StartsWith("searchpattern"))
                            {
                                strRefPatterns.Add(strRefPatternGrp[j].Replace(strSearchText, "SearchPattern:"));
                            }
                            else
                            {
                                strRefPatterns.Add(strRefPatternGrp[j]);
                            }
                        }

                        break;
                    }
                }
            }

            // Write the list array contents back to the pattern file //

            StreamWriter sw = new StreamWriter(strRefPatternFilename);

            for (int i = 0; i < strRefPatterns.Count; i++)
            {
                sw.WriteLine(strRefPatterns[i]);
            }

            sw.Close();
        }

        public static List<string> ReadAndStoreFileValuesInArray(string StyleMappingConfigFile)
        {
            List<string> strStyleMapping = new List<string>();
            strStyleMapping.Clear();

            if (StyleMappingConfigFile == null)
                return strStyleMapping;

            if (StyleMappingConfigFile == "")
                return strStyleMapping;

            int counter = 0;

            string strLine = null;

            StreamReader sr = new StreamReader(StyleMappingConfigFile);

            strStyleMapping.Clear();

            while ((strLine = sr.ReadLine()) != null)
            {
                if (strLine.StartsWith("//") == false && strLine != "")
                {
                    strStyleMapping.Add(strLine.Trim());
                    counter++;
                }
            }

            sr.Close();

            return strStyleMapping;
        }

        public static Microsoft.Office.Interop.Word.Document LoadWordDocument(string strDoc)
        {
            object oMissing = System.Reflection.Missing.Value;
            wordApp = new Microsoft.Office.Interop.Word.Application();

            try
            {
                wordApp.Visible = false;
                wordApp.ScreenUpdating = true;//7-5-2022

                Object filename = (Object)strDoc;
                Microsoft.Office.Interop.Word.Document mdoc = wordApp.Documents.Open(ref filename, ref oMissing,
                                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing);

                return mdoc;

            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public static List<string> DocumentRegEx(string strDocContent, string strSearchRegEx)
        {
            List<string> strMatchText = new List<string>();

            strMatchText.Clear();

            Regex regexText = new Regex(strSearchRegEx);

            // Match the regular expression pattern against a text string.
            Match m = regexText.Match(strDocContent);

            //============================================================================
            //             Hyperlink pattern START
            //============================================================================

            //If text string is starts with 'http' or 'www'
            if (m.Value.StartsWith("htt") || m.Value.StartsWith("ww"))
            {
                string[] arrOnlyLink;

                while (m.Success)
                {
                    Regex regTP = new Regex(@"(.\d+,\d+|,\d+)+");

                    //check whether hyperlink and superscirpt are together 
                    if (regTP.IsMatch(m.Value))
                    {
                        //Here we split the text with
                        //regTP pattern and
                        //we get :- hyperlink without superscirpt
                        arrOnlyLink = regTP.Split(m.Value);

                        foreach (var item in arrOnlyLink)
                        {
                            if (item.StartsWith("htt") || item.StartsWith("www"))
                            {
                                if (strMatchText.Contains(item) == false)
                                {
                                    strMatchText.Add(item);
                                    arrOnlyLink = null;
                                    break;
                                }
                            }
                        }

                    }
                    else
                    {
                        //if hyperlink does not contain superscript
                        if (strMatchText.Contains(m.Value) == false)
                            strMatchText.Add(m.Value);
                    }

                    m = m.NextMatch();
                }
            }
            else
            {
                while (m.Success)
                {
                    if (strMatchText.Contains(m.Value) == false)
                        strMatchText.Add(m.Value);
                    m = m.NextMatch();
                }
            }

            //====================================================================================
            //                      Hyperlink Pattern END
            //=====================================================================================

            return strMatchText;
        }


        public static bool ValidateRegEx(string strDocContent, string strSearchRegEx)
        {
            List<string> strMatchText = new List<string>();

            strMatchText.Clear();

            Regex regexText = new Regex(strSearchRegEx);

            // Match the regular expression pattern against a text string.
            Match m = regexText.Match(strDocContent);

            if (m.Success)
            {
                return true;
            }

            return false;
        }


        public static string RegExSearch(string strDocContent, string strSearchRegEx)
        {
            List<string> strMatchText = new List<string>();

            strMatchText.Clear();

            Regex regexText = new Regex(strSearchRegEx);

            // Match the regular expression pattern against a text string.
            Match m = regexText.Match(strDocContent);

            if (m.Success)
            {
                return m.Value;
            }

            return "";
        }

        //Execute Function 
        // ActiveDocument.Range.ListFormat.ConvertNumbersToText
        public static bool FormatChange(Microsoft.Office.Interop.Word.Document oActiveDoc, string strSearchText, string strReplaceText, string strSearchInParaStyle, string strReplaceCharStyle, string strReplaceParaStyle, bool bCharStyle, bool bParaStyle, bool bReplaceAll, bool bGeneralCrosslink, bool bMatchWildCard)
        {
            //ActiveDocument.Range.ListFormat.ConvertNumbersToText

            try
            {
                Range rngDoc = oActiveDoc.Range();
                rngDoc.ListFormat.ConvertNumbersToText();
                return true;
            }
            catch (Exception Ex)
            { }
            
            return false;

        }


        public static bool SearchAndReplace(Microsoft.Office.Interop.Word.Document oActiveDoc, string strSearchText, string strReplaceText, string strSearchInParaStyle, string strReplaceCharStyle, string strReplaceParaStyle, bool bCharStyle, bool bParaStyle, bool bReplaceAll, bool bGeneralCrosslink, bool bMatchWildCard)
        {
            // Clear Previous searched settings from Word Find dialog box
            //ClearFindAndReplaceParameters(oActiveDoc); // not required as of now //

            // get the range of the curent paragraph
            Range rngDoc = oActiveDoc.Range();
            // setup Microsoft Word Find based upon
            // Regular Expression Match
            rngDoc.Find.ClearFormatting();
            rngDoc.Find.Replacement.ClearFormatting();
            rngDoc.Find.Forward = true;
            rngDoc.Find.MatchWildcards = bMatchWildCard;
            List<string> strList = new List<string>();
            
                if (strSearchText != "")
                    rngDoc.Find.Text = strSearchText;

                if (strReplaceText != "")
                    rngDoc.Find.Replacement.Text = strReplaceText;

                if (bReplaceAll == true && bGeneralCrosslink == true)
                {
                    if (strSearchInParaStyle != "")
                        rngDoc.Find.set_Style(strSearchInParaStyle);

                    if (bParaStyle == true)
                        rngDoc.Find.Replacement.set_Style(strReplaceParaStyle);

                    if (bCharStyle == true)
                        rngDoc.Find.Replacement.set_Style(strReplaceCharStyle);
                }

                if (bGeneralCrosslink == false)
                {
                    if (strSearchInParaStyle != "")
                        rngDoc.Find.set_Style(strSearchInParaStyle);

                    if (bCharStyle == true)
                        rngDoc.Find.Replacement.set_Style(strReplaceCharStyle);

                    if (bParaStyle == true)
                        rngDoc.Find.Replacement.set_Style(strReplaceParaStyle);
                }

                if (bReplaceAll == false)
                {
                    if (strSearchInParaStyle != "")
                        rngDoc.Find.set_Style(strSearchInParaStyle);

                    if (bParaStyle == true)
                        rngDoc.Find.Replacement.set_Style(strReplaceParaStyle);

                    if (bCharStyle == true)
                        rngDoc.Find.Replacement.set_Style(strReplaceCharStyle);
                }

                // make search case sensitive
                object caseSensitive = "0";
                object missingValue = Type.Missing;

                rngDoc.Find.Wrap = Microsoft.Office.Interop.Word.WdFindWrap.wdFindStop;

                // wild cards
                object matchWildCards = Type.Missing;

                object replaceAll = Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll;
                //object replaceOne = Microsoft.Office.Interop.Word.WdReplace.wdReplaceOne;


                bool bBold = false;
                bool bItalic = false;

                if (bReplaceAll == true)
                {
                    // find the text in the word document
                    rngDoc.Find.Execute(ref missingValue, ref missingValue,
                        ref missingValue, ref missingValue, ref missingValue,
                        ref missingValue, ref missingValue, ref missingValue,
                        ref missingValue, ref missingValue, replaceAll,
                        ref missingValue, ref missingValue, ref missingValue,
                        ref missingValue);
                }
                else
                {
                    rngDoc.Find.Execute(ref missingValue, ref caseSensitive,
                           ref missingValue, ref missingValue, ref missingValue,
                           ref missingValue, ref missingValue, ref missingValue,
                           ref missingValue, ref missingValue, missingValue,
                           ref missingValue, ref missingValue, ref missingValue,
                           ref missingValue);

                    // we found the text
                    if (rngDoc.Find.Found)
                    {
                        do
                        {
                            bBold = false;
                            bItalic = false;

                            if (rngDoc.Bold == -1)
                            {
                                bBold = true;
                            }

                            if (rngDoc.Italic == -1)
                            {
                                bItalic = true;
                            }

                            if (rngDoc.ParagraphStyle.NameLocal != "TT" && rngDoc.ParagraphStyle.NameLocal != "BT" && rngDoc.ParagraphStyle.NameLocal != "FIGC" && rngDoc.ParagraphStyle.NameLocal != "REF1")
                            {
                                if (strReplaceCharStyle != "")
                                {
                                    rngDoc.set_Style(strReplaceCharStyle);
                                }
                            }

                            if (strSearchInParaStyle == rngDoc.ParagraphStyle.NameLocal)
                            {
                                if (strReplaceCharStyle != "")
                                {
                                    rngDoc.set_Style(strReplaceCharStyle);
                                }
                            }

                            if (rngDoc.ParagraphStyle.NameLocal == "BullList")
                            {
                                rngDoc.ListFormat.RemoveNumbers(NumberType: WdNumberType.wdNumberParagraph);
                            }

                            if (bBold)
                            {
                                rngDoc.Bold = -1;
                                bBold = false;
                            }

                            if (bItalic)
                            {
                                rngDoc.Italic = -1;
                                bItalic = false;
                            }

                            rngDoc.Move();

                            rngDoc.Find.Execute(ref missingValue, ref caseSensitive,
                            ref missingValue, ref missingValue, ref missingValue,
                            ref missingValue, ref missingValue, ref missingValue,
                            ref missingValue, ref missingValue, missingValue,
                            ref missingValue, ref missingValue, ref missingValue,
                            ref missingValue);

                        } while (rngDoc.Find.Found);
                        return true;
                    }
                }
                return false;
            
        }
        //Developer name:Priyanka Vishwakarma ,Date:12_10_2019 ,Requirement:Apply weblinks character style to hyperlinks if lenght is greater than 255 char long. Integrated by:Vikas sir.
        private static bool replaceReg(Range rngDoc, bool bReplaceAll, string strReplaceCharStyle, string strSearchInParaStyle)
        {
            // make search case sensitive
            object caseSensitive = "0";
            object missingValue = Type.Missing;

            rngDoc.Find.Wrap = Microsoft.Office.Interop.Word.WdFindWrap.wdFindStop;

            // wild cards
            object matchWildCards = Type.Missing;

            object replaceAll = Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll;
            //object replaceOne = Microsoft.Office.Interop.Word.WdReplace.wdReplaceOne;


            bool bBold = false;
            bool bItalic = false;

            if (bReplaceAll == true)
            {
                // find the text in the word document
                rngDoc.Find.Execute(ref missingValue, ref missingValue,
                    ref missingValue, ref missingValue, ref missingValue,
                    ref missingValue, ref missingValue, ref missingValue,
                    ref missingValue, ref missingValue, replaceAll,
                    ref missingValue, ref missingValue, ref missingValue,
                    ref missingValue);
            }
            else
            {
                rngDoc.Find.Execute(ref missingValue, ref caseSensitive,
                       ref missingValue, ref missingValue, ref missingValue,
                       ref missingValue, ref missingValue, ref missingValue,
                       ref missingValue, ref missingValue, missingValue,
                       ref missingValue, ref missingValue, ref missingValue,
                       ref missingValue);

                // we found the text
                if (rngDoc.Find.Found)
                {
                    do
                    {
                        bBold = false;
                        bItalic = false;

                        if (rngDoc.Bold == -1)
                        {
                            bBold = true;
                        }

                        if (rngDoc.Italic == -1)
                        {
                            bItalic = true;
                        }

                        if (rngDoc.ParagraphStyle.NameLocal != "TT" && rngDoc.ParagraphStyle.NameLocal != "BT" && rngDoc.ParagraphStyle.NameLocal != "FIGC")
                        {
                            if (strReplaceCharStyle != "")
                            {
                                rngDoc.set_Style(strReplaceCharStyle);
                            }
                        }

                        if (strSearchInParaStyle == rngDoc.ParagraphStyle.NameLocal)
                        {
                            if (strReplaceCharStyle != "")
                            {
                                rngDoc.set_Style(strReplaceCharStyle);
                            }
                        }

                        if (rngDoc.ParagraphStyle.NameLocal == "BullList")
                        {
                            rngDoc.ListFormat.RemoveNumbers(NumberType: WdNumberType.wdNumberParagraph);
                        }

                        if (bBold)
                        {
                            rngDoc.Bold = -1;
                            bBold = false;
                        }

                        if (bItalic)
                        {
                            rngDoc.Italic = -1;
                            bItalic = false;
                        }

                        rngDoc.Move();

                        rngDoc.Find.Execute(ref missingValue, ref caseSensitive,
                        ref missingValue, ref missingValue, ref missingValue,
                        ref missingValue, ref missingValue, ref missingValue,
                        ref missingValue, ref missingValue, missingValue,
                        ref missingValue, ref missingValue, ref missingValue,
                        ref missingValue);

                    } while (rngDoc.Find.Found);

                    return true;
                }
            }


            return false;
        }
        private static bool ClearFindAndReplaceParameters(Microsoft.Office.Interop.Word.Document oActiveDoc)
        {
            Range rngDoc = oActiveDoc.Range();

            // setup Microsoft Word Find based upon
            // Regular Expression Match
            rngDoc.Find.ClearFormatting();
            rngDoc.Find.Wrap = Microsoft.Office.Interop.Word.WdFindWrap.wdFindStop;
            rngDoc.Find.MatchWildcards = false;
            rngDoc.Find.set_Style("");
            rngDoc.Find.Replacement.set_Style("");
            rngDoc.Find.Text = "";
            rngDoc.Find.Replacement.Text = "";

            return true;
        }
        public static bool RemoveCharStyle(Microsoft.Office.Interop.Word.Document oActiveDoc, string strSearchText, string strReplaceText, string strSearchCharStyle)
        {
            // get the range of the curent paragraph
            Range rngDoc = oActiveDoc.Range();

            // setup Microsoft Word Find based upon
            // Regular Expression Match
            rngDoc.Find.ClearFormatting();
            rngDoc.Find.Forward = true;
            rngDoc.Find.Text = strSearchText;

            if (strReplaceText != "")
                rngDoc.Find.Replacement.Text = strReplaceText;

            rngDoc.Find.set_Style(strSearchCharStyle);
            rngDoc.Find.Replacement.set_Style("Default Paragraph Font");

            // make search case sensitive
            object caseSensitive = "0";
            object missingValue = Type.Missing;

            rngDoc.Find.Wrap = Microsoft.Office.Interop.Word.WdFindWrap.wdFindStop;

            // wild cards
            object matchWildCards = Type.Missing;

            object replaceAll = Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll;
            //object replaceOne = Microsoft.Office.Interop.Word.WdReplace.wdReplaceOne;


            // find the text in the word document
            rngDoc.Find.Execute(ref missingValue, ref missingValue,
                ref missingValue, ref missingValue, ref missingValue,
                ref missingValue, ref missingValue, ref missingValue,
                ref missingValue, ref missingValue, replaceAll,
                ref missingValue, ref missingValue, ref missingValue,
                ref missingValue);


            return true;

        }

        static bool bNormalParaFound = false;
        static bool bStyleParaFound = false;
        static string strCaptionText = null;
        public static void ApplyTableCaptionBetweenTwoTables(string newDoc)
        {
            bNormalParaFound = false;
            bStyleParaFound = false;


            using (WordprocessingDocument wDoc = WordprocessingDocument.Open(newDoc, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    RemoveComments = false,
                    RemoveContentControls = true,
                    RemoveEndAndFootNotes = false,
                    RemoveFieldCodes = true,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = false,//Developer name :Priyanka Vishwakarma. Date:29_5_2019, Requirement:it removes the indentation from the nested list  ,Integrated By:Vikas sir. 
                };

                MarkupSimplifier.SimplifyMarkup(wDoc, settings);

                var xDoc = wDoc.MainDocumentPart.GetXDocument();

                XmlDocument xd = xDoc.GetXmlDocument();

                xd.LoadXml(xd.InnerXml);

                XmlNodeList nodeList;
                XmlNamespaceManager ns = new XmlNamespaceManager(xd.NameTable);
                ns.AddNamespace("w", "http://schemas.openxmlformats.org/wordprocessingml/2006/main");

                XNamespace w = @"http://schemas.openxmlformats.org/wordprocessingml/2006/main";

                XmlNode root = xd.DocumentElement;

                nodeList = root.SelectNodes("w:body", ns);

                XElement xe = null;

                List<int> nNodeIndex = new List<int>();

                nNodeIndex.Clear();

                foreach (XmlNode book in nodeList)
                {
                    XmlNode nodeParent = book.ParentNode;

                    xe = book.GetXElement();

                    if(xe.HasElements)
                    {
                        foreach(XElement node in xe.Elements())
                        {
                            if (node.Name == W.tbl)
                            {
                                if (CheckElementsAfter(node))
                                {
                                    if(bNormalParaFound)
                                    {
                                        XElement run = new XElement(w + "r");
                                        XElement txt = new XElement(w + "t", strCaptionText);
                                        run.Add(txt);

                                        ((System.Xml.Linq.XElement)node.NextNode).Add(run);

                                        book.InnerXml = ((System.Xml.XmlDocument)(xe.GetXmlNode())).DocumentElement.InnerXml;

                                        continue;
                                    }
                                    else if (bStyleParaFound)
                                    {
                                        // Add new Paragraph above the current paragraph

                                        XElement para = new XElement(w + "p");
                                        XElement run = new XElement(w + "r");
                                        XElement txt = new XElement(w + "t", strCaptionText);
                                        run.Add(txt);
                                        para.Add(run);

                                        ((System.Xml.Linq.XElement)node.NextNode).AddBeforeSelf(para);

                                        book.InnerXml = ((System.Xml.XmlDocument)(xe.GetXmlNode())).DocumentElement.InnerXml;

                                    }
                                    else
                                    {
                                        strCaptionText = null;
                                    }

                                    //strCaptionText = null;
                                }
                            }

                            if (node.Name == W.p)
                            {
                                if (bNormalParaFound == true)
                                {
                                    bNormalParaFound = false;
                                    continue;
                                }

                                if (node.GetParagraphInfo() == null)
                                    continue;

                                BlockContentInfo bki = node.GetParagraphInfo();

                                if (bki.ThisBlockContentElement.FirstNode != null)
                                {
                                    if (((System.Xml.Linq.XContainer)bki.ThisBlockContentElement.FirstNode).FirstNode != null)
                                    {
                                        if (((System.Xml.Linq.XElement)(((System.Xml.Linq.XContainer)bki.ThisBlockContentElement.FirstNode).FirstNode)).Name == W.pStyle)
                                        {
                                            if ((((System.Xml.Linq.XElement)(((System.Xml.Linq.XContainer)bki.ThisBlockContentElement.FirstNode).FirstNode))).FirstAttribute != null)
                                            {
                                                string strStyle = (((System.Xml.Linq.XElement)(((System.Xml.Linq.XContainer)bki.ThisBlockContentElement.FirstNode).FirstNode))).FirstAttribute.Value;

                                                if (strStyle == "Caption")
                                                {
                                                    strCaptionText = node.Value;

                                                    Regex regexText = new Regex(@"Cuadro [A-Z]?[0-9]+\.[0-9]+");
                                                    Match m = regexText.Match(strCaptionText);
                                                    if(m.Length > 0)
                                                    {
                                                        strCaptionText = m.Value + " (Continued...)";
                                                    }
                                                    continue;
                                                }
                                            }
                                        }
                                    }
                                }

                            }
                        }
                    }

                }

                wDoc.MainDocumentPart.PutXDocument(xd.GetXDocument());

            } // End of Word Processing
        }

        private static bool CheckElementsAfter(XElement wp)
        {
            try
            {
                bool bParaFound = false;
                if (wp.ElementsAfterSelf() != null)
                {
                    XNamespace w = @"http://schemas.openxmlformats.org/wordprocessingml/2006/main";

                    IEnumerable<XElement> elements = wp.ElementsAfterSelf();

                    foreach (XElement xe in elements) // all elements
                    {
                        if (xe.Name == W.p) // check if the immediate first element is paragraphs and is empty or style NoteText // Else return
                        {
                            if (xe.Value == "")
                            {
                                bNormalParaFound = true;
                                bStyleParaFound = false;
                                bParaFound = true;
                                continue;
                            }
                            else
                            {
                                if(bParaFound == false)
                                {
                                    BlockContentInfo bki = xe.GetParagraphInfo();

                                    if (bki.ThisBlockContentElement.FirstNode != null)
                                    {
                                        if (((System.Xml.Linq.XContainer)bki.ThisBlockContentElement.FirstNode).FirstNode != null)
                                        {
                                            if (((System.Xml.Linq.XElement)(((System.Xml.Linq.XContainer)bki.ThisBlockContentElement.FirstNode).FirstNode)).Name == W.pStyle)
                                            {
                                                if ((((System.Xml.Linq.XElement)(((System.Xml.Linq.XContainer)bki.ThisBlockContentElement.FirstNode).FirstNode))).FirstAttribute != null)
                                                {
                                                    string strStyle = (((System.Xml.Linq.XElement)(((System.Xml.Linq.XContainer)bki.ThisBlockContentElement.FirstNode).FirstNode))).FirstAttribute.Value;

                                                    if (strStyle == "NoteText")
                                                    {
                                                        bNormalParaFound = false;
                                                        bStyleParaFound = true;
                                                        bParaFound = true;
                                                        continue;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }

                                Console.WriteLine(xe.Value);
                            }
                        }

                        if (bParaFound == true && xe.Name == W.tbl)
                        {
                            // Need to enter the Table Caption Text in the previous paragraph

                            return true;
                        }

                        bStyleParaFound = false;
                        bParaFound = false;
                        bNormalParaFound = false;

                        return false;
                    }
                }

                return false;
            }
            catch (Exception ex)
            {
                return false ;
            }
        }

        public static object OpenWordDocumentAndCompare(string strSourceDoc, string strTargetDoc)
        {
            try
            {
                object CompareFileName = null;
                object oMissing = System.Reflection.Missing.Value;
                wordApp = new Microsoft.Office.Interop.Word.Application();

                try
                {
                    wordApp.Visible = false;
                    wordApp.ScreenUpdating = false;

                    Object Sourcefilename = (Object)strSourceDoc;
                    SourceDoc = wordApp.Documents.Open(ref Sourcefilename, ref oMissing,
                                                       ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                                                       ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                                                       ref oMissing, ref oMissing, ref oMissing, ref oMissing);

                    Object Targetfilename = (Object)strTargetDoc;
                    TargetDoc = wordApp.Documents.Open(ref Targetfilename, ref oMissing,
                                                       ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                                                       ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                                                       ref oMissing, ref oMissing, ref oMissing, ref oMissing);

                    try
                    {
                        DocumentCompare(SourceDoc, TargetDoc);
                    }
                    finally
                    {
                        object saveChanges = WdSaveOptions.wdSaveChanges;
                        ((_Document)SourceDoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                        SourceDoc = null;

                        ((_Document)TargetDoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                        TargetDoc = null;
                    }
                }
                finally
                {
                    wordApp.ScreenUpdating = true;
                    ((_Application)wordApp).Quit(ref oMissing, ref oMissing, ref oMissing);
                    wordApp = null;
                }

                return CompareFileName;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }
        }

        private static void DocumentCompare(Microsoft.Office.Interop.Word.Document strSourceDoc, Microsoft.Office.Interop.Word.Document strTargetDoc)
        {
            object compareTarget = Microsoft.Office.Interop.Word.WdCompareTarget.wdCompareTargetNew;
            object addToRecentFiles = false;
            object oMissing = System.Reflection.Missing.Value;

            wordApp.CompareDocuments(strSourceDoc, strTargetDoc, WdCompareDestination.wdCompareDestinationRevised, WdGranularity.wdGranularityWordLevel, false, true, true, true, false, true, false, false, false, false, "3ClicksMaster", true);
        }

        public static String ReplaceWholeWord(String s, String word, String bywhat)
        {
            char firstLetter = word[0];
            StringBuilder sb = new StringBuilder();
            bool previousWasLetterOrDigit = false;
            int i = 0;
            while (i < s.Length - word.Length + 1)
            {
                bool wordFound = false;
                char c = s[i];
                if (c == firstLetter)
                    if (!previousWasLetterOrDigit)
                        if (s.Substring(i, word.Length).Equals(word))
                        {
                            wordFound = true;
                            bool wholeWordFound = true;
                            if (s.Length > i + word.Length)
                            {
                                if (Char.IsLetterOrDigit(s[i + word.Length]))
                                    wholeWordFound = false;
                            }

                            if (wholeWordFound)
                                sb.Append(bywhat);
                            else
                                sb.Append(word);

                            i += word.Length;
                        }

                if (!wordFound)
                {
                    previousWasLetterOrDigit = Char.IsLetterOrDigit(c);
                    sb.Append(c);
                    i++;
                }
            }

            if (s.Length - i > 0)
                sb.Append(s.Substring(i));

            return sb.ToString();
        }

        public static List<string> SortStringListOnLength(List<string> strStringColl)
        {
            List<string> strTmp = new List<string>();
            int nIndex = 0;
            int nCounter = 0;

            string strMid = null;

            strTmp = strStringColl;

            for (nIndex = 0; nIndex < strStringColl.Count; nIndex++)
            {
                for (nCounter = nIndex + 1; nCounter < strTmp.Count; nCounter++)
                {
                    if (strStringColl[nIndex].Length < strTmp[nCounter].Length)
                    {
                        strMid = strStringColl[nIndex];
                        strStringColl[nIndex] = strTmp[nCounter];
                        strTmp[nCounter] = strMid;
                        strMid = "";
                    }
                }
            }

            return strStringColl;
        }

        public static string SearchRegEx(string strDocContent, string strSearchRegEx)
        {
            string strSearchResult = "";

            Regex regexText = new Regex(strSearchRegEx);

            // Match the regular expression pattern against a text string.
            Match m = regexText.Match(strDocContent);

            if (m.Success)
            {
                strSearchResult = m.Value;
            }

            return strSearchResult;
        }

        public static string TrimStart(string target, string trimString)
        {
            string result = target;
            while (result.StartsWith(trimString))
            {
                result = result.Substring(trimString.Length);
            }

            return result;
        }

        public static string TrimEnd(string input, string suffixToRemove)
        {
            while (input != null && suffixToRemove != null && input.EndsWith(suffixToRemove))
            {
                input = input.Substring(0, input.Length - suffixToRemove.Length);
            }
            return input;
        }

        ///New Function added by Karan on 20-6-2018
        public static Dictionary<Single, string> SortDictionaryOnKeyWithNumber(Dictionary<Single, string> myDictionary)
        {
            Dictionary<Single, string> newMyDictionary = new Dictionary<Single, string>();
            newMyDictionary.Clear();

            // Acquire keys and sort them.
            var list = myDictionary.Keys.ToList();
            list.Sort();

            // Loop through keys.
            foreach (var key in list)
            {
                newMyDictionary.Add(key, myDictionary[key]);
            }

            list.Clear();
            return newMyDictionary;
        }

        public static void ReadCustomPropertiesXML(string strXMLPath)
        {
            var customProperties = from custProp in XElement.Load(strXMLPath).Elements() select custProp;

            foreach (var property in customProperties)
            {
                if (property.Name.LocalName == "TransactionID")
                {
                    strJobTransId = property.Value;
                    continue;
                }
                else if (property.Name.LocalName == "DocumentType")
                {
                    strDocumentType = property.Value;
                    continue;
                }
               else if (property.Name.LocalName == "ServiceType")
                {
                    strServiceType = property.Value;
                    continue;
                }
               else if (property.Name.LocalName == "RefType")
                {
                    strRefNum = property.Value;
                    continue;
                }
               else if (property.Name.LocalName == "ChapterPath")
                {
                    strJournalArticlePath = property.Value;
                    continue;
                }
               else if (property.Name.LocalName == "ClientName")
                {
                    strClientName = property.Value;
                    continue;
                }
                else if (property.Name.LocalName == "Copyediting")
                {
                    strCopyediting = property.Value.ToLower();
                    continue;
                }
               else if (property.Name.LocalName == "ProjectName")
                {
                    strProjectName = property.Value;
                    continue;
                }
               else if (property.Name.LocalName == "ArticleType") //Developer Name:Priyanka Vishwakarma, Date:15-09-2021, Requirement:read Article type for adding DT para style.
                {
                    strArticleType = property.Value;
                    continue;
                }
                else if(property.Name.LocalName== "JournalId")
                {
                    strJournalId = property.Value;
                    continue;
                }
                else if(property.Name.LocalName== "CopyEditingRequired")
                {
                    strCopyEditingRequired = property.Value;
                    continue;
                }
            }
        }

        public static string SearchRegExPatternFirstSearchInstanceOnly(string strParaContent, string strSearchRegEx)
        {
            Regex regexText = new Regex(strSearchRegEx);

            // Match the regular expression pattern against a text string.
            Match m = regexText.Match(strParaContent);

            if (m.Success)
            {
                return m.Value;
            }

            return null;
        }
        public static bool RefSearchAndReplace(Microsoft.Office.Interop.Word.Document oActiveDoc, string strSearchText, string strReplaceText, string strSearchInParaStyle, string strReplaceCharStyle, string strReplaceParaStyle, bool bCharStyle, bool bParaStyle, bool bReplaceAll, bool bGeneralCrosslink, bool bMatchWildCard)
        {
            // Clear Previous searched settings from Word Find dialog box
            //ClearFindAndReplaceParameters(oActiveDoc); // not required as of now //

            // get the range of the curent paragraph
            Range rngDoc = oActiveDoc.Range();

            // setup Microsoft Word Find based upon
            // Regular Expression Match
            rngDoc.Find.ClearFormatting();
            rngDoc.Find.Replacement.ClearFormatting();
            rngDoc.Find.Forward = true;
            rngDoc.Find.MatchWildcards = bMatchWildCard;
            List<string> strList = new List<string>();
            if (strSearchText.Length > 255 && strReplaceCharStyle == "weblinks")
            {
                bool replaceTrue = false;
                string first255Chars = strSearchText.Substring(0, 255);
                string next255chars = strSearchText.Substring(255);
                strList.Add(first255Chars);
                strList.Add(next255chars);
                foreach (string i in strList)
                {
                    strSearchText = i;
                    if (strSearchText != "" /*&& strSearchText.Length <= 255*/)

                        rngDoc.Find.Text = strSearchText;

                    if (strReplaceText != "")
                        rngDoc.Find.Replacement.Text = strReplaceText;

                    if (bReplaceAll == true && bGeneralCrosslink == true)
                    {
                        if (strSearchInParaStyle != "")
                            rngDoc.Find.set_Style(strSearchInParaStyle);

                        if (bParaStyle == true)
                            rngDoc.Find.Replacement.set_Style(strReplaceParaStyle);

                        if (bCharStyle == true)
                            rngDoc.Find.Replacement.set_Style(strReplaceCharStyle);
                    }

                    if (bGeneralCrosslink == false)
                    {
                        if (strSearchInParaStyle != "")
                            rngDoc.Find.set_Style(strSearchInParaStyle);

                        if (bCharStyle == true)
                            rngDoc.Find.Replacement.set_Style(strReplaceCharStyle);

                        if (bParaStyle == true)
                            rngDoc.Find.Replacement.set_Style(strReplaceParaStyle);
                    }

                    if (bReplaceAll == false)
                    {
                        if (strSearchInParaStyle != "")
                            rngDoc.Find.set_Style(strSearchInParaStyle);

                        if (bParaStyle == true)
                            rngDoc.Find.Replacement.set_Style(strReplaceParaStyle);

                        if (bCharStyle == true)
                            rngDoc.Find.Replacement.set_Style(strReplaceCharStyle);
                    }
                    replaceTrue = replaceReg(rngDoc, bReplaceAll, strReplaceCharStyle, strSearchInParaStyle);

                }
                return replaceTrue;

            }
            else
            {
                if (strSearchText != "")
                    rngDoc.Find.Text = strSearchText;

                if (strReplaceText != "")
                    rngDoc.Find.Replacement.Text = strReplaceText;

                if (bReplaceAll == true && bGeneralCrosslink == true)
                {
                    if (strSearchInParaStyle != "")
                        rngDoc.Find.set_Style(strSearchInParaStyle);

                    if (bParaStyle == true)
                        rngDoc.Find.Replacement.set_Style(strReplaceParaStyle);

                    if (bCharStyle == true)
                        rngDoc.Find.Replacement.set_Style(strReplaceCharStyle);
                }

                if (bGeneralCrosslink == false)
                {
                    if (strSearchInParaStyle != "")
                        rngDoc.Find.set_Style(strSearchInParaStyle);

                    if (bCharStyle == true)
                        rngDoc.Find.Replacement.set_Style(strReplaceCharStyle);

                    if (bParaStyle == true)
                        rngDoc.Find.Replacement.set_Style(strReplaceParaStyle);
                }

                if (bReplaceAll == false)
                {
                    if (strSearchInParaStyle != "")
                        rngDoc.Find.set_Style(strSearchInParaStyle);

                    if (bParaStyle == true)
                        rngDoc.Find.Replacement.set_Style(strReplaceParaStyle);

                    if (bCharStyle == true)
                        rngDoc.Find.Replacement.set_Style(strReplaceCharStyle);
                }

                // make search case sensitive
                object caseSensitive = "0";
                object missingValue = Type.Missing;

                rngDoc.Find.Wrap = Microsoft.Office.Interop.Word.WdFindWrap.wdFindStop;

                // wild cards
                object matchWildCards = Type.Missing;

                object replaceAll = Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll;
                //object replaceOne = Microsoft.Office.Interop.Word.WdReplace.wdReplaceOne;


                bool bBold = false;
                bool bItalic = false;                
                if (bReplaceAll == true)
                {
                    // find the text in the word document
                    rngDoc.Find.Execute(ref missingValue, ref missingValue,
                        ref missingValue, ref missingValue, ref missingValue,
                        ref missingValue, ref missingValue, ref missingValue,
                        ref missingValue, ref missingValue, replaceAll,
                        ref missingValue, ref missingValue, ref missingValue,
                        ref missingValue);
                }
                else
                {
                    rngDoc.Find.Execute(ref missingValue, ref caseSensitive,
                           ref missingValue, ref missingValue, ref missingValue,
                           ref missingValue, ref missingValue, ref missingValue,
                           ref missingValue, ref missingValue, missingValue,
                           ref missingValue, ref missingValue, ref missingValue,
                           ref missingValue);

                    // we found the text
                    if (rngDoc.Find.Found)
                    {
                        do
                        {
                            bBold = false;
                            bItalic = false;

                            if (rngDoc.Bold == -1)
                            {
                                bBold = true;
                            }

                            if (rngDoc.Italic == -1)
                            {
                                bItalic = true;
                            }

                            if (rngDoc.ParagraphStyle.NameLocal != "TT" && rngDoc.ParagraphStyle.NameLocal != "BT" && rngDoc.ParagraphStyle.NameLocal != "FIGC" && rngDoc.ParagraphStyle.NameLocal != "REF1")
                            {
                                if (strReplaceCharStyle != "")
                                {
                                    rngDoc.set_Style(strReplaceCharStyle);
                                }
                            }

                            if (strSearchInParaStyle == rngDoc.ParagraphStyle.NameLocal)
                            {
                                if (strReplaceCharStyle != "")
                                {
                                    rngDoc.set_Style(strReplaceCharStyle);
                                }
                            }

                            if (rngDoc.ParagraphStyle.NameLocal == "BullList")
                            {
                                rngDoc.ListFormat.RemoveNumbers(NumberType: WdNumberType.wdNumberParagraph);
                            }

                            if (bBold)
                            {
                                rngDoc.Bold = -1;
                                bBold = false;
                            }

                            if (bItalic)
                            {
                                rngDoc.Italic = -1;
                                bItalic = false;
                            }

                            rngDoc.Move();

                            rngDoc.Find.Execute(ref missingValue, ref caseSensitive,
                            ref missingValue, ref missingValue, ref missingValue,
                            ref missingValue, ref missingValue, ref missingValue,
                            ref missingValue, ref missingValue, missingValue,
                            ref missingValue, ref missingValue, ref missingValue,
                            ref missingValue);

                        } while (rngDoc.Find.Found);

                        return true;
                    }
                }


                return false;
            }

        }
        public static void CleanupAnalysisReport(string strDocPath)////Added for Sage client
        {
            
            var strb = new StringBuilder();
            strb.AppendLine("***********Start - Input Cleanup Report***********<E>");
            strb.AppendLine("Job Name:" + new FileInfo(strDocPath).Name.Replace(".docx", "") + "<E>");
            strb.AppendLine("Start Time:" + DateTime.Now.ToString("dd-MM-yyyy") + "(" + DateTime.Now.ToString("HH:mm") + ")" + "<E>");
            strb.AppendLine("****************************************************<E>");
            foreach(var str in CleanupReport.Distinct().ToList())
            {
                strb.AppendLine(str);
            }
            strb.AppendLine("***********End - Input Cleanup Report*************");


            ////Here input analysis will update to Database added by vikas on 18-05-2020
            UpdateAnlysisReportInDBSage(strb.ToString());
        }
        public static void UpdateAnlysisReportInDBSage(string Reportdata)
        {
            try
            {
                string jobTransID = GlobalMethods.strJobTransId;
                string jobID = "";
                if (jobTransID != "" && jobTransID != null)
                {
                    // jobID = SqlHelper.ExecuteNonQuery(ConfigurationManager.ConnectionStrings["con"].ToString(), "select * from Job_Transaction where jobtransid='" + jobTransID + "'");
                    var jobData = SqlHelper.ExecuteDataset(ConfigurationManager.ConnectionStrings["con"].ToString(), CommandType.StoredProcedure, "Usp_Get_JobID", new SqlParameter("@jobtransid", jobTransID));

                    if (jobData.Tables.Count > 0 && jobData.Tables[0].Rows.Count > 0)
                    {
                        jobID = jobData.Tables[0].Rows[0]["JobID"].ToString();
                    }
                }
                if (jobID != "" && jobID != null)
                {
                    SqlParameter[] parj = new SqlParameter[2];
                    parj[0] = new SqlParameter("@jobid", jobID);
                    parj[1] = new SqlParameter("@cleanupreport", Reportdata);

                    SqlHelper.ExecuteDataset(ConfigurationManager.ConnectionStrings["con"].ToString(), CommandType.StoredProcedure, "Usp_Update_CleanupReport", parj);
                }
            }
            catch (Exception ex)
            {

            }
        }
        public static void ListoPlainText(string wordpath)//////List to normal text 
        {
           
            var mdoc = LoadWordDocument(wordpath);
            foreach (var lp in mdoc.ListParagraphs)
                ((Paragraph)lp).Range.ListFormat.ConvertNumbersToText();
            object oMissing = System.Reflection.Missing.Value;

            object saveChanges = Microsoft.Office.Interop.Word.WdSaveOptions.wdSaveChanges;
            ((Microsoft.Office.Interop.Word._Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);

        }
        public static void CheckOrcidPara(string newDoc)
        {
            if (GlobalMethods.strJournalArticlePath != null)
            {
                if (Directory.Exists(GlobalMethods.strJournalArticlePath + "\\input"))
                {
                    DirectoryInfo Dir = new DirectoryInfo(GlobalMethods.strJournalArticlePath + "\\input");

                    DirectoryInfo[] directoryForProcess = Dir.GetDirectories();
                    string strSourceFileName = null;
                    string jobname = DOIImageNaming();
                    foreach (var dir in directoryForProcess)
                    {
                        if (dir.Name.ToLower() == jobname.ToLower())
                        {
                            DirectoryInfo Dir1 = new DirectoryInfo(dir.FullName);

                            FileInfo[] filesForProcess = Dir1.GetFiles();
                            foreach (var files in filesForProcess)
                            {
                                if (files.Extension == ".xml")
                                {
                                    string xmlPath = files.FullName;
                                    var orcidList = new List<XElement>();
                                    var customProperties = from custProp in XElement.Load(xmlPath).Elements() select custProp;
                                    foreach(var ele in customProperties.ToList().FirstOrDefault().Descendants("orcid").ToList())
                                    {
                                        if(ele.Value!=null && ele.Value!="")
                                        {                                           
                                            orcidList.Add(ele.Parent);
                                        }
                                    }
                                    if(orcidList.Count()>0)
                                    {
                                       MapStylesWithWordTemplate.addOrcidPara(orcidList, newDoc);
                                    }
                                }
                            }
                        }
                    }

                }
            }
        }
        public static string DOIImageNaming()
        {
            string strProjectNameForNumber = null;
            string imagename = null;
            if (!string.IsNullOrEmpty(GlobalMethods.strProjectName))
            {

                strProjectNameForNumber = GlobalMethods.strProjectName;

                if (strProjectNameForNumber.Contains("_") && strProjectNameForNumber.Split('_').Count() > 2)
                {
                    strProjectNameForNumber = strProjectNameForNumber.Substring(strProjectNameForNumber.IndexOf("_") + 1);
                    strProjectNameForNumber = strProjectNameForNumber.Substring(strProjectNameForNumber.IndexOf("_") + 1);
                    strProjectNameForNumber = strProjectNameForNumber.Substring(strProjectNameForNumber.IndexOf("_") + 1);
                }


            }

            return strProjectNameForNumber;
        }

       
    }
}
