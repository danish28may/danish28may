﻿using DocumentFormat.OpenXml.Packaging;
using System.Collections.Generic;
using System.Linq;
using DocumentFormat.OpenXml.Wordprocessing;
using DocumentFormat.OpenXml;
using OpenXmlPowerTools;
using System;

namespace MultiInstanceJournalCleanup
{
    class ArrangeFootNotes
    {
        private static Paragraph GetFootNoteContent(WordprocessingDocument wDoc, string footnoteRef)
        {
            Paragraph para = null;
            FootnotesPart footnotesPart = wDoc.MainDocumentPart.FootnotesPart;
            if (footnotesPart != null)
            {
                var footnotes = footnotesPart.Footnotes.Elements<Footnote>();
                foreach (var f in footnotes)
                {
                    if (f.Id == footnoteRef)
                    {
                        foreach (Paragraph p in f.Elements<Paragraph>())
                        {
                            foreach (Run r in p.Elements<Run>())
                            {
                                if (r.Elements<Text>().Count() == 0)
                                {
                                    if ((r.Elements<NoBreakHyphen>() != null) && (r.Elements<NoBreakHyphen>().Count() == 0))
                                    {
                                        if (r.FirstChild != null)
                                            r.FirstChild.Remove();
                                        if (r.LastChild != null)
                                            r.LastChild.Remove();
                                    }

                                }

                            }
                            para = p;
                        }
                        break;
                    }
                }
            }

            return para;
        }

        public static void Footnotes(string filePath)
        {
            using (WordprocessingDocument wDoc = WordprocessingDocument.Open(filePath, true))
            {
                var xDoc = wDoc.MainDocumentPart.Document.Body;

                var para = xDoc.Elements<Paragraph>();
                bool hasCT = false;
                List<Paragraph> listofFootnotes = new List<Paragraph>();
                int footnoteCount = 0;
                foreach (Paragraph p in para)
                {
                    var styleName = "";
                    if ((p.ParagraphProperties != null) && (p.ParagraphProperties.ParagraphStyleId != null))
                    {
                        styleName = p.ParagraphProperties.ParagraphStyleId.Val.Value;
                        if (styleName == "CT") hasCT = true;
                    }

                    int runLength = p.Elements<Run>().Count();
                    repeat:
                    runLength = runLength - 1;

                    foreach (var r in p.Elements<Run>())
                    {
                        foreach (var f in r.Elements<FootnoteReference>())
                        {
                            Paragraph footnotecontent = GetFootNoteContent(wDoc, f.Id);
                            listofFootnotes.Add(footnotecontent);
                            footnoteCount = footnoteCount + 1;
                            Run newrun = new Run(
                                            new RunProperties(
                                                new RunStyle()
                                                {
                                                    Val = "citefn"
                                                }
                                            )
                                );
                            newrun.AppendChild(new Text(footnoteCount.ToString()));
                            r.InsertBeforeSelf(newrun);
                            r.Remove();
                        }
                    }

                    if (runLength > 0)
                    {
                        goto repeat;
                    }

                    if (p.NextSibling<Paragraph>() != null)
                    {
                        var nextPara = p.NextSibling<Paragraph>();
                        if ((nextPara.ParagraphProperties != null) && (nextPara.ParagraphProperties.ParagraphStyleId != null))
                        {
                            var newstyleName = nextPara.ParagraphProperties.ParagraphStyleId.Val.Value;
                            if ((newstyleName == "CT") || (newstyleName == "PT"))
                            {
                                if (listofFootnotes.Count != 0)
                                {
                                    for (int i = listofFootnotes.Count; i > 0; i--)
                                    {
                                        Paragraph appendPara = new Paragraph(
                                                                    new ParagraphProperties(
                                                                        new ParagraphStyleId()
                                                                        {
                                                                            Val = "FTN"
                                                                        }
                                                                    )
                                                               );
                                        p.InsertAfterSelf(appendPara);

                                        Run appendRun = new Run(
                                                            new RunProperties(
                                                                new RunStyle()
                                                                {
                                                                    Val = "label-fn"
                                                                }
                                                            )
                                                        );
                                        appendPara.AppendChild(appendRun);

                                        appendRun.AppendChild(new Text(i + "") { Space = SpaceProcessingModeValues.Preserve });

                                        foreach (Run ir in listofFootnotes[i - 1].Elements<Run>())
                                        {
                                            if (ir.HasChildren)
                                            {
                                                appendPara.AppendChild(ir.CloneNode(true));

                                            }
                                        }

                                    }
                                    listofFootnotes.Clear();
                                    footnoteCount = 0;
                                    hasCT = false;
                                }
                            }
                        }
                    }

                    //lastpara = p;
                }

                if (hasCT)
                {
                    if (listofFootnotes.Count != 0)
                    {
                        for (int i = 0; i < listofFootnotes.Count; i++)
                        {
                            Paragraph appendPara = xDoc.AppendChild(new Paragraph(new ParagraphProperties(new ParagraphStyleId() { Val = "FTN" })));
                            Run newrun = new Run(
                                                new RunProperties(
                                                    new RunStyle()
                                                    {
                                                        Val = "label-fn"
                                                    }
                                                )
                                );
                            newrun.AppendChild(new Text(i + 1 + "") { Space = SpaceProcessingModeValues.Preserve });

                            appendPara.AppendChild(newrun);

                            foreach (Run ir in listofFootnotes[i].Elements<Run>())
                            {
                                if (ir.HasChildren)
                                {
                                    appendPara.AppendChild(ir.CloneNode(true));

                                }

                            }

                        }
                        listofFootnotes.Clear();
                    }
                }

                wDoc.MainDocumentPart.PutXDocument();
            }
        }


        private static List<Paragraph> GetFootNoteContentnew(WordprocessingDocument wDoc, string footnoteRef)
        {
            List<Paragraph> listpara = new List<Paragraph>();

            Paragraph para = null;
            FootnotesPart footnotesPart = wDoc.MainDocumentPart.FootnotesPart;
            if (footnotesPart != null)
            {
                var footnotes = footnotesPart.Footnotes.Elements<Footnote>();
                foreach (var f in footnotes)
                {
                    if (f.Id == footnoteRef)
                    {
                        foreach (Paragraph p in f.Elements<Paragraph>())
                        {
                            foreach (Run r in p.Elements<Run>())
                            {
                                if (r.Elements<Text>().Count() == 0)
                                {
                                    if ((r.Elements<NoBreakHyphen>() != null) && (r.Elements<NoBreakHyphen>().Count() == 0))
                                    {
                                        if (r.FirstChild != null)
                                            r.FirstChild.Remove();
                                        if (r.LastChild != null)
                                            r.LastChild.Remove();
                                    }

                                }

                            }
                            para = p;
                            listpara.Add(para);
                        }
                        break;
                    }
                }

            }

            return listpara;
        }

        private static List<Paragraph> GetEndNoteContent(WordprocessingDocument wDoc, string footnoteRef)
        {
            List<Paragraph> listpara = new List<Paragraph>();

            Paragraph para = null;
            EndnotesPart footnotesPart = wDoc.MainDocumentPart.EndnotesPart;
            if (footnotesPart != null)
            {
                var footnotes = footnotesPart.Endnotes.Elements<Endnote>();
                foreach (var f in footnotes)
                {
                    if (f.Id == footnoteRef)
                    {
                        foreach (Paragraph p in f.Elements<Paragraph>())
                        {
                            //foreach (Run r in p.Elements<Run>())
                            //{
                            //    if (r.Elements<Text>().Count() == 0)
                            //    {
                            //        if ((r.Elements<NoBreakHyphen>() != null) && (r.Elements<NoBreakHyphen>().Count() == 0))
                            //        {
                            //            if (r.FirstChild != null)
                            //                r.FirstChild.Remove();
                            //            if (r.LastChild != null)
                            //                r.LastChild.Remove();
                            //        }

                            //    }

                            //}
                            para = p;
                            listpara.Add(para);
                        }
                        break;
                    }
                }

            }

            return listpara;
        }

        public static void Footnotesnew(string filePath)
        {
            Findfootnoterefernce(filePath);
            using (WordprocessingDocument wDoc = WordprocessingDocument.Open(filePath, true))
            {
                var xDoc = wDoc.MainDocumentPart.Document.Body;

                var para = xDoc.Elements<Paragraph>();
                bool hasCT = false;
                string[] LowerAlphaarray1 = {
    "a",
    "b",
    "c",
    "d",
    "e",
    "f",
    "g",
    "h",
    "i",
    "j",
    "k",
    "l",
    "m",
    "n",
    "o",
    "p",
    "q",
    "r",
    "s",
    "t","u","v","w","x","y","z"
};
                var footnoteformating = "";
                //List<Paragraph> listofFootnotes = new List<Paragraph>();

                Dictionary<string, List<Paragraph>> dictfootnotes = new Dictionary<string, List<Paragraph>>();

                Dictionary<int, List<Paragraph>> dictendnotes = new Dictionary<int, List<Paragraph>>();

                int footnoteCount = 0;
                var twopart = false;
                foreach (Paragraph p in para)
                {
                    //var styleName = "";
                    //if ((p.ParagraphProperties != null) && (p.ParagraphProperties.ParagraphStyleId != null) && p.ParagraphProperties.ParagraphStyleId.Val != null)
                    //{
                    //    styleName = p.ParagraphProperties.ParagraphStyleId.Val.Value;
                    //    if (styleName == "CT")
                    //        hasCT = true;
                    //}

                    int runLength = p.Elements<Run>().Count();
                    repeat:
                    runLength = runLength - 1;

                    if (xDoc.Elements<SectionProperties>().Count() > 0)
                    {
                        try
                        {
                            if (xDoc.Elements<SectionProperties>().ToList().Any(x => x.Descendants<FootnoteProperties>().Count() > 0))
                            {
                                footnoteformating = xDoc.Elements<SectionProperties>().ToList().Where(x => x.Descendants<FootnoteProperties>() != null).FirstOrDefault().Descendants<NumberingFormat>().FirstOrDefault().GetAttributes().FirstOrDefault().Value;
                            }
                        }
                        catch (Exception e)
                        {



                        }
                    }

                    foreach (var r in p.Elements<Run>())
                    {
                        foreach (var f in r.Elements<FootnoteReference>())
                        {
                            List<Paragraph> footnotecontent = GetFootNoteContentnew(wDoc, f.Id);

                            //listofFootnotes.Add(footnotecontent);
                            if (r.InnerText == "*")
                            {
                                dictfootnotes.Add("*", footnotecontent);
                                twopart = true;
                            }
                            else
                            {
                                if (twopart)
                                {
                                    dictfootnotes.Add((Convert.ToInt32(f.Id.Value) - 1).ToString(), footnotecontent);
                                }
                                else
                                    dictfootnotes.Add(f.Id.Value.ToString(), footnotecontent);
                            }

                            footnoteCount = footnoteCount + 1;
                            //Run newrun = new Run(
                            //                new RunProperties(
                            //                    new RunStyle(){
                            //                        Val = "citefn"
                            //                    }
                            //                )
                            //    );
                            if (footnoteformating == "lowerLetter")
                            {
                                Run newrun = new Run();
                                RunProperties newrpr = new RunProperties();
                                newrpr.VerticalTextAlignment = new VerticalTextAlignment { Val = VerticalPositionValues.Superscript };
                                newrpr.RunStyle = new RunStyle() { Val = "citefn" };

                                newrun.Append(newrpr.CloneNode(true));
                                newrun.AppendChild(new Text(LowerAlphaarray1[footnoteCount - 1].ToString()));
                                r.InsertBeforeSelf(newrun);
                                r.Remove();
                            }
                            else if (r.InnerText == "*")
                            {
                                Run newrun = new Run();
                                RunProperties newrpr = new RunProperties();
                                newrpr.VerticalTextAlignment = new VerticalTextAlignment { Val = VerticalPositionValues.Superscript };
                                newrpr.RunStyle = new RunStyle() { Val = "citefn" };

                                newrun.Append(newrpr.CloneNode(true));
                                newrun.AppendChild(new Text("*"));
                                r.InsertBeforeSelf(newrun);
                                r.Remove();
                                footnoteCount = footnoteCount - 1;
                            }
                            else
                            {
                                Run newrun = new Run();
                                RunProperties newrpr = new RunProperties();
                                newrpr.VerticalTextAlignment = new VerticalTextAlignment { Val = VerticalPositionValues.Superscript };
                                newrpr.RunStyle = new RunStyle() { Val = "citefn" };

                                newrun.Append(newrpr.CloneNode(true));
                                newrun.AppendChild(new Text(footnoteCount.ToString()));
                                r.InsertBeforeSelf(newrun);
                                r.Remove();
                            }
                        }
                        foreach (var f in r.Elements<EndnoteReference>())/////added by vikas for endnote on 27-03-2020
                        {
                            List<Paragraph> footnotecontent = GetEndNoteContent(wDoc, f.Id);

                            //listofFootnotes.Add(footnotecontent);
                            if (!dictendnotes.ContainsKey(Convert.ToInt32(f.Id.Value)))
                                dictendnotes.Add(Convert.ToInt32(f.Id.Value), footnotecontent);


                            footnoteCount = footnoteCount + 1;
                            //Run newrun = new Run(
                            //                new RunProperties(
                            //                    new RunStyle(){
                            //                        Val = "citefn"
                            //                    }
                            //                )
                            //    );
                            //foreach (var j in r.Elements<RunProperties>().ToList())
                            //{
                            //    foreach (var k in j.Elements<RunStyle>().ToList())
                            //    {
                            //        j.Append(new VerticalTextAlignment { Val = VerticalPositionValues.Superscript });

                            //        k.Val = "citefn";
                            //    }
                            //}
                            Run newrun = new Run();
                            RunProperties newrpr = new RunProperties();
                            newrpr.VerticalTextAlignment = new VerticalTextAlignment { Val = VerticalPositionValues.Superscript };
                            newrpr.RunStyle = new RunStyle() { Val = "citefn" };

                            newrun.Append(newrpr.CloneNode(true));
                            newrun.AppendChild(new Text(footnoteCount.ToString()));
                            r.InsertBeforeSelf(newrun);
                            r.Remove();

                        }
                    }

                    if (runLength > 0)
                    {
                        goto repeat;
                    }

                    if (p.NextSibling<Paragraph>() != null)
                    {
                        var nextPara = p.NextSibling<Paragraph>();
                        if ((nextPara.ParagraphProperties != null) && (nextPara.ParagraphProperties.ParagraphStyleId != null) && nextPara.ParagraphProperties.ParagraphStyleId.Val != null)
                        {
                            var newstyleName = nextPara.ParagraphProperties.ParagraphStyleId.Val.Value;
                            if ((newstyleName == "CT") || (newstyleName == "PT"))
                            {
                                if (dictfootnotes.Count != 0)
                                {
                                    for (int i = dictfootnotes.Count; i > 0; i--)
                                    {
                                        string footnoteid = dictfootnotes.ElementAt(i - 1).Key;
                                        List<Paragraph> footnoteparas = dictfootnotes.ElementAt(i - 1).Value;

                                        for (int j = footnoteparas.Count; j > 0; j--)
                                        {
                                            Paragraph appendPara = new Paragraph(
                                                                        new ParagraphProperties(
                                                                            new ParagraphStyleId()
                                                                            {
                                                                                Val = "FTN"
                                                                            }
                                                                        )
                                                                   );
                                            p.InsertAfterSelf(appendPara);

                                            Run appendRun = new Run(
                                                                new RunProperties(
                                                                    new RunStyle()
                                                                    {
                                                                        Val = "label-fn"
                                                                    }
                                                                )
                                                            );
                                            appendPara.AppendChild(appendRun);

                                            if (j == 1)
                                            {
                                                if (footnoteformating == "lowerLetter")
                                                {
                                                    appendRun.AppendChild(new Text(LowerAlphaarray1[Convert.ToInt32(footnoteid) - 1].ToString() + "") { Space = SpaceProcessingModeValues.Preserve });
                                                }
                                                else if (footnoteparas[j].InnerText.StartsWith("*"))
                                                {
                                                    appendRun.AppendChild(new Text("*" + "") { Space = SpaceProcessingModeValues.Preserve });
                                                }
                                                else
                                                {
                                                    appendRun.AppendChild(new Text(footnoteid + "") { Space = SpaceProcessingModeValues.Preserve });
                                                }
                                            }

                                            foreach (Run ir in footnoteparas[j - 1].Elements<Run>())
                                            {
                                                if (ir.HasChildren)
                                                {
                                                    appendPara.AppendChild(ir.CloneNode(true));

                                                }
                                            }
                                        }
                                    }
                                    dictfootnotes.Clear();
                                    footnoteCount = 0;

                                }
                            }
                        }
                    }

                    //lastpara = p;
                }

                //if (hasCT)
                //{
                if (dictfootnotes.Count != 0)
                {
                    for (int i = 0; i < dictfootnotes.Count; i++)
                    {
                        string footnoteid = dictfootnotes.ElementAt(i).Key;
                        List<Paragraph> footnoteparas = dictfootnotes.ElementAt(i).Value;

                        for (int j = 0; j < footnoteparas.Count; j++)
                        {
                            Paragraph appendPara = xDoc.AppendChild(new Paragraph(new ParagraphProperties(new ParagraphStyleId() { Val = "FTN" })));
                            Run newrun = new Run(
                                                new RunProperties(
                                                    new RunStyle()
                                                    {
                                                        Val = "label-fn"
                                                    }
                                                )
                                );
                            if (j == 0)
                            {
                                if (footnoteformating == "lowerLetter")
                                {
                                    newrun.AppendChild(new Text(LowerAlphaarray1[Convert.ToInt32(footnoteid) - 1].ToString() + "") { Space = SpaceProcessingModeValues.Preserve });
                                }
                                else if (footnoteparas[j].InnerText.StartsWith("*"))
                                {
                                    if (footnoteparas[j].Descendants<Run>().Count() > 0)
                                    {
                                        if (footnoteparas[j].Descendants<Run>().FirstOrDefault().InnerText == "*")
                                        {
                                            footnoteparas[j].Descendants<Run>().FirstOrDefault().Remove();
                                        }
                                    }
                                    newrun.AppendChild(new Text("*" + "") { Space = SpaceProcessingModeValues.Preserve });
                                }
                                else
                                {
                                    newrun.AppendChild(new Text(footnoteid + "") { Space = SpaceProcessingModeValues.Preserve });
                                }

                            }

                            appendPara.AppendChild(newrun);

                            foreach (Run ir in footnoteparas[j].Elements<Run>())
                            {
                                if (ir.HasChildren)
                                {
                                    appendPara.AppendChild(ir.CloneNode(true));

                                }

                            }
                        }
                    }
                    dictfootnotes.Clear();
                }
                else if (dictendnotes.Count != 0)//////added by vikas on 27-03-2020 for endnote
                {
                    //for (int i = 0; i < dictendnotes.Count; i++)
                    //{
                    //    int footnoteid = dictendnotes.ElementAt(i).Key;
                    //    List<Paragraph> footnoteparas = dictendnotes.ElementAt(i).Value;

                    //    foreach (var paraft in footnoteparas)
                    //    {
                    //        foreach (var pft in paraft.Descendants<ParagraphProperties>().ToList())
                    //        {
                    //            foreach (var pstft in pft.Descendants<ParagraphStyleId>().ToList())
                    //            {
                    //                pstft.Val = "FTN";
                    //            }
                    //        }
                    //        foreach (var r in paraft.Elements<Run>())
                    //        {



                    //            //Run newrun = new Run(
                    //            //                new RunProperties(
                    //            //                    new RunStyle(){
                    //            //                        Val = "citefn"
                    //            //                    }
                    //            //                )
                    //            //    );
                    //            foreach (var j in r.Elements<RunProperties>().ToList())
                    //            {
                    //                foreach (var k in j.Elements<RunStyle>().ToList())
                    //                {
                    //                    if (k.Val == "EndnoteReference")
                    //                    {
                    //                        k.Val = "label-fn";
                    //                        j.Append(new VerticalTextAlignment { Val = VerticalPositionValues.Superscript });

                    //                    }
                    //                }
                    //            }


                    //        }
                    //    }
                    //}
                    for (int i = 0; i < dictendnotes.Count; i++)
                    {
                        int footnoteid = dictendnotes.ElementAt(i).Key;
                        List<Paragraph> footnoteparas = dictendnotes.ElementAt(i).Value;

                        for (int j = 0; j < footnoteparas.Count; j++)
                        {
                            Paragraph appendPara = xDoc.AppendChild(new Paragraph(new ParagraphProperties(new ParagraphStyleId() { Val = "FTN" })));
                            Run newrun = new Run(
                                                new RunProperties(
                                                    new RunStyle()
                                                    {
                                                        Val = "label-fn"
                                                    }
                                                )
                                );
                            if (j == 0)
                            {
                                if (footnoteformating == "lowerLetter")
                                {
                                    newrun.AppendChild(new Text(LowerAlphaarray1[Convert.ToInt32(footnoteid) - 1].ToString() + "") { Space = SpaceProcessingModeValues.Preserve });
                                }
                                else if (footnoteparas[j].InnerText.StartsWith("*"))
                                {
                                    if (footnoteparas[j].Descendants<Run>().Count() > 0)
                                    {
                                        if (footnoteparas[j].Descendants<Run>().FirstOrDefault().InnerText == "*")
                                        {
                                            footnoteparas[j].Descendants<Run>().FirstOrDefault().Remove();
                                        }
                                    }
                                    newrun.AppendChild(new Text("*" + "") { Space = SpaceProcessingModeValues.Preserve });
                                }
                                else
                                {
                                    newrun.AppendChild(new Text(footnoteid + "") { Space = SpaceProcessingModeValues.Preserve });
                                }

                            }

                            appendPara.AppendChild(newrun);

                            foreach (Run ir in footnoteparas[j].Elements<Run>())
                            {
                                if (ir.HasChildren)
                                {
                                    appendPara.AppendChild(ir.CloneNode(true));

                                }

                            }
                        }
                    }
                    dictendnotes.Clear();
                }
                //}

                wDoc.MainDocumentPart.PutXDocument();
            }
        }


        public static void Findfootnoterefernce(string strWordDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                  .Open(strWordDoc, true))
            {

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (var P in D.Descendants<Paragraph>().Where(x => x.OuterXml.Contains("w:val=\"FootnoteReference\"")))
                {
                    if (!P.Descendants<Run>().Any(x => x.Descendants().Any(y => y.LocalName == W.footnoteReference.LocalName)))
                    {
                        var paraswithfootnoterefenence = D.Descendants<Paragraph>().Where(x => x.OuterXml.Contains("w:footnoteReference") && !x.OuterXml.Contains("w:val=\"FootnoteReference\""));
                        if (paraswithfootnoterefenence.Count() > 0)
                        {
                            foreach (var run in paraswithfootnoterefenence.FirstOrDefault().Descendants<Run>().Where(x => x.Descendants().Any(y => y.LocalName == W.footnoteReference.LocalName)).ToList())
                            {
                                var footnoteref = run.Descendants<FootnoteReference>().FirstOrDefault();
                                var runnew= P.Descendants<Run>().Where(r=>r.Descendants<RunStyle>().Count()>0 && r.Descendants<RunStyle>().FirstOrDefault().GetAttributes().FirstOrDefault().Value== "FootnoteReference");
                                if(runnew.Count()>0)
                                {
                                    runnew.FirstOrDefault().Append(footnoteref.CloneNode(true));

                                    footnoteref.Remove();
                                }
                            }
                        }
                    }
                }
                D.Save();
            }
        }

    }
}
