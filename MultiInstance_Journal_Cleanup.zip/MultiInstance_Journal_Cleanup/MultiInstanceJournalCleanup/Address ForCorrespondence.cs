﻿using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;
using OpenXmlPowerTools;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace MultiInstanceJournalCleanup
{
    class Address_ForCorrespondence
    {
        public static List<string> LstAddressForCoresspondingStyleColl = null;

        public static void Merge_Address_ForCorrespondence(string strWordDoc, string straddress_cor_pattern, string strCoraddTxt, string strAddressinfoColl, string strDegreeColl)
        {
            try
            {
                List<string> strCorAddPatterns = new List<string>();
                strCorAddPatterns = GlobalMethods.ReadAndStoreFileValuesInArray(straddress_cor_pattern);

                //UpdateReferencePatternIndex method create. 
                GlobalMethods.UpdateReferencePatternIndex(strCorAddPatterns, straddress_cor_pattern);

                // Update the UpdateReferencePattern Lookup File //

                LstAddressForCoresspondingStyleColl = new List<string>();
                LstAddressForCoresspondingStyleColl.Clear();

                GlobalMethods.strAddressCorresspondenStyleDB = ConfigurationManager.AppSettings.Get("AddCoresspondingStyleDB");

                LstAddressForCoresspondingStyleColl = GlobalMethods.ReadAndStoreFileValuesInArray(GlobalMethods.strAddressCorresspondenStyleDB);

                MergeAddressCoressSpondElementsIntoOneGroup(strWordDoc, straddress_cor_pattern, strCoraddTxt, strAddressinfoColl, strDegreeColl);
                

            }
            catch (Exception ex)
            {

            }
        }
        

        private static void MergeAddressCoressSpondElementsIntoOneGroup(string newDoc, string AddCorFile, string AddressTxt, string AddressDB, string DegreeDB)
        {
            ///bool added by karan for pattern match or not on 18-08-2018
            GlobalMethods.AddressCorStructured = false;

            List<string> strAddCorPatterns = new List<string>();
            strAddCorPatterns = GlobalMethods.ReadAndStoreFileValuesInArray(AddCorFile);

            List<string> strAddressCollTxt = new List<string>();
            strAddressCollTxt = GlobalMethods.ReadAndStoreFileValuesInArray(AddressTxt);
            strAddressCollTxt = GlobalMethods.SortStringListOnLength(strAddressCollTxt);

            List<string> strAddressColl = new List<string>();
            strAddressColl = GlobalMethods.ReadAndStoreFileValuesInArray(AddressDB);
            strAddressColl = GlobalMethods.SortStringListOnLength(strAddressColl);

            #region old logic
            ////commeneted by Karan on 23-05-2018 start
            //////List<string> strPindcodesColl = new List<string>();
            //////strPindcodesColl = GlobalMethods.ReadAndStoreFileValuesInArray(PincodeDB);
            //////strPindcodesColl = GlobalMethods.SortStringListOnLength(strPindcodesColl);


            //////List<string> strCitysColl = new List<string>();
            //////strCitysColl = GlobalMethods.ReadAndStoreFileValuesInArray(CityDB);
            //////strCitysColl = GlobalMethods.SortStringListOnLength(strCitysColl);


            //////List<string> strStatesColl = new List<string>();
            //////strStatesColl = GlobalMethods.ReadAndStoreFileValuesInArray(StatesDB);
            //////strStatesColl = GlobalMethods.SortStringListOnLength(strStatesColl);
            ////commeneted by Karan on 23-05-2018 end
            #endregion

            List<string> strDegreesColl = new List<string>();
            strDegreesColl = GlobalMethods.ReadAndStoreFileValuesInArray(DegreeDB);
            strDegreesColl = GlobalMethods.SortStringListOnLength(strDegreesColl);

            ///logic start
            int nRefNumberCounter = 0;

            using (WordprocessingDocument WPD = WordprocessingDocument
                .Open(newDoc, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    RemoveComments = false,
                    RemoveContentControls = true,
                    RemoveEndAndFootNotes = false,
                    RemoveFieldCodes = true,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = false,//Developer name :Priyanka Vishwakarma. Date:29_5_2019, Requirement:it removes the indentation from the nested list  ,Integrated By:Vikas sir. 
                };

                MarkupSimplifier.SimplifyMarkup(WPD, settings);

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().
                    Where(e => e.ParagraphProperties != null
                        && e.ParagraphProperties.ParagraphStyleId != null
                        && e.ParagraphProperties.ParagraphStyleId.Val == "CORR"))
                {
                    if (P.HasChildren == false)
                    {
                        try
                        {
                            P.Remove();
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(ex.Message);
                        }
                    }
                    else
                    {
                        bool paramatch = false;
                        if (P.HasChildren == true)
                        {
                            var rList = P.Elements().ToList();
                            if (P.Descendants<Run>().Count() > 0)
                            {
                                string strReferenceText = null;

                                foreach (Run R in P.Descendants<Run>().ToList())
                                {
                                    foreach (Text T in R.Descendants<Text>().ToList())
                                    {
                                        strReferenceText = strReferenceText + T.Text;
                                        ///strReferenceText in Address for correspondence: Sunita Chhapola Shukla, DNB, DORL, FCPS, MS (ENT), Department of ENT Surgery, Mumbai Port Trust Hospital, Mumbai 400037, Maharashtra, India
                                    }


                                    //R.Remove();///commented by Karan on 21-06-2018
                                }
                                nRefNumberCounter++;

                                List<string> strRefGroups = new List<string>();
                                bool bPatternStart = false;
                                string SearchPattern = null;
                                int ReplaceGrpCount = 0;
                                strRefGroups.Clear();
                                List<string> strRefSearchPattern = new List<string>();
                                int nIndex = 0;
                                int nGrpCounter = 0;
                                int nPatternIndex = 0;

                                for (int i = 0; i < strAddCorPatterns.Count; i++)
                                {
                                    if (strAddCorPatterns[i].ToLower().StartsWith("[pattern start]") == true)
                                    {
                                        nPatternIndex++;
                                        strRefGroups.Clear();
                                        bPatternStart = true;
                                        continue;
                                    }
                                    if (bPatternStart == true)
                                    {
                                        if (strAddCorPatterns[i].ToLower().StartsWith("searchpattern:") == true)
                                        {
                                            SearchPattern = strAddCorPatterns[i].Replace("SearchPattern:", "");

                                            ///var degcount = CountStringOccurrences(SearchPattern, "DEG");

                                            continue;
                                        }
                                        if (strAddCorPatterns[i].ToLower().StartsWith("replacegroup:") == true)
                                        {
                                            string RpGrp = strAddCorPatterns[i].Replace("ReplaceGroup:", "");
                                            ReplaceGrpCount = Convert.ToInt32(RpGrp);
                                            continue;
                                        }

                                        if (strAddCorPatterns[i].ToLower().StartsWith("group:") == true)
                                        {
                                            strRefGroups.Add(strAddCorPatterns[i].Replace("Group:", ""));
                                            continue;
                                        }
                                    }
                                    string strAddtext = "";
                                    if (strAddCorPatterns[i].ToLower().StartsWith("[pattern end]") == true)
                                    {
                                        bPatternStart = false;

                                        for (nIndex = 0; nIndex < strAddressCollTxt.Count; nIndex++)
                                        {
                                            //string strTmp;

                                            if (strReferenceText.Contains(strAddressCollTxt[nIndex]))
                                            {
                                                strAddtext = strAddressCollTxt[nIndex];
                                                //strTmp = strAddressCollTxt[nIndex].Replace("(", @"\(").Replace(")", @"\)").Replace(".", @"\.");
                                                //strRefSearchPattern.Add(SearchPattern.Replace("(CORR)", "(" + strTmp + ")"));
                                                //break;
                                            }
                                        }
                                        bool bAddress = false;
                                        for (nIndex = 0; nIndex < strAddressColl.Count; nIndex++)
                                        {
                                            string strTmp; //= strJournalsColl[nIndex].Replace("(", @"\(").Replace(")", @"\)").Replace(".", @"\.");

                                            string newstr = strAddressColl[nIndex];
                                            string[] separators = { "|" };
                                            string[] links = newstr.Split(separators, StringSplitOptions.None);
                                            int count = links.Length;
                                            int counter = 0;
                                            for (int k = 0; k < links.Count(); k++)
                                            {
                                                if (strReferenceText.Contains(links[k]))
                                                {
                                                    bAddress = true;
                                                    counter++;
                                                }
                                                else
                                                {
                                                    bAddress = false;
                                                    goto nextstrAddressColl;
                                                }
                                            }

                                            if (bAddress == true && counter == count)
                                            {
                                                string country = links[0];
                                                string state = links[1];
                                                string city = links[2];
                                                string pincode = links[3];

                                                strTmp = strAddressColl[nIndex].Replace("(", @"\(").Replace(")", @"\)").Replace(".", @"\.");
                                                if (string.IsNullOrEmpty(country))
                                                {
                                                    SearchPattern = SearchPattern.Replace("(COUNTRY)(\\,)", "");
                                                }
                                                else
                                                {
                                                    SearchPattern = SearchPattern.Replace("(COUNTRY)", "(" + country + ")");
                                                }
                                                if (string.IsNullOrEmpty(state))
                                                {
                                                    SearchPattern = SearchPattern.Replace("(STATE)(\\,)", "");
                                                }
                                                else
                                                {
                                                    SearchPattern = SearchPattern.Replace("(STATE)", "(" + state + ")");
                                                }
                                                if (string.IsNullOrEmpty(city))
                                                {
                                                    SearchPattern = SearchPattern.Replace("(CITY)(\\,)", "");
                                                }
                                                else
                                                {
                                                    SearchPattern = SearchPattern.Replace("(CITY)", "(" + city + ")");
                                                }
                                                if (string.IsNullOrEmpty(pincode))
                                                {
                                                    SearchPattern = SearchPattern.Replace("(PINCODE)(\\,)", "");
                                                }
                                                else
                                                {
                                                    SearchPattern = SearchPattern.Replace("(PINCODE)", "(" + pincode + ")");
                                                }
                                                if (string.IsNullOrEmpty(strAddtext))
                                                {
                                                    SearchPattern = SearchPattern.Replace("(CORR)(\\:)", "");
                                                }
                                                else
                                                {
                                                    SearchPattern = SearchPattern.Replace("(CORR)", "(" + strAddtext + ")");
                                                }

                                                strRefSearchPattern.Add(SearchPattern);

                                                break;
                                            }
                                            nextstrAddressColl: { }

                                        }
                                        // Search operation is ready

                                        if (ReplaceGrpCount > 0)
                                        {
                                            if (strRefGroups.Count != ReplaceGrpCount)
                                            {
                                                strRefGroups.Clear();
                                                goto NextRefSearchPattern;
                                            }

                                            //bool paramatch = false;//commented by Karan on 11-06-2018
                                            paramatch = false;
                                            for (nIndex = 0; nIndex < strRefSearchPattern.Count; nIndex++)
                                            {
                                                paramatch = false;
                                                MatchCollection matches = Regex.Matches(strReferenceText, strRefSearchPattern[nIndex]);

                                                if (matches.Count == 1)
                                                {
                                                    ///bool added by karan for pattern match or not on 18-08-2018
                                                    GlobalMethods.AddressCorStructured = true;

                                                    ///added foreach by Karan on 21-06-2018 for remove R.
                                                    foreach (var item in P.Descendants<Run>().ToList())
                                                    {
                                                        item.Remove();
                                                    }

                                                    paramatch = true;
                                                    Run R = new Run();
                                                    P.Append(R);

                                                    foreach (Match match in matches)
                                                    {
                                                        if ((match.Groups.Count - 1) != ReplaceGrpCount)
                                                            break;

                                                        int GrpNo = 0;

                                                        for (nGrpCounter = 0; nGrpCounter < strRefGroups.Count; nGrpCounter++)
                                                        {
                                                            string tmpstr = null;
                                                            tmpstr = strRefGroups[nGrpCounter];
                                                            GrpNo = 0;
                                                            GrpNo = nGrpCounter + 1;

                                                            if (tmpstr.Contains(":"))
                                                            {
                                                                // Split the string
                                                                string[] separators = { ":" };
                                                                string[] strValues = tmpstr.Split(separators, StringSplitOptions.RemoveEmptyEntries);

                                                                if (strValues.Length > 0)
                                                                {
                                                                    if (strValues[0] == "space")
                                                                    {
                                                                        Run newrun = new Run();
                                                                        newrun.AppendChild(new Text(" ") { Space = SpaceProcessingModeValues.Preserve });
                                                                        R.InsertBeforeSelf(newrun);
                                                                    }
                                                                    else if (strValues[0] == "blank")
                                                                    {
                                                                        // No action required
                                                                    }
                                                                    else if (strValues[0] == "value")
                                                                    {
                                                                        //Run run = P.AppendChild(new Run());
                                                                        // Add Text to the Run element.
                                                                        Run newrun = new Run();
                                                                        newrun.AppendChild(new Text(match.Groups[nGrpCounter + 1].Value));
                                                                        R.InsertBeforeSelf(newrun);
                                                                    }

                                                                    if (strValues[1] != "") // Style
                                                                    {
                                                                        Run newrun = new Run();
                                                                        RunProperties rpr = new RunProperties(new RunStyle() { Val = strValues[1] });
                                                                        newrun.AppendChild(rpr);

                                                                        newrun.AppendChild(new Text(match.Groups[nGrpCounter + 1].Value));

                                                                        R.InsertBeforeSelf(newrun);
                                                                    }
                                                                }
                                                            }
                                                            else if (tmpstr.Contains("space"))
                                                            {
                                                                //Run run = P.AppendChild(new Run());
                                                                //OpenXmlAttribute openXmlAttribute = new OpenXmlAttribute("space", "xml", "preserve");
                                                                // Add Text to the Run element.
                                                                Run newrun = new Run();
                                                                Text T = new Text(" ") { Space = SpaceProcessingModeValues.Preserve };
                                                                //T.SetAttribute(openXmlAttribute);
                                                                newrun.AppendChild(T);
                                                                R.InsertBeforeSelf(newrun);
                                                            }
                                                            else if (tmpstr.Contains("blank"))
                                                            {
                                                            }
                                                            else if (tmpstr.Contains("value"))
                                                            {
                                                                //Run run = P.AppendChild(new Run());
                                                                // Add Text to the Run element.
                                                                Run newrun = new Run();
                                                                newrun.AppendChild(new Text(match.Groups[nGrpCounter + 1].Value));
                                                                R.InsertBeforeSelf(newrun);
                                                            }
                                                            else
                                                            {
                                                                Run newrun = new Run();
                                                                //Run run = new Run(new RunProperties(new RunStyle() { Val = tmpstr }));
                                                                RunProperties rpr = new RunProperties(new RunStyle() { Val = tmpstr });
                                                                newrun.AppendChild(rpr);
                                                                //P.AppendChild(run);
                                                                // Add Text to the Run element.
                                                                newrun.AppendChild(new Text(match.Groups[nGrpCounter + 1].Value));
                                                                R.InsertBeforeSelf(newrun);
                                                            }
                                                        }
                                                    }
                                                }
                                                if (paramatch)
                                                {
                                                    goto newpara;
                                                }
                                                else
                                                {
                                                    strRefSearchPattern.Clear();
                                                }
                                            }
                                        }
                                        NextRefSearchPattern:
                                        {
                                            continue;
                                        }
                                    }
                                }
                                //NextRef:
                                //{
                                //    continue;
                                //}
                            }
                            newpara:
                            {
                                ////commented by Karan on 21-06-2018 because deleted para handle.
                                ////if (paramatch == false)
                                ////{
                                ////    Paragraph newpara = new Paragraph();
                                ////    //ParagraphProperties newppr = new ParagraphProperties(new ParagraphStyleId { Val = "CORR" });
                                ////    //newpara.Append(newppr);
                                ////    foreach (var item in rList)
                                ////    {
                                ////        newpara.Append(item.CloneNode(true));
                                ////    }
                                ////    P.InsertAfterSelf(newpara);
                                ////    P.Remove();
                                ////}
                            }
                        }
                    }

                }
                D.Save();
                ///logic end
            }
        }

        public static void Merge_Address_ForCorrespondence1(string strWordDoc, string straddress_cor_pattern, string strCoraddTxt, string strCountryColl, string strStatesColl, string strCityColl, string strPincodeColl, string strDegreeColl, string strInstitutionColl, string strAddressLineColl)
        {
            try
            {

                LstAddressForCoresspondingStyleColl = new List<string>();
                LstAddressForCoresspondingStyleColl.Clear();

                GlobalMethods.strAddressCorresspondenStyleDB = ConfigurationManager.AppSettings.Get("AddCoresspondingStyleDB");

                LstAddressForCoresspondingStyleColl = GlobalMethods.ReadAndStoreFileValuesInArray(GlobalMethods.strAddressCorresspondenStyleDB);
                if(GlobalMethods.strClientName.ToLower() == "sage" || GlobalMethods.strClientName.ToLower() == "jaypee"|| GlobalMethods.strClientName.ToLower() == "ssllc" || GlobalMethods.strClientName.ToLower() == "pps")
                {
                    if (!GlobalMethods.strJournalArticlePath.Contains("\\India\\") && GlobalMethods.strClientName.ToLower() != "jaypee" && GlobalMethods.strClientName.ToLower() != "ssllc" && GlobalMethods.strClientName.ToLower() != "pps") //Developer Name:Priyanka Vishwakarma,Date:30-09-2021, Requirement: add condition for avoid corr para structuring
                    {
                        MergeAddressCoressSpondElementsIntoOneGroup1(strWordDoc, null, strCountryColl, strPincodeColl, strCityColl, strStatesColl, strDegreeColl, strInstitutionColl, strAddressLineColl);
                        checkAllCorrCharrStyleInSequence(strWordDoc);//Developer Name:Priyanka Vishwakarma, Date:05-01-2021, Requirement:Add function for Apply  corrInstitution Char style to corrAddressline when Corrinstitution style not found in CORR para 
                    }
                }                
                else
                {
                    MergeAddressCoressSpondElementsIntoOneGroup1(strWordDoc, null, strCountryColl, strPincodeColl, strCityColl, strStatesColl, strDegreeColl, strInstitutionColl, strAddressLineColl);

                    checkAllCorrCharrStyleInSequence(strWordDoc);//Developer Name:Priyanka Vishwakarma, Date:05-01-2021, Requirement:Add function for Apply  corrInstitution Char style to corrAddressline when Corrinstitution style not found in CORR para 
                }

                if (GlobalMethods.strClientName.ToLower()=="ufl"|| GlobalMethods.strClientName.ToLower() == "sage") //Developer Name:Priyanka Vishwakarma,Date:15-08-2020,Requirement:Email text comes into another para in ufl input and sage input 13-10-2020 added by vikas
                {
                    if (GlobalMethods.strCopyediting == "true") //condition added for sage india copyediting file.
                    {
                        CheckCorrPara(strWordDoc);
                    }
                }
            }
            catch (Exception ex)
            {

            }
        }

        private static void MergeAddressCoressSpondElementsIntoOneGroup1(string newDoc, string AddCorFile, string CountryDB, string PincodeDB, string CityDB, string StatesDB, string DegreeDB, string InstitutionDB, string AddressLineDB)
        {
            //List<string> strAddCorPatterns = new List<string>();
            //strAddCorPatterns = GlobalMethods.ReadAndStoreFileValuesInArray(AddCorFile);

            List<string> strCountrysColl = new List<string>();
            strCountrysColl = GlobalMethods.ReadAndStoreFileValuesInArray(CountryDB);
            strCountrysColl = GlobalMethods.SortStringListOnLength(strCountrysColl);


            List<string> strPindcodesColl = new List<string>();
            strPindcodesColl = GlobalMethods.ReadAndStoreFileValuesInArray(PincodeDB);
            strPindcodesColl = GlobalMethods.SortStringListOnLength(strPindcodesColl);


            List<string> strCitysColl = new List<string>();
            strCitysColl = GlobalMethods.ReadAndStoreFileValuesInArray(CityDB);
            strCitysColl = GlobalMethods.SortStringListOnLength(strCitysColl);


            List<string> strStatesColl = new List<string>();
            strStatesColl = GlobalMethods.ReadAndStoreFileValuesInArray(StatesDB);
            strStatesColl = GlobalMethods.SortStringListOnLength(strStatesColl);


            List<string> strDegreesColl = new List<string>();
            strDegreesColl = GlobalMethods.ReadAndStoreFileValuesInArray(DegreeDB);
            strDegreesColl = GlobalMethods.SortStringListOnLength(strDegreesColl);

            List<string> strInstitutionColl = new List<string>();
            strInstitutionColl = GlobalMethods.ReadAndStoreFileValuesInArray(InstitutionDB);
            strInstitutionColl = GlobalMethods.SortStringListOnLength(strInstitutionColl);

            List<string> strAddressLineColl = new List<string>();
            strAddressLineColl = GlobalMethods.ReadAndStoreFileValuesInArray(AddressLineDB);
            strAddressLineColl = GlobalMethods.SortStringListOnLength(strAddressLineColl);
            ///logic start

            using (WordprocessingDocument WPD = WordprocessingDocument
                .Open(newDoc, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    RemoveComments = false,
                    RemoveContentControls = true,
                    RemoveEndAndFootNotes = false,
                    RemoveFieldCodes = true,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = false,//Developer name :Priyanka Vishwakarma. Date:29_5_2019, Requirement:it removes the indentation from the nested list  ,Integrated By:Vikas sir. 
                };

                MarkupSimplifier.SimplifyMarkup(WPD, settings);

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().
                    Where(e => e.ParagraphProperties != null
                        && e.ParagraphProperties.ParagraphStyleId != null
                        && e.ParagraphProperties.ParagraphStyleId.Val == "CORR"))
                {
                   if((GlobalMethods.strClientName.ToLower()=="jaypee"|| GlobalMethods.strClientName.ToLower() == "ssllc") && P.Descendants<Run>().ToList().Where(x=>x.RunProperties!=null && x.RunProperties.RunStyle!=null && x.RunProperties.RunStyle.Val!=null && x.RunProperties.RunStyle.Val.Value.ToLower()=="corrtitle").Count()>0)
                    {
                        goto NextFun;
                    }

                    if (P.HasChildren == false)
                    {
                        try
                        {
                            P.Remove();
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(ex.Message);
                        }
                    }
                    else
                    {
                        var ppr = P.Descendants<ParagraphProperties>();
                        if (P.InnerText != null)
                        {
                            if (P.InnerText.ToLower().StartsWith("email") || P.InnerText.ToLower().StartsWith("e-mail"))
                            {
                                goto Next;
                            }
                            bool commentexist = false;
                            List<string> commentedtext = new List<string>();

                            bool IscorrTitle = false;

                            string previousstyle = null;

                            foreach (OpenXmlElement item in P.Elements().ToList())
                            {
                                if (item.XName == W.bookmarkStart)
                                {
                                    if (item.PreviousSibling().PreviousSibling().LocalName == "r")
                                    {
                                        Run R = (Run)item.PreviousSibling().PreviousSibling();
                                        string commentedtext1 = R.InnerText;

                                        ///commented text added in List
                                        commentedtext.Add(commentedtext1);
                                        commentexist = true;
                                    }
                                }
                            }

                            string dummytext = null;

                            if (commentexist)
                            {
                                if (commentedtext.Count > 0)
                                {
                                    foreach (Run R in P.Descendants<Run>().ToList())
                                    {
                                        if (commentedtext.Contains(R.InnerText))
                                        {
                                            if (R.PreviousSibling().PreviousSibling() != null && R.PreviousSibling().PreviousSibling().LocalName == "r")
                                            {
                                                dummytext += "<bookmarkStart DummyText>" + R.InnerText + "<bookmarkStart DummyText>";

                                                goto nextrun;
                                            }
                                            else if (R.NextSibling().NextSibling() != null && R.NextSibling().NextSibling().NextSibling() != null && R.NextSibling().NextSibling().NextSibling().LocalName == "r")
                                            {
                                                dummytext += "<bookmarkStart DummyText>" + R.InnerText + "<bookmarkStart DummyText>";
                                            }
                                            else if (commentedtext.Contains(R.InnerText)) //Developer Name:Priyanka Vishwakarma, Date:15-04-2021, Requirement:Add condition for handling comment add to two paras in word.
                                            {
                                                dummytext += "<bookmarkStart DummyText>" + R.InnerText + "<bookmarkStart DummyText>";
                                            }

                                        }
                                        else
                                        {
                                            dummytext += R.InnerText;
                                        }
                                    nextrun:
                                        {

                                        }
                                    }
                                }
                            }
                            else
                            {
                                foreach (Text T in P.Descendants<Text>().ToList())
                                {
                                    dummytext += T.Text;
                                }
                            }

                            commentexist = false;

                            foreach (var item in P.Descendants<Run>().ToList())
                            {
                                ////only Run remove in Para
                                item.Remove();
                            }

                            ////get para elements use for commented text
                            var PElements = P.Elements();

                            string emailtxt = "";
                            string withoutemail = "";
                            if (GlobalMethods.strClientName.ToLower() == "sage")
                            {
                                if (dummytext.ToLower().Contains("email") || dummytext.ToLower().Contains("@"))
                                {
                                    if (dummytext.Length > 50)
                                    {
                                        emailtxt = After(dummytext, "(");
                                        withoutemail = Before(dummytext, emailtxt);
                                    }
                                    else
                                    {
                                        emailtxt = dummytext;
                                        withoutemail = "";
                                    }
                                }
                                else
                                {
                                    withoutemail = dummytext.Trim().TrimEnd('.');
                                }

                            }
                            else
                            {
                                if(!string.IsNullOrEmpty(dummytext))
                                emailtxt = After(dummytext, "(");

                                if (!string.IsNullOrEmpty(dummytext) && !string.IsNullOrEmpty(emailtxt))
                                {
                                    withoutemail = Before(dummytext, emailtxt);
                                }
                                else
                                {
                                    withoutemail = dummytext; 
                                }

                                //Developer Name:Priyanka Vishwakarma,Date:19-03-2021,Requirement:Add condition for handling corr
                                if (string.IsNullOrEmpty(dummytext) && string.IsNullOrEmpty(emailtxt))
                                {
                                    if (commentedtext.Count() == 1)
                                    {

                                        Run newrunadd = new Run();
                                        Text newtxtadd = new Text(commentedtext[0]);
                                        newrunadd.Append(newtxtadd);
                                        P.Append(newrunadd);
                                        foreach (OpenXmlElement item in PElements.ToList())
                                        {
                                            if (item.XName == W.commentRangeStart)
                                            {
                                                newrunadd.InsertBeforeSelf(item.CloneNode(true));
                                                item.Remove();
                                            }
                                            else if (item.XName == W.commentRangeEnd)
                                            {
                                                newrunadd.InsertAfterSelf(item.CloneNode(true));
                                                item.Remove();
                                            }
                                            else if (item.XName == W.bookmarkStart)
                                            {
                                                OpenXmlElement last = P.LastChild;
                                                last.InsertAfterSelf(item.CloneNode(true));
                                                item.Remove();

                                            }
                                        }


                                    }
                                    goto NextFun;
                                }
                            }
                                //end on 19-03-2021


                            if (!withoutemail.ToLower().Replace(" ", "").Replace("<bookmarkstartdummytext>", "").Contains("addressforcorrespondence:"))  //Developer name:priyanka Vishwakarma ,Date:14_09_2019 ,Requirement:Add : when Address for corresponce comes without colon(:)  ,Integrated By:Vikas sir.
                            {

                                withoutemail = withoutemail.Replace("Address for correspondence", "Address for correspondence:");

                            }
                            string[] separators = { ":", "," }; //-----Added by priyanka on 25_2_2019 for comment oxy-commentStart and Oxy-CommentEnd comes without text in document
                            string[] links = withoutemail.Replace("  ", " ").Trim().TrimEnd('.').Split(separators, StringSplitOptions.RemoveEmptyEntries);


                            //for (int i = 0; i < links.Count(); i++)
                            //{
                            //    if (links[i].Contains("<bookmarkStart DummyText>"))
                            //    {
                            //        links[i] += ">";
                            //    }
                            //}
                            for (int i = 0; i < links.Count(); i++)
                            {
                                commentexist = false;

                                string finddegree = null;
                                string findinstitution = null;
                                string findcity = null;
                                string findstates = null;
                                string findpincode = null;
                                string findcountry = null;
                                string findaddressline = null;

                                if (links[i].Contains("<bookmarkStart DummyText>"))
                                {
                                    commentexist = true;
                                }

                                ///find the value
                                for (int degree = 0; degree < strDegreesColl.Count; degree++)
                                {
                                    if (links[i].Replace("<bookmarkStart DummyText>", "").ToLower().Trim().Equals(strDegreesColl[degree].ToLower().Trim()))
                                    {
                                        finddegree = links[i];
                                        goto match;
                                    }
                                }

                                for (int instituion = 0; instituion < strInstitutionColl.Count; instituion++)
                                {
                                    if (links[i].Replace("<bookmarkStart DummyText>", "").ToLower().Trim().Contains(strInstitutionColl[instituion].ToLower().Trim()))
                                    {
                                        findinstitution = links[i];
                                        goto match;
                                    }
                                }
                                for (int country = 0; country < strCountrysColl.Count; country++)
                                {
                                    if (links[i].Replace("<bookmarkStart DummyText>", "").ToLower().Trim().Equals(strCountrysColl[country].ToLower().Trim()))
                                    {
                                        findcountry = links[i];
                                        goto match;
                                    }
                                }
                                for (int addresline = 0; addresline < strAddressLineColl.Count; addresline++)
                                {
                                    if (links[i].Replace("<bookmarkStart DummyText>", "").ToLower().Trim().Contains(strAddressLineColl[addresline].ToLower().Trim()))
                                    {
                                        findaddressline = links[i];
                                        goto match;
                                    }
                                }

                                for (int city = 0; city < strCitysColl.Count; city++)
                                {
                                    if (links[i].Replace("<bookmarkStart DummyText>", "").ToLower().Trim().Equals(strCitysColl[city].ToLower().Trim()))
                                    {
                                        findcity = links[i];
                                        goto match;
                                    }
                                    if (commentexist)
                                    {
                                        string a = links[i];
                                        if (links[i].Trim().Replace("<bookmarkStart DummyText>", "").Contains(strCitysColl[city].Trim()))
                                        {
                                            links[i] = a;
                                            findcity = links[i];
                                            goto match;
                                        }
                                    }
                                }

                                for (int states = 0; states < strStatesColl.Count; states++)
                                {
                                    if (links[i].Replace("<bookmarkStart DummyText>", "").ToLower().Trim().Equals(strStatesColl[states].ToLower().Trim()))
                                    {
                                        findstates = links[i];
                                        goto match;
                                    }
                                }

                                for (int pincode = 0; pincode < strPindcodesColl.Count; pincode++)
                                {
                                    if (links[i].Replace("<bookmarkStart DummyText>", "").ToLower().Trim().Equals(strPindcodesColl[pincode].ToLower().Trim()))
                                    {
                                        findpincode = links[i];
                                        goto match;
                                    }
                                }


                            match:
                                {

                                }

                                if (links[i].ToLower() == "address for correspondence" || links[i].ToLower() == "correspondance address" || links[i].ToLower() == "Authors:" || links[i].ToLower() == "correspond author" || links[i].ToLower() == "corresponding author" || links[i].ToLower() == "home address" || links[i].ToLower() == "author" || links[i].ToLower() == "*correspondence to" || links[i].ToLower() == "*corresponding author" || links[i].ToLower() == "address" || (links[i].Replace("<bookmarkStart DummyText>", "").ToLower() == "address for correspondence" && commentexist == true)) //Developer name:Priyanka Vishwakarma ,Date:14-08-2020,Requirement:Apply corrtitle char style for ufl client. //21-09-2020  //16-10-2020
                                {
                                    if (commentexist)
                                    {
                                        // <bookmarkStart DummyText> Address <bookmarkStart DummyText> for correspondence
                                        string[] separator = { "<bookmarkStart DummyText>" };
                                        string[] link = links[i].Split(separator, StringSplitOptions.RemoveEmptyEntries);

                                        for (int j = 0; j < link.Count(); j++)
                                        {
                                            Run newrunadd = new Run();

                                            if (commentedtext.Contains(link[j]))
                                            {
                                                newrunadd.RunProperties = new RunProperties(new RunStyle { Val = "corrTitle" });
                                                Text newtxtadd = new Text(link[j]);
                                                newrunadd.Append(newtxtadd);
                                                P.Append(newrunadd);
                                                foreach (OpenXmlElement item in PElements.ToList())
                                                {
                                                    if (item.XName == W.commentRangeStart)
                                                    {
                                                        newrunadd.InsertBeforeSelf(item.CloneNode(true));
                                                        item.Remove();
                                                    }
                                                    else if (item.XName == W.commentRangeEnd)
                                                    {
                                                        newrunadd.InsertAfterSelf(item.CloneNode(true));
                                                        item.Remove();
                                                    }
                                                    else if (item.XName == W.bookmarkStart)
                                                    {
                                                        OpenXmlElement last = P.LastChild;
                                                        last.InsertAfterSelf(item.CloneNode(true));
                                                        item.Remove();
                                                        goto next;
                                                    }
                                                }
                                            next: { }
                                            }
                                            else
                                            {
                                                newrunadd.RunProperties = new RunProperties(new RunStyle { Val = "corrTitle" });
                                                Text newtxtadd = new Text(link[j]);
                                                newrunadd.Append(newtxtadd);
                                                P.Append(newrunadd);
                                            }

                                            if (j == link.Length - 1)
                                            {
                                                //for ":"
                                                Run newruncolon = new Run();
                                                Text colontxtadd = new Text(":");
                                                newruncolon.Append(colontxtadd);
                                                P.Append(newruncolon.CloneNode(true));
                                            }
                                        }
                                    }
                                    else
                                    {
                                        Run newrunadd = new Run();
                                        newrunadd.RunProperties = new RunProperties(new RunStyle { Val = "corrTitle" });
                                        Text newtxtadd = new Text(links[i]);
                                        newrunadd.Append(newtxtadd);
                                        P.Append(newrunadd);

                                        //for ":"
                                        Run newruncolon = new Run();
                                        Text colontxtadd = new Text(":");
                                        newruncolon.Append(colontxtadd);
                                        newrunadd.InsertAfterSelf(newruncolon);
                                    }

                                    IscorrTitle = true;
                                    previousstyle = "corrTitle";
                                }
                                else if (links[i] != null && links[i] != "" && IscorrTitle == true)
                                {
                                    if (commentexist)
                                    {
                                        // <bookmarkStart DummyText> Address <bookmarkStart DummyText> for correspondence
                                        string[] separator = { "<bookmarkStart DummyText>" };
                                        string[] link = links[i].Split(separator, StringSplitOptions.RemoveEmptyEntries);

                                        for (int j = 0; j < link.Count(); j++)
                                        {
                                            Run newrunadd = new Run();

                                            if (commentedtext.Contains(link[j]))
                                            {
                                                newrunadd.RunProperties = new RunProperties(new RunStyle { Val = "corrFullname" });
                                                Text newtxtadd = new Text(link[j]);
                                                newrunadd.Append(newtxtadd);
                                                P.Append(newrunadd);
                                                foreach (OpenXmlElement item in PElements.ToList())
                                                {
                                                    if (item.XName == W.commentRangeStart)
                                                    {
                                                        newrunadd.InsertBeforeSelf(item.CloneNode(true));
                                                        item.Remove();
                                                    }
                                                    else if (item.XName == W.commentRangeEnd)
                                                    {
                                                        newrunadd.InsertAfterSelf(item.CloneNode(true));
                                                        item.Remove();
                                                    }
                                                    else if (item.XName == W.bookmarkStart)
                                                    {
                                                        OpenXmlElement last = P.LastChild;
                                                        last.InsertAfterSelf(item.CloneNode(true));
                                                        item.Remove();
                                                        goto next;
                                                    }
                                                }
                                            next: { }
                                            }
                                            else
                                            {
                                                newrunadd.RunProperties = new RunProperties(new RunStyle { Val = "corrFullname" });
                                                Text newtxtadd = new Text(link[j]);
                                                newrunadd.Append(newtxtadd);
                                                P.Append(newrunadd);
                                            }
                                        }
                                        //Developer name:Priyanka Vishwakarma .Date:06_11_2019 ,Requirement:Add comma after comment in CORR paragraph style. Integrated By:Vikas sir.
                                        Run newruncolon = new Run();
                                        Text colontxtadd = new Text(",");
                                        newruncolon.Append(colontxtadd);
                                        P.Append(newruncolon);
                                        //-------------------------END---------------------------------------------------
                                    }
                                    else
                                    {

                                        Run newrunadd = new Run();
                                        newrunadd.RunProperties = new RunProperties(new RunStyle { Val = "corrFullname" });
                                        Text newtxtadd = new Text(links[i]);
                                        newrunadd.Append(newtxtadd);
                                        P.Append(newrunadd);

                                        //for ","
                                        Run newruncolon = new Run();
                                        newruncolon.RunProperties = new RunProperties(new RunStyle { Val = "corrFullname" });
                                        Text colontxtadd = new Text(",");
                                        newruncolon.Append(colontxtadd);
                                        newrunadd.InsertAfterSelf(newruncolon);
                                    }
                                    IscorrTitle = false;
                                    previousstyle = "corrFullname";
                                }
                                else if (links[i] != null && links[i] != "" && IscorrTitle == false && finddegree != null)
                                {
                                    if (commentexist)
                                    {
                                        // <bookmarkStart DummyText> Address <bookmarkStart DummyText> for correspondence
                                        string[] separator = { "<bookmarkStart DummyText>" };
                                        string[] link = links[i].Split(separator, StringSplitOptions.RemoveEmptyEntries);

                                        for (int j = 0; j < link.Count(); j++)
                                        {
                                            Run newrunadd = new Run();

                                            if (commentedtext.Contains(link[j]))
                                            {
                                                newrunadd.RunProperties = new RunProperties(new RunStyle { Val = "corrFullname" });
                                                Text newtxtadd = new Text(link[j]);
                                                newrunadd.Append(newtxtadd);
                                                P.Append(newrunadd);
                                                foreach (OpenXmlElement item in PElements.ToList())
                                                {
                                                    if (item.XName == W.commentRangeStart)
                                                    {
                                                        newrunadd.InsertBeforeSelf(item.CloneNode(true));
                                                        item.Remove();
                                                    }
                                                    else if (item.XName == W.commentRangeEnd)
                                                    {
                                                        newrunadd.InsertAfterSelf(item.CloneNode(true));
                                                        item.Remove();
                                                    }
                                                    else if (item.XName == W.bookmarkStart)
                                                    {
                                                        OpenXmlElement last = P.LastChild;
                                                        last.InsertAfterSelf(item.CloneNode(true));
                                                        item.Remove();
                                                        goto next;
                                                    }
                                                }
                                            next: { }
                                            }
                                            else
                                            {
                                                newrunadd.RunProperties = new RunProperties(new RunStyle { Val = "corrFullname" });
                                                Text newtxtadd = new Text(link[j]);
                                                newrunadd.Append(newtxtadd);
                                                P.Append(newrunadd);
                                            }
                                        }
                                        //Developer name:Priyanka Vishwakarma .Date:06_11_2019 ,Requirement:Add comma after comment in CORR paragraph style. Integrated By:Vikas sir.
                                        Run newruncolon = new Run();
                                        Text colontxtadd = new Text(",");
                                        newruncolon.Append(colontxtadd);
                                        P.Append(newruncolon);
                                        //-------------------------END---------------------------------------------------
                                    }
                                    else
                                    {

                                        Run newrunadd = new Run();
                                        newrunadd.RunProperties = new RunProperties(new RunStyle { Val = "corrFullname" });
                                        Text newtxtadd = new Text(links[i]);
                                        newrunadd.Append(newtxtadd);
                                        P.Append(newrunadd);

                                        //for ","
                                        Run newruncolon = new Run();
                                        newruncolon.RunProperties = new RunProperties(new RunStyle { Val = "corrFullname" });
                                        Text colontxtadd = new Text(",");
                                        newruncolon.Append(colontxtadd);
                                        newrunadd.InsertAfterSelf(newruncolon);
                                    }
                                    previousstyle = "corrFullname";
                                    goto nextsplitstring;

                                }
                                else if (links[i] != null && links[i] != "" && IscorrTitle == false && findinstitution != null)
                                {
                                    if (commentexist)
                                    {
                                        // <bookmarkStart DummyText> Address <bookmarkStart DummyText> for correspondence
                                        string[] separator = { "<bookmarkStart DummyText>" };
                                        string[] link = links[i].Split(separator, StringSplitOptions.RemoveEmptyEntries);

                                        for (int j = 0; j < link.Count(); j++)
                                        {
                                            Run newrunadd = new Run();

                                            if (commentedtext.Contains(link[j]))
                                            {
                                                newrunadd.RunProperties = new RunProperties(new RunStyle { Val = "corrInstitution" });
                                                Text newtxtadd = new Text(link[j]);
                                                newrunadd.Append(newtxtadd);
                                                P.Append(newrunadd);
                                                foreach (OpenXmlElement item in PElements.ToList())
                                                {
                                                    if (item.XName == W.commentRangeStart)
                                                    {
                                                        newrunadd.InsertBeforeSelf(item.CloneNode(true));
                                                        item.Remove();
                                                    }
                                                    else if (item.XName == W.commentRangeEnd)
                                                    {
                                                        newrunadd.InsertAfterSelf(item.CloneNode(true));
                                                        item.Remove();
                                                    }
                                                    else if (item.XName == W.bookmarkStart)
                                                    {
                                                        OpenXmlElement last = P.LastChild;
                                                        last.InsertAfterSelf(item.CloneNode(true));
                                                        item.Remove();
                                                        goto next;
                                                    }
                                                }
                                            next: { }
                                            }
                                            else
                                            {
                                                newrunadd.RunProperties = new RunProperties(new RunStyle { Val = "corrInstitution" });
                                                Text newtxtadd = new Text(link[j]);
                                                newrunadd.Append(newtxtadd);
                                                P.Append(newrunadd);
                                            }
                                        }

                                        //Developer name:Priyanka Vishwakarma .Date:06_11_2019 ,Requirement:Add comma after comment in CORR paragraph style. Integrated By:Vikas sir.
                                        Run newruncolon = new Run();
                                        Text colontxtadd = new Text(",");
                                        newruncolon.Append(colontxtadd);
                                        P.Append(newruncolon);
                                        //-------------------------END---------------------------------------------------
                                    }
                                    else
                                    {

                                        Run newrunadd = new Run();
                                        newrunadd.RunProperties = new RunProperties(new RunStyle { Val = "corrInstitution" });
                                        Text newtxtadd = new Text(links[i]);
                                        newrunadd.Append(newtxtadd);
                                        P.Append(newrunadd);

                                        //for ","
                                        Run newruncolon = new Run();
                                        newrunadd.RunProperties = new RunProperties(new RunStyle { Val = "corrInstitution" });
                                        Text colontxtadd = new Text(",");
                                        newruncolon.Append(colontxtadd);
                                        newrunadd.InsertAfterSelf(newruncolon);
                                    }
                                    previousstyle = "corrInstitution";
                                    goto nextsplitstring;
                                }
                                else if (links[i] != null && links[i] != "" && (IscorrTitle == false && findcity != null || findstates != null || findpincode != null || findaddressline != null))
                                {
                                    if (commentexist)
                                    {
                                        // <bookmarkStart DummyText> Address <bookmarkStart DummyText> for correspondence
                                        string[] separator = { "<bookmarkStart DummyText>" };
                                        string[] link = links[i].Split(separator, StringSplitOptions.RemoveEmptyEntries);

                                        for (int j = 0; j < link.Count(); j++)
                                        {
                                            Run newrunadd = new Run();

                                            if (commentedtext.Contains(link[j]))
                                            {
                                                newrunadd.RunProperties = new RunProperties(new RunStyle { Val = "corrAddrLine" });
                                                Text newtxtadd = new Text(link[j]);
                                                newrunadd.Append(newtxtadd);
                                                P.Append(newrunadd);
                                                foreach (OpenXmlElement item in PElements.ToList())
                                                {
                                                    if (item.XName == W.commentRangeStart)
                                                    {
                                                        newrunadd.InsertBeforeSelf(item.CloneNode(true));
                                                        item.Remove();
                                                    }
                                                    else if (item.XName == W.commentRangeEnd)
                                                    {
                                                        newrunadd.InsertAfterSelf(item.CloneNode(true));
                                                        item.Remove();
                                                    }
                                                    else if (item.XName == W.bookmarkStart)
                                                    {
                                                        OpenXmlElement last = P.LastChild;
                                                        last.InsertAfterSelf(item.CloneNode(true));
                                                        item.Remove();
                                                        goto next;
                                                    }
                                                }
                                            next: { }
                                            }
                                            else
                                            {
                                                newrunadd.RunProperties = new RunProperties(new RunStyle { Val = "corrAddrLine" });
                                                Text newtxtadd = new Text(link[j]);
                                                newrunadd.Append(newtxtadd);
                                                P.Append(newrunadd);
                                            }
                                        }
                                        //Developer name:Priyanka Vishwakarma .Date:06_11_2019 ,Requirement:Add comma after comment in CORR paragraph style. Integrated By:Vikas sir.
                                        Run newruncolon = new Run();
                                        Text colontxtadd = new Text(",");
                                        newruncolon.Append(colontxtadd);
                                        P.Append(newruncolon);
                                        //-------------------------END---------------------------------------------------
                                    }
                                    else
                                    {

                                        Run newrunadd = new Run();
                                        newrunadd.RunProperties = new RunProperties(new RunStyle { Val = "corrAddrLine" });
                                        Text newtxtadd = new Text(links[i]);
                                        newrunadd.Append(newtxtadd);
                                        P.Append(newrunadd);

                                        //for ","
                                        Run newruncolon = new Run();
                                        newrunadd.RunProperties = new RunProperties(new RunStyle { Val = "corrAddrLine" });
                                        Text colontxtadd = new Text(",");
                                        newruncolon.Append(colontxtadd);
                                        newrunadd.InsertAfterSelf(newruncolon);
                                    }
                                    previousstyle = "corrAddrLine";
                                    goto nextsplitstring;
                                }
                                else if (links[i] != null && links[i] != "" && IscorrTitle == false && findcountry != null)
                                {
                                    if (commentexist)
                                    {
                                        // <bookmarkStart DummyText> Address <bookmarkStart DummyText> for correspondence
                                        string[] separator = { "<bookmarkStart DummyText>" };
                                        string[] link = links[i].Split(separator, StringSplitOptions.RemoveEmptyEntries);

                                        for (int j = 0; j < link.Count(); j++)
                                        {
                                            Run newrunadd = new Run();

                                            if (commentedtext.Contains(link[j]))
                                            {
                                                newrunadd.RunProperties = new RunProperties(new RunStyle { Val = "corrCountry" });
                                                Text newtxtadd = new Text(link[j]);
                                                newrunadd.Append(newtxtadd);
                                                P.Append(newrunadd);
                                                foreach (OpenXmlElement item in PElements.ToList())
                                                {
                                                    if (item.XName == W.commentRangeStart)
                                                    {
                                                        newrunadd.InsertBeforeSelf(item.CloneNode(true));
                                                        item.Remove();
                                                    }
                                                    else if (item.XName == W.commentRangeEnd)
                                                    {
                                                        newrunadd.InsertAfterSelf(item.CloneNode(true));
                                                        item.Remove();
                                                    }
                                                    else if (item.XName == W.bookmarkStart)
                                                    {
                                                        OpenXmlElement last = P.LastChild;
                                                        last.InsertAfterSelf(item.CloneNode(true));
                                                        item.Remove();
                                                        goto next;
                                                    }
                                                }
                                            next: { }
                                            }
                                            else
                                            {
                                                newrunadd.RunProperties = new RunProperties(new RunStyle { Val = "corrCountry" });
                                                Text newtxtadd = new Text(link[j]);
                                                newrunadd.Append(newtxtadd);
                                                P.Append(newrunadd);
                                            }
                                        }
                                    }
                                    else
                                    {

                                        Run newrunadd = new Run();
                                        newrunadd.RunProperties = new RunProperties(new RunStyle { Val = "corrCountry" });
                                        Text newtxtadd = new Text(links[i]);
                                        newrunadd.Append(newtxtadd);
                                        P.Append(newrunadd);
                                    }
                                    previousstyle = "corrCountry";
                                    goto nextsplitstring;
                                }
                                else
                                {
                                    if (commentexist)
                                    {
                                        // <bookmarkStart DummyText> Address <bookmarkStart DummyText> for correspondence
                                        string[] separator = { "<bookmarkStart DummyText>" };
                                        string[] link = links[i].Split(separator, StringSplitOptions.RemoveEmptyEntries);

                                        for (int j = 0; j < link.Count(); j++)
                                        {
                                            Run newrunadd = new Run();

                                            if (commentedtext.Contains(link[j]))
                                            {
                                                newrunadd.RunProperties = new RunProperties(new RunStyle { Val = previousstyle });
                                                Text newtxtadd = new Text(link[j]);
                                                newrunadd.Append(newtxtadd);
                                                P.Append(newrunadd);
                                                foreach (OpenXmlElement item in PElements.ToList())
                                                {
                                                    if (item.XName == W.commentRangeStart)
                                                    {
                                                        newrunadd.InsertBeforeSelf(item.CloneNode(true));
                                                        item.Remove();
                                                    }
                                                    else if (item.XName == W.commentRangeEnd)
                                                    {
                                                        newrunadd.InsertAfterSelf(item.CloneNode(true));
                                                        item.Remove();
                                                    }
                                                    else if (item.XName == W.bookmarkStart)
                                                    {
                                                        OpenXmlElement last = P.LastChild;
                                                        last.InsertAfterSelf(item.CloneNode(true));
                                                        item.Remove();
                                                        goto next;
                                                    }
                                                }
                                            next: { }
                                            }
                                            else
                                            {
                                                newrunadd.RunProperties = new RunProperties(new RunStyle { Val = previousstyle });
                                                Text newtxtadd = new Text(link[j]);
                                                newrunadd.Append(newtxtadd);
                                                P.Append(newrunadd);
                                            }
                                        }
                                    }
                                    else
                                    {
                                        ////new logic added by Karan on 28-09-2018 for country and city start for below pattern 
                                        ////Address for correspondence: Amarja Nagre, DM, FCA, FICCC, C - 3, Department of Cardiac Anaesthesia, MGM Medical College and MCRI, Row House, Muthiyan Residency, Deepnagar, Aurangabad, Maharashtra, India 431001(e - mail: dramarja.1@gmail.com).
                                        for (int country = 0; country < strCountrysColl.Count; country++)
                                        {
                                            if (links[i].Trim().Contains(strCountrysColl[country].Trim()))
                                            {
                                                string countryname = strCountrysColl[country];

                                                string getpinno = links[i].Replace(countryname, "");

                                                if (getpinno != null && getpinno.Trim()!="." && getpinno.Trim()!=",") //07-05-2021
                                                {
                                                    try
                                                    {
                                                        int result = 0;

                                                        bool pin = int.TryParse(getpinno, out result);

                                                        if (pin)
                                                        {
                                                            if (links[i].Trim().StartsWith(countryname))
                                                            {
                                                                Run Rcountry = new Run();
                                                                Rcountry.RunProperties = new RunProperties(new RunStyle { Val = "corrCountry" });
                                                                Text RText = new Text(countryname);
                                                                Rcountry.Append(RText);

                                                                Run Rpin = new Run();
                                                                Rpin.RunProperties = new RunProperties(new RunStyle { Val = "corrAddrLine" });
                                                                Text PText = new Text(getpinno);
                                                                Rpin.Append(PText);

                                                                P.Append(Rpin);
                                                                Rpin.InsertBeforeSelf(Rcountry.CloneNode(true));

                                                                goto nextsplitstring;
                                                            }
                                                            else if (links[i].Trim().StartsWith(getpinno))
                                                            {
                                                                Run Rpin = new Run();
                                                                Rpin.RunProperties = new RunProperties(new RunStyle { Val = "corrAddrLine" });
                                                                Text PText = new Text(getpinno);
                                                                Rpin.Append(PText);

                                                                Run Rcountry = new Run();
                                                                Rcountry.RunProperties = new RunProperties(new RunStyle { Val = "corrCountry" });
                                                                Text RText = new Text(countryname);
                                                                Rcountry.Append(RText);

                                                                P.Append(Rcountry);
                                                                Rcountry.InsertBeforeSelf(Rpin.CloneNode(true));

                                                                goto nextsplitstring;
                                                            }
                                                        }
                                                        else
                                                        {
                                                            break;
                                                        }

                                                    }
                                                    catch (Exception e)
                                                    {

                                                    }

                                                }
                                            }
                                        }
                                        ////new logic added by Karan on 28-09-2018 for country and city End

                                        Run newrunadd = new Run();
                                        newrunadd.RunProperties = new RunProperties(new RunStyle { Val = previousstyle });
                                        Text newtxtadd = new Text(links[i]);
                                        newrunadd.Append(newtxtadd);
                                        P.Append(newrunadd);

                                        //for ","
                                        Run newruncolon = new Run();
                                        newrunadd.RunProperties = new RunProperties(new RunStyle { Val = previousstyle });
                                        if (links.Count() == i + 1)  //Developer Name:Priynka Vishwakarma,Requirement:Add condition for avoid to add at the last of run text in address.
                                        {
                                            Text colontxtadd = new Text(".");
                                            newruncolon.Append(colontxtadd);
                                        }
                                        else
                                        {
                                            Text colontxtadd = new Text(",");
                                            newruncolon.Append(colontxtadd);
                                        }
                                        newrunadd.InsertAfterSelf(newruncolon);
                                    }
                                }
                            nextsplitstring:
                                {

                                }
                            }
                            if (emailtxt != null)
                            {
                                if (emailtxt.Contains("<bookmarkStart DummyText>"))
                                {
                                    commentexist = true;
                                }

                                if (commentexist)
                                {
                                    // <bookmarkStart DummyText> Address <bookmarkStart DummyText> for correspondence
                                    string[] separator = { "<bookmarkStart DummyText>" };
                                    string[] link = emailtxt.Split(separator, StringSplitOptions.RemoveEmptyEntries);

                                    for (int j = 0; j < link.Count(); j++)
                                    {
                                        Run newrunadd = new Run();

                                        if (commentedtext.Contains(link[j]))
                                        {
                                            Text newtxtadd = new Text(link[j]);
                                            newrunadd.Append(newtxtadd);
                                            P.Append(newrunadd);
                                            foreach (OpenXmlElement item in PElements.ToList())
                                            {
                                                if (item.XName == W.commentRangeStart)
                                                {
                                                    newrunadd.InsertBeforeSelf(item.CloneNode(true));
                                                    item.Remove();
                                                }
                                                else if (item.XName == W.commentRangeEnd)
                                                {
                                                    newrunadd.InsertAfterSelf(item.CloneNode(true));
                                                    item.Remove();
                                                }
                                                else if (item.XName == W.bookmarkStart)
                                                {
                                                    OpenXmlElement last = P.LastChild;
                                                    last.InsertAfterSelf(item.CloneNode(true));
                                                    item.Remove();
                                                    goto next;
                                                }
                                            }
                                        next: { }
                                        }
                                        else
                                        {
                                            Text newtxtadd = new Text(link[j]);
                                            newrunadd.Append(newtxtadd);
                                            P.Append(newrunadd);
                                        }
                                    }
                                }
                                else
                                {
                                    Run newrunadd = new Run();
                                    Text newtxtadd = new Text(emailtxt);
                                    newrunadd.Append(newtxtadd);
                                    P.Append(newrunadd);
                                }
                            }
                            //P.InsertAfterSelf(pp);
                            //P.Remove();
                        }
                    Next:
                        { }
                    }
                }
                NextFun: { }
                D.Save();
            }
            ///logic end

        }

        public static void CheckCorrPara(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument.Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(x => x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val != null && x.ParagraphProperties.ParagraphStyleId.Val.Value == "CORR").ToList())
                {
                    if(P.InnerText.EndsWith(","))
                    {

                        var lastrun = P.Descendants<Run>().ToList().Where(x => x.InnerText.Trim() == ",").LastOrDefault();
                        if(lastrun.InnerText.Trim()==",")
                        {
                            lastrun.Remove();
                        }
                        
                    }


                }
                D.Save();
            }
        }

        public static string Before(string value, string a)
        {
            if(a.Trim()=="" && GlobalMethods.strClientName.ToLower()=="ufl")   //Developer Name:Priyanka Vishwakarma,Date:15-08-2020,Requirement:Email text comes into another para in ufl input
            {
                return value;
            }
            int posA = value.LastIndexOf(a);
            if (posA == -1)
            {
                return "";
            }
           
            return value.Substring(0, posA);
        }

        public static string After(string value, string a)
        {
            int posA = value.LastIndexOf(a);
            if (posA == -1)
            {
                return "";
            }
            int adjustedPosA = posA - a.Length;
            if (adjustedPosA >= value.Length)
            {
                return "";
            }
            string checkSpace = value[adjustedPosA].ToString();   //Developer name:Priyanka Vishwakarma ,Date:28-01-2020 ,Requiement:When space not added before email in word document . Integrated by:Vikas sir. 
            if (checkSpace.Trim() == "")
            {
                return value.Substring(adjustedPosA);
            }
            else
            {
                return value.Substring(adjustedPosA + 1);
            }
            //return value.Substring(adjustedPosA);
        }
        public static void checkAllCorrCharrStyleInSequence(string newDoc)
        {
            bool boolCorrInstitutionStart = false;
            using (WordprocessingDocument WPD = WordprocessingDocument.Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(x => x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val != null && x.ParagraphProperties.ParagraphStyleId.Val.Value == "CORR").ToList())
                {
                    var runElements = P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val != null && x.RunProperties.RunStyle.Val.Value != "").ToList();
                    foreach (var r in runElements.ToList())
                    {
                        if (r.RunProperties.RunStyle.Val.Value == "corrAddrLine")
                        {
                            if (boolCorrInstitutionStart)
                            {
                                r.RunProperties.RunStyle.Val.Value = "corrAddrLine";
                            }
                            else
                            {
                                r.RunProperties.RunStyle.Val.Value = "corrInstitution";
                            }
                        }
                        if (r.RunProperties.RunStyle.Val.Value == "corrInstitution")
                        {
                            boolCorrInstitutionStart = true;

                        }
                    }

                }

                D.Save();
            }
        }
        public static void CheckCorrParaExtrapunctuation(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(c => c.Parent.LocalName != W.tc && c.ParagraphProperties != null && c.ParagraphProperties.ParagraphStyleId != null && c.ParagraphProperties.ParagraphStyleId.Val != null && c.ParagraphProperties.ParagraphStyleId.Val.Value == "CORR").ToList())
                {
                     //Developer Name:Priyanka Vishwakarma Date:12-12-2020 ,Requirement:Period is required at the end of Corresponding address 
                        if (P.InnerText.Trim() != "" && !P.InnerText.Trim().EndsWith("."))
                        {
                            if (P.InnerText.Trim() != "" && (P.InnerText.Replace(" ", "").Trim().ToLower().Contains("addressforcorrespondence:")
                           || P.InnerText.Replace(" ", "").Trim().ToLower().Contains("correspondenceto:")
                           || P.InnerText.Replace(" ", "").Trim().ToLower().Contains("correspondingauthor:")
                           || P.InnerText.Replace(" ", "").Trim().ToLower().Contains("addressforcorrespondance:")
                           || P.InnerText.Replace(" ", "").Trim().ToLower().Contains("correspondingauthor:")
                           || P.InnerText.Replace(" ", "").Trim().ToLower().Contains("correspondauthor:")))
                            {

                                P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().ForEach(t => t.ToList().ForEach(txt =>
                                {
                                    if (txt == P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().LastOrDefault().LastOrDefault())
                                    {
                                        if (!txt.Text.Trim().EndsWith("."))
                                        {
                                            txt.Text = txt.Text + ".";
                                        }
                                    }
                                })
                       );
                            }
                        }

                        if (P.InnerText.Trim().StartsWith("E-mail:") || P.InnerText.Trim().StartsWith("Email:") || P.InnerText.Contains("@"))////Developer Name:Priyanka Vishwakarma Date:12-12-2020 ,Requirement:Period is not required at the end of Corresponding addressif it start with email 
                        {
                            P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().ForEach(t => t.ToList().ForEach(txt =>
                            {
                                if (txt == P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().LastOrDefault().LastOrDefault())
                                {
                                    if (txt.Text.Trim().EndsWith("."))
                                    {
                                        txt.Text = txt.Text.TrimEnd('.');
                                    }
                                }
                            }));
                        }

                    

                }
                D.Save();
            }
        }


    }
}
