﻿using DocumentFormat.OpenXml.Packaging;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using System.IO.Packaging;
using OpenXmlPowerTools;
using DocumentFormat.OpenXml.Wordprocessing;
using DocumentFormat.OpenXml;
using System.Xml;
using System.Text.RegularExpressions;
using System.IO;
using System.Configuration;

namespace MultiInstanceJournalCleanup
{
    class AbstractProcessing
    {
        public static List<string> AbstractKeywordColl = null;

        public static void BreakAbstractOnKeyword(string strWordDoc)
        {
            GlobalMethods.strAbsractFilePath = ConfigurationManager.AppSettings.Get("AbstractKeyword");

            AbstractKeywordColl = new List<string>();
            AbstractKeywordColl.Clear();

            AbstractKeywordColl = GlobalMethods.ReadAndStoreFileValuesInArray(GlobalMethods.strAbsractFilePath);

            if(AbstractKeywordColl.Count > 0)
            {
                // Check and Split Abstract Para on Keyword //

                ////commented by Karan on 14-06-2018 as per discussion with Abhijeet B.
                //CheckAndSplitAbstractPara(strWordDoc, AbstractKeywordColl);

            }
        }

        private static void CheckAndSplitAbstractPara(string strWordDoc, List<string> AbstractKeywordColl)
        {
            try
            {
                using (WordprocessingDocument WPD = WordprocessingDocument.Open(strWordDoc, true))
                {
                    SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                    {
                        RemoveComments = false,
                        RemoveContentControls = true,
                        RemoveEndAndFootNotes = false,
                        RemoveFieldCodes = true,
                        RemoveLastRenderedPageBreak = true,
                        RemovePermissions = true,
                        RemoveProof = true,
                        RemoveRsidInfo = true,
                        RemoveSmartTags = true,
                        RemoveSoftHyphens = false,
                        ReplaceTabsWithSpaces = false,//Developer name :Priyanka Vishwakarma. Date:29_5_2019, Requirement:it removes the indentation from the nested list  ,Integrated By:Vikas sir. 
                    };

                    MarkupSimplifier.SimplifyMarkup(WPD, settings);

                    MainDocumentPart MDP = WPD.MainDocumentPart;

                    Document D = MDP.Document;

                    bool bBold = true;
                    string strParaText = null;

                    // Search all Paragraphs that has "AB-TXT" style.
                    foreach (Paragraph P in D.Descendants<Paragraph>().ToList().
                    Where(e => e.ParagraphProperties != null
                        && e.ParagraphProperties.ParagraphStyleId != null
                        && e.ParagraphProperties.ParagraphStyleId.Val == "AB-TXT"))
                    {
                        if (P.HasChildren)
                        {
                            if (P.Descendants<Run>().Count() > 0)
                            {
                                foreach (Run R in P.Descendants<Run>().ToList())
                                {
                                    if (R.RunProperties != null)
                                    {
                                        if (R.RunProperties.Bold != null)
                                        {
                                            bBold = true;
                                        }
                                    }

                                    strParaText = null;
                                    foreach (Text T in R.Descendants<Text>().ToList())
                                    {
                                        strParaText += T.Text;
                                    }

                                    if(AbstractKeywordColl.Contains(strParaText))
                                    {
                                        if(bBold == true)
                                        {
                                            // Split the para from here //

                                            Paragraph appendAbsractPara = new Paragraph(new ParagraphProperties(new ParagraphStyleId() { Val = "ABT" }));
                                            Run newrun = new Run(new RunProperties(new Bold()));
                                            newrun.AppendChild(new Text(strParaText) { Space = SpaceProcessingModeValues.Preserve });
                                            appendAbsractPara.AppendChild(newrun);

                                            P.InsertBeforeSelf(appendAbsractPara);

                                            R.Remove();
                                        }
                                    }
                                    else
                                    {
                                        goto NextPara;
                                    }
                                }
                            }
                        }

                        NextPara:
                        { };

                    }

                    D.Save();
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
