﻿using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Wordprocessing;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Office.Interop.Word;

namespace MultiInstanceJournalCleanup
{
    class clsLinking
    {
        public static List<string> lstAllLabelStrong = new List<string>();
        public static void funcLinking(string WordPath)
        {
            WordprocessingDocument docx = WordprocessingDocument.Open(WordPath, true);
            try
            {
                funcRemoveCiteFigStyle(docx);

                //add function by Karan on 28-04-2018
                funcRemoveCiteTblStyle(docx);
                //end function by Karan on 28-04-2018

                funcGetAllLabelStrong(docx);
                //funcApplyBIBAndREFStyle(docx);
                docx.Close();
            }
            catch (Exception)
            {
                if(docx != null)
                    docx.Close();
            }

            try
            {
                ApplyCiteFigStyle(WordPath);       //Added on 30_3_2019 by priyanka for apply cite_fig style .
            }
            catch (Exception ex)
            {

            }
        }

        private static void funcApplyBIBAndREFStyle(WordprocessingDocument docx)
        {
            foreach (var p in docx.MainDocumentPart.Document.Body.Descendants<DocumentFormat.OpenXml.Wordprocessing.Paragraph>().ToList())
            {
                if (p.InnerText != "")
                {
                    if (p.ParagraphProperties != null &&
                        p.ParagraphProperties.ParagraphStyleId != null &&
                        p.ParagraphProperties.ParagraphStyleId.Val != null &&
                        p.ParagraphProperties.ParagraphStyleId.Val.HasValue &&
                        p.ParagraphProperties.ParagraphStyleId.Val.Value.Equals("bib1", StringComparison.CurrentCultureIgnoreCase) ||
                         p.ParagraphProperties.ParagraphStyleId.Val.Value.Equals("ref1", StringComparison.CurrentCultureIgnoreCase))
                    {

                        if (p.PreviousSibling() == null)
                        {
                            goto BIB1Found;
                        }

                        var preElement = p.PreviousSibling();

                        foreach (var para in preElement)
                        {
                            if (para.LocalName.ToLower().Trim() == "ppr")
                            {
                                foreach (ParagraphStyleId pstyle in para.Elements<ParagraphStyleId>().ToList())
                                {
                                    if (pstyle.Val != null && pstyle.Val.HasValue && pstyle.Val.Value.Equals("h1", StringComparison.CurrentCultureIgnoreCase))
                                    {
                                        if (p.ParagraphProperties.ParagraphStyleId.Val.Value.Equals("bib1",StringComparison.CurrentCultureIgnoreCase))
                                        {
                                            pstyle.Val = "BIB";
                                            goto BIB1Found;
                                        }
                                        else if (p.ParagraphProperties.ParagraphStyleId.Val.Value.Equals("ref1", StringComparison.CurrentCultureIgnoreCase))
                                        {
                                            pstyle.Val = "REF";
                                            goto BIB1Found;
                                        }
                                        else
                                        {
                                            goto BIB1Found;
                                        }
                                    }
                                    else
                                    {
                                        goto BIB1Found;
                                    }
                                }
                            }
                            break;
                        }
                    }
                }
            }

            BIB1Found: { }
        }
        private static void funcGetAllLabelStrong(WordprocessingDocument docx)
        {
            var eleLabelStrongTxt = docx.MainDocumentPart.Document.Body.Descendants<Run>().
                Where(r => r.RunProperties != null &&
                      r.RunProperties.RunStyle != null &&
                      r.RunProperties.RunStyle.Val != null &&
                      r.RunProperties.RunStyle.Val == "label-Strong").ToList();

            foreach (var i in eleLabelStrongTxt.ToList())
            {
                lstAllLabelStrong.Add(i.InnerText);
            }
        }

        private static void funcApplyCiteFigStyle(string WordPath)
        {
            if (lstAllLabelStrong.Count() != 0)
            {
                Microsoft.Office.Interop.Word.Document mdoc = null;
                try
                {
                    string strDocContent = null;

                    mdoc = GlobalMethods.LoadWordDocument(WordPath);

                    strDocContent = mdoc.Content.Text;

                    if (strDocContent == null)
                        return;

                    if (mdoc != null)
                    {
                        List<string> strMatchText = new List<string>();
                        string strSearchRegEx = null;

                        for (int i = 0; i < lstAllLabelStrong.Count(); i++)
                        {
                            strSearchRegEx = lstAllLabelStrong[i];
                            strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                            if (strMatchText.Count > 0)
                            {
                                for (int counter = 0; counter < strMatchText.Count; counter++)
                                {
                                    if(strMatchText[counter].ToLower().StartsWith("table") || strMatchText[counter].ToLower().StartsWith("tab"))
                                    {
                                        GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, true, false);
                                    }

                                    if (strMatchText[counter].ToLower().StartsWith("fig"))
                                    {
                                        GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, true, false);
                                    }
                                }
                            }
                        }

                        strSearchRegEx = @"(Figs\. [0-9]+\.[0-9]+[-–—][0-9]+\.[0-9]+)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, true, false);
                            }
                        }


                        strSearchRegEx = @"(Figs\. [0-9]+\.[0-9]+\s+and\s+[0-9]+\.[0-9]+)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, true, false);
                            }
                        }


                        object oMissing = System.Reflection.Missing.Value;
                        object saveChanges = WdSaveOptions.wdSaveChanges;
                        ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                        mdoc = null;
                    }
                }
                catch (Exception ex)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;
                }
                finally
                {
                    if (GlobalMethods.wordApp != null)
                    {
                        object oMissing = System.Reflection.Missing.Value;
                        ((_Application)GlobalMethods.wordApp).Quit(ref oMissing, ref oMissing, ref oMissing);
                        GlobalMethods.wordApp = null;
                    }
                }
            }
        }

        private static void funcRemoveCiteFigStyle(WordprocessingDocument docx)
        {
            
            var eleAllRprOfCiteFig = docx.MainDocumentPart.Document.Body.Descendants<RunStyle>().
                Where(rStyle => rStyle != null && rStyle.Val == "citefig").ToList();

            foreach (var i in eleAllRprOfCiteFig)
            {
                //Developer name:Priyanka Vishwakarma ,Date:27-08-2020 ,Requirement:Add condition for avoid to remove citation style if author query is present.
                if(i.Parent!=null && i.Parent.Parent!=null && 
                  (i.Parent.Parent.PreviousSibling()!=null && i.Parent.Parent.PreviousSibling().LocalName != null && i.Parent.Parent.PreviousSibling().LocalName== "commentRangeStart" 
                  && !i.Parent.Parent.InnerText.ToLower().Trim().StartsWith("fig")))
                {
                    continue;
                }
                else if(i.Parent != null && i.Parent.Parent != null &&
                   (i.Parent.Parent.NextSibling() != null && i.Parent.Parent.NextSibling().LocalName != null && i.Parent.Parent.NextSibling().LocalName == "commentRangeStart"
                   && i.Parent.Parent.InnerText.ToLower().Trim().StartsWith("fig")))
                {
                    continue;
                }
                else
                {
                    i.Remove();

                }
               
            }
        }

        private static void funcRemoveCiteTblStyle(WordprocessingDocument docx)
        {
            var eleAllRprOfCiteTbl = docx.MainDocumentPart.Document.Body.Descendants<RunStyle>().
                Where(rStyle => rStyle != null && rStyle.Val == "citetbl").ToList();

            foreach (var i in eleAllRprOfCiteTbl)
            {
                i.Remove();
            }
        }

        #region for Apply cite_fig and cite_tbl style

        private static void ApplyCiteFigStyle(string WordPath)   //add by priyanka 30_3_2019  
        {
            if (lstAllLabelStrong.Count() != 0)
            {
                Microsoft.Office.Interop.Word.Document mdoc = null;
                try
                {
                    string strDocContent = null;

                    mdoc = GlobalMethods.LoadWordDocument(WordPath);

                    strDocContent = mdoc.Content.Text;

                    if (strDocContent == null)
                        return;

                    if (mdoc != null)
                    {
                        List<string> strMatchText = new List<string>();
                        string strSearchRegEx = null;

                        for (int i = 0; i < lstAllLabelStrong.Count(); i++)
                        {
                            strSearchRegEx = lstAllLabelStrong[i].Trim().TrimEnd('.').TrimEnd(':');
                            strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                            if (strMatchText.Count > 0)
                            {
                                for (int counter = 0; counter < strMatchText.Count; counter++)
                                {
                                   
                                    if (strMatchText[counter].ToLower().StartsWith("table") || strMatchText[counter].ToLower().StartsWith("tab"))
                                    {
                                        GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, true, false);
                                    }

                                    if (strMatchText[counter].ToLower().StartsWith("fig"))
                                    {
                                        GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, true, false);
                                    }

                                }
                            }
                        }
                        //Regex for fig pattern ex. Fig. 3A  
                        //Developer Name:Priyanka Vishwakarma ,Date:3_6_2019, Requiredment:Regex for fig pattern ex. Fig. 3A  ,Intergrated by:Vikas Sir
                        strSearchRegEx = @"(Fig\.+\s+[0-9]+[A-Za-z]+)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, true, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;
                        //----------------------------------end----------------------------------------------

                        strSearchRegEx = @"(Fig\.\s[0-9]+\.[0-9]+)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, true, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        //strSearchRegEx = @"[(]Figs.[\s][0-9][][0-9][)]|[(]Fig.[\s][0-9][)]";
                        strSearchRegEx = @"(Figs.[\s][0-9][.][0-9])|(Fig.[\s][0-9])";    //23_5_2019 Triangle missing along with figure citation (eg. Fig. 1, Fig. 4, etc)
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, true, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Figs\. [0-9]+\.[0-9]+[-–—][0-9]+\.[0-9]+)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, true, false);
                            }
                        }

                        //For Figs.
                        strMatchText.Clear();
                        strSearchRegEx = null;
                        
                        strSearchRegEx = @"(Figs\. [0-9]+\.[0-9]+\s+and\s+[0-9]+\.[0-9]+)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, true, false);
                            }
                        }

                        



                        strMatchText.Clear();
                        strSearchRegEx = null;


                        strSearchRegEx = @"(Figs.\s+([0-9]\–)+([0-9]))";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                            }
                        }

                        strMatchText.Clear();
                        strSearchRegEx = null;


                        strSearchRegEx = @"(Fig\s[0-9]+)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Figs.\s+([0-9]\-)+([0-9]))";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Tables.\s+([0-9]\–)+([0-9]))";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, false, false);
                            }
                        }

                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Figs.\s[0-9]+[\-\–][0-9]+)";   //    03082019 Figs. 14–16
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                            }
                        }

                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Figs\s+([0-9])\s+(and\s)+([0-9]))";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;


                        strSearchRegEx = @"(Fig\.+\s+[0-9]+\.[0-9]+[A-Za-z]+)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;
                        //--------Developer Name:Priyanka Vishwakarma , Date:24_6_2019 , Requirement:Apply citeFig Character style in document ex. Fig. 2A, B, D  , Fig. 6D, E ,Fig. 5A and B , Figs. 2,4,5,6 -----------------------------------------------

                        // strSearchRegEx = @"(Fig\.\s[0-9]+[A-Z\,\s]+)";    //Fig. 2A, B, D  , Fig. 6D, E
                        strSearchRegEx = @"(Fig\.\s[0-9]+)([A-Z]+)([0-9A-Z,\s]+)";    //Fig. 2A, B, D  , Fig. 6D, E
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter].Trim(), "", "", "cite_fig", "", true, false, false, false, false);//developer Name:Priyanka Vishwakarma, Date:09-10-2020,Requirement:Trim end space from selected regex for avoid to apply citefig style to space at end.
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Fig.\s[0-9][A-Za-z]+\sand\s[A-Za-z])";  /// Fig. 5A and B  ,  Fig. 2C and D 
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                            }
                        }

                        // ////Developer Name:Priyanka Vishwakarma , Date:23_7_2019 , Requirement:Regex pattern for figcitation  ,Integrated By:Vikas sir.
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Figs.\s)([0-9A-Za-z]+,\s){1,}(and\s[0-9A-Za-z]+)";  ///  Figs. 1A, 2A, 3A, and 4A     or Figs. 1B, 1C, and 5
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                            }
                        }

                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Figs\.\s[0-9\,\s]+)";  /// Figs. 2,4,5,6
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter].Trim(), "", "", "cite_fig", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;




                        strSearchRegEx = @"(Tables\s+([0-9])\s+(and\s)+([0-9]))";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Figs\s+([0-9])\s+(to\s)+([0-9]))";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Tables\s+([0-9])\s+(to\s)+([0-9]))";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Figs\s+([0-9])\s+(&\s)+([0-9]))";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Tables\s+([0-9])\s+(&\s)+([0-9]))";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, false, false);
                            }
                        }
                        //strMatchText.Clear();
                        //strSearchRegEx = null;

                        //strSearchRegEx = @"(Fig\s+([0-9])\s+(and\s)+Fig\s+([0-9]))";
                        //strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        //if (strMatchText.Count > 0)
                        //{
                        //    for (int counter = 0; counter < strMatchText.Count; counter++)
                        //    {
                        //        GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                        //    }
                        //}


                        //Developer Name:Priyanka Vishwakarma ,Date:21_08_2019, Requiredment:Regex for fig pattern ex.Figures 2 and 3   ,Intergrated by:Vikas Sir
                        //------------------------pattern for Figures 2 and 3   

                        strMatchText.Clear();
                        strSearchRegEx = null;


                        strSearchRegEx = @"([Ff]igures+\s+[0-9]+\sand\s+[0-9]+)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, true, false);
                            }
                        }

                        strMatchText.Clear();
                        strSearchRegEx = null;


                        strSearchRegEx = @"([Ff]igure+\s+[0-9]+\sand\s+[0-9]+)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, true, false);
                            }
                        }

                        strSearchRegEx = @"([Ff]igures+\s+[0-9]+\sto\s+[0-9]+)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, true, false);
                            }
                        }

                        strMatchText.Clear();
                        strSearchRegEx = null;


                        strSearchRegEx = @"([Ff]igure+\s+[0-9]+\sto\s+[0-9]+)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, true, false);
                            }
                        }
                        //-------------------------End-------------------------------------------------------------
                        ////Developer name :Priyanka Vishwakarma .Date:30-7-2019 ,Requirement:Add new Citefig (Figs. 1A, E) and (Figs. 1A, D) 2518_THI_J_EJD-19-00134.docx file ,Integrated By:Vikas sir.

                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Figs.\s{1,}[0-9][A-Za-z]+\–[A-Za-z]+)";  /// Figs. 1A-D  
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Figs.\s{1,}[0-9]+[A-Z-a-z]\,\s[A-Za-z])";  /// Figs. 1A, D  
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                            }
                        }

                        //----------------------------------------------End----------------------------------------------------------------------------					





                        //strMatchText.Clear();
                        //strSearchRegEx = null;

                        //strSearchRegEx = @"(Table\s+([0-9])\s+(and\s)+Table\s+([0-9]))";
                        //strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        //if (strMatchText.Count > 0)
                        //{
                        //    for (int counter = 0; counter < strMatchText.Count; counter++)
                        //    {
                        //        GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, false, false);
                        //    }
                        //}
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Figs\.+\s+[0-9]+\.[0-9]+[A-Za-z]+\,+[0-9]+\.[0-9]+[A-Za-z]+)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Tables\.+\s+[0-9]+\.[0-9]+[A-Za-z]+\,+[0-9]+\.[0-9]+[A-Za-z]+)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Figs\.+\s+[0-9]+\.[0-9]+[A-Za-z]+\-+[0-9]+[A-Za-z]+)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Tables\.+\s+[0-9]+\.[0-9]+[A-Za-z]+\-+[0-9]+[A-Za-z]+)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Figs\.+\s+[0-9]+\.?[0-9]+[A-Za-z]+\,?\s+[0-9]+\.[0-9]+[A-Za-z]+)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Tables\.+\s+[0-9]+\.?[0-9]+[A-Za-z]+\,?\s+[0-9]+\.[0-9]+[A-Za-z]+)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Figs\.+\s+[0-9]+\.[0-9]+\,?\s+[0-9]+\.[0-9]+)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Tables\.+\s+[0-9]+\.[0-9]+\,?\s+[0-9]+\.[0-9]+)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Figs\.+\s+[0-9]+\.?[0-9]+[A-Za-z]+\,?\s+[0-9]+\.[0-9]+[A-Za-z]+\;\s+[A-Za-z]+\.?\s+[0-9]+\.[0-9]+[A-Za-z]+\-+[0-9]+\.[0-9]+[A-Za-z]+)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Tables\.+\s+[0-9]+\.?[0-9]+[A-Za-z]+\,?\s+[0-9]+\.[0-9]+[A-Za-z]+\;\s+[A-Za-z]+\.?\s+[0-9]+\.[0-9]+[A-Za-z]+\-+[0-9]+\.[0-9]+[A-Za-z]+)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Figs\.+\s+[0-9]+\.[0-9]+[A-Za-z]+\-+[0-9]+\.[0-9]+[A-Za-z]+)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Tables\.+\s+[0-9]+\.[0-9]+[A-Za-z]+\-+[0-9]+\.[0-9]+[A-Za-z]+)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Fig\.+\s+[0-9]+\.[0-9]+[A-Za-z]+)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_fig", "", true, false, false, false, false);
                            }
                        }

                        //-------------------Pattern for Supplementary Tables ------------------------------
                        //Developer Name:Priyanka Vishwakarma ,Date:17_08_2019 ,Requirement:Add Supplementary table in xml  ,Integrated by:Vikas Sir
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Supplementary Tables\s)([0-9A-Za-z]+,\s){1,}(and\s[0-9A-Za-z]+)";     //Supplementary Tables S2, S4, S3, and S4      ,  Supplementary Tables S2, S3, and S4
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, false, false);
                            }
                        }



                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Supplementary Table\s)([0-9A-Za-z]+)";     //Supplementary Table S1   
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, false, false);
                            }
                        }

                        //------------------------End-----------------------------------------------------------                       

                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Tables\.+\s+[0-9]+\.[0-9]+[A-Za-z]+)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Table+([0-9]+))";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, false, false);
                            }
                        }
                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strMatchText.Clear();
                        strSearchRegEx = null;

                        strSearchRegEx = @"(Tab [0-9]+\.[0-9]+)";
                        strMatchText = GlobalMethods.DocumentRegEx(strDocContent, strSearchRegEx);

                        if (strMatchText.Count > 0)
                        {
                            for (int counter = 0; counter < strMatchText.Count; counter++)
                            {
                                GlobalMethods.SearchAndReplace(mdoc, strMatchText[counter], "", "", "cite_tbl", "", true, false, false, false, false);
                            }
                        }


                        object oMissing = System.Reflection.Missing.Value;
                        object saveChanges = WdSaveOptions.wdSaveChanges;
                        ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                        mdoc = null;
                    }
                }
                catch (Exception ex)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    object saveChanges = WdSaveOptions.wdSaveChanges;
                    ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                    mdoc = null;
                }
                finally
                {
                    if (GlobalMethods.wordApp != null)
                    {
                        object oMissing = System.Reflection.Missing.Value;
                        ((_Application)GlobalMethods.wordApp).Quit(ref oMissing, ref oMissing, ref oMissing);
                        GlobalMethods.wordApp = null;
                    }
                }
            }
        }

        #endregion
    }
}
