﻿using DocumentFormat.OpenXml.Packaging;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace MultiInstanceJournalCleanup
{
    class PubMed
    {
        public static string ExtractPMID(string URL)
        {
            try
            {
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(URL);
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();

                if (response.StatusCode == HttpStatusCode.OK)
                {
                    Stream receiveStream = response.GetResponseStream();
                    StreamReader readStream = null;

                    if (response.CharacterSet == null)
                        readStream = new StreamReader(receiveStream);
                    else
                        readStream = new StreamReader(receiveStream, Encoding.GetEncoding(response.CharacterSet));

                    string data = readStream.ReadToEnd();

                    response.Close();
                    readStream.Close();

                    if (data != null)
                    {
                        XmlDocument xd = new XmlDocument();
                        xd.LoadXml(data);

                        XmlNodeList nodeList;
                        XmlNode root = xd.DocumentElement;
                        nodeList = root.SelectNodes("//eSearchResult");

                        //MessageBox.Show(nodeList.Count.ToString());

                        //XElement xe;
                        foreach (XmlNode book in nodeList)
                        {
                            XmlNodeList Nlist = book.ChildNodes;

                            foreach (XmlNode child in Nlist)
                            {
                                if (child.LocalName == "Count")
                                {
                                    try
                                    {
                                        int nCount = Convert.ToInt32(child.InnerText.Trim());

                                        if (nCount < 0 || nCount > 1)
                                            return "";
                                    }
                                    catch (Exception ex)
                                    {
                                        return "";
                                    }
                                }

                                if (child.LocalName == "IdList")
                                {
                                    try
                                    {
                                        XmlNodeList NClist = child.ChildNodes;

                                        if (NClist.Count > 0)
                                        {
                                            foreach (XmlNode child1 in NClist)
                                            {
                                                if (child1.LocalName == "Id")
                                                {
                                                    string strPmID = child1.InnerText.Trim();

                                                    return strPmID;
                                                }
                                            }
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        return "";
                                    }
                                }
                            }
                        }
                    }
                }
                return "";
            }
            catch (Exception ex)
            {
                return "";
            }
        }

        public static bool ValidatePubMedURI(Uri PubMedURL, WordprocessingDocument wdPackage, string StrToDisplay, string PubMedURI)
        {
            //add the url
            string urlLabel = StrToDisplay;
            System.Uri uri = new Uri(PubMedURI);
            //bool urlExists = false;

            foreach (HyperlinkRelationship hRel in wdPackage.MainDocumentPart.HyperlinkRelationships)
            {
                if (hRel.Uri == uri)
                {
                    return true;
                }
            }

            return false;
        }
    }
}
