﻿using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;
using OpenXmlPowerTools;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Xml.Linq;

namespace MultiInstanceJournalCleanup
{
    class CopyEditing
    {
        public static void PerformCopyEditing(string newDoc)
        {
            try
            {
                using (WordprocessingDocument wDoc = WordprocessingDocument.Open(newDoc, true))
                {
                    try
                    {
                        RevisionAccepter.AcceptRevisions(wDoc);

                        SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                        {
                            //RemoveComments = false,//commented by Karan on 06-08-2018
                            RemoveContentControls = true,
                            RemoveFieldCodes = true,
                            RemoveLastRenderedPageBreak = true,
                            RemovePermissions = true,
                            RemoveProof = true,
                            RemoveRsidInfo = true,
                            RemoveSmartTags = true,
                            RemoveSoftHyphens = true,
                            ReplaceTabsWithSpaces = false//Developer name :Priyanka Vishwakarma. Date:29_5_2019, Requirement:it removes the indentation from the nested list  ,Integrated By:Vikas sir. 
                        };

                        MarkupSimplifier.SimplifyMarkup(wDoc, settings);
                        var xDoc = wDoc.MainDocumentPart.GetXDocument();
                        IEnumerable<XElement> content;
                        content = xDoc.Descendants(W.p);

                        //DoubleOrMoreSpaceToSingleSpace(content);
                        //SpacesBeforeAfterMathematicalSymbol(content);
                        IdentifyEllipses(content);
                        if (GlobalMethods.strClientName.ToLower() == "sage"|| GlobalMethods.strClientName.ToLower() == "csiro")
                        {
                            RemoveDoublecommawithSinglecomma(content);
                        }

                        //Danish: 26-Apr-2023, CE Points for Jaypee                    
                        if (GlobalMethods.strClientName.ToLower() == "jaypee")
                        {

                            // AffiliationDoubleDepartmentexist(content);
                            AffiliationAddingBeginning(content); //Jitender 12-05-2023
                            ReplacepvalueinItalic(content);
                            ReplacenvalueinItalic(content);
                            insertspacebetweenaddsymbolandnuber(content);
                            insertspacebetweenaddsymbolandnuber(content);
                            BetweenthenAnd(content);
                            Fromthento(content);
                            //  Italicpvalue(content);
                        }

                        //RemoveSpacesBeforePercentSymbol(content);
                        //SpaceRequiredAfterComma(content);

                        CommaPeriodInsideQuotationMark(content);
                        if (!GlobalMethods.strJournalArticlePath.ToLower().Contains(@"\journal\ilo\") && GlobalMethods.strClientName.ToLower()!= "jaypee" && GlobalMethods.strClientName.ToLower() != "ssllc")/////Specific to ILO journal only added by vikas on 22-09-2020
                        {
                            AddCommaAfterEg(content);
                        }
                        AddCommaAfterIe(content);
                        RemoveNegativeMargins(content); //Danish
                        //SpaceRequiredAfterDot(content);
                        SpaceRequiredAfterSemicolon(content);
                        //SpaceRequiredAfterQuestionMark(content);
                        SpaceRequiredAfterExclamation(content);

                        // New points opened today 17 Jan 2016 starts //

                        RemoveSpacesBeforeComma(content);


                        //RemoveSpacesBeforeDot(content);//comented by vikas on 26-10-2020
                        RemoveSpacesBeforeSemicolon(content);
                        if (GlobalMethods.strClientName.ToLower() == "sage"|| GlobalMethods.strClientName.ToLower() == "csiro")
                        {
                            RemoveSpacesBeforeColon(content);
                            //RemovenonbreakingSpaces(content);
                            SpaceRequiredBeforeOpeningParenthesis(content);
                            SpaceRequiredAfterClosingParenthesis(content);
                            

                        }
                        RemoveSpacesBeforePercentSymbol(content); // Jitender, moved out of abopve condition.
                        RemoveSpacesBeforeQuestionMark(content);
                        RemoveSpacesBeforeExclamation(content);
                        SpacesBeforeAfterDegreeSymbol(content);

                        RemoveSpaceBetweenEg(content);
                        RemoveSpaceBetweenIe(content);

                        // New points opened today 17 Jan 2016 ends //

                        ConvertSIUnits(content);
                        //SpacesBeforeAfterHyphen(content
                        if (GlobalMethods.strClientName.ToLower() != "informs" && GlobalMethods.strClientName.ToLower() != "international labour organization")  //Developer Name:Priyanka Vishwakarma,Date:30-09-2020,Requirement:avoid to remove space after nad before endash for informs and ILO.
                        {
                            SpacesBeforeAfterEmDash(content);
                            SpacesBeforeAfterEnDash(content);
                        }
                        ///ReplaceFigureWithFigInParenthesis(content);//Commented by Ashwini.
                        //SpaceRequiredBeforeOpeningParenthesis(content); //Commented by priyanka vishwakarma. //Developer name:Priyanka Vishwakarma ,Date:26_08_2019 ,Requirement:It remove the formula numberring from word document.,Integrated by:Vikas sir.
                        NoSpaceAfterOpeningParenthesis(content);

                        //SpaceRequiredAfterClosingParenthesis(content);

                        NoSpaceBeforeClosingParenthesis(content);

                        IdentifyEtAl(content);
                        DoubleOrMoreSpaceToSingleSpace(content);
                        if (GlobalMethods.strClientName.ToLower() == "sage"|| GlobalMethods.strClientName.ToLower() == "csiro")
                        {
                            RemoveDoubleperiodwithSingleperiod(content);
                            SpacesBeforeAfterHyphen(content);
                            SpaceRequiredAfterComma(content);
                            SpaceRequiredAfterQuestionMark(content);
                            ////RemoveSpaceBeforePeriodfollowedbyNumber(content);////this done in wordtohtml sage copyediting points
                        }
                        //Developer Name:Priyanka Vishwakarma, Date:15-12-2021, Requirement:Add space after comma or dot when comma or dot comes between to text only
                            SpaceRequiredAfterCommaOnlybetweenText(content);
                           // SpaceRequiredAfterdotOnlybetweenText(content);
                       

                            wDoc.MainDocumentPart.PutXDocument();
                    }
                    catch (Exception x)
                    {
                        wDoc.MainDocumentPart.PutXDocument();
                    }
                }

            }
            catch (Exception x)
            {

            }
        }

        private static void RemoveSpacesBeforeComma(IEnumerable<XElement> content)
        {
            Regex regex = new Regex("\x020+(,)");
            var totaloccurance = 0;
            content.ToList().ForEach(x =>
            {
                var countoccureance = Regex.Matches(x.Value, "\x020+(,)").Count;
                totaloccurance += countoccureance;
            });
            if (totaloccurance != 0)
            {
                GlobalMethods.CleanupReport.Add("Space Before Comma: Found (" + totaloccurance.ToString() + ")<E>");
            }
            else
            {
                GlobalMethods.CleanupReport.Add("Space Before Comma: Not Found (" + totaloccurance.ToString() + ")<E>");
            }

            int count = OpenXmlRegexModified.Replace(content, regex, ",", null, false, "3ClicksMaster", "RemoveSpacesBeforeComma");
        }
        private static void RemoveSpacesBeforeDot(IEnumerable<XElement> content)
        {
            Regex regex = new Regex("\x020+(\\.)");
            var totaloccurance = 0;
            content.ToList().ForEach(x =>
            {
                var countoccureance = Regex.Matches(x.Value, "\x020+(\\.)").Count;
                totaloccurance += countoccureance;
            });
            if (totaloccurance != 0)
            {
                GlobalMethods.CleanupReport.Add("Spaces Before Dot: Found (" + totaloccurance.ToString() + ")<E>");
            }
            else
            {
                GlobalMethods.CleanupReport.Add("Spaces Before Dot: Not Found (" + totaloccurance.ToString() + ")<E>");
            }
            int count = OpenXmlRegexModified.Replace(content, regex, ".", null, false, "3ClicksMaster", "RemoveSpacesBeforeDot");
        }
        private static void RemoveSpacesBeforeSemicolon(IEnumerable<XElement> content)
        {
            Regex regex = new Regex("\x020+(;)");
            var totaloccurance = 0;
            content.ToList().ForEach(x =>
            {
                var countoccureance = Regex.Matches(x.Value, "\x020+(;)").Count;
                totaloccurance += countoccureance;
            });
            if (totaloccurance != 0)
            {
                GlobalMethods.CleanupReport.Add("Space Before SemiColon: Found (" + totaloccurance.ToString() + ")<E>");
            }
            else
            {
                GlobalMethods.CleanupReport.Add("Space Before SemiColon: Not Found (" + totaloccurance.ToString() + ")<E>");
            }
            int count = OpenXmlRegexModified.Replace(content, regex, ";", null, false, "3ClicksMaster", "RemoveSpacesBeforeSemicolon");
        }
        private static void RemoveSpacesBeforeColon(IEnumerable<XElement> content)
        {

            Regex regex = new Regex("\x020+(:)");
            var totaloccurance = 0;
            content.ToList().ForEach(x =>
            {
                var countoccureance = Regex.Matches(x.Value, "\x020+(:)").Count;
                totaloccurance += countoccureance;
            });
            if (totaloccurance != 0)
            {
                GlobalMethods.CleanupReport.Add("Space Before Colon: Found (" + totaloccurance.ToString() + ")<E>");
            }
            else
            {
                GlobalMethods.CleanupReport.Add("Space Before Colon: Not Found (" + totaloccurance.ToString() + ")<E>");
            }

            int count = OpenXmlRegexModified.Replace(content, regex, ":", null, false, "3ClicksMaster", "RemoveSpacesBeforeColon");
        }
        private static void RemovenonbreakingSpaces(IEnumerable<XElement> content)
        {

            Regex regex = new Regex("\x00A0");
            var totaloccurance = 0;
            content.ToList().ForEach(x =>
            {
                var countoccureance = Regex.Matches(x.Value, "\x00A0").Count;
                totaloccurance += countoccureance;
            });
            if (totaloccurance != 0)
            {
                GlobalMethods.CleanupReport.Add("Non-breaking Space: Found (" + totaloccurance.ToString() + ")<E>");
            }
            else
            {
                GlobalMethods.CleanupReport.Add("Non-breaking Space: Not Found (" + totaloccurance.ToString() + ")<E>");
            }
            int count = OpenXmlRegexModified.Replace(content, regex, " ", null, false, "3ClicksMaster", "RemovenonbreakingSpaces");
        }
        private static void RemoveSpacesBeforeQuestionMark(IEnumerable<XElement> content)
        {
            Regex regex = new Regex("\x020+(\\?)");
            var totaloccurance = 0;
            content.ToList().ForEach(x =>
            {
                var countoccureance = Regex.Matches(x.Value, "\x020+(\\?)").Count;
                totaloccurance += countoccureance;
            });
            if (totaloccurance != 0)
            {
                GlobalMethods.CleanupReport.Add("Spaces Before QuestionMark: Found (" + totaloccurance.ToString() + ")<E>");
            }
            else
            {
                GlobalMethods.CleanupReport.Add("Spaces Before QuestionMark: Not Found (" + totaloccurance.ToString() + ")<E>");
            }
            int count = OpenXmlRegexModified.Replace(content, regex, "?", null, false, "3ClicksMaster", "RemoveSpacesBeforeQuestionMark");
        }
        private static void RemoveSpacesBeforeExclamation(IEnumerable<XElement> content)
        {
            Regex regex = new Regex("\x020+(!)");
            var totaloccurance = 0;
            content.ToList().ForEach(x =>
            {
                var countoccureance = Regex.Matches(x.Value, "\x020+(!)").Count;
                totaloccurance += countoccureance;
            });
            if (totaloccurance != 0)
            {
                GlobalMethods.CleanupReport.Add("Spaces Before Exclamation: Found (" + totaloccurance.ToString() + ")<E>");
            }
            else
            {
                GlobalMethods.CleanupReport.Add("Spaces Before Exclamation: Not Found (" + totaloccurance.ToString() + ")<E>");
            }
            int count = OpenXmlRegexModified.Replace(content, regex, "!", null, false, "3ClicksMaster", "RemoveSpacesBeforeExclamation");
        }
        private static void SpaceRequiredAfterComma(IEnumerable<XElement> content)//updated
        {
            Regex regex = new Regex(@",([^\s\d])");
            var m = new List<string>(); int i = 0;
            int count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "SpaceRequiredAfterComma");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    if (mm == ",”") { }
                    else
                    {
                        string m1 = mm.Replace(",", ", ");
                        string mm1 = mm; bool skip = false;
                        //if (mm1.Contains("\u0001")) { skip = true; }
                        if (skip == false)
                        {
                            try
                            {
                                Regex r1 = new Regex(mm1);
                                int count1 = OpenXmlRegexModified.Replace(content, r1, m1, null, false, "3ClicksMaster", "SpaceRequiredAfterComma");
                            }
                            catch (Exception ex)
                            {

                            }
                        }
                    }
                }
            }
        }
        private static void SpaceRequiredAfterDot(IEnumerable<XElement> content)
        {
            Regex regex = new Regex(@"\.([^\s\d(com)])");
            var m = new List<string>(); int i = 0;
            int count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "SpaceRequiredAfterDot");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    if (mm == ".e") { }
                    else if (mm == ".g") { }
                    else if (mm == ".,") { }
                    else if (mm == ".)") { }
                    else if (mm == ".”") { }
                    else
                    {
                        string m1 = mm.Replace(".", ". ");
                        string mm1 = mm.Replace("(", "[(]");
                        mm1 = mm1.Replace(".", "\\.");
                        Regex r1 = new Regex(mm1);
                        int count1 = OpenXmlRegexModified.Replace(content, r1, m1, null, false, "3ClicksMaster", "SpaceRequiredAfterDot");
                    }
                }
            }
        }
        private static void SpaceRequiredAfterSemicolon(IEnumerable<XElement> content)
        {
            Regex regex = new Regex(@";([^\s])");
            var m = new List<string>(); int i = 0;
            int count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "SpaceRequiredAfterDot");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    string m1 = mm.Replace(";", "; ");
                    string mm1 = mm;
                    Regex r1 = new Regex(mm1);
                    int count1 = OpenXmlRegexModified.Replace(content, r1, m1, null, false, "3ClicksMaster", "SpaceRequiredAfterDot");
                }
            }
        }
        //Remove -ive margins Danish
        private static void RemoveNegativeMargins(IEnumerable<XElement> content)
        {
            Regex regex = new Regex(@"margin-left:-");
            var m = new List<string>(); int i = 0;

            OpenXmlRegexModified.Replace(content, regex, "margin-left:", null, false, "3ClicksMaster", "Removing -ive Margins");
            regex = new Regex(@"margin-left: -");
            OpenXmlRegexModified.Replace(content, regex, "margin-left: ", null, false, "3ClicksMaster", "Removing -ive Margins");


            regex = new Regex(@"margin-right:-");
            OpenXmlRegexModified.Replace(content, regex, "margin-right:", null, false, "3ClicksMaster", "Removing -ive Margins");
            regex = new Regex(@"margin-right: -");
            OpenXmlRegexModified.Replace(content, regex, "margin-right:", null, false, "3ClicksMaster", "Removing -ive Margins");


            /*
            int count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "SpaceRequiredAfterDot");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    string m1 = mm.Replace(";", "; ");
                    string mm1 = mm;
                    Regex r1 = new Regex(mm1);
                    int count1 = OpenXmlRegexModified.Replace(content, r1, m1, null, false, "3ClicksMaster", "SpaceRequiredAfterDot");
                }
            }*/
        }

        private static void SpaceRequiredAfterQuestionMark(IEnumerable<XElement> content)
        {
            Regex regex = new Regex(@"\?([^\s])");
            var m = new List<string>(); int i = 0;
            int count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "SpaceRequiredAfterQuestionMark");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    string m1 = mm.Replace("?", "? ");
                    string mm1 = mm;
                    mm1 = mm1.Replace("?", "?");
                    Regex r1 = new Regex(mm1);
                    int count1 = OpenXmlRegexModified.Replace(content, r1, m1, null, false, "3ClicksMaster", "SpaceRequiredAfterQuestionMark");
                }
            }
        }
        private static void SpaceRequiredAfterExclamation(IEnumerable<XElement> content)
        {
            Regex regex = new Regex(@"!([^\s])");
            var m = new List<string>(); int i = 0;
            int count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "SpaceRequiredAfterExclamation");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    string m1 = mm.Replace("!", "! ");
                    string mm1 = mm;
                    Regex r1 = new Regex(mm1);
                    int count1 = OpenXmlRegexModified.Replace(content, r1, m1, null, false, "3ClicksMaster", "SpaceRequiredAfterExclamation");
                }
            }
        }
        private static void SpacesBeforeAfterDegreeSymbol(IEnumerable<XElement> content)
        {
            Regex regex = new Regex("(°)\x020+");
            int count = OpenXmlRegexModified.Replace(content, regex, "°", null, false, "3ClicksMaster", "SpacesBeforeAfterDegreeSymbol");
            regex = new Regex("\x020+(°)");
            count = OpenXmlRegexModified.Replace(content, regex, "°", null, false, "3ClicksMaster", "SpacesBeforeAfterDegreeSymbol");
        }
        private static void AddCommaAfterEg(IEnumerable<XElement> content)//to be looked into
        {
            Regex regex = new Regex(@"(\se\\.g\\.\s)[^,]");  //Developer Name:Priyanka Vishwakarma, Date:31-12-2021, Change regex for replace e.g. to e.g. , add space before and after e.g. text
            var m = new List<string>(); int i = 0;
            int count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "AddCommaAfterEg");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    string m1 = mm.Replace("e.g.", "e.g., ");
                    string mm1 = mm; bool skip = false;
                    if (skip == false)
                    {
                        Regex r1 = new Regex(mm1);
                        int count1 = OpenXmlRegexModified.Replace(content, r1, m1, null, false, "3ClicksMaster", "AddCommaAfterEg");
                    }
                }
            }
        }
        private static void RemoveSpaceBetweenEg(IEnumerable<XElement> content)
        {
            Regex regex = new Regex("(e\\.)[\\s](g\\.)[,]");
            int count = OpenXmlRegexModified.Replace(content, regex, "e.g.,", null, false, "3ClicksMaster", "RemoveSpaceBetweenEg");
        }

        private static void RemoveDoublecommawithSinglecomma(IEnumerable<XElement> content)
        {
            Regex regex = new Regex("[,,]");
            int count = OpenXmlRegexModified.Replace(content, regex, ",", null, false, "3ClicksMaster", "RemoveDoublecommawithSinglecomma");
        }

        // Changes made by Danish Date:4-14-2023, Requirement if (p-value) given then it converts into italicp-value. 
        private static void ReplacepvalueinItalic(IEnumerable<XElement> content)
        {
            /*Regex regex = new Regex("(?<!<)p(?![^<>]*>)(-)(value)");
            int count = OpenXmlRegexModified.Replace(content, regex, "<i>p</i>-value", null, false, "3ClicksMaster", "ReplacepvalueinItalic");

            regex = new Regex("(?<!<)p(?![^<>]*>)( )(value)");
            count = count + OpenXmlRegexModified.Replace(content, regex, "<i>p</i> value", null, false, "3ClicksMaster", "ReplacepvalueinItalic");
            */
        }
        // Changes made by Danish Date:4-14-2023, Requirement if (n=23) given then it converts into italicn.
        private static void ReplacenvalueinItalic(IEnumerable<XElement> content)
        {
            Regex regex = new Regex("(?<!<)n(?![^<>]*>)(=)(0-9)");
            int count = OpenXmlRegexModified.Replace(content, regex, "<i>n</i>-value", null, false, "3ClicksMaster", "ReplacepvalueinItalic");

            regex = new Regex("(?<!<)r(?![^<>]*>)(=)(0-9)");
            count = count + OpenXmlRegexModified.Replace(content, regex, "<i>r</i> value", null, false, "3ClicksMaster", "ReplacepvalueinItalic");

        }

        // Changes made by Danish Date:4-14-2023 Requirement: if  number  given with the operator then it made space between number and operator.
        private static void insertspacebetweenaddsymbolandnuber(IEnumerable<XElement> content)
        {
            Regex ra = new Regex(@"([0-9]+)([\+\-\=×])([0-9]+)");

            var m = new List<string>(); int i = 0;

            int count = OpenXmlRegexModified.Match(content, ra, (element, match) =>
            { m.Add(match.Value); i++; }, "AddSpaceinOperator");

            if (count > 0)
            {
                foreach (var mm in m)
                {
                    Match mVal = ra.Match(mm);

                    string m1 = mVal.Groups[1] + " " + mVal.Groups[2] + " " + mVal.Groups[3];
                    string mm1 = mVal.Groups[0].ToString(); bool skip = false;

                    mm1 = mm1.Replace("+", "\\+").Replace("-", "\\-");

                    if (skip == false)
                    {
                        Regex r1 = new Regex(mm1);
                        int count1 = OpenXmlRegexModified.Replace(content, r1, m1, null, false, "3ClicksMaster", "AddSpaceinOperator");
                    }
                }
            }

            /*
            foreach (Match match in ra.Matches("Dannnnnnnnnnnsafsafsadfsdasdfs"))
            {
                if (match.Length > 0)
                {
                    string src = match.ToString();
                    string tar = match.Groups[1].ToString() +" "+ match.Groups[2].ToString() +" "+ match.Groups[3].ToString();

                    //textread = textread.Replace(match.ToString(), "");
                   // int count = OpenXmlRegexModified.Replace(src, tar, null,false,"3ClicksMaster", "insertspacebetweenaddsymbolandnuber");
                }
            }
            */

            //int count = OpenXmlRegexModified.Replace(content, regex, "", null, false, "3ClicksMaster", "insertspacebetweenaddsymbolandnube");
        }

        //Changes made by danish Date: 18-04-2023, Requirement:If between 1 to 10 given like this then it convert into 1 and 10. 
        private static void BetweenthenAnd(IEnumerable<XElement> content)
        {
            Regex ra = new Regex(@"([Bb])(etween)( )([A-z0-9a-z]+)( )(to)( )([A-z0-9a-z]+)");

            var m = new List<string>(); int i = 0;

            int count = OpenXmlRegexModified.Match(content, ra, (element, match) =>
            { m.Add(match.Value); i++; }, "AddSpaceinOperator");

            if (count > 0)
            {
                foreach (var mm in m)
                {
                    Match mVal = ra.Match(mm);


                    string m1 = mVal.Groups[1] + "" + mVal.Groups[2] + "" + mVal.Groups[3] + mVal.Groups[4] + mVal.Groups[5] + "and" + mVal.Groups[7] + mVal.Groups[8];
                    string mm1 = mVal.Groups[0].ToString(); bool skip = false;

                    // mm1 = mm1.Replace("+", "\\+").Replace("-", "\\-");

                    if (skip == false)
                    {
                        Regex r1 = new Regex(mm1);
                        int count1 = OpenXmlRegexModified.Replace(content, r1, m1, null, false, "3ClicksMaster", "AddSpaceinOperator");
                    }
                }
            }
        }

        //  Fromthento
        //Changes made by danish Date: 18-04-2023, Requirement:If from 1 and  10 given like this then it convert into 1 to 10. 
        private static void Fromthento(IEnumerable<XElement> content)
        {
            Regex ra = new Regex(@"([Ff])(rom)( )([A-z0-9a-z]+)( )(and)( )([A-z0-9a-z]+)");

            var m = new List<string>(); int i = 0;

            int count = OpenXmlRegexModified.Match(content, ra, (element, match) =>
            { m.Add(match.Value); i++; }, "AddSpaceinOperator");

            if (count > 0)
            {
                foreach (var mm in m)
                {
                    Match mVal = ra.Match(mm);


                    string m1 = mVal.Groups[1] + "" + mVal.Groups[2] + "" + mVal.Groups[3] + mVal.Groups[4] + mVal.Groups[5] + "to" + mVal.Groups[7] + mVal.Groups[8];
                    string mm1 = mVal.Groups[0].ToString(); bool skip = false;

                    // mm1 = mm1.Replace("+", "\\+").Replace("-", "\\-");

                    if (skip == false)
                    {
                        Regex r1 = new Regex(mm1);
                        int count1 = OpenXmlRegexModified.Replace(content, r1, m1, null, false, "3ClicksMaster", "AddSpaceinOperator");
                    }
                }
            }
        }

        // Changes made by Danish Ali Date:18-04-2023 Requirement:Single department of should be correct
        private static void AffiliationDoubleDepartmentexist(IEnumerable<XElement> content)
        {
            Regex ra = new Regex(@"([Dd])(epartment)( )(of)( )([Dd])(epartment)( )(of)");

            var m = new List<string>(); int i = 0;

            int count = OpenXmlRegexModified.Match(content, ra, (element, match) =>
            { m.Add(match.Value); i++; }, "AddSpaceinOperator");

            if (count > 0)
            {
                foreach (var mm in m)
                {
                    Match mVal = ra.Match(mm);

                    string m1 = mVal.Groups[1] + "" + mVal.Groups[2] + "" + mVal.Groups[3] + "" + mVal.Groups[4];
                    string mm1 = mVal.Groups[0].ToString(); bool skip = false;

                    if (skip == false)
                    {
                        Regex r1 = new Regex(mm1);
                        int count1 = OpenXmlRegexModified.Replace(content, r1, m1, null, false, "3ClicksMaster", "AddSpaceinOperator");
                    }
                }
            }
        }

        //Jitender 12-05-2023
        private static void AffiliationAddingBeginning(IEnumerable<XElement> content)
        {
            Regex ra = new Regex(@"([Dd])(epartment)( )(of)( )([Dd])(epartment)( )(of)");

            var m = new List<string>(); int i = 0;

            int count = OpenXmlRegexModified.Match(content, ra, (element, match) =>
            { m.Add(match.Value); i++; }, "AddSpaceinOperator");

            if (count > 0)
            {
                foreach (var mm in m)
                {
                    Match mVal = ra.Match(mm);

                    string m1 = mVal.Groups[1] + "" + mVal.Groups[2] + "" + mVal.Groups[3] + "" + mVal.Groups[4];
                    string mm1 = mVal.Groups[0].ToString(); bool skip = false;

                    if (skip == false)
                    {
                        Regex r1 = new Regex(mm1);
                        int count1 = OpenXmlRegexModified.Replace(content, r1, m1, null, false, "3ClicksMaster", "AddSpaceinOperator");
                    }
                }
            }
        }



        private static void RemoveDoubleperiodwithSingleperiod(IEnumerable<XElement> content)///doubledotwithsingledot
        {
            Regex regex = new Regex("[..]");
            int count = OpenXmlRegexModified.Replace(content, regex, ".", null, false, "3ClicksMaster", "RemoveDoublecommawithSinglecomma");
        }
        private static void AddCommaAfterIe(IEnumerable<XElement> content)
        {
            Regex regex = new Regex("(i[\\.]e[\\.])[^,]");
            var m = new List<string>(); int i = 0;
            int count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "AddCommaAfterIe");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    string m1 = mm.Replace("i.e.", "i.e., ");
                    string mm1 = mm; bool skip = false;
                    mm1 = mm1.Replace("i.e.", "i\\.e\\.");
                    //if (mm1.Contains("\u0001")) { skip = true; }
                    if (skip == false)
                    {
                        Regex r1 = new Regex(mm1);
                        int count1 = OpenXmlRegexModified.Replace(content, r1, m1, null, false, "3ClicksMaster", "AddCommaAfterIe");
                    }
                }
            }
        }
        private static void RemoveSpaceBetweenIe(IEnumerable<XElement> content)
        {
            //Regex regex = new Regex("(i[\\.\\s]e[\\.,])");
            Regex regex = new Regex("(i\\.)[\\s](e\\.)[,]");
            int count = OpenXmlRegexModified.Replace(content, regex, "i.e.,", null, false, "3ClicksMaster", "RemoveSpaceBetweenIe");
        }
        private static void DoubleOrMoreSpaceToSingleSpace(IEnumerable<XElement> content)
        {
            Regex regex = new Regex("\x020+(\x020)");
            var totaloccurance = 0;
            content.ToList().ForEach(x =>
            {
                var countoccureance = Regex.Matches(x.Value, "\x020+(\x020)").Count;
                totaloccurance += countoccureance;
            });
            if (totaloccurance != 0)
            {
                GlobalMethods.CleanupReport.Add("Double Space: Found (" + totaloccurance.ToString() + ")<E>");
            }
            else
            {
                GlobalMethods.CleanupReport.Add("Double Space: Not Found (" + totaloccurance.ToString() + ")<E>");
            }
            int count = OpenXmlRegexModified.Replace(content, regex, "\x020", null, true, "3ClicksMaster", "DoubleOrMoreSpaceToSingleSpace");
        }
        private static void ConvertSIUnits(IEnumerable<XElement> content)
        {
            Regex regex = new Regex(@"(\d)\s(millimeter)");
            var m = new List<string>(); int i = 0;
            int count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "ConvertSIUnits");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    string m1 = mm.Replace("millimeter", "mm");
                    Regex r1 = new Regex(mm);
                    int count1 = OpenXmlRegexModified.Replace(content, r1, m1, null, false, "3ClicksMaster", "ConvertSIUnits");
                }
            }
            regex = new Regex(@"(\d)(millimeter)");
            m = new List<string>(); i = 0;
            count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "ConvertSIUnits");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    string m1 = mm.Replace("millimeter", "\x020mm");
                    Regex r1 = new Regex(mm);
                    int count1 = OpenXmlRegexModified.Replace(content, r1, m1, null, false, "3ClicksMaster", "ConvertSIUnits");
                }
            }
            //regex = new Regex(@"(\d)(mm)");
            //m = new List<string>(); i = 0;
            //count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            //{ m.Add(match.Value); i++; }, "ConvertSIUnits");
            //if (count > 0)
            //{
            //    foreach (var mm in m)
            //    {
            //        string m1 = mm.Replace("mm", "\x020mm");
            //        Regex r1 = new Regex(mm);
            //        int count1 = OpenXmlRegexModified.Replace(content, r1, m1, null, false, "3ClicksMaster", "ConvertSIUnits");
            //    }

            //}
            regex = new Regex(@"(\d)(mm|kg|cm|km)");
            m = new List<string>(); i = 0;
            count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "ConvertSIUnits");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    string m1 = mm.Replace("mm", "\x2009mm").Replace("km", "\x2009km").Replace("kg", "\x2009kg").Replace("cm", "\x2009cm");
                    Regex r1 = new Regex(mm);
                    int count1 = OpenXmlRegexModified.Replace(content, r1, m1, null, false, "3ClicksMaster", "ConvertSIUnits");
                }

            }


        }
        private static void SpacesBeforeAfterHyphen(IEnumerable<XElement> content)
        {
            Regex regex = new Regex("(-)\x020+");
            int count = OpenXmlRegexModified.Replace(content, regex, "-", null, false, "3ClicksMaster", "SpacesBeforeAfterHyphen");
            regex = new Regex("\x020+(-)");
            count = OpenXmlRegexModified.Replace(content, regex, "-", null, false, "3ClicksMaster", "SpacesBeforeAfterHyphen");
        }
        private static void RemoveSpaceBeforePeriodfollowedbyNumber(IEnumerable<XElement> content)
        {
            if (content.Count() > 0 && content.FirstOrDefault().Parent != null)
            {
                var strMatchText = GlobalMethods.DocumentRegEx(content.FirstOrDefault().Parent.Value, @"(( \. )[A-Za-z])");
                foreach (var replace in strMatchText)
                {
                    var regex = new Regex(replace);
                    OpenXmlRegexModified.Replace(content, regex, replace.TrimStart(' '), null, false, "3ClicksMaster", "RemoveSpaceBeforePeriodfollowedbyNumber");
                }
            }
        }
        private static void SpacesBeforeAfterEmDash(IEnumerable<XElement> content)
        {
            Regex regex = new Regex("(—)\x020+");
            int count = OpenXmlRegexModified.Replace(content, regex, "—", null, false, "3ClicksMaster", "SpacesBeforeAfterEmDash");
            regex = new Regex("\x020+(—)");
            count = OpenXmlRegexModified.Replace(content, regex, "—", null, false, "3ClicksMaster", "SpacesBeforeAfterEmDash");
        }
        private static void SpacesBeforeAfterEnDash(IEnumerable<XElement> content)
        {
            Regex regex = new Regex("(–)\x020+");
            int count = OpenXmlRegexModified.Replace(content, regex, "–", null, false, "3ClicksMaster", "SpacesBeforeAfterEnDash");
            regex = new Regex("\x020+(–)");
            count = OpenXmlRegexModified.Replace(content, regex, "–", null, false, "3ClicksMaster", "SpacesBeforeAfterEnDash");
        }

        private static void SpaceRequiredAfterSingleQuote(IEnumerable<XElement> content)//not required
        {
            Regex regex = new Regex(@"’([^\s])");
            var m = new List<string>(); int i = 0;
            int count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "SpaceRequiredAfterSingleQuote");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    string m1 = mm.Replace("’", "’ ");
                    Regex r1 = new Regex(mm);
                    int count1 = OpenXmlRegexModified.Replace(content, r1, m1, null, false, "3ClicksMaster", "SpaceRequiredAfterSingleQuote");
                }
            }
        }
        private static void ReplaceFigureWithFigInParenthesis(IEnumerable<XElement> content)
        {
            Regex regex = new Regex(@"[(](Figure)");
            int count = OpenXmlRegexModified.Replace(content, regex, "(Fig", null, false, "3ClicksMaster", "ReplaceFigureWithFigInParenthesis");
        }
        private static void SpaceRequiredBeforeOpeningParenthesis(IEnumerable<XElement> content)//updated
        {
            Regex regex = new Regex("[^\\s][(][^s)]");
            var m = new List<string>(); int i = 0;
            int count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "SpaceRequiredBeforeOpeningParenthesis");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    string mm1 = mm.Replace("(", "[(]");
                    mm1 = mm1.Replace(")", "[)]");
                    mm1 = mm1.Replace(".", "\\.");
                    string m1 = mm.Replace("(", " (");
                    Regex r1 = new Regex(mm1);
                    int count1 = OpenXmlRegexModified.Replace(content, r1, m1, null, false, "3ClicksMaster", "SpaceRequiredBeforeOpeningParenthesis");
                }
            }
        }
        private static void NoSpaceAfterOpeningParenthesis(IEnumerable<XElement> content)
        {
            Regex regex = new Regex("[(]\x020+");
            int count1 = OpenXmlRegexModified.Replace(content, regex, "(", null, false, "3ClicksMaster", "NoSpaceAfterOpeningParenthesis");
        }//update not required
        private static void SpaceRequiredAfterClosingParenthesis(IEnumerable<XElement> content)
        {
            // Regex regex = new Regex("[)][^\\s]");
            Regex regex = new Regex(@"[)][\w]");//12_08_2021 regex changed by vikas 
            var m = new List<string>(); int i = 0;
            int count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "SpaceRequiredAfterClosingParenthesis");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    if (mm == "),") { }
                    else if (mm == ").") { }
                    else if (mm == ");") { }
                    else
                    {
                        if (mm != ")*"&& mm != ")+")  //22_03_2021, Add condition  for avoiding add astric after closing parenthesis //12_08_2021, Add condition  for avoiding add plus after closing parenthesis 
                        {
                            string mm1 = mm.Replace(")", "[)]");
                            mm1 = mm1.Replace("(", "[(]");
                            mm1 = mm1.Replace(".", "\\.");
                            string s = mm.Replace(")", ")\x020");
                            Regex r1 = new Regex(mm1);
                            int count1 = OpenXmlRegexModified.Replace(content, r1, s, null, false, "3ClicksMaster", "SpaceRequiredAfterClosingParenthesis");
                        }
                    }
                }
            }
        }//updated
        private static void NoSpaceBeforeClosingParenthesis(IEnumerable<XElement> content)
        {
            Regex regex = new Regex("\x020+[)]");
            int count1 = OpenXmlRegexModified.Replace(content, regex, ")", null, false, "3ClicksMaster", "NoSpaceBeforeClosingParenthesis");
        }//update not required
        private static void IdentifyEtAl(IEnumerable<XElement> content)
        {
            Regex regex = new Regex("([^\\s]et[\\s]al[\\s])");
            var m = new List<string>(); int i = 0;
            int count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "NoSpaceBeforeClosingParenthesis");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    string m1 = mm.Replace("et al", " et al ");
                    string mm1 = mm; bool skip = false;
                    //if (mm1.Contains("\u0001")) { skip = true; }
                    if (skip == false)
                    {
                        Regex r1 = new Regex(mm1);
                        int count1 = OpenXmlRegexModified.Replace(content, r1, m1, null, false, "3ClicksMaster", "NoSpaceBeforeClosingParenthesis");
                    }
                }
            }
            regex = new Regex("([^\\s]et[\\s]al[\\.])");
            m = new List<string>(); i = 0;
            count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "NoSpaceBeforeClosingParenthesis");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    string m1 = mm.Replace("et al.", " et al ");
                    string mm1 = mm; bool skip = false;
                    //if (mm1.Contains("\u0001")) { skip = true; }
                    if (skip == false)
                    {
                        Regex r1 = new Regex(mm1);
                        int count1 = OpenXmlRegexModified.Replace(content, r1, m1, null, false, "3ClicksMaster", "NoSpaceBeforeClosingParenthesis");
                    }
                }
            }
            regex = new Regex("([^\\s]et[\\s]al)[^\\s]");
            m = new List<string>(); i = 0;
            content = content.Skip(1).Take(1);
            count = OpenXmlRegex.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; });
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    string m1 = mm.Replace("et al", " et al ");
                    string mm1 = mm; bool skip = false;
                    //if (mm1.Contains("\u0001")) { skip = true; }
                    if (skip == false)
                    {
                        Regex r1 = new Regex(mm1);
                        int count1 = OpenXmlRegexModified.Replace(content, r1, m1, null, false, "3ClicksMaster", "NoSpaceBeforeClosingParenthesis");
                    }
                }
            }
        }
        private static void IdentifyEllipses(IEnumerable<XElement> content)
        {
            Regex regex = new Regex("\x020+\\.\\.\\.\x020+");
            int count = OpenXmlRegexModified.Replace(content, regex, " \u2026 ", null, false, "3ClicksMaster", "IdentifyEllipses");
            regex = new Regex("\x020+\\.\\s\\.\\s\\.\x020+");
            count = OpenXmlRegexModified.Replace(content, regex, " \u2026 ", null, false, "3ClicksMaster", "IdentifyEllipses");
            regex = new Regex("\x020+(\u2026)\x020+");
            count = OpenXmlRegexModified.Replace(content, regex, " \u2026 ", null, false, "3ClicksMaster", "IdentifyEllipses");
        }
        private static void SpacesBeforeAfterMathematicalSymbol(IEnumerable<XElement> content)
        {
            Regex regex = new Regex("[\\+][^\\s]");
            var m = new List<string>(); int i = 0;
            int count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "SpacesBeforeAfterMathematicalSymbol");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    if (mm == "+)") { }
                    else if (mm == "(+") { }
                    else
                    {
                        string mm1 = mm.Replace("+", "\\+");
                        mm1 = mm1.Replace(".", "\\.");
                        string s = mm.Replace("+", "+\x020");
                        Regex r1 = new Regex(mm1);
                        int count1 = OpenXmlRegexModified.Replace(content, r1, s, null, false, "3ClicksMaster", "SpacesBeforeAfterMathematicalSymbol");
                    }
                }
            }
            regex = new Regex("[^\\s][\\+]");
            m = new List<string>(); i = 0;
            count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "SpacesBeforeAfterMathematicalSymbol");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    if (mm == "(+") { }
                    else
                    {
                        string mm1 = mm.Replace("+", "\\+");
                        mm1 = mm1.Replace(".", "\\.");
                        string s = mm.Replace("+", "\x020+");
                        Regex r1 = new Regex(mm1);
                        int count1 = OpenXmlRegexModified.Replace(content, r1, s, null, false, "3ClicksMaster", "SpacesBeforeAfterMathematicalSymbol");
                    }
                }
            }
            regex = new Regex("[=][^\\s]");
            m = new List<string>(); i = 0;
            count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "SpacesBeforeAfterMathematicalSymbol");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    if (mm == "=)") { }
                    else if (mm == "(=") { }
                    else
                    {
                        string mm1 = mm.Replace(".", "\\.");
                        string s = mm.Replace("=", "=\x020");
                        Regex r1 = new Regex(mm1);
                        int count1 = OpenXmlRegexModified.Replace(content, r1, s, null, false, "3ClicksMaster", "SpacesBeforeAfterMathematicalSymbol");
                    }
                }
            }
            regex = new Regex("[^\\s][=]");
            m = new List<string>(); i = 0;
            count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "SpacesBeforeAfterMathematicalSymbol");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    if (mm == "(=") { }
                    else
                    {
                        string mm1 = mm.Replace(".", "\\.");
                        string s = mm.Replace("=", "\x020=");
                        Regex r1 = new Regex(mm1);
                        int count1 = OpenXmlRegexModified.Replace(content, r1, s, null, false, "3ClicksMaster", "SpacesBeforeAfterMathematicalSymbol");
                    }
                }
            }
            regex = new Regex("[−][^\\s]");
            m = new List<string>(); i = 0;
            count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "SpacesBeforeAfterMathematicalSymbol");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    if (mm == "−)") { }
                    else if (mm == "(−") { }
                    else
                    {
                        string mm1 = mm.Replace(".", "\\.");
                        string s = mm.Replace("−", "−\x020");
                        Regex r1 = new Regex(mm1);
                        int count1 = OpenXmlRegexModified.Replace(content, r1, s, null, false, "3ClicksMaster", "SpacesBeforeAfterMathematicalSymbol");
                    }
                }
            }
            regex = new Regex("[^\\s][−]");
            m = new List<string>(); i = 0;
            count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "SpacesBeforeAfterMathematicalSymbol");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    if (mm == "(−") { }
                    else
                    {
                        string mm1 = mm.Replace(".", "\\.");
                        string s = mm.Replace("−", "\x020−");
                        Regex r1 = new Regex(mm1);
                        int count1 = OpenXmlRegexModified.Replace(content, r1, s, null, false, "3ClicksMaster", "SpacesBeforeAfterMathematicalSymbol");
                    }
                }
            }
            regex = new Regex("[±][^\\s]");
            m = new List<string>(); i = 0;
            count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "SpacesBeforeAfterMathematicalSymbol");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    if (mm == "±)") { }
                    else if (mm == "(±") { }
                    else
                    {
                        string mm1 = mm.Replace(".", "\\.");
                        string s = mm.Replace("±", "±\x020");
                        Regex r1 = new Regex(mm1);
                        int count1 = OpenXmlRegexModified.Replace(content, r1, s, null, false, "3ClicksMaster", "SpacesBeforeAfterMathematicalSymbol");
                    }
                }
            }
            regex = new Regex("[^\\s][±]");
            m = new List<string>(); i = 0;
            count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "SpacesBeforeAfterMathematicalSymbol");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    if (mm == "(±") { }
                    else
                    {
                        string mm1 = mm.Replace(".", "\\.");
                        string s = mm.Replace("±", "\x020±");
                        Regex r1 = new Regex(mm1);
                        int count1 = OpenXmlRegexModified.Replace(content, r1, s, null, false, "3ClicksMaster", "SpacesBeforeAfterMathematicalSymbol");
                    }
                }
            }
            regex = new Regex("[≥][^\\s]");
            m = new List<string>(); i = 0;
            count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "SpacesBeforeAfterMathematicalSymbol");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    if (mm == "≥)") { }
                    else if (mm == "(≥") { }
                    else
                    {
                        string mm1 = mm.Replace(".", "\\.");
                        string s = mm.Replace("≥", "≥\x020");
                        Regex r1 = new Regex(mm1);
                        int count1 = OpenXmlRegexModified.Replace(content, r1, s, null, false, "3ClicksMaster", "SpacesBeforeAfterMathematicalSymbol");
                    }
                }
            }
            regex = new Regex("[^\\s][≥]");
            m = new List<string>(); i = 0;
            count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "SpacesBeforeAfterMathematicalSymbol");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    if (mm == "(≥") { }
                    else
                    {
                        string mm1 = mm.Replace(".", "\\.");
                        string s = mm.Replace("≥", "\x020≥");
                        Regex r1 = new Regex(mm1);
                        int count1 = OpenXmlRegexModified.Replace(content, r1, s, null, false, "3ClicksMaster", "SpacesBeforeAfterMathematicalSymbol");
                    }
                }
            }
            regex = new Regex("[<][^\\s]");
            m = new List<string>(); i = 0;
            count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "SpacesBeforeAfterMathematicalSymbol");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    if (mm == "<)") { }
                    else if (mm == "(<") { }
                    else
                    {
                        string mm1 = mm.Replace(".", "\\.");
                        string s = mm.Replace("<", "<\x020");
                        Regex r1 = new Regex(mm1);
                        int count1 = OpenXmlRegexModified.Replace(content, r1, s, null, false, "3ClicksMaster", "SpacesBeforeAfterMathematicalSymbol");
                    }
                }
            }
            regex = new Regex("[^\\s][<]");
            m = new List<string>(); i = 0;
            count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "SpacesBeforeAfterMathematicalSymbol");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    if (mm == "(<") { }
                    else
                    {
                        string mm1 = mm.Replace(".", "\\.");
                        string s = mm.Replace("<", "\x020<");
                        Regex r1 = new Regex(mm1);
                        int count1 = OpenXmlRegexModified.Replace(content, r1, s, null, false, "3ClicksMaster", "SpacesBeforeAfterMathematicalSymbol");
                    }
                }
            }
            regex = new Regex("[>][^\\s]");
            m = new List<string>(); i = 0;
            count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "SpacesBeforeAfterMathematicalSymbol");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    if (mm == ">)") { }
                    else if (mm == "(>") { }
                    else
                    {
                        string mm1 = mm.Replace(".", "\\.");
                        string s = mm.Replace(">", ">\x020");
                        Regex r1 = new Regex(mm1);
                        int count1 = OpenXmlRegexModified.Replace(content, r1, s, null, false, "3ClicksMaster", "SpacesBeforeAfterMathematicalSymbol");
                    }
                }
            }
            regex = new Regex("[^\\s][>]");
            m = new List<string>(); i = 0;
            count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "SpacesBeforeAfterMathematicalSymbol");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    if (mm == "(>") { }
                    else
                    {
                        string mm1 = mm.Replace(".", "\\.");
                        string s = mm.Replace(">", "\x020>");
                        Regex r1 = new Regex(mm1);
                        int count1 = OpenXmlRegexModified.Replace(content, r1, s, null, false, "3ClicksMaster", "SpacesBeforeAfterMathematicalSymbol");
                    }
                }
            }
            regex = new Regex("[×][^\\s]");
            m = new List<string>(); i = 0;
            count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "SpacesBeforeAfterMathematicalSymbol");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    if (mm == "×)") { }
                    else if (mm == "(×") { }
                    else
                    {
                        string mm1 = mm.Replace(".", "\\.");
                        string s = mm.Replace("×", "×\x020");
                        Regex r1 = new Regex(mm1);
                        int count1 = OpenXmlRegexModified.Replace(content, r1, s, null, false, "3ClicksMaster", "SpacesBeforeAfterMathematicalSymbol");
                    }
                }
            }
            regex = new Regex("[^\\s][×]");
            m = new List<string>(); i = 0;
            count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "SpacesBeforeAfterMathematicalSymbol");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    if (mm == "(±") { }
                    else
                    {
                        string mm1 = mm.Replace(".", "\\.");
                        string s = mm.Replace("×", "\x020×");
                        Regex r1 = new Regex(mm1);
                        int count1 = OpenXmlRegexModified.Replace(content, r1, s, null, false, "3ClicksMaster", "SpacesBeforeAfterMathematicalSymbol");
                    }
                }
            }
            regex = new Regex("[÷][^\\s]");
            m = new List<string>(); i = 0;
            count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "SpacesBeforeAfterMathematicalSymbol");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    if (mm == "÷)") { }
                    else if (mm == "(÷") { }
                    else
                    {
                        string mm1 = mm.Replace(".", "\\.");
                        string s = mm.Replace("÷", "÷\x020");
                        Regex r1 = new Regex(mm1);
                        int count1 = OpenXmlRegexModified.Replace(content, r1, s, null, false, "3ClicksMaster", "SpacesBeforeAfterMathematicalSymbol");
                    }
                }
            }
            regex = new Regex("[^\\s][÷]");
            m = new List<string>(); i = 0;
            count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "SpacesBeforeAfterMathematicalSymbol");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    if (mm == "(÷") { }
                    else
                    {
                        string mm1 = mm.Replace(".", "\\.");
                        string s = mm.Replace("÷", "\x020÷");
                        Regex r1 = new Regex(mm1);
                        int count1 = OpenXmlRegexModified.Replace(content, r1, s, null, false, "3ClicksMaster", "SpacesBeforeAfterMathematicalSymbol");
                    }
                }
            }
            regex = new Regex("[~][^\\s]");
            m = new List<string>(); i = 0;
            count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "SpacesBeforeAfterMathematicalSymbol");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    if (mm == "~)") { }
                    else if (mm == "(~") { }
                    else
                    {
                        string mm1 = mm.Replace(".", "\\.");
                        string s = mm.Replace("~", "~\x020");
                        Regex r1 = new Regex(mm1);
                        int count1 = OpenXmlRegexModified.Replace(content, r1, s, null, false, "3ClicksMaster", "SpacesBeforeAfterMathematicalSymbol");
                    }
                }
            }
            regex = new Regex("[^\\s][~]");
            m = new List<string>(); i = 0;
            count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "SpacesBeforeAfterMathematicalSymbol");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    if (mm == "(~") { }
                    else
                    {
                        string mm1 = mm.Replace(".", "\\.");
                        string s = mm.Replace("~", "\x020~");
                        Regex r1 = new Regex(mm1);
                        int count1 = OpenXmlRegexModified.Replace(content, r1, s, null, false, "3ClicksMaster", "SpacesBeforeAfterMathematicalSymbol");
                    }
                }
            }
            regex = new Regex("[≈][^\\s]");
            m = new List<string>(); i = 0;
            count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "SpacesBeforeAfterMathematicalSymbol");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    if (mm == "≈)") { }
                    else if (mm == "(≈") { }
                    else
                    {
                        string mm1 = mm.Replace(".", "\\.");
                        string s = mm.Replace("≈", "≈\x020");
                        Regex r1 = new Regex(mm1);
                        int count1 = OpenXmlRegexModified.Replace(content, r1, s, null, false, "3ClicksMaster", "SpacesBeforeAfterMathematicalSymbol");
                    }
                }
            }
            regex = new Regex("[^\\s][≈]");
            m = new List<string>(); i = 0;
            count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "SpacesBeforeAfterMathematicalSymbol");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    if (mm == "(≈") { }
                    else
                    {
                        string mm1 = mm.Replace(".", "\\.");
                        string s = mm.Replace("≈", "\x020≈");
                        Regex r1 = new Regex(mm1);
                        int count1 = OpenXmlRegexModified.Replace(content, r1, s, null, false, "3ClicksMaster", "SpacesBeforeAfterMathematicalSymbol");
                    }
                }
            }
        }//updated
        private static void RemoveSpacesBeforePercentSymbol(IEnumerable<XElement> content)//update not required
        {

            Regex regex = new Regex("\x020+(%)");
            var totaloccurance = 0;
            content.ToList().ForEach(x =>
            {
                var countoccureance = Regex.Matches(x.Value, "\x020+(%)").Count;
                totaloccurance += countoccureance;
            });
            if (totaloccurance != 0)
            {
                GlobalMethods.CleanupReport.Add("Space Before Percent Symbol: Found (" + totaloccurance.ToString() + ")<E>");
            }
            else
            {
                GlobalMethods.CleanupReport.Add("Space Before Percent Symbol: Not Found (" + totaloccurance.ToString() + ")<E>");
            }
            int count = OpenXmlRegexModified.Replace(content, regex, "%", null, false, "3ClicksMaster", "RemoveSpacesBeforePercentSymbol");
        }
        private static void CommaPeriodInsideQuotationMark(IEnumerable<XElement> content)//update not required
        {
            Regex regex = new Regex("\\”,");
            int count = OpenXmlRegexModified.Replace(content, regex, ",”", null, false, "3ClicksMaster", "CommaPeriodInsideQuotationMark");
            regex = new Regex("(”\\.)");
            count = OpenXmlRegexModified.Replace(content, regex, ".”", null, false, "3ClicksMaster", "CommaPeriodInsideQuotationMark");
            regex = new Regex("(;”)");
            count = OpenXmlRegexModified.Replace(content, regex, "”;", null, false, "3ClicksMaster", "CommaPeriodInsideQuotationMark");
        }

        private static void SpaceRequiredAfterCommaOnlybetweenText(IEnumerable<XElement> content)//updated
        {
            Regex regex = new Regex(@"([A-Za-z]+\,[A-Za-z]+)");
            var m = new List<string>(); int i = 0;
            int count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "SpaceRequiredAfterCommaOnlybetweenText");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    if (mm == ",”") { }
                    else
                    {
                        string m1 = mm.Replace(",", ", ");
                        string mm1 = mm; bool skip = false;
                        //if (mm1.Contains("\u0001")) { skip = true; }
                        if (skip == false)
                        {
                            try
                            {
                                Regex r1 = new Regex(mm1);
                                int count1 = OpenXmlRegexModified.Replace(content, r1, m1, null, false, "3ClicksMaster", "SpaceRequiredAfterCommaOnlybetweenText");
                            }
                            catch (Exception ex)
                            {

                            }
                        }
                    }
                }
            }
        }
        private static void SpaceRequiredAfterdotOnlybetweenText(IEnumerable<XElement> content)//updated
        {
            Regex regex = new Regex(@"([A-Za-z]+\.[A-Za-z]+)");
            var m = new List<string>(); int i = 0;
            int count = OpenXmlRegexModified.Match(content, regex, (element, match) =>
            { m.Add(match.Value); i++; }, "SpaceRequiredAfterdotOnlybetweenText");
            if (count > 0)
            {
                foreach (var mm in m)
                {
                    if (mm == ",”") { }
                    else
                    {
                        string m1 = mm.Replace(".", ". ");
                        string mm1 = mm; bool skip = false;
                        //if (mm1.Contains("\u0001")) { skip = true; }
                        if (skip == false)
                        {
                            try
                            {
                                Regex r1 = new Regex(mm1);
                                int count1 = OpenXmlRegexModified.Replace(content, r1, m1, null, false, "3ClicksMaster", "SpaceRequiredAfterdotOnlybetweenText");
                            }
                            catch (Exception ex)
                            {

                            }
                        }
                    }
                }
            }
        }

    }
}
