﻿using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace MultiInstanceJournalCleanup
{
    class CitationApply
    {
        public static void ApplyCiteFig_and_CiteTbl(string strProcessDoc)
        {
            GlobalMethods.CitationStyle = ConfigurationManager.AppSettings.Get("CitationStyle");
            List<string> CitationPatternsColl = new List<string>();

            ///Configuration read from Supporting folder
            CitationPatternsColl = GlobalMethods.ReadAndStoreFileValuesInArray(GlobalMethods.CitationStyle);

            CitationPatternsColl = GlobalMethods.SortStringListOnLength(CitationPatternsColl);

            using (WordprocessingDocument WPD = WordprocessingDocument.Open(strProcessDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P != null && P.InnerText != "")
                    {
                        if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null
                            && P.ParagraphProperties.ParagraphStyleId.Val.Value != "FIGC" || P.ParagraphProperties.ParagraphStyleId.Val.Value != "TT")
                        {
                            string serachtext = P.InnerText;

                            List<string> arr = new List<string>();

                            foreach (var item in CitationPatternsColl.ToList())
                            {


                                #region openxml logic 
                                /////////multiple matches
                                //////var arr1 = Regex.Matches(serachtext, item).Cast<Match>().Select(m => m.Value).ToList();

                                //////if (arr1.Count > 0)
                                //////{
                                //////    string search = null;
                                //////    foreach (var m in arr1.ToList())
                                //////    {
                                //////        search = m;
                                //////        foreach (Run R in P.Descendants<Run>().ToList())
                                //////        {
                                //////            foreach (Text t in R.Descendants<Text>().ToList())
                                //////            {
                                //////                if(t.Text.Equals(search))
                                //////                {
                                //////                    if(R.RunProperties!= null)
                                //////                    {
                                //////                        if(R.RunProperties.RunStyle==null)
                                //////                        {
                                //////                            R.RunProperties.RunStyle = new RunStyle { Val = "citefig" };
                                //////                        }
                                //////                    }
                                //////                    else
                                //////                    {
                                //////                        R.RunProperties = new RunProperties(new RunStyle { Val = "citefig" });
                                //////                    }
                                //////                }
                                //////            }
                                //////        }
                                //////    }
                                //////    arr1.Clear();
                                //////}
                                #endregion
                            }
                        }
                    }
                }
                D.Save();
            }
        }
    }
}
