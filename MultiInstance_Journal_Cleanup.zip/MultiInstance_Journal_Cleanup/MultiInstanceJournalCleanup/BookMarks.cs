﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DocumentFormat.OpenXml.Packaging;
using OpenXmlPowerTools;
using DocumentFormat.OpenXml.Wordprocessing;
using System.Xml.Linq;

namespace MultiInstanceJournalCleanup
{
    class BookMarks
    {
        public static void RemoveHiddenBookMark(string newDoc)
        {
            try
            {
                List<string> lstAuthorAffIDs = new List<string>();
                lstAuthorAffIDs.Clear();

                using (WordprocessingDocument WPD = WordprocessingDocument
                .Open(newDoc, true))
                {
                    SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                    {
                        //RemoveComments = false,//commented by Karan on 06-08-2018
                        RemoveContentControls = true,
                        RemoveEndAndFootNotes = false,
                        RemoveFieldCodes = true,
                        RemoveLastRenderedPageBreak = true,
                        RemovePermissions = true,
                        RemoveProof = true,
                        RemoveRsidInfo = true,
                        RemoveSmartTags = true,
                        RemoveSoftHyphens = false,
                        ReplaceTabsWithSpaces = false,//Developer name :Priyanka Vishwakarma. Date:29_5_2019, Requirement:it removes the indentation from the nested list  ,Integrated By:Vikas sir. 
                    };

                    MarkupSimplifier.SimplifyMarkup(WPD, settings);

                    MainDocumentPart MDP = WPD.MainDocumentPart;

                    Document D = MDP.Document;

                    // Go thorugh Author Paragraph and extract all the superscript values 
                    // and store in Array

                    string strAuthorID = null;
                    string strAffID = null;
                    bool bSuperScript = false;

                    foreach (Paragraph P in D.Descendants<Paragraph>().ToList().
                   Where(e => e.ParagraphProperties != null
                       && e.ParagraphProperties.ParagraphStyleId != null
                       && e.ParagraphProperties.ParagraphStyleId.Val == "AU"))
                    {
                        // Extract superscript values

                        if (P.HasChildren == true)
                        {
                            if (P.Descendants<Run>().Count() > 0)
                            {
                                foreach (Run R in P.Descendants<Run>().ToList())
                                {
                                    if (R.RunProperties != null)
                                    {
                                        if (R.RunProperties.VerticalTextAlignment != null)
                                        {
                                            bSuperScript = false;
                                            if (R.RunProperties.VerticalTextAlignment.Val == "superscript")
                                            {
                                                bSuperScript = true;
                                            }
                                        }
                                    }

                                    strAuthorID = null;
                                    foreach (Text T in R.Descendants<Text>().ToList())
                                    {
                                        if (bSuperScript)
                                        {
                                            bSuperScript = false;
                                            strAuthorID += T.Text;

                                            if (strAuthorID.Contains(","))
                                            {
                                                // Split the string on comma and seperate the Affiliation ID's
                                                string[] separators = { "," };
                                                string[] AffID = strAuthorID.Split(separators, StringSplitOptions.RemoveEmptyEntries);

                                                if (AffID.Length > 0)
                                                {
                                                    for (int counter = 0; counter < AffID.Length; counter++)
                                                    {
                                                        if (lstAuthorAffIDs.Contains(AffID[counter]) == false)
                                                        {
                                                            lstAuthorAffIDs.Add(AffID[counter]);
                                                        }
                                                    }
                                                }
                                            }
                                            else
                                            {
                                                if (lstAuthorAffIDs.Contains(strAuthorID) == false)
                                                {
                                                    lstAuthorAffIDs.Add(strAuthorID);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    strAffID = null;
                    foreach (Paragraph P in D.Descendants<Paragraph>().ToList().
                            Where(e => e.ParagraphProperties != null
                                && e.ParagraphProperties.ParagraphStyleId != null
                                && e.ParagraphProperties.ParagraphStyleId.Val == "AFFL"))
                    {
                        if (P.HasChildren == true)
                        {
                            if (P.Descendants<Run>().Count() > 0)
                            {
                                foreach (Run R in P.Descendants<Run>().ToList())
                                {
                                    if (R.RunProperties != null)
                                    {
                                        if (R.RunProperties.VerticalTextAlignment != null)
                                        {
                                            bSuperScript = false;
                                            if (R.RunProperties.VerticalTextAlignment.Val == "superscript")
                                            {
                                                bSuperScript = true;
                                            }
                                        }
                                    }

                                    strAffID = null;
                                    foreach (Text T in R.Descendants<Text>().ToList())
                                    {
                                        if (bSuperScript)
                                        {
                                            bSuperScript = false;
                                            strAffID += T.Text;

                                            if (lstAuthorAffIDs.Contains(strAffID))
                                            {
                                                if (R.RunProperties != null)
                                                {
                                                    if (R.RunProperties.RunStyle != null)
                                                    {
                                                        R.RunProperties.RunStyle.Remove();
                                                    }
                                                }

                                                // Create a new Run Style for the number

                                                RunStyle rs = new RunStyle();
                                                rs.Val = "affnumber";

                                                R.RunProperties.AppendChild(rs);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
