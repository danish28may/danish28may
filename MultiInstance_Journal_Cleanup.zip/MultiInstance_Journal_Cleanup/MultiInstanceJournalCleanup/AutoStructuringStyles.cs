﻿using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;
using OpenXmlPowerTools;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Xml;

namespace MultiInstanceJournalCleanup
{
    class AutoStructuringStyles
    {
        //public static void H1StyleApply(string newDoc, string tempH1style)
        //{
        //    //use tempervaory H1 style for logic.
        //    GlobalMethods.H1Style = ConfigurationManager.AppSettings.Get("H1Style");

        //    List<string> H1StylesColl = new List<string>();
        //    ///Configuration read from Supporting folder
        //    H1StylesColl = GlobalMethods.ReadAndStoreFileValuesInArray(GlobalMethods.H1Style);
        //    using (WordprocessingDocument WPD = WordprocessingDocument
        //        .Open(newDoc, true))
        //    {
        //        MainDocumentPart MDP = WPD.MainDocumentPart;

        //        Document D = MDP.Document;

        //        foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
        //        {
        //            if (P != null && P.InnerText != "")
        //            {
        //                string a = P.InnerText.ToLower();

        //                for (int i = 0; i < H1StylesColl.Count; i++)
        //                {
        //                    if (H1StylesColl[i].ToLower().Trim() == a.Trim() || H1StylesColl[i].ToLower().Trim() + ":" == a.Trim()) //Developer Name:Priyanka Vishwakarma, Date:5-10-2021, Add condition for match heading1 text.
        //                    {
        //                        if (P.ParagraphProperties != null)
        //                        {
        //                            if (P.ParagraphProperties.ParagraphStyleId != null)
        //                            {
        //                                if (P.ParagraphProperties.ParagraphStyleId.Val != "KYWD")   //Developer name:Priyanka Vishwakarma ,Date:13_09_2019 ,Requirement:apply KYWD style if it comes after Keywords paragraph in word document not apply h1 paragraph style ,Integrated by:Vikas sir.
        //                                {
        //                                    P.ParagraphProperties.ParagraphStyleId.Val = "H1";
        //                                }
        //                            }
        //                            else
        //                            {
        //                                P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "H1" };
        //                            }
        //                        }
        //                        else
        //                        {
        //                            P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "H1" });
        //                        }
        //                    }
        //                }
        //            }
        //        }
        //        D.Save();
        //    }
        //}


        public static void H1StyleApply(string newDoc, string tempH1style)
        {
            //use tempervaory H1 style for logic.
            GlobalMethods.H1Style = ConfigurationManager.AppSettings.Get("H1Style");

            List<string> H1StylesColl = new List<string>();
            ///Configuration read from Supporting folder
            H1StylesColl = GlobalMethods.ReadAndStoreFileValuesInArray(GlobalMethods.H1Style);
            using (WordprocessingDocument WPD = WordprocessingDocument
                .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(x => x.InnerText.Length < 50))
                {
                    if (P.Parent != null && P.Parent.LocalName != "tc") //Developer Name:Priyanka Vishwakarma, Date:14-12-2021, Reqiurement:Add condition for void table para
                    {
                        if (P != null && P.InnerText != "")
                        {
                            string a = P.InnerText.ToLower();
                            a = a.Replace(" ", "").Replace("-", "").Replace(":", "").Replace(".", "").Replace("?", "");
                            a = Regex.Replace(a.Trim(), @"^([0-9]+)", "").Trim();
                            for (int i = 0; i < H1StylesColl.Count; i++)
                            {
                                string retValMatch = matchHeadingPara(a.ToLower(), H1StylesColl[i].ToLower().Trim());
                                if (retValMatch == "0")
                                {
                                    if (P.ParagraphProperties != null)
                                    {
                                        if (P.ParagraphProperties.ParagraphStyleId != null)
                                        {
                                            if (P.ParagraphProperties.ParagraphStyleId.Val != "KYWD" && P.ParagraphProperties.ParagraphStyleId.Val != "DT" && P.ParagraphProperties.ParagraphStyleId.Val != "AB")   //Developer name:Priyanka Vishwakarma ,Date:13_09_2019 ,Requirement:apply KYWD style if it comes after Keywords paragraph in word document not apply h1 paragraph style ,Integrated by:Vikas sir.
                                            {
                                                P.ParagraphProperties.ParagraphStyleId.Val = "H1";
                                            }
                                        }
                                        else
                                        {
                                            P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "H1" };
                                        }
                                    }
                                    else
                                    {
                                        P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "H1" });
                                    }
                                }
                                else if (retValMatch == "-1")
                                {
                                    continue;
                                }
                                else
                                {
                                    if (P.ParagraphProperties != null)
                                    {
                                        if (P.ParagraphProperties.ParagraphStyleId != null)
                                        {
                                            if (P.ParagraphProperties.ParagraphStyleId.Val != "KYWD" && P.ParagraphProperties.ParagraphStyleId.Val != "DT" && P.ParagraphProperties.ParagraphStyleId.Val != "AB")
                                            {
                                                P.ParagraphProperties.ParagraphStyleId.Val = "H1";

                                                //Add Query
                                            }
                                        }
                                        else
                                        {
                                            P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "H1" };
                                            //Add Query
                                        }
                                    }
                                    else
                                    {
                                        P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "H1" });
                                        //Add Query
                                    }



                                    //Comment Add Part
                                    Comments comments = null;
                                    string id = "0";

                                    // Verify that the document contains a 
                                    // WordProcessingCommentsPart part; if not, add a new one.
                                    if (D.MainDocumentPart.GetPartsCountOfType<WordprocessingCommentsPart>() > 0)
                                    {
                                        comments = D.MainDocumentPart.WordprocessingCommentsPart.Comments;

                                        if (comments.HasChildren)
                                        {
                                            // Obtain an unused ID.
                                            id = (comments.Descendants<Comment>().Select(e => int.Parse(e.Id.Value)).Max() + 1).ToString();
                                        }
                                    }
                                    else
                                    {
                                        // No WordprocessingCommentsPart part exists, so add one to the package.
                                        WordprocessingCommentsPart commentPart =
                                            D.MainDocumentPart.AddNewPart<WordprocessingCommentsPart>();
                                        commentPart.Comments = new Comments();
                                        comments = commentPart.Comments;
                                        //if (commentPart != null && commentPart.Comments != null)
                                        //{
                                        //    var commentList = commentPart.Comments.ToList();
                                        //}
                                    }

                                    foreach (var PS in P.Descendants().ToList().Where(x => x.XName == W.commentRangeStart).ToList())
                                    {
                                        var commentRangeStartText = PS.NextSibling().InnerText.Trim();
                                        if (commentRangeStartText.Contains(retValMatch))
                                        {
                                            continue;
                                        }

                                    }
                                    // Compose a new Comment and add it to the Comments part.
                                    Paragraph p = new Paragraph();
                                    Run r1 = new Run();
                                    r1.RunProperties = new RunProperties(new RunStyle { Val = "CommentReference" });
                                    AnnotationReferenceMark an = new AnnotationReferenceMark();
                                    r1.AppendChild(an);
                                    p.AppendChild(r1);
                                    Run r2 = new Run(new Text(retValMatch));
                                    p.AppendChild(r2);
                                    p.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "CommentText" });
                                    Comment cmt =
                                        new Comment()
                                        {
                                            Initials = "AU",
                                            Author = "Author Query",
                                            Id = id,
                                            Date = DateTime.Now
                                        };
                                    cmt.AppendChild(p);
                                    comments.AppendChild(cmt);
                                    comments.Save();

                                    // Specify the text range for the Comment. 
                                    // Insert the new CommentRangeStart before the first run of paragraph.
                                    P.InsertBefore(new CommentRangeStart()
                                    { Id = id }, P.GetFirstChild<Run>());

                                    // Insert the new CommentRangeEnd after last run of paragraph.
                                    var cmtEnd = P.InsertAfter(new CommentRangeEnd()
                                    { Id = id }, P.Elements<Run>().Last());

                                    // Compose a run with CommentReference and insert it.
                                    P.InsertAfter(new Run(new CommentReference() { Id = id }), cmtEnd);
                                    //End comment 
                                    goto nextPara;
                                }
                            }
                        }
                    }
                    nextPara: { }
                }
                D.Save();
            }
        }
        public static void H1StyleApplySage(string newDoc, string tempH1style)
        {
            //use tempervaory H1 style for logic.
            GlobalMethods.H1Style = ConfigurationManager.AppSettings.Get("H1Style");

            List<string> H1StylesColl = new List<string>();
            ///Configuration read from Supporting folder
            H1StylesColl = GlobalMethods.ReadAndStoreFileValuesInArray(GlobalMethods.H1Style);
            using (WordprocessingDocument WPD = WordprocessingDocument
                .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(x => x.InnerText.Length < 50))
                {
                    if (P.Parent != null && P.Parent.LocalName != "tc") //Developer Name:Priyanka Vishwakarma, Date:14-12-2021, Reqiurement:Add condition for void table para
                    {
                        if (P != null && P.InnerText != "")
                        {
                            string a = P.InnerText.ToLower();
                            a = a.Replace(" ", "").Replace("-", "").Replace(":", "").Replace(".", "").Replace("?", "");
                            a = Regex.Replace(a.Trim(), @"^([0-9]+)", "").Trim();
                            for (int i = 0; i < H1StylesColl.Count; i++)
                            {
                                string retValMatch = matchHeadingPara(a.ToLower(), H1StylesColl[i].ToLower().Trim());
                                if (retValMatch == "0")
                                {
                                    if (P.ParagraphProperties != null)
                                    {
                                        if (P.ParagraphProperties.ParagraphStyleId != null)
                                        {
                                            if (P.ParagraphProperties.ParagraphStyleId.Val != "KYWD" && P.ParagraphProperties.ParagraphStyleId.Val != "DT" && P.ParagraphProperties.ParagraphStyleId.Val != "AB")   //Developer name:Priyanka Vishwakarma ,Date:13_09_2019 ,Requirement:apply KYWD style if it comes after Keywords paragraph in word document not apply h1 paragraph style ,Integrated by:Vikas sir.
                                            {
                                                P.ParagraphProperties.ParagraphStyleId.Val = "H1";
                                            }
                                        }
                                        else
                                        {
                                            P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "H1" };
                                        }
                                    }
                                    else
                                    {
                                        P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "H1" });
                                    }
                                }
                                else if (retValMatch == "-1")
                                {
                                    continue;
                                }
                                else
                                {
                                    if (P.ParagraphProperties != null)
                                    {
                                        if (P.ParagraphProperties.ParagraphStyleId != null)
                                        {
                                            if (P.ParagraphProperties.ParagraphStyleId.Val != "KYWD" && P.ParagraphProperties.ParagraphStyleId.Val != "DT" && P.ParagraphProperties.ParagraphStyleId.Val != "AB")
                                            {
                                                P.ParagraphProperties.ParagraphStyleId.Val = "H1";

                                                //Add Query
                                            }
                                        }
                                        else
                                        {
                                            P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "H1" };
                                            //Add Query
                                        }
                                    }
                                    else
                                    {
                                        P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "H1" });
                                        //Add Query
                                    }

                                    goto nextPara;
                                }
                            }
                        }
                    }
                nextPara: { }
                }
                D.Save();
            }
        }

        public static string matchHeadingPara(string strSource, string strMatch)
        {
            string RetVal = "-1";
            if (strSource.Trim().Length == 1 || strSource.Trim() == "") //Developer Name:Priyanka Vishwakarma, Date:7-1-2022,add condition for avoid blan para when it contains only dot or dash
            {
                RetVal = "-1";
                return RetVal;
            }
            string[] Arr = new string[strSource.Length - 2];
            for (int x = 0; x < strSource.Length - 2; x++)
            {
                Arr[x] = strSource.Substring(x, 3);
                // Console.WriteLine(Arr[x]);
            }

            bool fnd = false;
            int matchVal = 0;
            for (int x = 0; x < strSource.Length - 2; x++)
            {
                if (strMatch.Replace(" ", "").Replace("-", "").Replace(":", "").Replace(".", "").Replace("?", "").ToLower().Contains(Arr[x].ToLower()))
                    matchVal++;
            }

            if (matchVal==0 && Arr.Length==0)
            {
                RetVal = "-1";

            }
            else if (matchVal == Arr.Length)
            {
                RetVal = "0";
            }
            else if (matchVal >= Arr.Length / 2)
            {
                float f = ((float)matchVal / (float)Arr.Length) * (float)100;
                //Console.WriteLine("Partial Match: Score" + f);
                if (f > 60)
                {
                    RetVal = "Please check the heading content, it matches with \"" + strMatch + "\"";
                }
                else
                {
                    RetVal = "-1";
                }
            }
            else
            {
                RetVal = "-1";
            }


            return RetVal;
        }
        public static string matchREFHeadingPara(string strSource, string strMatch)
        {
            string RetVal = "-1";
            if (strSource.Trim().Length == 1 || strSource.Trim() == "") //Developer Name:Priyanka Vishwakarma, Date:7-1-2022,add condition for avoid blan para when it contains only dot or dash
            {
                RetVal = "-1";
                return RetVal;
            }
            string[] Arr = new string[strSource.Length - 2];
            for (int x = 0; x < strSource.Length - 2; x++)
            {
                Arr[x] = strSource.Substring(x, 3);
                // Console.WriteLine(Arr[x]);
            }

            bool fnd = false;
            int matchVal = 0;
            for (int x = 0; x < strSource.Length - 2; x++)
            {
                if (strMatch.Replace(" ", "").Replace("-", "").Replace(":", "").Replace(".", "").Replace("?", "").ToLower().Contains(Arr[x].ToLower()))
                    matchVal++;
            }
            if (matchVal == 0 && Arr.Length == 0)
            {
                RetVal = "-1";

            }
            else if (matchVal == Arr.Length)
            {
                RetVal = "0";
            }
            else if (matchVal >= Arr.Length / 2)
            {
                float f = ((float)matchVal / (float)Arr.Length) * (float)100;
                //Console.WriteLine("Partial Match: Score" + f);
                if (f > 60)
                {
                    RetVal = "Please check the Reference heading content, it matches with \"" + strMatch + "\"";
                }
                else
                {
                    RetVal = "-1";
                }
            }
            else
            {
                RetVal = "-1";
            }


            return RetVal;
        }

        public static string matchDTPara(string strSource, string strMatch)
        {
            string RetVal = "-1";
            if (strSource.Trim().Length == 1 || strSource.Trim() == "") //Developer Name:Priyanka Vishwakarma, Date:7-1-2022,add condition for avoid blan para when it contains only dot or dash
            {
                RetVal = "-1";
                return RetVal;
            }
            string[] Arr = new string[strSource.Length - 2];
            for (int x = 0; x < strSource.Length - 2; x++)
            {
                Arr[x] = strSource.Substring(x, 3);
                //Console.WriteLine(Arr[x]);
            }

            bool fnd = false;
            int matchVal = 0;
            for (int x = 0; x < strSource.Length - 2; x++)
            {
                if (strMatch.ToLower().Replace(" ", "").Replace("-", "").Replace(":", "").Replace(".", "").Replace("?", "").Contains(Arr[x].ToLower()))
                    matchVal++;
            }
            if (matchVal == 0 && Arr.Length == 0)
            {
                RetVal = "-1";

            }
            else  if (matchVal == Arr.Length)
            {
                RetVal = "0";
            }
            else if (matchVal >= Arr.Length / 2)
            {
                float f = ((float)matchVal / (float)Arr.Length) * (float)100;
                //Console.WriteLine("Partial Match: Score" + f);
                if (f > 60)
                {
                    RetVal = "Please check the Article Type content, it matches with \"" + strMatch + "\"";
                }
                else
                {
                    RetVal = "-1";
                }
            }
            else
            {
                RetVal = "-1";
            }


            return RetVal;
        }

        public static void H1StyleApplyold(string newDoc, string tempH1style)
        {
            //use tempervaory H1 style for logic.
            GlobalMethods.H1Style = ConfigurationManager.AppSettings.Get("H1Style");

            List<string> H1StylesColl = new List<string>();
            ///Configuration read from Supporting folder
            H1StylesColl = GlobalMethods.ReadAndStoreFileValuesInArray(GlobalMethods.H1Style);
            using (WordprocessingDocument WPD = WordprocessingDocument
                .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P != null && P.InnerText != "")
                    {
                        string a = P.InnerText.ToLower();

                        for (int i = 0; i < H1StylesColl.Count; i++)
                        {
                            if (H1StylesColl[i].ToLower().Trim() == a.Trim()) //Developer Name:Priyanka Vishwakarma, Date:5-10-2021, Add condition for match heading1 text.
                            {
                                if (P.ParagraphProperties != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId != null)
                                    {
                                        if (P.ParagraphProperties.ParagraphStyleId.Val != "KYWD")   //Developer name:Priyanka Vishwakarma ,Date:13_09_2019 ,Requirement:apply KYWD style if it comes after Keywords paragraph in word document not apply h1 paragraph style ,Integrated by:Vikas sir.
                                        {
                                            P.ParagraphProperties.ParagraphStyleId.Val = "H1";
                                        }
                                    }
                                    else
                                    {
                                        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "H1" };
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "H1" });
                                }
                            }
                        }
                    }
                }
                D.Save();
            }
        }

        public static void Master_Style_Mapping(string newDoc, string AutoStructringstyles)
        {
            List<string> strStyles = new List<string>();
            string newstr = ConfigurationManager.AppSettings.Get("StyleAutostrcuturing");
            strStyles = GlobalMethods.ReadAndStoreFileValuesInArray(newstr);

            for (int i = 0; i < strStyles.Count; i++)
            {
                string newstr1 = strStyles[i];
                string[] separators = { "|" };
                string[] links = newstr1.Split(separators, StringSplitOptions.None);
                string input = "";
                if (links[1] != null && links[1] != "")
                {
                    input = links[1].ToLower();

                }
                switch (input)
                {
                    case "afflstyle":
                        Affl_StyleApplied(newDoc);
                        break;

                    case "corrstyle":
                        Corr_StyleApplied(newDoc);
                        break;

                    case "crstyle":
                        Cr_StyleApplied(newDoc);
                        break;

                    case "uidstyle":
                        Uid_StyleApplied(newDoc);
                        break;

                    case "rrhstyle":
                        if (GlobalMethods.strClientName.ToLower() != "ufl")  //Developer Name:Priyanka Vishwakarma,Date:22-09-2020,Requirement:add conditon for avoid to apply RRH using Authoe name for ufl input
                        {
                           //Danuuuuuuuuuuuuuuuuuuuuuuu Rrh_StyleApplied(newDoc);05-10-2023
                        }
                        break;

                    case "dtstyle":
                        if (GlobalMethods.strClientName.ToLower() == "sage" && GlobalMethods.strCopyediting == "true" && !GlobalMethods.strJournalArticlePath.Contains("\\India\\"))//Developer Name:Priyanka Vishwakarma Date:31-05-2021,Requiremnt :Add condition for avoid to apply paragraph style to structured document.
                        {
                            Dt_StyleApplied(newDoc);
                        }
                        break;

                    case "tistyle":
                        Ti_StyleApplied(newDoc);
                        break;

                    case "austyle":
                        Au_StyleApplied(newDoc);
                        break;

                    case "abstyle":
                        Ab_StyleApplied(newDoc);
                        break;

                    case "abtxtstyle":
                        if (GlobalMethods.strClientName.ToLower() != "ufl"/*&& GlobalMethods.strClientName.ToLower() != "sage"*/)  //Developer Name:Priyanka Vishwakarma,Date:21-09-2020 ,Requirement:Add condition for avoid to apply AB-TXT para style for UFL inputs
                        {
                            Abtxt_StyleApplied(newDoc);
                        }
                        break;

                    case "ackstyle":
                        if (GlobalMethods.strClientName.ToLower() != "ssllc") //Developer Name:Priyanka Vishwakarma, Date:7-2-2022, add condition for avoid to apply ACK in ssllc 
                        {
                            ack_StyleApplied(newDoc);       //Developer Name:Priyanka Vishwakarma ,Date:20_5_2019 ,Requirement:Apply ACK style for Acknowledgement Heading Para ,Integrated By:Vikas sir 
                        }
                        break;

                    case "acktxtstyle":
                        if (GlobalMethods.strClientName.ToLower() != "ssllc")
                        {
                            ACKtxt_StyleApplied(newDoc);   //Developer Name:Priyanka Vishwakarma ,Date:20_5_2019 ,Requirement:Apply ACK-TXT style for Acknowledgement Para ,Integrated By:Vikas sir 
                        }
                        break;

                    case "kywdstyle":
                        if (GlobalMethods.strClientName.ToLower() != "sage")  //Developer Name:Priyanka Vishwakarma,Date:21-09-2020 ,Requirement:Add condition for avoid to apply AB-TXT para style for UFL inputs
                        {
                            if (GlobalMethods.strClientName.ToLower() == "jaypee" || GlobalMethods.strClientName.ToLower() == "ssllc" || GlobalMethods.strClientName.ToLower() == "pps")
                            {
                                Kywd_StyleAppliedForJaypee(newDoc);
                            }
                            else
                            {
                                Kywd_StyleApplied(newDoc);
                            }
                        }

                        break;

                    case "h1style":
                        H1_StyleApplied(newDoc);
                        break;

                    case "txtstyle":
                        if (GlobalMethods.strClientName.ToLower() == "sage" && GlobalMethods.strCopyediting == "true" && !GlobalMethods.strJournalArticlePath.Contains("\\India\\"))//Developer Name:Priyanka Vishwakarma Date:31-05-2021,Requiremnt :Add condition for avoid to apply paragraph style to structured document.
                        {
                            Txt_StyleApplied(newDoc);
                        }
                        break;

                    case "h2style":
                        H2_StyleApplied(newDoc);
                        break;

                    case "txt2style":
                        if (GlobalMethods.strClientName.ToLower() == "sage" && GlobalMethods.strCopyediting == "true" && !GlobalMethods.strJournalArticlePath.Contains("\\India\\"))//Developer Name:Priyanka Vishwakarma Date:31-05-2021,Requiremnt :Add condition for avoid to apply paragraph style to structured document.
                        {
                            Txt2_StyleApplied(newDoc);
                        }
                        break;

                    case "refstyle":
                        Ref_StyleApplied(newDoc);
                        REFStyle(newDoc);
                        break;

                    case "ref1style":

                        if (GlobalMethods.strClientName.ToLower() == "informs")
                        {
                            Ref1_StyleAppliedINF(newDoc);
                        }
                        else if (GlobalMethods.strClientName.ToLower() == "ufl")
                        {
                            Ref1_StyleAppliedflow(newDoc);
                        }
                        else
                        {
                            Ref1_StyleApplied(newDoc);
                        }
                        break;

                    case "figstyle":
                        Fig_StyleApplied(newDoc);
                        break;


                    case "ttstyle":

                        Tt_StyleApplied(newDoc);
                        break;

                    case "tfnstyle":
                        if (GlobalMethods.strClientName.ToLower() == "thieme")
                        {
                            Tfn_StyleApplied(newDoc);
                            TFN_StyleAppliedBasisofText(newDoc);//20-04-2021
                        }
                        break;

                    case "h5style":
                        H5_StyleApplied(newDoc);
                        break;

                    case "ulstyle":
                        Ul_StyleApplied(newDoc);
                        break;

                    case "extau":
                        extAu_styleApplied(newDoc);
                        break;
                }
            }
        }

        public static void Affl_StyleApplied(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {


                    //Developer name:Priyanka Vishwakarma ,Date:03-04-2020  Requirement:Avoid to Apply AFFL paragraph style After CORR or DT paragraph style . Integrated by:Vikas sir.
                    if (P != null && P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val != "TFN")
                    {
                        if ((GlobalMethods.strClientName.ToLower() != "jaypee" && GlobalMethods.strClientName.ToLower() != "ssllc" && GlobalMethods.strClientName.ToLower() != "pps") && (P.ParagraphProperties.ParagraphStyleId.Val.Value == "CORR" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "DT")) //Developer name:Priyanka Vishwakarma ,Date:  Requirement:Avoid to Apply AFFL paragraph style After CORR or DT paragraph style . Integrated by:Vikas sir.
                        {
                            break;
                        }

                        else if ((GlobalMethods.strClientName.ToLower() == "jaypee" || GlobalMethods.strClientName.ToLower() == "ssllc" || GlobalMethods.strClientName.ToLower() == "ufl"|| GlobalMethods.strClientName.ToLower() == "pps") && (P.ParagraphProperties.ParagraphStyleId.Val.Value == "CORR" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "AB" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "KYWD")) //Developer name:Priyanka Vishwakarma ,Date:31-08-2021  Requirement:Avoid to Apply AFFL paragraph style After CORR or AB or KYWD paragraph style 
                        {
                            break;
                        }
                    }
                    //----------------End on 03-04-2020 ----------------------------


                    if (P != null)
                    {
                        if (P.Descendants<Run>().Count() != 0)
                        {
                            Run R = P.Descendants<Run>().First();
                            if (R != null)
                            {
                                foreach (OpenXmlElement ox in R.Elements())
                                {
                                    if (ox.XName == W.rPr)
                                    {
                                        if (ox.HasChildren)
                                        {
                                            foreach (OpenXmlElement ox1 in ox.Elements())
                                            {
                                                if (ox1.XName == W.vertAlign)
                                                {
                                                    if (ox1.HasAttributes)
                                                    {
                                                        foreach (var item in ox1.GetAttributes())
                                                        {
                                                            if (item.Value == "superscript")
                                                            {
                                                                if (P.ParagraphProperties != null)
                                                                {
                                                                    if (P.ParagraphProperties.ParagraphStyleId != null)
                                                                    {
                                                                        if (P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val != "TFN")  //Developer name:priyanka Vishwakarma ,Date:11_09_2019 ,Requirement:apply TFN style to paragraph after table in word document. ,Integrated By:Vikas sir.
                                                                        {
                                                                            P.ParagraphProperties.ParagraphStyleId.Val.Value = "AFFL";
                                                                            ;
                                                                        }
                                                                    }
                                                                    else
                                                                    {
                                                                        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "AFFL" };
                                                                    }
                                                                }
                                                                else
                                                                {
                                                                    P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "AFFL" });
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                D.Save();
            }
        }

        public static void Corr_StyleApplied(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P != null)
                    {
                        if (P.InnerText.Trim().ToLower().StartsWith("address for correspondence") || P.InnerText.Trim().ToLower().StartsWith("corresponding author:")) //Developer Name:Priyanka Vishwakarma, Date:30-09-2021, Requirement: add condition for apply corr para for jaypee input
                        {
                            if (P.ParagraphProperties != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null)
                                {
                                    P.ParagraphProperties.ParagraphStyleId.Val = "CORR";
                                }
                                else
                                {
                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "CORR" };
                                }
                            }
                            else
                            {
                                P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "CORR" });

                            }
                        }
                    }
                }
                D.Save();
            }
        }

        public static void Cr_StyleApplied(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P.InnerText.Contains("©"))
                    {
                        string copyrightwithyear = P.InnerText;
                        string a = After(copyrightwithyear, "©");
                        if (a != "")
                        {
                            string sub = a.TrimStart().Substring(0, 4);

                            try
                            {
                                int i = Convert.ToInt32(sub);

                                if (P.ParagraphProperties != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId != null)
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val = "CR";
                                    }
                                    else
                                    {
                                        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "CR" };
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "CR" });
                                }
                            }
                            catch (Exception ex)
                            {
                                continue;
                            }
                        }

                    }
                }
                D.Save();
            }
        }

        public static string After(string value, string a)
        {
            int posA = value.LastIndexOf(a);
            if (posA == -1)
            {
                return "";
            }
            int adjustedPosA = posA + a.Length;
            if (adjustedPosA >= value.Length)
            {
                return "";
            }

            return value.Substring(adjustedPosA);
        }

        public static void Uid_StyleApplied(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P.InnerText.TrimStart().ToLower().StartsWith("received") || P.InnerText.TrimStart().ToLower().StartsWith("doi")
                        || P.InnerText.TrimStart().ToLower().StartsWith("accepted") || P.InnerText.TrimStart().ToLower().StartsWith("issn"))
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val = "UID";
                            }
                            else
                            {
                                P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "UID" };
                            }
                        }
                        else
                        {
                            P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "UID" });
                        }
                    }
                }
                D.Save();
            }
        }

        ///string use globaly because authore name use in multiple method.
        static string matchauthorename = null;
        static string matchauthorenameForAU = null; //Developer Name:priyanka Vishwakarma ,Date:15_5_2019 ,Requirement:Author name match with Corrfullname for apply AU  ,Integrated By:Vikas sir

        public static void Rrh_StyleApplied(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                bool corrstyle = false;
                List<string> authorSurnameList = new List<string>();  //Developer Name:priyanka Vishwakarma ,Date:15_5_2019 ,Requirement:Create list of author for apply RRH style  ,Integrated By:Vikas sir

                //matchauthorename = null;
                //foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                //{
                //    if (P.ParagraphProperties != null)
                //    {
                //        if (P.ParagraphProperties.ParagraphStyleId != null)
                //        {
                //            if (P.ParagraphProperties.ParagraphStyleId.Val.Value == "CORR")
                //            {
                //                corrstyle = true;
                //                string match = P.InnerText;
                //                matchauthorename = match.Split(',')[0].Split(' ').Last();
                //                break;
                //            }
                //        }
                //    }
                //}


                //----Developer Name:priyanka Vishwakarma ,Date:15_5_2019 ,Requirement:Create list of author for apply RRH style  ,Integrated By:Vikas sir
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P.ParagraphProperties != null)
                    {
                        if (P.ParagraphProperties.ParagraphStyleId != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId.Val.Value == "AU")
                            {
                                corrstyle = true;
                                string match = P.InnerText;
                                string[] authorNameList = match.Split(',');
                                for (int i = 0; i < authorNameList.Count(); i++)
                                {
                                    string auSurname = match.Split(',')[i].Split(' ').Last();
                                    auSurname = Regex.Replace(auSurname, "[0-9]", "", RegexOptions.IgnoreCase);
                                    if (auSurname.Trim() != "")
                                    {
                                        authorSurnameList.Add(auSurname);
                                    }

                                }

                                break;
                            }
                        }
                    }
                }

                //------------------------end by priyanka--------------------------

                if (corrstyle)
                {
                    foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                    {
                        //if ((P.InnerText.Contains("//" + matchauthorename) || P.InnerText.Contains("/" + matchauthorename)) && !P.InnerText.Trim().ToLower().StartsWith("address for correspondence") && corrstyle == true)
                        //{
                        //    corrstyle = false;
                        //    if (P.ParagraphProperties != null)
                        //    {
                        //        if (P.ParagraphProperties.ParagraphStyleId != null)
                        //        {
                        //            P.ParagraphProperties.ParagraphStyleId.Val = "RRH";
                        //        }
                        //        else
                        //        {
                        //            P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "RRH" };
                        //        }
                        //    }
                        //    else
                        //    {
                        //        P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "RRH" });
                        //    }
                        //}
                        if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != "RRH")  //if paragraph have RRH style then do not need to change it
                         {
                            //foreach (var auSurname in authorSurnameList.ToList())   //Developer Name:priyanka Vishwakarma ,Date:15_5_2019 ,Requirement:Create list of author for apply RRH style  ,Integrated By:Vikas sir 
                            //{

                            if ((authorSurnameList.ToList().Any(auSurname => P.InnerText.Contains("//" + auSurname)) || authorSurnameList.ToList().Any(auSurname => P.InnerText.Contains("/" + auSurname))) && !P.InnerText.Trim().ToLower().StartsWith("address for correspondence") && corrstyle == true)//Developer Name:priyanka Vishwakarma ,Date:15_5_2019 ,Requirement:Create list of author for apply RRH style  ,Integrated By:Vikas sir 
                            {
                                corrstyle = false;
                                if (P.ParagraphProperties != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId != null)
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val = "RRH";
                                        break;
                                    }
                                    else
                                    {
                                        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "RRH" };
                                        break;
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "RRH" });
                                    break;
                                }
                            }
                            //}    //foreach Close.
                        }

                    }
                }
                D.Save();
            }
        }
        public static void Dt_StyleApplied(string newDoc)
        {
            GlobalMethods.DTStyle = ConfigurationManager.AppSettings.Get("DTStyle");

            List<string> DTStyleColl = new List<string>();
            ///Configuration read from Supporting folder
            DTStyleColl = GlobalMethods.ReadAndStoreFileValuesInArray(GlobalMethods.DTStyle);
            using (WordprocessingDocument WPD = WordprocessingDocument
                .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(x => x.InnerText.Length < 50))
                {
                    if (P != null && P.InnerText != "")
                    {
                        if (P.Parent != null && P.Parent.LocalName != "tc") //Developer Name:Priyanka Vishwakarma, Date:14-12-2021, Reqiurement:Add condition for void table para
                        {
                            string a = P.InnerText.ToLower();
                            a = a.Replace(" ", "").Replace("-", "").Replace(":", "").Replace(".", "").Replace("?", "");
                            for (int i = 0; i < DTStyleColl.Count; i++)
                            {
                                string retValMatch = matchDTPara(a.ToLower(), DTStyleColl[i].ToLower().Trim().Replace(" ", "").Replace("-", "").Replace(":", "").Replace(".", "").Replace("?", ""));
                                if (retValMatch == "0")
                                {
                                    if (P.ParagraphProperties != null)
                                    {
                                        if (P.ParagraphProperties.ParagraphStyleId != null)
                                        {
                                            P.ParagraphProperties.ParagraphStyleId.Val = "DT";
                                        }
                                        else
                                        {
                                            P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "DT" };
                                        }
                                    }
                                    else
                                    {
                                        P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "DT" });
                                    }
                                    goto nextFunction;
                                }
                                else if (retValMatch == "-1")
                                {
                                    continue;
                                }
                                else
                                {
                                    if (P.ParagraphProperties != null)
                                    {
                                        if (P.ParagraphProperties.ParagraphStyleId != null)
                                        {
                                            P.ParagraphProperties.ParagraphStyleId.Val = "DT";
                                        }
                                        else
                                        {
                                            P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "DT" };
                                        }
                                    }
                                    else
                                    {
                                        P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "DT" });
                                    }

                                    //Comment Add Part
                                    Comments comments = null;
                                    string id = "0";

                                    // Verify that the document contains a 
                                    // WordProcessingCommentsPart part; if not, add a new one.
                                    if (D.MainDocumentPart.GetPartsCountOfType<WordprocessingCommentsPart>() > 0)
                                    {
                                        comments =
                                            D.MainDocumentPart.WordprocessingCommentsPart.Comments;
                                        if (comments.HasChildren)
                                        {
                                            // Obtain an unused ID.
                                            id = (comments.Descendants<Comment>().Select(e => int.Parse(e.Id.Value)).Max() + 1).ToString();
                                        }
                                    }
                                    else
                                    {
                                        // No WordprocessingCommentsPart part exists, so add one to the package.
                                        WordprocessingCommentsPart commentPart =
                                            D.MainDocumentPart.AddNewPart<WordprocessingCommentsPart>();
                                        commentPart.Comments = new Comments();
                                        comments = commentPart.Comments;
                                    }
                                    foreach (var PS in P.Descendants().ToList().Where(x => x.XName == W.commentRangeStart).ToList())
                                    {
                                        var commentRangeStartText = PS.NextSibling().InnerText.Trim();
                                        if (commentRangeStartText.Contains(retValMatch))
                                        {
                                            goto nextFunction;
                                        }

                                    }
                                    // Compose a new Comment and add it to the Comments part.
                                    Paragraph p = new Paragraph();
                                    Run r1 = new Run();
                                    r1.RunProperties = new RunProperties(new RunStyle { Val = "CommentReference" });
                                    AnnotationReferenceMark an = new AnnotationReferenceMark();
                                    r1.AppendChild(an);
                                    p.AppendChild(r1);
                                    Run r2 = new Run(new Text(retValMatch));
                                    p.AppendChild(r2);
                                    p.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "CommentText" });
                                    Comment cmt =
                                        new Comment()
                                        {
                                            Initials="AU",
                                            Author = "Author Query",
                                            Id = id,
                                            Date = DateTime.Now
                                        };
                                    cmt.AppendChild(p);
                                    comments.AppendChild(cmt);
                                    comments.Save();

                                    // Specify the text range for the Comment. 
                                    // Insert the new CommentRangeStart before the first run of paragraph.
                                    P.InsertBefore(new CommentRangeStart()
                                    { Id = id }, P.GetFirstChild<Run>());

                                    // Insert the new CommentRangeEnd after last run of paragraph.
                                    var cmtEnd = P.InsertAfter(new CommentRangeEnd()
                                    { Id = id }, P.Elements<Run>().Last());

                                    // Compose a run with CommentReference and insert it.
                                    P.InsertAfter(new Run(new CommentReference() { Id = id }), cmtEnd);
                                    //End comment                              
                                    goto nextFunction;  
                                }
                            }
                        }
                    }
                }
            nextFunction: { }
                D.Save();
            }
        }
        public static void Dt_StyleAppliedSage(string newDoc)
        {
            GlobalMethods.DTStyle = ConfigurationManager.AppSettings.Get("DTStyle");

            List<string> DTStyleColl = new List<string>();
            ///Configuration read from Supporting folder
            DTStyleColl = GlobalMethods.ReadAndStoreFileValuesInArray(GlobalMethods.DTStyle);
            using (WordprocessingDocument WPD = WordprocessingDocument
                .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(x => x.InnerText.Length < 50))
                {
                    if (P != null && P.InnerText != "")
                    {
                        if (P.Parent != null && P.Parent.LocalName != "tc") //Developer Name:Priyanka Vishwakarma, Date:14-12-2021, Reqiurement:Add condition for void table para
                        {
                            string a = P.InnerText.ToLower();
                            a = a.Replace(" ", "").Replace("-", "").Replace(":", "").Replace(".", "").Replace("?", "");
                            for (int i = 0; i < DTStyleColl.Count; i++)
                            {
                                string retValMatch = matchDTPara(a.ToLower(), DTStyleColl[i].ToLower().Trim().Replace(" ", "").Replace("-", "").Replace(":", "").Replace(".", "").Replace("?", ""));
                                if (retValMatch == "0")
                                {
                                    if (P.ParagraphProperties != null)
                                    {
                                        if (P.ParagraphProperties.ParagraphStyleId != null)
                                        {
                                            P.ParagraphProperties.ParagraphStyleId.Val = "DT";
                                        }
                                        else
                                        {
                                            P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "DT" };
                                        }
                                    }
                                    else
                                    {
                                        P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "DT" });
                                    }
                                    goto nextFunction;
                                }
                                else if (retValMatch == "-1")
                                {
                                    continue;
                                }
                                else
                                {
                                    if (P.ParagraphProperties != null)
                                    {
                                        if (P.ParagraphProperties.ParagraphStyleId != null)
                                        {
                                            P.ParagraphProperties.ParagraphStyleId.Val = "DT";
                                        }
                                        else
                                        {
                                            P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "DT" };
                                        }
                                    }
                                    else
                                    {
                                        P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "DT" });
                                    }
                                                              
                                    goto nextFunction;
                                }
                            }
                        }
                    }
                }
            nextFunction: { }
                D.Save();
            }
        }

        //public static void Dt_StyleApplied(string newDoc)
        //{
        //    GlobalMethods.DTStyle = ConfigurationManager.AppSettings.Get("DTStyle");

        //    List<string> DTStylesColl = new List<string>();
        //    ///Configuration read from Supporting folder
        //    DTStylesColl = GlobalMethods.ReadAndStoreFileValuesInArray(GlobalMethods.DTStyle);
        //    using (WordprocessingDocument WPD = WordprocessingDocument
        //         .Open(newDoc, true))
        //    {
        //        MainDocumentPart MDP = WPD.MainDocumentPart;
        //        Document D = MDP.Document;
        //        foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
        //        {
        //            string a = P.InnerText;
        //            //Developer name:Priyanka Vishwakarma ,Date:31-01-2020 ,Requirement:After TI ,AU ,or KYWD paragraph style avoid to apply DT Paragraph style which heading match with DT style List from Supporting file..
        //            if (P.InnerText != null && P.InnerText != "")
        //            {
        //                if (P.ParagraphProperties != null)
        //                {
        //                    if (P.ParagraphProperties.ParagraphStyleId != null)
        //                    {
        //                        if (P.ParagraphProperties.ParagraphStyleId.Val == "TI" && P.ParagraphProperties.ParagraphStyleId.Val == "AU" && P.ParagraphProperties.ParagraphStyleId.Val == "KYWD")
        //                        {
        //                            break;
        //                        }
        //                    }
        //                }
        //                //-----------------End-----------------------
        //                if (DTStylesColl.Contains(a.ToLower().Trim()))
        //                {
        //                    //Developer Name:Priyanka Vishwakarma, Date:04-01-2021, Requirement:Apply DT style to atricle type for UFL.
        //                    if (GlobalMethods.strClientName.ToLower() == "ufl")
        //                    {
        //                        if (P.InnerText.Trim().StartsWith("<") && P.InnerText.Trim().EndsWith(">"))
        //                        {
        //                            P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().ForEach(t => t.ToList().ForEach(txt =>
        //                            {

        //                                if (txt == P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().FirstOrDefault().FirstOrDefault())
        //                                {
        //                                    txt.Text = txt.Text.Trim().TrimStart('<');
        //                                }
        //                                if (txt == P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().LastOrDefault().LastOrDefault())
        //                                {
        //                                    txt.Text = txt.Text.Trim().TrimEnd('>');
        //                                }
        //                            })
        //                            );
        //                        }
        //                        if (P.ParagraphProperties != null)
        //                        {
        //                            if (P.ParagraphProperties.ParagraphStyleId != null)
        //                            {

        //                                P.ParagraphProperties.ParagraphStyleId.Val = "DT";
        //                                break;   ////////Developer Name:priyanka Vishwakarma ,Date:15_5_2019 ,Requirement:DT comes only one time in document but case report comes twice after apply parastyle DT break the loop,Integrated By:Vikas sir

        //                            }
        //                            else
        //                            {
        //                                P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "DT" };
        //                                break;   ////////Developer Name:priyanka Vishwakarma ,Date:15_5_2019 ,Requirement:DT comes only one time in document but case report comes twice after apply parastyle DT break the loop,Integrated By:Vikas sir

        //                            }
        //                        }
        //                        else
        //                        {
        //                            P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "DT" });
        //                            break;   ////////Developer Name:priyanka Vishwakarma ,Date:15_5_2019 ,Requirement:DT comes only one time in document but case report comes twice after apply parastyle DT break the loop,Integrated By:Vikas sir

        //                        }
        //                    }
        //                    else
        //                    {
        //                        if (P.ParagraphProperties != null)
        //                        {
        //                            if (P.ParagraphProperties.ParagraphStyleId != null)
        //                            {

        //                                P.ParagraphProperties.ParagraphStyleId.Val = "DT";
        //                                break;   ////////Developer Name:priyanka Vishwakarma ,Date:15_5_2019 ,Requirement:DT comes only one time in document but case report comes twice after apply parastyle DT break the loop,Integrated By:Vikas sir

        //                            }
        //                            else
        //                            {
        //                                P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "DT" };
        //                                break;   ////////Developer Name:priyanka Vishwakarma ,Date:15_5_2019 ,Requirement:DT comes only one time in document but case report comes twice after apply parastyle DT break the loop,Integrated By:Vikas sir

        //                            }
        //                        }
        //                        else
        //                        {
        //                            P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "DT" });
        //                            break;   ////////Developer Name:priyanka Vishwakarma ,Date:15_5_2019 ,Requirement:DT comes only one time in document but case report comes twice after apply parastyle DT break the loop,Integrated By:Vikas sir

        //                        }
        //                    }
        //                }

        //            }
        //        }
        //        D.Save();

        //    }
        //}


        ///retrun word count
        public static int CountWords1(string s)
        {
            MatchCollection collection = Regex.Matches(s, @"[\S]+");
            return collection.Count;
        }

        public static void Ti_StyleApplied(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                bool bBold = false;

                int nBold = 0;


                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    bBold = false;
                    nBold = 0;

                    if ((GlobalMethods.strClientName.ToLower() == "ufl"|| GlobalMethods.strClientName.ToLower() == "sage") && P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val.Value == "TI")  //Developer Name:Priyanka Vishwakarma,Date:23-09-2020,Requirement:ADD condition for check if already TI para exists for UFL input..
                    {
                        break;
                    }
                    

                        if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val.Value == "AU")
                    {
                        if (P.PreviousSibling() != null && P.PreviousSibling().LocalName == "p")/////////Developer Name:priyanka Vishwakarma ,Date:15_5_2019 ,Requirement:object reference null error ,Integrated By:Vikas sir
                        {
                            Paragraph checkp = (Paragraph)P.PreviousSibling();
                            if (checkp.ParagraphProperties != null && checkp.ParagraphProperties.ParagraphStyleId != null && checkp.ParagraphProperties.ParagraphStyleId.Val != "TXT-2"
                                && checkp.ParagraphProperties.ParagraphStyleId.Val != "TXT" && checkp.ParagraphProperties.ParagraphStyleId.Val != "BodyA")//Developer name:Priyanka Vishwakarma ,Date:25_09_2019 ,Requirement:Paragraph style change to  BodyA ,Intergreted by:Vikas sir.
                            {
                                foreach (Run R in checkp.Descendants<Run>().ToList())
                                {
                                    if (R != null)
                                    {
                                        foreach (RunProperties Rp in R.Descendants<RunProperties>().ToList())
                                        {
                                            if (Rp != null)
                                            {
                                                if (R.RunProperties.Bold != null && nBold == 0 && R.RunProperties.Bold.Val != "0")
                                                {
                                                    if (R.RunProperties.Bold.Val == null)
                                                    {
                                                        bBold = true;
                                                    }
                                                    else if (R.RunProperties.Bold.Val != "0")
                                                    {
                                                        bBold = true;
                                                    }
                                                    else if (R.RunProperties.Bold.Val == "0")
                                                    {
                                                        bBold = false;
                                                    }

                                                }
                                                else if (R.RunProperties.RunStyle != null)
                                                {
                                                    if (R.RunProperties.RunStyle.Val != null)
                                                    {
                                                        if (R.RunProperties.RunStyle.Val == "Strong")
                                                        {
                                                            bBold = true;
                                                        }
                                                        else
                                                        {
                                                            nBold = 1;
                                                            bBold = false;
                                                        }
                                                    }
                                                }
                                                else
                                                {
                                                    if (R.InnerText.Trim().Equals(".") || R.InnerText.Trim().Equals("-"))
                                                    {
                                                        goto next;
                                                    }
                                                    if (R.InnerText.Trim() != "")
                                                    {
                                                        bBold = false;
                                                        nBold = 1;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                next:
                                    {

                                    }
                                }
                                if (bBold)
                                {
                                    if (checkp.ParagraphProperties != null)
                                    {
                                        if (checkp.ParagraphProperties.ParagraphStyleId != null)
                                        {
                                            checkp.ParagraphProperties.ParagraphStyleId.Val = "TI";
                                        }
                                        else
                                        {
                                            checkp.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "TI" };
                                        }
                                    }
                                    else
                                    {
                                        checkp.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "TI" });
                                    }
                                }
                            }
                            /////////Developer Name:priyanka Vishwakarma ,Date:15_5_2019 ,Requirement:AU style Paragraph's Previous Paragraph should be TI ,Integrated By:Vikas sir
                            else if (checkp != null)
                            {
                                if (checkp.ParagraphProperties != null)
                                {
                                    if (checkp.ParagraphProperties.ParagraphStyleId != null)
                                    {
                                        checkp.ParagraphProperties.ParagraphStyleId.Val = "TI";
                                        break;
                                    }
                                    else
                                    {
                                        checkp.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "TI" };
                                        break;
                                    }
                                }
                                else
                                {
                                    checkp.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "TI" });
                                    break;
                                }


                            }
                            //-------------------------------------end by Priyanka on 15_4_2019------------------------------------------------------
                        }
                    }
                }
                D.Save();
            }
        }

        public static void Au_StyleApplied(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                ///Developer Name:priyanka Vishwakarma ,Date:15_5_2019 ,Requirement:AU style before Corr Style on basis of full name of Author  ,Integrated By:Vikas sir
                matchauthorenameForAU = null;
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P.ParagraphProperties != null)
                    {
                        if (P.ParagraphProperties.ParagraphStyleId != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId.Val.Value == "CORR")
                            {
                                string match = P.InnerText;
                                ///////start  for add : after Address for correspondence split on : for author name
                                if (!match.ToLower().Replace(" ", "").Contains("addressforcorrespondence:"))
                                {
                                    match = match.Replace("Address for correspondence", "Address for correspondence:");
                                }

                                matchauthorenameForAU = match.Split(',')[0].Split(':').Last().Trim();

                                if (matchauthorenameForAU.Trim().ToLower().StartsWith("dr."))   //Developer name:Priyanka Vishwakarma ,Date:17-02-2020 ,Requirement:CORR paragraph contains Dr. at Author name but in AU paragraph style Author name should not contains Dr. with Author name. Integrated by:Vikas sir.
                                {
                                    matchauthorenameForAU = matchauthorenameForAU.Replace("Dr.", "");
                                }
                                //matchauthorename = match.Split(',')[0].Split(' ').Last();

                                break;
                            }
                        }
                    }
                }

                /// D.Descendants<Paragraph>().ToList().Where(x => x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val.Value == "CORR").Select(p => matchauthorenameForAU = p.InnerText.Split(',')[0].Split(':').Last().Trim());

                //----------------------------End----------------------------------
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                    {
                        if (P.ParagraphProperties.ParagraphStyleId.Val.Value == "H1" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H2" && P.ParagraphProperties.ParagraphStyleId.Val.Value == "H3" && P.ParagraphProperties.ParagraphStyleId.Val.Value == "H4" && P.ParagraphProperties.ParagraphStyleId.Val.Value == "H5" && P.ParagraphProperties.ParagraphStyleId.Val.Value == "H6" && P.ParagraphProperties.ParagraphStyleId.Val.Value == "H7")//Developer Name:Priyanka Vishwakarma Date:17-10-2020,Requirement:Avoid to apply AU after heading start.
                        {
                            break;
                        }
                    }
                    if (P != null && P.InnerText != "" && !P.InnerText.ToLower().StartsWith("address for correspondence") && matchauthorenameForAU != null && matchauthorenameForAU.Trim() != "")//Developer Name:Priyanka Vishwakarma, Date:07-09-2021, Requirement:check empty author name
                    {
                        if (((P.InnerText.ToLower().Replace(" ", " ").Contains(matchauthorenameForAU.ToLower() + ',') || P.InnerText.ToLower().Replace(" ", " ").Contains(matchauthorenameForAU.ToLower())) && !P.InnerText.ToLower().Replace(" ", " ").Contains("/" + matchauthorenameForAU.ToLower())) || P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val == "AU") ///Developer Name:priyanka Vishwakarma ,Date:15_5_2019 ,Requirement:AU style before Corr Style on basis of full name of Author  ,Integrated By:Vikas sir                        
                        {
                            if (P.ParagraphProperties != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId.Val != "RRH" && P.ParagraphProperties.ParagraphStyleId.Val != "UID" && P.ParagraphProperties.ParagraphStyleId.Val != "orcid" && P.ParagraphProperties.ParagraphStyleId.Val != "CORR" && P.ParagraphProperties.ParagraphStyleId.Val != "TI")
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val = "AU";
                                        break;
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "AU" };
                                    break;
                                }
                            }
                            else
                            {
                                P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "AU" });
                                break;
                            }

                        }
                    }
                }
                D.Save();
            }
        }

        public static void Ab_StyleApplied(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P != null && P.InnerText != "")
                    {   //Danish 24-11-2022 for adding new text for abstract
                        if (P.InnerText.ToLower().StartsWith("abstract") || P.InnerText.ToLower().StartsWith("sažetak"))
                        {
                            if (P.ParagraphProperties != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null)
                                {
                                    P.ParagraphProperties.ParagraphStyleId.Val = "AB";
                                }
                                else
                                {
                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "AB" };
                                }
                            }
                            else
                            {
                                P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "AB" });
                            }
                        }
                    }
                }
                D.Save();
            }
        }
        //Developer Name:Priyanka Vishwakarma ,Date:20_5_2019 ,Requirement:Apply ACK style for Acknowledgement Heading Para ,Integrated By:Vikas sir 
        public static void ack_StyleApplied(string newDoc)     //20_5_2019
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P != null && P.InnerText != "")
                    {
                        if ((P.InnerText.ToLower().StartsWith("acknowledgments") || P.InnerText.ToLower().StartsWith("acknowledgment") || P.InnerText.ToLower().StartsWith("acknowledgements") || P.InnerText.ToLower().StartsWith("acknowledgement")) && GlobalMethods.strClientName.ToLower() != "ufl")//clent ufl condition added by vikas on 14-08-2020 for florida job
                        {
                            if (P.ParagraphProperties != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null)
                                {
                                    P.ParagraphProperties.ParagraphStyleId.Val = "ACK";
                                }
                                else
                                {
                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "ACK" };
                                }
                            }
                            else
                            {
                                P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "ACK" });
                            }
                        }
                    }
                }
                D.Save();
            }
        }


        public static void ACKtxt_StyleApplied(string newDoc)   //Developer Name:Priyanka Vishwakarma ,Date:20_5_2019 ,Requirement:Apply ACK-TXT style for Paragraph after Acknowledgement Heading ,Integrated By:Vikas sir 
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P.ParagraphProperties != null)
                    {
                        if (P.ParagraphProperties.ParagraphStyleId != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId.Val.Value == "ACK")
                            {
                                if (P.NextSibling() != null && P.NextSibling().LocalName != "tbl") //Developer Name:Priyanka Vishwakarma, Date:22-7-2022, Add condition for check table para
                                {
                                    Paragraph checkp = (Paragraph)P.NextSibling();

                                    if (checkp != null && checkp.InnerText != null)
                                    {
                                        //if (checkp.InnerText.Length > 100)//commented by Priyanka on 14_08_2019 , ack paratxt move to section .
                                        //{
                                        if (checkp.ParagraphProperties != null)
                                        {
                                            if (checkp.ParagraphProperties.ParagraphStyleId != null)
                                            {
                                                checkp.ParagraphProperties.ParagraphStyleId.Val = "ACK-TXT";
                                                break;
                                            }
                                            else
                                            {
                                                checkp.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "ACK-TXT" };
                                                break;
                                            }
                                        }
                                        else
                                        {
                                            checkp.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "ACK-TXT" });
                                            break;
                                        }
                                        // }
                                    }
                                }
                            }

                        }
                    }

                }
                D.Save();
            }
        }
        //----------------------------End-------------------------------------------------
        public static void Abtxt_StyleApplied(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                bool abfound = false;
                bool nextH1 = false;
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P.ParagraphProperties != null)
                    {
                        if (P.ParagraphProperties.ParagraphStyleId != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId.Val.Value == "AB")
                            {
                                abfound = true;
                                nextH1 = false;
                                continue;
                            }
                            else if (GlobalMethods.strClientName.ToLower() == "sage")///sage condition added by vikas on 10-10-2020 for sage client
                            {
                                if (P.InnerText.Replace(" ", "").ToLower().StartsWith("keywords") || P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val.Value.StartsWith("H"))
                                {
                                    abfound = false;
                                }
                            }
                            else if (GlobalMethods.strClientName.ToLower() == "csiro")/////EXT and <txt> condition added by vikas on 14-08-2020 for florida job///informs condition added by vikas on 09-09-2020 for informs client
                            {
                                if (P.InnerText.Replace(" ", "").ToLower().StartsWith("keywords"))
                                {
                                    if (P.ParagraphProperties != null)
                                    {
                                        if (P.ParagraphProperties.ParagraphStyleId != null)
                                        {
                                            P.ParagraphProperties.ParagraphStyleId.Val = "KYWD";
                                        }
                                        else
                                        {
                                            P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "KYWD" };
                                        }
                                    }
                                    else
                                    {
                                        P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "KYWD" });
                                    }
                                }

                                nextH1 = true;
                                abfound = false;
                                break;
                            }
                            else if (P.ParagraphProperties.ParagraphStyleId.Val.Value == "H1" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "EXT" || (P.ParagraphProperties.ParagraphStyleId.Val.Value == "BodyA" && GlobalMethods.strClientName.ToLower() == "informs") || (GlobalMethods.strClientName.ToLower() != "sage" && GlobalMethods.strClientName.ToLower() != "jaypee" && GlobalMethods.strClientName.ToLower() != "ssllc"))/////EXT and <txt> condition added by vikas on 14-08-2020 for florida job///informs condition added by vikas on 09-09-2020 for informs client
                            {
                                if (P.InnerText.Replace(" ", "").ToLower().StartsWith("keywords"))
                                {
                                    if (P.ParagraphProperties != null)
                                    {
                                        if (P.ParagraphProperties.ParagraphStyleId != null)
                                        {
                                            P.ParagraphProperties.ParagraphStyleId.Val = "KYWD";
                                        }
                                        else
                                        {
                                            P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "KYWD" };
                                        }
                                    }
                                    else
                                    {
                                        P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "KYWD" });
                                    }
                                }

                                nextH1 = true;
                                abfound = false;
                                break;
                            }

                        }
                    }
                    if (abfound && !GlobalMethods.strJournalArticlePath.ToLower().Contains(@"\journal\ilo\"))
                    {
                        if (P.InnerText.Replace(" ", "").ToLower().StartsWith("keywords") || P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val.Value.StartsWith("H"))
                        {
                            abfound = false;
                            break;
                        }
                        if (P != null && P.InnerText != null && !P.InnerText.Replace(" ", "").ToLower().StartsWith("keywords:"))////keywords condition added by vikas on 14-08-2020
                        {
                            if (P.InnerText.Length > 100)
                            {
                                if (P.ParagraphProperties != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val.Value == "KYWD")////KYWD condition for informs client added by vikas on 10-09-2020
                                    {
                                        continue;
                                    }
                                    if (P.ParagraphProperties.ParagraphStyleId != null)
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val = "AB-TXT";
                                    }
                                    else
                                    {
                                        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "AB-TXT" };
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "AB-TXT" });
                                }
                            }
                        }
                    }
                }
                D.Save();
            }
        }

        public static void Kywd_StyleApplied(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                bool kywdfound = false;
                bool nextH1 = false;
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P.ParagraphProperties != null)
                    {
                        if (P.ParagraphProperties.ParagraphStyleId != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId.Val.Value == "KYWD")
                            {
                                kywdfound = true;
                                nextH1 = false;
                                continue;
                            }
                            else if (P.ParagraphProperties.ParagraphStyleId.Val.Value == "H1")
                            {
                                nextH1 = true;
                                kywdfound = false;
                                break;
                            }
                            else if (P.ParagraphProperties.ParagraphStyleId.Val.Value == "H1" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H5")  //Developer Name:Priyanka Vishwakarma ,Date:26_6_2019,Requirement :H1 heading not present in document . Integrated By:Vikas sir.
                            {
                                nextH1 = true;
                                kywdfound = false;
                                break;
                            }
                        }
                    }
                    if (kywdfound)
                    {
                        if (P != null && P.InnerText != null)
                        {
                            if (P.InnerText.Length < 50)
                            {
                                if (P.ParagraphProperties != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId != null)
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val = "KYWD";
                                    }
                                    else
                                    {
                                        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "KYWD" };
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "KYWD" });
                                }
                            }
                        }
                    }
                }
                D.Save();
            }
        }

        public static void Kywd_StyleAppliedForJaypee(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P != null && P.InnerText != "")
                    {
                        if (P.InnerText.ToLower().StartsWith("keywords:") || P.InnerText.ToLower().StartsWith("key words:") || P.InnerText.ToLower().StartsWith("keyword")|| P.InnerText.ToLower().StartsWith("keywords:") || P.InnerText.ToLower().Trim().StartsWith("palavras-chave") || P.InnerText.ToLower().Trim().StartsWith("palavras–chave") || P.InnerText.ToLower().Trim().StartsWith("palavras—chave")) //developer Name:Priyanka Vishwakarma, Date:5-10-2021,Add condition for apply KYWD in Jaypee input.
                        {
                            if (P.ParagraphProperties != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null)
                                {
                                    P.ParagraphProperties.ParagraphStyleId.Val = "KYWD";
                                    break;
                                }
                                else
                                {
                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "KYWD" };
                                    break;
                                }
                            }
                            else
                            {
                                P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "KYWD" });
                                break;
                            }
                        }
                    }
                }
                D.Save();
            }
        }

        public static void Ref_StyleApplied(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().Where(x => x.Parent != null && x.Parent.LocalName != W.tc.LocalName).ToList())
                {
                    if (P != null && P.InnerText != "")
                    {
                        if (P.InnerText.ToLower().Trim().Equals("references") || P.InnerText.ToLower().Trim().Equals("reference") || P.InnerText.ToLower().Equals("references cited") || P.InnerText.ToLower().Equals("selected bibliography") || P.InnerText.ToLower().Trim() == "final references:" || P.InnerText.ToLower().Trim() == "references:" || P.InnerText.ToLower().Trim() == "references" || P.InnerText.ToLower().Trim() == "final references" || P.InnerText.ToLower().Trim() == "reference" || P.InnerText.ToLower().Trim() == "reference:" || P.InnerText.ToLower().Trim() == "bibliography" || P.InnerText.ToLower().Trim() == "bibliography:" || P.InnerText.ToLower().Trim() == "bibliografia:" || P.InnerText.ToLower().Trim() == "bibliografia")  //Developer Name:Priyanka Vishwakarma , Date : 22-06-2021 ,Requirement:Apply REF paragarph style to heading Reference in cleanup process
                        {
                            if (P.ParagraphProperties != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null)
                                {
                                    P.ParagraphProperties.ParagraphStyleId.Val = "REF";
                                }
                                else
                                {
                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "REF" };
                                }
                            }
                            else
                            {
                                P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "REF" });
                            }
                        }
                    }
                }
                D.Save();
            }
        }

        public static void H1_StyleApplied(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {

                }
                D.Save();
            }
        }

        public static void Txt_StyleApplied(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                bool h1stylefound = false;
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    ////P.ParagraphProperties!=null added on 24-10-2020
                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val == "EQ")////Check equation present in document required for informs client added by vikas
                    {
                        GlobalMethods.bEqcheck = true;
                    }
                    if (P != null && P.InnerText != null)
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null)
                            {
                                //if (P.ParagraphProperties.ParagraphStyleId.Val.Value == "H1")
                                if (P.ParagraphProperties.ParagraphStyleId.Val.Value == "H1" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H2" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H3" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H4" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H5" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H6" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H7") //added on 8_4_2019 by Priyanka for heading text..H1-H7 Style
                                {
                                    h1stylefound = true;
                                    continue;
                                }
                                else if (P.ParagraphProperties.ParagraphStyleId.Val.Value == "REF")
                                {
                                    h1stylefound = false;
                                    break;
                                }
                            }
                        }
                    }
                    if (h1stylefound)
                    {
                        if (P != null && P.InnerText != null)
                        {
                            if (P.ParagraphProperties != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val != "EXT" && P.ParagraphProperties.ParagraphStyleId.Val != "NL" && P.ParagraphProperties.ParagraphStyleId.Val != "BL" && P.ParagraphProperties.ParagraphStyleId.Val != "UL" && P.ParagraphProperties.ParagraphStyleId.Val != "EQ" && P.ParagraphProperties.ParagraphStyleId.Val != "ORCID-AU" && P.ParagraphProperties.ParagraphStyleId.Val != "TFN" && P.ParagraphProperties.ParagraphStyleId.Val != "TT")//Developer name:Priyanka Vishwakarma,Date:14-10-2020,Requirement:Avoid to apply TXT para to ORcid para
                                {
                                    if (P.ParagraphProperties.Indentation == null)
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val = "TXT";
                                    }
                                    else
                                    {
                                        if (P.ParagraphProperties.Indentation != null)
                                        {
                                            if (P.ParagraphProperties.Indentation.FirstLine != null)
                                            {
                                                if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val != "EXT" && P.ParagraphProperties.ParagraphStyleId.Val != "NL" && P.ParagraphProperties.ParagraphStyleId.Val != "BL" && P.ParagraphProperties.ParagraphStyleId.Val != "UL" && P.ParagraphProperties.ParagraphStyleId.Val != "EQ" && P.ParagraphProperties.ParagraphStyleId.Val != "ORCID-AU" && P.ParagraphProperties.ParagraphStyleId.Val != "TFN" && P.ParagraphProperties.ParagraphStyleId.Val != "TT")////EXT condition added by priyanka for not change style if EXT style their integrated by vikas on 24-05-2019
                                                {
                                                    P.ParagraphProperties.ParagraphStyleId.Val = "TXT-2";
                                                }
                                            }
                                        }
                                    }
                                }
                                else
                                {
                                    if (P.ParagraphProperties.Indentation == null)
                                    {
                                        if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val != "EXT" && P.ParagraphProperties.ParagraphStyleId.Val != "NL" && P.ParagraphProperties.ParagraphStyleId.Val != "BL" && P.ParagraphProperties.ParagraphStyleId.Val != "UL" && P.ParagraphProperties.ParagraphStyleId.Val != "EQ" && P.ParagraphProperties.ParagraphStyleId.Val != "ORCID-AU" && P.ParagraphProperties.ParagraphStyleId.Val != "TFN" && P.ParagraphProperties.ParagraphStyleId.Val != "TT")////EXT condition added by priyanka for not change style if EXT style their integrated by vikas on 24-05-2019
                                        {
                                            P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "TXT" };
                                        }
                                    }
                                    else
                                    {
                                        if (P.ParagraphProperties.Indentation != null)
                                        {
                                            if (P.ParagraphProperties.Indentation.FirstLine != null)
                                            {
                                                if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val != "EXT" && P.ParagraphProperties.ParagraphStyleId.Val != "NL" && P.ParagraphProperties.ParagraphStyleId.Val != "BL" && P.ParagraphProperties.ParagraphStyleId.Val != "UL" && P.ParagraphProperties.ParagraphStyleId.Val != "EQ" && P.ParagraphProperties.ParagraphStyleId.Val != "ORCID-AU" && P.ParagraphProperties.ParagraphStyleId.Val != "TFN" && P.ParagraphProperties.ParagraphStyleId.Val != "TT")////EXT condition added by priyanka for not change style if EXT style their integrated by vikas on 24-05-2019
                                                {
                                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "TXT-2" };
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            else
                            {
                                if (P.ParagraphProperties != null)
                                {
                                    if (P.ParagraphProperties.Indentation == null)
                                    {
                                        P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "TXT" });
                                    }
                                    else
                                    {
                                        if (P.ParagraphProperties.Indentation != null)
                                        {
                                            if (P.ParagraphProperties.Indentation.FirstLine != null)
                                            {
                                                P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "TXT-2" });
                                            }
                                        }
                                    }
                                }
                                else///added on 24-10-2020
                                {
                                    P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "TXT" });
                                }
                            }
                        }
                    }
                }
                D.Save();
            }
        }

        public static void H2_StyleApplied(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {

                }
                D.Save();
            }
        }

        public static void figcApplyBoldStyle(string newDoc)  //17_5_2019
        {
            List<Run> FigcRunStyle = new List<Run>();
            using (WordprocessingDocument WPD = WordprocessingDocument
                .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;


                FigcRunStyle = D.Descendants<Run>().Where(r => r.RunProperties != null &&
                             r.RunProperties.RunStyle != null &&
                             r.RunProperties.RunStyle.Val != null &&
                             r.RunProperties.RunStyle.Val == "label-Strong").ToList();


                foreach (var R in FigcRunStyle.ToList())
                {
                    Bold bold = new Bold();
                    R.RunProperties.AppendChild(bold);
                }


                D.Save();
            }

        }
        public static void Txt2_StyleApplied(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {

                }
                D.Save();
            }
        }

        public static void Ref1_StyleApplied(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                bool refstratfound = false;
                bool refendfound = false;
                bool refFound = false;  ////Developer Name:priyanka Vishwakarma ,Date:15_5_2019 ,Requirement:Apply Ref1 Style to References when in document Ref_start and Ref_End style not apply ,Integrated By:Vikas sir

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(c => c.Parent.LocalName != W.tc).ToList())
                {
                    if(P.InnerText.Contains("References"))
                    {

                    }
                    if (P.ParagraphProperties != null)
                    {
                        if (P.ParagraphProperties.ParagraphStyleId != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId.Val.Value == "Ref-Start")
                            {
                                refstratfound = true;
                                refendfound = false;
                                continue;
                            }
                            else if (P.ParagraphProperties.ParagraphStyleId.Val.Value == "Ref-End")
                            {
                                refendfound = true;
                                refstratfound = false;
                                break;
                            }
                            ////Developer Name:priyanka Vishwakarma ,Date:15_5_2019 ,Requirement:Apply Ref1 Style to References when in document Ref_start and Ref_End style not apply ,Integrated By:Vikas sir
                           else if (P.ParagraphProperties.ParagraphStyleId.Val.Value == "REF")
                            {
                                refFound = true;
                            }
                            //-------------------------end by priyanka on 15_5_2019 -----------------------------------------------
                            else if (P.ParagraphProperties.ParagraphStyleId.Val.Value == "FIGC" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "TT" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H1" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H2" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "BodyTextRight")  //Developer name:priyanka Vishwakarma ,Date:31072020 ,Requirement:for avoid the REF1 style apply to figc and TT  paragraph. Integrated by:Vikas sir.   H1 and H2 added by vikas on 18-10-2020 ///BodyTextRight added by vikas on 01-04-2021 for break the style apply as REF1
                            {
                                refFound = false;
                            }
                            else if (P.InnerText.Trim().ToLower().StartsWith("graph") || P.InnerText.Trim().ToLower().StartsWith("flowchart"))
                            {
                                if (refstratfound == true || refFound == true)
                                {
                                    refstratfound = false;
                                    refendfound = true;
                                    break;
                                }
                               
                            }

                        }
                    }
                    if (refstratfound)
                    {
                        if (P != null && P.InnerText != null)
                        {
                            if (P.ParagraphProperties != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null)
                                {
                                    P.ParagraphProperties.ParagraphStyleId.Val = "REF1";
                                }
                                else
                                {
                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "REF1" };
                                }
                            }
                            else
                            {
                                P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "REF1" });
                            }
                        }
                    }
                    ////Developer Name:priyanka Vishwakarma ,Date:15_5_2019 ,Requirement:Apply Ref1 Style to References when in document Ref_start and Ref_End style not apply ,Integrated By:Vikas sir
                    if (refFound)
                    {

                        if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val.Value != "" && P.ParagraphProperties.ParagraphStyleId.Val.Value == "REF")//RefStyle apply on basis of text file..
                                                                                                                                                                                                                                                                                         // if (P.InnerText.ToLower().Trim() == "references" || P.InnerText.ToLower().Trim() == "reference" || P.InnerText.ToLower().Trim() == "references cited" || P.InnerText.ToLower().Trim() == "final references:" || P.InnerText.ToLower().Trim() == "references:" || P.InnerText.ToLower().Trim() == "references" || P.InnerText.ToLower().Trim() == "final references" || P.InnerText.ToLower().Trim() == "reference" || P.InnerText.ToLower().Trim() == "reference:" || P.InnerText.ToLower().Trim() == "bibliography:" || P.InnerText.ToLower().Trim() == "bibliography" || P.InnerText.ToLower().Trim() == "bibliografia:" || P.InnerText.ToLower().Trim() == "bibliografia") ////Developer Name:Priyanka Vishwakarma , Date : 08-06-2020 ,Requirement:Apply REF paragarph style to heading Reference in cleanup process ///references cited condition added by vikas on 14-08-2020 for florida job
                        {
                            continue;
                        }
                        //For copy edited MSS where refrences are already taged
                        if (P.InnerText.StartsWith("<") && P.InnerText.EndsWith(">"))
                        {
                            if (P != null && P.InnerText != null)
                            {
                                if (P.ParagraphProperties != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId != null)
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val = "REF1";
                                    }
                                    else
                                    {
                                        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "REF1" };
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "REF1" });
                                }

                            }
                        }
                        //For Non copy edited MSS where refrence needs to be taged added by vikas on 22-09-2019
                        //else if (Regex.Match(P.InnerText, @"(\s[0-9]+th+\s+ed)|([A-Za-z]+[\,]+\s{1,}[A-Za-z]+[\:]\s{1,}[A-Za-z\:\’\–\-\&\s]+[\;]+\s+[0-9]+)|(In:|In;)|([\(]ed\.[\)])", RegexOptions.IgnoreCase).Success)//For <bok> ...</bok>
                        //Ashish 27-03-2023
                        else if (Regex.Match(P.InnerText, @"(\s[0-9]+th+\s+ed)|([A-Za-z]+[\,]+\s{1,}[A-Za-z]+[\:]\s{1,}[A-Za-z\:\’\–\-\&\s]+[\;]+\s+[0-9]+)|(In:|In;)|([\(]ed\.[\)]|[\(]Eds\.[\)]|[\(][0-9stndrdth\s]+ed\.[\)])", RegexOptions.IgnoreCase).Success)//For <bok> ...</bok> // Developer Name:Ashish , Date:18032023 , Requirement:Added regex.
                        {
                            if (P != null && P.InnerText != null)
                            {
                                if (P.ParagraphProperties != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId != null)
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val = "REF1";
                                    }
                                    else
                                    {
                                        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "REF1" };
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "REF1" });
                                }

                                if (!P.InnerText.StartsWith("<bok>"))
                                {
                                    P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().ForEach(t => t.ToList().ForEach(txt =>
                                    {

                                        if (txt == P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().FirstOrDefault().FirstOrDefault())
                                        {
                                            txt.Text = "<bok>" + txt.Text;
                                        }
                                        if (txt == P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().LastOrDefault().LastOrDefault())
                                        {
                                            txt.Text = txt.Text + "</bok>";
                                        }
                                    })
                                    );
                                }

                            }

                        }
                        else if (Regex.Match(P.InnerText, @"\d+[(]+[\d]+[)]|(\d+[(]+[\d]+[)]|\d+[;]\d+[:]\d+[\-\–]\d+)|([\.]+\s{1,}[A-Za-z\s]+\s{1,}[0-9]+[\;])|([A-Za-z\s]+[\,]\s{1,}[pp]+[\.]\s{1,}[0-9]+[\-\–][0-9]+)|(Vol.\s{1,}[0-9]+[\,]\s{1,}[No.]+\s{1,}[0-9]+)|([0-9]+\([0-9\.]+\)\,\s[0-9]+\–[0-9]+)|([0-9]+\s{0,1}\;\s{0,1}[0-9]+\s{0,1}\:\s{0,1}[A-Z0-9]+\-[A-Z0-9]+)").Success)//For <jrn> ...</jrn>
                        {
                            if (P != null && P.InnerText != null)
                            {
                                if (P.ParagraphProperties != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId != null)
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val = "REF1";
                                    }
                                    else
                                    {
                                        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "REF1" };
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "REF1" });
                                }

                                if (!P.InnerText.StartsWith("<jrn>"))
                                {
                                    P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().ForEach(t => t.ToList().ForEach(txt =>
                                    {

                                        if (txt == P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().FirstOrDefault().FirstOrDefault())
                                        {
                                            txt.Text = "<jrn>" + txt.Text;
                                        }
                                        if (txt == P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().LastOrDefault().LastOrDefault())
                                        {
                                            txt.Text = txt.Text + "</jrn>";
                                        }
                                    })
                                    );
                                }

                            }
                        }
                        else if (Regex.Match(P.InnerText, @"([0-9]{4}\;[0-9]+\([0-9]+\)\:[0-9]+[\-|\-|\–][0-9]+)|([0-9]+\s{0,1}\;\s{0,1}[0-9]+\s{0,1}\:\s{0,1}[A-Z0-9]+\-[A-Z0-9]+)|([0-9]+\([0-9]+\)\:[0-9]+[\-|\-|\–][0-9]+)|([0-9]{4}\;[0-9]+\:\s[0-9]+[\-|\-|\–][0-9]+)|([0-9]{4}\;[0-9]+\:[0-9]+[\-|\-|\–][0-9]+)|([0-9]{4}\s\;\(\s[0-9]+\)\:[A-Z0-9]+)|([0-9]{4}\;[0-9]+\:[a-zA-Z0-9]+)|([0-9]{4}\;\s[0-9]+\([0-9]\)\:\s[0-9]+[\-|\-|\–][0-9]+)|([0-9]+\.\sp\.\s[0-9]+[\-|\-|\–][0-9]+)|([0-9]+\:[0-9]+[\-|\-|\–][0-9]+)|([0-9]+\.\s[0-9]+[\-|\-|\–][0-9]+)|([0-9]{4}\;[0-9]+\([0-9]+\)\,\s[0-9]+[\-|\-|\–][0-9]+)|([0-9]{4}\;\([0-9]+\)\:[0-9]+[\-|\-|\–][0-9]+)").Success)//For <jrn> ...</jrn>
                        {
                            if (P != null && P.InnerText != null)
                            {
                                if (P.ParagraphProperties != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId != null)
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val = "REF1";
                                    }
                                    else
                                    {
                                        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "REF1" };
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "REF1" });
                                }

                                if (!P.InnerText.StartsWith("<jrn>"))
                                {
                                    P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().ForEach(t => t.ToList().ForEach(txt =>
                                    {

                                        if (txt == P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().FirstOrDefault().FirstOrDefault())
                                        {
                                            txt.Text = "<jrn>" + txt.Text;
                                        }
                                        if (txt == P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().LastOrDefault().LastOrDefault())
                                        {
                                            txt.Text = txt.Text + "</jrn>";
                                        }
                                    })
                                    );
                                }

                            }
                        }
                        else if (Regex.Match(P.InnerText.TrimStart(), @"^\d+", RegexOptions.IgnoreCase).Success)//For <other> ...</other>
                        {
                            if (P != null && P.InnerText != null)
                            {
                                if (P.ParagraphProperties != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId != null)
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val = "REF1";
                                    }
                                    else
                                    {
                                        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "REF1" };
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "REF1" });
                                }

                                if (!P.InnerText.StartsWith("<unknown>"))
                                {
                                    P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().ForEach(t => t.ToList().ForEach(txt =>
                                    {

                                        if (txt == P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().FirstOrDefault().FirstOrDefault())
                                        {
                                            txt.Text = "<unknown>" + txt.Text;
                                        }
                                        if (txt == P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().LastOrDefault().LastOrDefault())
                                        {
                                            txt.Text = txt.Text + "</unknown>";
                                        }
                                    })
                                    );
                                }

                            }

                        }
                        //Developer name:Priyanka vishwakarma ,Date:12_10_2019 ,Requirement for unstructured file without numbering reference ,Integrated by:Vikas sir. added by vikas P.NextSibling().XName.LocalName!= "sectPr" on 12-11-2019 for IJCDW article IJCDW-19-0168-ED
                        else if (P.NextSibling() != null && P.NextSibling().XName.LocalName != "sectPr" && P.NextSibling<Paragraph>() != null && P.NextSibling<Paragraph>().ParagraphProperties != null && P.NextSibling<Paragraph>().ParagraphProperties.ParagraphStyleId != null && P.NextSibling<Paragraph>().ParagraphProperties.ParagraphStyleId.Val != null && P.NextSibling<Paragraph>().ParagraphProperties.ParagraphStyleId.Val.Value == "FIGC")
                        {
                            if (P != null && P.InnerText != null)
                            {
                                if (P.ParagraphProperties != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId != null)
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val = "REF1";
                                    }
                                    else
                                    {
                                        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "REF1" };
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "REF1" });
                                }

                                if (!P.InnerText.StartsWith("<unknown>"))
                                {
                                    P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().ForEach(t => t.ToList().ForEach(txt =>
                                    {

                                        if (txt == P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().FirstOrDefault().FirstOrDefault())
                                        {
                                            txt.Text = "<unknown>" + txt.Text;
                                        }
                                        if (txt == P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().LastOrDefault().LastOrDefault())
                                        {
                                            txt.Text = txt.Text + "</unknown>";
                                        }
                                    })
                                    );
                                }

                            }

                        }
                        else if (!P.InnerText.StartsWith("<") && !P.InnerText.EndsWith(">"))
                        {
                            if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && (P.ParagraphProperties.ParagraphStyleId.Val.Value == "H1" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "BoxStart" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H2" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H3" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H4" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H5" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H6"))
                            {
                                refFound = false;
                            }
                            else if (P.Descendants<Run>().ToList().FirstOrDefault() != null && P.Descendants<Run>().ToList().FirstOrDefault().Descendants().Any(x => x.LocalName == "b"))//CheckFor bold 
                            {
                                refFound = false;
                            }
                            else if (P.Parent != null && P.Parent.XName.LocalName == "tc")  //31-3-2022
                            {
                                refFound = false;
                            }
                            else
                            {
                                if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                                {
                                    P.ParagraphProperties.ParagraphStyleId.Val = "REF1";
                                }
                                if (!P.InnerText.StartsWith("<unknown>"))
                                {
                                    P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().ForEach(t => t.ToList().ForEach(txt =>
                                    {

                                        if (txt == P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().FirstOrDefault().FirstOrDefault())
                                        {
                                            txt.Text = "<unknown>" + txt.Text;
                                        }
                                        if (txt == P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().LastOrDefault().LastOrDefault())
                                        {

                                            txt.Text = txt.Text + "</unknown>";
                                        }
                                        else if (GlobalMethods.strClientName.ToLower() == "sage" && txt == P.Descendants<Text>().ToList().LastOrDefault())
                                        {
                                            txt.Text = txt.Text + "</unknown>";
                                        }
                                    })
                                    );
                                }
                            }

                        }
                    }
                    //-------------------------End by Priyanka on 15_5_2019----------------------------------------------------------

                }
                D.Save();
            }
        }

        public static void Ref1_StyleAppliedflow(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                bool refstratfound = false;
                bool refendfound = false;
                bool refFound = false;  ////Developer Name:priyanka Vishwakarma ,Date:15_5_2019 ,Requirement:Apply Ref1 Style to References when in document Ref_start and Ref_End style not apply ,Integrated By:Vikas sir

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(c => c.Parent.LocalName != W.tc).ToList())
                {
                    if (P.ParagraphProperties != null)
                    {
                        if (P.ParagraphProperties.ParagraphStyleId != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId.Val.Value == "Ref-Start")
                            {
                                refstratfound = true;
                                refendfound = false;
                                continue;
                            }
                            else if (P.ParagraphProperties.ParagraphStyleId.Val.Value == "Ref-End")
                            {
                                refendfound = true;
                                refstratfound = false;
                                break;
                            }

                            if (P.ParagraphProperties.ParagraphStyleId.Val.Value == "REF")
                            {
                                refFound = true;
                            }

                            else if (P.ParagraphProperties.ParagraphStyleId.Val.Value == "FIGC" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "TT")  //Developer name:priyanka Vishwakarma ,Date:31072020 ,Requirement:for avoid the REF1 style apply to figc and TT  paragraph. Integrated by:Vikas sir.   
                            {
                                refFound = false;
                            }
                        }
                    }


                    if (refFound)
                    {
                        if (P.InnerText.ToLower().Trim() == "references" || P.InnerText.ToLower().Trim() == "reference" || P.InnerText.ToLower().Trim() == "references cited" || P.InnerText.ToLower().Trim() == "selected bibliography" || P.InnerText.ToLower().Trim() == "bibliography" || P.InnerText.ToLower().Trim() == "bibliography:" || P.InnerText.ToLower().Trim() == " bibliografia:" || P.InnerText.ToLower().Trim() == " bibliografia")
                        {
                            continue;
                        }
                        else if (P != null && P.InnerText != null)
                        {
                            if (P.ParagraphProperties != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null)
                                {
                                    P.ParagraphProperties.ParagraphStyleId.Val = "REF1";
                                }
                                else
                                {
                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "REF1" };
                                }
                            }
                            else
                            {
                                P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "REF1" });
                            }
                        }
                    }
                }
                D.Save();
            }
        }

        public static void Ref1_StyleAppliedINF(string newDoc)
        {

            List<string> strJournalsColl = new List<string>();
            strJournalsColl = GlobalMethods.ReadAndStoreFileValuesInArray(ConfigurationManager.AppSettings.Get("JournalNameDB"));
            List<string> strBooksColl = new List<string>();
            strBooksColl = GlobalMethods.ReadAndStoreFileValuesInArray(ConfigurationManager.AppSettings.Get("PublisherNameDB"));

            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                bool refstratfound = false;
                bool refendfound = false;
                bool refFound = false;  ////Developer Name:priyanka Vishwakarma ,Date:15_5_2019 ,Requirement:Apply Ref1 Style to References when in document Ref_start and Ref_End style not apply ,Integrated By:Vikas sir

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(c => c.Parent.LocalName != W.tc).ToList())
                {
                    if (P.ParagraphProperties != null)
                    {
                        if (P.ParagraphProperties.ParagraphStyleId != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId.Val.Value == "Ref-Start")
                            {
                                refstratfound = true;
                                refendfound = false;
                                continue;
                            }
                            else if (P.ParagraphProperties.ParagraphStyleId.Val.Value == "Ref-End")
                            {
                                refendfound = true;
                                refstratfound = false;
                                break;
                            }
                            ////Developer Name:priyanka Vishwakarma ,Date:15_5_2019 ,Requirement:Apply Ref1 Style to References when in document Ref_start and Ref_End style not apply ,Integrated By:Vikas sir
                            if (P.ParagraphProperties.ParagraphStyleId.Val.Value == "REF")
                            {
                                refFound = true;
                            }
                            //-------------------------end by priyanka on 15_5_2019 -----------------------------------------------
                            else if (P.ParagraphProperties.ParagraphStyleId.Val.Value == "FIGC" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "TT")  //Developer name:priyanka Vishwakarma ,Date:31072020 ,Requirement:for avoid the REF1 style apply to figc and TT  paragraph. Integrated by:Vikas sir.   
                            {
                                refFound = false;
                            }
                        }
                    }
                    if (refstratfound)
                    {
                        if (P != null && P.InnerText != null)
                        {
                            if (P.ParagraphProperties != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null)
                                {
                                    P.ParagraphProperties.ParagraphStyleId.Val = "REF1";
                                }
                                else
                                {
                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "REF1" };
                                }
                            }
                            else
                            {
                                P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "REF1" });
                            }
                        }
                    }
                    ////Developer Name:priyanka Vishwakarma ,Date:15_5_2019 ,Requirement:Apply Ref1 Style to References when in document Ref_start and Ref_End style not apply ,Integrated By:Vikas sir
                    if (refFound)
                    {
                        if (P.InnerText.ToLower().Trim() == "references" || P.InnerText.ToLower().Trim() == "reference" || P.InnerText.ToLower().Trim() == "references cited" || P.InnerText.ToLower().Trim() == "bibliography" || P.InnerText.ToLower().Trim() == "bibliography:" || P.InnerText.ToLower().Trim() == "bibliografia:" || P.InnerText.ToLower().Trim() == "bibliografia") ////Developer Name:Priyanka Vishwakarma , Date : 08-06-2020 ,Requirement:Apply REF paragarph style to heading Reference in cleanup process ///references cited condition added by vikas on 14-08-2020 for florida job
                        {
                            continue;
                        }


                        //For copy edited MSS where refrences are already taged
                        if (P.InnerText.StartsWith("<") && P.InnerText.EndsWith(">"))
                        {
                            if (P != null && P.InnerText != null)
                            {
                                if (P.ParagraphProperties != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId != null)
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val = "REF1";
                                    }
                                    else
                                    {
                                        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "REF1" };
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "REF1" });
                                }

                            }
                        }
                        //For Non copy edited MSS where refrence needs to be taged added by vikas on 22-09-2019

                        //else if (Regex.Match(P.InnerText, @"([A-Za-z]+)(\,)\s{1,}([0-9]{4})(\.)|(\()(Ed\.)(\))|(\()(Eds)(\))(\.)|(\()(eds.|Eds.)(\))", RegexOptions.IgnoreCase).Success)
                        else if (Regex.Match(P.InnerText, @"([A-Za-z]+)(\,)\s{1,}([0-9]{4})(\.)|(\()(Ed\.)(\))|(\()(Eds)(\))(\.)|([\(]ed\.[\)]|[\(]Eds\.[\)]|[\(][0-9stndrdth\s]+ed\.[\)])", RegexOptions.IgnoreCase).Success) // Developer Name:Ashish , Date:18032023 , Requirement:Add regex.
                        {
                            if (P != null && P.InnerText != null)
                            {
                                if (P.ParagraphProperties != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId != null)
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val = "REF1";
                                    }
                                    else
                                    {
                                        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "REF1" };
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "REF1" });
                                }

                                if (!P.InnerText.StartsWith("<bok>"))
                                {
                                    P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().ForEach(t => t.ToList().ForEach(txt =>
                                    {

                                        if (txt == P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().FirstOrDefault().FirstOrDefault())
                                        {
                                            txt.Text = "<bok>" + txt.Text;
                                        }
                                        if (txt == P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().LastOrDefault().LastOrDefault())
                                        {
                                            txt.Text = txt.Text + "</bok>";
                                        }
                                    })
                                    );
                                }

                            }


                        }

                        else if (Regex.Match(P.InnerText, @"([0-9]+)(\,)\s{1,}([0-9]+)(\-|\–)([0-9]+)(\.)|([0-9]+)(\,|:)\s{1,}([0-9]+)(\-|\–)([0-9]+)(\.)|([0-9]+\([0-9]+\)\:[0-9]+[\-|\–][0-9]+\,\s{1,}([0-9]+)\.)|([0-9]+)(\:)([0-9]+)(\-|\–)([0-9]+)(\,)\s{1,}([0-9]+)(\.)|([0-9]+)(\()([0-9]+)(\))(\:)").Success)
                        {

                            if (P != null && P.InnerText != null)
                            {
                                if (P.ParagraphProperties != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId != null)
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val = "REF1";
                                    }
                                    else
                                    {
                                        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "REF1" };
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "REF1" });
                                }

                                if (!P.InnerText.StartsWith("<jrn>"))
                                {
                                    P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().ForEach(t => t.ToList().ForEach(txt =>
                                    {

                                        if (txt == P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().FirstOrDefault().FirstOrDefault())
                                        {
                                            txt.Text = "<jrn>" + txt.Text;
                                        }
                                        if (txt == P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().LastOrDefault().LastOrDefault())
                                        {
                                            txt.Text = txt.Text + "</jrn>";
                                        }
                                    })
                                    );
                                }

                            }


                        }

                        //else if (strJournalsColl.Any(x => x.Trim() != "" && x.Trim().Contains(" ") && P.InnerText.ToLower().Contains(x.ToLower().Trim())))
                        //{

                        //    foreach (var a in strJournalsColl.ToList())
                        //    {
                        //        if(a.Trim().Contains(" ") && P.InnerText.ToLower().Contains(a.ToLower().Trim()))
                        //        {

                        //        }

                        //    }

                        //    if (P != null && P.InnerText != null)
                        //    {
                        //        if (P.ParagraphProperties != null)
                        //        {
                        //            if (P.ParagraphProperties.ParagraphStyleId != null)
                        //            {
                        //                P.ParagraphProperties.ParagraphStyleId.Val = "REF1";
                        //            }
                        //            else
                        //            {
                        //                P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "REF1" };
                        //            }
                        //        }
                        //        else
                        //        {
                        //            P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "REF1" });
                        //        }

                        //        if (!P.InnerText.StartsWith("<jrn>"))
                        //        {
                        //            P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().ForEach(t => t.ToList().ForEach(txt =>
                        //            {

                        //                if (txt == P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().FirstOrDefault().FirstOrDefault())
                        //                {
                        //                    txt.Text = "<jrn>" + txt.Text;
                        //                }
                        //                if (txt == P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().LastOrDefault().LastOrDefault())
                        //                {
                        //                    txt.Text = txt.Text + "</jrn>";
                        //                }
                        //            })
                        //            );
                        //        }

                        //    }


                        //}


                        else if (!P.InnerText.StartsWith("<") && !P.InnerText.EndsWith(">"))
                        {
                            if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && (P.ParagraphProperties.ParagraphStyleId.Val.Value == "H1" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "BoxStart" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H2" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H3" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H4" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H5" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H6"))
                            {
                                refFound = false;
                            }
                            else if (P.Parent != null && P.Parent.LocalName == "tc")  //Developer name:Priyanka Vishwakarma,Date:11-09-2020,Requirement:avoid to apply ref1 style into table 
                            {
                                refFound = false;
                            }
                            else
                            {
                                //if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                                //{
                                //    P.ParagraphProperties.ParagraphStyleId.Val = "REF1";
                                //}
                                if (P.ParagraphProperties != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId != null)
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val = "REF1";
                                    }
                                    else
                                    {
                                        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "REF1" };
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "REF1" });
                                }
                                if (!P.InnerText.StartsWith("<unknown>"))
                                {
                                    P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().ForEach(t => t.ToList().ForEach(txt =>
                                    {

                                        if (txt == P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().FirstOrDefault().FirstOrDefault())
                                        {
                                            txt.Text = "<unknown>" + txt.Text;
                                        }
                                        if (txt == P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().LastOrDefault().LastOrDefault())
                                        {
                                            txt.Text = txt.Text + "</unknown>";
                                        }
                                    })
                                    );
                                }
                            }

                        }
                    }
                    //-------------------------End by Priyanka on 15_5_2019----------------------------------------------------------

                }
                D.Save();
            }
        }
        //public static void Ref1_StyleApplied(string newDoc)
        //{
        //    using (WordprocessingDocument WPD = WordprocessingDocument
        //         .Open(newDoc, true))
        //    {
        //        MainDocumentPart MDP = WPD.MainDocumentPart;

        //        Document D = MDP.Document;
        //        bool refstratfound = false;
        //        bool refendfound = false;
        //        bool refFound = false;  ////Developer Name:priyanka Vishwakarma ,Date:15_5_2019 ,Requirement:Apply Ref1 Style to References when in document Ref_start and Ref_End style not apply ,Integrated By:Vikas sir

        //        foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(c => c.Parent.LocalName != W.tc).ToList())
        //        {
        //            if (P.ParagraphProperties != null)
        //            {
        //                if (P.ParagraphProperties.ParagraphStyleId != null)
        //                {
        //                    if (P.ParagraphProperties.ParagraphStyleId.Val.Value == "Ref-Start")
        //                    {
        //                        refstratfound = true;
        //                        refendfound = false;
        //                        continue;
        //                    }
        //                    else if (P.ParagraphProperties.ParagraphStyleId.Val.Value == "Ref-End")
        //                    {
        //                        refendfound = true;
        //                        refstratfound = false;
        //                        break;
        //                    }
        //                    ////Developer Name:priyanka Vishwakarma ,Date:15_5_2019 ,Requirement:Apply Ref1 Style to References when in document Ref_start and Ref_End style not apply ,Integrated By:Vikas sir
        //                    if (P.ParagraphProperties.ParagraphStyleId.Val.Value == "REF")
        //                    {
        //                        refFound = true;
        //                    }
        //                    //-------------------------end by priyanka on 15_5_2019 -----------------------------------------------
        //                    else if (P.ParagraphProperties.ParagraphStyleId.Val.Value == "FIGC")  //Developer name:priyanka Vishwakarma ,Date:28092019 ,Requirement:for avoid the REF1 style apply to figc  paragraph. Integrated by:Vikas sir. 
        //                    {
        //                        refFound = false;
        //                    }
        //                }
        //            }
        //            if (refstratfound)
        //            {
        //                if (P != null && P.InnerText != null)
        //                {
        //                    if (P.ParagraphProperties != null)
        //                    {
        //                        if (P.ParagraphProperties.ParagraphStyleId != null)
        //                        {
        //                            P.ParagraphProperties.ParagraphStyleId.Val = "REF1";
        //                        }
        //                        else
        //                        {
        //                            P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "REF1" };
        //                        }
        //                    }
        //                    else
        //                    {
        //                        P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "REF1" });
        //                    }
        //                }
        //            }
        //            ////Developer Name:priyanka Vishwakarma ,Date:15_5_2019 ,Requirement:Apply Ref1 Style to References when in document Ref_start and Ref_End style not apply ,Integrated By:Vikas sir
        //            if (refFound)
        //            {
        //                if (P.InnerText.ToLower().Trim() == "references" || P.InnerText.ToLower().Trim() == "reference") ////Developer Name:Priyanka Vishwakarma , Date : 08-06-2020 ,Requirement:Apply REF paragarph style to heading Reference in cleanup process
        //                {
        //                    continue;
        //                }
        //                //For copy edited MSS where refrences are already taged
        //                if (P.InnerText.StartsWith("<") && P.InnerText.EndsWith(">"))
        //                {
        //                    if (P != null && P.InnerText != null)
        //                    {
        //                        if (P.ParagraphProperties != null)
        //                        {
        //                            if (P.ParagraphProperties.ParagraphStyleId != null)
        //                            {
        //                                P.ParagraphProperties.ParagraphStyleId.Val = "REF1";
        //                            }
        //                            else
        //                            {
        //                                P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "REF1" };
        //                            }
        //                        }
        //                        else
        //                        {
        //                            P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "REF1" });
        //                        }

        //                    }
        //                }
        //                //For Non copy edited MSS where refrence needs to be taged added by vikas on 22-09-2019
        //                else if (Regex.Match(P.InnerText, @"\d+[(]+[\d]+[)]|(\d+[(]+[\d]+[)]|\d+[;]\d+[:]\d+[\-\–]\d+)|([\.]+\s{1,}[A-Za-z\s]+\s{1,}[0-9]+[\;])").Success)//For <jrn> ...</jrn>
        //                {
        //                    if (P != null && P.InnerText != null)
        //                    {
        //                        if (P.ParagraphProperties != null)
        //                        {
        //                            if (P.ParagraphProperties.ParagraphStyleId != null)
        //                            {
        //                                P.ParagraphProperties.ParagraphStyleId.Val = "REF1";
        //                            }
        //                            else
        //                            {
        //                                P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "REF1" };
        //                            }
        //                        }
        //                        else
        //                        {
        //                            P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "REF1" });
        //                        }

        //                        if (!P.InnerText.StartsWith("<jrn>"))
        //                        {
        //                            P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().ForEach(t => t.ToList().ForEach(txt =>
        //                             {

        //                                 if (txt == P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().FirstOrDefault().FirstOrDefault())
        //                                 {
        //                                     txt.Text = "<jrn>" + txt.Text;
        //                                 }
        //                                 if (txt == P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().LastOrDefault().LastOrDefault())
        //                                 {
        //                                     txt.Text = txt.Text + "</jrn>";
        //                                 }
        //                             })
        //                            );
        //                        }

        //                    }
        //                }
        //                else if (Regex.Match(P.InnerText, @"\s[0-9]+th+\s+ed|([A-Za-z]+[\,]+\s{1,}[A-Za-z]+[\:]\s{1,}[A-Za-z\:\’\–\-\&\s]+[\;]+\s+[0-9]+)|(In:|In;)", RegexOptions.IgnoreCase).Success)//For <bok> ...</bok>
        //                {
        //                    if (P != null && P.InnerText != null)
        //                    {
        //                        if (P.ParagraphProperties != null)
        //                        {
        //                            if (P.ParagraphProperties.ParagraphStyleId != null)
        //                            {
        //                                P.ParagraphProperties.ParagraphStyleId.Val = "REF1";
        //                            }
        //                            else
        //                            {
        //                                P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "REF1" };
        //                            }
        //                        }
        //                        else
        //                        {
        //                            P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "REF1" });
        //                        }

        //                        if (!P.InnerText.StartsWith("<bok>"))
        //                        {
        //                            P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().ForEach(t => t.ToList().ForEach(txt =>
        //                            {

        //                                if (txt == P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().FirstOrDefault().FirstOrDefault())
        //                                {
        //                                    txt.Text = "<bok>" + txt.Text;
        //                                }
        //                                if (txt == P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().LastOrDefault().LastOrDefault())
        //                                {
        //                                    txt.Text = txt.Text + "</bok>";
        //                                }
        //                            })
        //                            );
        //                        }

        //                    }

        //                }
        //                else if (Regex.Match(P.InnerText, @"^\d+", RegexOptions.IgnoreCase).Success)//For <other> ...</other>
        //                {
        //                    if (P != null && P.InnerText != null)
        //                    {
        //                        if (P.ParagraphProperties != null)
        //                        {
        //                            if (P.ParagraphProperties.ParagraphStyleId != null)
        //                            {
        //                                P.ParagraphProperties.ParagraphStyleId.Val = "REF1";
        //                            }
        //                            else
        //                            {
        //                                P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "REF1" };
        //                            }
        //                        }
        //                        else
        //                        {
        //                            P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "REF1" });
        //                        }

        //                        if (!P.InnerText.StartsWith("<unknown>"))
        //                        {
        //                            P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().ForEach(t => t.ToList().ForEach(txt =>
        //                            {

        //                                if (txt == P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().FirstOrDefault().FirstOrDefault())
        //                                {
        //                                    txt.Text = "<unknown>" + txt.Text;
        //                                }
        //                                if (txt == P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().LastOrDefault().LastOrDefault())
        //                                {
        //                                    txt.Text = txt.Text + "</unknown>";
        //                                }
        //                            })
        //                            );
        //                        }

        //                    }

        //                }
        //                //Developer name:Priyanka vishwakarma ,Date:12_10_2019 ,Requirement for unstructured file without numbering reference ,Integrated by:Vikas sir. added by vikas P.NextSibling().XName.LocalName!= "sectPr" on 12-11-2019 for IJCDW article IJCDW-19-0168-ED
        //                else if (P.NextSibling() != null && P.NextSibling().XName.LocalName != "sectPr" && P.NextSibling<Paragraph>().ParagraphProperties != null && P.NextSibling<Paragraph>().ParagraphProperties.ParagraphStyleId != null && P.NextSibling<Paragraph>().ParagraphProperties.ParagraphStyleId.Val != null && P.NextSibling<Paragraph>().ParagraphProperties.ParagraphStyleId.Val.Value == "FIGC")
        //                {
        //                    if (P != null && P.InnerText != null)
        //                    {
        //                        if (P.ParagraphProperties != null)
        //                        {
        //                            if (P.ParagraphProperties.ParagraphStyleId != null)
        //                            {
        //                                P.ParagraphProperties.ParagraphStyleId.Val = "REF1";
        //                            }
        //                            else
        //                            {
        //                                P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "REF1" };
        //                            }
        //                        }
        //                        else
        //                        {
        //                            P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "REF1" });
        //                        }

        //                        if (!P.InnerText.StartsWith("<unknown>"))
        //                        {
        //                            P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().ForEach(t => t.ToList().ForEach(txt =>
        //                            {

        //                                if (txt == P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().FirstOrDefault().FirstOrDefault())
        //                                {
        //                                    txt.Text = "<unknown>" + txt.Text;
        //                                }
        //                                if (txt == P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().LastOrDefault().LastOrDefault())
        //                                {
        //                                    txt.Text = txt.Text + "</unknown>";
        //                                }
        //                            })
        //                            );
        //                        }

        //                    }

        //                }
        //                else if (GlobalMethods.strJournalArticlePath.ToLower().Contains(@"\journal\ilo\"))/////Specific to ILO journal only added by vikas on 18-07-2020
        //                {
        //                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && (P.ParagraphProperties.ParagraphStyleId.Val == "H1" || P.ParagraphProperties.ParagraphStyleId.Val == "AppendixHead"))
        //                    {
        //                        refFound = false;
        //                    }
        //                    if (refFound)
        //                    {
        //                        if (P.ParagraphProperties != null)
        //                        {
        //                            if (P.ParagraphProperties.ParagraphStyleId != null)
        //                            {
        //                                P.ParagraphProperties.ParagraphStyleId.Val = "REF1";
        //                            }
        //                            else
        //                            {
        //                                P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "REF1" };
        //                            }
        //                        }
        //                        else
        //                        {
        //                            P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "REF1" });
        //                        }
        //                    }
        //                }
        //                else if (!P.InnerText.StartsWith("<") && !P.InnerText.EndsWith(">"))
        //                {
        //                    refFound = false;
        //                }
        //            }
        //            //-------------------------End by Priyanka on 15_5_2019----------------------------------------------------------

        //        }
        //        D.Save();
        //    }
        //}

        public static void Fig_StyleApplied(string newDoc)
        {
            bool refParaStart = false;//Developer Name:Priyanka Vishwakarma,Date:19-03-2021,Requirement:Apply figc para after reference 
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;


                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P != null && P.InnerText != "")
                    {
                        //Developer Name:Priyanka Vishwakarma,Date:19-03-2021,Requirement:Apply figc para after reference 
                        if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val.Value == "REF")
                        {
                            if (GlobalMethods.strClientName.ToLower() == "ufl")
                            {
                                refParaStart = true;
                            }
                        }
                        //End on 19-03-2021

                        ////start added by vikas on 18-04-2019
                        bool bciteFig = false;
                        if (P.Descendants<Run>().Count() > 0 && P.Descendants<Run>().FirstOrDefault().Descendants<RunStyle>().Count() > 0 && P.Descendants<Run>().FirstOrDefault().Descendants<RunStyle>().FirstOrDefault().Val == "citefig")
                        {
                            bciteFig = true;
                        }
                        ////end added by vikas on 18-04-2019


                        //Developer name:Priyanka Vishwakarma ,Date:17_09_2019 ,Requirement:to avoid apply Figc paragraph style when it has heading style. Integrated by:Vikas sir.
                        if ((P.InnerText.ToLower().TrimStart().StartsWith("fig.") || P.InnerText.ToLower().TrimStart().StartsWith("fig ")) && bciteFig == false)
                        {
                            if (P.ParagraphProperties != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null)
                                {
                                    if (refParaStart == false)//Developer Name:Priyanka Vishwakarma,Date:19-03-2021,Requirement:Apply figc para after reference 
                                        P.ParagraphProperties.ParagraphStyleId.Val = "FIG";
                                }
                                else
                                {
                                    if (refParaStart == false)//Developer Name:Priyanka Vishwakarma,Date:19-03-2021,Requirement:Apply figc para after reference 
                                        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "FIG" };
                                }
                            }
                            else
                            {
                                if (refParaStart == false)//Developer Name:Priyanka Vishwakarma,Date:19-03-2021,Requirement:Apply figc para after reference 
                                    P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "FIG" });
                            }
                        }
                    }
                }
                D.Save();
            }
        }

        public static void Tt_StyleApplied(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P != null && P.InnerText != "")
                    {
                        if (P.InnerText.ToLower().TrimStart().StartsWith("table") && P.Descendants<Run>().ToList().FirstOrDefault().Descendants().Any(x => x.LocalName == "b"))
                        {
                            //Developer name :Priyanka Vishwakarma ,Date:01-02-2020 ;Requirement:Check if Paragraph Start with Table and it has citetbl character style then dont apply TT paragraph style. Integrated by:Vikas sir.
                            if (P.Descendants<Run>().ToList().FirstOrDefault() != null && P.Descendants<Run>().ToList().FirstOrDefault().Descendants().Where(x => x.LocalName == "rStyle").FirstOrDefault() != null && P.Descendants<Run>().ToList().FirstOrDefault().Descendants().Where(x => x.LocalName == "rStyle").FirstOrDefault().GetAttribute("val", P.NamespaceUri).Value == "citetbl")
                            {
                                continue;
                            }
                            if (P.ParagraphProperties != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null)
                                {
                                    P.ParagraphProperties.ParagraphStyleId.Val = "TT";
                                }
                                else
                                {
                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "TT" };
                                }
                            }
                            else
                            {
                                P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "TT" });
                            }

                        }
                        //Developer Name :Priyanka Vishwakarma ,Date:16_08_2019 ,Requirement:Add Supplemetary Table in xml ,Integrated by:Vikas Sir,
                        else if (P.InnerText.ToLower().TrimStart().StartsWith("supplementary table") && P.Descendants<Run>().ToList().FirstOrDefault().Descendants().Any(x => x.LocalName == "b"))
                        {
                            if (P.ParagraphProperties != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null)
                                {
                                    P.ParagraphProperties.ParagraphStyleId.Val = "TT";
                                }
                                else
                                {
                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "TT" };
                                }
                            }
                            else
                            {
                                P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "TT" });
                            }
                        }
                        else if (P.InnerText.ToLower().TrimStart().StartsWith("list of abbreviations") && (P.Descendants<Run>().ToList().FirstOrDefault().Descendants().Any(x => x.LocalName == "b") || P.Descendants<Run>().ToList().FirstOrDefault().Descendants().Any(x => x.LocalName == "bCs")))
                        {
                            if (P.ParagraphProperties != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null)
                                {
                                    P.ParagraphProperties.ParagraphStyleId.Val = "TT";
                                }
                                else
                                {
                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "TT" };
                                }
                            }
                            else
                            {
                                P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "TT" });
                            }
                        }

                        //-----------------End---------------------------------------------------------
                    }
                }
                D.Save();
            }
        }

        public static void Tfn_StyleApplied(string newDoc)
        {

            bool tableFound = false;   //Developer Name:Priyanka Vishwakarma ,Date:13_8_2019 ,Requirement:Apply Table Footnote when paraStart with superscript present in table.(ex, a,b, or (a,b)) ,Integrated by:Viksa sir.
            List<string> txtList = new List<string>();
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P.PreviousSibling() != null && P.PreviousSibling().LocalName == "tbl")
                    {
                        tableFound = true;
                        if (P.InnerText.Trim() != "" && !P.InnerText.Trim().ToLower().StartsWith("table") && !P.InnerText.ToLower().StartsWith("fig") && !P.InnerText.Trim().ToLower().StartsWith("supplementary table") && !P.InnerText.ToLower().TrimStart().StartsWith("list of abbreviations"))  //Developer Name :Priyanka Vishwakarma ,Date:16_08_2019 ,Requirement:Add Supplemetary Table in xml ,Integrated by:Vikas Sir, //Date:16_08_2019 Requirement:Add Supplementary table.////Developer Name:Priyanka Vishwakarma ,Date:22_5_2019 ,Requirement:for avoid blank tfoot avoid ,Integrated By:Vikas sir   /////30-01-2020
                        {
                            //if (P.ParagraphProperties != null)
                            //{
                            //    //if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val != "H1")   //  Developer Name:Priyanka Vishwakarma ,Date:19_6_2019 ,Requirement:H1 Heading apply to Appendix Para  ,Integrated By:Vikas sir
                            //    //{
                            //    if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val != "H1" && P.ParagraphProperties.ParagraphStyleId.Val != "TXT")   //  Developer Name:Priyanka Vishwakarma ,Date:06_11_2019 ,Requirement:Table Comes within body section not at end of document(3448_THI_J_NJCA-19-0010).   ,Integrated By:Vikas sir
                            //    {
                            //        P.ParagraphProperties.ParagraphStyleId.Val = "TFN";
                            //    }
                            //    else
                            //    {
                            //        if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val != "H1" && P.ParagraphProperties.ParagraphStyleId.Val != "TXT")   //  Developer Name:Priyanka Vishwakarma ,Date:06_11_2019 ,Requirement:Table Comes within body section not at end of document(3448_THI_J_NJCA-19-0010).   ,Integrated By:Vikas sir
                            //        {
                            //            P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "TFN" };
                            //        }
                            //        // P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "TFN" };
                            //    }
                            //}
                            //else
                            //{
                            //    if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val != "H1" && P.ParagraphProperties.ParagraphStyleId.Val != "TXT")   //  Developer Name:Priyanka Vishwakarma ,Date:06_11_2019 ,Requirement:Table Comes within body section not at end of document(3448_THI_J_NJCA-19-0010).   ,Integrated By:Vikas sir                         
                            //    {
                            //        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "TFN" };
                            //    }
                            //    //P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "TFN" });
                            //}
                            if (P.ParagraphProperties != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId.Val != "H1" && P.ParagraphProperties.ParagraphStyleId.Val != "H2" && P.ParagraphProperties.ParagraphStyleId.Val != "H3" && P.ParagraphProperties.ParagraphStyleId.Val != "H4" && P.ParagraphProperties.ParagraphStyleId.Val != "H5" && P.ParagraphProperties.ParagraphStyleId.Val != "h6" && P.ParagraphProperties.ParagraphStyleId.Val != "H7" && P.ParagraphProperties.ParagraphStyleId.Val != "TXT" && P.ParagraphProperties.ParagraphStyleId.Val != "TT")//Developer Name:Priyanka Vishwakarma,Date:19-03-2021,Requirment :Add condition for avoid to apply TFN para style to TT para style.
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val = "TFN";
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId();
                                    P.ParagraphProperties.ParagraphStyleId.Val = "TFN";
                                }
                            }
                            else
                            {
                                P.ParagraphProperties = new ParagraphProperties();
                                P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId();
                                P.ParagraphProperties.ParagraphStyleId.Val = "TFN";
                            }
                        }
                    }
                    #region table foot note style
                    else   //----create list of superscript in table.   Added By Priyanka on 19_02_2019
                    {
                        txtList.Clear();
                        foreach (var para in D.Body.ChildElements.ToList())
                        {
                            if (para.LocalName == "tbl")
                            {
                                foreach (var table1 in para.ChildElements.ToList())
                                {
                                    if (table1 != null)
                                    {
                                        if (table1.Descendants<Run>().Count() != 0)
                                        {
                                            var R = table1.Descendants<Run>().ToList();
                                            foreach (var R1 in R)
                                            {
                                                if (R1 != null)
                                                {
                                                    foreach (OpenXmlElement ox in R1.ChildElements)
                                                    {
                                                        if (ox.XName == W.rPr)
                                                        {
                                                            if (ox.HasChildren)
                                                            {
                                                                foreach (OpenXmlElement ox1 in ox.ChildElements)
                                                                {
                                                                    if (ox1.XName == W.vertAlign)
                                                                    {
                                                                        if (ox1.HasAttributes)
                                                                        {
                                                                            foreach (var item in ox1.GetAttributes())
                                                                            {
                                                                                if (item.Value == "superscript")
                                                                                {
                                                                                    // txtList.Add(R1.InnerText);
                                                                                    //Developer Name:Priyanka Vishwakarma ,Date:13_8_2019 ,Requirement:Apply Table Footnote when paraStart with superscript present in table.(ex, a,b, or (a,b)) ,Integrated by:Viksa sir.
                                                                                    if (R1.InnerText.Contains(','))
                                                                                    {
                                                                                        string[] mulSup = R1.InnerText.Split(',');
                                                                                        foreach (var a in mulSup)
                                                                                        {
                                                                                            txtList.Add(a);
                                                                                        }
                                                                                    }
                                                                                    else
                                                                                    {
                                                                                        txtList.Add(R1.InnerText);
                                                                                    }

                                                                                    //---------------------End----------------------------------------------

                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                        }

                        //for check superscript inner text match with superscript within table

                        if (P != null && tableFound == true)    //Developer Name:Priyanka Vishwakarma ,Date:13_8_2019 ,Requirement:Apply Table Footnote when paraStart with superscript present in table.(ex, a,b, or (a,b)) ,Integrated by:Viksa sir.
                        {

                            if (P.Descendants<Run>().Count() != 0)
                            {
                                Run R = P.Descendants<Run>().First();
                                if (R != null)
                                {
                                    foreach (OpenXmlElement ox in R.Elements())
                                    {
                                        if (ox.XName == W.rPr)
                                        {
                                            if (ox.HasChildren)
                                            {
                                                foreach (OpenXmlElement ox1 in ox.Elements())
                                                {
                                                    if (ox1.XName == W.vertAlign)
                                                    {
                                                        if (ox1.HasAttributes)
                                                        {
                                                            foreach (var item in ox1.GetAttributes())
                                                            {
                                                                if (item.Value == "superscript")
                                                                {
                                                                    if (P.ParagraphProperties != null)
                                                                    {

                                                                        if (P.ParagraphProperties.ParagraphStyleId != null)
                                                                        {
                                                                            for (int i = 0; i < txtList.Count; i++)
                                                                            {
                                                                                if (P.InnerText.StartsWith(txtList[i]))
                                                                                {
                                                                                    P.ParagraphProperties.ParagraphStyleId.Val.Value = "TFN";
                                                                                }
                                                                                else
                                                                                {

                                                                                }
                                                                            }

                                                                        }

                                                                    }

                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                        }
                        //---End by Priyanka on 19_02_2019. 
                        #endregion
                    }

                }
                D.Save();
            }
        }

        public static void H5_StyleApplied(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {

                }
                D.Save();
            }
        }

        public static void Ul_StyleApplied(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {

                }
                D.Save();
            }
        }
        ///Developer name:priyanka Vishwakarma ,Date:28_5_2019 ,Requirement:Para after EXT style have  right alignment shold be apply EXT-AU style, Integrated by:Vikas sir.
        public static void extAu_styleApplied(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;


                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P != null && P.InnerText != null)
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId.Val.Value == "EXT" && P.NextSibling() != null && P.NextSibling().LocalName != "sectPr")
                                {
                                    Paragraph checkp = (Paragraph)P.NextSibling();

                                    if (checkp.Elements().Where(x => x.XName == W.pPr).ToList().Count > 0 && checkp.Elements().Where(x => x.XName == W.pPr).LastOrDefault().Elements().Where(x => x.XName == W.jc).ToList().Count > 0 && checkp.Elements().Where(x => x.XName == W.pPr).LastOrDefault().Elements().Where(x => x.XName == W.jc).LastOrDefault().GetAttribute("val", checkp.NamespaceUri).Value == "right")
                                    {
                                        if (checkp.InnerText.Trim() != "")
                                        {
                                            if (checkp.ParagraphProperties != null)
                                            {
                                                if (checkp.ParagraphProperties.ParagraphStyleId != null)
                                                {
                                                    checkp.ParagraphProperties.ParagraphStyleId.Val = "EXT-AU";
                                                }
                                                else
                                                {
                                                    checkp.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "EXT-AU" };
                                                }
                                            }
                                            else
                                            {
                                                checkp.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "EXT-AU" });
                                            }
                                        }

                                    }

                                }
                            }
                        }
                    }
                }

                D.Save();
            }
        }

        //-------------------------End--------------------------------------------------------------
        public static void ChangeAUpretoAU(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
               .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P != null && P.InnerText != "")
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val == "au-pre")
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val = "AU";
                                break;
                            }

                        }

                    }
                }
                D.Save();
            }
        }
        public static void ApplyEQParaStyle(string newDoc)   //Developer name:priyanka Vishwakarma ,Date:29_08_2019 ,Requirement:Apply EQ paragraph Style for Display equation  .Integrated By:vikas sir.
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
               .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P != null && P.InnerText != "")
                    {
                        if (P.InnerText.ToLower().Trim().StartsWith("formula_") && !P.InnerText.Replace("formula_", "").ToList().Any(x => char.IsLetter(x)))////letter condition added by vikas on 17-07-2021
                        {
                            if (P.ParagraphProperties != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null)
                                {
                                    P.ParagraphProperties.ParagraphStyleId.Val = "EQ";
                                }
                                else
                                {
                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "EQ" };
                                }
                            }
                            else
                            {
                                P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "EQ" });
                            }
                        }
                        else if (P.InnerText.ToLower().Trim().StartsWith("formula_"))/////start with formula_ but it has other text also
                        {
                            if (P.ParagraphProperties != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null)
                                {
                                    P.ParagraphProperties.ParagraphStyleId.Val = "BodyA";
                                }
                                else
                                {
                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "BodyA" };
                                }
                            }
                            else
                            {
                                P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "BodyA" });
                            }
                        }
                    }
                }
                D.Save();
            }
        }
        public static void removeBlankHead(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {

                    if (P != null && P.InnerText.Trim() == "" && P.Parent != null && P.Parent.LocalName != "tc") //Developer Name:Priyanka Vishwakarma, Date:7-2-2022, Document currupt because of table.
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null)
                            {

                                if (P.ParagraphProperties.ParagraphStyleId.Val.Value == "H1" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H2" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H3" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H4" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H5" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H6" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H7") //added on 8_4_2019 by Priyanka for heading text..H1-H7 Style
                                {
                                    P.Remove();
                                }
                            }
                        }
                    }
                }

                D.Save();
            }
        }
        //////Developer Name:Priyanka Vishwakarma ,Date:11_09_2019 ,Requirement :Apply TT paragraph style to blank paragraph or add new paragraph if Callout missing for table in word document (2884_THI_J_IJNS-19-00035-OA.docx). ,Integrated by:Vikas sir
        public static void AddTTStyleforWithoutCalloutTable(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (var xe1 in D.Descendants<DocumentFormat.OpenXml.Wordprocessing.Table>().ToList())
                {
                    Paragraph prePara = xe1.PreviousSibling<Paragraph>();

                    if (prePara != null && prePara.InnerText.Trim() != "" && prePara.ParagraphProperties != null && prePara.ParagraphProperties.ParagraphStyleId != null && prePara.ParagraphProperties.ParagraphStyleId.Val != null && prePara.ParagraphProperties.ParagraphStyleId.Val == "TT")
                    {
                        continue;
                    }
                    else if (prePara != null && prePara.InnerText.Trim() == "")
                    {
                        if (prePara.ParagraphProperties != null && prePara.ParagraphProperties.ParagraphStyleId != null && prePara.ParagraphProperties.ParagraphStyleId.Val != null && prePara.ParagraphProperties.ParagraphStyleId.Val == "BodyA")
                        {
                            prePara.ParagraphProperties.ParagraphStyleId.Val = "TT";

                        }
                    }
                    else if (prePara != null && prePara.InnerText.Trim() != "")
                    {
                        if (prePara.ParagraphProperties != null && prePara.ParagraphProperties.ParagraphStyleId != null && prePara.ParagraphProperties.ParagraphStyleId.Val != null && prePara.ParagraphProperties.ParagraphStyleId.Val == "TFN")
                        {
                            Paragraph p = new Paragraph();
                            p.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "TT" });
                            xe1.InsertBeforeSelf(p);

                        }
                        //Developer Name:Priyanka Vishwakarma ,Date:06_11_2019 ,Requirement:Add TT paragraph style to blank paragraph or add new paragraph if Callout missing and table heading Missing  for table in word document ,Integrated By:Vikas sir.
                        else if (prePara.ParagraphProperties != null && prePara.ParagraphProperties.ParagraphStyleId != null && prePara.ParagraphProperties.ParagraphStyleId.Val != null /*&& prePara.ParagraphProperties.ParagraphStyleId.Val == "BodyA"*/)
                        {
                            Paragraph p = new Paragraph();
                            p.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "TT" });
                            xe1.InsertBeforeSelf(p);

                        }
                        //------------------------End------------------------------------------------
                    }

                }

                D.Save();
            }
        }
        public static void orcidParaApplyBodyAStyle(string newDoc)
        {

            using (WordprocessingDocument WPD = WordprocessingDocument.Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;
                Document D = MDP.Document;
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(e => e != null && e.ParagraphProperties != null && e.ParagraphProperties.ParagraphStyleId != null && (e.ParagraphProperties.ParagraphStyleId.Val == "UID" || e.ParagraphProperties.ParagraphStyleId.Val == "orcid")))
                {
                    if (P != null && P.InnerText != "")
                    {
                        string orcidIDParaWothputAuthorAndIdFound = GlobalMethods.RegExSearch(P.InnerText.TrimStart(' '), @"[0-9]{4}\-[0-9]{4}\-[0-9]{4}\-[0-9X]{4}");

                        if (P.InnerText.Contains("ORCID"))
                        {
                            P.ParagraphProperties.ParagraphStyleId.Val = "BodyA";
                        }
                        else if (!string.IsNullOrEmpty(orcidIDParaWothputAuthorAndIdFound))   //for orcid id only number given.
                        {
                            P.ParagraphProperties.ParagraphStyleId.Val = "BodyA";
                        }
                    }
                }
                D.Save();
            }
        }

        ////Developer Name:Priyanka Vishwakarma ,Date:11_09_2019 ,Requirement :Apply REF style to Reference Paragraph in word. ,Integrated by:Vikas sir
        public static void ChangeReferenceToREFStyle(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().Where(x => x.Parent != null && x.Parent.LocalName != W.tc.LocalName).ToList())
                {

                    if (P != null && P.InnerText.Trim() != "" && (P.InnerText.ToLower().Trim().Equals("references") || P.InnerText.ToLower().Trim().Equals("reference") || P.InnerText.ToLower().Trim().Equals("references cited") || P.InnerText.ToLower().Trim().Equals("selected bibliography") || P.InnerText.ToLower().Trim().Equals("bibliografia:") || P.InnerText.ToLower().Trim().Equals("bibliografia")))//Developer Name:Priyanka Vishwakarma , Date : 08-06-2020 ,Requirement:Apply REF paragarph style to heading Reference in cleanup process
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null)
                            {

                                if (P.ParagraphProperties.ParagraphStyleId.Val.Value == "H1")
                                {
                                    P.ParagraphProperties.ParagraphStyleId.Val.Value = "REF";
                                }
                            }
                        }
                    }
                }

                D.Save();
            }
        }
        public static void funding_paraStyle(string newDoc)     //Developer Name:Priyanka Vishwakarma, Date:14_8_2019 ,Requirement:Funding Paragraph apply H5 paragraph style in word document. ,Integrated by:Vikas sir.
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P != null && P.InnerText != "")
                    {
                        if (P.InnerText.ToLower().StartsWith("funding") || P.InnerText.ToLower().StartsWith("fundings"))
                        {
                            if (P.ParagraphProperties != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null)
                                {
                                    P.ParagraphProperties.ParagraphStyleId.Val = "H5";
                                }
                                else
                                {
                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "H5" };
                                }
                            }
                            else
                            {
                                P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "H5" });
                            }
                        }
                    }
                }
                D.Save();
            }
        }
        public static void removeChangeBoldBraketsInFigureCaption(string newDoc)     //Developer Name:Priyanka Vishwakarma, Date:15_10_2019 ,Requirement:Opening and Closing BRACKETs should be UNBOLD in Figure Caption ,Integrated by:Vikas sir.
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                // Run startBraket = new Run(new RunProperties(new Text("(")));
                //  Run endBraket = new Run(new RunProperties(new Text(")")));
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val.Value == "FIGC")
                    {
                        foreach (Run r in P.Descendants<Run>().ToList()/*.Any(x => x.LocalName == "b")*/)
                        {
                            if (r.Descendants().ToList().Any(x => x.LocalName == "b") && r.InnerText.Trim().StartsWith("(") && r.InnerText.Trim().EndsWith(")"))
                            {
                                Run figText = new Run(new RunProperties(new Bold()));
                                figText.AppendChild(new Text(r.InnerText.Trim().Replace("(", "").Replace(")", "")));
                                if (r.InnerText.StartsWith(" ") || r.InnerText.StartsWith(" "))
                                {
                                    Run newrun = new Run();
                                    Text T = new Text(" ") { Space = SpaceProcessingModeValues.Preserve };
                                    newrun.AppendChild(T);
                                    r.InsertBeforeSelf(newrun);
                                    r.InsertBeforeSelf(new Run(new Text("(")));

                                }
                                else
                                {
                                    r.InsertBeforeSelf(new Run(new Text("(")));
                                }
                                r.InsertBeforeSelf(figText);
                                if (r.InnerText.EndsWith(" ") || r.InnerText.EndsWith(" "))
                                {
                                    r.InsertBeforeSelf(new Run(new Text(")")));
                                    Run newrun = new Run();
                                    Text T = new Text(" ") { Space = SpaceProcessingModeValues.Preserve };
                                    newrun.AppendChild(T);
                                    r.InsertBeforeSelf(newrun);
                                }
                                else
                                {
                                    r.InsertBeforeSelf(new Run(new Text(")")));
                                }

                                r.Remove();
                            }
                        }
                    }

                }
                D.Save();
            }
        }
        public static void NormalParaConverttoBodyA(string newDoc)     //Developer Name:Priyanka Vishwakarma, Date:04_11_2019 ,Requirement:apply BodyA paragraph style to normal paragraph . ,Integrated by:Vikas sir.
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P.ParagraphProperties != null)
                    {
                        if (P.ParagraphProperties.ParagraphStyleId == null)
                        {
                            P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId();
                            P.ParagraphProperties.ParagraphStyleId.Val = "BodyA";
                        }
                    }
                    else
                    {
                        P.ParagraphProperties = new ParagraphProperties();
                        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId();
                        P.ParagraphProperties.ParagraphStyleId.Val = "BodyA";
                    }
                }
                D.Save();
            }
        }
        public static void removeComment(string newDoc)     //Developer Name:Priyanka Vishwakarma, Date:17_12_2019 ,Requirement:Remove CommentRangeStart and commentRangeEnd if text is not selected for comment in word document.(3565_THI_J_Test3586-09-002019) ,Integrated by:Vikas sir.
        {
            bool CommentStartWithoutText = false;

            List<string> ParagraphStylesColl = new List<string>();
            ///Configuration read from Supporting folder
            ParagraphStylesColl = GlobalMethods.ReadAndStoreFileValuesInArray(ConfigurationManager.AppSettings.Get("CommentParagraphStyleList"));
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    CommentStartWithoutText = false;

                    //if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && (P.ParagraphProperties.ParagraphStyleId.Val.Value == "TT" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "FIGC" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "CORR"))
                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && ParagraphStylesColl.Any(x => x == P.ParagraphProperties.ParagraphStyleId.Val.Value.ToString()))  //04-01-2020
                    {
                        if (P.Descendants().ToList().Any(x => x.LocalName == "commentRangeStart") && P.Descendants().ToList().Any(x => x.LocalName == "commentRangeEnd") && P.Descendants().ToList().Any(x => x.LocalName == "commentReference"))
                        {
                            foreach (var ele in P.Descendants().ToList().Where(x => x.LocalName == "commentRangeStart"))
                            {
                                if (ele.NextSibling() != null && ele.NextSibling().LocalName == "commentRangeEnd" && ele.HasAttributes == true && ele.NextSibling().HasAttributes == true && ele.GetAttribute("id", ele.NamespaceUri).Value == ele.NextSibling().GetAttribute("id", ele.NextSibling().NamespaceUri).Value)
                                {
                                    CommentStartWithoutText = true;

                                }

                            }
                        }
                    }

                    if (CommentStartWithoutText == true)
                    {
                        foreach (var cDelete in P.Descendants().ToList())
                        {
                            if (cDelete.LocalName == "commentRangeStart" || cDelete.LocalName == "commentRangeEnd")
                            {
                                cDelete.Remove();
                            }

                        }

                    }

                }
                D.Save();
            }
        }
        //Developer Name:Priyanka Vishwakarma, Date:19_12_2019 ,Requirement:Add Orcid Footnote in xml file ,Integrated by:Vikas sir.
        public static void orcidStyle(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                List<string> authorename = new List<string>();
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P.ParagraphProperties != null)
                    {
                        if (P.ParagraphProperties.ParagraphStyleId != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId.Val.Value == "AU")
                            {
                                string match = P.InnerText;
                                string[] AuList = match.Split(',');

                                foreach (var name in AuList)
                                {
                                    string au = Regex.Replace(name, "[0-9]+", "");

                                    if (!string.IsNullOrEmpty(au))
                                    {
                                        authorename.Add(au.Replace("*", "").Trim());
                                    }

                                }
                            }
                        }
                    }
                }

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    ////Start Added by vikas on 02-03-2021 for apply ORCID-AU 3cm style to orchid style of customer style
                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower() == "orcid")
                    {
                        P.ParagraphProperties.ParagraphStyleId.Val = "ORCID-AU";
                        continue;
                    }
                    ////End Added by vikas on 02-03-2021
                    Regex regcitefig = new Regex(@"[0-9]{4}[\-|\—|\–][0-9]{4}[\-|\—|\–][0-9]{4}[\-|\—|\–][0-9X]{4}");
                    if (regcitefig.IsMatch(P.InnerText))
                    {
                        foreach (var orcidAU in authorename)
                        {
                            if (P.InnerText.Replace(" ", "").Replace(" ", "").ToLower().StartsWith("dr." + orcidAU.Replace(" ", "").Replace(" ", "").ToLower() + "’sorcid") ||
                                P.InnerText.Replace(" ", "").Replace(" ", "").ToLower().StartsWith("dr" + orcidAU.Replace(" ", "").Replace(" ", "").ToLower() + "’sorcid") ||
                                P.InnerText.Replace(" ", "").Replace(" ", "").ToLower().StartsWith(orcidAU.Replace(" ", "").Replace(" ", "").ToLower() + "https://orcid.org/"))
                            {
                                if (P.ParagraphProperties != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId != null)
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val = "ORCID-AU";
                                    }
                                    else
                                    {
                                        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "ORCID-AU" };
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "ORCID-AU" });
                                }
                                goto nextpara;

                            }
                            else if (orcidAU.Contains("."))
                            {
                                string fname = "";
                                string sname = "";

                                string[] au_FnameSurname = orcidAU.Split(' ');
                                if (au_FnameSurname.Count() == 3)
                                {
                                    fname = au_FnameSurname[0];
                                    sname = au_FnameSurname[2];


                                    if (P.InnerText.ToLower().Contains(fname.ToLower()) && P.InnerText.ToLower().Contains(sname.ToLower())) //&& P.InnerText.ToLower().Contains("orcid"))
                                    {
                                        if (P.ParagraphProperties != null)
                                        {
                                            if (P.ParagraphProperties.ParagraphStyleId != null)
                                            {
                                                P.ParagraphProperties.ParagraphStyleId.Val = "ORCID-AU";
                                            }
                                            else
                                            {
                                                P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "ORCID-AU" };
                                            }
                                        }
                                        else
                                        {
                                            P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "ORCID-AU" });
                                        }
                                        goto nextpara;

                                    }
                                }
                            }

                        }
                    }
                nextpara: { }


                }
                D.Save();
            }
        }
        public static void FormatorcidPara(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                List<string> authorename = new List<string>();
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P.ParagraphProperties != null)
                    {
                        if (P.ParagraphProperties.ParagraphStyleId != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId.Val.Value == "AU")
                            {
                                string match = P.InnerText;
                                string[] AuList = match.Split(',');

                                foreach (var name in AuList)
                                {
                                    string au = Regex.Replace(name, "[0-9]+", "");

                                    if (!string.IsNullOrEmpty(au))
                                    {
                                        authorename.Add(au.Replace("*", "").Trim());
                                    }

                                }
                            }
                        }
                    }
                }

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    ////Start Added by vikas on 02-03-2021 for apply ORCID-AU 3cm style to orchid style of customer style
                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower() == "orcid")
                    {
                        P.ParagraphProperties.ParagraphStyleId.Val = "ORCID-AU";
                        continue;
                    }
                    ////End Added by vikas on 02-03-2021
                    Regex regcitefig = new Regex(@"[0-9]{4}[\-|\—|\–][0-9]{4}[\-|\—|\–][0-9]{4}[\-|\—|\–][0-9X]{4}");
                    if (regcitefig.IsMatch(P.InnerText))
                    {
                        string OrcidId = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(P.InnerText, @"([0-9]{4}[\-|\—|\–][0-9]{4}[\-|\—|\–][0-9]{4}[\-|\—|\–][0-9X]{4})");                        
                        foreach (var orcidAU in authorename)
                        {
                            if (P.InnerText.Replace(" ", " ").Replace(" ", " ").ToLower().Contains(orcidAU.Replace(" ", " ").Replace(" ", " ").ToLower()))
                            {
                                if (P.ParagraphProperties != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId != null)
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val = "ORCID-AU";

                                        string auhtorNameStr = orcidAU;
                                        if(!string.IsNullOrEmpty(OrcidId) && !string.IsNullOrEmpty(orcidAU))
                                        {
                                            Run authorname = new Run(new RunProperties(new Italic()));
                                            //Italic italic = new Italic();
                                            //authorname.RunProperties.AppendChild(italic);
                                            Text name = new Text { Text = orcidAU, Space = SpaceProcessingModeValues.Preserve };
                                            authorname.AppendChild(name);
                                            Run orcidIdText = new Run();
                                            string strorcidIdText= "https://orcid.org/"+ OrcidId.Replace("–", "-").Replace("—", "-");
                                            Text runOrcidIDText = new Text { Text = " "+ strorcidIdText, Space = SpaceProcessingModeValues.Preserve };
                                            orcidIdText.AppendChild(runOrcidIDText);
                                            foreach(var run in P.Descendants<Run>().ToList())
                                            {
                                                run.Remove();
                                            }
                                            P.AppendChild(authorname);
                                            P.AppendChild(orcidIdText);
                                        }
                                    }
                                    else
                                    {
                                        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "ORCID-AU" };
                                        string auhtorNameStr = orcidAU;
                                        if (!string.IsNullOrEmpty(OrcidId) && !string.IsNullOrEmpty(orcidAU))
                                        {
                                            Run authorname = new Run(new RunProperties(new Italic()));
                                            //Italic italic = new Italic();
                                            //authorname.RunProperties.AppendChild(italic);
                                           
                                            Text name = new Text { Text = orcidAU, Space = SpaceProcessingModeValues.Preserve };
                                            authorname.AppendChild(name);
                                            Run orcidIdText = new Run();
                                            string strorcidIdText = "https://orcid.org/" + OrcidId.Replace("–", "-").Replace("—", "-");
                                            Text runOrcidIDText = new Text { Text = " " + strorcidIdText, Space = SpaceProcessingModeValues.Preserve };
                                            orcidIdText.AppendChild(runOrcidIDText);
                                            foreach (var run in P.Descendants<Run>().ToList())
                                            {
                                                run.Remove();
                                            }
                                            P.AppendChild(authorname);
                                            P.AppendChild(orcidIdText);
                                        }
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "ORCID-AU" });
                                    string auhtorNameStr = orcidAU;
                                    if (!string.IsNullOrEmpty(OrcidId) && !string.IsNullOrEmpty(orcidAU))
                                    {
                                        Run authorname = new Run(new RunProperties(new Italic()));
                                        //Italic italic = new Italic();
                                        //authorname.RunProperties.AppendChild(italic);
                                        
                                        Text name = new Text { Text = orcidAU, Space = SpaceProcessingModeValues.Preserve };
                                        authorname.AppendChild(name);
                                        Run orcidIdText = new Run();
                                        string strorcidIdText = "https://orcid.org/" + OrcidId.Replace("–", "-").Replace("—", "-");
                                        Text runOrcidIDText = new Text { Text = " " + strorcidIdText, Space = SpaceProcessingModeValues.Preserve };
                                        orcidIdText.AppendChild(runOrcidIDText);
                                        foreach (var run in P.Descendants<Run>().ToList())
                                        {
                                            run.Remove();
                                        }
                                        P.AppendChild(authorname);
                                        P.AppendChild(orcidIdText);
                                    }
                                }
                                goto nextpara;

                            }
                            else if (orcidAU.Contains("."))
                            {
                                string fname = "";
                                string sname = "";

                                string[] au_FnameSurname = orcidAU.Split(' ');
                                if (au_FnameSurname.Count() == 3)
                                {
                                    fname = au_FnameSurname[0];
                                    sname = au_FnameSurname[2];


                                    if (P.InnerText.ToLower().Contains(fname.ToLower()) && P.InnerText.ToLower().Contains(sname.ToLower())) //&& P.InnerText.ToLower().Contains("orcid"))
                                    {
                                        if (P.ParagraphProperties != null)
                                        {
                                            if (P.ParagraphProperties.ParagraphStyleId != null)
                                            {
                                                P.ParagraphProperties.ParagraphStyleId.Val = "ORCID-AU";
                                            }
                                            else
                                            {
                                                P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "ORCID-AU" };
                                            }
                                        }
                                        else
                                        {
                                            P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "ORCID-AU" });
                                        }
                                        goto nextpara;

                                    }
                                }
                            }

                        }
                    }
                nextpara: { }


                }
                D.Save();
            }
        }

        //---------------------------------------------------------------------------------------------------------------------
        public static void GetCommentsBeforeDocument(string fileName)
        {
            //List<string> cmt = new List<string>();
            using (WordprocessingDocument WPD = WordprocessingDocument
                .Open(fileName, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                WordprocessingCommentsPart commentsPart =
                    D.MainDocumentPart.WordprocessingCommentsPart;

                if (commentsPart != null && commentsPart.Comments != null)
                {
                    foreach (Comment comment in commentsPart.Comments.Elements<Comment>())
                    {
                        GlobalMethods.beforecmt.Add(comment.InnerText.Replace(" ", " ").Replace(" ", " ").Replace(" ", " ").Trim());
                    }
                }

                D.Save();
            }
        }
        public static void GetCommentsAfterDocument(string fileName)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
    .Open(fileName, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                WordprocessingCommentsPart commentsPart =
                    D.MainDocumentPart.WordprocessingCommentsPart;

                if (commentsPart != null && commentsPart.Comments != null)
                {
                    foreach (Comment comment in commentsPart.Comments.Elements<Comment>())
                    {
                        GlobalMethods.Aftercmt.Add(comment.InnerText.Replace(" ", " ").Replace(" ", " ").Replace(" ", " ").Trim());
                    }
                }


                D.Save();
            }

        }

        public static void checkMissingComment(string fileName, List<string> list1, List<string> list2)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(fileName, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                WordprocessingCommentsPart commentsPart =
                    D.MainDocumentPart.WordprocessingCommentsPart;

                foreach (var cmt in list2.ToList())
                {
                    //if (list1.Contains(cmt))
                    //{
                    if (list1.Any(x => x.ToLower().Replace(" ", "").Replace(" ", "").Contains(cmt.ToLower().Replace(" ", "").Replace(" ", ""))))   //Developer name:Priyanka Vishwakarma ,Date:25-01-2020 ,Requirement:remove em-space ,en-space from text.
                    {
                        list1.Remove(cmt);

                    }
                }

                if (list1.Count > 0)
                {
                    string commenttxt = "Queries are Missing::";
                    foreach (var a in list1.ToList())
                    {
                        commenttxt += " " + a + " ";  //04-01-2020
                    }
                    var lastPara = D.Descendants<Paragraph>().ToList().Last();
                    int id = 0;
                    Comments comments = null;
                    if (MDP.WordprocessingCommentsPart != null)/////null check added by vikas on 08-12-2020
                    {
                        comments = MDP.WordprocessingCommentsPart.Comments;
                        if (comments.HasChildren)
                        {
                            id = Convert.ToInt32(comments.Descendants<Comment>().ToList().LastOrDefault().Id.Value) + 1;
                        }

                        Paragraph p = new Paragraph(new Run(new Text(commenttxt)));
                        Comment cmt =
                            new Comment()
                            {
                                Id = id.ToString(),
                                Date = DateTime.Now
                            };
                        cmt.AppendChild(p);
                        comments.AppendChild(cmt);
                        comments.Save();

                        Paragraph p1 = new Paragraph();
                        p1.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "BodyA" });//Developer Name:Priyanka Vishwakarma, Date:21-07-2021,Apply bodyA paragarph style for author query.
                        Run lastcmt = (new Run(new CommentReference() { Id = id.ToString() }));
                        //Developer Name:Priyanka Vishwakarma ,Date:24-09-2020 ,Requirement:Add Author Query into new paragraph and add paragraph after last para. 
                        p1.AppendChild(lastcmt);
                        lastPara.InsertAfterSelf(p1);
                    }
                    //lastPara.AppendChild(lastcmt);
                }


                D.Save();
            }

        }
        public static void ApplyFootnoteParaStyle(string newDoc)  //Developer name:priyanka Vishwakarma ,Date:11-01-2020 ,Requirement:Apply footnote paragraph style when paragraph has FTN paragraph style and text should be start with * . .Integrated By:vikas sir.
        {

            using (WordprocessingDocument WPD = WordprocessingDocument.Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;
                Document D = MDP.Document;
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(e => e != null && e.ParagraphProperties != null && e.ParagraphProperties.ParagraphStyleId != null && e.ParagraphProperties.ParagraphStyleId.Val == "FTN"))
                {
                    if (P != null && P.InnerText != "")
                    {
                        //DEveloper name:priyanka Vishwakarma, Date:10-04-2020 ,Requirement:Apply Footnote paragraph style to paragraph .Integrated by:Vikas sir
                        string str = GlobalMethods.RegExSearch(P.InnerText, @"^[^A-Za-z0-9]+");
                        //if (P.InnerText.Trim().StartsWith("*"))
                        //{
                        //    P.ParagraphProperties.ParagraphStyleId.Val = "Footnote";
                        //}
                        ////--Developer name:Priyanka Vishwakarma ,Date:03-04-2020 ,Requirement:Handle # type FTN in Cleanup ,Integrated by:Vikas sir.
                        //else if (P.InnerText.Trim().StartsWith("#"))
                        //{
                        //    P.ParagraphProperties.ParagraphStyleId.Val = "BodyA";
                        //}
                        ////------------End on 03-04-2020---------------------------
                        if (!string.IsNullOrEmpty(str))
                        {
                            if (!string.IsNullOrEmpty(str))
                            {
                                if (P.Descendants<Run>().ToList().Any(x => x.InnerText.Trim().StartsWith(str.Trim()) && x.Descendants().ToList().Any(y => y.XName.LocalName == "vertAlign" && y.GetAttribute("val", P.NamespaceUri).Value == "superscript")))
                                {

                                    //}

                                    P.ParagraphProperties.ParagraphStyleId.Val.Value = "Footnote";
                                    //if (P.InnerText.Trim().StartsWith("*"))
                                    //{
                                    //    P.ParagraphProperties.ParagraphStyleId.Val = "Footnote";
                                    //}
                                    ////--Developer name:Priyanka Vishwakarma ,Date:03-04-2020 ,Requirement:Handle # type FTN in Cleanup ,Integrated by:Vikas sir.
                                    //else if (P.InnerText.Trim().StartsWith("#"))
                                    //{
                                    //    P.ParagraphProperties.ParagraphStyleId.Val = "BodyA";
                                    //}
                                    ////------------End on 03-04-2020---------------------------
                                }
                                else if (P.InnerText.Trim().StartsWith("*"))
                                {
                                    P.ParagraphProperties.ParagraphStyleId.Val = "Footnote";
                                }
                            }
                        }
                    }
                }

                D.Save();
            }
        }
        public static void RemoveBlankPara(string newDoc)     //Developer Name:Priyanka Vishwakarma, Date:14_8_2019 ,Requirement:Funding Paragraph apply H5 paragraph style in word document. ,Integrated by:Vikas sir.
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P != null && P.InnerText.Trim() == "")
                    {

                        if (P.ParagraphProperties != null && P.Parent != null && P.Parent.LocalName != "tc") //Developer Name:Priyanka Vishwakarma .Date:20-07-2020 ,Requirement :Avoid to remove blank para from table.
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.Parent != null && P.Parent.LocalName != "tc" && (P.ParagraphProperties.ParagraphStyleId.Val.Value == "TT" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "TFN" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "TXT"))
                            {
                                P.Remove();
                            }
                        }
                    }
                }
                D.Save();
            }
        }
        public static void RemoveBlankParaWithStyle(string newDoc)     //Developer Name:Priyanka Vishwakarma, Date:14_8_2019 ,Requirement:Funding Paragraph apply H5 paragraph style in word document. ,Integrated by:Vikas sir.
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P != null && P.InnerText.Trim() == "")
                    {

                        if (P.ParagraphProperties != null && P.Parent != null && P.Parent.LocalName != "tc") //Developer Name:Priyanka Vishwakarma .Date:20-07-2020 ,Requirement :Avoid to remove blank para from table.
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val.Value != null && P.Parent != null && P.Parent.LocalName != "tc" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "TT")
                            {
                                if (!P.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower().EndsWith("start") && !P.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower().EndsWith("end"))
                                {
                                    P.Remove();
                                }
                            }
                        }
                    }
                }
                D.Save();
            }
        }

        public static void applySupplementoryVideoStyle(string newDoc)     //Developer Name:Priyanka Vishwakarma, Date:14_8_2019 ,Requirement:Funding Paragraph apply H5 paragraph style in word document. ,Integrated by:Vikas sir.
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P != null && P.InnerText != "")
                    {
                        if (P.InnerText.ToLower().Trim().StartsWith("supplementary video") || P.InnerText.ToLower().Trim().StartsWith("supplemental video"))  ///Apply Suppvid parastyle to supplemental video 26-08-2020
                        {
                            if (P.ParagraphProperties != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null)
                                {
                                    P.ParagraphProperties.ParagraphStyleId.Val = "Suppvideo";
                                }
                                else
                                {
                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "Suppvideo" };
                                }
                            }
                            else
                            {
                                P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "Suppvideo" });
                            }
                        }
                    }
                }
                D.Save();
            }
        }
        public static void applySupplementoryVideoTxtStyle(string newDoc)     //Developer Name:Priyanka Vishwakarma, Date:14_8_2019 ,Requirement:Funding Paragraph apply H5 paragraph style in word document. ,Integrated by:Vikas sir.
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(x => x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val != null && x.ParagraphProperties.ParagraphStyleId.Val.Value == "Suppvideo").ToList())
                {
                    if (P.NextSibling() != null && P.NextSibling().LocalName.ToString() == "p")//27-08-2020
                    {
                        Paragraph NextPara = (Paragraph)P.NextSibling();
                        if (NextPara != null && NextPara.InnerText != "" && NextPara.Descendants<Run>().ToList().FirstOrDefault().Descendants().Any(x => x.LocalName == "b") == false)
                        {


                            if (NextPara.ParagraphProperties != null)
                            {
                                if (NextPara.ParagraphProperties.ParagraphStyleId != null)
                                {
                                    NextPara.ParagraphProperties.ParagraphStyleId.Val = "Suppvideo-TXT";

                                }
                                else
                                {
                                    NextPara.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "Suppvideo-TXT" };
                                }
                            }
                            else
                            {
                                NextPara.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "Suppvideo-TXT" });
                            }
                        }

                    }
                    D.Save();
                }
            }
        }

        public static void removeListingfromParagraph(string newDoc)    //Developer name : Priyanka Vishwakarma ,Date:22-02-2020 ,Requirement:remove listing when paragraph has only listing number (Live Job 4474_THI_J_NJCA-19-0068) ,Integrated by:Vikas sir.
        {
            List<string> PatternList = new List<string>();

            PatternList = GlobalMethods.ReadAndStoreFileValuesInArray(ConfigurationManager.AppSettings.Get("RemoveListnumber"));
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                string Listnumber = null;
                string gettxt = null;
                string TextwithoutListnumber = null;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(x => x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val != null).ToList())
                {

                    if (P.Parent != null && P.Parent.XName.LocalName != "tc" && (P.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower() == "nl" || P.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower() == "bl" || P.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower() == "ul" || P.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower().EndsWith("list")))
                    {
                        if (P.InnerText != null && P.InnerText.Trim() != "")
                        {

                            gettxt = P.InnerText.Trim();


                            for (int nIndex = 0; nIndex < PatternList.Count; nIndex++)
                            {

                                MatchCollection matches = Regex.Matches(gettxt, PatternList[nIndex]);

                                if (matches.Count == 1)
                                {
                                    TextwithoutListnumber = Regex.Replace(gettxt.Trim(), PatternList[nIndex], "", RegexOptions.IgnoreCase);
                                }
                            }

                            if (string.IsNullOrEmpty(TextwithoutListnumber))
                            {
                                if (TextwithoutListnumber == null || TextwithoutListnumber.Trim() == "")/////For null TextwithoutListnumber==null check condition added by vikas on 12-05-2020
                                    P.ParagraphProperties.ParagraphStyleId.Val.Value = "BodyA";


                            }
                        }
                    }

                }
                D.Save();
            }
        }


        public static void checkNormalParaorListingPara(string newDoc)    //Developer name : Priyanka Vishwakarma ,Date:22-02-2020 ,Requirement:Avoid to apply AlphaUpperList,AlphalowerList and RomanList when para start with A ot I in word.  ,Integrated by:Vikas sir.
        {
            List<string> ListofListingStyleinWord = new List<string>();


            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                string Listnumber = null;
                string gettxt = null;
                string TextwithoutListnumber = null;
                List<Paragraph> listingParagraph = D.Descendants<Paragraph>().ToList().Where(x => x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val != null && x.Parent != null && x.Parent.XName.LocalName != "tc" && (x.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower() == "nl" || x.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower() == "bl" || x.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower() == "ul" || x.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower().EndsWith("list"))).ToList();
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(x => x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val != null).ToList())
                {

                    if (P.Parent != null && P.Parent.XName.LocalName != "tc" && (P.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower() == "nl" || P.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower() == "bl" || P.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower() == "ul" || P.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower().EndsWith("list")))
                    {
                        ListofListingStyleinWord.Add(P.ParagraphProperties.ParagraphStyleId.Val.Value);
                    }

                }

                if (ListofListingStyleinWord.Count > 0)
                {
                    if (ListofListingStyleinWord.Contains("AlphaUpparList") || ListofListingStyleinWord.Contains("AlphaLowerList") || ListofListingStyleinWord.Contains("RomanList"))
                    {

                        foreach (Paragraph listPara in listingParagraph.ToList())
                        {

                            if (listPara.ParagraphProperties != null && listPara.ParagraphProperties.ParagraphStyleId != null && listPara.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                if (listPara.ParagraphProperties.ParagraphStyleId.Val.Value == "AlphaUpparList" || listPara.ParagraphProperties.ParagraphStyleId.Val.Value == "RomanList" || listPara.ParagraphProperties.ParagraphStyleId.Val.Value == "AlphaLowerList")
                                {
                                    if (listPara.InnerText.ToLower().StartsWith("a ") || listPara.InnerText.ToLower().StartsWith("i "))   //For Alphalist and roman list without dot and brackets.
                                    {
                                        if (listPara.NextSibling() != null && listPara.NextSibling().LocalName.ToString() == "p")  //DeveloperName:Priyanka Vishwakarma, Date:26-11-2021,Requirement: a check next sibling should be paragraph
                                        {
                                            Paragraph NextPara = (Paragraph)listPara.NextSibling();

                                            if (NextPara.ParagraphProperties != null && NextPara.ParagraphProperties.ParagraphStyleId != null && NextPara.ParagraphProperties.ParagraphStyleId.Val != null && !NextPara.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower().EndsWith("list"))
                                            {
                                                listPara.ParagraphProperties.ParagraphStyleId.Val.Value = "BodyA";
                                            }
                                        }
                                    }
                                }
                            }

                        }

                    }
                }
                D.Save();
            }
        }

        public static void HandleRomanList(string newDoc)    //Developer name : Priyanka Vishwakarma ,Date:22-02-2020 ,Requirement:Avoid to apply AlphaUpperList,AlphalowerList and RomanList when para start with A ot I in word.  ,Integrated by:Vikas sir.
        {
            List<string> ListofListingStyleinWord = new List<string>();


            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                string Listnumber = null;
                string gettxt = null;
                string TextwithoutListnumber = null;
                List<Paragraph> listingParagraph = D.Descendants<Paragraph>().ToList().Where(x => x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val != null && x.Parent != null && x.Parent.XName.LocalName != "tc" && (x.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower() == "nl" || x.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower() == "bl" || x.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower() == "ul" || x.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower().EndsWith("list"))).ToList();
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(x => x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val != null).ToList())
                {

                    if (P.Parent != null && P.Parent.XName.LocalName != "tc" && (P.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower() == "nl" || P.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower() == "bl" || P.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower() == "ul" || P.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower().EndsWith("list")))
                    {
                        ListofListingStyleinWord.Add(P.ParagraphProperties.ParagraphStyleId.Val.Value);
                    }

                }

                if (ListofListingStyleinWord.Count > 0)
                {
                    if (ListofListingStyleinWord.Contains("AlphaUpparList") || ListofListingStyleinWord.Contains("AlphaLowerList") || ListofListingStyleinWord.Contains("RomanList"))
                    {

                        foreach (Paragraph listPara in listingParagraph.ToList())
                        {

                            if (listPara.ParagraphProperties != null && listPara.ParagraphProperties.ParagraphStyleId != null && listPara.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                if (listPara.ParagraphProperties.ParagraphStyleId.Val.Value == "RomanList")
                                {
                                    if (listPara.InnerText.ToLower().StartsWith("i ") || listPara.InnerText.ToLower().StartsWith("i. "))  //Developer name:Priyanka Vishwakarma ,Date:26-03-2020 Requirement:For Alphalist and roman list without dot and brackets..,Integrated by:Vikas sir.   //For Alphalist and roman list without dot and brackets.
                                    {
                                        if (listPara.NextSibling() != null && listPara.NextSibling() != null)
                                        {
                                            Paragraph NextPara = (Paragraph)listPara.NextSibling();
                                            Paragraph PrevPara = (Paragraph)listPara.PreviousSibling();
                                            if (NextPara.ParagraphProperties != null && NextPara.ParagraphProperties.ParagraphStyleId != null && NextPara.ParagraphProperties.ParagraphStyleId.Val != null && NextPara.ParagraphProperties.ParagraphStyleId.Val == "AlphaUpparList")
                                            {
                                                if (PrevPara.ParagraphProperties != null && PrevPara.ParagraphProperties.ParagraphStyleId != null && PrevPara.ParagraphProperties.ParagraphStyleId.Val != null && PrevPara.ParagraphProperties.ParagraphStyleId.Val == "AlphaUpparList")
                                                {

                                                    listPara.ParagraphProperties.ParagraphStyleId.Val.Value = "AlphaUpparList";
                                                }
                                            }
                                            else if (NextPara.ParagraphProperties != null && NextPara.ParagraphProperties.ParagraphStyleId != null && NextPara.ParagraphProperties.ParagraphStyleId.Val != null && NextPara.ParagraphProperties.ParagraphStyleId.Val == "AlphaLowerList")
                                            {
                                                if (PrevPara.ParagraphProperties != null && PrevPara.ParagraphProperties.ParagraphStyleId != null && PrevPara.ParagraphProperties.ParagraphStyleId.Val != null && PrevPara.ParagraphProperties.ParagraphStyleId.Val == "AlphaLowerList")
                                                {

                                                    listPara.ParagraphProperties.ParagraphStyleId.Val.Value = "AlphaLowerList";
                                                }
                                            }
                                            else if (NextPara.ParagraphProperties != null && NextPara.ParagraphProperties.ParagraphStyleId != null && NextPara.ParagraphProperties.ParagraphStyleId.Val != null && !NextPara.ParagraphProperties.ParagraphStyleId.Val.Value.Contains("list"))
                                            {
                                                if (PrevPara.ParagraphProperties != null && PrevPara.ParagraphProperties.ParagraphStyleId != null && PrevPara.ParagraphProperties.ParagraphStyleId.Val != null && PrevPara.ParagraphProperties.ParagraphStyleId.Val == "AlphaUpparList")
                                                {
                                                    listPara.ParagraphProperties.ParagraphStyleId.Val.Value = "AlphaUpparList";
                                                }
                                                else if (PrevPara.ParagraphProperties != null && PrevPara.ParagraphProperties.ParagraphStyleId != null && PrevPara.ParagraphProperties.ParagraphStyleId.Val != null && PrevPara.ParagraphProperties.ParagraphStyleId.Val == "AlphaLowerList")
                                                {
                                                    listPara.ParagraphProperties.ParagraphStyleId.Val.Value = "AlphaLowerList";
                                                }

                                            }
                                        }
                                    }
                                }
                            }

                        }

                    }
                }
                D.Save();
            }
        }
        public static void AppendixParaStyle(string newDoc)   //Developer Name:Priyanka Vishwakarma ,Date:15-02-2020 Requirement:for appendix para apply AppendixHead paragraph style.,Integrated by:Vikas sir.	  
        {
            bool AppendixDataFound = false;
            bool FoundBoxStart = false, FoundBoxEnd = false;

            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(x => x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val != null && x.ParagraphProperties.ParagraphStyleId.Val.Value == "BoxStart").ToList())
                {


                    Paragraph NextPara = (Paragraph)P.NextSibling();
                    if (NextPara != null && NextPara.InnerText != "" && NextPara.ParagraphProperties != null && NextPara.ParagraphProperties.ParagraphStyleId != null && NextPara.ParagraphProperties.ParagraphStyleId.Val.Value == "H1" && NextPara.InnerText.ToLower().Trim().StartsWith("appendix"))  //For Identify Box use for Appendix data.
                    {
                        Paragraph newAppendixHead = new Paragraph();
                        newAppendixHead.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "AppendixHead" });
                        NextPara.InsertBeforeSelf(newAppendixHead);
                        AppendixDataFound = true;


                    }

                }

                foreach (Paragraph appendixPara in D.Descendants<Paragraph>().ToList())
                {
                    if (appendixPara.ParagraphProperties != null && appendixPara.ParagraphProperties.ParagraphStyleId != null && appendixPara.ParagraphProperties.ParagraphStyleId.Val.Value == "BoxStart")
                    {
                        FoundBoxStart = true;

                    }
                    else if (appendixPara.ParagraphProperties != null && appendixPara.ParagraphProperties.ParagraphStyleId != null && appendixPara.ParagraphProperties.ParagraphStyleId.Val.Value == "BoxEnd")
                    {
                        FoundBoxEnd = true;
                        AppendixDataFound = false;
                    }

                    if (AppendixDataFound == true && FoundBoxStart == true && FoundBoxEnd == false)
                    {
                        if (appendixPara.Parent != null && appendixPara.Parent.XName.LocalName != "tc" && (appendixPara.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower() == "nl" || appendixPara.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower() == "bl" || appendixPara.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower() == "ul" || appendixPara.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower().EndsWith("list")))
                        {
                            appendixPara.ParagraphProperties.ParagraphStyleId.Val.Value = "BodyA";
                        }
                        else if (appendixPara.ParagraphProperties.ParagraphStyleId.Val.Value == "H1" && appendixPara.Descendants<Run>().FirstOrDefault().Descendants<RunStyle>().Count() > 0 && appendixPara.Descendants<Run>().FirstOrDefault().Descendants<RunStyle>().FirstOrDefault().Val == "citefig")
                        {
                            appendixPara.Descendants<RunStyle>().FirstOrDefault().Remove();
                        }



                    }

                }
                D.Save();
            }
        }
        //Developer name:Priyanka Vishwakarma ,Date:06-04-20202 ;Requirement:  Add Dummy <sup> infront of citebib number for avoid to convert superscript to normal text when Fig citation apply. Integrated by:Vikas sir.
        public static void addDummyInSuperscript(string newDoc)
        {

            using (WordprocessingDocument WPD = WordprocessingDocument
             .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    foreach (Run r in P.Descendants<Run>().ToList())
                    {
                        if (r.RunProperties != null && r.RunProperties.RunStyle != null && r.RunProperties.RunStyle.Val.Value != null && r.RunProperties.RunStyle.Val.Value == "citebib")
                        {
                            Run supRun = new Run(new RunProperties(new Bold(), new VerticalTextAlignment() { Val = VerticalPositionValues.Superscript }), new Text("<sup>"));

                            r.InsertBeforeSelf(supRun);
                        }


                    }
                }
                D.Save();
            }
        }

        //Developer name:Priyanka Vishwakarma ,Date:06-04-20202 ;Requirement:  Remove Dummy <sup> infront of citebib number for avoid to convert superscript to normal text when Fig citation apply. Integrated by:Vikas sir.
        public static void removeDummyInSuperscript(string newDoc)
        {

            using (WordprocessingDocument WPD = WordprocessingDocument
             .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    foreach (Run r in P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.VerticalTextAlignment != null && x.RunProperties.VerticalTextAlignment.Val.Value.ToString() == "Superscript" && x.InnerText.Trim() == "<sup>").ToList())
                    {
                        r.Remove();
                    }
                }
                D.Save();
            }
        }
        public static void CheckAppendixTable(string newDoc)   //Developer Name:Priyanka Vishwakarma ,Date:03-06-2020 Requirement:Handle Appendix Table without heading H1.
        {

            bool FoundBoxStart = false;

            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val.Value == "BoxStart")
                    {
                        FoundBoxStart = true;
                    }
                    else if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val.Value == "BoxEnd")
                    {
                        FoundBoxStart = false;
                    }

                    if (FoundBoxStart)
                    {

                        if (P != null && P.InnerText != "" && P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val.Value == "TT" && P.InnerText.ToLower().Trim().StartsWith("appendix"))  //For Identify Box use for Appendix data.
                        {
                            P.ParagraphProperties.ParagraphStyleId.Val.Value = "H1";


                        }
                    }

                }
                D.Save();
            }
        }
        public static void RemoveBlankUnwantedPara(string newDoc)     //Developer Name:Vikas , Date:18-07-2020 ,Requirement:Funding Paragraph which has blank content and remove that para.
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P != null && P.InnerText.Trim() == "")
                    {

                        if (P.ParagraphProperties != null && P.Parent != null && P.Parent.LocalName != "tc")  //Developer Name:Priyanka Vishwakarma .Date:20-07-2020 ,Requirement :Avoid to remove blank para from table.
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && (P.ParagraphProperties.ParagraphStyleId.Val.Value != "BoxStart" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "BoxEnd"))
                            {
                                P.Remove();
                            }
                        }
                        else if (P.Parent != null && P.Parent.LocalName != "tc") //Developer Name:Priyanka Vishwakarma .Date:20-07-2020 ,Requirement :Avoid to remove blank para from table.
                        {
                            P.Remove();
                        }
                    }
                }
                D.Save();
            }
        }
        public static List<string> authorfootnote = new List<string>();
        public static void AppltParaTIandAUstyle(string newDoc)     //Developer Name:Vikas , Date:18-07-2020 ,Requirement:Funding Paragraph articletitle and author and apply TI andAU style.
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                int count = 0;
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (!P.InnerText.ToLower().StartsWith("international labour review"))
                    {
                        count++;
                        if (P.ParagraphProperties != null && count == 1)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val = "TI";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId() { Val = "TI" });
                            }
                        }
                        else if (P.ParagraphProperties != null && count == 2)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val = "AU";
                                if (P.InnerText.Trim().EndsWith("*"))
                                {
                                    authorfootnote.Add("*");
                                }
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId() { Val = "AU" });
                            }
                        }
                        else if (count == 1)
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId() { Val = "TI" }));
                        }
                        else if (count == 2)
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId() { Val = "AU" }));
                        }
                        else if (authorfootnote.Any(x => P.InnerText.StartsWith(x)))
                        {
                            P.ParagraphProperties.ParagraphStyleId.Val = "FTN";
                        }
                    }
                }
                D.Save();
            }
        }

        public static void ApplyHeadingLevlestyle(string newDoc)     //Developer Name:Vikas , Date:18-07-2020 ,Requirement:Funding Paragraph of Headig level.
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                int count = 0;
                int appendixcount = 0;
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(x => x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.Parent != null && x.Parent.LocalName != W.tc.LocalName).ToList())
                {
                    var listofParas = D.Descendants<Paragraph>().ToList().Where(x => x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.Parent != null && x.Parent.LocalName != W.tc.LocalName).ToList();
                    count++;
                    if (Regex.Match(P.InnerText, @"^([\d][.]\s)").Success)
                    {
                        if (appendixcount == 0 && (P.ParagraphProperties.ParagraphStyleId.Val.Value.EndsWith("List") && listofParas[count - 1].ParagraphProperties != null && listofParas[count + 1].ParagraphProperties != null && listofParas[count - 1].ParagraphProperties.ParagraphStyleId != null && listofParas[count + 1].ParagraphProperties.ParagraphStyleId != null && !listofParas[count - 1].ParagraphProperties.ParagraphStyleId.Val.Value.EndsWith("List") || !listofParas[count + 1].ParagraphProperties.ParagraphStyleId.Val.Value.EndsWith("List")))
                        {
                            P.ParagraphProperties.ParagraphStyleId.Val.Value = "H1";
                        }
                    }
                    else if (Regex.Match(P.InnerText, @"^([\d][.][\d][.]\s)").Success)
                    {
                        P.ParagraphProperties.ParagraphStyleId.Val.Value = "H2";
                    }
                    else if (Regex.Match(P.InnerText, @"^([\d][.][\d][.][\d][.]\s)").Success)
                    {
                        P.ParagraphProperties.ParagraphStyleId.Val.Value = "H3";
                    }
                    else if (Regex.Match(P.InnerText, @"^([\d][.][\d][.][\d][.][\d][.]\s)").Success)
                    {
                        P.ParagraphProperties.ParagraphStyleId.Val.Value = "H4";
                    }
                    else if (Regex.Match(P.InnerText, @"^([\d][.][\d][.][\d][.][\d][.][\d][.]\s)").Success)
                    {
                        P.ParagraphProperties.ParagraphStyleId.Val.Value = "H5";
                    }
                    else if (Regex.Match(P.InnerText, @"^(Appendix [\d]\s)").Success)
                    {
                        appendixcount++;
                        P.ParagraphProperties.ParagraphStyleId.Val.Value = "H1";
                        //if (appendixcount == 1)
                        //{
                        //    var newpara = new Paragraph(new ParagraphProperties(new ParagraphStyleId() { Val = "AppendixHead" }));
                        //    P.InsertBeforeSelf(newpara);
                        //}
                    }
                    else if (Regex.Match(P.InnerText.Trim(), @"^(Table ([0-9]+)\s)|^(Table ([0-9]+\.)\s)").Success)  //Developer Name:Priyanka Vishwakarma ,Date:20-07-2020 ,Requirement:Add Pattern for Figure and table.
                    {
                        P.ParagraphProperties.ParagraphStyleId.Val.Value = "TT";
                    }
                    else if (Regex.Match(P.InnerText.Trim(), @"^(Figure ([0-9]+)\s)|^(Figure ([0-9]+\.)\s)").Success)//Developer Name:Priyanka Vishwakarma ,Date:20-07-2020 ,Requirement:Add Pattern for Figure and table.
                    {
                        P.ParagraphProperties.ParagraphStyleId.Val.Value = "FIGC";
                    }
                    else if (P.InnerText.ToLower().StartsWith("notes:") || P.InnerText.ToLower().StartsWith("note:"))
                    {
                        P.ParagraphProperties.ParagraphStyleId.Val.Value = "TFN";
                    }
                    else if (P.InnerText.ToLower().StartsWith("source:") || P.InnerText.ToLower().StartsWith("sources:"))
                    {
                        P.ParagraphProperties.ParagraphStyleId.Val.Value = "TFN";
                    }
                    else if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && (P.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower() == "header" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "center" || P.ParagraphProperties.ParagraphStyleId.Val == "BodyText"))
                    {
                        P.ParagraphProperties.ParagraphStyleId.Val.Value = "BodyA";
                    }
                }
                D.Save();
            }
        }

        public static void ApplyTextBasedstyle(string newDoc)     //Developer Name:Vikas , Date:18-07-2020 ,Requirement:Funding Abstract and keywords style apply.
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                bool abstarctstyleapplied = false;
                bool keywordsstyleapplied = false;
                bool authorfootnote = false;
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(x => x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.Parent != null && x.Parent.LocalName != W.tc.LocalName).ToList())
                {
                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val.Value == "FTN")
                    {
                        authorfootnote = true;
                    }
                    else if (P.InnerText.ToLower().StartsWith("abstract") && abstarctstyleapplied == false)
                    {
                        P.ParagraphProperties.ParagraphStyleId.Val.Value = "AB";
                        abstarctstyleapplied = true;
                    }
                    else if (authorfootnote == true && abstarctstyleapplied == false)
                    {
                        //P.ParagraphProperties.ParagraphStyleId.Val.Value = "AFFL";
                        P.ParagraphProperties.ParagraphStyleId.Val.Value = "FTN";
                    }
                    else if (P.InnerText.ToLower().StartsWith("keyword") && keywordsstyleapplied == false)
                    {
                        P.ParagraphProperties.ParagraphStyleId.Val.Value = "KYWD";
                        keywordsstyleapplied = true;
                    }
                }
                D.Save();
            }
        }
        public static void AuthorMarking(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                .Open(newDoc, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    RemoveComments = false,
                    RemoveContentControls = true,
                    RemoveEndAndFootNotes = false,
                    RemoveFieldCodes = true,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = false,//Developer name :Priyanka Vishwakarma. Date:29_5_2019, Requirement:it removes the indentation from the nested list  ,Integrated By:Vikas sir. 
                };

                MarkupSimplifier.SimplifyMarkup(WPD, settings);

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().
                    Where(e => e.ParagraphProperties != null
                        && e.ParagraphProperties.ParagraphStyleId != null
                        && e.ParagraphProperties.ParagraphStyleId.Val == "AU"))
                {
                    if (P.HasChildren == false)
                    {
                        try
                        {
                            P.Remove();
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(ex.Message);
                        }
                    }
                    else
                    {
                        var ppr = P.Descendants<ParagraphProperties>();
                        string dummytext = null;

                        bool bothtagexist = false;
                        bool firsttagexist = false;
                        bool secondtagexist = false;

                        if (P.InnerText != null)
                        {
                            List<string> commentedtext = new List<string>();


                            //bool and int only For run comment text
                            bool getruntext = false;
                            int rcounter = 0;

                            foreach (var PE in P.Elements().ToList())
                            {
                                if (PE.XName == W.commentRangeStart)
                                {
                                    getruntext = true;
                                }
                                else if (PE.XName == W.bookmarkStart)
                                {
                                    dummytext = dummytext + "</bookmarkStart_DummyText>";
                                    getruntext = false;
                                    rcounter = 0;
                                }
                                if (PE.XName == W.r && getruntext == true)
                                {
                                    if (PE.InnerText != null && rcounter == 0)
                                    {
                                        dummytext += "<bookmarkStart_DummyText>" + PE.InnerText;
                                        rcounter++;
                                    }
                                    else
                                    {
                                        dummytext += PE.InnerText;
                                    }
                                }
                                else
                                {
                                    dummytext += PE.InnerText;
                                }
                            }
                        }

                        foreach (Run R in P.Descendants<Run>().ToList())
                        {
                            ////without superscript run remove in para
                            if (R.RunProperties != null)
                            {
                                if (R.RunProperties.VerticalTextAlignment != null)
                                {
                                    if (R.RunProperties.VerticalTextAlignment.Val == "superscript")
                                    {
                                        continue;
                                    }
                                }
                            }
                            R.Remove();
                        }

                        ////get para elements use for commented text

                        string[] separators = { "" };
                        string[] links = dummytext.Trim().Split(separators, StringSplitOptions.RemoveEmptyEntries);

                        for (int i = 0; i < links.Count(); i++)
                        {


                            string[] separators_space = { " " };
                            string[] links_space = links[i].Split(separators_space, StringSplitOptions.RemoveEmptyEntries);
                            if (links_space.Count() == 4)
                            {
                                for (var auname = 0; auname < links_space.Count(); auname++)
                                {
                                    if (auname == 0 || auname == 2)
                                    {
                                        var newrunadd = new Run();
                                        newrunadd.RunProperties = new RunProperties(new RunStyle { Val = "aufname" });
                                        Text newtxtadd = new Text(links_space[auname]);
                                        newrunadd.Append(newtxtadd);
                                        P.Append(newrunadd);
                                        var newrunaddc = new Run();
                                        Text newtxtaddc = new Text("\u0020") { Space = SpaceProcessingModeValues.Preserve };
                                        newrunaddc.Append(newtxtaddc);
                                        P.Append(newrunaddc);

                                    }
                                    else if (auname == 1 || auname == 3)
                                    {
                                        var newrunadd = new Run();
                                        newrunadd.RunProperties = new RunProperties(new RunStyle { Val = "ausurname" });
                                        Text newtxtadd1 = new Text(links_space[auname].TrimEnd(','));
                                        newrunadd.Append(newtxtadd1);
                                        P.Append(newrunadd);
                                        if (links_space[auname].EndsWith(","))
                                        {
                                            var newrunaddc = new Run();
                                            Text newtxtadd = new Text(",");
                                            newrunaddc.Append(newtxtadd);
                                            P.Append(newrunaddc);
                                        }
                                    }

                                }
                            }
                            else if (links_space.Count() == 3)
                            {
                                for (var auname = 0; auname < links_space.Count(); auname++)
                                {
                                    if (auname == 0)
                                    {
                                        var newrunadd = new Run();
                                        newrunadd.RunProperties = new RunProperties(new RunStyle { Val = "aufname" });
                                        Text newtxtadd = new Text(links_space[auname] + " ");
                                        newrunadd.Append(newtxtadd);
                                        P.Append(newrunadd);

                                    }
                                    else if (auname == 1)
                                    {
                                        var newrunadd = new Run();
                                        newrunadd.RunProperties = new RunProperties(new RunStyle { Val = "ausurname" });
                                        Text newtxtadd1 = new Text(links_space[auname]);
                                        newrunadd.Append(newtxtadd1);
                                        P.Append(newrunadd);
                                    }
                                    else if (links_space[auname] == "*" || links_space[auname] == "**")
                                    {
                                        var newrunadd = new Run();
                                        newrunadd.RunProperties = new RunProperties(new RunStyle { Val = "citefn" });
                                        Text newtxtadd = new Text(links_space[auname]);
                                        newrunadd.Append(newtxtadd);
                                        P.Append(newrunadd);
                                    }
                                    else
                                    {
                                        var newrunadd = new Run();
                                        Text newtxtadd = new Text(links_space[auname]);
                                        newrunadd.Append(newtxtadd);
                                        P.Append(newrunadd);
                                    }
                                }
                            }
                            else if (links_space.Count() == 6)
                            {
                                for (var auname = 0; auname < links_space.Count(); auname++)
                                {
                                    if (auname == 0 || auname == 3)
                                    {
                                        var newrunadd = new Run();
                                        newrunadd.RunProperties = new RunProperties(new RunStyle { Val = "aufname" });
                                        Text newtxtadd = new Text(links_space[auname] + "\u0020");
                                        newrunadd.Append(newtxtadd);
                                        P.Append(newrunadd);

                                    }
                                    else if (auname == 1)
                                    {
                                        if (links_space[auname].EndsWith("*"))
                                        {
                                            var newrunadd = new Run();
                                            newrunadd.RunProperties = new RunProperties(new RunStyle { Val = "ausurname" });
                                            Text newtxtadd1 = new Text(links_space[auname].Replace("*", ""));
                                            newrunadd.Append(newtxtadd1);
                                            P.Append(newrunadd);
                                            newrunadd = new Run();
                                            newrunadd.RunProperties = new RunProperties(new RunStyle { Val = "citefn" });
                                            newtxtadd1 = new Text("*");
                                            newrunadd.Append(newtxtadd1);
                                            P.Append(newrunadd);
                                        }
                                        else
                                        {
                                            var newrunadd = new Run();
                                            newrunadd.RunProperties = new RunProperties(new RunStyle { Val = "ausurname" });
                                            Text newtxtadd1 = new Text(links_space[auname]);
                                            newrunadd.Append(newtxtadd1);
                                            P.Append(newrunadd);
                                        }
                                    }
                                    else if (auname == 4)
                                    {
                                        var newrunadd = new Run();
                                        newrunadd.RunProperties = new RunProperties(new RunStyle { Val = "ausurname" });
                                        Text newtxtadd1 = new Text(links_space[auname] + "\u0020");
                                        newrunadd.Append(newtxtadd1);
                                        P.Append(newrunadd);
                                    }
                                    else if (auname == 5)
                                    {
                                        if (links_space[auname].EndsWith("*"))
                                        {
                                            var newrunadd = new Run();
                                            newrunadd.RunProperties = new RunProperties(new RunStyle { Val = "ausurname" });
                                            Text newtxtadd1 = new Text(links_space[auname].Replace("*", ""));
                                            newrunadd.Append(newtxtadd1);
                                            P.Append(newrunadd);
                                            newrunadd = new Run();
                                            newrunadd.RunProperties = new RunProperties(new RunStyle { Val = "citefn" });
                                            newtxtadd1 = new Text("**");
                                            newrunadd.Append(newtxtadd1);
                                            P.Append(newrunadd);
                                        }
                                        else
                                        {
                                            var newrunadd = new Run();
                                            newrunadd.RunProperties = new RunProperties(new RunStyle { Val = "ausurname" });
                                            Text newtxtadd1 = new Text(links_space[auname]);
                                            newrunadd.Append(newtxtadd1);
                                            P.Append(newrunadd);
                                        }
                                    }
                                    else if (links_space[auname] == "*" || links_space[auname] == "**")
                                    {
                                        var newrunadd = new Run();
                                        newrunadd.RunProperties = new RunProperties(new RunStyle { Val = "citefn" });
                                        Text newtxtadd = new Text(links_space[auname]);
                                        newrunadd.Append(newtxtadd);
                                        P.Append(newrunadd);
                                    }
                                    else if (links_space[auname] == "and")
                                    {
                                        var newrunadd = new Run();
                                        Text newtxtadd = new Text("\u0020" + links_space[auname] + "\u0020");
                                        newrunadd.Append(newtxtadd);
                                        P.Append(newrunadd);
                                    }
                                    else
                                    {
                                        var newrunadd = new Run();
                                        Text newtxtadd = new Text(links_space[auname]);
                                        newrunadd.Append(newtxtadd);
                                        P.Append(newrunadd);
                                    }
                                }
                            }
                            else
                            {
                                var newrunadd = new Run();
                                Text newtxtadd = new Text(dummytext);
                                newrunadd.Append(newtxtadd);
                                P.Append(newrunadd);
                            }
                        }
                    }
                }

                D.Save();
            }
        }
        public static void AppendixParaContainsList(string newDoc)   //Developer Name:Priyanka Vishwakarma ,Date:15-02-2020 Requirement:for appendix para apply AppendixHead paragraph style.,Integrated by:Vikas sir.	  
        {
            bool AppendixDataFound = false;
            bool FoundBoxStart = false, FoundBoxEnd = false;

            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(x => x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val != null && x.ParagraphProperties.ParagraphStyleId.Val.Value == "BoxStart").ToList())
                {


                    Paragraph NextPara = (Paragraph)P.NextSibling();
                    if (NextPara != null && NextPara.InnerText != "" && NextPara.ParagraphProperties != null && NextPara.ParagraphProperties.ParagraphStyleId != null && NextPara.ParagraphProperties.ParagraphStyleId.Val.Value == "H1" && NextPara.InnerText.ToLower().Trim().StartsWith("appendix"))  //For Identify Box use for Appendix data.
                    {
                        Paragraph newAppendixHead = new Paragraph();
                        newAppendixHead.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "AppendixHead" });
                        NextPara.InsertBeforeSelf(newAppendixHead);
                        AppendixDataFound = true;
                        break;


                    }

                }



                D.Save();
            }
        }

        public static void ChangeUnknownRef(string newDoc)
        {
            bool bParaHasStructuredRef = false;

            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(x => x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val != null && x.ParagraphProperties.ParagraphStyleId.Val.Value == "REF1").ToList())
                {
                    if (P.Descendants<Run>().Count() > 0)
                    {
                        List<OpenXmlElement> RList = P.Descendants<OpenXmlElement>().ToList();

                        bParaHasStructuredRef = CheckIfParaHasStructuredReference(RList);

                        if (bParaHasStructuredRef == false)
                        {
                            //string newRefText = P.InnerText.Replace("<jrn>", "<unknown>").Replace("</jrn>", "</unknown>").Replace("<bok>", "<unknown>").Replace("</bok>", "</unknown>");
                            //Run newRun = new Run(new Text(newRefText));
                            //if (newRefText != null && newRun != null)
                            //{
                            //    foreach (var run in P.Descendants<Run>().ToList())
                            //    {
                            //        run.Remove();
                            //    }
                            //    P.AppendChild(newRun);
                            //}

                            P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().ForEach(t => t.ToList().ForEach(txt =>
                            {

                                if (txt == P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().FirstOrDefault().FirstOrDefault())
                                {
                                    txt.Text = txt.Text.Replace("<jrn>", "<unknown>").Replace("</jrn>", "</unknown>").Replace("<bok>", "<unknown>").Replace("</bok>", "</unknown>");
                                }
                                if (txt == P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().LastOrDefault().LastOrDefault())
                                {
                                    txt.Text = txt.Text.Replace("<jrn>", "<unknown>").Replace("</jrn>", "</unknown>").Replace("<bok>", "<unknown>").Replace("</bok>", "</unknown>");
                                }
                            })
                                       );



                        }



                    }




                }



                D.Save();
            }
        }
        private static bool CheckIfParaHasStructuredReference(List<OpenXmlElement> RList)
        {
            foreach (OpenXmlElement R in RList)
            {
                if (R.LocalName != null)
                {
                    if (R.LocalName == "r")
                    {
                        if (R.HasChildren)
                        {
                            foreach (OpenXmlElement el in R.Elements())
                            {
                                if (el.LocalName == "rPr")
                                {
                                    if (el.HasChildren)
                                    {
                                        foreach (OpenXmlElement el1 in el.Elements())
                                        {
                                            if (el1.LocalName == "rStyle")
                                            {
                                                string Style = ((DocumentFormat.OpenXml.Wordprocessing.String253Type)el1).Val;

                                                if (Style != null)
                                                {

                                                    return true;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            return false;
        }

        public static void ConvertNLandBLParaStyle(string newDoc)     //Developer Name:Priyanka Vishwakarma, Date:03-09-2020 ,Requirement:Convert nl Para to Numlist and BL para to bulllist.
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P != null && P.InnerText.Trim() != "")
                    {

                        if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val.Value == "NL")
                        {
                            P.ParagraphProperties.ParagraphStyleId.Val = "NumList";

                        }
                        else if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val.Value == "BL")
                        {
                            P.ParagraphProperties.ParagraphStyleId.Val = "BullList";

                        }
                    }

                }
                D.Save();
            }
        }

        public static void ApplyciteEq(string newDoc)     //Developer Name:Vikas for inform client added on 08-09-2020
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P != null && P.InnerText.Trim() != "")
                    {

                        if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val.Value == "EQ" && !P.InnerText.StartsWith("formula_"))
                        {
                            if (P.Descendants<Run>().ToList().Any(x => x.Descendants<RunStyle>().Any(y => y.Val == "label-Strong")))
                            {
                                P.Descendants<Run>().ToList().ForEach(c =>
                                {
                                    c.Descendants<RunStyle>().ToList().ForEach(rs =>
                                    {
                                        if (rs.Val == "label-Strong")
                                        {
                                            rs.Val.Value = "citeeq";
                                        }
                                    });

                                });
                            }
                        }
                        if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val.Value == "EQ" && !P.InnerText.StartsWith("formula_"))
                        {
                            P.ParagraphProperties.ParagraphStyleId.Val.Value = "BodyA";
                        }
                    }

                }
                D.Save();
            }
        }

        public static void ApplyheadingStyletoNumberedPara(string newDoc)     //Developer Name:Vikas for inform client heading style apply H1,H2,H3 added on 08-09-2020
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().Where(x => x.Parent != null && x.Parent.LocalName != W.tc.LocalName).ToList())
                {
                    if (P != null && P.InnerText.Trim() != "")
                    {

                        if (CheckifParaStartWithNumber(P.Descendants<Run>()) == "1")
                        {
                            if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "H1";
                            }
                        }
                        else if (CheckifParaStartWithNumber(P.Descendants<Run>()) == "2")
                        {
                            if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "H2";
                            }
                        }
                        else if (CheckifParaStartWithNumber(P.Descendants<Run>()) == "3")
                        {
                            if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "H3";
                            }
                        }
                    }

                }
                D.Save();
            }
        }

        private static string CheckifParaStartWithNumber(IEnumerable<Run> RunColl)
        {
            foreach (Run R in RunColl.ToList())
            {
                string strParaText = null;

                if (R.HasChildren == true)
                {
                    foreach (Text T in R.Descendants<Text>().ToList())
                    {
                        strParaText += T.Text;

                        string strSearchRegEx = null;
                        strSearchRegEx = null;

                        strSearchRegEx = @"^[0-9]{1,}\.?[0-9]{1,}\.?[0-9]{1,}?\s|^[0-9]{1,}\.?[0-9]{1,}\.?[0-9]{1,}\.?\s";
                        if (GlobalMethods.ValidateRegEx(strParaText, strSearchRegEx) == true)
                        {
                            string strRetVal = GlobalMethods.RegExSearch(strParaText, strSearchRegEx);

                            if (T.Text.StartsWith(strRetVal.Trim()))
                            {
                                return "3";
                            }
                        }

                        strSearchRegEx = @"^[0-9]{1,}\.?[0-9]{1,}?\s|^[0-9]{1,}\.?[0-9]{1,}\.?\s";
                        if (GlobalMethods.ValidateRegEx(strParaText, strSearchRegEx) == true)
                        {
                            string strRetVal = GlobalMethods.RegExSearch(strParaText, strSearchRegEx);

                            if (T.Text.StartsWith(strRetVal.Trim()))
                            {
                                return "2";
                            }
                        }

                        strSearchRegEx = @"^[0-9]{1,}\s|^[0-9]{1,}\.\s";
                        if (GlobalMethods.ValidateRegEx(strParaText, strSearchRegEx) == true)
                        {
                            string strRetVal = GlobalMethods.RegExSearch(strParaText, strSearchRegEx);

                            if (T.Text.StartsWith(strRetVal.Trim()) && CheckifCompleteParaIsBold(RunColl))
                            {
                                return "1";
                            }
                        }
                    }
                }
            }

            return "0";
        }

        private static bool CheckifCompleteParaIsBold(IEnumerable<Run> RunColl)
        {
            bool bcompleteParaIsBold = false;

            foreach (Run R in RunColl.ToList())
            {
                if (R.HasChildren == true)
                {
                    if (R.RunProperties != null)
                    {
                        if (R.RunProperties.Bold != null)
                        {
                            bcompleteParaIsBold = true;
                        }
                        else
                        {
                            bcompleteParaIsBold = false;
                            return false;
                        }
                    }
                    else
                    {
                        bcompleteParaIsBold = false;
                        return false;
                    }
                }
                else
                {
                    bcompleteParaIsBold = false;
                    return false;
                }
            }

            if (bcompleteParaIsBold)
                return true;

            return false;
        }
        public static void KeywordParastyleCheck(string newDoc)     //Developer Name:Vikas for inform client kYWD style check
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().Where(x => x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val != null && x.ParagraphProperties.ParagraphStyleId.Val.Value != null && x.ParagraphProperties.ParagraphStyleId.Val.Value == "KYWD").Skip(1).ToList())
                {

                    P.ParagraphProperties.ParagraphStyleId.Val.Value = "BodyA";
                }
                D.Save();
            }
        }
        public static void Ref1styleapplyforinform(string newDoc)     //Developer Name:Vikas for inform client kYWD style check
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().Where(x => x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val != null && x.ParagraphProperties.ParagraphStyleId.Val.Value != null && (x.InnerText.Trim().StartsWith("<jrn>") || x.InnerText.Trim().StartsWith("<bok>") || x.InnerText.Trim().StartsWith("<unknown>"))).ToList())
                {

                    P.ParagraphProperties.ParagraphStyleId.Val.Value = "REF1";
                }
                D.Save();
            }
        }

        public static void ApplyEqtoBodyA(string newDoc)     //Developer Name:Vikas  added on 22-09-2020
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P != null && P.InnerText.Trim() != "")
                    {
                        if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val.Value == "EQ" && !P.InnerText.StartsWith("formula_"))
                        {
                            P.ParagraphProperties.ParagraphStyleId.Val.Value = "BodyA";
                        }
                    }

                }
                D.Save();
            }
        }

        public static void Checkempasisbold(string newDoc)
        {
            bool BoldFound = false;

            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(x => x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val != null && x.ParagraphProperties.ParagraphStyleId.Val.Value == "AB-TXT").ToList())
                {



                    foreach (var run in P.Descendants<Run>().ToList())
                    {
                        if (run.PreviousSibling() != null && run.NextSibling() != null)
                        {


                            if (run.RunProperties != null && run.RunProperties.Bold != null && run.InnerText.Trim() == ".")
                            {
                                Run r1 = new Run();
                                Text runspace = new Text { Text = ".", Space = SpaceProcessingModeValues.Preserve };
                                r1.AppendChild(runspace);
                                run.InsertAfterSelf(r1);
                                run.Remove();


                            }

                        }

                    }


                }

                D.Save();
            }
        }


        public static void CheckSpaceBold(string newDoc)
        {
            bool BoldFound = false;

            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(x => x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val != null).ToList())
                {



                    var run = P.Descendants<Run>().ToList().FirstOrDefault();
                    if (run != null)
                    {
                        if (run.RunProperties != null && run.RunProperties.Bold != null)
                        {
                            if (run.InnerText.EndsWith(" "))
                            {
                                Run r1 = new Run();
                                Text runspace = new Text { Text = " ", Space = SpaceProcessingModeValues.Preserve };
                                r1.AppendChild(runspace);
                                run.InsertAfterSelf(r1);
                                var firstrun = run.Descendants<Text>().FirstOrDefault();
                                if (firstrun != null)
                                {
                                    firstrun.Text = firstrun.Text.Trim();
                                }
                            }
                        }



                    }


                }

                D.Save();
            }
        }


        public static void CheckCitefnText(string newDoc)
        {
            bool BoldFound = false;

            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Run R in D.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val != null && x.RunProperties.RunStyle.Val == "citefn").ToList())
                {
                    if (R.NextSibling() != null && R.NextSibling() != null && R.NextSibling().LocalName == "r")
                    {
                        if (R.NextSibling().InnerText.Trim().StartsWith("[") && R.NextSibling().InnerText.Trim().EndsWith("]"))
                        {
                            foreach (var x in R.NextSibling().Descendants().ToList())
                            {
                                if (x.LocalName.ToString() == "vertAlign")
                                {
                                    R.NextSibling().Remove();
                                }

                            }
                        }
                    }


                }
                bool LabelfnFound = false;
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(x => x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val != null && x.ParagraphProperties.ParagraphStyleId.Val == "FTN").ToList())
                {
                    LabelfnFound = false;
                    foreach (Run R in D.Descendants<Run>().ToList())
                    {

                        if (R.RunProperties != null && R.RunProperties.RunStyle != null && R.RunProperties.RunStyle.Val != null && R.RunProperties.RunStyle.Val == "label-fn")
                        {

                            LabelfnFound = true;
                            continue;

                        }
                        if (LabelfnFound)
                        {
                            if (R.Descendants().Any(x => x.LocalName.ToString() == "vertAlign"))
                            {
                                R.Remove();
                            }
                        }
                    }
                }
                D.Save();
            }
        }

        public static void Ref1_StyleAppliedSage(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                bool refstratfound = false;
                bool refendfound = false;
                bool refFound = false;  ////Developer Name:priyanka Vishwakarma ,Date:15_5_2019 ,Requirement:Apply Ref1 Style to References when in document Ref_start and Ref_End style not apply ,Integrated By:Vikas sir

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(c => c.Parent.LocalName != W.tc).ToList())
                {
                    if (P.ParagraphProperties != null)
                    {
                        if (P.ParagraphProperties.ParagraphStyleId != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId.Val.Value == "Ref-Start")
                            {
                                refstratfound = true;
                                refendfound = false;
                                continue;
                            }
                            else if (P.ParagraphProperties.ParagraphStyleId.Val.Value == "Ref-End")
                            {
                                refendfound = true;
                                refstratfound = false;
                                break;
                            }
                            ////Developer Name:priyanka Vishwakarma ,Date:15_5_2019 ,Requirement:Apply Ref1 Style to References when in document Ref_start and Ref_End style not apply ,Integrated By:Vikas sir
                            if (P.ParagraphProperties.ParagraphStyleId.Val.Value == "REF")
                            {
                                refFound = true;
                            }
                            //-------------------------end by priyanka on 15_5_2019 -----------------------------------------------
                            else if (P.ParagraphProperties.ParagraphStyleId.Val.Value == "FIGC" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "TT" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H1" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H2" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "BodyTextRight")  //Developer name:priyanka Vishwakarma ,Date:31072020 ,Requirement:for avoid the REF1 style apply to figc and TT  paragraph. Integrated by:Vikas sir.   H1 and H2 added by vikas on 18-10-2020 ///BodyTextRight condition added by vikas on 31-03-2021 after reference right align text come then refFound set to false
                            {
                                refFound = false;
                            }
                        }
                    }
                    if (refstratfound)
                    {
                        if (P != null && P.InnerText != null)
                        {
                            if (P.ParagraphProperties != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null)
                                {
                                    P.ParagraphProperties.ParagraphStyleId.Val = "REF1";
                                }
                                else
                                {
                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "REF1" };
                                }
                            }
                            else
                            {
                                P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "REF1" });
                            }
                        }
                    }
                    ////Developer Name:priyanka Vishwakarma ,Date:15_5_2019 ,Requirement:Apply Ref1 Style to References when in document Ref_start and Ref_End style not apply ,Integrated By:Vikas sir
                    if (refFound)
                    {
                        if (P.InnerText.ToLower().Trim() == "references" || P.InnerText.ToLower().Trim() == "reference" || P.InnerText.ToLower().Trim() == "references cited" || P.InnerText.ToLower().Trim() == "bibliography" || P.InnerText.ToLower().Trim() == "bibliography:" || P.InnerText.ToLower().Trim() == "bibliografia:" || P.InnerText.ToLower().Trim() == "bibliografia") ////Developer Name:Priyanka Vishwakarma , Date : 08-06-2020 ,Requirement:Apply REF paragarph style to heading Reference in cleanup process ///references cited condition added by vikas on 14-08-2020 for florida job
                        {
                            continue;
                        }
                        //For copy edited MSS where refrences are already taged
                        if (P.InnerText.StartsWith("<") && P.InnerText.EndsWith(">"))
                        {
                            if (P != null && P.InnerText != null)
                            {
                                if (P.ParagraphProperties != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId != null)
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val = "REF1";
                                    }
                                    else
                                    {
                                        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "REF1" };
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "REF1" });
                                }


                            }
                        }
                        //For Non copy edited MSS where refrence needs to be taged added by vikas on 22-09-2019
                        else if (Regex.Match(P.InnerText, @"\s[0-9]+th+\s+ed|([A-Za-z]+[\,]+\s{1,}[A-Za-z]+[\:]\s{1,}[A-Za-z\:\’\–\-\&\s]+[\;]+\s+[0-9]+)|(In:|In;)|([\(]ed\.[\)])|(Press)", RegexOptions.IgnoreCase).Success)//For <bok> ...</bok>
                        {
                            if (P != null && P.InnerText != null)
                            {
                                if (P.ParagraphProperties != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId != null)
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val = "REF1";
                                    }
                                    else
                                    {
                                        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "REF1" };
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "REF1" });
                                }

                                if (!P.InnerText.StartsWith("<bok>"))
                                {
                                    P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().ForEach(t => t.ToList().ForEach(txt =>
                                    {

                                        if (txt == P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().FirstOrDefault().FirstOrDefault())
                                        {
                                            txt.Text = "<bok>" + txt.Text;
                                        }
                                        if (txt == P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().LastOrDefault().LastOrDefault())
                                        {


                                            Run lastRun = P.Descendants<Run>().ToList().LastOrDefault();
                                            if (lastRun != null)
                                            {
                                                if (lastRun.RunProperties != null && lastRun.RunProperties.RunStyle != null && lastRun.RunProperties.RunStyle.Val != null && lastRun.RunProperties.RunStyle.Val.Value == "weblinks")
                                                {
                                                    Run r1 = new Run();
                                                    Text runspace = new Text { Text = ".</bok>", Space = SpaceProcessingModeValues.Preserve };
                                                    r1.AppendChild(runspace);
                                                    P.AppendChild(r1);


                                                }
                                                else
                                                {
                                                    txt.Text = txt.Text + "</bok>";
                                                }
                                            }

                                            //txt.Text = txt.Text + "</bok>";
                                        }
                                    })
                                    );
                                }

                            }

                        }
                        else if (Regex.Match(P.InnerText, @"\d+[(]+[\d]+[)]|(\d+[(]+[\d]+[)]|\d+[;]\d+[:]\d+[\-\–]\d+)|([\.]+\s{1,}[A-Za-z\s]+\s{1,}[0-9]+[\;])|([A-Za-z\s]+[\,]\s{1,}[pp]+[\.]\s{1,}[0-9]+[\-\–][0-9]+)|(Vol.\s{1,}[0-9]+[\,]\s{1,}[No.]+\s{1,}[0-9]+)").Success)//For <jrn> ...</jrn>
                        {
                            if (P != null && P.InnerText != null)
                            {
                                if (P.ParagraphProperties != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId != null)
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val = "REF1";
                                    }
                                    else
                                    {
                                        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "REF1" };
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "REF1" });
                                }

                                if (!P.InnerText.StartsWith("<jrn>"))
                                {
                                    P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().ForEach(t => t.ToList().ForEach(txt =>
                                    {

                                        if (txt == P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().FirstOrDefault().FirstOrDefault())
                                        {
                                            txt.Text = "<jrn>" + txt.Text;
                                        }
                                        if (txt == P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().LastOrDefault().LastOrDefault())
                                        {
                                            txt.Text = txt.Text + "</jrn>";
                                        }
                                    })
                                    );
                                }

                            }
                        }

                        else if (Regex.Match(P.InnerText, @"^\d+", RegexOptions.IgnoreCase).Success)//For <other> ...</other>
                        {
                            if (P != null && P.InnerText != null)
                            {
                                if (P.ParagraphProperties != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId != null)
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val = "REF1";
                                    }
                                    else
                                    {
                                        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "REF1" };
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "REF1" });
                                }

                                if (!P.InnerText.StartsWith("<unknown>"))
                                {
                                    P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().ForEach(t => t.ToList().ForEach(txt =>
                                    {

                                        if (txt == P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().FirstOrDefault().FirstOrDefault())
                                        {
                                            txt.Text = "<unknown>" + txt.Text;
                                        }
                                        if (txt == P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().LastOrDefault().LastOrDefault())
                                        {
                                            txt.Text = txt.Text + "</unknown>";
                                        }
                                    })
                                    );
                                }

                            }

                        }
                        //Developer name:Priyanka vishwakarma ,Date:12_10_2019 ,Requirement for unstructured file without numbering reference ,Integrated by:Vikas sir. added by vikas P.NextSibling().XName.LocalName!= "sectPr" on 12-11-2019 for IJCDW article IJCDW-19-0168-ED
                        else if (P.NextSibling() != null && P.NextSibling().XName.LocalName != "sectPr" && P.NextSibling<Paragraph>().ParagraphProperties != null && P.NextSibling<Paragraph>().ParagraphProperties.ParagraphStyleId != null && P.NextSibling<Paragraph>().ParagraphProperties.ParagraphStyleId.Val != null && P.NextSibling<Paragraph>().ParagraphProperties.ParagraphStyleId.Val.Value == "FIGC")
                        {
                            if (P != null && P.InnerText != null)
                            {
                                if (P.ParagraphProperties != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId != null)
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val = "REF1";
                                    }
                                    else
                                    {
                                        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "REF1" };
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "REF1" });
                                }

                                if (!P.InnerText.StartsWith("<unknown>"))
                                {
                                    P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().ForEach(t => t.ToList().ForEach(txt =>
                                    {

                                        if (txt == P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().FirstOrDefault().FirstOrDefault())
                                        {
                                            txt.Text = "<unknown>" + txt.Text;
                                        }
                                        if (txt == P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().LastOrDefault().LastOrDefault())
                                        {
                                            txt.Text = txt.Text + "</unknown>";
                                        }
                                    })
                                    );
                                }

                            }

                        }
                        else if (!P.InnerText.StartsWith("<") && !P.InnerText.EndsWith(">"))
                        {
                            if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && (P.ParagraphProperties.ParagraphStyleId.Val.Value == "H1" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "BoxStart" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H2" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H3" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H4" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H5" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H6"))
                            {
                                refFound = false;
                            }
                            else
                            {
                                if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                                {
                                    P.ParagraphProperties.ParagraphStyleId.Val = "REF1";
                                }
                                if (!P.InnerText.StartsWith("<unknown>"))
                                {
                                    P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().ForEach(t => t.ToList().ForEach(txt =>
                                    {

                                        if (txt == P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().FirstOrDefault().FirstOrDefault())
                                        {
                                            txt.Text = "<unknown>" + txt.Text;
                                        }
                                        if (txt == P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().LastOrDefault().LastOrDefault())
                                        {
                                            Run lastRun = P.Descendants<Run>().ToList().LastOrDefault();
                                            if (lastRun != null)
                                            {
                                                if (lastRun.RunProperties != null && lastRun.RunProperties.RunStyle != null && lastRun.RunProperties.RunStyle.Val != null && lastRun.RunProperties.RunStyle.Val.Value == "weblinks")
                                                {
                                                    Run r1 = new Run();
                                                    Text runspace = new Text { Text = ".</unknown>", Space = SpaceProcessingModeValues.Preserve };
                                                    r1.AppendChild(runspace);
                                                    P.AppendChild(r1);


                                                }
                                                else
                                                {
                                                    txt.Text = txt.Text + "</unknown>";
                                                }
                                            }


                                        }
                                        else if (GlobalMethods.strClientName.ToLower() == "sage" && txt == P.Descendants<Text>().ToList().LastOrDefault())
                                        {
                                            txt.Text = txt.Text + "</unknown>";
                                        }
                                    })
                                    );
                                }
                            }

                        }
                    }
                    //-------------------------End by Priyanka on 15_5_2019----------------------------------------------------------

                }
                D.Save();
            }
        }
        public static void RemoveRstyleEmphasisForWordAddItalicRunProperty(string newDoc)
        {

            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Run run in D.Descendants<Run>().ToList().ToList())
                {
                    if (run.RunProperties != null && run.RunProperties.RunStyle != null && run.RunProperties.RunStyle.Val != null && run.RunProperties.RunStyle.Val == "Emphasis")
                    {
                        if (run.Descendants().ToList().Where(x => x.LocalName.ToString() == "iCs").Count() > 0)
                        {

                            Italic italic = new Italic();
                            //run.RunProperties.AppendChild(italic);
                            run.RunProperties.RunStyle.Remove();
                        }
                        else
                        {
                            Italic italic = new Italic();
                            ItalicComplexScript icstag = new ItalicComplexScript();
                            //run.RunProperties.AppendChild(italic);
                            //run.RunProperties.AppendChild(icstag);
                            run.RunProperties.RunStyle.Remove();

                        }
                    }

                }
                D.Save();
            }



        }

        public static void WDDeleteHiddenText(string docName)
        {

            using (WordprocessingDocument WPD = WordprocessingDocument.Open(docName, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().ToList())
                {
                    if (P.OuterXml.Contains("w:vanish"))
                    {
                        P.Remove();
                    }
                }
                D.Save();
            }
        }
        public static void removespacebeforedotlastrun(string docName)
        {

            using (WordprocessingDocument WPD = WordprocessingDocument.Open(docName, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().ToList())
                {
                    if (P.Descendants<Run>().Where(x => x.InnerText.EndsWith(" .")).Count() > 0)
                    {
                        foreach (Run R in P.Descendants<Run>().Where(x => x.InnerText.EndsWith(" .")).ToList())
                        {
                            if (R.NextSibling<Run>() == null)
                            {
                                foreach (Text text in R.Descendants<Text>().ToList())
                                {
                                    text.Text = text.Text.Replace(" .", ".");
                                }
                            }

                        }
                    }
                }
                D.Save();
            }
        }
        public static void RemoveAbbriviationFormAffl(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(c => c.Parent.LocalName != W.tc).ToList())
                {
                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val.Value == "AFFL")
                    {
                        foreach (var t in P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList())
                        {
                            foreach (var txt in t.ToList())
                            {
                                if (txt.Text.Trim().StartsWith("Dr.") || txt.Text.Trim().StartsWith("Doctor"))
                                {
                                    txt.Text = Regex.Replace(txt.Text.Trim(), @"^(\s{0,1}Dr.\s)|^(\s{0,1}Doctor\s)", "");
                                    continue;
                                }
                                else if (txt.Text.Trim().StartsWith("Jr.") || txt.Text.Trim().StartsWith("Junior"))
                                {
                                    txt.Text = Regex.Replace(txt.Text.Trim(), @"^(\s{0,1}Jr.\s)|^(\s{0,1}Junior\s)", "");
                                    continue;
                                }
                                else if (txt.Text.Trim().StartsWith("Prof.") || txt.Text.Trim().StartsWith("Professor"))
                                {
                                    txt.Text = Regex.Replace(txt.Text.Trim(), @"^(\s{0,1}Prof.\s)|^(\s{0,1}Professor\s)", "");
                                    continue;
                                }
                                else if (txt.Text.Trim().StartsWith("Sr.") || txt.Text.Trim().StartsWith("Senior"))
                                {
                                    txt.Text = Regex.Replace(txt.Text.Trim(), @"^(\s{0,1}Sr.\s)|^(\s{0,1}Senior\s)", "");
                                    continue;
                                }
                                else if (txt.Text.Trim().StartsWith("St.") || txt.Text.Trim().StartsWith("Saint"))
                                {
                                    txt.Text = Regex.Replace(txt.Text.Trim(), @"^(\s{0,1}St.\s)|^(\s{0,1}Saint\s)", "");
                                    continue;
                                }
                            }
                        }


                        P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().ForEach(t => t.ToList().ForEach(txt =>
                        {
                            if (txt == P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().LastOrDefault().LastOrDefault())
                            {
                                if (txt.Text.Trim().EndsWith("."))
                                {
                                    txt.Text = txt.Text.TrimEnd(' ').TrimEnd('.');
                                }
                            }
                        })
                        );




                    }
                    else if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val.Value == "CORR")
                    {
                        if (P.InnerText.Trim() != "" && !P.InnerText.Replace(" ", "").Trim().ToLower().Contains("addressforcorrespondence:")
                           && !P.InnerText.Replace(" ", "").Trim().ToLower().Contains("correspondenceto:")
                           && !P.InnerText.Replace(" ", "").Trim().ToLower().Contains("correspondingauthor:")
                           && !P.InnerText.Replace(" ", "").Trim().ToLower().Contains("addressforcorrespondance:")
                           && !P.InnerText.Replace(" ", "").Trim().ToLower().Contains("correspondingauthor:")
                           && !P.InnerText.Replace(" ", "").Trim().ToLower().Contains("correspondauthor:"))
                        {
                            P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().ForEach(t => t.ToList().ForEach(txt =>
                            {
                                if (txt.Text.Contains("Address for correspondence"))
                                {
                                    txt.Text = txt.Text.Replace("Address for correspondence", "Address for correspondence:");
                                }
                                else if (txt.Text.Contains("Correspondence to"))
                                {
                                    txt.Text = txt.Text.Replace("Correspondence to", "Correspondence to:");
                                }
                                else if (txt.Text.Contains("Corresponding author"))
                                {
                                    txt.Text = txt.Text.Replace("Corresponding author", "Corresponding author:");
                                }
                                else if (txt.Text.Contains("Address for correspondance"))
                                {
                                    txt.Text = txt.Text.Replace("Address for correspondance", "Address for correspondance:");
                                }
                                else if (txt.Text.Contains("Corresponding Author"))
                                {
                                    txt.Text = txt.Text.Replace("Corresponding Author", "Corresponding Author:");
                                }
                                else if (txt.Text.Contains("Correspond Author"))
                                {
                                    txt.Text = txt.Text.Replace("Correspond Author", "Correspond Author:");
                                }
                            })
                       );
                        }
                        //Developer Name:Priyanka Vishwakarma Date:12-12-2020 ,Requirement:Period is required at the end of Corresponding address 
                        if (P.InnerText.Trim() != "" && !P.InnerText.Trim().EndsWith("."))
                        {
                            if (P.InnerText.Trim() != "" && (P.InnerText.Replace(" ", "").Trim().ToLower().Contains("addressforcorrespondence:")
                           || P.InnerText.Replace(" ", "").Trim().ToLower().Contains("correspondenceto:")
                           || P.InnerText.Replace(" ", "").Trim().ToLower().Contains("correspondingauthor:")
                           || P.InnerText.Replace(" ", "").Trim().ToLower().Contains("addressforcorrespondance:")
                           || P.InnerText.Replace(" ", "").Trim().ToLower().Contains("correspondingauthor:")
                           || P.InnerText.Replace(" ", "").Trim().ToLower().Contains("correspondauthor:")))
                            {
                                if (P.InnerText.Replace(" ", "").Trim().ToLower() != "addressforcorrespondence:"
                                    && P.InnerText.Replace(" ", "").Trim().ToLower() != "correspondenceto:"
                                    && P.InnerText.Replace(" ", "").Trim().ToLower() != "correspondingauthor:"
                                    && P.InnerText.Replace(" ", "").Trim().ToLower() != "addressforcorrespondance:"
                                    && P.InnerText.Replace(" ", "").Trim().ToLower() != "correspondingauthor:"
                                    && P.InnerText.Replace(" ", "").Trim().ToLower() != "correspondauthor:")
                                {
                                    P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().ForEach(t => t.ToList().ForEach(txt =>
                                    {
                                        if (txt == P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().LastOrDefault().LastOrDefault())
                                        {
                                            if (!txt.Text.Trim().EndsWith("."))
                                            {
                                                txt.Text = txt.Text + ".";
                                            }
                                        }
                                    }));
                                }
                            }
                        }

                        if (P.InnerText.Trim().StartsWith("E-mail:") || P.InnerText.Trim().StartsWith("Email:") || P.InnerText.Contains("@"))////Developer Name:Priyanka Vishwakarma Date:12-12-2020 ,Requirement:Period is not required at the end of Corresponding addressif it start with email 
                        {
                            P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().ForEach(t => t.ToList().ForEach(txt =>
                            {
                                if (txt == P.Descendants<Run>().ToList().Select(c => c.Descendants<Text>()).ToList().LastOrDefault().LastOrDefault())
                                {
                                    if (txt.Text.Trim().EndsWith("."))
                                    {
                                        txt.Text = txt.Text.TrimEnd('.');
                                    }
                                }
                            }));
                        }

                    }

                }
                D.Save();
            }
        }
        public static void CheckFIGCParaWithoutLabelStrong(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P != null && P.InnerText != "")
                    {
                        if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val.Value == "FIGC")
                        {
                            if (P.Descendants<Run>().ToList().FirstOrDefault() != null
                                && P.Descendants<Run>().ToList().FirstOrDefault().Descendants().Where(x => x.LocalName == "rStyle").FirstOrDefault() == null
                                /*&& P.Descendants<Run>().ToList().FirstOrDefault().Descendants().Where(x => x.LocalName == "rStyle").FirstOrDefault().GetAttribute("val", P.NamespaceUri).Value != "label-Strong"*/)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "BodyA";
                            }
                        }
                    }


                }
                D.Save();
            }
        }
        public static void TFN_StyleAppliedBasisofText(string newDoc)     //Developer Name:Priyanka Vishwakarma,Date:20-04-2021,Requirement:Add conditioj for apply TFN paragarph style.
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(x => x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val.Value == "TT" && x.Parent != null && x.Parent.LocalName != W.tc.LocalName).ToList())
                {

                    if (P.InnerText.ToLower().StartsWith("notes:") || P.InnerText.ToLower().StartsWith("note:"))
                    {
                        P.ParagraphProperties.ParagraphStyleId.Val.Value = "TFN";
                    }
                    else if (P.InnerText.ToLower().StartsWith("source:") || P.InnerText.ToLower().StartsWith("sources:"))
                    {
                        P.ParagraphProperties.ParagraphStyleId.Val.Value = "TFN";
                    }
                    else if (P.InnerText.ToLower().StartsWith("abbreviation: ") || P.InnerText.ToLower().StartsWith("abbreviations:"))
                    {
                        P.ParagraphProperties.ParagraphStyleId.Val.Value = "TFN";
                    }

                }
                D.Save();
            }
        }
        public static void CheckTTParaLabelstrongText(string newDoc)     //Developer Name:Priyanka Vishwakarma,Date:20-04-2021,Requirement:Add conditioj for apply TFN paragarph style.
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(x => x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val.Value == "TT" && x.Parent != null && x.Parent.LocalName != W.tc.LocalName).ToList())
                {

                    if (P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val != null && x.RunProperties.RunStyle.Val.Value.ToLower() == "label-strong").ToList().Count() == 1)
                    {
                        var run = P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val != null && x.RunProperties.RunStyle.Val.Value.ToLower() == "label-strong").ToList().FirstOrDefault();
                        if (run != null)
                        {
                            if (GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(run.InnerText.Trim(), @"^(Table[0-9]+\s)") != null && GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(run.InnerText.Trim(), @"^(Table[0-9]+\s)") != "")
                            {
                                foreach (var txt in run.Descendants<Text>().ToList())
                                {
                                    txt.Text = txt.Text.Replace("Table", "Table ");
                                }

                            }

                        }

                    }


                }
                D.Save();
            }
        }
        public static void ChangeMSONormalParaStyleInParagraph(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower() == "normalweb")
                    {
                        if (P.Parent != null && P.Parent.LocalName == W.tc.LocalName)
                        {
                            P.ParagraphProperties.ParagraphStyleId.Val = "T-TXT";
                        }
                        else
                        {
                            P.ParagraphProperties.ParagraphStyleId.Val = "BodyA";
                        }
                    }

                }
                D.Save();
            }
        }

        public static void CheckTTParaComesBeforeTable(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
               .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val.Value == "TT")
                    {
                        if (P.NextSibling() != null && P.NextSibling().LocalName != "tbl")
                        {
                            P.ParagraphProperties.ParagraphStyleId.Val.Value = "BodyA";

                            foreach (Run R in P.Descendants<Run>().ToList())
                            {
                                if (R.RunProperties != null && R.RunProperties.RunStyle != null && R.RunProperties.RunStyle.Val.Value != null && R.RunProperties.RunStyle.Val.Value == "label-Strong")
                                {
                                    if (Regex.Match(R.InnerText.Trim(), @"(Table\s[A-Z][0-9]+\.?)").Value != "" && GlobalMethods.strClientName.ToLower() == "sage")//Developer Name:Priyanka Vishwakarma,Date:19-08-2021;Requirement:Add condition for avoid appendix table 
                                    {
                                        R.RunProperties.Remove();
                                    }
                                    else
                                    {
                                        R.RunProperties.RunStyle.Val.Value = "citetbl";
                                    }
                                }
                            }
                        }
                    }
                }
                D.Save();
            }

        }
        public static void CheckAlphalistParagraph(string newDoc)    //Developer name : Priyanka Vishwakarma ,Date:22-02-2020 ,Requirement:Avoid to apply AlphaUpperList,AlphalowerList and RomanList when para start with A ot I in word.  ,Integrated by:Vikas sir.
        {
            List<string> ListofListingStyleinWord = new List<string>();

            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                string Listnumber = null;
                string gettxt = null;
                string TextwithoutListnumber = null;
                List<Paragraph> listingParagraph = D.Descendants<Paragraph>().ToList().Where(x => x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val != null && x.Parent != null && x.Parent.XName.LocalName != "tc" && (x.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower() == "nl" || x.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower() == "bl" || x.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower() == "ul" || x.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower().EndsWith("list"))).ToList();
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(x => x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val != null && x.ParagraphProperties.ParagraphStyleId.Val.Value == "AlphaUpparList" && x.InnerText.Trim() != "").ToList())
                {
                    if (P.NextSibling().LocalName == "p" && (Paragraph)P.PreviousSibling() != null && P.NextSibling().LocalName == "p" && (Paragraph)P.NextSibling() != null)
                    {
                        Paragraph PrevPara = (Paragraph)P.PreviousSibling();
                        Paragraph NextPara = (Paragraph)P.NextSibling();
                        if (NextPara != null && NextPara.ParagraphProperties != null && NextPara.ParagraphProperties.ParagraphStyleId != null && NextPara.ParagraphProperties.ParagraphStyleId.Val != null && NextPara.ParagraphProperties.ParagraphStyleId.Val.Value != "AlphaUpparList")
                        {
                            if (PrevPara != null && PrevPara.ParagraphProperties != null && PrevPara.ParagraphProperties.ParagraphStyleId != null && PrevPara.ParagraphProperties.ParagraphStyleId.Val != null && PrevPara.ParagraphProperties.ParagraphStyleId.Val.Value != "AlphaUpparList")
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "BodyA";
                            }
                        }
                    }

                }

                D.Save();
            }
        }
        //Developer Name:Vikas , Date:02-10-2021 ,Requirement:if space in superscript run shift to next run if not superscript run like this for bold,italic,underline.
        public static void CleanupExtraSpaces(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P.Descendants<Run>().ToList().Any(x => x.InnerText.StartsWith(" ") || x.InnerText.EndsWith(" ") || x.InnerText == " "))
                    {
                        int i = 0;
                        var Rcount = P.Descendants<Run>().ToList().Count;

                        foreach (Run R in P.Descendants<Run>().ToList())
                        {
                            try
                            {
                                i++;
                                //////////////If run text is equal to space
                                if (R.InnerText.Trim() == "")
                                {
                                    if (R.RunProperties != null && R.RunProperties.VerticalTextAlignment != null && R.RunProperties.VerticalTextAlignment.Val == VerticalPositionValues.Superscript)
                                    {
                                        if (i < Rcount)
                                        {
                                            var nextR = P.Descendants<Run>().ToList()[i];
                                            if (nextR.RunProperties != null && nextR.RunProperties.VerticalTextAlignment == null)
                                            {
                                                if (nextR.Descendants<Text>().Count() > 0)
                                                {
                                                    var text = R.InnerText;
                                                    nextR.Descendants<Text>().FirstOrDefault().Text = text + nextR.Descendants<Text>().FirstOrDefault().Text;
                                                    nextR.Descendants<Text>().FirstOrDefault().Space = SpaceProcessingModeValues.Preserve;
                                                    R.Remove();
                                                }
                                            }
                                            else
                                            {
                                                if (nextR.Descendants<Text>().Count() > 0)
                                                {
                                                    var text = R.InnerText;
                                                    nextR.Descendants<Text>().FirstOrDefault().Text = text + nextR.Descendants<Text>().FirstOrDefault().Text;
                                                    nextR.Descendants<Text>().FirstOrDefault().Space = SpaceProcessingModeValues.Preserve;
                                                    R.Remove();
                                                }
                                            }
                                        }
                                    }
                                    else if (R.RunProperties != null && R.RunProperties.VerticalTextAlignment != null && R.RunProperties.VerticalTextAlignment.Val == VerticalPositionValues.Subscript)
                                    {
                                        if (i < Rcount)
                                        {
                                            var nextR = P.Descendants<Run>().ToList()[i];
                                            if (nextR.RunProperties != null && nextR.RunProperties.VerticalTextAlignment == null)
                                            {
                                                if (nextR.Descendants<Text>().Count() > 0)
                                                {
                                                    var text = R.InnerText;
                                                    nextR.Descendants<Text>().FirstOrDefault().Text = text + nextR.Descendants<Text>().FirstOrDefault().Text;
                                                    nextR.Descendants<Text>().FirstOrDefault().Space = SpaceProcessingModeValues.Preserve;
                                                    R.Remove();
                                                }
                                            }
                                            else
                                            {
                                                if (nextR.Descendants<Text>().Count() > 0)
                                                {
                                                    var text = R.InnerText;
                                                    nextR.Descendants<Text>().FirstOrDefault().Text = text + nextR.Descendants<Text>().FirstOrDefault().Text;
                                                    nextR.Descendants<Text>().FirstOrDefault().Space = SpaceProcessingModeValues.Preserve;
                                                    R.Remove();
                                                }
                                            }
                                        }
                                    }
                                    else if (R.RunProperties != null && R.RunProperties.Bold != null)
                                    {
                                        if (i < Rcount)
                                        {
                                            var nextR = P.Descendants<Run>().ToList()[i];
                                            if (nextR.RunProperties != null && (nextR.RunProperties.VerticalTextAlignment == null && nextR.RunProperties.Bold == null && nextR.RunProperties.Italic == null && nextR.RunProperties.Underline == null))
                                            {
                                                if (nextR.Descendants<Text>().Count() > 0)
                                                {
                                                    var text = R.InnerText;
                                                    nextR.Descendants<Text>().FirstOrDefault().Text = text + nextR.Descendants<Text>().FirstOrDefault().Text;
                                                    nextR.Descendants<Text>().FirstOrDefault().Space = SpaceProcessingModeValues.Preserve;
                                                    R.Remove();
                                                }
                                            }
                                            else
                                            {
                                                if (nextR.Descendants<Text>().Count() > 0)
                                                {
                                                    var text = R.InnerText;
                                                    nextR.Descendants<Text>().FirstOrDefault().Text = text + nextR.Descendants<Text>().FirstOrDefault().Text;
                                                    nextR.Descendants<Text>().FirstOrDefault().Space = SpaceProcessingModeValues.Preserve;
                                                    R.Remove();
                                                }
                                            }
                                        }
                                    }
                                    else if (R.RunProperties != null && R.RunProperties.Italic != null)
                                    {
                                        if (i < Rcount)
                                        {
                                            var nextR = P.Descendants<Run>().ToList()[i];
                                            if (nextR.RunProperties != null && (nextR.RunProperties.VerticalTextAlignment == null && nextR.RunProperties.Bold == null && nextR.RunProperties.Italic == null && nextR.RunProperties.Underline == null))
                                            {
                                                if (nextR.Descendants<Text>().Count() > 0)
                                                {
                                                    var text = R.InnerText;
                                                    nextR.Descendants<Text>().FirstOrDefault().Text = text + nextR.Descendants<Text>().FirstOrDefault().Text;
                                                    nextR.Descendants<Text>().FirstOrDefault().Space = SpaceProcessingModeValues.Preserve;
                                                    R.Remove();
                                                }
                                            }
                                            else
                                            {
                                                if (nextR.Descendants<Text>().Count() > 0)
                                                {
                                                    var text = R.InnerText;
                                                    nextR.Descendants<Text>().FirstOrDefault().Text = text + nextR.Descendants<Text>().FirstOrDefault().Text;
                                                    nextR.Descendants<Text>().FirstOrDefault().Space = SpaceProcessingModeValues.Preserve;
                                                    R.Remove();
                                                }
                                            }
                                        }
                                    }
                                    else if (R.RunProperties != null && R.RunProperties.Underline != null)
                                    {
                                        if (i < Rcount)
                                        {
                                            var nextR = P.Descendants<Run>().ToList()[i];
                                            if (nextR.RunProperties != null && (nextR.RunProperties.VerticalTextAlignment == null && nextR.RunProperties.Bold == null && nextR.RunProperties.Italic == null && nextR.RunProperties.Underline == null))
                                            {
                                                if (nextR.Descendants<Text>().Count() > 0)
                                                {
                                                    var text = R.InnerText;
                                                    nextR.Descendants<Text>().FirstOrDefault().Text = text + nextR.Descendants<Text>().FirstOrDefault().Text;
                                                    nextR.Descendants<Text>().FirstOrDefault().Space = SpaceProcessingModeValues.Preserve;
                                                    R.Remove();
                                                }
                                            }
                                            else
                                            {
                                                if (nextR.Descendants<Text>().Count() > 0)
                                                {
                                                    var text = R.InnerText;
                                                    nextR.Descendants<Text>().FirstOrDefault().Text = text + nextR.Descendants<Text>().FirstOrDefault().Text;
                                                    nextR.Descendants<Text>().FirstOrDefault().Space = SpaceProcessingModeValues.Preserve;
                                                    R.Remove();
                                                }
                                            }
                                        }
                                    }
                                    Rcount = P.Descendants<Run>().ToList().Count;

                                }



                                //////////////If run text endswith space
                                else if (R.InnerText.EndsWith(" "))
                                {
                                    if (R.RunProperties != null && R.RunProperties.VerticalTextAlignment != null && R.RunProperties.VerticalTextAlignment.Val == VerticalPositionValues.Superscript)
                                    {
                                        if (i < Rcount)
                                        {
                                            //var nextR = P.Descendants<Run>().ToList()[i];
                                            if (R.NextSibling() != null && R.NextSibling().XName.LocalName == "r")
                                            {
                                                var nextR = ((Run)R.NextSibling());
                                                if (nextR.RunProperties != null && nextR.RunProperties.VerticalTextAlignment == null)
                                                {
                                                    if (nextR.Descendants<Text>().Count() > 0)
                                                    {
                                                        var text = " ";
                                                        nextR.Descendants<Text>().FirstOrDefault().Text = text + nextR.Descendants<Text>().FirstOrDefault().Text;
                                                        nextR.Descendants<Text>().FirstOrDefault().Space = SpaceProcessingModeValues.Preserve;
                                                        R.Descendants<Text>().FirstOrDefault().Text = R.Descendants<Text>().FirstOrDefault().Text.TrimEnd();

                                                    }
                                                }
                                                else
                                                {
                                                    if (nextR.Descendants<Text>().Count() > 0)
                                                    {
                                                        var text = " ";
                                                        nextR.Descendants<Text>().FirstOrDefault().Text = text + nextR.Descendants<Text>().FirstOrDefault().Text;
                                                        nextR.Descendants<Text>().FirstOrDefault().Space = SpaceProcessingModeValues.Preserve;
                                                        R.Descendants<Text>().FirstOrDefault().Text = R.Descendants<Text>().FirstOrDefault().Text.TrimEnd();

                                                    }
                                                }
                                            }
                                        }
                                    }
                                    else if (R.RunProperties != null && R.RunProperties.VerticalTextAlignment != null && R.RunProperties.VerticalTextAlignment.Val == VerticalPositionValues.Subscript)
                                    {
                                        if (i < Rcount)
                                        {
                                            //var nextR = P.Descendants<Run>().ToList()[i];
                                            if (R.NextSibling() != null && R.NextSibling().XName.LocalName == "r")
                                            {
                                                var nextR = ((Run)R.NextSibling());

                                                if (nextR.RunProperties != null && nextR.RunProperties.VerticalTextAlignment == null)
                                                {
                                                    if (nextR.Descendants<Text>().Count() > 0)
                                                    {
                                                        var text = " ";
                                                        nextR.Descendants<Text>().FirstOrDefault().Text = text + nextR.Descendants<Text>().FirstOrDefault().Text;
                                                        nextR.Descendants<Text>().FirstOrDefault().Space = SpaceProcessingModeValues.Preserve;
                                                        R.Descendants<Text>().FirstOrDefault().Text = R.Descendants<Text>().FirstOrDefault().Text.TrimEnd();

                                                    }
                                                }
                                                else
                                                {
                                                    if (nextR.Descendants<Text>().Count() > 0)
                                                    {
                                                        var text = " ";
                                                        nextR.Descendants<Text>().FirstOrDefault().Text = text + nextR.Descendants<Text>().FirstOrDefault().Text;
                                                        nextR.Descendants<Text>().FirstOrDefault().Space = SpaceProcessingModeValues.Preserve;
                                                        R.Descendants<Text>().FirstOrDefault().Text = R.Descendants<Text>().FirstOrDefault().Text.TrimEnd();

                                                    }
                                                }
                                            }
                                        }
                                    }
                                    else if (R.RunProperties != null && R.RunProperties.Bold != null)
                                    {
                                        if (i < Rcount)
                                        {
                                            //var nextR = P.Descendants<Run>().ToList()[i];
                                            if (R.NextSibling() != null && R.NextSibling().XName.LocalName == "r")
                                            {
                                                var nextR = ((Run)R.NextSibling()); if (nextR.RunProperties != null && (nextR.RunProperties.VerticalTextAlignment == null && nextR.RunProperties.Bold == null && nextR.RunProperties.Italic == null && nextR.RunProperties.Underline == null))
                                                {

                                                    if (nextR.Descendants<Text>().Count() > 0)
                                                    {
                                                        var text = " ";
                                                        nextR.Descendants<Text>().FirstOrDefault().Text = text + nextR.Descendants<Text>().FirstOrDefault().Text;
                                                        nextR.Descendants<Text>().FirstOrDefault().Space = SpaceProcessingModeValues.Preserve;
                                                        R.Descendants<Text>().FirstOrDefault().Text = R.Descendants<Text>().FirstOrDefault().Text.TrimEnd();

                                                    }
                                                }
                                                else
                                                {
                                                    if (nextR.Descendants<Text>().Count() > 0)
                                                    {
                                                        var text = " ";
                                                        nextR.Descendants<Text>().FirstOrDefault().Text = text + nextR.Descendants<Text>().FirstOrDefault().Text;
                                                        nextR.Descendants<Text>().FirstOrDefault().Space = SpaceProcessingModeValues.Preserve;
                                                        R.Descendants<Text>().FirstOrDefault().Text = R.Descendants<Text>().FirstOrDefault().Text.TrimEnd();

                                                    }
                                                }
                                            }
                                        }
                                    }
                                    else if (R.RunProperties != null && R.RunProperties.Italic != null)
                                    {
                                        if (i < Rcount)
                                        {
                                            //var nextR = P.Descendants<Run>().ToList()[i];
                                            if (R.NextSibling() != null && R.NextSibling().XName.LocalName == "r")
                                            {
                                                var nextR = ((Run)R.NextSibling()); if (nextR.RunProperties != null && (nextR.RunProperties.VerticalTextAlignment == null && nextR.RunProperties.Bold == null && nextR.RunProperties.Italic == null && nextR.RunProperties.Underline == null))
                                                {
                                                    if (nextR.Descendants<Text>().Count() > 0)
                                                    {
                                                        var text = " ";
                                                        nextR.Descendants<Text>().FirstOrDefault().Text = text + nextR.Descendants<Text>().FirstOrDefault().Text;
                                                        nextR.Descendants<Text>().FirstOrDefault().Space = SpaceProcessingModeValues.Preserve;
                                                        R.Descendants<Text>().FirstOrDefault().Text = R.Descendants<Text>().FirstOrDefault().Text.TrimEnd();

                                                    }
                                                }
                                                else
                                                {
                                                    if (nextR.Descendants<Text>().Count() > 0)
                                                    {
                                                        var text = " ";
                                                        nextR.Descendants<Text>().FirstOrDefault().Text = text + nextR.Descendants<Text>().FirstOrDefault().Text;
                                                        nextR.Descendants<Text>().FirstOrDefault().Space = SpaceProcessingModeValues.Preserve;
                                                        R.Descendants<Text>().FirstOrDefault().Text = R.Descendants<Text>().FirstOrDefault().Text.TrimEnd();

                                                    }
                                                }
                                            }
                                        }
                                    }
                                    else if (R.RunProperties != null && R.RunProperties.Underline != null)
                                    {
                                        if (i < Rcount)
                                        {
                                            //var nextR = P.Descendants<Run>().ToList()[i];
                                            if (R.NextSibling() != null && R.NextSibling().XName.LocalName == "r")
                                            {
                                                var nextR = ((Run)R.NextSibling());
                                                if (nextR.RunProperties != null && (nextR.RunProperties.VerticalTextAlignment == null && nextR.RunProperties.Bold == null && nextR.RunProperties.Italic == null && nextR.RunProperties.Underline == null))
                                                {
                                                    if (nextR.Descendants<Text>().Count() > 0)
                                                    {
                                                        var text = " ";
                                                        nextR.Descendants<Text>().FirstOrDefault().Text = text + nextR.Descendants<Text>().FirstOrDefault().Text;
                                                        nextR.Descendants<Text>().FirstOrDefault().Space = SpaceProcessingModeValues.Preserve;
                                                        R.Descendants<Text>().FirstOrDefault().Text = R.Descendants<Text>().FirstOrDefault().Text.TrimEnd();

                                                    }
                                                }
                                                else
                                                {
                                                    if (nextR.Descendants<Text>().Count() > 0)
                                                    {
                                                        var text = " ";
                                                        nextR.Descendants<Text>().FirstOrDefault().Text = text + nextR.Descendants<Text>().FirstOrDefault().Text;
                                                        nextR.Descendants<Text>().FirstOrDefault().Space = SpaceProcessingModeValues.Preserve;
                                                        R.Descendants<Text>().FirstOrDefault().Text = R.Descendants<Text>().FirstOrDefault().Text.TrimEnd();
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    Rcount = P.Descendants<Run>().ToList().Count;

                                }


                                //////////////If run text endswith space
                                else if (R.InnerText.StartsWith(" ") && i != 1)
                                {
                                    if (R.RunProperties != null && R.RunProperties.VerticalTextAlignment != null && R.RunProperties.VerticalTextAlignment.Val == VerticalPositionValues.Superscript)
                                    {
                                        if (i <= Rcount)
                                        {
                                            if (R.PreviousSibling().XName.LocalName == "r")
                                            {
                                                var prevR = ((Run)R.PreviousSibling());
                                                if (prevR.RunProperties != null && prevR.RunProperties.VerticalTextAlignment == null)
                                                {
                                                    if (prevR.Descendants<Text>().Count() > 0)
                                                    {
                                                        var text = " ";
                                                        prevR.Descendants<Text>().FirstOrDefault().Text = prevR.Descendants<Text>().FirstOrDefault().Text + text;
                                                        prevR.Descendants<Text>().FirstOrDefault().Space = SpaceProcessingModeValues.Preserve;
                                                        R.Descendants<Text>().FirstOrDefault().Text = R.Descendants<Text>().FirstOrDefault().Text.TrimStart();

                                                    }
                                                }
                                                else
                                                {
                                                    if (prevR.Descendants<Text>().Count() > 0)
                                                    {
                                                        var text = " ";
                                                        prevR.Descendants<Text>().FirstOrDefault().Text = prevR.Descendants<Text>().FirstOrDefault().Text + text;
                                                        prevR.Descendants<Text>().FirstOrDefault().Space = SpaceProcessingModeValues.Preserve;
                                                        R.Descendants<Text>().FirstOrDefault().Text = R.Descendants<Text>().FirstOrDefault().Text.TrimStart();

                                                    }
                                                }
                                            }
                                        }
                                    }
                                    else if (R.RunProperties != null && R.RunProperties.VerticalTextAlignment != null && R.RunProperties.VerticalTextAlignment.Val == VerticalPositionValues.Subscript)
                                    {
                                        if (i <= Rcount)
                                        {
                                            if (R.PreviousSibling().XName.LocalName == "r")
                                            {
                                                var prevR = ((Run)R.PreviousSibling());
                                                if (prevR.RunProperties != null && prevR.RunProperties.VerticalTextAlignment == null)
                                                {
                                                    if (prevR.Descendants<Text>().Count() > 0)
                                                    {
                                                        var text = " ";
                                                        prevR.Descendants<Text>().FirstOrDefault().Text = prevR.Descendants<Text>().FirstOrDefault().Text + text;
                                                        prevR.Descendants<Text>().FirstOrDefault().Space = SpaceProcessingModeValues.Preserve;
                                                        R.Descendants<Text>().FirstOrDefault().Text = R.Descendants<Text>().FirstOrDefault().Text.TrimStart();

                                                    }
                                                }
                                                else
                                                {
                                                    if (prevR.Descendants<Text>().Count() > 0)
                                                    {
                                                        var text = " ";
                                                        prevR.Descendants<Text>().FirstOrDefault().Text = prevR.Descendants<Text>().FirstOrDefault().Text + text;
                                                        prevR.Descendants<Text>().FirstOrDefault().Space = SpaceProcessingModeValues.Preserve;
                                                        R.Descendants<Text>().FirstOrDefault().Text = R.Descendants<Text>().FirstOrDefault().Text.TrimStart();

                                                    }
                                                }
                                            }
                                        }
                                    }
                                    else if (R.RunProperties != null && R.RunProperties.Bold != null)
                                    {
                                        if (i <= Rcount)
                                        {
                                            if (R.PreviousSibling().XName.LocalName == "r")
                                            {
                                                var prevR = ((Run)R.PreviousSibling());
                                                if (prevR.RunProperties != null && (prevR.RunProperties.VerticalTextAlignment == null && prevR.RunProperties.Bold == null && prevR.RunProperties.Italic == null && prevR.RunProperties.Underline == null))
                                                {
                                                    if (prevR.Descendants<Text>().Count() > 0)
                                                    {
                                                        var text = " ";
                                                        prevR.Descendants<Text>().FirstOrDefault().Text = prevR.Descendants<Text>().FirstOrDefault().Text + text;
                                                        prevR.Descendants<Text>().FirstOrDefault().Space = SpaceProcessingModeValues.Preserve;
                                                        R.Descendants<Text>().FirstOrDefault().Text = R.Descendants<Text>().FirstOrDefault().Text.TrimStart();

                                                    }
                                                }
                                                else
                                                {
                                                    if (prevR.Descendants<Text>().Count() > 0)
                                                    {
                                                        var text = " ";
                                                        prevR.Descendants<Text>().FirstOrDefault().Text = prevR.Descendants<Text>().FirstOrDefault().Text + text;
                                                        prevR.Descendants<Text>().FirstOrDefault().Space = SpaceProcessingModeValues.Preserve;
                                                        R.Descendants<Text>().FirstOrDefault().Text = R.Descendants<Text>().FirstOrDefault().Text.TrimStart();

                                                    }
                                                }
                                            }
                                        }
                                    }
                                    else if (R.RunProperties != null && R.RunProperties.Italic != null)
                                    {
                                        if (i <= Rcount)
                                        {
                                            if (R.PreviousSibling().XName.LocalName == "r")
                                            {
                                                var prevR = ((Run)R.PreviousSibling());
                                                if (prevR.RunProperties != null && (prevR.RunProperties.VerticalTextAlignment == null && prevR.RunProperties.Bold == null && prevR.RunProperties.Italic == null && prevR.RunProperties.Underline == null))
                                                {
                                                    if (prevR.Descendants<Text>().Count() > 0)
                                                    {
                                                        var text = " ";
                                                        prevR.Descendants<Text>().FirstOrDefault().Text = prevR.Descendants<Text>().FirstOrDefault().Text + text;
                                                        prevR.Descendants<Text>().FirstOrDefault().Space = SpaceProcessingModeValues.Preserve;
                                                        R.Descendants<Text>().FirstOrDefault().Text = R.Descendants<Text>().FirstOrDefault().Text.TrimStart();

                                                    }
                                                }
                                                else
                                                {
                                                    if (prevR.Descendants<Text>().Count() > 0)
                                                    {
                                                        var text = " ";
                                                        prevR.Descendants<Text>().FirstOrDefault().Text = prevR.Descendants<Text>().FirstOrDefault().Text + text;
                                                        prevR.Descendants<Text>().FirstOrDefault().Space = SpaceProcessingModeValues.Preserve;
                                                        R.Descendants<Text>().FirstOrDefault().Text = R.Descendants<Text>().FirstOrDefault().Text.TrimStart();

                                                    }
                                                }
                                            }
                                        }
                                    }
                                    else if (R.RunProperties != null && R.RunProperties.Underline != null)
                                    {
                                        if (i <= Rcount)
                                        {
                                            if (R.PreviousSibling().XName.LocalName == "r")
                                            {
                                                var prevR = ((Run)R.PreviousSibling());
                                                if (prevR.RunProperties != null && (prevR.RunProperties.VerticalTextAlignment == null && prevR.RunProperties.Bold == null && prevR.RunProperties.Italic == null && prevR.RunProperties.Underline == null))
                                                {
                                                    if (prevR.Descendants<Text>().Count() > 0)
                                                    {
                                                        var text = " ";
                                                        prevR.Descendants<Text>().FirstOrDefault().Text = prevR.Descendants<Text>().FirstOrDefault().Text + text;
                                                        prevR.Descendants<Text>().FirstOrDefault().Space = SpaceProcessingModeValues.Preserve;
                                                        R.Descendants<Text>().FirstOrDefault().Text = R.Descendants<Text>().FirstOrDefault().Text.TrimStart();

                                                    }
                                                }
                                                else
                                                {
                                                    if (prevR.Descendants<Text>().Count() > 0)
                                                    {
                                                        var text = " ";
                                                        prevR.Descendants<Text>().FirstOrDefault().Text = prevR.Descendants<Text>().FirstOrDefault().Text + text;
                                                        prevR.Descendants<Text>().FirstOrDefault().Space = SpaceProcessingModeValues.Preserve;
                                                        R.Descendants<Text>().FirstOrDefault().Text = R.Descendants<Text>().FirstOrDefault().Text.TrimStart();
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    Rcount = P.Descendants<Run>().ToList().Count;

                                }
                            }
                            catch (Exception ex)
                            {
                            }

                        }
                    }
                }
                D.Save();
                WPD.Save();
            }
        }
        ///Added by vikas on 05-10-2021 for remove extra blank paragraphs and set aligment left for Table caption para and Figure caption para
        //Developer Name: Priyanka Vishwaakrma, Date:26-11-2021, Requirement: Remove space between dot and superscript value, Remove space between comma and superscript value
        public static void removespaceBetweencommaandRefcallout(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P.Descendants<Run>().ToList().Any(x => x.InnerText.StartsWith(" ") || x.InnerText.EndsWith(" ") || x.InnerText == " "))
                    {
                        int i = 0;
                        var Rcount = P.Descendants<Run>().ToList().Count;

                        foreach (Run R in P.Descendants<Run>().ToList())
                        {
                            if (R.RunProperties != null && R.RunProperties.RunStyle != null && R.RunProperties.RunStyle.Val != null && R.RunProperties.RunStyle.Val.Value == "citebib")
                            {
                                if (R.PreviousSibling().XName.LocalName.ToString() == "r") //Developer Name:Priyanka Vishwakarma, Date:6-12-2021, Requirement: add condiiton to xhexk next run is not comment tag
                                {
                                    var prevRun = (Run)R.PreviousSibling();
                                    if (prevRun != null && (prevRun.InnerText.EndsWith(", ") || prevRun.InnerText.EndsWith(", ")))
                                    {
                                        var text1 = prevRun.Descendants<Text>().ToList().LastOrDefault();
                                        if (text1 != null && (text1.InnerText.EndsWith(", ") || text1.InnerText.EndsWith(", ")))
                                        {
                                            text1.Text = text1.Text.TrimEnd(' ').TrimEnd(' ');
                                        }
                                    }
                                    else if (prevRun != null && (prevRun.InnerText.EndsWith(". ") || prevRun.InnerText.EndsWith(". ")))
                                    {
                                        var text1 = prevRun.Descendants<Text>().ToList().LastOrDefault();
                                        if (text1 != null && (text1.InnerText.EndsWith(". ") || text1.InnerText.EndsWith(". ")))
                                        {
                                            text1.Text = text1.Text.TrimEnd(' ').TrimEnd(' ');
                                        }
                                    }
                                    else if (prevRun != null && (prevRun.InnerText.EndsWith(": ") || prevRun.InnerText.EndsWith(": ")))
                                    {
                                        var text1 = prevRun.Descendants<Text>().ToList().LastOrDefault();
                                        if (text1 != null && (text1.InnerText.EndsWith(": ") || text1.InnerText.EndsWith(": ")))
                                        {
                                            text1.Text = text1.Text.TrimEnd(' ').TrimEnd(' ');
                                        }
                                    }
                                    else if (prevRun != null && (prevRun.InnerText.EndsWith("; ") || prevRun.InnerText.EndsWith("; ")))
                                    {
                                        var text1 = prevRun.Descendants<Text>().ToList().LastOrDefault();
                                        if (text1 != null && (text1.InnerText.EndsWith("; ") || text1.InnerText.EndsWith("; ")))
                                        {
                                            text1.Text = text1.Text.TrimEnd(' ').TrimEnd(' ');
                                        }
                                    }
                                    else if (prevRun != null && (prevRun.InnerText.EndsWith("? ") || prevRun.InnerText.EndsWith("? ")))
                                    {
                                        var text1 = prevRun.Descendants<Text>().ToList().LastOrDefault();
                                        if (text1 != null && (text1.InnerText.EndsWith("? ") || text1.InnerText.EndsWith("? ")))
                                        {
                                            text1.Text = text1.Text.TrimEnd(' ').TrimEnd(' ');
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                D.Save();
                WPD.Save();
            }
        }


        public static void BlankParasremoveandalignleftforFIGCandTT(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().Where(x => x.Parent != null && x.Parent.XName.LocalName != "tc" && x.Descendants<Run>().Count() == 0).ToList())
                {
                    if (P.PreviousSibling() != null && P.PreviousSibling().XName.LocalName != "tbl")
                        P.Remove();
                }

                foreach (Paragraph P in D.Descendants<Paragraph>().Where(x => x.Parent != null && x.Parent.XName.LocalName != "tc" && x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val != null && (x.ParagraphProperties.ParagraphStyleId.Val == "FIGC" || x.ParagraphProperties.ParagraphStyleId.Val == "TT")).ToList())
                {
                    if (P.ParagraphProperties.Justification != null && P.ParagraphProperties.Justification.Val == JustificationValues.Center)
                    {
                        P.ParagraphProperties.Justification.Val = JustificationValues.Left;
                    }
                }
                D.Save();
            }
        }
        public static void AddColonInTabbleCaptionandFigureCaptionForJaypee(string newDoc)    //Developer name : Priyanka Vishwakarma ,Date:5-10-2021, add function for add colon after figure and table labelstrong text
        {
            List<string> ListofListingStyleinWord = new List<string>();

            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;
                Document D = MDP.Document;
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(x => x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val != null && (x.ParagraphProperties.ParagraphStyleId.Val.Value == "TT" || x.ParagraphProperties.ParagraphStyleId.Val.Value == "FIGC")).ToList())
                {
                    var labelStrongRun = P.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val.Value == "label-Strong").ToList().LastOrDefault();
                    if (labelStrongRun != null && labelStrongRun.NextSibling() != null && labelStrongRun.NextSibling().XName.LocalName == W.r.LocalName)//not null check and element is run element check added by vikas on 14-11-2021
                    {
                        Run NextPara = (Run)labelStrongRun.NextSibling();
                        if (NextPara != null && NextPara.InnerText.Trim() != " ")
                        {
                            if (NextPara.NextSibling() != null && NextPara.NextSibling().XName.LocalName == W.r.LocalName)//not null check and element is run element check added by vikas on 14-11-2021
                            {
                                NextPara = (Run)NextPara.NextSibling();
                            }
                            else if (NextPara.NextSibling() != null && NextPara.NextSibling().NextSibling() != null && NextPara.NextSibling().NextSibling().XName.LocalName == W.r.LocalName)///this added due to nextsibling is some time commentEnd tag so goto NextSibling().NextSibling() for run check added by vikas on 14-11-2021
                            {
                                NextPara = (Run)NextPara.NextSibling().NextSibling();
                            }
                        }
                        if (labelStrongRun != null && labelStrongRun.InnerText != "" && !labelStrongRun.InnerText.Trim().EndsWith(":"))
                        {
                            if (NextPara != null && NextPara.InnerText != "" && NextPara.InnerText.Trim().StartsWith(":"))
                            {
                                var text = labelStrongRun.Descendants<Text>().ToList().LastOrDefault();
                                if (text != null)
                                {
                                    text.Text = text.Text + ":";
                                }
                                var text2 = NextPara.Descendants<Text>().ToList().FirstOrDefault();
                                if (text2 != null && (text2.InnerText.StartsWith(" :")|| text2.InnerText.StartsWith(" :")|| text2.InnerText.StartsWith(" :"))) //Developer Name:Priyanka Vishwakarma, Date:16-2-2022,Add condition for avoid to add colon in figc and TT 
                                {
                                    text2.Text = text2.Text.Trim().TrimStart(':');
                                    text2.Text = " " + text2.Text;
                                }
                               else  if (text2 != null && text2.InnerText.StartsWith(":"))
                                {
                                    text2.Text = text2.Text.TrimStart(':');
                                }

                            }
                            else if (NextPara != null && NextPara.InnerText != "" && NextPara.InnerText.Trim().StartsWith("."))
                            {
                                var text = labelStrongRun.Descendants<Text>().ToList().LastOrDefault();
                                if (text != null)
                                {
                                    text.Text = text.Text + ":";
                                }
                                var text2 = NextPara.Descendants<Text>().ToList().FirstOrDefault();
                                if (text2 != null && text2.InnerText.StartsWith("."))
                                {
                                    text2.Text = text2.Text.TrimStart('.');
                                }

                            }
                            else
                            {
                                var text = labelStrongRun.Descendants<Text>().ToList().LastOrDefault();
                                if (text != null)
                                {
                                    text.Text = text.Text.TrimEnd('.') + ":";
                                }

                            }
                        }
                    }
                }
                D.Save();
            }
        }
        public static void ReplaceEndashAndEmdashIntodashInOrcid(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                List<string> authorename = new List<string>();
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(x => x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val != null && x.ParagraphProperties.ParagraphStyleId.Val.Value == "ORCID-AU"))
                {
                    foreach (var text in P.Descendants<Text>().ToList())
                    {
                        if (text.InnerText.Contains("–") || text.InnerText.Contains("—"))
                        {
                            text.Text = text.Text.Replace("–", "-").Replace("—", "-");
                        }
                    }

                }
                D.Save();
            }
        }
        public static void AddDummyHeadingTag(string newDoc)     //Developer Name:Priyanka Vishwakarma, Date:27-11-2021, Add dummy heading tag 
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                var HowtocitethisarticleHead = D.Descendants<Paragraph>().ToList().Where(x => x.InnerText.ToLower().Trim() == "how to cite this article").ToList().FirstOrDefault();
                var Sourceofsupport = D.Descendants<Paragraph>().ToList().Where(x => x.InnerText.ToLower().Trim() == "source of support").ToList().FirstOrDefault();
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P != null && P.InnerText.Trim() == "")
                    {

                        if (P.ParagraphProperties != null && P.Parent != null && P.Parent.LocalName != "tc") //Developer Name:Priyanka Vishwakarma .Date:20-07-2020 ,Requirement :Avoid to remove blank para from table.
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val.Value != null && P.Parent != null && P.Parent.LocalName != "tc" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "TT")
                            {
                                if (!P.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower().EndsWith("start") && !P.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower().EndsWith("end"))
                                {
                                    P.Remove();
                                }
                            }
                        }
                    }
                }
                D.Save();
            }
        }
        public static void REFStyle(string newDoc)
        {
            //use tempervaory H1 style for logic.
            var RFStyle = ConfigurationManager.AppSettings.Get("RefHeadingList");

            List<string> REFStylesColl = new List<string>();
            ///Configuration read from Supporting folder
            REFStylesColl = GlobalMethods.ReadAndStoreFileValuesInArray(RFStyle);
            using (WordprocessingDocument WPD = WordprocessingDocument
                .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                var refpara = D.Descendants<Paragraph>().ToList().Where(x => x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val != null && x.ParagraphProperties.ParagraphStyleId.Val.Value == "REF").ToList().FirstOrDefault();
                if (refpara == null)
                {
                    foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(x => x.InnerText.Length < 50))
                    {
                        if (P != null && P.InnerText != "")
                        {
                            if (P.Parent != null && P.Parent.LocalName != "tc") //Developer Name:Priyanka Vishwakarma, Date:14-12-2021, Reqiurement:Add condition for void table para
                            {
                                string a = P.InnerText.ToLower();
                                a = a.Replace(" ", "").Replace("-", "").Replace(":", "").Replace(".", "").Replace("?", "");
                                for (int i = 0; i < REFStylesColl.Count; i++)
                                {
                                    string retValMatch = matchREFHeadingPara(a.ToLower(), REFStylesColl[i].ToLower().Trim());
                                    if (retValMatch == "0")
                                    {
                                        if (P.ParagraphProperties != null)
                                        {
                                            if (P.ParagraphProperties.ParagraphStyleId != null)
                                            {
                                                P.ParagraphProperties.ParagraphStyleId.Val = "REF";
                                            }
                                            else
                                            {
                                                P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "REF" };
                                            }
                                        }
                                        else
                                        {
                                            P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "REF" });
                                        }
                                        goto nextFunction;
                                    }
                                    else if (retValMatch == "-1")
                                    {
                                        continue;
                                    }
                                    else
                                    {
                                        if (P.ParagraphProperties != null)
                                        {
                                            if (P.ParagraphProperties.ParagraphStyleId != null)
                                            {
                                                P.ParagraphProperties.ParagraphStyleId.Val = "REF";
                                            }
                                            else
                                            {
                                                P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "REF" };
                                                //Add Query
                                            }
                                        }
                                        else
                                        {
                                            P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "REF" });
                                            //Add Query
                                        }



                                        //Comment Add Part
                                        Comments comments = null;
                                        string id = "0";

                                        // Verify that the document contains a 
                                        // WordProcessingCommentsPart part; if not, add a new one.
                                        if (D.MainDocumentPart.GetPartsCountOfType<WordprocessingCommentsPart>() > 0)
                                        {
                                            comments = D.MainDocumentPart.WordprocessingCommentsPart.Comments;
                                            List<string> allcomments = new List<string>();
                                            foreach (var cm in comments.ToList())
                                            {
                                                allcomments.Add(cm.InnerText.Trim());
                                            }

                                            if (allcomments.Any(x => x == retValMatch.Trim()))
                                            {
                                                goto nextFunction; //continue;
                                            }
                                            if (comments.HasChildren)
                                            {
                                                // Obtain an unused ID.
                                                id = (comments.Descendants<Comment>().Select(e => int.Parse(e.Id.Value)).Max() + 1).ToString();
                                            }
                                        }
                                        else
                                        {
                                            // No WordprocessingCommentsPart part exists, so add one to the package.
                                            WordprocessingCommentsPart commentPart =
                                                D.MainDocumentPart.AddNewPart<WordprocessingCommentsPart>();
                                            commentPart.Comments = new Comments();
                                            comments = commentPart.Comments;
                                            //if (commentPart != null && commentPart.Comments != null)
                                            //{
                                            //    var commentList = commentPart.Comments.ToList();
                                            //}
                                        }


                                        // Compose a new Comment and add it to the Comments part.
                                        Paragraph p = new Paragraph();
                                        Run r1 = new Run();
                                        r1.RunProperties = new RunProperties(new RunStyle { Val = "CommentReference" });
                                        AnnotationReferenceMark an = new AnnotationReferenceMark();
                                        r1.AppendChild(an);
                                        p.AppendChild(r1);
                                        Run r2 = new Run(new Text(retValMatch));
                                        p.AppendChild(r2);
                                        p.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "CommentText" });
                                        Comment cmt =
                                            new Comment()
                                            {
                                                Initials = "AU",
                                                Author = "Author Query",
                                                Id = id,
                                                Date = DateTime.Now
                                            };
                                        cmt.AppendChild(p);
                                        comments.AppendChild(cmt);
                                        comments.Save();

                                        // Specify the text range for the Comment. 
                                        // Insert the new CommentRangeStart before the first run of paragraph.
                                        P.InsertBefore(new CommentRangeStart()
                                        { Id = id }, P.GetFirstChild<Run>());

                                        // Insert the new CommentRangeEnd after last run of paragraph.
                                        var cmtEnd = P.InsertAfter(new CommentRangeEnd()
                                        { Id = id }, P.Elements<Run>().Last());

                                        // Compose a run with CommentReference and insert it.
                                        P.InsertAfter(new Run(new CommentReference() { Id = id }), cmtEnd);
                                        //End comment
                                        goto nextFunction;

                                    }
                                }
                            }
                        }
                    }
                    nextFunction: { }
                }
                D.Save();
            }
        }

        public static void removeSpacebeforerefCallout(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P.Descendants<Run>().ToList().Any(x => x.InnerText.StartsWith(" ") || x.InnerText.EndsWith(" ") || x.InnerText == " "))
                    {
                        int i = 0;
                        var Rcount = P.Descendants<Run>().ToList().Count;

                        foreach (Run R in P.Descendants<Run>().ToList())
                        {
                            if (R.RunProperties != null && R.RunProperties.RunStyle != null && R.RunProperties.RunStyle.Val != null && R.RunProperties.RunStyle.Val.Value == "citebib")
                            {
                                if (R.PreviousSibling()!=null && R.PreviousSibling().XName.LocalName.ToString() == "r") 
                                {
                                    var prevRun = (Run)R.PreviousSibling();
                                    if (prevRun != null && (prevRun.InnerText.EndsWith(" ") || prevRun.InnerText.EndsWith(" ")))
                                    {
                                        var text1 = prevRun.Descendants<Text>().ToList().LastOrDefault();
                                        if (text1 != null && (text1.InnerText.EndsWith(" ") || text1.InnerText.EndsWith(" ")))
                                        {
                                            text1.Text = text1.Text.TrimEnd(' ').TrimEnd(' ');
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                D.Save();
                WPD.Save();
            }
            Addspaceafterrefcallout(newDoc);
        }
        public static void Addspaceafterrefcallout(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    foreach (Run R in P.Descendants<Run>().ToList())
                    {
                        if (R.RunProperties != null && R.RunProperties.RunStyle != null && R.RunProperties.RunStyle.Val != null && R.RunProperties.RunStyle.Val.Value == "citebib")
                        {
                            if (R.NextSibling() != null && R.NextSibling().XName.LocalName.ToString() == "r")
                            {
                                var NextRun = (Run)R.NextSibling();
                                if (NextRun != null && (!NextRun.InnerText.StartsWith(" ") && !NextRun.InnerText.StartsWith(" ") && !NextRun.InnerText.StartsWith(",") && !NextRun.InnerText.StartsWith(".") && !NextRun.InnerText.StartsWith(";") && !NextRun.InnerText.StartsWith(":") && !NextRun.InnerText.StartsWith("?") && !NextRun.InnerText.StartsWith("!")))
                                {
                                    var text1 = NextRun.Descendants<Text>().ToList().LastOrDefault();
                                    if (text1 != null && (!text1.InnerText.StartsWith(" ") || !text1.InnerText.StartsWith(" ")))
                                    {
                                        Run r = new Run();
                                        Text T = new Text(" ") { Space = SpaceProcessingModeValues.Preserve };
                                        r.AppendChild(T);
                                        NextRun.InsertBeforeSelf(r);
                                    }
                                }
                            }
                        }
                    }
                }
                D.Save();
                WPD.Save();
            }
        }

        public static bool checkReferenceParagraphsComesinFootnote(string newDoc)
        {
            List<string> allFootnotePara = new List<string>();
            bool ReferenceParaFound = false;
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(x => x.Parent.LocalName != W.tc && x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val != null && x.ParagraphProperties.ParagraphStyleId.Val.Value == "FTN").ToList())
                {
                    var newP = P.CloneNode(true);
                    Run r = newP.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val != null && x.RunProperties.RunStyle.Val.Value == "label-fn").ToList().FirstOrDefault();
                    if (r != null)
                    {
                        r.Remove();
                    }
                    if (P.InnerText.Trim() != "")
                        allFootnotePara.Add(P.InnerText.Trim());
                }
                int cnt = 0;
                int allfootnoteCnt = allFootnotePara.Count();
                if (allFootnotePara.Count() > 0)
                {
                    foreach (var text in allFootnotePara.ToList())
                    {
                        if (Regex.Match(text, @"([0-9]{4})([\;\s]+)([0-9]+)(\()([A-Z][a-z]+)(\))(\:)([GQBEeSsCcZz0-9]+)([\–|\-|\—])([GQBEeSsCcZz0-9]+)|([0-9]{4})([\:\)\;\s\,]+)([0-9]+)([\(\s]+)([0-9-\/]+)(\))([\:\s]+)([GQBEeSsCcZz0-9]+)([\–|\-|\—])([GQBEeSsCcZz0-9]+)|([0-9]{4})([\:\)\;\s\,]+)([0-9]+)([\(\s]+)([0-9-\/]+)(\))([GQBEeSsCcZz0-9]+)([\–|\-|\—])([GQBEeSsCcZz0-9]+)|([0-9]{4})([\:\)\;\s\,]+)([0-9]+)([\(\s]+)([0-9]+)([\)\:\s]+)([GQBEeSsCcZz0-9]+)([\–|\-|\—])([GQBEeSsCcZz0-9]+)|([0-9]{4})([\:\)\;\s\,]+)([0-9]+)([\(\s]+)([0-9-\/]+)([\)\:\s]+)([GQBEeSsCcZz0-9]+)([\–|\-|\—])([GQBEeSsCcZz0-9]+)|([0-9]{4})([\:\)\;\s\,]+)([0-9]+)([\(\s]+)([0-9]+–[0-9]+)(\))([\:\s]+)([GQBEeSsCcZz0-9]+)([\–|\-|\—])([GQBEeSsCcZz0-9]+)|([0-9]{4}\s[A-Z][a-z]{2})([\s\;]+)([0-9]+)([\s\(]+)([0-9]+)([\)\:\s]+)([\)\:\s]+)([GQBEeSsCcZz0-9]+)([\–|\-|\—])([GQBEeSsCcZz0-9]+)|([0-9]{4}\s[A-Z][a-z]{2}\/[A-Z][a-z]{2})([\s\;]+)([0-9]+)([\s\(]+)([0-9]+)([\)\:\s]+)([\)\:\s]+)([GQBEeSsCcZz0-9]+)([\–|\-|\—])([GQBEeSsCcZz0-9]+)|([0-9]{4}\s[A-Z][a-z]{2}\-[A-Z][a-z]{2})([\s\;]+)([0-9]+)([\s\(]+)([0-9]+)([\)\:\s]+)([\)\:\s]+)([GQBEeSsCcZz0-9]+)([\–|\-|\—])([GQBEeSsCcZz0-9]+)|([0-9]{4}\s[A-Z][a-z]{2}\s[0-9]+)(\;)([0-9]+)(\()([0-9]+)(\))(\:)([GQBEeSsCcZz0-9]+)([\–|\-|\—])([GQBEeSsCcZz0-9]+)|([0-9]{4}\s[A-Z][a-z]{2}\s[0-9]+)(\;)([0-9]+)(\()([0-9]+)(\))(\:)([0-9]+)([\–|\-|\—])([GQBEeSsCcZz0-9]+)|([0-9]{4}\s[A-Z][a-z]{2}\s[0-9]+)(\;)([0-9]+)(\()([0-9]+)(\))(\:)([GQBEeSsCcZz0-9]+)([\–|\-|\—])([GQBEeSsCcZz0-9]+)|([0-9]{4}\s[A-Z][a-z]{2})(\;)([0-9]+)(\()([0-9]+)(\))(\:)([GQBEeSsCcZz0-9]+)([\–|\-|\—])([GQBEeSsCcZz0-9]+)|([0-9]{4}\s[A-Z][a-z]{2}\-[A-Z][a-z]{2})(\;\s)([0-9]+)(\()([0-9]+)(\))(\:)([GQBEeSsCcZz0-9]+)([\–|\-|\—])([GQBEeSsCcZz0-9]+)|([0-9]{4})(\.)([0-9]+)(\()([0-9]+)([\)\:]+)([GQBEeSsCcZz0-9]+)|([0-9]{4})([\:\)\;\s\,]+)([0-9]+)([\(\s]+)([0-9-\/]+)(\))([\:\s]+)([EeSsCcZz.0-9]+)([.]*)|([0-9]{4}\s[A-Z][a-z]{2})(\;)([0-9]+)(\()([0-9]+)(\))(\:)([GQBEeSsCcZz0-9]+)([.]*)|([0-9]{4}\s[A-Z][a-z]{2}\s[0-9]+)(\;)([0-9]+)(\()([0-9]+)(\))(\:)([GQBEeSsCcZz0-9]+)([.]*)|([0-9]{4})([\:\)\;\s\,]+)([IVXL]+)([\:\s]+)([GQBEeSsCcZz0-9]+)([\–|\-|\—])([GQBEeSsCcZz0-9]+)|([0-9]{4})([\:\)\;\s\,]+)([0-9]+)([\:\s]+)([GQBEeSsCcZz0-9]+)([\–|\-|\—])([GQBEeSsCcZz0-9]+)|([0-9]{4}\s[A-Z][a-z]{2})([\s\;])([0-9]+)(\:)([GQBEeSsCcZz0-9]+)([\–|\-|\—])([GQBEeSsCcZz0-9]+)([.]*)|([0-9]{4})(\;)([GQBEeSsCcZz0-9]+)([\–|\-|\—])([GQBEeSsCcZz0-9]+)|([0-9]{4}\s[A-Z][a-z]{2}\s[0-9]+)(\;)([0-9]+)(\:)([GQBEeSsCcZz0-9]+)([.]*)|([0-9]{4})([\:\)\;\s\,]+)([0-9]+)([\:\s]+)([GQBEeSsCcZz0-9]+)([.]*)|([0-9]{4})([\:\)\;\s\,]+)([0-9]+)([\(\s]+)([0-9-\/]+)(\))([.]*)", RegexOptions.IgnoreCase).Success)
                        {
                            cnt++;
                        }
                    }

                    var cntper = 0.75 * allFootnotePara.Count();
                    if (cnt >= Convert.ToInt32(cntper))
                    {
                        ReferenceParaFound = true;
                    }
                }
                D.Save();
                WPD.Save();
            }
            return ReferenceParaFound;
        }
        public static void checkForReferencePara(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                var refpara = D.Descendants<Paragraph>().ToList().Where(x => x.Parent.LocalName != W.tc && x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val != null && x.ParagraphProperties.ParagraphStyleId.Val.Value == "REF").ToList().FirstOrDefault();
                if (refpara == null)
                {
                    Paragraph refHeadingPara = new Paragraph(new Run(new Text("References")));
                    refHeadingPara.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "REF" });
                    var ftnpara = D.Descendants<Paragraph>().ToList().Where(x => x.Parent.LocalName != W.tc && x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val != null && x.ParagraphProperties.ParagraphStyleId.Val.Value == "FTN").ToList().FirstOrDefault();
                    if (ftnpara != null)
                    {
                        ftnpara.InsertBeforeSelf(refHeadingPara);
                    }
                }

                D.Save();
            }
        }
        public static void removelabelfnfromFTN(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;
                Document D = MDP.Document;
                var ftnPara = D.Descendants<Paragraph>().ToList().Where(x => x.Parent.LocalName != W.tc && x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val != null && x.ParagraphProperties.ParagraphStyleId.Val.Value == "FTN").ToList();
                foreach (var para in ftnPara.ToList())
                {
                    var labelfn = para.Descendants<Run>().ToList().Where(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val != null && x.RunProperties.RunStyle.Val.Value == "label-fn").ToList();
                    foreach (var fn in labelfn.ToList())
                    {
                        fn.RunProperties = null;
                    }
                }

                D.Save();
            }
        }
        public static void ApplyH1StyleToAllCapsParagraph(string newDoc)
        {
            bool IntroductionHeadingParaFound = false;
            bool RefHeadingParaFound = false;
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;
                Document D = MDP.Document;
                var IntroductionHeadingPara = D.Descendants<Paragraph>().ToList().Where(x => x.Parent.LocalName != W.tc && x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val != null && x.ParagraphProperties.ParagraphStyleId.Val.Value == "H1" && x.InnerText.ToLower().Trim() == "introduction").ToList().FirstOrDefault();
                var RefHeadingPara = D.Descendants<Paragraph>().ToList().Where(x => x.Parent.LocalName != W.tc && x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val != null && x.ParagraphProperties.ParagraphStyleId.Val.Value == "REF").ToList().FirstOrDefault();
                if (IntroductionHeadingPara != null && RefHeadingPara != null)
                {
                    foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(x => x.InnerText.Length < 50))
                    {
                        if (P.Parent != null && P.Parent.LocalName != "tc")
                        {
                            if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val.Value == "H1" && P.InnerText.ToLower().Trim() == "introduction")
                            {
                                IntroductionHeadingParaFound = true;
                            }
                            if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val.Value == "REF")
                            {
                                RefHeadingParaFound = true;
                                break;
                            }

                            if (P != null && P.InnerText != "" && IntroductionHeadingParaFound)
                            {
                                string a = P.InnerText.Replace(" ", "").Replace("-", "").Replace(":", "").Replace(".", "").Replace("?", "");
                                var AllCapParaFound = checkAllcharISUpper(a);
                                if (AllCapParaFound)
                                {
                                    if (P.ParagraphProperties != null)
                                    {
                                        if (P.ParagraphProperties.ParagraphStyleId != null)
                                        {
                                            P.ParagraphProperties.ParagraphStyleId.Val = "H1";
                                        }
                                        else
                                        {
                                            P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "H1" };
                                        }
                                    }
                                    else
                                    {
                                        P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "H1" });
                                    }
                                }

                            }
                        }
                    }
                }
                D.Save();
            }
        }
        public static bool checkAllcharISUpper(string word)
        {
            if (word.ToList().All(x => char.IsUpper(x)))
            {
                return true;
            }
            return false;
        }
        public static void ApplyABTXTStyle(string newDoc)
        {
            bool AbstractHeadingParaParaFound = false;
            bool KeywordsHeadingParaFound = false;
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;
                Document D = MDP.Document;
                var AbstractHeadingPara = D.Descendants<Paragraph>().ToList().Where(x => x.Parent.LocalName != W.tc && x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val != null && x.ParagraphProperties.ParagraphStyleId.Val.Value == "AB").ToList().FirstOrDefault();
                var KeywordsHeadingPara = D.Descendants<Paragraph>().ToList().Where(x => x.Parent.LocalName != W.tc && x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val != null && x.ParagraphProperties.ParagraphStyleId.Val.Value == "KYWD").ToList().FirstOrDefault();
                if (AbstractHeadingPara != null && KeywordsHeadingPara != null)
                {
                    foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                    {
                        if (P.Parent != null && P.Parent.LocalName != "tc")
                        {
                            if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val.Value == "AB")
                            {
                                AbstractHeadingParaParaFound = true;
                                continue;
                            }
                            if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val.Value == "KYWD")
                            {
                                KeywordsHeadingParaFound = true;
                                break;
                            }

                            if (P != null && P.InnerText != "" && AbstractHeadingParaParaFound)
                            {
                                if (P.ParagraphProperties != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId != null)
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val = "AB-TXT";
                                    }
                                    else
                                    {
                                        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "AB-TXT" };
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "AB-TXT" });
                                }
                            }
                        }
                    }
                }
                D.Save();
            }
        }

        public static void ChangeBraketsFigureCaption(string newDoc)     //Developer Name:Priyanka Vishwakarma, Date:15_10_2019 ,Requirement:Opening and Closing BRACKETs should be UNBOLD in Figure Caption ,Integrated by:Vikas sir.
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                    {
                        foreach (Run r in P.Descendants<Run>().ToList()/*.Any(x => x.LocalName == "b")*/)
                        {
                            if (r.RunProperties != null && r.RunProperties.RunStyle != null && r.RunProperties.RunStyle.Val != null && r.RunProperties.RunStyle.Val.Value=="citefig")
                            {
                                if (r.PreviousSibling() != null && r.NextSibling() != null && r.NextSibling().InnerText.StartsWith(")") && r.PreviousSibling().InnerText.EndsWith("("))
                                {
                                    var lastText = r.PreviousSibling().Descendants<Text>().ToList().LastOrDefault();
                                    var FirstText = r.NextSibling().Descendants<Text>().ToList().FirstOrDefault();
                                    if (lastText.Text.EndsWith("(") && FirstText.Text.StartsWith(")"))
                                    {
                                        if (lastText.Text.EndsWith("("))
                                        {
                                            lastText.Text = lastText.Text.TrimEnd('(') + "[";
                                        }


                                        if (FirstText.Text.StartsWith(")"))
                                        {
                                            FirstText.Text = "]" + FirstText.Text.TrimStart(')');
                                        }
                                    }
                                }
                                else if (r.PreviousSibling() != null && r.NextSibling() != null && r.NextSibling().InnerText.StartsWith("}") && r.PreviousSibling().InnerText.EndsWith("{"))
                                {
                                    var lastText = r.PreviousSibling().Descendants<Text>().ToList().LastOrDefault();
                                    var FirstText = r.NextSibling().Descendants<Text>().ToList().FirstOrDefault();
                                    if (lastText.Text.EndsWith("{") && FirstText.Text.StartsWith("}"))
                                    {
                                        if (lastText.Text.EndsWith("{"))
                                        {
                                            lastText.Text = lastText.Text.TrimEnd('{') + "[";
                                        }

                                       
                                        if (FirstText.Text.StartsWith("}"))
                                        {
                                            FirstText.Text = "]" + FirstText.Text.TrimStart('}');
                                        }
                                    }
                                }
                                

                            }
                        }
                    }

                }
                D.Save();
            }
        }

        public static void ChangeBraketsTableCaption(string newDoc)     //Developer Name:Priyanka Vishwakarma, Date:15_10_2019 ,Requirement:Opening and Closing BRACKETs should be UNBOLD in Figure Caption ,Integrated by:Vikas sir.
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                    {
                        foreach (Run r in P.Descendants<Run>().ToList()/*.Any(x => x.LocalName == "b")*/)
                        {
                            if (r.RunProperties != null && r.RunProperties.RunStyle != null && r.RunProperties.RunStyle.Val != null && r.RunProperties.RunStyle.Val.Value == "citetbl")
                            {
                                if (r.PreviousSibling() != null && r.NextSibling() != null && r.NextSibling().InnerText.StartsWith(")") && r.PreviousSibling().InnerText.EndsWith("("))
                                {
                                    var lastText = r.PreviousSibling().Descendants<Text>().ToList().LastOrDefault();
                                    var FirstText = r.NextSibling().Descendants<Text>().ToList().FirstOrDefault();
                                    if (lastText.Text.EndsWith("(") && FirstText.Text.StartsWith(")"))
                                    {
                                        if (lastText.Text.EndsWith("("))
                                        {
                                            lastText.Text = lastText.Text.TrimEnd('(') + "[";
                                        }


                                        if (FirstText.Text.StartsWith(")"))
                                        {
                                            FirstText.Text = "]" + FirstText.Text.TrimStart(')');
                                        }
                                    }
                                }
                                else if (r.PreviousSibling() != null && r.NextSibling() != null && r.NextSibling().InnerText.StartsWith("}") && r.PreviousSibling().InnerText.EndsWith("{"))
                                {
                                    var lastText = r.PreviousSibling().Descendants<Text>().ToList().LastOrDefault();
                                    var FirstText = r.NextSibling().Descendants<Text>().ToList().FirstOrDefault();
                                    if (lastText.Text.EndsWith("{") && FirstText.Text.StartsWith("}"))
                                    {
                                        if (lastText.Text.EndsWith("{"))
                                        {
                                            lastText.Text = lastText.Text.TrimEnd('{') + "[";
                                        }


                                        if (FirstText.Text.StartsWith("}"))
                                        {
                                            FirstText.Text = "]" + FirstText.Text.TrimStart('}');
                                        }
                                    }
                                }


                            }
                        }
                    }

                }
                D.Save();
            }
        }
        public static void ChangeFigCalloutForRange(string newDoc)     //Developer Name:Priyanka Vishwakarma, Date:15_10_2019 ,Requirement:Opening and Closing BRACKETs should be UNBOLD in Figure Caption ,Integrated by:Vikas sir.
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                    {
                        foreach (Run r in P.Descendants<Run>().ToList()/*.Any(x => x.LocalName == "b")*/)
                        {
                            if (r.RunProperties != null && r.RunProperties.RunStyle != null && r.RunProperties.RunStyle.Val != null && r.RunProperties.RunStyle.Val.Value == "citefig")
                            {
                                var text = r.Descendants<Text>().ToList();

                                foreach (var t in text.ToList())
                                {
                                    if (System.Text.RegularExpressions.Regex.Match(t.Text.TrimStart(), @"(Fig\.\s[0-9]+[\-|\–|\—][0-9]+)", System.Text.RegularExpressions.RegexOptions.IgnoreCase).Success)
                                    {
                                        t.Text = t.Text.Replace("Fig.", "Figures").Replace("fig.", "Figures");
                                    }
                                }
                            }
                        }
                    }

                }
                D.Save();
            }
        }

        public static void ChangeFigCalloutForRangeForJaypee(string newDoc)     //Developer Name:Priyanka Vishwakarma, Date:15_10_2019 ,Requirement:Opening and Closing BRACKETs should be UNBOLD in Figure Caption ,Integrated by:Vikas sir.
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                    {
                        foreach (Run r in P.Descendants<Run>().ToList()/*.Any(x => x.LocalName == "b")*/)
                        {
                            if (r.RunProperties != null && r.RunProperties.RunStyle != null && r.RunProperties.RunStyle.Val != null && r.RunProperties.RunStyle.Val.Value == "citefig")
                            {
                                var text = r.Descendants<Text>().ToList();
                                foreach (var t in text.ToList())
                                {
                                    if (System.Text.RegularExpressions.Regex.Match(t.Text.TrimStart(), @"(Fig\.\s[0-9]+[\-|\–|\—][0-9]+)", System.Text.RegularExpressions.RegexOptions.IgnoreCase).Success)
                                    {
                                        t.Text = t.Text.Replace("Fig.", "Figs").Replace("fig.", "Figs");
                                    }
                                    if (System.Text.RegularExpressions.Regex.Match(t.Text.TrimStart(), @"(Fig\.\s{1,}[0-9]+[A-Za-z]\sand\s[A-Za-z])|(fig\.\s{1,}[0-9]+[A-Za-z]\sand\s[A-Za-z])", System.Text.RegularExpressions.RegexOptions.IgnoreCase).Success)
                                    {
                                        t.Text = t.Text.Replace("Fig.", "Figs").Replace("fig.", "Figs");
                                    }
                                }
                            }
                        }
                    }

                }
                D.Save();
            }
        }

    }
}
