﻿using DocumentFormat.OpenXml.Packaging;
using OpenXmlPowerTools;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MultiInstanceJournalCleanup
{
    class NormalizeWordDocument
    {
        public static void NormalizeWord(string strFilePath)
        {
            using (WordprocessingDocument wDoc = WordprocessingDocument.Open(strFilePath, true))
            {
                RevisionAccepter.AcceptRevisions(wDoc);
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    NormalizeXml = false,
                    RemoveHyperlinks = false,
                    RemoveComments = false,
                    RemoveContentControls = true,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = false,//Developer name :Priyanka Vishwakarma. Date:29_5_2019, Requirement:it removes the indentation from the nested list  ,Integrated By:Vikas sir. 

                    RemoveEndAndFootNotes = false,
                    RemoveFieldCodes = true,
                    AcceptRevisions = true,
                    //RemoveBookmarks = true,
                    RemoveGoBackBookmark = true,
                    RemoveWebHidden = true,
                    RemoveMarkupForDocumentComparison = true                 
                };

                MarkupSimplifier.SimplifyMarkup(wDoc, settings);

                wDoc.MainDocumentPart.PutXDocument();
            }

            // Convert Special Font characters to Special Characters //


        }

        public static void NormalizeWordSageClient(string strFilePath)
        {
            using (WordprocessingDocument wDoc = WordprocessingDocument.Open(strFilePath, true))
            {
                RevisionAccepter.AcceptRevisions(wDoc);
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    NormalizeXml = false,
                    RemoveHyperlinks = true,
                    RemoveComments = true,//////required for sage client
                    RemoveContentControls = true,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = false,//Developer name :Priyanka Vishwakarma. Date:29_5_2019, Requirement:it removes the indentation from the nested list  ,Integrated By:Vikas sir. 

                    RemoveEndAndFootNotes = false,
                    RemoveFieldCodes = true,
                    AcceptRevisions = true,
                    //RemoveBookmarks = true,
                    RemoveGoBackBookmark = true,
                    RemoveWebHidden = true,
                    RemoveMarkupForDocumentComparison = true
                };

                MarkupSimplifier.SimplifyMarkup(wDoc, settings);

                wDoc.MainDocumentPart.PutXDocument();
            }

            // Convert Special Font characters to Special Characters //


        }

    }
}
