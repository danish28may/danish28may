﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace MultiInstanceJournalCleanup
{
    class Program
    {
        static void Main(string[] args)
        {
            //string filepath = @"D:\3CMAutomation\JournalCleanupMarkup\Process\50868";

            string filepath = args[0];
            
            try
            {
            Start(filepath);
            }
            catch (Exception ex)
            {
                string folderpath = filepath.Substring(filepath.LastIndexOf("\\"));

                //folderpath = folderpath.Substring(folderpath.LastIndexOf("\\"));

                string strErrorFileName = null;
                string strProcessFolder = null;

                if (GlobalMethods.StrOutFolder != null || GlobalMethods.StrOutFolder != "")
                {
                    strErrorFileName = GlobalMethods.StrOutFolder;
                    if (folderpath.StartsWith("\\"))
                        strErrorFileName = strErrorFileName + folderpath;
                    else
                        strErrorFileName = strErrorFileName + "\\" + folderpath;

                    if (Directory.Exists(strErrorFileName) == false)
                        Directory.CreateDirectory(strErrorFileName);

                    if (strErrorFileName.EndsWith("\\") == false)
                        strErrorFileName = strErrorFileName + "\\";

                    strErrorFileName = strErrorFileName + "Error.log";

                    // Generate Error log and the move the error log in the out folder
                    StreamWriter sw = new StreamWriter(strErrorFileName);
                    sw.WriteLine(ex.ToString());
                    sw.WriteLine("Journals CleanupMarkup");
                    sw.WriteLine("Exception in Processing the document. Please consult 3CM Administrator.");
                    sw.Close();

                    Directory.Delete(GlobalMethods.StrProcessFolder + folderpath, true);
                }

                strProcessFolder = GlobalMethods.StrProcessFolder;

                if (folderpath.StartsWith("\\"))
                    strProcessFolder = strProcessFolder + folderpath;
                else
                    strProcessFolder = strProcessFolder + "\\" + folderpath;
                if (Directory.Exists(strProcessFolder))
                    Directory.Delete(strProcessFolder, true);
            }
        }

        public static void Start(string strDocumentName)
        {

            object OutputFilename = null;

            FileInfo ff = null;

            GlobalMethods.strJobTransId = null;
            GlobalMethods.strDocumentType = null;
            GlobalMethods.strServiceType = null;

            DirectoryInfo Dir = new DirectoryInfo(strDocumentName);

            FileInfo[] filesForProcess = Dir.GetFiles();
            string strSourceFileName = null;
            foreach (var files in filesForProcess)
            {
                if (files.Extension == ".xml")
                {
                    /// read XML file for document custom properties
                    GlobalMethods.ReadCustomPropertiesXML(files.FullName);
                }
                if (files.Extension == ".docx")
                {
                    if (!files.Name.StartsWith("~$"))
                    {
                        ff = files;
                    }
                }
            }

            if (ff == null)
            {
                Console.WriteLine("Job name: " + ff.Name + " ," + "Job ID: " + ff.Directory.Name + " ," + "Processing start time:" + DateTime.Now.ToString("dd-MM-yyyy hh:mm:ss"));

                string strErrorFileName = null;

                if (GlobalMethods.StrOutFolder != null && GlobalMethods.StrOutFolder != "")
                {
                    strErrorFileName = GlobalMethods.StrOutFolder + "\\" + Dir.Name;

                    if (Directory.Exists(strErrorFileName) == false)
                        Directory.CreateDirectory(strErrorFileName);

                    if (strErrorFileName.EndsWith("\\") == false)
                        strErrorFileName = strErrorFileName + "\\";

                    strErrorFileName = strErrorFileName + "Error.log";

                    // Generate Error log and the move the error log in the out folder
                    StreamWriter sw = new StreamWriter(strErrorFileName);
                    sw.WriteLine("Document not found in Journals CleanupMarkup Input folder. Please consult 3CM Administrator.");
                    sw.Close();
                }

                // Remove the document from Process folder

                goto EndProcess;
            }

            if (GlobalMethods.strJobTransId == null || GlobalMethods.strJobTransId == "")
            {
                string strErrorFileName = null;

                if (GlobalMethods.StrOutFolder != null && GlobalMethods.StrOutFolder != "")
                {
                    strErrorFileName = GlobalMethods.StrOutFolder + "\\" + ff.Directory.Name;

                    if (Directory.Exists(strErrorFileName) == false)
                        Directory.CreateDirectory(strErrorFileName);

                    if (strErrorFileName.EndsWith("\\") == false)
                        strErrorFileName = strErrorFileName + "\\";

                    // Generate Error log and the move the error log in the out folder
                    StreamWriter sw = new StreamWriter(strErrorFileName);
                    sw.WriteLine("Journals CleanupMarkup");
                    sw.WriteLine("Either the Job Transaction ID is missing in the document properties or is empty. Please consult 3CM Administrator.");
                    sw.Close();
                }

                // Remove the document from Process folder

                goto EndProcess;
            }

            if (GlobalMethods.strDocumentType == null || GlobalMethods.strDocumentType == "")
            {
                string strErrorFileName = null;

                if (GlobalMethods.StrOutFolder != null && GlobalMethods.StrOutFolder != "")
                {
                    strErrorFileName = GlobalMethods.StrOutFolder + "\\" + GlobalMethods.strJobTransId;

                    if (Directory.Exists(strErrorFileName) == false)
                        Directory.CreateDirectory(strErrorFileName);

                    if (strErrorFileName.EndsWith("\\") == false)
                        strErrorFileName = strErrorFileName + "\\";

                    // Generate Error log and the move the error log in the out folder
                    StreamWriter sw = new StreamWriter(strErrorFileName);
                    sw.WriteLine("Journals CleanupMarkup");
                    sw.WriteLine("Either the DocumentType is missing in the document properties or is empty. Please consult 3CM Administrator.");
                    sw.Close();
                }

                // Remove the document from Process folder

                goto EndProcess;
            }

            if (GlobalMethods.strServiceType == null || GlobalMethods.strServiceType == "")
            {
                string strErrorFileName = null;

                if (GlobalMethods.StrOutFolder != null && GlobalMethods.StrOutFolder != "")
                {
                    strErrorFileName = GlobalMethods.StrOutFolder + "\\" + GlobalMethods.strJobTransId;

                    if (Directory.Exists(strErrorFileName) == false)
                        Directory.CreateDirectory(strErrorFileName);

                    if (strErrorFileName.EndsWith("\\") == false)
                        strErrorFileName = strErrorFileName + "\\";

                    // Generate Error log and the move the error log in the out folder
                    StreamWriter sw = new StreamWriter(strErrorFileName);
                    sw.WriteLine("Journals CleanupMarkup");
                    sw.WriteLine("Either the ServiceType is missing in the document properties or is empty. Please consult 3CM Administrator.");
                    sw.Close();
                }

                // Remove the document from Process folder

                goto EndProcess;
            }

            strSourceFileName = ff.FullName.Replace(ff.Extension, "");

            strSourceFileName = strSourceFileName + "_Source" + ff.Extension;

            File.Copy(ff.FullName, strSourceFileName, true);
            GlobalMethods.ArticlePath = "";
            //GlobalMethods.DOI = "";
            //GlobalMethods.ISBN = "";
            //GlobalMethods.eISBN = "";
            //GlobalMethods.VolumeTitle = "";
            //GlobalMethods.SeriesTitle = "";
            //GlobalMethods.JournalSubTitle = "";
            //GlobalMethods.CopyrightNote = "";
            //GlobalMethods.CopyrightYear = "";
            //GlobalMethods.Publisher = "";
            //GlobalMethods.ArticleTitle = "";
            GlobalMethods.strCleanup = "";
            GlobalMethods.ArticleImagePath = "";

            GlobalMethods.ArticleId = "";
            GlobalMethods.ManuscriptId = "";
            GlobalMethods.ManuscriptNumber = "";
            GlobalMethods.VolumeNo = "";
            GlobalMethods.IssueNo = "";
            GlobalMethods.FirstPage = "";
            GlobalMethods.LastPage = "";
            GlobalMethods.OpenAccess = "";
            GlobalMethods.EduProg = "";
            GlobalMethods.ArticleType = "";
            GlobalMethods.TransactionID = "";
            GlobalMethods.ArticleLanguage = "";
            GlobalMethods.strStyleMappingConfig = "";

            // Extract Document Properties and Store in Variable //

            //GlobalMethods.DOI = CustomProperties.WDGetCustomProperty(ff.FullName, "DOI");
            //GlobalMethods.ISBN = CustomProperties.WDGetCustomProperty(ff.FullName, "ISBN");
            //GlobalMethods.eISBN = CustomProperties.WDGetCustomProperty(ff.FullName, "EISBN");
            //GlobalMethods.VolumeTitle = CustomProperties.WDGetCustomProperty(ff.FullName, "Volume Title");
            //GlobalMethods.SeriesTitle = CustomProperties.WDGetCustomProperty(ff.FullName, "Series Title");
            //GlobalMethods.JournalTitle = CustomProperties.WDGetCustomProperty(ff.FullName, "Journal Title");
            //GlobalMethods.JournalSubTitle = CustomProperties.WDGetCustomProperty(ff.FullName, "Journal Sub Title");
            //GlobalMethods.CopyrightNote = CustomProperties.WDGetCustomProperty(ff.FullName, "Copyright Note");
            //GlobalMethods.CopyrightYear = CustomProperties.WDGetCustomProperty(ff.FullName, "Copyright Year");
            //GlobalMethods.Publisher = CustomProperties.WDGetCustomProperty(ff.FullName, "Publisher");
            //GlobalMethods.ArticleTitle = CustomProperties.WDGetCustomProperty(ff.FullName, "ArticleTitle");
            //GlobalMethods.ArticleNumber = CustomProperties.WDGetCustomProperty(ff.FullName, "ArticleNumber");


            GlobalMethods.strCleanup = CustomProperties.WDGetCustomProperty(ff.FullName, "Cleanup");
            GlobalMethods.ArticlePath = CustomProperties.WDGetCustomProperty(ff.FullName, "ArticlePath");

            //new

            GlobalMethods.ArticleId = CustomProperties.WDGetCustomProperty(ff.FullName, "ArticleId");
            GlobalMethods.ManuscriptId = CustomProperties.WDGetCustomProperty(ff.FullName, "ManuscriptId");
            GlobalMethods.ManuscriptNumber = CustomProperties.WDGetCustomProperty(ff.FullName, "ManuscriptNumber");
            GlobalMethods.VolumeNo = CustomProperties.WDGetCustomProperty(ff.FullName, "VolumeNo");
            GlobalMethods.IssueNo = CustomProperties.WDGetCustomProperty(ff.FullName, "IssueNo");
            GlobalMethods.FirstPage = CustomProperties.WDGetCustomProperty(ff.FullName, "FirstPage");
            GlobalMethods.LastPage = CustomProperties.WDGetCustomProperty(ff.FullName, "LastPage");
            GlobalMethods.OpenAccess = CustomProperties.WDGetCustomProperty(ff.FullName, "OpenAccess");
            GlobalMethods.EduProg = CustomProperties.WDGetCustomProperty(ff.FullName, "EduProg");
            GlobalMethods.ArticleType = CustomProperties.WDGetCustomProperty(ff.FullName, "ArticleType");
            GlobalMethods.TransactionID = CustomProperties.WDGetCustomProperty(ff.FullName, "TransactionID");
            GlobalMethods.ArticleLanguage = CustomProperties.WDGetCustomProperty(ff.FullName, "ArticleLanguage");

            GlobalMethods.strStyleMappingConfig = ConfigurationManager.AppSettings.Get("3CMStyleMappingConfig");
            GlobalMethods.str3CMWordTemplate = ConfigurationManager.AppSettings.Get("3CMWordTemplate");
            GlobalMethods.StrInFolder = ConfigurationManager.AppSettings.Get("CleanupMarkupIN");
            GlobalMethods.StrOutFolder = ConfigurationManager.AppSettings.Get("CleanupMarkupOUT");
            GlobalMethods.StrProcessFolder = ConfigurationManager.AppSettings.Get("CleanupMarkupPROCESS");

            if (GlobalMethods.strCleanup != null)
            {
                if (GlobalMethods.strCleanup != "")
                {
                    if (GlobalMethods.strCleanup.ToLower() == "yes")
                    {
                        GlobalMethods.bCleanupRequired = true;
                    }
                    else
                    {
                        GlobalMethods.bCleanupRequired = false;
                    }
                }
                else
                {
                    GlobalMethods.bCleanupRequired = true;

                }
            }
            else
            {
                GlobalMethods.bCleanupRequired = true;
            }

            if (GlobalMethods.ArticlePath != null)
            {
                if (GlobalMethods.ArticlePath != "")
                {
                    DirectoryInfo dd = new DirectoryInfo(GlobalMethods.ArticlePath);
                    GlobalMethods.ArticleImagePath = dd.Parent.FullName;

                    if (GlobalMethods.ArticleImagePath.EndsWith("\\"))
                        GlobalMethods.ArticleImagePath = GlobalMethods.ArticleImagePath + "Images";
                    else
                        GlobalMethods.ArticleImagePath = GlobalMethods.ArticleImagePath + "\\Images";
                }
            }

            if (GlobalMethods.strJournalArticlePath.ToLower().Contains(@"\journal\ilo\"))/////Specific to ILO journal only
            {
                AutoStructuringStyles.RemoveBlankUnwantedPara(ff.FullName);   // Added on 18-07-2020 by vikas for ILO Journal structuring
                AutoStructuringStyles.AppltParaTIandAUstyle(ff.FullName);
                MapStylesWithWordTemplate.List_Style(ff.FullName);  //added on 29_3_2019 by priyanka for apply List Style
                AutoStructuringStyles.ApplyHeadingLevlestyle(ff.FullName);
                AutoStructuringStyles.ApplyTextBasedstyle(ff.FullName);
                AutoStructuringStyles.AuthorMarking(ff.FullName);
            }


            if (GlobalMethods.bCleanupRequired == true)
            {
                AutoStructuringStyles.RemoveBlankPara(ff.FullName);   // Added on 31-01-2020 by priyanka
                AutoStructuringStyles.RemoveBlankParaWithStyle(ff.FullName);//Developer Name:Priyanka Vishwakarma, Date: 27-11-2021, remove blank para which has paragraph style other than boxstast ,boxend, list start,listend
                if (GlobalMethods.strCopyEditingRequired != null && GlobalMethods.strCopyEditingRequired.ToLower() == "true")                
                    MapStylesWithWordTemplate.ReplaceplaceholdersForPunctuations(ff.FullName);//Developer Name:Priyanka Vishwakarma, Date: 11-12-2021, remove space before . , ; : ?                 
                AutoStructuringStyles.GetCommentsBeforeDocument(ff.FullName);//Developer Name:Priyanka Vishwakarma, Date:31_12_2019 ,Requirement:Add all comments in list before cleanup completed,Integrated by:Vikas sir. 
                if (GlobalMethods.strClientName.ToLower() == "ufl")
                {
                    MapStylesWithWordTemplate.FloridaArticleMappinngBasedonText(ff.FullName);////Added by vikas on 13-08-2020 for florida articles
                    MapStylesWithWordTemplate.ApplyBoxStartandBoxEndToAppendixPara(ff.FullName);//Developer Name:Priyanka Vishwakarma, Date:17-02-2021 ,Requirement:Apply BoxStart and BoxEnd for Appendix data.
                }
                if (GlobalMethods.strClientName.ToLower() == "informs")
                {
                    MapStylesWithWordTemplate.InformsArticleMappinngBasedonText(ff.FullName);////Added by vikas on 10-09-2020 for informs client structuring 
                }
                if (GlobalMethods.strClientName.ToLower() == "sage")
                {   //05-05-2023 - Styling
                    //if (GlobalMethods.strCopyediting == "false" && GlobalMethods.strJournalArticlePath.Contains("\\India\\"))   
                    if (GlobalMethods.strCopyediting == "false")
                    {
                        AutoStructuringStyles.RemoveBlankUnwantedPara(ff.FullName);   // 31-05-2021
                        MapStylesWithWordTemplate.SageIndiaEnglishArticleMappinngBasedonText(ff.FullName);//Developer Name:Priyanka Vishwakarma,Date:20-03-2021,Requirement:Apply paragraph style based on ta for sage India input for copyedited doc
                        
                    }
                    else
                    {
                        if (GlobalMethods.strCopyEditingRequired != null && GlobalMethods.strCopyEditingRequired.ToLower() == "true")
                            MapStylesWithWordTemplate.NspacetoNormalspace(ff.FullName);///added by vikas on 30-10-2020
                        MapStylesWithWordTemplate.ExecuteStyleMapping(ff.FullName, GlobalMethods.strStyleMappingConfig);
                        AutoStructuringStyles.H1StyleApplySage(ff.FullName, GlobalMethods.H1Style); //Developer Name:Priyanka Vishwakarma, Date:01-10-2021, Requirement: add condition for apply h1 heading style 
                        AutoStructuringStyles.Dt_StyleAppliedSage(ff.FullName); ////Developer Name:Priyanka Vishwakarma, Date:01-10-2021, Requirement: add condition for apply DT style
                        if (ff.FullName.Contains("_J_"))
                        MapStylesWithWordTemplate.SageArticleMappinngBasedonText(ff.FullName);////Added by vikas on 10-10-2020 for Sage client structuring for non-structured
                        if (GlobalMethods.strCopyEditingRequired != null && GlobalMethods.strCopyEditingRequired.ToLower() == "true")
                            MapStylesWithWordTemplate.SageboldItalicParagraphMarkRemove(ff.FullName);////Added by vikas on 10-10-2020 for Sage client boldItalic paragraphmarking remove
                    }
                }
                if (GlobalMethods.strClientName.ToLower()=="csiro")
                {
                    MapStylesWithWordTemplate.CSIROArticleMappinngBasedonText(ff.FullName);
                }
                if (GlobalMethods.strClientName.ToLower() == "sage" && GlobalMethods.strCopyediting == "true" && !GlobalMethods.strJournalArticlePath.Contains("\\India\\"))//Developer Name:Priyanka Vishwakarma Date:31-05-2021,Requiremnt :Add condition for avoid to apply paragraph style to structured document.
                {
                    AutoStructuringStyles.H1StyleApply(ff.FullName, GlobalMethods.H1Style);
                }
                if (GlobalMethods.strClientName.ToLower() == "jaypee"|| GlobalMethods.strClientName.ToLower() == "ssllc")
                {
                    MapStylesWithWordTemplate.ExecuteStyleMapping(ff.FullName, GlobalMethods.strStyleMappingConfig);
                    AutoStructuringStyles.H1StyleApply(ff.FullName, GlobalMethods.H1Style); //Developer Name:Priyanka Vishwakarma, Date:01-10-2021, Requirement: add condition for apply h1 heading style 
                    AutoStructuringStyles.Dt_StyleApplied(ff.FullName); ////Developer Name:Priyanka Vishwakarma, Date:01-10-2021, Requirement: add condition for apply DT style
                    MapStylesWithWordTemplate.JaypeeArticleMappinngBasedonText(ff.FullName);//Developer Name:Priyanka Vishwakarma,Date:22-06-2021,Requirement:Apply paragraph style based on Text for jaypee client.
                    MapStylesWithWordTemplate.ApplyABTXTParagraphStyle(ff.FullName);
                }
                if(GlobalMethods.strClientName.ToLower()=="pps")
                {
                    MapStylesWithWordTemplate.ExecuteStyleMapping(ff.FullName, GlobalMethods.strStyleMappingConfig);
                   // MapStylesWithWordTemplate.PPSArticleMappinngBasedonText(ff.FullName);                   
                    AutoStructuringStyles.Dt_StyleApplied(ff.FullName); ////Developer Name:Priyanka Vishwakarma, Date:01-10-2021, Requirement: add condition for apply DT style
                    MapStylesWithWordTemplate.PPSArticleMappinngBasedonText(ff.FullName);//Developer Name:Priyanka Vishwakarma,Date:22-06-2021,Requirement:Apply paragraph style based on Text for jaypee client.
                    AutoStructuringStyles.H1StyleApply(ff.FullName, GlobalMethods.H1Style); //Developer Name:Priyanka Vishwakarma, Date:01-10-2021, Requirement: add condition for apply h1 heading style 
                    MapStylesWithWordTemplate.ApplyABTXTParagraphStyle(ff.FullName);
                }
                MapStylesWithWordTemplate.StyleMapping(ff.FullName, GlobalMethods.strStyleMappingConfig);
                if (GlobalMethods.strRefNum != null && GlobalMethods.strRefNum == "Numbered") //Developer Name:Priyanka Vishwakarma, Date:31-3-2022, Merge ref1 para only for numbered references.
                {
                    if (GlobalMethods.strCopyEditingRequired != null && GlobalMethods.strCopyEditingRequired.ToLower() == "true")
                        MapStylesWithWordTemplate.mergeRef1Para(ff.FullName);
                }
                if (GlobalMethods.strClientName.ToLower() != "sage" && GlobalMethods.strClientName.ToLower() != "jaypee" && GlobalMethods.strClientName.ToLower() != "pps")
                {
                    if (GlobalMethods.strCopyEditingRequired != null && GlobalMethods.strCopyEditingRequired.ToLower() == "true")
                        AutoStructuringStyles.funding_paraStyle(ff.FullName);   //Developer name :Priyanka Vishwakarma .Date:27_09_2019 ,Requirement:Funding Paragraph apply H5 paragraph style in word document ,Integrated by:Vikas sir.
                }
                    AutoStructuringStyles.Master_Style_Mapping(ff.FullName, GlobalMethods.AutoStructringstyles);

                if (GlobalMethods.strClientName.ToLower() == "sage")
                {
                    if (GlobalMethods.strCopyEditingRequired != null && GlobalMethods.strCopyEditingRequired.ToLower() == "true")
                        AutoStructuringStyles.RemoveAbbriviationFormAffl(ff.FullName); 
                }
                if (GlobalMethods.strClientName.ToLower() == "jaypee" || GlobalMethods.strClientName.ToLower() == "ssllc")//Developer Name:Priyanka Vishwakarma,Date: 9-3-2022, Requirement:author name sholud be italic  and id should be Author name along with https://orcid.org/xxxx-xxxx-xxxx-xxxx
                {
                    if (GlobalMethods.strCopyEditingRequired != null && GlobalMethods.strCopyEditingRequired.ToLower() == "true")
                        AutoStructuringStyles.FormatorcidPara(ff.FullName);
                }
                AutoStructuringStyles.orcidStyle(ff.FullName);  //Developer Name:Priyanka Vishwakarma, Date:19_12_2019 ,Requirement:Add Orcid Footnote in xml file ,Integrated by:Vikas sir.
                AutoStructuringStyles.ApplyEQParaStyle(ff.FullName);  //Developer name:priyanka Vishwakarma ,Date:29_08_2019 ,Requirement:Apply EQ paragraph Style for Display equation  .Integrated By:vikas sir.
                AutoStructuringStyles.ChangeAUpretoAU(ff.FullName);  //Developer name:priyanka Vishwakarma ,Date:27_08_2019 ,Requirement:Change Au-pre paragraph style to AU .Integrated By:vikas sir.
                AutoStructuringStyles.ConvertNLandBLParaStyle(ff.FullName); //Developer Name:Priyanka Vishwakarma, Date:03-09-2020 ,Requirement:Convert nl Para to Numlist and BL para to bulllist.
                if (GlobalMethods.strClientName.ToLower() == "informs"/*|| GlobalMethods.strClientName.ToLower() == "jaypee"*/)////Added by vikas on 08-09-2020 for informs client
                {
                    if (GlobalMethods.strCopyEditingRequired != null && GlobalMethods.strCopyEditingRequired.ToLower() == "true")
                        AutoStructuringStyles.ApplyheadingStyletoNumberedPara(ff.FullName);
                }
                MapStylesWithWordTemplate.List_Style(ff.FullName);  //added on 29_3_2019 by priyanka for apply List Style
                if (GlobalMethods.strCopyEditingRequired != null && GlobalMethods.strCopyEditingRequired.ToLower() == "true")
                {
                    MapStylesWithWordTemplate.KeywordandAbstractparaRemoveList(ff.FullName);//Developer name:Priyanka Vishwakarma ,Date:21-02-2020 ,Requirement:Not Apply listing style within Abstract paragraph. integrated by:Vikas sir.

                    AutoStructuringStyles.removeListingfromParagraph(ff.FullName);  //Developer name : Priyanka Vishwakarma ,Date:22-02-2020 ,Requirement:remove listing when paragraph has only listing number (Live Job 4474_THI_J_NJCA-19-0068) ,Integrated by:Vikas sir.

                    MapStylesWithWordTemplate.addVeralignForAstricInAUPara(ff.FullName); //--- Developer name:Priyanka Vishwakarma , Date: 11-01-2020 ,Requirement:Add * as Superscript in Word when it does not come as Superscript only with in AU Paragraph ,Integrated by:Vikas sir.
                }
                if (!GlobalMethods.strJournalArticlePath.ToLower().Contains(@"\journal\ilo\"))/////not required to ILO journal only codition added by vikas on 18-07-2020
                {
                    AutoStructuringStyles.ApplyFootnoteParaStyle(ff.FullName);  //Developer name:priyanka Vishwakarma ,Date:11-01-2020 ,Requirement:Apply footnote paragraph style when paragraph has FTN paragraph style and text should be start with * . .Integrated By:vikas sir.
                }
                AutoStructuringStyles.CheckAppendixTable(ff.FullName); // //Developer Name:Priyanka Vishwakarma ,Date:03-06-2020 Requirement:Handle Appendix Table without heading H1.

                AutoStructuringStyles.orcidParaApplyBodyAStyle(ff.FullName);  //Developer name:priyanka Vishwakarma ,Date:13_09_2019 ,Requirement:Apply BodyA paragraph style to orcid footnot for handling author query missing. .Integrated By:vikas sir.
                //Jitender 10122022
               // GlobalMethods.FormatChange();
                if (GlobalMethods.strClientName == "sage")
                {
                    NormalizeWordDocument.NormalizeWordSageClient(ff.FullName);
                }
                else
                {
                    // Normalize the Word document
                    NormalizeWordDocument.NormalizeWord(ff.FullName);
                }

                ///commented by Karan as per requirment on 19-06-2018
                ///MapStylesWithWordTemplate.RRHParagraphDelete(ff.FullName);

                // Export Comments to an external text file and insert bookmark in place of comment
                //ConvertComments.ProcessComments(ff.FullName);

                //ConvertComments.exportCommentsAndRemoveFromDocument(ff.FullName);

                // Entity Conversion //
                if (GlobalMethods.strCopyEditingRequired != null && GlobalMethods.strCopyEditingRequired.ToLower() == "true")
                    EntityConversion.ConvertEntities(ff.FullName);

                //// Remove Character filename to be extracted from Configuration
                string strRemoveCharStyleFilename = ConfigurationManager.AppSettings.Get("RemoveCharStyleFile");

                //// Clean Word Document and save
                FilterWordDocument.CleanWordDocument(ff.FullName, strRemoveCharStyleFilename);

               
                //// Start Word Markup //
                MapStylesWithWordTemplate.StyleMapping(ff.FullName, GlobalMethods.strStyleMappingConfig);

                //if (GlobalMethods.strRefNum != null && GlobalMethods.strRefNum == "UnNumbered")
                //{
                //    References.SearchAndReplaceAuthors(ff.FullName);
                //}//////commented by vikas on 15-07-2020
                //new Function added by Karan on 06-09-2018 Start
                if (GlobalMethods.strCopyEditingRequired != null && GlobalMethods.strCopyEditingRequired.ToLower() == "true")
                    SearchAndReplace.SearchAndReplaceNonBreakingSpace(ff.FullName);
                //new Function added by Karan on 06-09-2018 end.

                MapStylesWithWordTemplate.ApplyTCHStyleInTable(ff.FullName);    //Developer Name:Priyanka Vishwakarma , Date:27_9_2019 , Requirement:Apply TCH Paragraph style to bold text within Table. ,Integrated By:Vikas sir.

                ///New Function added by Karan on 20-6-2018 for indentlevel
                MapStylesWithWordTemplate.NewApplyTableStyles(ff.FullName);
                //MapStylesWithWordTemplate.ApplyTCH_CenterTableStyles(ff.FullName);  //Developer Name:Priyanka Vishwakarma , Date:30_5_2019 , Requirement:Apply TCHCenter style within table which table head having center alignment ,Integrated By:Vikas sir.

                // Abstract para break Abstract Para if required // 
                AbstractProcessing.BreakAbstractOnKeyword(ff.FullName);

                // Check for Missing Heading styles in the document and apply
                if (GlobalMethods.strCopyEditingRequired != null && GlobalMethods.strCopyEditingRequired.ToLower() == "true")
                    MissingSections.CheckForMissingSections(ff.FullName);

                //// Move Footnotes within main document
                //ArrangeFootNotes.Footnotes(ff.FullName);
                ArrangeFootNotes.Footnotesnew(ff.FullName);
                ////AuthorAffiliation marking
                AuthorAffiliation.AuthorAffiliationMarking(ff.FullName);


                // Perform CopyEditing // 
                if (GlobalMethods.strClientName.ToLower() != "ufl" && GlobalMethods.strClientName != "International Labour Organization")
                {
                    ///Lablestrong style applied using supporting folder txt.
                    MapStylesWithWordTemplate.CheckAllPara(ff.FullName);
                    if (GlobalMethods.strCopyEditingRequired != null && GlobalMethods.strCopyEditingRequired.ToLower() == "true")
                        CopyEditing.PerformCopyEditing(ff.FullName);
                    
                }
                if (GlobalMethods.strClientName.ToLower() != "informs" && GlobalMethods.strClientName.ToLower() != "sage" && GlobalMethods.strClientName.ToLower() != "jaypee" && GlobalMethods.strClientName.ToLower() != "ssllc")
                {
                    if (GlobalMethods.strCopyEditingRequired != null && GlobalMethods.strCopyEditingRequired.ToLower() == "true")
                        AutoStructuringStyles.addDummyInSuperscript(ff.FullName);  //Developer name:Priyanka Vishwakarma ,Date:06-04-20202 ;Requirement:  Add Dummy <sup> infront of citebib number for avoid to convert superscript to normal text when Fig citation apply. Integrated by:Vikas sir.
                }
                clsLinking.funcLinking(ff.FullName);

                /////  MapStylesWithWordTemplate.mergeCitefigStyle(ff.FullName);   ////Developer Name:Priyanka Vishwakarma/Aarti gupta , Date:23_7_2019 , Requirement:Merge the text of citefig  character style ,Integrated By:Vikas sir.


                ////below function commented by Karan because developing is pending for some pattern discuss with sir.
                ////SearchAndReplace.SearchAndReplacecitation(ff.FullName);               
                SearchAndReplace.GeneralSearchAndReplace(ff.FullName);
               
                if (GlobalMethods.strClientName.ToLower() == "informs")////Added by vikas on 08-09-2020 for informs client
                {
                    AutoStructuringStyles.ApplyciteEq(ff.FullName);
                }
                // add full path of .docx file
                // ID Generation and Crosslinking ///
                if (GlobalMethods.strClientName.ToLower() != "informs" && GlobalMethods.strClientName.ToLower() != "sage")  //Developer Name:PRiyanka Vishwakarma ,Date:10-09-2020,Requirement:avoid to add <sup> for informs 
                {
                    if (GlobalMethods.strCopyEditingRequired != null && GlobalMethods.strCopyEditingRequired.ToLower() == "true")
                        AutoStructuringStyles.removeDummyInSuperscript(ff.FullName);  //Developer name:Priyanka Vishwakarma ,Date:06-04-20202 ;Requirement:  Remove Dummy <sup> infront of citebib number for avoid to convert superscript to normal text when Fig citation apply. Integrated by:Vikas sir.
                }
                ///two function added by Karan on 20-06-2018 for enspace Start.

                    if (ff.FullName.Contains("_J_"))
                        MapStylesWithWordTemplate.FigAndTextBetweenEmSpace(ff.FullName);
                    if (GlobalMethods.strClientName != "International Labour Organization")
                    {
                        MapStylesWithWordTemplate.TableAndTextBetweenEmSpace(ff.FullName);
                    }                 
                BookMarks.RemoveHiddenBookMark(ff.FullName);

                ///New Function added by Karan on 08-06-2018 
                if (GlobalMethods.strCopyEditingRequired != null && GlobalMethods.strCopyEditingRequired.ToLower() == "true")
                MapStylesWithWordTemplate.Copyrights(ff.FullName);

                if (GlobalMethods.strCopyEditingRequired != null && GlobalMethods.strCopyEditingRequired.ToLower() == "true")
                    AutoStructuringStyles.figcApplyBoldStyle(ff.FullName);  //Developer Name:Priyanka Vishwakarma , Date:17_4_2019 , Requirement:In Caption Fig. 2 should come under <b> tag</b> for bolded text ,Integrated By:Vikas sir.
                if (GlobalMethods.strClientName.ToLower() == "sage" && GlobalMethods.strJournalArticlePath.Contains("\\India\\"))//Developer Name:Priyanka Vishwakarma,Date:29-06-2021,Requirement:Add condition for sage india client TCHCenter and T-TXTCenter atyle not apply in table.
                {
                    MapStylesWithWordTemplate.CheckRowInTable(ff.FullName);//Developer Name:Priyanka Vishwakarma,Date:29-06-2021,Requirement:Add function for apply T-TXT to bold text in table from second row
                    MapStylesWithWordTemplate.ApplyTXTToTCHWithinTableForSageIndia(ff.FullName);//Developer Name:Priyanka Vishwakarma,Date:29-06-2021,Requirement:Add function for apply T-TXT to bold text in table from second row
                    MapStylesWithWordTemplate.CheckAllTableCell(ff.FullName);
                    MapStylesWithWordTemplate.ApplyHeadingTwoForbackMatterHeading(ff.FullName);


                }
                else
                {
                    if(GlobalMethods.strClientName.ToLower()=="ufl" || GlobalMethods.strClientName.ToLower() == "jaypee" || GlobalMethods.strClientName.ToLower() == "ssllc")//Developer Name:Priyanka Vishwakarma,Date:29-09-2021,Requirement:Add function for apply T-TXT to bold text in table from second row for jaypee
                    {
                        MapStylesWithWordTemplate.CheckRowInTable(ff.FullName);//Developer Name:Priyanka Vishwakarma,Date:29-06-2021,Requirement:Add function for apply T-TXT to bold text in table from second row
                        MapStylesWithWordTemplate.ApplyTXTToTCHWithinTableForSageIndia(ff.FullName);//Developer Name:Priyanka Vishwakarma,Date:29-06-2021,Requirement:Add function for apply T-TXT to bold text in table from second row
                        MapStylesWithWordTemplate.CheckAllTableCell(ff.FullName);
                    }
                    MapStylesWithWordTemplate.ApplyTXTToTCHWithinTable(ff.FullName); //Developer Name:Priyanka Vishwakarma ,Date:29_6_2019 ,Requirement :Multiple Multiple TCH Handle (doc: ASJO-19-00012.docx)
                }
                AutoStructuringStyles.removeBlankHead(ff.FullName);  ////Developer Name:Priyanka Vishwakarma ,Date:07_09_2019 ,Requirement :Remove blank heading from word. ,Integrated by:Vikas sir
                AutoStructuringStyles.AddTTStyleforWithoutCalloutTable(ff.FullName); ////Developer Name:Priyanka Vishwakarma ,Date:11_09_2019 ,Requirement :Apply TT paragraph style to blank paragraph or add new paragraph if Callout missing for table in word document (2884_THI_J_IJNS-19-00035-OA.docx). ,Integrated by:Vikas sir

                
                if (GlobalMethods.strClientName.ToLower() != "sage"  && !GlobalMethods.strJournalArticlePath.Contains("\\India\\"))//Developer Name:Priyanka Vishwakarma,Date:29-06-2021,Requirement:Add condition for sage india client TCHCenter and T-TXTCenter atyle not apply in table.
                {
                    MapStylesWithWordTemplate.ApplyCenterAlignForColspan(ff.FullName);//Developer Name :Priyanka Vishwakarma ,Date:01_11_2019 ,Requirement:Apply Center Alignment if colspan present in Table data. Integrated By:Vikas sir.
                }
                AutoStructuringStyles.ChangeReferenceToREFStyle(ff.FullName);
                if (GlobalMethods.strCopyEditingRequired != null && GlobalMethods.strCopyEditingRequired.ToLower() == "true")
                    AutoStructuringStyles.removeChangeBoldBraketsInFigureCaption(ff.FullName);  //Developer Name:Priyanka Vishwakarma, Date:15_10_2019 ,Requirement:Opening and Closing BRACKETs should be UNBOLD in Figure Caption ,Integrated by:Vikas sir.
                AutoStructuringStyles.NormalParaConverttoBodyA(ff.FullName);    //Developer Name:Priyanka Vishwakarma, Date:04_11_2019 ,Requirement:apply BodyA paragraph style to normal paragraph . ,Integrated by:Vikas sir.
                AutoStructuringStyles.removeComment(ff.FullName);  //Developer Name:Priyanka Vishwakarma, Date:17_12_2019 ,Requirement:Remove CommentRangeStart and commentRangeEnd if text is not selected for comment in word document.(3565_THI_J_Test3586-09-002019) ,Integrated by:Vikas sir.

                AutoStructuringStyles.GetCommentsAfterDocument(ff.FullName); //Developer Name:Priyanka Vishwakarma, Date:31_12_2019 ,Requirement:Add all comments in list after cleanup completed,Integrated by:Vikas sir.                              
                AutoStructuringStyles.checkMissingComment(ff.FullName, GlobalMethods.beforecmt, GlobalMethods.Aftercmt);//Developer Name:Priyanka Vishwakarma, Date:31_12_2019 ,Requirement:Add comment in word document if any query is missing after cleanup process. ,Integrated by:Vikas sir.


                //Developer name:Priyanka Vishwakarma ,Date:08-02-2020 ,Requirement:Add Supplementory video citation.,Integrated by:Vikas sir.
                AutoStructuringStyles.applySupplementoryVideoStyle(ff.FullName);
                AutoStructuringStyles.applySupplementoryVideoTxtStyle(ff.FullName);

                if (GlobalMethods.strJournalArticlePath.ToLower().Contains(@"\journal\ilo\"))/////Specific to ILO journal only
                {
                    AutoStructuringStyles.AppendixParaContainsList(ff.FullName);  //Developer name:Priyanka Vishwakarma ,Date:20072020 ,Requirement listing required in appendix section

                }
                else
                {
                    AutoStructuringStyles.AppendixParaStyle(ff.FullName);  //Developer Name:Priyanka Vishwakarma ,Date:15-02-2020 Requirement:for appendix para apply AppendixHead paragraph style.,Integrated by:Vikas sir.
                }
                AutoStructuringStyles.checkNormalParaorListingPara(ff.FullName);//Developer name : Priyanka Vishwakarma ,Date:22-02-2020 ,Requirement:Avoid to apply AlphaUpperList,AlphalowerList and RomanList when para start with A ot I in word.  ,Integrated by:Vikas sir.
                AutoStructuringStyles.HandleRomanList(ff.FullName); //Developer Name:Priyanka Vishwakarma ,Date:24-02-2020 ,Requirement:Handle RomanList text i. ,Integrated by:Vikas sir.
                if (GlobalMethods.strJournalArticlePath.ToLower().Contains(@"\journal\ilo\"))
                {
                    AutoStructuringStyles.ChangeUnknownRef(ff.FullName); //Developer name:Priyanka Vishwakarma ,Date:21-07-2020,Requirement:change reference unknown type when is does not change.
                }

                MapStylesWithWordTemplate.List_Style(ff.FullName);  //added on 29_3_2019 by priyanka for apply List Style
                AutoStructuringStyles.CheckAlphalistParagraph(ff.FullName);

            }
            else
            {
                //// Copy Styles from Word Template to the document
                CopyStylesFromTemplate.ExtractStyles(ff.FullName, GlobalMethods.str3CMWordTemplate);

                //// Start Word Markup //
                MapStylesWithWordTemplate.StyleMapping(ff.FullName, GlobalMethods.strStyleMappingConfig);
            }
            //Danish, this needs to be done for all the files.
            AutoStructuringStyles.RemoveRstyleEmphasisForWordAddItalicRunProperty(ff.FullName);  //Remove Emphasis and add Italic in run properties

            if (GlobalMethods.strClientName.ToLower() == "ufl")
            {
                MapStylesWithWordTemplate.CitetblStyleRemoveforSpace(ff.FullName);
                MapStylesWithWordTemplate.CheckAbstractParaStyle(ff.FullName);
                MapStylesWithWordTemplate.ApplyTFNAfterTable(ff.FullName); //Developer Name:Priyanka Vishwakarma,Date:12-02-2021,Requirement:Apply TFN for ufl input
            }
            if (GlobalMethods.strClientName.ToLower() == "informs")
            {
                AutoStructuringStyles.KeywordParastyleCheck(ff.FullName);
                AutoStructuringStyles.Ref1styleapplyforinform(ff.FullName);
                AutoStructuringStyles.AuthorMarking(ff.FullName);
            }
            if (GlobalMethods.strClientName.ToLower() == "jaypee" || GlobalMethods.strClientName.ToLower() == "ssllc") //Developer Name: Priyanka Vishwakarma, Date:20-12-2021, Requirement: handle references when it comes in footnote.
            {
                if (GlobalMethods.refStructureDone == false)
                {
                    bool ReferenceParaFound = AutoStructuringStyles.checkReferenceParagraphsComesinFootnote(ff.FullName);
                    if (ReferenceParaFound)
                    {
                        AutoStructuringStyles.checkForReferencePara(ff.FullName);
                        AutoStructuringStyles.removelabelfnfromFTN(ff.FullName);
                        AutoStructuringStyles.Ref1_StyleApplied(ff.FullName);
                        SearchAndReplace.ApplyCitebibForJaypee(ff.FullName);
                        References.changeReferenceCaloout(ff.FullName);
                        References.MergeReferenceElements(ff.FullName, GlobalMethods.strReferncePatternFilename, GlobalMethods.strJournalDBFilename, GlobalMethods.strPublisherDBFilename);
                    }
                }

            }
            if (GlobalMethods.strClientName.ToLower() == "sage")
            {
                MapStylesWithWordTemplate.RemoveNormalStyleapplyBodyA(ff.FullName);

                if (GlobalMethods.refStructureDone == false)
                {
                    AutoStructuringStyles.Ref_StyleApplied(ff.FullName);
                    AutoStructuringStyles.Ref1_StyleAppliedSage(ff.FullName);
                    MapStylesWithWordTemplate.ApplyREFStructureandcitebibforSage(ff.FullName, GlobalMethods.strStyleMappingConfig);
                }
                AutoStructuringStyles.Checkempasisbold(ff.FullName);    //Developer Name:Priyanka Date:19-10-2020 ,requirement:remove bold from dot and space.
                AutoStructuringStyles.CheckSpaceBold(ff.FullName);
                AutoStructuringStyles.CheckCitefnText(ff.FullName);  //Developer name:Priyanka Vishwakarma,Date:19-10-2020,Requirement:Remove double  labelfn and citelabel .
               AutoStructuringStyles.RemoveRstyleEmphasisForWordAddItalicRunProperty(ff.FullName);  //Remove Emphasis and add Italic in run properties
               AutoStructuringStyles.WDDeleteHiddenText(ff.FullName);///Added by vikas on 28-10-2020 for remove hidden text
                if (GlobalMethods.strCopyediting == "true")////if copy editing selected then it will run this function added condition by vikas on 24-03-2021
                {
                    if (GlobalMethods.strCopyEditingRequired != null && GlobalMethods.strCopyEditingRequired.ToLower() == "true")
                        MapStylesWithWordTemplate.doublecommaspacetocommaspace(ff.FullName);///Added by vikas on 19-10-2020
                }
                if (GlobalMethods.strCopyEditingRequired != null && GlobalMethods.strCopyEditingRequired.ToLower() == "true")
                {
                    MapStylesWithWordTemplate.RemovespacedotwithdotinPara(ff.FullName);////last run space dot replace with dot only added by vikas on 02-11-2020
                    MapStylesWithWordTemplate.RemovespaceStrtEndPara((ff.FullName));///Remove start and last content of para space trim
                }
            }
            else if(GlobalMethods.strClientName.ToLower() == "csiro")
            {
                if (GlobalMethods.strCopyEditingRequired != null && GlobalMethods.strCopyEditingRequired.ToLower() == "true")
                {
                    MapStylesWithWordTemplate.doublecommaspacetocommaspace(ff.FullName);///Added by vikas on 19-10-2020
                    AutoStructuringStyles.WDDeleteHiddenText(ff.FullName);///Added by vikas on 28-10-2020 for remove hidden text
                    AutoStructuringStyles.removespacebeforedotlastrun(ff.FullName);
                }
            }
            if (GlobalMethods.strClientName.ToLower() == "sage" && GlobalMethods.strJournalArticlePath.Contains("\\India\\"))//Developer Name:Priyanka Vishwakarma,Date:29-06-2021,Requirement:Add condition for sage india client TCHCenter and T-TXTCenter atyle not apply in table.
            {
                AutoStructuringStyles.CheckTTParaComesBeforeTable(ff.FullName);//Developer Name:Priyanka Vishwakarma,Date:06-07-2021, Requirement:Add function for check TT para next siblink is table .
            }
            MapStylesWithWordTemplate.CheckTTandFIGCPara(ff.FullName); //Developer Name:Priyanka Vishwakarma,Date:10-09-2020,Requirement:Change TT paragraph if paragraph start with Table without bold text.///FIGC added by vikas on 11-09-2020
            AutoStructuringStyles.CheckTTParaLabelstrongText(ff.FullName);//Developer Name:Priyanka Vishwakarma,Date:20-04-2021,Requirement:add conditon for check TT para and label strong text 
            SearchAndReplace.GeneralSearchAndReplace(ff.FullName);
            AutoStructuringStyles.ApplyEqtoBodyA(ff.FullName);///Developer name:Priyanka Vishwakarma,Date:22-10-2020,Requirement:For remove EQ style of inline equation to BodyA style added by vikas on 22-09-2020
            ////ConvertComments.ExportCommentAndInsertBookmark(ff.FullName);
            AutoStructuringStyles.CheckFIGCParaWithoutLabelStrong(ff.FullName);//Developer Name:Priyanka Vishwakarma,Date:03-02-2021,Requirement:add Codition for apply BODYA para style whlile FIGC para does nor contains label-strong char style.
                                                                               ////MapStylesWithWordTemplate.UpdateTableCellWidth(ff.FullName);

            //Compare the updated document with Source document and delete source document //
            ///GlobalMethods.OpenWordDocumentAndCompare(strSourceFileName, ff.FullName);
            MapStylesWithWordTemplate.CheckForbibnumberInPara(ff.FullName);//Developer Name:Priyanka Vishwakarma, Date:15-04-2021 ,Requirement:Apply REF1 paragraph style when para contains bibnumber char style.
            MapStylesWithWordTemplate.CheckParaStyleBodyAtoTTXTInTable(ff.FullName);//Developer Name:Priyanka Vishwakarma, Date:21-06-2021 ,Requirement:Apply T-TXT Paragarpha style instead of BodyA Para style in table.
            AutoStructuringStyles.Ref_StyleApplied(ff.FullName);
            AutoStructuringStyles.ChangeMSONormalParaStyleInParagraph(ff.FullName);
            if (GlobalMethods.strClientName.ToLower() == "sage" && GlobalMethods.strCopyediting == "false" && GlobalMethods.strJournalArticlePath.Contains("\\India\\")) //Developer Name:Priyanka Vishwakarma, Date:09-09-2021, Requirement: add orcid para in input if orcid information not present.
            {
                GlobalMethods.CheckOrcidPara(ff.FullName);
                MapStylesWithWordTemplate.CheckDTParaForSAGE(ff.FullName);
            }

            /////Added by Vikas on 02-10-2021 for remove extar spaces in superscript,subscript,bold,italic,underline run and shift to next or previous run as per space poision in run text
            if (GlobalMethods.strCopyEditingRequired != null && GlobalMethods.strCopyEditingRequired.ToLower() == "true")
                AutoStructuringStyles.CleanupExtraSpaces(ff.FullName);
            if (GlobalMethods.strClientName.ToLower() != "sage") //Developer Name:Priyanka Vishwakarma, Date:09-09-2021, Requirement: add orcid para in input if orcid information not present.
            {
                if (GlobalMethods.strCopyEditingRequired != null && GlobalMethods.strCopyEditingRequired.ToLower() == "true")
                {
                    AutoStructuringStyles.removespaceBetweencommaandRefcallout(ff.FullName);//Developer Name: Priyanka Vishwaakrma, Date:26-11-2021, Requirement: Remove space between dot and superscript value, Remove space between comma and superscript value
                    AutoStructuringStyles.removeSpacebeforerefCallout(ff.FullName);//Developer Name: Priyanka Vishwakarma, Date:17-12-2021, Requirement: remove space before reference callout and add space after refrence callout.
                }
            }
            //////Added for remove blank paras and

            if (GlobalMethods.strCopyEditingRequired != null && GlobalMethods.strCopyEditingRequired.ToLower() == "true")
            {
                AutoStructuringStyles.BlankParasremoveandalignleftforFIGCandTT(ff.FullName);
                AutoStructuringStyles.ReplaceEndashAndEmdashIntodashInOrcid(ff.FullName);//Developer Name:Priyanka Vishwakarma, Date:14-10-2021 ,Requirement:Replace Endash and Emdash into dash in orcid para.
            }
            if (GlobalMethods.strClientName.ToLower() == "jaypee" || GlobalMethods.strClientName.ToLower() == "ssllc")
            {
                AutoStructuringStyles.AddColonInTabbleCaptionandFigureCaptionForJaypee(ff.FullName);//Developer Name:Priyanka Vishwakarma, Date:5-10-2021, Add colon after figc or tt para id only for jaypee
                AutoStructuringStyles.ApplyH1StyleToAllCapsParagraph(ff.FullName);//Developer Name:Priyanka Vishwakarma, Date:22-1-2022, Change all the Uppercase content to Heading 1, after Introduction and before References
                AutoStructuringStyles.ApplyABTXTStyle(ff.FullName);//Developer Name:Priyanka Vishwakarma,Date:25-1-2022,Requirement: apply AB-TXT to paragraph between AB and kywd paras
            }
            AutoStructuringStyles.AddDummyHeadingTag(ff.FullName);
            if (GlobalMethods.strCopyEditingRequired != null && GlobalMethods.strCopyEditingRequired.ToLower() == "true")
            {
                if (GlobalMethods.strClientName.ToLower() == "ssllc") ////Developer Name:Priyanka Vishwakarma,Date:11-4-2022,Requirement: Table and figure callout should be in square brackets
                {
                    //Jitender 27-Sept-2022 - This is Global for all SSL Articles.
                    //if (GlobalMethods.strJournalId.ToLower() == "csdm" || GlobalMethods.strJournalId.ToLower() == "jcis")
                    {
                      
                        AutoStructuringStyles.ChangeBraketsFigureCaption(ff.FullName);
                        AutoStructuringStyles.ChangeBraketsTableCaption(ff.FullName);
                    }
                    
                    AutoStructuringStyles.ChangeFigCalloutForRange(ff.FullName);
                }
                if (GlobalMethods.strClientName.ToLower() == "jaypee")
                {
                    AutoStructuringStyles.ChangeFigCalloutForRangeForJaypee(ff.FullName);
                }
            }
            try
            {
                GlobalMethods.CleanupAnalysisReport(ff.FullName);
            }
            catch (Exception er)
            {

            }
            System.Threading.Thread.Sleep(1000);

            // Delete the Source Document //

            File.Delete(strSourceFileName);


            OutputFilename = ff.FullName;

            if (OutputFilename != null)
            {
                if (File.Exists(OutputFilename.ToString()))
                {
                    // Move the processed document to out folder
                    FileInfo fout = new FileInfo(OutputFilename.ToString());

                    string strParentDirectory = GlobalMethods.strJobTransId;
                    string outfile = null;
                    string EmptyDoc = null;

                    EmptyDoc = fout.Directory.FullName;

                    if (EmptyDoc.EndsWith("\\") == false)
                    {
                        EmptyDoc += "\\EmptyDocument.docx";
                    }
                    else
                    {
                        EmptyDoc += "EmptyDocument.docx";
                    }

                    // Delete EmptyDocument.docx
                    if (File.Exists(EmptyDoc))
                    {
                        File.Delete(EmptyDoc);
                    }

                    outfile = fout.Name;

                    if (Directory.Exists(GlobalMethods.StrOutFolder + "\\" + strParentDirectory) == false)
                    {
                        Directory.CreateDirectory(GlobalMethods.StrOutFolder + "\\" + strParentDirectory);
                    }

                    outfile = GlobalMethods.StrOutFolder + "\\" + strParentDirectory + "\\" + outfile;

                    // On completion copy the output file in out folder

                    if (Directory.Exists(GlobalMethods.StrOutFolder + "\\" + strParentDirectory))
                    {
                        File.Copy(OutputFilename.ToString(), outfile, true);
                    }
                    else
                    {
                        Directory.CreateDirectory(GlobalMethods.StrOutFolder + "\\" + strParentDirectory);
                        File.Copy(OutputFilename.ToString(), outfile, true);
                    }
                    // Delete the files from the Process folder


                    fout.Delete();

                    Directory.Delete(fout.Directory.FullName, true);

                    System.Threading.Thread.Sleep(3000);
                }
            }
            EndProcess:
            {
                if (Directory.Exists(GlobalMethods.StrProcessFolder + "\\" + Dir.Name))
                {
                    Directory.Delete(GlobalMethods.StrProcessFolder + "\\" + Dir.Name);
                }
            }
            //ff.Delete();
            //bProcessingInProgress = false;
            // Reinitiate the processing to check other input //
        }
    }
}
