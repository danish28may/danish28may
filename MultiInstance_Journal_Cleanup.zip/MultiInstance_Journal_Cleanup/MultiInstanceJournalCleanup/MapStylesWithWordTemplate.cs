﻿using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;
using OpenXmlPowerTools;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml;
using System.Xml.Linq;
using System.Configuration;
using System.Text.RegularExpressions;
using DocumentFormat.OpenXml;

namespace MultiInstanceJournalCleanup
{
    class MapStylesWithWordTemplate
    {
        static int nJournalTitleParaNumber = 0;
        static int nAuthorInfoParaNumber = 0;
        static int nJournalSubTitleParaNumber = 0;

        public static List<DocumentFormat.OpenXml.Wordprocessing.Run> commentHyperlink = new List<DocumentFormat.OpenXml.Wordprocessing.Run>();


        public static void StyleMapping(string newDoc, string StyleMappingConfig)
        {
            ExecuteStyleMapping(newDoc, StyleMappingConfig);

            CheckParaTextAndApplyStyle(newDoc);

            System.Threading.Thread.Sleep(1000);

            ConditionalStyleMapping(newDoc);
            AutoStructuringStyles.REFStyle(newDoc);//For Apply Ref style to Reference heading.

            ////// Check the text present in the document required to be inserted and moved from current location //

            //////nJournalTitleParaNumber = 0;
            //////nJournalTitleParaNumber = CheckIfTheParaTextInTheDocument(newDoc, GlobalMethods.JournalTitle);

            //////nAuthorInfoParaNumber = 0;
            //////nAuthorInfoParaNumber = CheckIfTheParaTextInTheDocument(newDoc, GlobalMethods.AuthorInfo);

            //////nJournalSubTitleParaNumber = 0;
            //////nJournalSubTitleParaNumber = CheckIfTheParaTextInTheDocument(newDoc, GlobalMethods.JournalSubTitle);

            ////// Check the text present in the document required to be inserted and moved from current location //

            //////ConditionalStyleMappingCont(newDoc);

            //Developer name:Priyanka Vishwakarma,Date:10-09-2020,Requirement:read reference pattern file for informs client.

            GlobalMethods.strReferncePatternFilename = null;
            if (GlobalMethods.strClientName.ToLower() == "informs")
            {
                GlobalMethods.strReferncePatternFilename = ConfigurationManager.AppSettings.Get("RefrencePatternFilenameForINF");

            }
            else if (GlobalMethods.strClientName.ToLower() == "sage")  //10-10-2020
            {
                GlobalMethods.strReferncePatternFilename = ConfigurationManager.AppSettings.Get("RefrencePatternFilenameForSage");

            }
            else
            {
                GlobalMethods.strReferncePatternFilename = ConfigurationManager.AppSettings.Get("RefrencePatternFilename");
            }
            //-------------End on 10-09-2020
            GlobalMethods.strJournalDBFilename = null;
            GlobalMethods.strPublisherDBFilename = null;
            if (GlobalMethods.strClientName.ToLower() == "sage")  //10-10-2020
            {
                GlobalMethods.strJournalDBFilename = ConfigurationManager.AppSettings.Get("JournalNameDBSage");
                GlobalMethods.strPublisherDBFilename = ConfigurationManager.AppSettings.Get("PublisherNameDBSage");
            }
            else
            {
                GlobalMethods.strJournalDBFilename = ConfigurationManager.AppSettings.Get("JournalNameDB");
                GlobalMethods.strPublisherDBFilename = ConfigurationManager.AppSettings.Get("PublisherNameDB");
            }
            if (GlobalMethods.strClientName.ToLower() != "ufl")
            {
                References.MergeReferenceElements(newDoc, GlobalMethods.strReferncePatternFilename, GlobalMethods.strJournalDBFilename, GlobalMethods.strPublisherDBFilename);  //Comment for Florida  14-08-2020
            }
            ///Logic for Address for correspondence

            ////remove comment from document added by karan 
            ConvertComments.RemoveCommenteName(newDoc);/////commented by vikas 6-6-2019

            ///logic pending for AuthorMarking
            ///AuthorAffiliation.AuthorMarking(newDoc);

            ///bool added by karan for pattern match or not on 18-08-2018
            GlobalMethods.AddressCorStructured = false;

            #region regex code commented 
            ////GlobalMethods.strCorrespondenPatternFilename = null;
            ////GlobalMethods.strCorrespondenPatternFilename = ConfigurationManager.AppSettings.Get("AddressforcorrespondenceFilename");

            ////GlobalMethods.strAddressForCorresspondencetxt = null;
            ////GlobalMethods.strAddressForCorresspondencetxt = ConfigurationManager.AppSettings.Get("AddressForCorresspondenceTxt");

            ////GlobalMethods.strAddressDetails = null;
            ////GlobalMethods.strAddressDetails = ConfigurationManager.AppSettings.Get("strAddressDetailsInfo");

            ////GlobalMethods.strDegreeDBFilename = null;
            ////GlobalMethods.strDegreeDBFilename = ConfigurationManager.AppSettings.Get("strDegreeDBFilename");

            ///////for regex
            ////Address_ForCorrespondence.Merge_Address_ForCorrespondence(newDoc, GlobalMethods.strCorrespondenPatternFilename, GlobalMethods.strAddressForCorresspondencetxt, GlobalMethods.strAddressDetails, GlobalMethods.strDegreeDBFilename);
            #endregion

            ///second logic for Address for correspondence Added by Karan on 18-08-2018 Start
            if ((GlobalMethods.AddressCorStructured == false && GlobalMethods.strRefNum != "UnNumbered") || (GlobalMethods.AddressCorStructured == false && GlobalMethods.strClientName.ToLower() == "ufl") || (GlobalMethods.AddressCorStructured == false && GlobalMethods.strClientName.ToLower() == "sage")) //Developer Name:Priyanka Vishwakarma,Date:15-08-2020,Requirement:Add condition for address for correspondance  for UFL client input.
            {
                GlobalMethods.strCountryDBFilename = null;
                GlobalMethods.strCountryDBFilename = ConfigurationManager.AppSettings.Get("strCountryDBFilename");

                GlobalMethods.strPincodeDBFilename = null;
                GlobalMethods.strPincodeDBFilename = ConfigurationManager.AppSettings.Get("strPincodeDBFilename");

                GlobalMethods.strCityDBFilename = null;
                GlobalMethods.strCityDBFilename = ConfigurationManager.AppSettings.Get("strCityDBFilename");

                GlobalMethods.strStatesDBFilename = null;
                GlobalMethods.strStatesDBFilename = ConfigurationManager.AppSettings.Get("strStatesDBFilename");

                GlobalMethods.strDegreeDBFilename = null;
                GlobalMethods.strDegreeDBFilename = ConfigurationManager.AppSettings.Get("strDegreeDBFilename");

                GlobalMethods.strInstitutionDBFilename = null;
                GlobalMethods.strInstitutionDBFilename = ConfigurationManager.AppSettings.Get("strInstitutionDBFilename");

                GlobalMethods.strAddressCorresspondenStyleDB = null;
                GlobalMethods.strAddressCorresspondenStyleDB = ConfigurationManager.AppSettings.Get("strAddressCorresspondenStyleDB");

                GlobalMethods.strAddressLineDB = null;
                GlobalMethods.strAddressLineDB = ConfigurationManager.AppSettings.Get("strAddressLineDB");

                //MergeCORRParaForSage(newDoc);

                if (GlobalMethods.strClientName.ToLower() == "sage")
                {
                    if (!GlobalMethods.strJournalArticlePath.Contains("\\India\\"))
                    {
                        if (GlobalMethods.strCopyEditingRequired != null && GlobalMethods.strCopyEditingRequired.ToLower() == "true")
                            MergeCORRParaForSage(newDoc);
                        Address_ForCorrespondence.Merge_Address_ForCorrespondence1(newDoc, null, GlobalMethods.strAddressForCorresspondencetxt, GlobalMethods.strCountryDBFilename, GlobalMethods.strStatesDBFilename, GlobalMethods.strCityDBFilename, GlobalMethods.strPincodeDBFilename, GlobalMethods.strDegreeDBFilename, GlobalMethods.strInstitutionDBFilename, GlobalMethods.strAddressLineDB);
                        if (GlobalMethods.strCopyEditingRequired != null && GlobalMethods.strCopyEditingRequired.ToLower() == "true")
                            Address_ForCorrespondence.CheckCorrParaExtrapunctuation(newDoc);//Developer Name:Priyanka Vishwakarma,Date:07-05-2021,Requirement:Check corr para ends with dot 
                    }
                }
                else
                {
                    if (GlobalMethods.strCopyEditingRequired != null && GlobalMethods.strCopyEditingRequired.ToLower() == "true")
                        MergeCORRParaForSage(newDoc);
                    Address_ForCorrespondence.Merge_Address_ForCorrespondence1(newDoc, null, GlobalMethods.strAddressForCorresspondencetxt, GlobalMethods.strCountryDBFilename, GlobalMethods.strStatesDBFilename, GlobalMethods.strCityDBFilename, GlobalMethods.strPincodeDBFilename, GlobalMethods.strDegreeDBFilename, GlobalMethods.strInstitutionDBFilename, GlobalMethods.strAddressLineDB);
                    if (GlobalMethods.strCopyEditingRequired != null && GlobalMethods.strCopyEditingRequired.ToLower() == "true")
                        Address_ForCorrespondence.CheckCorrParaExtrapunctuation(newDoc);//Developer Name:Priyanka Vishwakarma,Date:07-05-2021,Requirement:Check corr para ends with dot 
                }


            }
            ///second logic for Address for correspondence Added by Karan on 18-08-2018 End

            ////testing is pending 
            ////AuthorAffiliation.AuthorMarking(newDoc);
            if (GlobalMethods.strCopyEditingRequired != null && GlobalMethods.strCopyEditingRequired.ToLower() == "true")
                MapStylesWithWordTemplate.RRHinMspace(newDoc);

            //add comment in document added by karan
            ConvertComments.ExportCommentName(newDoc);/////commented by vikas 6-6-2019

            if (GlobalMethods.strClientName.ToLower() == "sage")
            {
                if (GlobalMethods.strJournalArticlePath.Contains("\\India\\"))
                {
                    if (GlobalMethods.strCopyEditingRequired != null && GlobalMethods.strCopyEditingRequired.ToLower() == "true")
                        MergeCORRParaForSage(newDoc);
                }
            }
            ////Commented by Karan on 20-06-2018
            ///TableStyling.AdditionalWordMarkup(newDoc);

            // Include Para and List immediately below the Figure Caption as Figure Para

            //IncludeParaListInsideFigure(newDoc);

        }

        public static void StyleMappingForJaypee(string newDoc, string StyleMappingConfig)
        {
            ExecuteStyleMapping(newDoc, StyleMappingConfig);

            

        }

        public static void Copyrights(string strProcessDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument.Open(strProcessDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {

                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val.Value == "CR" && P.InnerText.Trim().Contains("©"))
                    {
                        ParagraphProperties pr = P.Descendants<ParagraphProperties>().First();
                        ///Copyright © 2017 Indian Society of Otology
                        string strText = null;
                        foreach (Run R in P.Descendants<Run>().ToList())
                        {
                            foreach (Text T in R.Descendants<Text>().ToList())
                            {
                                strText = strText + T.Text;
                                ///Copyright © 2017 Indian Society of Otology
                            }

                            R.Remove();
                        }
                        string[] separators = { "©" };
                        string[] links = strText.Split(separators, StringSplitOptions.None);
                        int count = links.Length;
                        Paragraph para = new Paragraph();
                        ParagraphProperties ppr = pr;
                        Run newrun1 = new Run();

                        Run newrun2 = new Run();
                        if (links[0] != null)
                        {
                            Text newtext1 = new Text();
                            newtext1.Text = links[0];

                            newrun1.Append(newtext1);
                        }
                        if (links[1] != null)
                        {
                            RunProperties rpr = new RunProperties(new RunStyle { Val = "copyright" });
                            //RunStyle rstyle = new RunStyle();
                            //rstyle.Val = "copyright";
                            //rpr.Append(rstyle);
                            Text newtext2 = new Text();
                            // newtext2.Text = " " + "©" + links[1].TrimStart();
                            //added by narayan 12-04-2019
                            //newtext2.Text = strText;//commented by priyanka on 23_08_2019
                            newtext2.Text = "©" + links[1];  //Developer name:Priyanka Vishwakarma, Date:23_08_2019 ,Requirement:apply copyright style after copyright symbol. .integareted by:vikas sir
                            newrun2.Append(rpr);
                            newrun2.Append(newtext2);
                        }
                        para.Append(ppr.CloneNode(true));
                        P.InsertBeforeSelf(para);
                        para.Append(newrun1);
                        para.Append(newrun2);
                        //newrun1.InsertAfterSelf(newrun2);
                        P.Remove();

                    }
                }
                D.Save();
            }
        }

        public static void RRHParagraphDelete(string strProcessDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument.Open(strProcessDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val.Value == "RRH")
                    {
                        P.Remove();
                    }
                    ///commented code for applied to normal Sytle.
                    ////if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val.Value != "")
                    ////{
                    ////    P.ParagraphProperties.ParagraphStyleId.Val.Value = "Normal";
                    ////}
                }
                D.Save();
            }
        }

        public static void UpdateTableCellWidth(string strProcessDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument.Open(strProcessDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                var allTables = D.Body.Elements<DocumentFormat.OpenXml.Wordprocessing.Table>();

                foreach (var tb in allTables)
                {
                    bool tblWidthFound = false;
                    if (tb.HasChildren)
                    {
                        foreach (var item in tb.Elements())
                        {
                            if (item.XName == W.tblPr)
                            {
                                foreach (var item1 in item.Elements())
                                {
                                    if (item1.XName == W.tblW)
                                    {
                                        if (item1.HasAttributes)
                                        {
                                            foreach (var attr in item1.GetAttributes())
                                            {
                                                var atr = attr;
                                                if (atr.LocalName == "w" && atr.Value == "0")
                                                {
                                                    atr.Value = "50";
                                                    tblWidthFound = true;
                                                    break;
                                                }
                                            }
                                        }
                                    }
                                    if (tblWidthFound)
                                        break;
                                }
                            }
                            if (tblWidthFound)
                                break;
                        }
                    }
                    //if (tblWidthFound == false)
                    //{

                    //}
                }
                D.Save();
                WPD.Close();
            }
        }


        //private static void IncludeParaListInsideFigure(string newDoc)
        //{
        //    using (WordprocessingDocument WPD = WordprocessingDocument
        //         .Open(newDoc, true))
        //    {
        //        SimplifyMarkupSettings settings = new SimplifyMarkupSettings
        //        {
        //            NormalizeXml = false,
        //            RemoveHyperlinks = false,
        //            RemoveComments = false,
        //            RemoveContentControls = true,
        //            RemoveLastRenderedPageBreak = true,
        //            RemovePermissions = true,
        //            RemoveProof = true,
        //            RemoveRsidInfo = true,
        //            RemoveSmartTags = true,
        //            RemoveSoftHyphens = false,
        //            ReplaceTabsWithSpaces = true,

        //            RemoveEndAndFootNotes = false,
        //            RemoveFieldCodes = true,
        //            AcceptRevisions = true,
        //            RemoveBookmarks = true,
        //            RemoveGoBackBookmark = true,
        //            RemoveWebHidden = true,
        //            RemoveMarkupForDocumentComparison = true,
        //        };

        //        MarkupSimplifier.SimplifyMarkup(WPD, settings);

        //        MainDocumentPart MDP = WPD.MainDocumentPart;

        //        Document D = MDP.Document;

        //        bool bFigCaptionStarts = false;

        //        foreach (Paragraph P in D.Descendants<Paragraph>())
        //        {
        //            if (P.HasChildren == true)
        //            {
        //                if (P.ParagraphProperties != null)
        //                {
        //                    if (P.ParagraphProperties.ParagraphStyleId != null)
        //                    {
        //                        if (P.ParagraphProperties.ParagraphStyleId.Val == "FIGC")
        //                        {
        //                            bFigCaptionStarts = true;
        //                            //goto NextPara;
        //                        }
        //                        else if (P.ParagraphProperties.ParagraphStyleId.Val == "BodyA" || P.ParagraphProperties.ParagraphStyleId.Val == "BullList" || P.ParagraphProperties.ParagraphStyleId.Val == "lower-alpha-list" || P.ParagraphProperties.ParagraphStyleId.Val == "lower-roman-list")
        //                        {
        //                            if (bFigCaptionStarts)
        //                            {
        //                                //P.ParagraphProperties.ParagraphStyleId.Val = "FIGP" ;
        //                                ApplyStyleToParagraph(WPD, "FIGP", "FIGP", P);
        //                                //goto NextPara;
        //                            }
        //                        }
        //                        else
        //                        {
        //                            bFigCaptionStarts = false;
        //                            //goto NextPara;
        //                        }
        //                    }
        //                }
        //            }
        //            //NextPara: { };
        //        }

        //        //D.Save();
        //    }
        //}

        //// Apply a style to a paragraph.
        //public static void ApplyStyleToParagraph(WordprocessingDocument doc,
        //    string styleid, string stylename, Paragraph p)
        //{
        //    // If the paragraph has no ParagraphProperties object, create one.
        //    if (p.Elements<ParagraphProperties>().Count() == 0)
        //    {
        //        p.PrependChild<ParagraphProperties>(new ParagraphProperties());
        //    }

        //    // Get the paragraph properties element of the paragraph.
        //    ParagraphProperties pPr = p.Elements<ParagraphProperties>().First();

        //    // Set the style of the paragraph.
        //    pPr.ParagraphStyleId = new ParagraphStyleId() { Val = styleid };
        //}


        //private static void newExecuteStyleMapping(string newDoc, string StyleMappingConfig)
        //{
        //    try
        //    {
        //        // Style Mapping //

        //        // Read the StyleMappingConfing and store the values in array //
        //        List<string> strStyleMapping = new List<string>();

        //        strStyleMapping = GlobalMethods.ReadAndStoreFileValuesInArray(StyleMappingConfig);

        //        string SourceStyle = null;
        //        string TargetStyle = null;
        //        int nCounter = 0;


        //        List<string> strRefNumColl = new List<string>();

        //        using (WordprocessingDocument WPD = WordprocessingDocument
        //            .Open(newDoc, true))
        //        {
        //            SimplifyMarkupSettings settings = new SimplifyMarkupSettings
        //            {
        //                RemoveComments = false,
        //                RemoveContentControls = true,
        //                RemoveEndAndFootNotes = false,
        //                RemoveFieldCodes = true,
        //                RemoveLastRenderedPageBreak = true,
        //                RemovePermissions = true,
        //                RemoveProof = true,
        //                RemoveRsidInfo = true,
        //                RemoveSmartTags = true,
        //                RemoveSoftHyphens = false,
        //                ReplaceTabsWithSpaces = true,
        //            };

        //            MarkupSimplifier.SimplifyMarkup(WPD, settings);

        //            MainDocumentPart MDP = WPD.MainDocumentPart;

        //            Document D = MDP.Document;

        //            for(nCounter = 0; nCounter < strStyleMapping.Count(); nCounter++)
        //            {
        //                string[] strStyleArr;

        //                strStyleArr = strStyleMapping[nCounter].Split('|');

        //                if(strStyleArr.Length > 0)
        //                {
        //                    SourceStyle = strStyleArr[0];
        //                    TargetStyle = strStyleArr[1];

        //                    if (SourceStyle.ToLower() != "normal")
        //                    {
        //                        foreach (Paragraph P in D.Descendants<Paragraph>().ToList().
        //                       Where(e => e.ParagraphProperties != null
        //                           && e.ParagraphProperties.ParagraphStyleId != null
        //                           && e.ParagraphProperties.ParagraphStyleId.Val == SourceStyle))
        //                        {
        //                            P.ParagraphProperties.ParagraphStyleId.Val = TargetStyle;
        //                        }
        //                    }
        //                }

        //            }

        //            D.Save();
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        Console.WriteLine(ex.Message);
        //    }
        //}


        ///commented By Karan becasuse new Function added from Financial Cleaup ref.
        ////private static void ExecuteStyleMapping(string newDoc, string StyleMappingConfig)
        ////{
        ////    // Read the StyleMappingConfing and store the values in array //
        ////    List<string> strStyleMapping = new List<string>();

        ////    strStyleMapping = GlobalMethods.ReadAndStoreFileValuesInArray(StyleMappingConfig);

        ////    string SourceStyle = null;
        ////    string TargetStyle = null;

        ////    using (WordprocessingDocument wDoc = WordprocessingDocument.Open(newDoc, true))
        ////    {
        ////        SimplifyMarkupSettings settings = new SimplifyMarkupSettings
        ////        {
        ////            RemoveComments = false,
        ////            RemoveContentControls = true,
        ////            RemoveEndAndFootNotes = false,
        ////            RemoveFieldCodes = true,
        ////            RemoveLastRenderedPageBreak = true,
        ////            RemovePermissions = true,
        ////            RemoveProof = true,
        ////            RemoveRsidInfo = true,
        ////            RemoveSmartTags = true,
        ////            RemoveSoftHyphens = false,
        ////            ReplaceTabsWithSpaces = true,
        ////        };

        ////        MarkupSimplifier.SimplifyMarkup(wDoc, settings);

        ////        var xDoc = wDoc.MainDocumentPart.GetXDocument();

        ////        XmlDocument xd = xDoc.GetXmlDocument();

        ////        xd.LoadXml(xd.InnerXml);

        ////        XmlNodeList nodeList;


        ////        XmlNamespaceManager ns = new XmlNamespaceManager(xd.NameTable);
        ////        ns.AddNamespace("w", "http://schemas.openxmlformats.org/wordprocessingml/2006/main");

        ////        XmlNode root = xd.DocumentElement;
        ////        nodeList = root.SelectNodes("w:body[w:p/w:pPr]", ns);

        ////        XElement xe;
        ////        foreach (XmlNode book in nodeList)
        ////        {
        ////            xe = book.GetXElement();

        ////            if (xe.HasElements)
        ////            {
        ////                foreach (XElement xee in xe.Elements())
        ////                {
        ////                    if (xee.HasElements)
        ////                    {
        ////                            // Check if the paragraph has style element
        ////                        if (CheckIfTheParaHasChildElement(xee) == false)
        ////                        {
        ////                            // Create new Style element with Normal style

        ////                            foreach (string strStyle in strStyleMapping)
        ////                            {
        ////                                if (strStyle != null)
        ////                                {
        ////                                    SourceStyle = null;
        ////                                    TargetStyle = null;
        ////                                    string[] t = strStyle.Split('|');

        ////                                    if (t.Length > 0)
        ////                                    {
        ////                                        SourceStyle = t[0];
        ////                                        TargetStyle = t[1];

        ////                                        if (SourceStyle == "Normal")
        ////                                        {
        ////                                            XNamespace w = @"http://schemas.openxmlformats.org/wordprocessingml/2006/main";
        ////                                            XElement style = new XElement(w + "pPr", "",
        ////                                                new XElement(w + "pStyle", new XAttribute(w + "val", TargetStyle)));
        ////                                            xee.AddFirst(style);
        ////                                        }
        ////                                    }
        ////                                }
        ////                            }
        ////                        }
        ////                        else
        ////                        {
        ////                            foreach (XElement xec in xee.Elements())
        ////                            {
        ////                                if (xec.HasElements)
        ////                                {
        ////                                    foreach (XElement xec1 in xec.Elements())
        ////                                    {
        ////                                        if (xec1.Name.LocalName == "pStyle")
        ////                                        {
        ////                                            foreach (XAttribute xa1 in xec1.Attributes())
        ////                                            {
        ////                                                if (xa1.Name == W.val)
        ////                                                {
        ////                                                    foreach (string strStyle in strStyleMapping)
        ////                                                    {
        ////                                                        if (strStyle != null)
        ////                                                        {
        ////                                                            SourceStyle = null;
        ////                                                            TargetStyle = null;
        ////                                                            string[] t = strStyle.Split('|');

        ////                                                            if (t.Length > 0)
        ////                                                            {
        ////                                                                SourceStyle = t[0];
        ////                                                                TargetStyle = t[1];

        ////                                                                if (xa1.Value == SourceStyle)
        ////                                                                {
        ////                                                                    xa1.SetValue(TargetStyle);
        ////                                                                    break;
        ////                                                                }
        ////                                                            }
        ////                                                        }
        ////                                                    } // For Each
        ////                                                }
        ////                                            }
        ////                                        }
        ////                                    }
        ////                                }
        ////                            } //For each
        ////                        }

        ////                    }//if (xee.HasElements)
        ////                }
        ////            }

        ////            //root.InnerXml = xe.GetXmlNode().InnerXml;
        ////            //xd.InnerXml = root.InnerXml;
        ////            xd.FirstChild.FirstChild.InnerXml = ((System.Xml.XmlDocument)(xe.GetXmlNode())).DocumentElement.InnerXml;
        ////            //xd.ReplaceChild(((System.Xml.XmlDocument)(xe.GetXmlNode())).DocumentElement, xd.FirstChild.FirstChild);
        ////        }
        ////        wDoc.MainDocumentPart.PutXDocument(xd.GetXDocument());
        ////    } // End of Word Processing
        ////}

        public static void ExecuteStyleMapping(string newDoc, string StyleMappingConfig)
        {
            // Read the StyleMappingConfing and store the values in array //
            List<string> strStyleMapping = new List<string>();

            strStyleMapping = GlobalMethods.ReadAndStoreFileValuesInArray(StyleMappingConfig);

            using (WordprocessingDocument WPD = WordprocessingDocument.Open(newDoc, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    RemoveComments = false,
                    RemoveContentControls = true,
                    RemoveEndAndFootNotes = false,
                    RemoveFieldCodes = true,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = false,//Developer name :Priyanka Vishwakarma. Date:29_5_2019, Requirement:it removes the indentation from the nested list  ,Integrated By:Vikas sir. 
                };

                MarkupSimplifier.SimplifyMarkup(WPD, settings);
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                List<ParagraphStyleId> S = D.Descendants<ParagraphStyleId>()
                                        .Where(c => c.Val != null).ToList();

                foreach (ParagraphStyleId PS in S)
                {
                    if (strStyleMapping.Any(str => str.Contains(PS.Val)))
                    {
                        int nIndex = -1;

                        foreach (var item in strStyleMapping)
                        {
                            nIndex++;

                            if (item.StartsWith(PS.Val))
                                break;
                        }

                        if (nIndex >= 0)
                        {
                            string strStyle = null;

                            strStyle = strStyleMapping[nIndex];

                            string[] t = strStyle.Split('|');

                            if (t.Length > 0)
                            {
                                if (PS.Val == t[0])
                                {
                                    PS.Val = t[1];

                                    #region  // This code needs to be commented if not required //


                                    //if (GlobalMethods.StyleList.Count > 0)
                                    //{
                                    //    // Extract the style properties if the current paragraph style
                                    //    // #2: get values for a key
                                    //    string key = t[0];
                                    //    List<Style> mystyle = (from kvp in GlobalMethods.StyleList where kvp.Key == key select kvp.Value).ToList();

                                    //    if (mystyle.Count > 0)
                                    //    {
                                    //        ParagraphProperties Pp;

                                    //        if (((ParagraphProperties)PS.Parent) == null)
                                    //        {
                                    //            Pp = new ParagraphProperties();
                                    //        }
                                    //        else
                                    //        {
                                    //            Pp = ((ParagraphProperties)PS.Parent);
                                    //        }

                                    //        if (Pp.Indentation == null)
                                    //        {
                                    //            if (mystyle[0].StyleParagraphProperties.Indentation != null)
                                    //            {
                                    //                if (Pp.Indentation == null)
                                    //                {
                                    //                    Pp.Indentation = new Indentation();
                                    //                }

                                    //                if (mystyle[0].StyleParagraphProperties.Indentation.Left != null)
                                    //                {
                                    //                    Pp.Indentation.Left = mystyle[0].StyleParagraphProperties.Indentation.Left;
                                    //                }

                                    //                if (mystyle[0].StyleParagraphProperties.Indentation.Hanging != null)
                                    //                {
                                    //                    Pp.Indentation.Left = mystyle[0].StyleParagraphProperties.Indentation.Hanging;
                                    //                }

                                    //                if (mystyle[0].StyleParagraphProperties.Indentation.FirstLine != null)
                                    //                {
                                    //                    Pp.Indentation.Left = mystyle[0].StyleParagraphProperties.Indentation.FirstLine;
                                    //                }

                                    //                if (mystyle[0].StyleParagraphProperties.Indentation.Right != null)
                                    //                {
                                    //                    Pp.Indentation.Left = mystyle[0].StyleParagraphProperties.Indentation.Right;
                                    //                }
                                    //            }
                                    //        }

                                    //        if (Pp.Justification == null)
                                    //        {
                                    //            Pp.Justification = new Justification();

                                    //            if (mystyle[0].StyleParagraphProperties.Justification != null)
                                    //            {
                                    //                Pp.Justification = mystyle[0].StyleParagraphProperties.Justification;
                                    //            }
                                    //        }
                                    //    }
                                    //}

                                    // This code needs to be commented if not required //
                                    #endregion
                                }
                            }
                        }
                    }
                }

            } // End of Word Processing
        }


        private static bool CheckIfTheParaHasChildElement(XElement xee)
        {
            foreach (XElement xec in xee.Elements())
            {
                if (xec.HasElements)
                {
                    foreach (XElement xec1 in xec.Elements())
                    {
                        if (xec1.Name.LocalName == "pStyle")
                        {
                            return true;
                        }
                    }
                }
            }

            return false;
        }

        //old Logic 
        public static void FigAndTextBetweenEnSpace1(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    NormalizeXml = false,
                    RemoveHyperlinks = false,
                    RemoveComments = false,
                    RemoveContentControls = true,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = false,//Developer name :Priyanka Vishwakarma. Date:29_5_2019, Requirement:it removes the indentation from the nested list  ,Integrated By:Vikas sir. 

                    RemoveEndAndFootNotes = false,
                    RemoveFieldCodes = true,
                    AcceptRevisions = true,
                    RemoveBookmarks = true,
                    RemoveGoBackBookmark = true,
                    RemoveWebHidden = true,
                    RemoveMarkupForDocumentComparison = true,
                };
                MarkupSimplifier.SimplifyMarkup(WPD, settings);

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                string strParaText = null;
                string strFig = null;
                bool blablestrong = false;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val.Value == "FIGC")
                    {
                        Run firstRun = P.Descendants<Run>().First();
                        strParaText = null;

                        foreach (Run R in P.Descendants<Run>().ToList())
                        {


                            foreach (DocumentFormat.OpenXml.OpenXmlElement ox in R.Elements())
                            {
                                if (ox.XName == W.t)
                                {
                                    ////if (ox.HasAttributes)
                                    ////{
                                    ////    foreach (var attr in ox.GetAttributes())
                                    ////    {
                                    ////        if(attr.Value != null && attr.Value== "preserve")
                                    ////        {
                                    ////            ox.RemoveAttribute(attr.LocalName,attr.NamespaceUri);
                                    ////        }
                                    ////    }
                                    ////}
                                    //stored all text
                                    strParaText += ox.InnerText;
                                }
                            }
                        }

                        foreach (Run R in P.Descendants<Run>().ToList())
                        {
                            foreach (RunProperties rp in R.Descendants<RunProperties>().ToList())
                            {
                                if (rp.RunStyle != null)
                                {
                                    if (rp.RunStyle.Val != null)
                                    {
                                        if (rp.RunStyle.Val.Value == "label-Strong")
                                        {
                                            blablestrong = true;
                                        }
                                    }
                                }
                            }
                        }

                        if (firstRun.Descendants<Text>().Count() > 0 && blablestrong == true)
                        {
                            if (strParaText != null)
                            {

                                strFig = null;


                                strFig = MapStylesWithWordTemplate.SearchRegExPatternFirstSearchInstanceOnly(strParaText, @"^(Fig.)+\s+([0-9a-zA-Z]{1,2})");

                                if (strFig != null)
                                {
                                    if (strParaText.Trim().StartsWith(strFig.Trim()))
                                    {
                                        //remove fig ex:Fig. 1
                                        strParaText = strParaText.Remove(0, strFig.Length);

                                        strParaText.StartsWith(" ".Replace(" ", ""));


                                        Run NewRunAfterFigtext = new Run();


                                        if (firstRun.RunProperties != null)
                                        {
                                            NewRunAfterFigtext.Append(firstRun.RunProperties.CloneNode(true));
                                        }

                                        Text numT = new Text(strFig);
                                        NewRunAfterFigtext.Append(numT);

                                        firstRun.InsertAfterSelf(NewRunAfterFigtext);

                                        Run nrunmspace = new Run();
                                        Text mspce = new Text("\u2003");
                                        nrunmspace.Append(mspce);
                                        NewRunAfterFigtext.InsertAfterSelf(nrunmspace);

                                        firstRun.Remove();

                                        #region start 

                                        //        //strItemTxt = MapStylesWithWordTemplate.SearchRegExPatternFirstSearchInstanceOnly(strParaText, @"^[0-9a-zA-Z]{1,}");

                                        //        if (strItemTxt != null)
                                        //        {
                                        //            //Run newRun = new Run();
                                        //            //string itemText = null;
                                        //            //bool itemFound = false;

                                        //            //foreach (Run eachRun in P.Descendants<Run>().ToList())
                                        //            //{
                                        //            //    foreach (var ele in eachRun.Elements())
                                        //            //    {
                                        //            //        if (ele.XName == W.t)
                                        //            //        {
                                        //            //            itemText += ele.InnerText;
                                        //            //            if (itemText.Trim().Contains(strFig.Trim()))
                                        //            //            {
                                        //            //                Text newText = new Text(itemText.Remove(0, strFig.Trim().Length).TrimStart(' '));
                                        //            //                if (eachRun.RunProperties != null)
                                        //            //                {
                                        //            //                    newRun.Append(eachRun.RunProperties.CloneNode(true));
                                        //            //                }
                                        //            //                newRun.Append(newText);
                                        //            //                eachRun.InsertBeforeSelf(newRun);
                                        //            //                eachRun.Remove();

                                        //            //                itemFound = true;
                                        //            //                break;
                                        //            //            }
                                        //            //            else
                                        //            //            {
                                        //            //                eachRun.Remove();
                                        //            //            }
                                        //            //        }
                                        //            //    }
                                        //            //    if (itemFound)
                                        //            //    {
                                        //            //        break;
                                        //            //    }
                                        //            //}

                                        //            Run newNumRun = new Run();

                                        //            Text numT = new Text(strFig.Trim());

                                        //            Text mspce = new Text("\u2003");

                                        //            if (firstRun.RunProperties != null)
                                        //            {
                                        //                newNumRun.AppendChild(firstRun.RunProperties.CloneNode(true));
                                        //            }

                                        //            newNumRun.Append(numT);
                                        //            newNumRun.Append(mspce);

                                        //            newRun.InsertBeforeSelf(newNumRun);
                                        //        }
                                        //    }

                                        //    //goto nextPara;
                                        //}
                                        #endregion
                                    }
                                }
                            }
                        }
                    }

                }
                D.Save();
            }
        }

        //New Logic implemeted by Karan on 02-06-2018
        public static void FigAndTextBetweenEmSpace(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    NormalizeXml = false,
                    RemoveHyperlinks = false,
                    //RemoveComments = false,//commented by Karan on 06-08-2018
                    RemoveContentControls = true,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = false,

                    RemoveEndAndFootNotes = false,
                    RemoveFieldCodes = true,
                    AcceptRevisions = true,
                    //RemoveBookmarks = true,
                    RemoveGoBackBookmark = true,
                    RemoveWebHidden = true,
                    RemoveMarkupForDocumentComparison = true,
                };
                MarkupSimplifier.SimplifyMarkup(WPD, settings);

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                string strParaText = null;
                string strFig = null;
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val.Value == "FIGC" && P.InnerText != null && P.InnerText != "")
                    {
                        if (GlobalMethods.strClientName.ToLower() == "ufl" && GlobalMethods.ValidateRegEx(P.InnerText.Trim(), @"^(Fig\.\s{1,}[0-9]+[\-\—])")) //Developer Name:Priyanka Vishwakarma,Date:25-09-2020,Requirement:FIGC para contains hyphen then space not require for Ufl input.
                        {
                            goto NextPara;
                        }

                        Run firstRun = P.Descendants<Run>().First();
                        strParaText = null;
                        int counter = 0;
                        foreach (Run R in P.Descendants<Run>().ToList())
                        {
                            if (R.RunProperties != null && R.RunProperties.RunStyle != null && R.RunProperties.RunStyle.Val != null && R.RunProperties.RunStyle.Val == "label-Strong")
                            {
                                strFig = null;
                                strFig = MapStylesWithWordTemplate.SearchRegExPatternFirstSearchInstanceOnly(R.InnerText, @"^(Supplemental\s{1,}Video\s{1,}[S][0-9]+)|^(Figure\s[0-9]+\s{0,}[A-Za-z\,\s]+[\-|\—|\–|\:|\.])|^(Figure\s[0-9]+\s{0,}[A-Za-z]\s{0,}[\-|\—|\–][A-Za-z][\-|\—|\–|\:|\.])|^(Figure\s[0-9]+\:)|^(Fig\.\s[0-9]+\:)|^([Fig\.]+)\s([0-9]+[\,]\s[0-9]+)|^(Fig.)+\s+([0-9a-zA-Z]{1,2})|^(Video)+\s+([0-9a-zA-Z]{1,2})|^(Graph)+\s+([0-9a-zA-Z]{1,2})|^((Figure)\s[0-9]+\.)|^((Figure)\s[0-9]+)|(Fig\s[0-9]+\.)|(Figure\s[A-Z][0-9]+\.?)|^(Figure\s[0-9]+[\:|\.])|^(Table\s[0-9]+\:)"); //Developer Name:Priyanka vishwakarma, Date:26-08-2020 ,Requirement:Add pattren for Fig 7, 8 in label-strong text in FIGC para.
                                continue;
                            }
                            else
                            {
                                if (counter < 1)
                                {
                                    if (R.PreviousSibling().LocalName != "commentRangeStart")//Added by Karan on 28-08-2018
                                    {
                                        foreach (Text T in R.Descendants<Text>().ToList())
                                        {
                                            var spacetext = T.InnerText;
                                            spacetext = spacetext.TrimStart();
                                            Text sptext = new Text(spacetext);
                                            R.Append(sptext);
                                            T.Remove();
                                            counter++;
                                        }
                                    }
                                }
                            }
                        }
                        foreach (Run R in P.Descendants<Run>().ToList())
                        {
                            foreach (DocumentFormat.OpenXml.OpenXmlElement ox in R.Elements())
                            {
                                if (ox.XName == W.t)
                                {
                                    strParaText += ox.InnerText;
                                }
                            }
                        }
                        if (firstRun.Descendants<Text>().Count() > 0)
                        {
                            if (strParaText != null)
                            {
                                if (strFig != null)
                                {
                                    if (strParaText.Trim().StartsWith(strFig.Trim()))
                                    {
                                        //remove fig ex:Fig. 1
                                        strParaText = strParaText.Remove(0, strFig.Length);

                                        Run NewRunAfterFigtext = new Run();

                                        if (firstRun.RunProperties != null)
                                        {
                                            NewRunAfterFigtext.Append(firstRun.RunProperties.CloneNode(true));
                                        }

                                        Text numT = new Text(strFig);
                                        NewRunAfterFigtext.Append(numT);

                                        firstRun.InsertAfterSelf(NewRunAfterFigtext);

                                        Run nrunmspace = new Run();
                                        Text nspce = new Text("\u2003");
                                        nrunmspace.Append(nspce);
                                        NewRunAfterFigtext.InsertAfterSelf(nrunmspace);

                                        firstRun.Remove();
                                    }
                                }
                            }
                        }
                    NextPara:
                        {

                        }
                    }

                }
                D.Save();
            }
        }

        public static void TableAndTextBetweenEmSpace(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    NormalizeXml = false,
                    RemoveHyperlinks = false,
                    //RemoveComments = false,//commented by Karan on 06-08-2018
                    RemoveContentControls = true,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = false,//Developer name :Priyanka Vishwakarma. Date:29_5_2019, Requirement:it removes the indentation from the nested list  ,Integrated By:Vikas sir. 

                    RemoveEndAndFootNotes = false,
                    RemoveFieldCodes = true,
                    AcceptRevisions = true,
                    //RemoveBookmarks = true,
                    RemoveGoBackBookmark = true,
                    RemoveWebHidden = true,
                    RemoveMarkupForDocumentComparison = true,
                };
                MarkupSimplifier.SimplifyMarkup(WPD, settings);

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                string strParaText = null;
                string strTable = null;
                bool firstlablestrong = false;
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    firstlablestrong = false;
                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val.Value == "TT" && P.InnerText != null && P.InnerText != "")
                    {

                        if (GlobalMethods.ValidateRegEx(P.InnerText.Trim(), @"^(Table\s{1,}[0-9]+[\-\—\.])|(Table\s[A-Z][0-9]+\.?)")) //Developer Name:Priyanka Vishwakarma,Date:25-09-2020,Requirement:FIGC para contains hyphen then space not require for Ufl input.
                        {
                            goto NextPara;
                        }

                        Run firstRun = P.Descendants<Run>().First();
                        strParaText = null;
                        int counter = 0;
                        foreach (Run R in P.Descendants<Run>().ToList())
                        {
                            if (R.RunProperties != null && R.RunProperties.RunStyle != null && R.RunProperties.RunStyle.Val != null && R.RunProperties.RunStyle.Val == "label-Strong")
                            {
                                if (firstlablestrong == false && GlobalMethods.strClientName.ToLower() == "ufl")
                                {
                                    strTable = null;
                                    strTable = MapStylesWithWordTemplate.SearchRegExPatternFirstSearchInstanceOnly(R.InnerText, @"^(Table [0-9]+\.)");
                                    if (strTable == null)  //Developer Name:Priyanka Vishwakarma Date:06-10-2020,Requirement:Add conditon for table caption for add sapce in UFL input. 
                                    {
                                        strTable = MapStylesWithWordTemplate.SearchRegExPatternFirstSearchInstanceOnly(R.InnerText, @"^(Table [0-9]+)");
                                    }
                                    firstlablestrong = true;
                                    continue;
                                }

                                else if (firstlablestrong == false)
                                {
                                    strTable = null;
                                    strTable = MapStylesWithWordTemplate.SearchRegExPatternFirstSearchInstanceOnly(R.InnerText, @"^(Table\s[0-9]+\:)|^(Table [0-9]+\.)|^(Table [0-9]+)|^(Appendix\s[0-9]+\.)|^(Table\s[0-9]+[A-Z])"); //Add pattern for Table 1A for sage 01-06-2021
                                    firstlablestrong = true;
                                    continue;
                                }
                            }
                            else
                            {
                                if (counter < 1)
                                {
                                    foreach (Text T in R.Descendants<Text>().ToList())
                                    {
                                        var spacetext = T.InnerText;
                                        spacetext = spacetext.TrimStart();
                                        Text sptext = new Text(spacetext);
                                        R.Append(sptext);
                                        T.Remove();
                                        counter++;
                                    }
                                }
                            }
                        }
                        foreach (Run R in P.Descendants<Run>().ToList())
                        {
                            foreach (DocumentFormat.OpenXml.OpenXmlElement ox in R.Elements())
                            {
                                if (ox.XName == W.t)
                                {
                                    strParaText += ox.InnerText;
                                }
                            }
                        }
                        if (firstRun.Descendants<Text>().Count() > 0)
                        {
                            if (strParaText != null)
                            {
                                if (!string.IsNullOrEmpty(strTable) && strTable != null)
                                {
                                    if (strParaText.Trim().StartsWith(strTable.Trim()))
                                    {
                                        //remove fig ex:Fig. 1
                                        strParaText = strParaText.Remove(0, strTable.Length);

                                        Run NewRunAfterFigtext = new Run();

                                        if (firstRun.RunProperties != null)
                                        {
                                            NewRunAfterFigtext.Append(firstRun.RunProperties.CloneNode(true));
                                        }

                                        Text numT = new Text(strTable);
                                        NewRunAfterFigtext.Append(numT);

                                        firstRun.InsertAfterSelf(NewRunAfterFigtext);

                                        Run nrunmspace = new Run();
                                        Text nspce = new Text("\u2002");
                                        nrunmspace.Append(nspce);
                                        NewRunAfterFigtext.InsertAfterSelf(nrunmspace);

                                        firstRun.Remove();
                                    }
                                }
                            }
                        }
                    }
                NextPara: { }
                }
                D.Save();
            }
        }

        public static string SearchRegExPatternFirstSearchInstanceOnly(string strParaContent, string strSearchRegEx)
        {
            Regex regexText = new Regex(strSearchRegEx);

            // Match the regular expression pattern against a text string.
            Match m = regexText.Match(strParaContent);

            if (m.Success)
            {
                return m.Value;
            }

            return null;
        }

        private static bool CheckParaTextAndApplyStyle(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    NormalizeXml = false,
                    RemoveHyperlinks = false,
                    RemoveComments = false,
                    RemoveContentControls = true,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = false,//Developer name :Priyanka Vishwakarma. Date:29_5_2019, Requirement:it removes the indentation from the nested list  ,Integrated By:Vikas sir. 

                    RemoveEndAndFootNotes = false,
                    RemoveFieldCodes = true,
                    AcceptRevisions = true,
                    //RemoveBookmarks = true,
                    RemoveGoBackBookmark = true,
                    RemoveWebHidden = true,
                    RemoveMarkupForDocumentComparison = true,
                };

                MarkupSimplifier.SimplifyMarkup(WPD, settings);

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                bool bBreakRun = false;
                bool bFigCaptionStarts = false;
                bool bCOIStarts = false;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P.HasChildren == true)
                    {
                        if (P.ParagraphProperties != null)
                        {
                            bool bListFound = false;
                            foreach (ParagraphProperties Pr in P.Descendants<ParagraphProperties>().ToList())
                            {
                                bListFound = false;
                            }

                            if (bListFound == true)
                            {
                                bListFound = false;
                                continue;
                            }
                            ////start added by vikas on 18-04-2019
                            bool bciteFig = false;
                            if (P.Descendants<Run>().Count() > 0 && P.Descendants<Run>().FirstOrDefault().Descendants<RunStyle>().Count() > 0 && P.Descendants<Run>().FirstOrDefault().Descendants<RunStyle>().FirstOrDefault().Val == "citefig")
                            {
                                bciteFig = true;
                            }
                            ////end added by vikas on 18-04-2019
                            if (P.ParagraphProperties.ParagraphStyleId != null)
                            {
                                foreach (Run R in P.Descendants<Run>().ToList())
                                {
                                    if (bCOIStarts == true)
                                    {
                                        if (P.ParagraphProperties.ParagraphStyleId.Val == "BodyA")
                                        {
                                            P.ParagraphProperties.ParagraphStyleId.Val = "COI-P";
                                            bCOIStarts = false;
                                            goto NextPara;
                                        }
                                        else
                                        {
                                            bCOIStarts = false;
                                        }
                                    }
                                    if ((P.InnerText.Trim().ToLower().StartsWith("fig.") || P.InnerText.Trim().ToLower().StartsWith("fig ") || P.InnerText.Trim().ToLower().StartsWith("figure ")) && bciteFig == false)//Developer name:Priyanka Vishwakarma ,Date:15-04-2021 ,Requirement:to avoid apply Figc paragraph style when it has heading style. Integrated by:Vikas sir.
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val = "FIGC";
                                        bFigCaptionStarts = true;
                                        goto NextPara;
                                    }
                                    if ((P.InnerText.ToLower().StartsWith("table ") || (P.InnerText.ToLower().Trim().StartsWith("table "))) /*&& P.Descendants<Run>().ToList().FirstOrDefault().Descendants().Any(x => x.LocalName == "b")*/)  ///Developer Name:Priyanka Vishwakarma ,Date:26-08-2020,Requirement:Apply TT Paragraph style only para start wiht table with bold emphasis.  //Developer name:vikas ,Date:13-08-2020 ,Requirement:for apply caption style TT
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val = "TT";
                                        bFigCaptionStarts = true;
                                        goto NextPara;
                                    }
                                    if ((P.InnerText.ToLower().StartsWith("appendix table ")) && GlobalMethods.strClientName.ToLower() == "informs")
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val = "TT";
                                        bFigCaptionStarts = true;
                                        goto NextPara;
                                    }
                                    if ((P.InnerText.ToLower().StartsWith("appendix figure ")) && GlobalMethods.strClientName.ToLower() == "informs")
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val = "FIGC";
                                        bFigCaptionStarts = true;
                                        goto NextPara;
                                    }
                                    if (Regex.Match(P.InnerText.TrimStart(), "(^Lemma ([0-9]+))", RegexOptions.IgnoreCase).Success && GlobalMethods.strClientName.ToLower() == "informs")  //Added by vikas for informs client on 05-09-2020
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val = "LemmaT";
                                        bFigCaptionStarts = true;
                                        goto NextPara;
                                    }
                                    else if (Regex.Match(P.InnerText.TrimStart(), "(^Theorem ([0-9]+))", RegexOptions.IgnoreCase).Success && GlobalMethods.strClientName.ToLower() == "informs")  //Added by vikas for informs client on 05-09-2020
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val = "TheoremT";
                                        bFigCaptionStarts = true;
                                        goto NextPara;
                                    }
                                    else if (Regex.Match(P.InnerText.TrimStart(), "(^Example ([0-9]+))", RegexOptions.IgnoreCase).Success && GlobalMethods.strClientName.ToLower() == "informs")  //Added by vikas for informs client on 05-09-2020
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val = "ExampleT";
                                        bFigCaptionStarts = true;
                                        goto NextPara;
                                    }
                                    else if (Regex.Match(P.InnerText.TrimStart(), "(^Proposition ([0-9]+))", RegexOptions.IgnoreCase).Success && GlobalMethods.strClientName.ToLower() == "informs")  //Added by vikas for informs client on 05-09-2020
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val = "PropositionT";
                                        bFigCaptionStarts = true;
                                        goto NextPara;
                                    }
                                    else if (Regex.Match(P.InnerText.TrimStart(), "(^Assumption ([0-9]+))", RegexOptions.IgnoreCase).Success && GlobalMethods.strClientName.ToLower() == "informs")  //Added by vikas for informs client on 05-09-2020
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val = "AssumptionT";
                                        bFigCaptionStarts = true;
                                        goto NextPara;
                                    }
                                    else if (Regex.Match(P.InnerText.TrimStart(), "(^Remark ([0-9]+))", RegexOptions.IgnoreCase).Success && GlobalMethods.strClientName.ToLower() == "informs")  //Added by vikas for informs client on 05-09-2020
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val = "RemarkT";
                                        bFigCaptionStarts = true;
                                        goto NextPara;
                                    }
                                    else if (Regex.Match(P.InnerText.TrimStart(), "(^Defination ([0-9]+))", RegexOptions.IgnoreCase).Success && GlobalMethods.strClientName.ToLower() == "informs")  //Added by vikas for informs client on 05-09-2020
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val = "DefinationT";
                                        bFigCaptionStarts = true;
                                        goto NextPara;
                                    }
                                    bBreakRun = false;
                                    foreach (Text T in R.Descendants<Text>().ToList())
                                    {
                                        if ((T.Text.ToLower().StartsWith("conflict of interest") || P.InnerText.ToLower().StartsWith("conflict of interest")) || (T.Text.ToLower().StartsWith("conflicts of interest") || P.InnerText.ToLower().StartsWith("conflicts of interest")))    //Developer Name:Priyanka Vishwakarma, Date:17_5_2019 ,Requirement:conflict info come within sec .Because Heading is change as Conflicts of interest. Integrated by :Vikas sir 
                                        {
                                            if (GlobalMethods.strClientName.ToLower() != "ssllc" && GlobalMethods.strClientName.ToLower() != "pps") //Developer Name:Priyanka Vishwakarma, Date:7-2-2022, Requirement: add condition for avoid to apply COI para style
                                            {
                                                P.ParagraphProperties.ParagraphStyleId.Val = "COI";
                                                bCOIStarts = true;                                                
                                            }
                                            goto NextPara;
                                        }
                                        //Developer name :Priyanka Vishwakarma,Date:07022020,Requirement:Apply Figc Paragraph Style for graph and supplementary video ,Integrated by:Vikas sir. 
                                        else if (P.Descendants<Run>().ToList().FirstOrDefault().Descendants().Any(x => x.LocalName == "b") && (P.InnerText.ToLower().StartsWith("fig.") || P.InnerText.ToLower().StartsWith("graph ") || P.InnerText.ToLower().StartsWith("supplementary video ") || P.InnerText.ToLower().StartsWith("supplemental video ") || P.InnerText.ToLower().StartsWith("fig ")) && bciteFig == false)  //Developer name:Priyanka Vishwakarma ,Date:17_09_2019 ,Requirement:to avoid apply Figc paragraph style when it has heading style. Integrated by:Vikas sir.  //27-08-2020 for supplemental video
                                        {
                                            P.ParagraphProperties.ParagraphStyleId.Val = "FIGC";
                                            bFigCaptionStarts = true;
                                            goto NextPara;
                                        }
                                        //---Developer name :Priyanka Vishwakarma Date:26_6_2019 , Requirement:Apply FICG Paragraph style when video citetation given ex(1582_THI_J_jccc_20062019_TEST.docx)  ,Integrated By:Vikas sir.
                                        else if (T.Text.ToLower().StartsWith("video") && P.Descendants<Run>().ToList().FirstOrDefault().Descendants().Any(x => x.LocalName == "b") && (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val.Value != "H1" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "H2" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "H3" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "H4" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "H5" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "H6" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "H7" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "AFFL" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "CORR" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "AU" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "UID" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "DT" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "TI" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "RRH" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "AB" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "AB-TXT" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "KYWD"))//03-02-2021
                                        {
                                            P.ParagraphProperties.ParagraphStyleId.Val = "FIGC";
                                            goto NextPara;
                                        }
                                        //---------------------------------------------------------------------------------------------
                                        else if (T.Text.ToLower().StartsWith("part ") && GlobalMethods.strClientName.ToLower() == "thieme")
                                        {
                                            P.ParagraphProperties.ParagraphStyleId.Val = "PT";
                                        }
                                        else
                                        {
                                            string strSearchRegEx = null;
                                            strSearchRegEx = null;

                                            strSearchRegEx = @"^Video [0-9]+\.[0-9]+\-[0-9]+";
                                            if (GlobalMethods.ValidateRegEx(T.Text, strSearchRegEx) == true)
                                            {
                                                P.ParagraphProperties.ParagraphStyleId.Val = "FIGC";

                                                goto NextPara;

                                            }
                                            if (T.Text.ToLower().StartsWith("") || T.Text.ToLower().StartsWith("•"))
                                            {
                                                bFigCaptionStarts = false;
                                                T.Text = T.Text.Replace("", "");
                                                // T.Text = T.Text.Replace("•", "");   //Developer name:Priyanka Vishwakarma ,Date:29_5_2019 ,  Requirement :Remove Bullet symbol from bullet list from document ,Integrated by:Vikas sir

                                                P.ParagraphProperties.ParagraphStyleId.Val = "BullList";
                                            }
                                            else
                                            {
                                                bFigCaptionStarts = false;
                                            }
                                        }

                                        bBreakRun = true;
                                        break;
                                    }

                                    if (bBreakRun == true)
                                    {
                                        break;
                                    }

                                nextrun:
                                    {

                                    }

                                }
                            }
                        }
                    }
                NextPara: { };
                }

                D.Save();
            }

            return true;
        }

        private static bool ConditionalStyleMapping(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    NormalizeXml = false,
                    RemoveHyperlinks = false,
                    RemoveComments = false,
                    RemoveContentControls = true,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = false,//Developer name :Priyanka Vishwakarma. Date:29_5_2019, Requirement:it removes the indentation from the nested list  ,Integrated By:Vikas sir. 

                    RemoveEndAndFootNotes = false,
                    RemoveFieldCodes = true,
                    AcceptRevisions = true,
                    //RemoveBookmarks = true,
                    RemoveGoBackBookmark = true,
                    RemoveWebHidden = true,
                    RemoveMarkupForDocumentComparison = true,
                };

                MarkupSimplifier.SimplifyMarkup(WPD, settings);

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                bool bBreakRun = false;

                bool secLevel = false;
                string secLevelNum = null;
                int nsecLevelNum = 0;


                bool bPartInfoFound = false;
                Paragraph PrevPara = null;
                Run PrevRun = null;
                DocumentFormat.OpenXml.OpenXmlElement ox = null;
                bool bReferenceSection = false;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P.HasChildren == true)
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId.Val == "Ref-Start")
                                {
                                    bReferenceSection = true;
                                    goto NextPara;
                                }

                                if (P.ParagraphProperties.ParagraphStyleId.Val == "REF")
                                {
                                    bReferenceSection = true;
                                    goto NextPara;
                                }

                                if (P.ParagraphProperties.ParagraphStyleId.Val == "Ref-End")
                                {
                                    bReferenceSection = false;
                                    goto NextPara;
                                }

                                if (P.ParagraphProperties.ParagraphStyleId.Val == "REF1")
                                {
                                    //bReferenceSection = false;
                                    goto NextPara;
                                }

                                if (bReferenceSection == true)
                                {
                                    P.ParagraphProperties.ParagraphStyleId.Val = "REF1";
                                    goto NextPara;
                                }

                                //// Check if the current paragraph is section // 
                                //// If yes then extract the section level number // 
                                //if (P.ParagraphProperties.ParagraphStyleId.Val == "H1" || P.ParagraphProperties.ParagraphStyleId.Val == "H2"
                                //|| P.ParagraphProperties.ParagraphStyleId.Val == "H3" || P.ParagraphProperties.ParagraphStyleId.Val == "H4" ||
                                //P.ParagraphProperties.ParagraphStyleId.Val == "H5")
                                //{
                                //    secLevel = false;

                                //    secLevelNum = P.ParagraphProperties.ParagraphStyleId.Val;
                                //    secLevelNum = secLevelNum.Replace("H", "");

                                //    int n;
                                //    bool isnumeric = int.TryParse(secLevelNum, out n);

                                //    if(isnumeric)
                                //    {
                                //        secLevel = true;
                                //        nsecLevelNum = n;

                                //        // Need to check if next Section level is greater then available section then what has to be done //
                                //    }

                                //    //continue;
                                //}

                                //if(secLevel == true)
                                //{
                                //    if (P.ParagraphProperties.ParagraphStyleId.Val == "BodyA")
                                //    {
                                //        // Check if the complete Paragraph is bold //
                                //        if (CheckifCompleteParaIsBold(P.Descendants<Run>()) == true)
                                //        {
                                //            int nStyleIndex = 0; // nsecLevelNum + 1;

                                //            if (CheckifParaStartWithNumber(P.Descendants<Run>()))
                                //            {
                                //                nStyleIndex = nsecLevelNum;
                                //            }
                                //            else
                                //            {
                                //                nStyleIndex = nsecLevelNum + 1;
                                //            }

                                //            if (nStyleIndex == 1)
                                //                P.ParagraphProperties.ParagraphStyleId.Val = "H1";
                                //            else if (nStyleIndex == 2)
                                //                P.ParagraphProperties.ParagraphStyleId.Val = "H2";
                                //            else if (nStyleIndex == 3)
                                //                P.ParagraphProperties.ParagraphStyleId.Val = "H3";
                                //            else if (nStyleIndex == 4)
                                //                P.ParagraphProperties.ParagraphStyleId.Val = "H4";
                                //            else if (nStyleIndex == 5)
                                //                P.ParagraphProperties.ParagraphStyleId.Val = "H5";
                                //            else if (nStyleIndex == 6)
                                //                P.ParagraphProperties.ParagraphStyleId.Val = "H6";
                                //        }
                                //    }
                                //}

                                bool bOneRound = false;

                                string strParaText = null;
                                strParaText = "";

                                foreach (Run R in P.Descendants<Run>().ToList())
                                {
                                    bBreakRun = false;

                                    if (bPartInfoFound)
                                    {
                                        if (PrevPara != null)
                                        {
                                            ox = R.CloneNode(true);
                                            R.Remove();
                                            //P.Remove();

                                            if (bOneRound == false)
                                            {
                                                Run r = new Run(new Text(": "));
                                                PrevPara.Append(r);
                                                bOneRound = true;
                                            }

                                            PrevPara.Append(ox);

                                            continue;
                                        }
                                    }

                                    bPartInfoFound = false;

                                    bool bFirstT = false;

                                    foreach (Text T in R.Descendants<Text>().ToList())
                                    {
                                        strParaText += T.Text;

                                        if (P.ParagraphProperties.ParagraphStyleId.Val == "Ref-Start")
                                        {
                                            goto NextPara;
                                        }

                                        if (P.ParagraphProperties.ParagraphStyleId.Val == "Ref-End")
                                        {
                                            goto NextPara;
                                        }

                                        if (P.ParagraphProperties.ParagraphStyleId.Val == "REF1")
                                        {
                                            goto NextPara;
                                        }

                                        //if (P.ParagraphProperties.ParagraphStyleId.Val == "H1" || P.ParagraphProperties.ParagraphStyleId.Val == "H2" ||
                                        //    P.ParagraphProperties.ParagraphStyleId.Val == "H3" || P.ParagraphProperties.ParagraphStyleId.Val == "H4" || P.ParagraphProperties.ParagraphStyleId.Val == "H5" ||
                                        //    P.ParagraphProperties.ParagraphStyleId.Val == "H6" && bFirstT == false)
                                        //{
                                        //    //// This code will delete the Heading Numbers from the document //
                                        //    // This code is commented on 18 Dec as this is no longer required //
                                        //    // Heading number to be commented in the XML //

                                        //    // ============== Comment Start =================== //

                                        //    //bFirstT = true;

                                        //    //string strSearchRegEx = null;
                                        //    //strSearchRegEx = null;

                                        //    //strSearchRegEx = @"^[0-9]{1,}\.?[0-9]{1,}?\s";
                                        //    //if (GlobalMethods.ValidateRegEx(T.Text, strSearchRegEx) == true)
                                        //    //{
                                        //    //    string strRetVal = GlobalMethods.RegExSearch(strParaText, strSearchRegEx);

                                        //    //    if (T.Text.StartsWith(strRetVal.Trim()))
                                        //    //    {
                                        //    //        //T.Text = T.Text.Replace(strRetVal, "");
                                        //    //        goto NextPara;
                                        //    //    }
                                        //    //}

                                        //    //strSearchRegEx = @"^[0-9]{1,}\s";
                                        //    //if (GlobalMethods.ValidateRegEx(T.Text, strSearchRegEx) == true)
                                        //    //{
                                        //    //    string strRetVal = GlobalMethods.RegExSearch(strParaText, strSearchRegEx);

                                        //    //    if (T.Text.StartsWith(strRetVal.Trim()))
                                        //    //    {
                                        //    //        //T.Text = T.Text.Replace(strRetVal, "");
                                        //    //        goto NextPara;
                                        //    //    }
                                        //    //}

                                        //    // ==================== Comment End ========================= //

                                        //}
                                    }

                                    //if (strParaText.ToLower().StartsWith("part "))
                                    //{
                                    //    PrevRun = R;
                                    //    PrevPara = P;
                                    //    bPartInfoFound = true;
                                    //    goto NextPara;
                                    //}

                                    //if(GlobalMethods.AuthorInfo != null)
                                    //{
                                    //    if (strParaText.Contains(GlobalMethods.AuthorInfo))
                                    //    {
                                    //        //P.ParagraphProperties.ParagraphStyleId.Val = "AU";
                                    //    }
                                    //}

                                    //if(GlobalMethods.JournalTitle != null)
                                    //{
                                    //    if (strParaText == GlobalMethods.JournalTitle)
                                    //    {
                                    //        P.ParagraphProperties.ParagraphStyleId.Val = "CT";
                                    //    }
                                    //}

                                    //if(GlobalMethods.ArticleNumber != null)
                                    //{
                                    //    if(P.ParagraphProperties.ParagraphStyleId.Val != null)
                                    //    {
                                    //        if(P.ParagraphProperties.ParagraphStyleId.Val == "CT")
                                    //        {
                                    //            if (strParaText == GlobalMethods.ArticleNumber)
                                    //            {
                                    //                P.ParagraphProperties.ParagraphStyleId.Val = "CN-FM";
                                    //            }
                                    //        }
                                    //    }
                                    //}

                                    //if(GlobalMethods.ArticleTitle != null)
                                    //{
                                    //    if (strParaText == GlobalMethods.ArticleTitle)
                                    //    {
                                    //        P.ParagraphProperties.ParagraphStyleId.Val = "CT";
                                    //    }
                                    //}

                                    //if(GlobalMethods.JournalSubTitle != null)
                                    //{
                                    //    if (strParaText == GlobalMethods.JournalSubTitle)
                                    //    {
                                    //        P.ParagraphProperties.ParagraphStyleId.Val = "CT";
                                    //    }
                                    //}

                                    if (strParaText != null)
                                    {
                                        //if (strParaText.ToLower() == "foreword")
                                        //{
                                        //    P.ParagraphProperties.ParagraphStyleId.Val = "CT";
                                        //}

                                        //if (strParaText.ToLower() == "preface")
                                        //{
                                        //    P.ParagraphProperties.ParagraphStyleId.Val = "CT";
                                        //}

                                        //if (strParaText.ToLower() == "acknowledgments")
                                        //{
                                        //    P.ParagraphProperties.ParagraphStyleId.Val = "CT";
                                        //}

                                        //if (strParaText.ToLower() == "contributors")
                                        //{
                                        //    P.ParagraphProperties.ParagraphStyleId.Val = "CT";
                                        //}

                                        //if (strParaText.ToLower() == "abbreviations")
                                        //{
                                        //    P.ParagraphProperties.ParagraphStyleId.Val = "CT";
                                        //}

                                        //if (strParaText.ToLower() == "appendix")
                                        //{
                                        //    P.ParagraphProperties.ParagraphStyleId.Val = "CT";
                                        //}

                                        //if (strParaText == "Article " + GlobalMethods.ArticleNumber + ". " + GlobalMethods.ArticleTitle)
                                        //{
                                        //    // break the Paragraph into two Paragraphs, Article Number & Article Title //
                                        //    Paragraph pp = new Paragraph(new ParagraphProperties());
                                        //    pp.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId();

                                        //    pp.ParagraphProperties.ParagraphStyleId.Val = "CN-FM";

                                        //    Run r = new Run(new Text(GlobalMethods.ArticleNumber));

                                        //    pp.Append(r);

                                        //    P.InsertBeforeSelf<Paragraph>(pp);

                                        //    // Remove Article Number from the Current Paragraph from the start of the paragraph //

                                        //    foreach (Text T in R.Descendants<Text>().ToList())
                                        //    {
                                        //        if(GlobalMethods.ArticleNumber != null)
                                        //        {
                                        //            if (T.Text.StartsWith("Article " + GlobalMethods.ArticleNumber + "."))
                                        //            {
                                        //                T.Text = T.Text.Replace("Article ", "");
                                        //                T.Text = T.Text.Replace(GlobalMethods.ArticleNumber + ". ", "");
                                        //                break;
                                        //            }
                                        //        }
                                        //    }
                                        //}
                                    }

                                    if (bBreakRun == true)
                                        break;
                                }

                                //if(bPartInfoFound == true)
                                //{
                                //    P.Remove();
                                //}

                                bPartInfoFound = false;
                            }
                            else
                            {
                                if (bReferenceSection == true)
                                {
                                    // Since the paragraph style property does not exist then create the new and attach it to the paragraph //

                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId();
                                    P.ParagraphProperties.ParagraphStyleId.Val = "REF1";

                                    goto NextPara;
                                }
                            }
                        }
                    }
                NextPara: { };
                }

                D.Save();
            }

            return true;
        }

        //private static bool ConditionalStyleMappingCont(string newDoc)
        //{
        //    using (WordprocessingDocument WPD = WordprocessingDocument
        //         .Open(newDoc, true))
        //    {
        //        SimplifyMarkupSettings settings = new SimplifyMarkupSettings
        //        {
        //            NormalizeXml = false,
        //            RemoveHyperlinks = false,
        //            RemoveComments = false,
        //            RemoveContentControls = true,
        //            RemoveLastRenderedPageBreak = true,
        //            RemovePermissions = true,
        //            RemoveProof = true,
        //            RemoveRsidInfo = true,
        //            RemoveSmartTags = true,
        //            RemoveSoftHyphens = false,
        //            ReplaceTabsWithSpaces = true,

        //            RemoveEndAndFootNotes = false,
        //            RemoveFieldCodes = true,
        //            AcceptRevisions = true,
        //            RemoveBookmarks = true,
        //            RemoveGoBackBookmark = true,
        //            RemoveWebHidden = true,
        //            RemoveMarkupForDocumentComparison = true,
        //        };

        //        MarkupSimplifier.SimplifyMarkup(WPD, settings);

        //        MainDocumentPart MDP = WPD.MainDocumentPart;

        //        Document D = MDP.Document;

        //        string strParaText = null;
        //        bool bApplyFrontMatter = false;
        //        int nParaNumber = 0;
        //        bool bMoveArticleTitleUp = false;
        //        bool bAutInfoFound = false;

        //        DocumentFormat.OpenXml.OpenXmlElement ox = null;

        //        if (nJournalTitleParaNumber > 0)
        //        {
        //            bApplyFrontMatter = true;
        //        }


        //        if (nJournalTitleParaNumber > nAuthorInfoParaNumber)
        //        {
        //            bMoveArticleTitleUp = true;
        //        }

        //        Paragraph AuPara = null;


        //        foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
        //        {
        //            nParaNumber++;

        //            if (P.HasChildren == true)
        //            {
        //                if (P.ParagraphProperties != null)
        //                {
        //                    if (P.ParagraphProperties.ParagraphStyleId != null)
        //                    {
        //                        strParaText = "";

        //                        foreach (Run R in P.Descendants<Run>().ToList())
        //                        {
        //                            foreach (Text T in R.Descendants<Text>().ToList())
        //                            {
        //                                strParaText += T.Text;
        //                            }
        //                        }

        //                        if (strParaText == null)
        //                            goto NextPara;


        //                        //if (bMoveArticleTitleUp == true)
        //                        //{
        //                        //    if(GlobalMethods.AuthorInfo != null)
        //                        //    {
        //                        //        if (strParaText.ToLower() == GlobalMethods.AuthorInfo.ToLower())
        //                        //        {
        //                        //            // Reset the flag to move Article title up //
        //                        //            bMoveArticleTitleUp = false;

        //                        //            // We will move Author info after chapter Title and Article Sub Title //
        //                        //            AuPara = P;

        //                        //            goto NextPara;
        //                        //        }
        //                        //    }
        //                        //}

        //                        //if(GlobalMethods.JournalTitle != null)
        //                        //{
        //                        //    if (strParaText.ToLower() == GlobalMethods.JournalTitle.ToLower())
        //                        //    {
        //                        //        // We will move Author info after chapter Title and Article Sub Title //

        //                        //        if (AuPara != null)
        //                        //        {
        //                        //            ox = P.CloneNode(true);
        //                        //            P.Remove();
        //                        //            AuPara.InsertBeforeSelf(ox);
        //                        //            goto NextPara;
        //                        //        }
        //                        //    }
        //                        //}

        //                        //if(GlobalMethods.JournalSubTitle != null)
        //                        //{
        //                        //    if (strParaText.ToLower() == GlobalMethods.JournalSubTitle.ToLower())
        //                        //    {
        //                        //        // We will move Author info after chapter Title and Article Sub Title //

        //                        //        if (AuPara != null)
        //                        //        {
        //                        //            ox = P.CloneNode(true);
        //                        //            P.Remove();
        //                        //            AuPara.InsertBeforeSelf(ox);

        //                        //            AuPara = null;

        //                        //            goto NextPara;
        //                        //        }
        //                        //    }
        //                        //}


        //                        //if (nParaNumber == 1)
        //                        //{
        //                        //    if (strParaText.ToLower() != "frontmatter" && bApplyFrontMatter == true)
        //                        //    {
        //                        //        // Insert new Para and add Front Matter text to it //

        //                        //        Paragraph pp = new Paragraph(new ParagraphProperties());
        //                        //        pp.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId();

        //                        //        pp.ParagraphProperties.ParagraphStyleId.Val = "PT";

        //                        //        Run r = new Run(new Text("Frontmatter"));

        //                        //        pp.Append(r);

        //                        //        P.InsertBeforeSelf<Paragraph>(pp);

        //                        //        goto NextPara;
        //                        //    }
        //                        //}
        //                    }
        //                    else
        //                    {
        //                        // In this block Paragraph style is not applied and hence need to create new para style before applying any para style //
        //                        // Para properties exist only need to create new style property //

        //                        strParaText = "";

        //                        foreach (Run R in P.Descendants<Run>().ToList())
        //                        {
        //                            foreach (Text T in R.Descendants<Text>().ToList())
        //                            {
        //                                strParaText += T.Text;

        //                            }
        //                        }

        //                        //if (nParaNumber == 1)
        //                        //{
        //                        //    if (strParaText.ToLower() != "frontmatter" && bApplyFrontMatter == true)
        //                        //    {
        //                        //        // Insert new Para and add Front Matter text to it //

        //                        //        Paragraph pp = new Paragraph(new ParagraphProperties());
        //                        //        pp.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId();

        //                        //        pp.ParagraphProperties.ParagraphStyleId.Val = "PT";

        //                        //        Run r = new Run(new Text("Frontmatter"));

        //                        //        pp.Append(r);

        //                        //        P.InsertBeforeSelf<Paragraph>(pp);

        //                        //        goto NextPara;
        //                        //    }
        //                        //}
        //                    }
        //                }
        //            }
        //            NextPara: { };
        //        }

        //        D.Save();
        //    }

        //    return true;
        //}

        private static int CheckIfTheParaTextInTheDocument(string newDoc, string strLookupText)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    NormalizeXml = false,
                    RemoveHyperlinks = false,
                    RemoveComments = false,
                    RemoveContentControls = true,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = false,//Developer name :Priyanka Vishwakarma. Date:29_5_2019, Requirement:it removes the indentation from the nested list  ,Integrated By:Vikas sir. 

                    RemoveEndAndFootNotes = false,
                    RemoveFieldCodes = true,
                    AcceptRevisions = true,
                    RemoveBookmarks = true,
                    RemoveGoBackBookmark = true,
                    RemoveWebHidden = true,
                    RemoveMarkupForDocumentComparison = true,
                };

                MarkupSimplifier.SimplifyMarkup(WPD, settings);

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                string strParaText = null;
                int nParaIndex = 0;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    nParaIndex++;

                    if (P.HasChildren == true)
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null)
                            {
                                strParaText = "";

                                foreach (Run R in P.Descendants<Run>().ToList())
                                {
                                    foreach (Text T in R.Descendants<Text>().ToList())
                                    {
                                        strParaText += T.Text;
                                    }
                                }

                                if (strParaText == strLookupText)
                                {
                                    return nParaIndex;
                                }
                            }
                            else
                            {
                                // In this block Paragraph style is not applied and hence need to create new para style before applying any para style //
                                // Para properties exist only need to create new style property //

                                strParaText = "";

                                foreach (Run R in P.Descendants<Run>().ToList())
                                {
                                    foreach (Text T in R.Descendants<Text>().ToList())
                                    {
                                        strParaText += T.Text;
                                    }
                                }

                                if (strParaText == strLookupText)
                                {
                                    return nParaIndex;
                                }
                            }
                        }
                    }
                }
            }

            return 0;
        }

        private static bool CheckifParaStartWithNumber(IEnumerable<Run> RunColl)
        {
            foreach (Run R in RunColl.ToList())
            {
                string strParaText = null;

                if (R.HasChildren == true)
                {
                    foreach (Text T in R.Descendants<Text>().ToList())
                    {
                        strParaText += T.Text;

                        string strSearchRegEx = null;
                        strSearchRegEx = null;

                        strSearchRegEx = @"^[0-9]{1,}\.?[0-9]{1,}?\s";
                        if (GlobalMethods.ValidateRegEx(strParaText, strSearchRegEx) == true)
                        {
                            string strRetVal = GlobalMethods.RegExSearch(strParaText, strSearchRegEx);

                            if (T.Text.StartsWith(strRetVal.Trim()))
                            {
                                return true;
                            }
                        }

                        strSearchRegEx = @"^[0-9]{1,}\s";
                        if (GlobalMethods.ValidateRegEx(strParaText, strSearchRegEx) == true)
                        {
                            string strRetVal = GlobalMethods.RegExSearch(strParaText, strSearchRegEx);

                            if (T.Text.StartsWith(strRetVal.Trim()))
                            {
                                return true;
                            }
                        }
                    }
                }
            }

            return false;
        }

        private static bool CheckifCompleteParaIsBold(IEnumerable<Run> RunColl)
        {
            bool bcompleteParaIsBold = false;

            foreach (Run R in RunColl.ToList())
            {
                if (R.HasChildren == true)
                {
                    if (R.RunProperties != null)
                    {
                        if (R.RunProperties.Bold != null)
                        {
                            bcompleteParaIsBold = true;
                        }
                        else
                        {
                            bcompleteParaIsBold = false;
                            return false;
                        }
                    }
                    else
                    {
                        bcompleteParaIsBold = false;
                        return false;
                    }
                }
                else
                {
                    bcompleteParaIsBold = false;
                    return false;
                }
            }

            if (bcompleteParaIsBold)
                return true;

            return false;
        }

        private static void CreateFigParaAfterFigCaption(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    NormalizeXml = false,
                    RemoveHyperlinks = false,
                    RemoveComments = false,
                    RemoveContentControls = true,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = false,//Developer name :Priyanka Vishwakarma. Date:29_5_2019, Requirement:it removes the indentation from the nested list  ,Integrated By:Vikas sir. 

                    RemoveEndAndFootNotes = false,
                    RemoveFieldCodes = true,
                    AcceptRevisions = true,
                    RemoveBookmarks = true,
                    RemoveGoBackBookmark = true,
                    RemoveWebHidden = true,
                    RemoveMarkupForDocumentComparison = true,
                };

                MarkupSimplifier.SimplifyMarkup(WPD, settings);

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P.HasChildren == true)
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId.Val == "FIGC")
                                {
                                    //Paragraph pp = new Paragraph(new ParagraphProperties());
                                    //pp.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId();

                                    //pp.ParagraphProperties.ParagraphStyleId.Val = "FIG";

                                    //P.InsertAfterSelf<Paragraph>(pp);

                                    continue;
                                }
                            }
                        }
                    }
                }

                D.Save();
            }
        }

        public static void CheckAllPara(string newDoc)
        {
            GlobalMethods.LableStrongStyle = ConfigurationManager.AppSettings.Get("LableStrongStyle");
            List<string> LableStrongPatternsColl = new List<string>();

            ///Configuration read from Supporting folder
            LableStrongPatternsColl = GlobalMethods.ReadAndStoreFileValuesInArray(GlobalMethods.LableStrongStyle);

            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    bool labelStrongApply = false;  //Developer Name:Priyanka Vishwakarma. Date:17_10_2019 ,Requirement:apply label-strong character style when bold text contains comment ,Integrated by:Vikas sir.
                    if (P != null && P.InnerText != "")
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId.Val != null)
                                {
                                    if ((P.InnerText.ToLower().StartsWith("appendix table ") || P.InnerText.ToLower().StartsWith("appendix figure ") && GlobalMethods.strClientName.ToLower() == "informs"))
                                    {
                                        continue;
                                    }
                                    if (P.ParagraphProperties.ParagraphStyleId.Val.Value == "FIGC" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "TT")
                                    {
                                        string paraText = P.InnerText;

                                        foreach (var figpattern in LableStrongPatternsColl.ToList())
                                        {
                                            string match = GlobalMethods.SearchRegEx(paraText.TrimStart(' '), figpattern);



                                            if (match != "")
                                            {
                                                string runtext = null;
                                                List<Run> matchingrun = new List<Run>();
                                                foreach (Run R in P.Descendants<Run>().ToList())
                                                {
                                                    if (R.RunProperties != null && R.RunProperties.RunStyle != null && R.RunProperties.RunStyle.Val != null && R.RunProperties.RunStyle.Val.Value == "label-Strong")
                                                    {
                                                        break;
                                                    }
                                                    else if (R.RunProperties != null && R.RunProperties.Descendants().Any(x => x.XName.LocalName == "rStyle"))
                                                    {
                                                        var runstyle = (RunStyle)R.RunProperties.Descendants().Where(x => x.XName.LocalName == "rStyle").FirstOrDefault();  // 8_4_2019 Typecasting for check runstyle val not coming directly ..
                                                        if (runstyle.Val == "label-Strong")
                                                        {
                                                            break;
                                                        }
                                                    }
                                                    foreach (var item in R.Descendants<Text>().ToList())
                                                    {
                                                        foreach (var item1 in item.GetAttributes().ToList())
                                                        {
                                                            if (item1.XName.LocalName == "space")
                                                            {
                                                                var r = item1;
                                                                r.Value = SpaceProcessingModeValues.Default.ToString();
                                                            }
                                                        }
                                                    }
                                                    //runtext += R.InnerText.Trim();
                                                    runtext += R.InnerText; //Developer Name:Priyanka Vishwakarma. Date:17_10_2019 ,Requirement:apply label-strong character style when bold text contains comment ,Integrated by:Vikas sir.
                                                    string runmatch = GlobalMethods.SearchRegEx(runtext.TrimStart(' '), figpattern);

                                                    if (runmatch == "")
                                                    {
                                                        matchingrun.Add(R);
                                                        continue;
                                                    }
                                                    else if (P.Descendants<Run>().Count() == 1)
                                                    {
                                                        string withoutlablestrongtxt = runtext.Replace(runmatch, "");

                                                        Run r1 = new Run(new RunProperties(new RunStyle { Val = "label-Strong" }));

                                                        Text t1 = new Text(runmatch);
                                                        r1.Append(t1);

                                                        Run r2 = new Run();
                                                        Text t2 = null;
                                                        if (withoutlablestrongtxt.StartsWith(""))
                                                        {
                                                            Text runspace = new Text { Text = " ", Space = SpaceProcessingModeValues.Preserve };
                                                            t2 = new Text(withoutlablestrongtxt.TrimStart(' '));
                                                            r2.Append(runspace);
                                                            r2.Append(t2);
                                                        }
                                                        else
                                                        {
                                                            t2 = new Text(withoutlablestrongtxt);
                                                            r2.Append(t2);
                                                        }



                                                        R.Remove();

                                                        P.Append(r1);

                                                        P.Append(r2);

                                                        break;

                                                    }
                                                    else
                                                    {
                                                        matchingrun.Add(R);

                                                        foreach (Run run in matchingrun)
                                                        {
                                                            if (run.RunProperties != null)
                                                            {
                                                                if (run.RunProperties.RunStyle != null)
                                                                {
                                                                    ///Added by Karan on 01-09-2018 Start
                                                                    if (run.RunProperties.RunStyle.Val == "Strong")
                                                                    {
                                                                        Bold bold = new Bold();
                                                                        run.RunProperties.AppendChild(bold);
                                                                        run.RunProperties.RunStyle.Val = null;
                                                                    }
                                                                    ///Added by Karan on 01-09-2018 End
                                                                    if (run.RunProperties.RunStyle.Val == null)
                                                                    {
                                                                        run.RunProperties.RunStyle = new RunStyle() { Val = "label-Strong" };
                                                                    }
                                                                    else if (run.RunProperties.RunStyle.Val != "label-Strong")
                                                                    {
                                                                        run.RunProperties.RunStyle.Val.Value = "label-Strong";
                                                                    }
                                                                }
                                                                else
                                                                {
                                                                    //---Added  by Priyanka on 9_4_2019 for inserting rstyle in run property.
                                                                    //Run r1 = new Run(new RunProperties(new RunStyle { Val = "label-Strong" }));
                                                                    //Text t1 = new Text(runmatch);
                                                                    //r1.Append(t1);
                                                                    //P.ReplaceChild(r1, run);

                                                                    //---End by Priyanka on 9_4_2019 for inserting rstyle in run property.
                                                                    //---Added  by Priyanka on 9_4_2019 for inserting rstyle in run property.
                                                                    if (labelStrongApply == false)  //Developer Name:Priyanka Vishwakarma. Date:17_10_2019 ,Requirement:apply label-strong character style when bold text contains comment ,Integrated by:Vikas sir.
                                                                    {
                                                                        if (GlobalMethods.strClientName.ToLower() == "ufl")   //Developer name:Priyanka Vishwakarma,Date:14-08-2020,Requirement:apply label-strong for ufl doc.
                                                                        {
                                                                            Run r1 = new Run(new RunProperties(new RunStyle { Val = "label-Strong" }));

                                                                            string withoutlablestrongtxt = runtext.Replace(runmatch, "");

                                                                            Text t1 = new Text(runmatch);
                                                                            r1.Append(t1);

                                                                            Run r2 = new Run();
                                                                            Text t2 = new Text(withoutlablestrongtxt);
                                                                            r2.Append(t2);

                                                                            P.ReplaceChild(r1, run);
                                                                            r1.InsertAfterSelf(r2);

                                                                        }
                                                                        else
                                                                        {
                                                                            Run r1 = new Run(new RunProperties(new RunStyle { Val = "label-Strong" }));
                                                                            ////Developer name:Priyanka Vishwakarma .Date:31-01-2020 ,Requirement:Table Caption comes without sapce within Table and number ex.Table1 ,Integrated by:Vikas sir.
                                                                            //string TableWithoutSpace = null;
                                                                            //TableWithoutSpace = MapStylesWithWordTemplate.SearchRegExPatternFirstSearchInstanceOnly(R.InnerText, @"^(Table[0-9a-zA-Z]{1,2})");
                                                                            //if (!string.IsNullOrEmpty(TableWithoutSpace))
                                                                            //{
                                                                            //    runmatch = runmatch.Replace("Table", "Table ");
                                                                            //}
                                                                            ////------------------------------End---------------------------------------------------------------------------------
                                                                            //Developer Name:Priyanka Vishwakarma,Date:01-10-2020,Requirement:Add condition for Adding run without label strong in another run
                                                                            if (runtext.Trim() == runmatch.Trim())
                                                                            {
                                                                                if (runtext.EndsWith(" "))
                                                                                {
                                                                                    Text t1 = new Text(runmatch);
                                                                                    r1.Append(t1);
                                                                                    Run runspace = new Run((new Text { Text = " ", Space = SpaceProcessingModeValues.Preserve }));
                                                                                    P.ReplaceChild(r1, run);
                                                                                    r1.InsertAfterSelf(runspace);


                                                                                }
                                                                                else
                                                                                {
                                                                                    Text t1 = new Text(runmatch);
                                                                                    r1.Append(t1);
                                                                                    P.ReplaceChild(r1, run);
                                                                                }
                                                                            }
                                                                            else
                                                                            {
                                                                                string withoutlablestrongtxt = runtext.Replace(runmatch, "");

                                                                                Text t1 = new Text(runmatch);
                                                                                r1.Append(t1);
                                                                                Run r2 = new Run();
                                                                                if (!string.IsNullOrEmpty(withoutlablestrongtxt))
                                                                                {

                                                                                    if (withoutlablestrongtxt.StartsWith(" "))//Developer Name:Priyanka Vishwkarma,Date:07-07-2021,Requirement:Add space after label strong
                                                                                    {
                                                                                        Text runspace = new Text { Text = " ", Space = SpaceProcessingModeValues.Preserve };
                                                                                        r2.Append(runspace);
                                                                                        Text t2 = new Text(withoutlablestrongtxt.TrimStart(' '));
                                                                                        r2.Append(t2);
                                                                                    }
                                                                                    else
                                                                                    {
                                                                                        Text t2 = new Text(withoutlablestrongtxt);
                                                                                        r2.Append(t2);
                                                                                    }

                                                                                }

                                                                                P.ReplaceChild(r1, run);
                                                                                r1.InsertAfterSelf(r2);

                                                                            }

                                                                        }
                                                                        labelStrongApply = true;
                                                                    }
                                                                    else
                                                                    {
                                                                        run.Remove();
                                                                    }
                                                                    //--------------END----------------------------------------

                                                                    //RunStyle rstyle = new RunStyle() { Val = "label-Strong" };  //Commented by Priyanka on 9_4_2019 for inserting rstyle in run property not Properly.
                                                                    // run.RunProperties.Append(rstyle.CloneNode(true));
                                                                }
                                                            }
                                                            else
                                                            {
                                                                if (GlobalMethods.strClientName.ToLower() == "ufl") //Developer name:Priyanka Vishwakarma,Date:14-08-2020,Requirement:apply label-strong for ufl doc.
                                                                {
                                                                    string withoutlablestrongtxt = runtext.Replace(runmatch, "");

                                                                    Run r1 = new Run(new RunProperties(new RunStyle { Val = "label-Strong" }));

                                                                    Text t1 = new Text(runmatch);
                                                                    r1.Append(t1);

                                                                    Run r2 = new Run();
                                                                    Text t2 = new Text(withoutlablestrongtxt);
                                                                    r2.Append(t2);

                                                                    P.ReplaceChild(r1, run);
                                                                    r1.InsertAfterSelf(r2);

                                                                }
                                                                else
                                                                {
                                                                    RunProperties runprop = new RunProperties();
                                                                    RunStyle rstyle = new RunStyle() { Val = "label-Strong" };

                                                                    runprop.Append(rstyle.CloneNode(true));


                                                                    run.Append(runprop.CloneNode(true));
                                                                }


                                                            }
                                                        }

                                                        break;
                                                    }
                                                    break;  //Added  by Priyanka on 8_4_2019
                                                }
                                            }
                                        }

                                    }
                                }
                            }
                        }
                    }
                }
                D.Save();
            }
        }


        ///New Function added by Karan on 20-6-2018
        public static void NewApplyTableStyles(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    //RemoveComments = true,//commented by Karan on 06-08-2018
                    RemoveContentControls = true,
                    RemoveEndAndFootNotes = false,
                    RemoveFieldCodes = true,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = false,//Developer name :Priyanka Vishwakarma. Date:29_5_2019, Requirement:it removes the indentation from the nested list  ,Integrated By:Vikas sir. 
                };

                MarkupSimplifier.SimplifyMarkup(WPD, settings);

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                //bool bShading = false;

                Dictionary<Single, string> strTableIndent = new Dictionary<Single, string>();
                strTableIndent.Clear();

                Single leftInd = 0;
                int nColIndex = 0;

                string strStyle = null;
                string strRunText = null;

                leftInd = 0;
                Single tcMarLeftMargin = 0;

                string strTableParaStyle = null;  ////Developer Name:Priyanka Vishwakarma ,Date:21_5_2019 ,Requirement:Listing tag should be added within table ,Integrated by:Vikas Sir

                foreach (OpenXmlElement xe in D.Elements<OpenXmlElement>().ToList())
                {
                    if (xe.LocalName == "body")
                    {
                        if (xe.HasChildren)
                        {
                            foreach (OpenXmlElement xRootChild in xe.Elements<OpenXmlElement>().ToList())
                            {
                                if (xRootChild.LocalName == "tbl")
                                {
                                    leftInd = 0;
                                    strTableIndent.Clear();
                                    strRunText = null;

                                    foreach (OpenXmlElement xChild in xRootChild.Elements<OpenXmlElement>().ToList())
                                    {
                                        if (xChild.LocalName == "tr")
                                        {
                                            ///bShading = false;
                                            strStyle = null;
                                            tcMarLeftMargin = 0;
                                            nColIndex = 0;
                                            strRunText = null;

                                            if (xChild.HasChildren)
                                            {
                                                foreach (OpenXmlElement xChild1 in xChild.Elements<OpenXmlElement>().ToList())
                                                {

                                                    nColIndex = 0;   //19_10_2019  Developer Name:Priyanka Vishwakarma ,Date:19_10_2019 ,Requirement :check each table row cell has indent ,Integrated by :Vikas sir.
                                                    if (xChild1.LocalName == "tc")
                                                    {
                                                        nColIndex++;
                                                        if (xChild1.HasChildren)
                                                        {
                                                            foreach (OpenXmlElement xChild2 in xChild1.Elements<OpenXmlElement>().ToList())
                                                            {
                                                                strStyle = null;   //Developer name:Priyanka Vishwakarma ,Date:16_09_2019,Requirement:Add Indend within table 2889_THI_J_JNRP-351-18 
                                                                if (xChild2.XName == W.p)
                                                                {
                                                                    bool bParaPropertiesFound = false;
                                                                    bool bParaStyleApplied = false;
                                                                    OpenXmlElement opPr = null;
                                                                    OpenXmlElement xParaEle = null;
                                                                    OpenXmlElement opStyle = null;
                                                                    strRunText = null;

                                                                    Single nLeftInd = 0;
                                                                    Single nHangingInd = 0;
                                                                    Single nFirstLineInd = 0;

                                                                    xParaEle = xChild2;

                                                                    if (xChild2.HasChildren)
                                                                    {
                                                                        strTableParaStyle = null;  //Developer Name:Priyanka Vishwakarma ,Date:21_5_2019 ,Requirement:Listing tag should be added within table ,Integrated by:Vikas Sir
                                                                        foreach (OpenXmlElement xChild3 in xChild2.Elements<OpenXmlElement>().ToList())
                                                                        {
                                                                            if (xChild3.XName == W.pPr)
                                                                            {
                                                                                if (xChild2.Elements().Where(x => x.XName == W.pPr).ToList().Count > 0 && xChild2.Elements().Where(x => x.XName == W.pPr).FirstOrDefault().Elements().Where(x => x.XName == W.pStyle).ToList().Count > 0 && xChild2.Elements().Where(x => x.XName == W.pPr).FirstOrDefault().Elements().Where(x => x.XName == W.pStyle).FirstOrDefault().GetAttribute("val", xChild2.NamespaceUri).Value != "")
                                                                                {
                                                                                    strTableParaStyle = xChild2.Elements().Where(x => x.XName == W.pPr).FirstOrDefault().Elements().Where(x => x.XName == W.pStyle).FirstOrDefault().GetAttribute("val", xChild2.NamespaceUri).Value;  ////Developer Name:Priyanka Vishwakarma ,Date:21_5_2019 ,Requirement:Listing tag should be added within table ,Integrated by:Vikas Sir

                                                                                }
                                                                                bParaPropertiesFound = true;
                                                                                opPr = xChild3;
                                                                                if (xChild3.HasChildren)
                                                                                {

                                                                                    foreach (OpenXmlElement xChild4 in xChild3.Elements<OpenXmlElement>().ToList())
                                                                                    {
                                                                                        if (xChild4.XName == W.pStyle)
                                                                                        {

                                                                                            if (((DocumentFormat.OpenXml.Wordprocessing.StringType)xChild4).Val == "TCH")
                                                                                            {
                                                                                                goto nexttr;
                                                                                            }
                                                                                            else
                                                                                            {
                                                                                                bParaStyleApplied = true;
                                                                                                opStyle = xChild4;
                                                                                            }
                                                                                        }

                                                                                        else if (xChild4.XName == W.ind)
                                                                                        {
                                                                                            if (((DocumentFormat.OpenXml.Wordprocessing.Indentation)xChild4).Left != null)
                                                                                            {
                                                                                                nLeftInd = Convert.ToSingle(((DocumentFormat.OpenXml.Wordprocessing.Indentation)xChild4).Left.Value);
                                                                                            }

                                                                                            if (((DocumentFormat.OpenXml.Wordprocessing.Indentation)xChild4).Hanging != null)
                                                                                            {
                                                                                                nHangingInd = Convert.ToSingle(((DocumentFormat.OpenXml.Wordprocessing.Indentation)xChild4).Hanging.Value);
                                                                                            }

                                                                                            if (((DocumentFormat.OpenXml.Wordprocessing.Indentation)xChild4).FirstLine != null)
                                                                                            {
                                                                                                nFirstLineInd = Convert.ToSingle(((DocumentFormat.OpenXml.Wordprocessing.Indentation)xChild4).FirstLine.Value);
                                                                                            }

                                                                                        }

                                                                                        else if (xChild4.XName == W.jc)
                                                                                        {
                                                                                            if (((DocumentFormat.OpenXml.Wordprocessing.Justification)xChild4).Val != null)
                                                                                            {
                                                                                                if (((DocumentFormat.OpenXml.Wordprocessing.Justification)xChild4).Val == "center")
                                                                                                {
                                                                                                    tcMarLeftMargin = 0;
                                                                                                    nLeftInd = 0;
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                            else if (xChild3.XName == W.r)
                                                                            {
                                                                                if (xChild3.HasChildren)
                                                                                {
                                                                                    foreach (OpenXmlElement xChild4 in xChild3.Elements<OpenXmlElement>().ToList())
                                                                                    {
                                                                                        if (xChild4.XName == W.t)
                                                                                        {
                                                                                            if (nColIndex == 1)
                                                                                            {
                                                                                                strRunText += xChild4.InnerText;
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                    if (bParaPropertiesFound == false)
                                                                    {
                                                                        // Create new Paragraph properties

                                                                        ((DocumentFormat.OpenXml.Wordprocessing.Paragraph)xParaEle).ParagraphProperties = new ParagraphProperties();
                                                                        opPr = ((DocumentFormat.OpenXml.Wordprocessing.Paragraph)xParaEle).ParagraphProperties;

                                                                        bParaPropertiesFound = true;
                                                                    }
                                                                    if (nColIndex == 1)
                                                                    {
                                                                        if (tcMarLeftMargin <= 43)
                                                                        {
                                                                            tcMarLeftMargin = 0;
                                                                        }

                                                                        if (tcMarLeftMargin != 0)
                                                                        {
                                                                            if (tcMarLeftMargin > nLeftInd)
                                                                                nLeftInd = tcMarLeftMargin;
                                                                        }

                                                                        if (nFirstLineInd != 0)
                                                                        {
                                                                            if (nFirstLineInd > nLeftInd)
                                                                                nLeftInd = nFirstLineInd;
                                                                        }

                                                                        if ((nLeftInd - nHangingInd) > 0)
                                                                        {
                                                                            leftInd = nLeftInd;
                                                                        }
                                                                        else
                                                                        {
                                                                            leftInd = 0;
                                                                        }

                                                                        if (strRunText == null || strRunText == "")
                                                                        {
                                                                            strRunText = null;
                                                                            strStyle = "T-TXT";
                                                                            goto applystyle1;
                                                                        }
                                                                        // Developer Name:Ashwini Desai .Date:28_11_2019 ,Requirement:Add tablebodyindent style into Table. Integrated by :Vikas sir.
                                                                        if (leftInd != 0 && leftInd <= 720)// If the list has values then compare the Indent with list indent and then apply the style
                                                                        {
                                                                            if (!strTableIndent.ContainsKey(leftInd))
                                                                            {
                                                                                strTableIndent.Add(leftInd, "TableBodyIndent1");
                                                                            }
                                                                        }
                                                                        else if (leftInd > 720 && leftInd <= 1440)// If the list has values then compare the Indent with list indent and then apply the style
                                                                        {
                                                                            if (!strTableIndent.ContainsKey(leftInd))
                                                                            {
                                                                                strTableIndent.Add(leftInd, "TableBodyIndent2");
                                                                            }
                                                                        }
                                                                        else if (leftInd > 1440)// If the list has values then compare the Indent with list indent and then apply the style
                                                                        {
                                                                            if (!strTableIndent.ContainsKey(leftInd))
                                                                            {
                                                                                strTableIndent.Add(leftInd, "TableBodyIndent3");
                                                                            }
                                                                        }
                                                                        // -----------------------------------
                                                                        if (strTableIndent.Count <= 0)
                                                                        {
                                                                            strTableIndent.Clear();
                                                                            // If no value in List then apply table body
                                                                            strTableIndent.Add(leftInd, "T-TXT");

                                                                            strStyle = "T-TXT";
                                                                            goto applystyle1;
                                                                        }
                                                                        else
                                                                        {
                                                                            // If the list has values then compare the Indent with list indent and then apply the style
                                                                            if (strTableIndent.ContainsKey(leftInd))
                                                                            {
                                                                                strStyle = strTableIndent[leftInd];

                                                                                if (strStyle != null || strStyle != "")
                                                                                {
                                                                                    if (strStyle == "T-TXT")
                                                                                    {
                                                                                        strTableIndent.Clear();
                                                                                        strTableIndent.Add(leftInd, "T-TXT");
                                                                                    }
                                                                                    goto applystyle1;
                                                                                }
                                                                                else
                                                                                {
                                                                                    strTableIndent.Clear();
                                                                                    strStyle = "T-TXT";

                                                                                    goto applystyle1;
                                                                                }
                                                                            }
                                                                            else
                                                                            {
                                                                                strTableIndent = GlobalMethods.SortDictionaryOnKeyWithNumber(strTableIndent);

                                                                                strStyle = ExtractStyleNameFromDictionary(strTableIndent, leftInd);

                                                                                if (strStyle == null)
                                                                                {
                                                                                    strStyle = "T-TXT";
                                                                                }

                                                                                if (strStyle == "T-TXT")
                                                                                {
                                                                                    strTableIndent.Clear();
                                                                                    strTableIndent.Add(leftInd, "T-TXT");
                                                                                }
                                                                                goto applystyle1;
                                                                            }
                                                                        }
                                                                    applystyle1:
                                                                        {
                                                                            if (((DocumentFormat.OpenXml.Wordprocessing.ParagraphProperties)opPr).ParagraphStyleId == null)
                                                                                ((DocumentFormat.OpenXml.Wordprocessing.ParagraphProperties)opPr).ParagraphStyleId = new ParagraphStyleId();
                                                                            // Developer Name:Priyanka Vishwakarma .Date:04_11_2019 ,Requirement:Add NumList Within Table. Integrated by :Vikas sir.
                                                                            if (strStyle != null && !string.IsNullOrEmpty(strTableParaStyle) && (strTableParaStyle.ToLower().Trim() != "bulllist" && strTableParaStyle.ToLower().Trim() != "nl"))
                                                                            {
                                                                                ((DocumentFormat.OpenXml.Wordprocessing.ParagraphProperties)opPr).ParagraphStyleId.Val = strStyle;
                                                                            }
                                                                            else if (!string.IsNullOrEmpty(strTableParaStyle) && (strTableParaStyle.ToLower().Trim() == "bulllist" || strTableParaStyle.ToLower().Trim() == "nl")) //04_11_2019 ////Developer Name:Priyanka Vishwakarma ,Date:21_5_2019 ,Requirement:Listing tag should be added within table ,Integrated by:Vikas Sir
                                                                            {
                                                                                ((DocumentFormat.OpenXml.Wordprocessing.ParagraphProperties)opPr).ParagraphStyleId.Val = strTableParaStyle;
                                                                            }
                                                                            else
                                                                            {
                                                                                ((DocumentFormat.OpenXml.Wordprocessing.ParagraphProperties)opPr).ParagraphStyleId.Val = "T-TXT";
                                                                            }
                                                                            //=--------------------END------------------------------------------------------------

                                                                            // ((DocumentFormat.OpenXml.Wordprocessing.ParagraphProperties)opPr).ParagraphStyleId.Val = strStyle;
                                                                        }
                                                                    }
                                                                    else if (nColIndex > 1)
                                                                    {
                                                                        if (((DocumentFormat.OpenXml.Wordprocessing.ParagraphProperties)opPr).ParagraphStyleId == null)
                                                                            ((DocumentFormat.OpenXml.Wordprocessing.ParagraphProperties)opPr).ParagraphStyleId = new ParagraphStyleId();

                                                                        if (strStyle != null && !string.IsNullOrEmpty(strTableParaStyle) && strTableParaStyle.ToLower().Trim() != "bulllist")
                                                                        {
                                                                            ((DocumentFormat.OpenXml.Wordprocessing.ParagraphProperties)opPr).ParagraphStyleId.Val = strStyle;
                                                                        }
                                                                        else if (!string.IsNullOrEmpty(strTableParaStyle) && (strTableParaStyle.ToLower().Trim() == "bulllist" || strTableParaStyle.ToLower().Trim() == "nl")) //04_11_2019 ////Developer Name:Priyanka Vishwakarma ,Date:21_5_2019 ,Requirement:Listing tag should be added within table ,Integrated by:Vikas Sir
                                                                        {
                                                                            ((DocumentFormat.OpenXml.Wordprocessing.ParagraphProperties)opPr).ParagraphStyleId.Val = strTableParaStyle;
                                                                        }
                                                                        else
                                                                        {

                                                                            ((DocumentFormat.OpenXml.Wordprocessing.ParagraphProperties)opPr).ParagraphStyleId.Val = "T-TXT";
                                                                        }

                                                                        //((DocumentFormat.OpenXml.Wordprocessing.ParagraphProperties)opPr).ParagraphStyleId.Val = "T-TXT";
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    nexttr: { };
                                    }
                                }
                            }
                        }
                    }
                }

                D.Save();
            }
        }

        ///New Function added by Karan on 20-6-2018
        private static string ExtractStyleNameFromDictionary(Dictionary<Single, string> strTableIndent, Single leftInd)
        {
            string strStyle = null;

            foreach (KeyValuePair<Single, string> item in strTableIndent)
            {
                if (leftInd < item.Key)
                {
                    if (item.Value == "T-TXT")
                    {
                        strStyle = "T-TXT";
                        strTableIndent.Add(leftInd, strStyle);
                        return strStyle;
                    }

                    else if (item.Value == "TableBodyIndent1")
                    {
                        strStyle = "T-TXT";
                        strTableIndent.Add(leftInd, strStyle);
                        return strStyle;
                    }

                    else if (item.Value == "TableBodyIndent2")
                    {
                        strStyle = "TableBodyIndent1";
                        strTableIndent.Add(leftInd, strStyle);
                        return strStyle;
                    }

                    else if (item.Value == "TableBodyIndent3")
                    {
                        strStyle = "TableBodyIndent2";
                        strTableIndent.Add(leftInd, strStyle);
                        return strStyle;
                    }
                    else
                    {
                        strStyle = "T-TXT"; //Changed by Manish on 23-05-2018
                        strTableIndent.Add(leftInd, strStyle);
                        return strStyle;
                    }
                }

                strStyle = item.Value;
            }

            if (strStyle == "T-TXT")
            {
                strStyle = "TableBodyIndent1";
                strTableIndent.Add(leftInd, strStyle);
                return strStyle;
            }
            else if (strStyle == "TableBodyIndent1")
            {
                strStyle = "TableBodyIndent2";
                strTableIndent.Add(leftInd, strStyle);
                return strStyle;
            }
            else if (strStyle == "TableBodyIndent2")
            {
                strStyle = "TableBodyIndent3";
                strTableIndent.Add(leftInd, strStyle);
                return strStyle;
            }
            else if (strStyle == "TableBodyIndent3")
            {
                strStyle = "TableBodyIndent3";
                strTableIndent.Add(leftInd, strStyle);
                return strStyle;
            }
            else
            {
                //strStyle = "TableBodyIndent3";
                strStyle = "TableBodyIndent1";
                strTableIndent.Add(leftInd, strStyle);
                return strStyle;
            }
        }

        public static void RRHinMspace(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P != null)
                    {
                        if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId != null
                            && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val == "RRH")
                        {
                            if (P.InnerText.Contains("/"))
                            {
                                foreach (Run R in P.Descendants<Run>().ToList())
                                {
                                    if (R != null)
                                    {
                                        foreach (Text T in R.Descendants<Text>().ToList())
                                        {
                                            if (T != null)
                                            {
                                                if (T.InnerText.Contains("/"))
                                                {
                                                    //T.Text = T.InnerText.Trim().Replace("/", "\u2003");
                                                    string[] tlist = T.InnerText.Split('/');
                                                    string newText = null;

                                                    if (tlist.Count() == 3)
                                                    {
                                                        for (int i = 0; i < tlist.Count(); i++)
                                                        {
                                                            if (tlist.Count() == 3 && i < 1)
                                                            {
                                                                newText = newText + tlist[i] + "/";
                                                            }
                                                            else
                                                            {
                                                                newText = newText + tlist[i] + "\u2003";
                                                            }
                                                        }

                                                        T.Text = newText;
                                                    }
                                                    else
                                                    {
                                                        T.Text = T.InnerText.Trim().Replace("/", "\u2003");
                                                    }
                                                    break;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                D.Save();
            }
        }

        public static void commentHyperlinkremove(string filename)
        {
            commentHyperlink = new List<DocumentFormat.OpenXml.Wordprocessing.Run>();

            using (WordprocessingDocument WPD = WordprocessingDocument
                                                .Open(filename, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    RemoveComments = false,
                    RemoveContentControls = true,
                    RemoveEndAndFootNotes = false,
                    RemoveFieldCodes = true,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = false,//Developer name :Priyanka Vishwakarma. Date:29_5_2019, Requirement:it removes the indentation from the nested list  ,Integrated By:Vikas sir. 
                };

                MarkupSimplifier.SimplifyMarkup(WPD, settings);

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                int counter = 0;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P != null)
                    {
                        foreach (Run R in P.Descendants<Run>().ToList())
                        {
                            if (R != null)
                            {
                                if (R.RunProperties != null)
                                {
                                    if (R.RunProperties.RunStyle != null)
                                    {
                                        if (R.RunProperties.RunStyle.Val == "Hyperlink")
                                        {
                                            if (R.InnerText != null)
                                            {
                                                if (R.InnerText.Trim().StartsWith("[") && R.InnerText.Trim().EndsWith("]"))
                                                {
                                                    BookmarkStart bks1 = new BookmarkStart();
                                                    bks1.Id = "comment " + counter;
                                                    R.InsertBeforeSelf(bks1);
                                                    //R added in list then R remove.
                                                    commentHyperlink.Add(R);
                                                    R.Remove();
                                                    counter++;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                D.Save();
            }
        }

        public static void commentHyperlinkadd(string filename)
        {

            using (WordprocessingDocument WPD = WordprocessingDocument
                                                .Open(filename, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    RemoveComments = false,
                    RemoveContentControls = true,
                    RemoveEndAndFootNotes = false,
                    RemoveFieldCodes = true,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = false,//Developer name :Priyanka Vishwakarma. Date:29_5_2019, Requirement:it removes the indentation from the nested list  ,Integrated By:Vikas sir. 
                };

                MarkupSimplifier.SimplifyMarkup(WPD, settings);

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;



                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P.HasChildren == true)
                    {
                        foreach (BookmarkStart bokmrk in P.Descendants<BookmarkStart>().ToList())
                        {
                            foreach (var match in commentHyperlink.ToList())
                            {

                                bokmrk.InsertAfterSelf(match);
                                bokmrk.Remove();
                                commentHyperlink.Remove(match);
                                goto nextbookmark;
                            }
                        nextbookmark:
                            {

                            }
                        }
                    }
                }
                D.Save();
            }
        }

        #region for apply list Style to paragraph old.
        //added on 29_3_2019 by priyanka for Apply List style
        //public static void List_Style(string newDoc)
        //{
        //    bool startwithsup = false;
        //    using (WordprocessingDocument WPD = WordprocessingDocument
        //                                       .Open(newDoc, true))
        //    {
        //        MainDocumentPart MDP = WPD.MainDocumentPart;

        //        Document D = MDP.Document;
        //        string strRomanNew = null;
        //        string strUpparAlpha = null;
        //        string strLowerAlpha = null;
        //        string strNum = null;
        //        string strStar = null;
        //        string strDash = null;
        //        string strRoman = null;
        //        string strBull1 = null;
        //        string strBull2 = null;
        //        string strBull3 = null;
        //        string strBull4 = null;
        //        string strBull5 = null;
        //        string strBull6 = null;
        //        string strBull7 = null;
        //        string strBull8 = null;
        //        string strBull9 = null;
        //        string strBull10 = null;
        //        string strNumWithBracket = null;
        //        string strNumWithBracketDot = null;
        //        string strNumWithoutSpace = null;
        //        string strAlphaNum = null;
        //        string strSquare = null;

        //        foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
        //        {
        //            startwithsup = false;
        //            if (P != null && P.InnerText.Trim() != null)
        //            {
        //                if (P.HasChildren)
        //                {
        //                    if (P.Descendants<Run>().Count() > 0)
        //                    {
        //                        //foreach (Run R in P.Descendants<Run>().ToList())
        //                        //{
        //                        Run R = P.Descendants<Run>().FirstOrDefault();
        //                        if (R.RunProperties != null)
        //                            {
        //                                if (R.RunProperties.VerticalTextAlignment != null)
        //                                {
        //                                    if (R.RunProperties.VerticalTextAlignment.Val == "superscript")
        //                                    {
        //                                        continue;
        //                                    }

        //                                }
        //                            }
        //                        //}
        //                    }
        //                }
        //                string gettxt = P.InnerText;

        //                strRoman = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt, @"^\(?\[?\{?([ivxIVX]{1,})[\.\}\)\]]{1,2}\s");
        //                strRomanNew = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt, @"^\(?\[?\{?([ivxIVX]{1,})[\.\}\)\]]{1,2}");
        //                //strUpparAlpha = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt, @"^\(?\[?\{?([A-Z]{1,2})[\.\}\)\]]{1,2}\s");\\\\commented by vikas on 15-05-2019
        //                strUpparAlpha = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt, @"^\(?\[?\{?([A-Z]{1,2})[\:\}\)\]]{1,2}\s|^\(?\[?\{?([A-Z]{1,2})[\.\}\)\]]{1,2}\s");   //////Developer Name:priyanka Vishwakarma ,Date:15_5_2019 ,Requirement:regex added for UpperAlpha List    ,Integrated By:Vikas sir

        //                strLowerAlpha = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt, @"^\(?\[?\{?([a-z]{1,2})[\.\}\)\]]{1,2}\s");
        //                strNum = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt, @"^[0-9]{1,2}\.\s");
        //                strStar = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt, @"^[*]{1,}\s?");
        //                strDash = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt, @"^[-|–]{1,}\s?");
        //                strNumWithBracket = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt, @"^\(?\[?\{?[0-9]{1,2}\.?\}?\)?\]?\s");
        //                strNumWithBracketDot = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt, @"^\(?\[?\{?[0-9]{1,2}\.[0-9]{1,2}\.?\}?\)?\]?\s");
        //                strNumWithoutSpace = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt, @"^[0-9]{1,2}\.?\s?");
        //                strAlphaNum = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt, @"^\(?\[?\{?([a-zA-Z\.]{1,2})\}?\]?\)?\(?\[?\{?([0-9\.]{1,2})\}?\]?\)?\s");
        //                strBull1 = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt, @"^[•]{1,}\s?");
        //                strBull2 = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt, @"^[●]{1,}\s?");
        //                strBull3 = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt, @"^[■]{1,}\s?");
        //                strBull4 = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt, @"^[▪]{1,}\s?");
        //                strBull5 = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt, @"^[†]{1,}\s?");
        //                strBull6 = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt, @"^[#]{1,}\s?");
        //                strBull7 = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt, @"^[]{1,}\s?");
        //                strBull8 = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt, @"^[+]{1,}\s?");
        //                strBull9 = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt, @"^[\^]{1,}\s?");
        //                strBull10 = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt, @"^[○]\s?");//////added by vikas for cilcle list on 19-06-2019
        //                strSquare = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt, @"^[□]{1,}\s?");




        //                if (strRoman != null || strRomanNew != null)
        //                {
        //                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId!=null)
        //                    {
        //                        if (P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val != "AU")
        //                        {
        //                            P.ParagraphProperties.ParagraphStyleId.Val.Value = "RomanList";
        //                        }
        //                    }
        //                }
        //                else if (strUpparAlpha != null)
        //                {
        //                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null)
        //                    {
        //                        if (P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val != "AU")
        //                        {
        //                            P.ParagraphProperties.ParagraphStyleId.Val.Value = "AlphaUpparList";
        //                        }
        //                    }
        //                }
        //                else if (strLowerAlpha != null)
        //                {
        //                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null)
        //                    {
        //                        if (P.ParagraphProperties.ParagraphStyleId.Val != null)
        //                        {
        //                            P.ParagraphProperties.ParagraphStyleId.Val.Value = "AlphaLowerList";
        //                        }
        //                    }
        //                }
        //                else if (strNum != null && startwithsup != true)
        //                {
        //                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null)
        //                    {
        //                        if (P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val !="TFN" && P.ParagraphProperties.ParagraphStyleId.Val != "TCH" && P.ParagraphProperties.ParagraphStyleId.Val != "T-TXT" && P.ParagraphProperties.ParagraphStyleId.Val != "REF1")
        //                        {
        //                            P.ParagraphProperties.ParagraphStyleId.Val.Value = "NumList";
        //                        }
        //                    }
        //                }
        //                else if (strNumWithBracket != null && startwithsup != true)
        //                {
        //                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null)
        //                    {
        //                        if (P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val != "TFN" && P.ParagraphProperties.ParagraphStyleId.Val != "TCH" && P.ParagraphProperties.ParagraphStyleId.Val != "T-TXT" && P.ParagraphProperties.ParagraphStyleId.Val != "REF1")
        //                        {
        //                            P.ParagraphProperties.ParagraphStyleId.Val.Value = "NumList";
        //                        }
        //                    }
        //                }
        //                else if (strNumWithBracketDot != null && startwithsup != true)
        //                {
        //                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null)
        //                    {
        //                        if (P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val != "H1" && P.ParagraphProperties.ParagraphStyleId.Val != "TCH" && P.ParagraphProperties.ParagraphStyleId.Val != "T-TXT" && P.ParagraphProperties.ParagraphStyleId.Val != "REF1")
        //                        {
        //                            P.ParagraphProperties.ParagraphStyleId.Val.Value = "NumList";
        //                        }
        //                    }
        //                }
        //                else if (strNumWithoutSpace != null && startwithsup != true)
        //                {
        //                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null)
        //                    {
        //                        if (P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val != "CT" && P.ParagraphProperties.ParagraphStyleId.Val != "H1" && P.ParagraphProperties.ParagraphStyleId.Val != "TCH" && P.ParagraphProperties.ParagraphStyleId.Val != "T-TXT" && P.ParagraphProperties.ParagraphStyleId.Val != "REF1")
        //                        {
        //                            P.ParagraphProperties.ParagraphStyleId.Val.Value = "NumList";
        //                        }
        //                    }
        //                }
        //                else if (strAlphaNum != null)
        //                {
        //                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != "TCH" && P.ParagraphProperties.ParagraphStyleId.Val != "NL" && P.ParagraphProperties.ParagraphStyleId.Val != "UID")  //Developer name:priyanka vishwakarma ,Date:13_09_2019 ,Requirement:Not apply Listing for Appendix in word document .,Integrated by:Vikas sir.   //Developer Name:Priyanka Vishwakarma , Date:25_5_2019 ,Requirement:Within table Para start with No. of K-wires this is consider as Alpha num list to avoid check if para has "TCH" char style. ,Integrated by:Vikas Sir  //Developer name:priyanka vishwakarma ,Date:24_08_2019 ,Requirement:Not apply Listing for Appendix in word document .,Integrated by:Vikas sir.   //Developer Name:Priyanka Vishwakarma , Date:25_5_2019 ,Requirement:Within table Para start with No. of K-wires this is consider as Alpha num list to avoid check if para has "TCH" char style. ,Integrated by:Vikas Sir
        //                    {
        //                        if (P.ParagraphProperties.ParagraphStyleId.Val != null)
        //                        {
        //                            P.ParagraphProperties.ParagraphStyleId.Val.Value = "AlphaList";
        //                        }
        //                    }
        //                }
        //                else if (strStar != null && gettxt.StartsWith("* "))////added by vikas on 19-06-2019 for star list with space
        //                {
        //                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null)
        //                    {
        //                        if (P.ParagraphProperties.ParagraphStyleId.Val != null)
        //                        {
        //                            P.ParagraphProperties.ParagraphStyleId.Val.Value = "StarList";
        //                        }
        //                    }
        //                }
        //                else if (strDash != null)
        //                {
        //                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null)
        //                    {
        //                        if (P.ParagraphProperties.ParagraphStyleId.Val != null)
        //                        {
        //                            P.ParagraphProperties.ParagraphStyleId.Val.Value = "DashList";
        //                        }
        //                    }
        //                }
        //                else if (strBull1 != null)
        //                {
        //                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null)
        //                    {
        //                        if (P.ParagraphProperties.ParagraphStyleId.Val != null)
        //                        {
        //                            P.ParagraphProperties.ParagraphStyleId.Val.Value = "SmallBullList";
        //                        }
        //                    }
        //                }
        //                else if (strBull2 != null)
        //                {
        //                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null)
        //                    {
        //                        if (P.ParagraphProperties.ParagraphStyleId.Val != null)
        //                        {
        //                            P.ParagraphProperties.ParagraphStyleId.Val.Value = "LargeBullList";
        //                        }
        //                    }
        //                }
        //                else if (strBull3 != null)
        //                {
        //                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null)
        //                    {
        //                        if (P.ParagraphProperties.ParagraphStyleId.Val != null)
        //                        {
        //                            P.ParagraphProperties.ParagraphStyleId.Val.Value = "LargeSquareList";
        //                        }
        //                    }
        //                }
        //                else if (strBull4 != null)
        //                {
        //                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null)
        //                    {
        //                        if (P.ParagraphProperties.ParagraphStyleId.Val != null)
        //                        {
        //                            P.ParagraphProperties.ParagraphStyleId.Val.Value = "SmallSquareList";
        //                        }
        //                    }
        //                }
        //                else if (strBull5 != null)
        //                {
        //                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null)
        //                    {
        //                        if (P.ParagraphProperties.ParagraphStyleId.Val != null)
        //                        {
        //                            P.ParagraphProperties.ParagraphStyleId.Val.Value = "BullList";
        //                        }
        //                    }
        //                }
        //                else if (strBull6 != null)
        //                {
        //                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null)
        //                    {
        //                        if (P.ParagraphProperties.ParagraphStyleId.Val != null)
        //                        {
        //                            P.ParagraphProperties.ParagraphStyleId.Val.Value = "BullList";
        //                        }
        //                    }
        //                }
        //                else if (strBull7 != null)
        //                {
        //                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null)
        //                    {
        //                        if (P.ParagraphProperties.ParagraphStyleId.Val != null)
        //                        {
        //                            P.ParagraphProperties.ParagraphStyleId.Val.Value = "BullList";
        //                        }
        //                    }
        //                }
        //                else if (strBull8 != null)
        //                {
        //                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null)
        //                    {
        //                        if (P.ParagraphProperties.ParagraphStyleId.Val != null)
        //                        {
        //                            P.ParagraphProperties.ParagraphStyleId.Val.Value = "BullList";
        //                        }
        //                    }
        //                }
        //                else if (strBull9 != null)
        //                {
        //                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null)
        //                    {
        //                        if (P.ParagraphProperties.ParagraphStyleId.Val != null)
        //                        {
        //                            P.ParagraphProperties.ParagraphStyleId.Val.Value = "BullList";
        //                        }
        //                    }
        //                }
        //                else if (strBull10 != null)
        //                {
        //                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null)
        //                    {
        //                        if (P.ParagraphProperties.ParagraphStyleId.Val != null)
        //                        {
        //                            P.ParagraphProperties.ParagraphStyleId.Val.Value = "CircList";
        //                        }
        //                    }
        //                }
        //                else if (strSquare != null)
        //                {
        //                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null)
        //                    {
        //                        if (P.ParagraphProperties.ParagraphStyleId.Val != null)
        //                        {
        //                            P.ParagraphProperties.ParagraphStyleId.Val.Value = "EmptySquareList";
        //                        }
        //                    }
        //                }


        //            }
        //        }
        //        D.Save();
        //    }
        //}
        #endregion
        #region for apply list Style to paragraph.
        public static void List_Style(string newDoc)
        {
            bool startwithsup = false;
            using (WordprocessingDocument WPD = WordprocessingDocument
                                               .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                string strRomanNew = null;
                string strUpparAlpha = null;
                string strLowerAlpha = null;
                string strNum = null;
                string strStar = null;
                string strDash = null;
                string strRoman = null;
                string strBull1 = null;
                string strBull2 = null;
                string strBull3 = null;
                string strBull4 = null;
                string strBull5 = null;
                string strBull6 = null;
                string strBull7 = null;
                string strBull8 = null;
                string strBull9 = null;
                string strBull10 = null;
                string strNumWithBracket = null;
                string strNumWithBracketDot = null;
                string strNumWithoutSpace = null;
                string strAlphaNum = null;
                string strSquare = null;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    startwithsup = false;
                    if (P != null && P.InnerText.Trim() != null)
                    {
                        if (P.HasChildren)
                        {
                            if (P.Descendants<Run>().Count() > 0)
                            {
                                //foreach (Run R in P.Descendants<Run>().ToList())
                                //{
                                Run R = P.Descendants<Run>().FirstOrDefault();
                                if (R.RunProperties != null)
                                {
                                    if (R.RunProperties.VerticalTextAlignment != null)
                                    {
                                        if (R.RunProperties.VerticalTextAlignment.Val == "superscript")
                                        {
                                            continue;
                                        }

                                    }
                                    if (R.Descendants<Drawing>().Count() > 0)
                                    {
                                        continue;
                                    }
                                }
                                if (P.ParagraphProperties != null)
                                {
                                    if (P.ParagraphProperties.Justification != null)
                                    {
                                        if (P.ParagraphProperties.Justification.Val == "right")
                                        {
                                            continue;
                                        }

                                    }
                                }
                                //}
                            }
                        }
                        if (P.Parent != null && P.Parent.XName.LocalName == "tc")     //Developer name :Priyanka Vishwakarma ,Date:17_02_2020, Requirement:should not apply list style within table . Integrated by:Vikas sir.
                        {
                            continue;
                        }


                        if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && (P.ParagraphProperties.ParagraphStyleId.Val.Value == "H1" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H2" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H3" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H4" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H5" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H6" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "REF1" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "DT" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "TI" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "Alt-TI" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "RRH" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "AU" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "CORR" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "AFFL" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "UID" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "AB" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "AB-TXT" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "KYWD"))     //Developer name :Priyanka Vishwakarma ,Date:15-07-2020, Requirement:should not apply list style to heading in document.
                        {
                            continue;
                        }
                        string gettxt = P.InnerText.Trim();//23-03-2020  //Developer name:Priyanka Vishwakarma ,Date:26-03-2020 ,Requirement:Listing not apply because paragraph start with space. Integrated by:Vikas sir.



                        strRoman = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt, @"^\(?\[?\{?([ivxIVX]{1,})[\.\}\)\]]{1,2}\s");/*@"^\(?\[?\{?([ivxIVX]{1,})[\.\}\)\]]{1,2}\s|^([ivxIVX]{1,}\s{1,})");*//////commented by vikas due to I content not required roman list on 22-09-2020  ///developer name:Priyanka Vishwakarma .Date:21-02-2020 Roman list without ot //Developer Name:Priyanka Vishwakarma ,Date:22-02-2020 Requirement:add Pattern for Roman List without dot or without brackets. ,Integrated by:Vikas sir
                        strRomanNew = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt, @"^\(?\[?\{?([ivxIVX]{1,})[\.\}\)\]]{1,2}");
                        //strUpparAlpha = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt, @"^\(?\[?\{?([A-Z]{1,2})[\.\}\)\]]{1,2}\s");\\\\commented by vikas on 15-05-2019
                        // strUpparAlpha = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt, @"^\(?\[?\{?([A-Z]{1,2})[\:\}\)\]]{1,2}\s|^\(?\[?\{?([A-Z]{1,2})[\.\}\)\]]{1,2}\s|^([A-Z]\s{1,})"); ///developer name:Priyanka Vishwakarma .Date:21-02-2020 alpha upperlist without .  //////Developer Name:priyanka Vishwakarma ,Date:15_5_2019 ,Requirement:regex added for UpperAlpha List    ,Integrated By:Vikas sir
                        //-------Developer name:Priyanka Vishwakarma ,Date:26-03-2020 ,Requirement:Paragraph start wiht AB: apply AlphaUpperList in clenupProcess. ,Integrated by:Vikas sir --------------------
                        // strUpparAlpha = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt, @"^\(?\[?\{?([A-Z]{1,2})[\}\)\]]{1,2}\s|^\(?\[?\{?([A-Z]{1,2})[\.\}\)\]]{1,2}\s|^([A-Z]\s{1,})");//Developer name:Priyanka Vishwakarma ,Date:26-03-2020 ,Requirement:Paragraph start wiht AB: apply AlphaUpperList in clenupProcess. ,Integrated by:Vikas sir
                        strUpparAlpha = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt.TrimStart(), @"^\(?\[?\{?([A-Z]{1,2})[\.|)\}\)\]]{1,2}\s");
                        //------------End on 26-03-2020------------------------

                        strLowerAlpha = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt, @"^\(?\[?\{?([a-z]{1,2})[\.\}\)\]]{1,2}\s|^([a-zA-z][)]\s{1,})|^([a-z][\.]\s{1,})|^([a-z]\s{1,})");   ///developer name:Priyanka Vishwakarma .Date:21-02-2020 alpha lowerlist without .
                        //strNum = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt, @"^[0-9]{1,2}\.\s|^([0-9]\s{1,})"); // //Developer Name:Priyanka Vishwakarma ,Date:22-02-2020 Requirement:add Pattern for number List without dot or without brackets. ,Integrated by:Vikas sir
                        strNum = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt, @"^[0-9]{1,2}\.\s");

                        strStar = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt, @"^[*]{1,}\s?");
                        strDash = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt, @"^[-|–]{1,}\s?");
                        if (GlobalMethods.strClientName.ToLower() != "informs")
                        {
                            strNumWithBracket = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt, @"^\(?\[?\{?[0-9]{1,2}\.\}?\)?\]?\s|^\(?\[?\{?[0-9]{1,2}\.?\}?\)?\]?\s");  //Developer Name:Priyanka Vishwakarma ,Date:22-02-2020 Requirement:add Pattern for Number list without dot ,Integrated by:Vikas sir                   
                            strNumWithBracketDot = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt, @"^\(?\[?\{?[0-9]{1,2}\.[0-9]{1,2}\.?\}?\)?\]?\s");
                            if (GlobalMethods.strClientName.ToLower() != "sage")
                            {
                                strNumWithoutSpace = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt, @"^[0-9]{1,2}\.\s?");
                            }
                        }
                        if (GlobalMethods.strClientName.ToLower() == "sage")
                        {
                            var newstrNumWithBracket = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt, @"^\(?\[?\{?[0-9]{1,2}\.\}?\)?\]?\s");
                            if (!string.IsNullOrEmpty(newstrNumWithBracket))
                            {
                                strNumWithBracket = newstrNumWithBracket;
                            }
                        }
                        //strAlphaNum = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt, @"^\(?\[?\{?([a-zA-Z\.]{1,2})\}?\]?\)?\(?\[?\{?([0-9\.]{1,2})\}?\]?\)?\s");
                        strAlphaNum = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt, @"^\(?\[?\{?([a-zA-Z\.])\}?\]?\)?\(?\[?\{?([0-9\.]{1,2})\}?\]?\)?\s");  ////DEveloper name :Priyanka vishwakarma .Date:15_10_2019 ,Requirement:change regex for select alpha numlist like a1. etc not apply alphanumlist to Dr. :Integrated by:Vikas sir.                
                        strBull1 = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt, @"^[•]{1,}\s?");
                        strBull2 = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt, @"^[?]{1,}\s?");
                        strBull3 = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt, @"^[¦]{1,}\s?");
                        strBull4 = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt, @"^[?]{1,}\s?|^[▪]{1,}\s?");  //Developer Name:Priyanka Vishwakarma ,Date:22-02-2020 Requirement:add Pattern for squar bullet list ,Integrated by:Vikas sir
                        strBull5 = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt, @"^[†]{1,}\s?|^[●]{1,}\s?");
                        strBull6 = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt, @"^[#]{1,}\s?");
                        strBull7 = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt, @"^[?]{1,}\s?");
                        strBull8 = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt, @"^[+]{1,}\s?");
                        strBull9 = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt, @"^[\^]{1,}\s?");
                        strBull10 = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt, @"^[?]\s?|^([o]\s{1,})|^([○]\s{1,})");//////added by vikas for cilcle list on 19-06-2019  ////DEveloper name :Priyanka vishwakarma .Date:15_10_2019 ,Requirement:change regex for select alpha numlist like a1. etc not apply alphanumlist to Dr. :Integrated by:Vikas sir.
                        strSquare = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(gettxt, @"^[?]{1,}\s?|^[▫]{1,}\s?"); ////DEveloper name :Priyanka vishwakarma .Date:15_10_2019 ,Requirement:change regex for select alpha numlist like a1. etc not apply alphanumlist to Dr. :Integrated by:Vikas sir.//Developer Name:Priyanka Vishwakarma ,Date:22-02-2020 Requirement:add Pattern for Empty squar list. ,Integrated by:Vikas sir



                        //Developer name:Priyanka Vishwakarma .Date:24_09_2019 ,Requirement:apply List paragraph style for unstructured document.

                        if (strRoman != null || strRomanNew != null)
                        {
                            if (P.ParagraphProperties != null)  //Developer name:priyanka vishwakarma ,Date:13_09_2019 ,Requirement:Not apply Listing for Appendix in word document .,Integrated by:Vikas sir.   //Developer Name:Priyanka Vishwakarma , Date:25_5_2019 ,Requirement:Within table Para start with No. of K-wires this is consider as Alpha num list to avoid check if para has "TCH" char style. ,Integrated by:Vikas Sir  //Developer name:priyanka vishwakarma ,Date:24_08_2019 ,Requirement:Not apply Listing for Appendix in word document .,Integrated by:Vikas sir.   //Developer Name:Priyanka Vishwakarma , Date:25_5_2019 ,Requirement:Within table Para start with No. of K-wires this is consider as Alpha num list to avoid check if para has "TCH" char style. ,Integrated by:Vikas Sir
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId.Val != "TCH" && P.ParagraphProperties.ParagraphStyleId.Val != "AU" && /*P.ParagraphProperties.ParagraphStyleId.Val != "NL" &&*/ P.ParagraphProperties.ParagraphStyleId.Val != "UID")
                                    {
                                        {
                                            P.ParagraphProperties.ParagraphStyleId.Val.Value = "RomanList";
                                        }
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "RomanList" };
                                }
                            }
                            else
                            {
                                P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "RomanList" });   //24_09_2019

                            }
                            //if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId!=null)
                            //{
                            //    if (P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val != "AU")
                            //    {
                            //        P.ParagraphProperties.ParagraphStyleId.Val.Value = "RomanList";
                            //    }
                            //    else
                            //    {
                            //        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "RomanList" };
                            //    }
                            //} 
                            //else
                            //{
                            //    P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "RomanList" });   //24_09_2019

                            //}
                        }

                        //-------Developer name:Priyanka Vishwakarma ,Date:26-03-2020;Requirement:Circle List not Apply in Master Document,Integrated by:Vikas sir.
                        // 
                        else if (strBull10 != null)
                        {
                            if (P.ParagraphProperties != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId.Val != "TCH" && P.ParagraphProperties.ParagraphStyleId.Val != "UID")
                                    {
                                        {
                                            P.ParagraphProperties.ParagraphStyleId.Val.Value = "CircList";
                                        }
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "CircList" };
                                }
                            }
                            else
                            {
                                P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "CircList" });

                            }
                        }
                        //--------------End on 26-03-2020
                        else if (strUpparAlpha != null)
                        {
                            if (P.ParagraphProperties != null)  //Developer name:priyanka vishwakarma ,Date:13_09_2019 ,Requirement:Not apply Listing for Appendix in word document .,Integrated by:Vikas sir.   //Developer Name:Priyanka Vishwakarma , Date:25_5_2019 ,Requirement:Within table Para start with No. of K-wires this is consider as Alpha num list to avoid check if para has "TCH" char style. ,Integrated by:Vikas Sir  //Developer name:priyanka vishwakarma ,Date:24_08_2019 ,Requirement:Not apply Listing for Appendix in word document .,Integrated by:Vikas sir.   //Developer Name:Priyanka Vishwakarma , Date:25_5_2019 ,Requirement:Within table Para start with No. of K-wires this is consider as Alpha num list to avoid check if para has "TCH" char style. ,Integrated by:Vikas Sir
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                                {
                                    // if (P.ParagraphProperties.ParagraphStyleId.Val != "TCH" && P.ParagraphProperties.ParagraphStyleId.Val != "AU" && P.ParagraphProperties.ParagraphStyleId.Val != "AU" && /*P.ParagraphProperties.ParagraphStyleId.Val != "NL" &&*/ P.ParagraphProperties.ParagraphStyleId.Val != "UID")
                                    if (P.ParagraphProperties.ParagraphStyleId.Val != "TCH" && P.ParagraphProperties.ParagraphStyleId.Val != "AU" && P.ParagraphProperties.ParagraphStyleId.Val != "UID" && P.ParagraphProperties.ParagraphStyleId.Val != "CR" && P.ParagraphProperties.ParagraphStyleId.Val != "TI") //Developer name :Priyanka Vishwakarma ,Date:03-04-2020 ,Requirement:Avoid to apply list to Copyrignt paragraph is start with J space ..(4649_THI_J_JNRP-19-00386) ,Integrated by:Vikas sir///TI Added by vikas on 31-03-2021
                                    {

                                        P.ParagraphProperties.ParagraphStyleId.Val.Value = "AlphaUpparList";

                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "AlphaUpparList" };
                                }
                            }
                            else
                            {
                                P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "AlphaUpparList" });   //24_09_2019

                            }
                            //if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null)
                            //{
                            //    if (P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val != "AU")
                            //    {
                            //        P.ParagraphProperties.ParagraphStyleId.Val.Value = "AlphaUpparList";
                            //    }
                            //    else
                            //    {
                            //        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "AlphaUpparList" };
                            //    }
                            //}
                            //else
                            //{
                            //    P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "AlphaUpparList" });   //24_09_2019

                            //}
                        }
                        else if (strLowerAlpha != null)
                        {
                            if (P.ParagraphProperties != null)  //Developer name:priyanka vishwakarma ,Date:13_09_2019 ,Requirement:Not apply Listing for Appendix in word document .,Integrated by:Vikas sir.   //Developer Name:Priyanka Vishwakarma , Date:25_5_2019 ,Requirement:Within table Para start with No. of K-wires this is consider as Alpha num list to avoid check if para has "TCH" char style. ,Integrated by:Vikas Sir  //Developer name:priyanka vishwakarma ,Date:24_08_2019 ,Requirement:Not apply Listing for Appendix in word document .,Integrated by:Vikas sir.   //Developer Name:Priyanka Vishwakarma , Date:25_5_2019 ,Requirement:Within table Para start with No. of K-wires this is consider as Alpha num list to avoid check if para has "TCH" char style. ,Integrated by:Vikas Sir
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId.Val != "TCH" && P.ParagraphProperties.ParagraphStyleId.Val != "AU" && P.ParagraphProperties.ParagraphStyleId.Val != "AU" && /*P.ParagraphProperties.ParagraphStyleId.Val != "NL" &&*/ P.ParagraphProperties.ParagraphStyleId.Val != "UID")
                                    {
                                        {
                                            P.ParagraphProperties.ParagraphStyleId.Val.Value = "AlphaLowerList";
                                        }
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "AlphaLowerList" };
                                }
                            }
                            else
                            {
                                P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "AlphaLowerList" });   //24_09_2019

                            }
                            //if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null)
                            //{
                            //    if (P.ParagraphProperties.ParagraphStyleId.Val != null)
                            //    {
                            //        P.ParagraphProperties.ParagraphStyleId.Val.Value = "AlphaLowerList";
                            //    }
                            //    else
                            //    {
                            //        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "AlphaLowerList" };
                            //    }
                            //}
                            //else
                            //{
                            //    P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "AlphaLowerList" });   //24_09_2019

                            //}
                        }
                        else if (strNum != null && startwithsup != true)
                        {
                            if (P.ParagraphProperties != null)  //Developer name:priyanka vishwakarma ,Date:13_09_2019 ,Requirement:Not apply Listing for Appendix in word document .,Integrated by:Vikas sir.   //Developer Name:Priyanka Vishwakarma , Date:25_5_2019 ,Requirement:Within table Para start with No. of K-wires this is consider as Alpha num list to avoid check if para has "TCH" char style. ,Integrated by:Vikas Sir  //Developer name:priyanka vishwakarma ,Date:24_08_2019 ,Requirement:Not apply Listing for Appendix in word document .,Integrated by:Vikas sir.   //Developer Name:Priyanka Vishwakarma , Date:25_5_2019 ,Requirement:Within table Para start with No. of K-wires this is consider as Alpha num list to avoid check if para has "TCH" char style. ,Integrated by:Vikas Sir
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId.Val != "TFN" && P.ParagraphProperties.ParagraphStyleId.Val != "TCH" && P.ParagraphProperties.ParagraphStyleId.Val != "T-TXT" && P.ParagraphProperties.ParagraphStyleId.Val != "REF1" && P.ParagraphProperties.ParagraphStyleId.Val != "AU" && /*P.ParagraphProperties.ParagraphStyleId.Val != "NL" &&*/ P.ParagraphProperties.ParagraphStyleId.Val != "UID" && P.ParagraphProperties.ParagraphStyleId.Val != "H1" && P.ParagraphProperties.ParagraphStyleId.Val != "H2" && P.ParagraphProperties.ParagraphStyleId.Val != "H3" && P.ParagraphProperties.ParagraphStyleId.Val != "H4" && P.ParagraphProperties.ParagraphStyleId.Val != "FTN")
                                    {
                                        {
                                            P.ParagraphProperties.ParagraphStyleId.Val.Value = "NumList";
                                        }
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "NumList" };
                                }
                            }
                            else
                            {
                                P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "NumList" });   //24_09_2019

                            }
                            //if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null)
                            //{
                            //    if (P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val !="TFN" && P.ParagraphProperties.ParagraphStyleId.Val != "TCH" && P.ParagraphProperties.ParagraphStyleId.Val != "T-TXT" && P.ParagraphProperties.ParagraphStyleId.Val != "REF1")
                            //    {
                            //        P.ParagraphProperties.ParagraphStyleId.Val.Value = "NumList";
                            //    }
                            //    else
                            //    {
                            //        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "NumList" };
                            //    }
                            //}
                            //else
                            //{
                            //    P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "NumList" });

                            //}
                        }
                        else if (strNumWithBracket != null && startwithsup != true)
                        {
                            if (P.ParagraphProperties != null)  //Developer name:priyanka vishwakarma ,Date:13_09_2019 ,Requirement:Not apply Listing for Appendix in word document .,Integrated by:Vikas sir.   //Developer Name:Priyanka Vishwakarma , Date:25_5_2019 ,Requirement:Within table Para start with No. of K-wires this is consider as Alpha num list to avoid check if para has "TCH" char style. ,Integrated by:Vikas Sir  //Developer name:priyanka vishwakarma ,Date:24_08_2019 ,Requirement:Not apply Listing for Appendix in word document .,Integrated by:Vikas sir.   //Developer Name:Priyanka Vishwakarma , Date:25_5_2019 ,Requirement:Within table Para start with No. of K-wires this is consider as Alpha num list to avoid check if para has "TCH" char style. ,Integrated by:Vikas Sir
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId.Val != "TFN" && P.ParagraphProperties.ParagraphStyleId.Val != "TCH" && P.ParagraphProperties.ParagraphStyleId.Val != "T-TXT" && P.ParagraphProperties.ParagraphStyleId.Val != "REF1" && P.ParagraphProperties.ParagraphStyleId.Val != "AU" && /*P.ParagraphProperties.ParagraphStyleId.Val != "NL" &&*/ P.ParagraphProperties.ParagraphStyleId.Val != "UID" && P.ParagraphProperties.ParagraphStyleId.Val != "H1" && P.ParagraphProperties.ParagraphStyleId.Val != "H2" && P.ParagraphProperties.ParagraphStyleId.Val != "H3" && P.ParagraphProperties.ParagraphStyleId.Val != "H4" && P.ParagraphProperties.ParagraphStyleId.Val != "FTN" && P.ParagraphProperties.ParagraphStyleId.Val != "AFFL") //Developer Name:Priyanka Vishwakarma,Date:22-03-2021,Requirement:Add condition
                                    {
                                        {
                                            P.ParagraphProperties.ParagraphStyleId.Val.Value = "NumList";
                                        }
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "NumList" };
                                }
                            }
                            else
                            {
                                P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "NumList" });   //24_09_2019

                            }
                            //if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null)
                            //{
                            //    if (P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val != "TFN" && P.ParagraphProperties.ParagraphStyleId.Val != "TCH" && P.ParagraphProperties.ParagraphStyleId.Val != "T-TXT" && P.ParagraphProperties.ParagraphStyleId.Val != "REF1")
                            //    {
                            //        P.ParagraphProperties.ParagraphStyleId.Val.Value = "NumList";
                            //    }
                            //    else
                            //    {
                            //        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "NumList" };
                            //    }
                            //}
                            //else
                            //{
                            //    P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "NumList" });   //24_09_2019

                            //}
                        }
                        else if (strNumWithBracketDot != null && startwithsup != true)
                        {
                            if (P.ParagraphProperties != null)  //Developer name:priyanka vishwakarma ,Date:13_09_2019 ,Requirement:Not apply Listing for Appendix in word document .,Integrated by:Vikas sir.   //Developer Name:Priyanka Vishwakarma , Date:25_5_2019 ,Requirement:Within table Para start with No. of K-wires this is consider as Alpha num list to avoid check if para has "TCH" char style. ,Integrated by:Vikas Sir  //Developer name:priyanka vishwakarma ,Date:24_08_2019 ,Requirement:Not apply Listing for Appendix in word document .,Integrated by:Vikas sir.   //Developer Name:Priyanka Vishwakarma , Date:25_5_2019 ,Requirement:Within table Para start with No. of K-wires this is consider as Alpha num list to avoid check if para has "TCH" char style. ,Integrated by:Vikas Sir
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId.Val != "TFN" && P.ParagraphProperties.ParagraphStyleId.Val != "H1" && P.ParagraphProperties.ParagraphStyleId.Val != "TCH" && P.ParagraphProperties.ParagraphStyleId.Val != "T-TXT" && P.ParagraphProperties.ParagraphStyleId.Val != "REF1" && P.ParagraphProperties.ParagraphStyleId.Val != "AU" && /*P.ParagraphProperties.ParagraphStyleId.Val != "NL" &&*/ P.ParagraphProperties.ParagraphStyleId.Val != "UID" && P.ParagraphProperties.ParagraphStyleId.Val != "H1" && P.ParagraphProperties.ParagraphStyleId.Val != "H2" && P.ParagraphProperties.ParagraphStyleId.Val != "H3" && P.ParagraphProperties.ParagraphStyleId.Val != "H4" && P.ParagraphProperties.ParagraphStyleId.Val != "FTN")
                                    {
                                        {
                                            P.ParagraphProperties.ParagraphStyleId.Val.Value = "NumList";
                                        }
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "NumList" };
                                }
                            }
                            else
                            {
                                P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "NumList" });   //24_09_2019

                            }
                            //if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null)
                            //{
                            //    if (P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val != "H1" && P.ParagraphProperties.ParagraphStyleId.Val != "TCH" && P.ParagraphProperties.ParagraphStyleId.Val != "T-TXT" && P.ParagraphProperties.ParagraphStyleId.Val != "REF1")
                            //    {
                            //        P.ParagraphProperties.ParagraphStyleId.Val.Value = "NumList";
                            //    }
                            //    else
                            //    {
                            //        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "NumList" };
                            //    }
                            //}
                            //else
                            //{
                            //    P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "NumList" });   //24_09_2019

                            //}
                        }
                        else if (strNumWithoutSpace != null && startwithsup != true)
                        {
                            if (P.ParagraphProperties != null)  //Developer name:priyanka vishwakarma ,Date:13_09_2019 ,Requirement:Not apply Listing for Appendix in word document .,Integrated by:Vikas sir.   //Developer Name:Priyanka Vishwakarma , Date:25_5_2019 ,Requirement:Within table Para start with No. of K-wires this is consider as Alpha num list to avoid check if para has "TCH" char style. ,Integrated by:Vikas Sir  //Developer name:priyanka vishwakarma ,Date:24_08_2019 ,Requirement:Not apply Listing for Appendix in word document .,Integrated by:Vikas sir.   //Developer Name:Priyanka Vishwakarma , Date:25_5_2019 ,Requirement:Within table Para start with No. of K-wires this is consider as Alpha num list to avoid check if para has "TCH" char style. ,Integrated by:Vikas Sir
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId.Val != "TFN" && P.ParagraphProperties.ParagraphStyleId.Val != "H1" && P.ParagraphProperties.ParagraphStyleId.Val != "CT" && P.ParagraphProperties.ParagraphStyleId.Val != "TCH" && P.ParagraphProperties.ParagraphStyleId.Val != "T-TXT" && P.ParagraphProperties.ParagraphStyleId.Val != "REF1" && P.ParagraphProperties.ParagraphStyleId.Val != "AU" && /*P.ParagraphProperties.ParagraphStyleId.Val != "NL" &&*/ P.ParagraphProperties.ParagraphStyleId.Val != "UID" && P.ParagraphProperties.ParagraphStyleId.Val != "H1" && P.ParagraphProperties.ParagraphStyleId.Val != "H2" && P.ParagraphProperties.ParagraphStyleId.Val != "H3" && P.ParagraphProperties.ParagraphStyleId.Val != "H4" && P.ParagraphProperties.ParagraphStyleId.Val != "FTN")
                                    {
                                        {
                                            P.ParagraphProperties.ParagraphStyleId.Val.Value = "NumList";
                                        }
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "NumList" };
                                }
                            }
                            else
                            {
                                P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "NumList" });   //24_09_2019

                            }
                            //if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null)
                            //{
                            //    if (P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val != "CT" && P.ParagraphProperties.ParagraphStyleId.Val != "H1" && P.ParagraphProperties.ParagraphStyleId.Val != "TCH" && P.ParagraphProperties.ParagraphStyleId.Val != "T-TXT" && P.ParagraphProperties.ParagraphStyleId.Val != "REF1")
                            //    {
                            //        P.ParagraphProperties.ParagraphStyleId.Val.Value = "NumList";
                            //    }
                            //    else
                            //    {
                            //        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "NumList" };
                            //    }
                            //}
                            //else
                            //{
                            //    P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "NumList" });   //24_09_2019

                            //}
                        }
                        else if (strAlphaNum != null)
                        {
                            if (P.ParagraphProperties != null)  //Developer name:priyanka vishwakarma ,Date:13_09_2019 ,Requirement:Not apply Listing for Appendix in word document .,Integrated by:Vikas sir.   //Developer Name:Priyanka Vishwakarma , Date:25_5_2019 ,Requirement:Within table Para start with No. of K-wires this is consider as Alpha num list to avoid check if para has "TCH" char style. ,Integrated by:Vikas Sir  //Developer name:priyanka vishwakarma ,Date:24_08_2019 ,Requirement:Not apply Listing for Appendix in word document .,Integrated by:Vikas sir.   //Developer Name:Priyanka Vishwakarma , Date:25_5_2019 ,Requirement:Within table Para start with No. of K-wires this is consider as Alpha num list to avoid check if para has "TCH" char style. ,Integrated by:Vikas Sir
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId.Val != "TCH" && /*P.ParagraphProperties.ParagraphStyleId.Val != "NL" &&*/ P.ParagraphProperties.ParagraphStyleId.Val != "UID")
                                    {
                                        {
                                            P.ParagraphProperties.ParagraphStyleId.Val.Value = "AlphaList";
                                        }
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "AlphaList" };
                                }
                            }
                            else
                            {
                                P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "AlphaList" });   //24_09_2019

                            }
                        }
                        else if (strStar != null && gettxt.StartsWith("* "))////added by vikas on 19-06-2019 for star list with space
                        {
                            if (P.ParagraphProperties != null)  //Developer name:priyanka vishwakarma ,Date:13_09_2019 ,Requirement:Not apply Listing for Appendix in word document .,Integrated by:Vikas sir.   //Developer Name:Priyanka Vishwakarma , Date:25_5_2019 ,Requirement:Within table Para start with No. of K-wires this is consider as Alpha num list to avoid check if para has "TCH" char style. ,Integrated by:Vikas Sir  //Developer name:priyanka vishwakarma ,Date:24_08_2019 ,Requirement:Not apply Listing for Appendix in word document .,Integrated by:Vikas sir.   //Developer Name:Priyanka Vishwakarma , Date:25_5_2019 ,Requirement:Within table Para start with No. of K-wires this is consider as Alpha num list to avoid check if para has "TCH" char style. ,Integrated by:Vikas Sir
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId.Val != "TCH" && P.ParagraphProperties.ParagraphStyleId.Val != "TFN" && P.ParagraphProperties.ParagraphStyleId.Val != "UID" && P.ParagraphProperties.ParagraphStyleId.Val != "FTN")
                                    {
                                        {
                                            P.ParagraphProperties.ParagraphStyleId.Val.Value = "StarList";
                                        }
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "StarList" };
                                }
                            }
                            else
                            {
                                P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "StarList" });   //24_09_2019

                            }
                            //if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null)
                            //{
                            //    if (P.ParagraphProperties.ParagraphStyleId.Val != null)
                            //    {
                            //        P.ParagraphProperties.ParagraphStyleId.Val.Value = "StarList";
                            //    }
                            //    else
                            //    {
                            //        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "StarList" };
                            //    }
                            //}
                            //else
                            //{
                            //    P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "StarList" });   //24_09_2019

                            //}
                        }
                        else if (strDash != null)
                        {
                            if (P.ParagraphProperties != null)  //Developer name:priyanka vishwakarma ,Date:13_09_2019 ,Requirement:Not apply Listing for Appendix in word document .,Integrated by:Vikas sir.   //Developer Name:Priyanka Vishwakarma , Date:25_5_2019 ,Requirement:Within table Para start with No. of K-wires this is consider as Alpha num list to avoid check if para has "TCH" char style. ,Integrated by:Vikas Sir  //Developer name:priyanka vishwakarma ,Date:24_08_2019 ,Requirement:Not apply Listing for Appendix in word document .,Integrated by:Vikas sir.   //Developer Name:Priyanka Vishwakarma , Date:25_5_2019 ,Requirement:Within table Para start with No. of K-wires this is consider as Alpha num list to avoid check if para has "TCH" char style. ,Integrated by:Vikas Sir
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId.Val != "TCH" && /*P.ParagraphProperties.ParagraphStyleId.Val != "NL" &&*/ P.ParagraphProperties.ParagraphStyleId.Val != "UID")
                                    {
                                        {
                                            P.ParagraphProperties.ParagraphStyleId.Val.Value = "DashList";
                                        }
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "DashList" };
                                }
                            }
                            else
                            {
                                P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "DashList" });   //24_09_2019

                            }
                            //if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null)
                            //{
                            //    if (P.ParagraphProperties.ParagraphStyleId.Val != null)
                            //    {
                            //        P.ParagraphProperties.ParagraphStyleId.Val.Value = "DashList";
                            //    }
                            //    else
                            //    {
                            //        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "DashList" };
                            //    }
                            //}
                            //else
                            //{
                            //    P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "DashList" });   //24_09_2019

                            //}
                        }
                        else if (strBull1 != null)
                        {
                            if (P.ParagraphProperties != null)  //Developer name:priyanka vishwakarma ,Date:13_09_2019 ,Requirement:Not apply Listing for Appendix in word document .,Integrated by:Vikas sir.   //Developer Name:Priyanka Vishwakarma , Date:25_5_2019 ,Requirement:Within table Para start with No. of K-wires this is consider as Alpha num list to avoid check if para has "TCH" char style. ,Integrated by:Vikas Sir  //Developer name:priyanka vishwakarma ,Date:24_08_2019 ,Requirement:Not apply Listing for Appendix in word document .,Integrated by:Vikas sir.   //Developer Name:Priyanka Vishwakarma , Date:25_5_2019 ,Requirement:Within table Para start with No. of K-wires this is consider as Alpha num list to avoid check if para has "TCH" char style. ,Integrated by:Vikas Sir
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId.Val != "TCH" && /*P.ParagraphProperties.ParagraphStyleId.Val != "NL" &&*/ P.ParagraphProperties.ParagraphStyleId.Val != "UID")
                                    {
                                        {
                                            P.ParagraphProperties.ParagraphStyleId.Val.Value = "SmallBullList";
                                        }
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "SmallBullList" };
                                }
                            }
                            else
                            {
                                P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "SmallBullList" });   //24_09_2019

                            }
                            //if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null)
                            //{
                            //    if (P.ParagraphProperties.ParagraphStyleId.Val != null)
                            //    {
                            //        P.ParagraphProperties.ParagraphStyleId.Val.Value = "SmallBullList";
                            //    }
                            //    else
                            //    {
                            //        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "SmallBullList" };
                            //    }
                            //}
                            //else
                            //{
                            //    P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "SmallBullList" });   //24_09_2019

                            //}
                        }
                        else if (strBull2 != null)
                        {
                            if (P.ParagraphProperties != null)  //Developer name:priyanka vishwakarma ,Date:13_09_2019 ,Requirement:Not apply Listing for Appendix in word document .,Integrated by:Vikas sir.   //Developer Name:Priyanka Vishwakarma , Date:25_5_2019 ,Requirement:Within table Para start with No. of K-wires this is consider as Alpha num list to avoid check if para has "TCH" char style. ,Integrated by:Vikas Sir  //Developer name:priyanka vishwakarma ,Date:24_08_2019 ,Requirement:Not apply Listing for Appendix in word document .,Integrated by:Vikas sir.   //Developer Name:Priyanka Vishwakarma , Date:25_5_2019 ,Requirement:Within table Para start with No. of K-wires this is consider as Alpha num list to avoid check if para has "TCH" char style. ,Integrated by:Vikas Sir
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId.Val != "TCH" && /*P.ParagraphProperties.ParagraphStyleId.Val != "NL" &&*/ P.ParagraphProperties.ParagraphStyleId.Val != "UID")
                                    {
                                        {
                                            P.ParagraphProperties.ParagraphStyleId.Val.Value = "LargeBullList";
                                        }
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "LargeBullList" };
                                }
                            }
                            else
                            {
                                P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "LargeBullList" });   //24_09_2019

                            }
                            //if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null)
                            //{
                            //    if (P.ParagraphProperties.ParagraphStyleId.Val != null)
                            //    {
                            //        P.ParagraphProperties.ParagraphStyleId.Val.Value = "LargeBullList";
                            //    }
                            //    else
                            //    {
                            //        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "LargeBullList" };
                            //    }
                            //}
                            //else
                            //{
                            //    P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "LargeBullList" });   //24_09_2019

                            //}

                        }
                        else if (strBull3 != null)
                        {
                            if (P.ParagraphProperties != null)  //Developer name:priyanka vishwakarma ,Date:13_09_2019 ,Requirement:Not apply Listing for Appendix in word document .,Integrated by:Vikas sir.   //Developer Name:Priyanka Vishwakarma , Date:25_5_2019 ,Requirement:Within table Para start with No. of K-wires this is consider as Alpha num list to avoid check if para has "TCH" char style. ,Integrated by:Vikas Sir  //Developer name:priyanka vishwakarma ,Date:24_08_2019 ,Requirement:Not apply Listing for Appendix in word document .,Integrated by:Vikas sir.   //Developer Name:Priyanka Vishwakarma , Date:25_5_2019 ,Requirement:Within table Para start with No. of K-wires this is consider as Alpha num list to avoid check if para has "TCH" char style. ,Integrated by:Vikas Sir
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId.Val != "TCH" && /*P.ParagraphProperties.ParagraphStyleId.Val != "NL" &&*/ P.ParagraphProperties.ParagraphStyleId.Val != "UID")
                                    {
                                        {
                                            P.ParagraphProperties.ParagraphStyleId.Val.Value = "LargeSquareList";
                                        }
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "LargeSquareList" };
                                }
                            }
                            else
                            {
                                P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "LargeSquareList" });   //24_09_2019

                            }
                            //if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null)
                            //{
                            //    if (P.ParagraphProperties.ParagraphStyleId.Val != null)
                            //    {
                            //        P.ParagraphProperties.ParagraphStyleId.Val.Value = "LargeSquareList";
                            //    }
                            //    else
                            //    {
                            //        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "LargeSquareList" };
                            //    }
                            //}
                            //else
                            //{
                            //    P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "LargeSquareList" });   //24_09_2019

                            //}
                        }
                        else if (strBull4 != null)
                        {
                            if (P.ParagraphProperties != null)  //Developer name:priyanka vishwakarma ,Date:13_09_2019 ,Requirement:Not apply Listing for Appendix in word document .,Integrated by:Vikas sir.   //Developer Name:Priyanka Vishwakarma , Date:25_5_2019 ,Requirement:Within table Para start with No. of K-wires this is consider as Alpha num list to avoid check if para has "TCH" char style. ,Integrated by:Vikas Sir  //Developer name:priyanka vishwakarma ,Date:24_08_2019 ,Requirement:Not apply Listing for Appendix in word document .,Integrated by:Vikas sir.   //Developer Name:Priyanka Vishwakarma , Date:25_5_2019 ,Requirement:Within table Para start with No. of K-wires this is consider as Alpha num list to avoid check if para has "TCH" char style. ,Integrated by:Vikas Sir
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId.Val != "TCH" && /*P.ParagraphProperties.ParagraphStyleId.Val != "NL" &&*/ P.ParagraphProperties.ParagraphStyleId.Val != "UID")
                                    {
                                        {
                                            P.ParagraphProperties.ParagraphStyleId.Val.Value = "SmallSquareList";
                                        }
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "SmallSquareList" };
                                }
                            }
                            else
                            {
                                P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "SmallSquareList" });   //24_09_2019

                            }
                            //if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null)
                            //{
                            //    if (P.ParagraphProperties.ParagraphStyleId.Val != null)
                            //    {
                            //        P.ParagraphProperties.ParagraphStyleId.Val.Value = "SmallSquareList";
                            //    }
                            //    else
                            //    {
                            //        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "SmallSquareList" };
                            //    }
                            //}
                            //else
                            //{
                            //    P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "SmallSquareList" });   //24_09_2019

                            //}
                        }
                        else if (strBull5 != null)
                        {
                            if (P.ParagraphProperties != null)  //Developer name:priyanka vishwakarma ,Date:13_09_2019 ,Requirement:Not apply Listing for Appendix in word document .,Integrated by:Vikas sir.   //Developer Name:Priyanka Vishwakarma , Date:25_5_2019 ,Requirement:Within table Para start with No. of K-wires this is consider as Alpha num list to avoid check if para has "TCH" char style. ,Integrated by:Vikas Sir  //Developer name:priyanka vishwakarma ,Date:24_08_2019 ,Requirement:Not apply Listing for Appendix in word document .,Integrated by:Vikas sir.   //Developer Name:Priyanka Vishwakarma , Date:25_5_2019 ,Requirement:Within table Para start with No. of K-wires this is consider as Alpha num list to avoid check if para has "TCH" char style. ,Integrated by:Vikas Sir
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId.Val != "TCH" && /*P.ParagraphProperties.ParagraphStyleId.Val != "NL" &&*/ P.ParagraphProperties.ParagraphStyleId.Val != "UID")
                                    {
                                        {
                                            P.ParagraphProperties.ParagraphStyleId.Val.Value = "BullList";
                                        }
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "BullList" };
                                }
                            }
                            else
                            {
                                P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "BullList" });   //24_09_2019

                            }
                            //if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null)
                            //{
                            //    if (P.ParagraphProperties.ParagraphStyleId.Val != null)
                            //    {
                            //        P.ParagraphProperties.ParagraphStyleId.Val.Value = "BullList";
                            //    }
                            //    else
                            //    {
                            //        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "BullList" };
                            //    }
                            //}
                            //else
                            //{
                            //    P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "BullList" });   //24_09_2019

                            //}
                        }
                        else if (strBull6 != null)
                        {
                            if (P.ParagraphProperties != null)  //Developer name:priyanka vishwakarma ,Date:13_09_2019 ,Requirement:Not apply Listing for Appendix in word document .,Integrated by:Vikas sir.   //Developer Name:Priyanka Vishwakarma , Date:25_5_2019 ,Requirement:Within table Para start with No. of K-wires this is consider as Alpha num list to avoid check if para has "TCH" char style. ,Integrated by:Vikas Sir  //Developer name:priyanka vishwakarma ,Date:24_08_2019 ,Requirement:Not apply Listing for Appendix in word document .,Integrated by:Vikas sir.   //Developer Name:Priyanka Vishwakarma , Date:25_5_2019 ,Requirement:Within table Para start with No. of K-wires this is consider as Alpha num list to avoid check if para has "TCH" char style. ,Integrated by:Vikas Sir
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId.Val != "TCH" && /*P.ParagraphProperties.ParagraphStyleId.Val != "NL" &&*/ P.ParagraphProperties.ParagraphStyleId.Val != "UID")
                                    {
                                        {
                                            P.ParagraphProperties.ParagraphStyleId.Val.Value = "BullList";
                                        }
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "BullList" };
                                }
                            }
                            else
                            {
                                P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "BullList" });   //24_09_2019

                            }
                            //if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null)
                            //{
                            //    if (P.ParagraphProperties.ParagraphStyleId.Val != null)
                            //    {
                            //        P.ParagraphProperties.ParagraphStyleId.Val.Value = "BullList";
                            //    }
                            //    else
                            //    {
                            //        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "BullList" };
                            //    }
                            //}
                            //else
                            //{
                            //    P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "BullList" });   //24_09_2019

                            //}

                        }
                        else if (strBull7 != null)
                        {
                            if (P.ParagraphProperties != null)  //Developer name:priyanka vishwakarma ,Date:13_09_2019 ,Requirement:Not apply Listing for Appendix in word document .,Integrated by:Vikas sir.   //Developer Name:Priyanka Vishwakarma , Date:25_5_2019 ,Requirement:Within table Para start with No. of K-wires this is consider as Alpha num list to avoid check if para has "TCH" char style. ,Integrated by:Vikas Sir  //Developer name:priyanka vishwakarma ,Date:24_08_2019 ,Requirement:Not apply Listing for Appendix in word document .,Integrated by:Vikas sir.   //Developer Name:Priyanka Vishwakarma , Date:25_5_2019 ,Requirement:Within table Para start with No. of K-wires this is consider as Alpha num list to avoid check if para has "TCH" char style. ,Integrated by:Vikas Sir
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId.Val != "TCH" && /*P.ParagraphProperties.ParagraphStyleId.Val != "NL" &&*/ P.ParagraphProperties.ParagraphStyleId.Val != "UID")
                                    {
                                        {
                                            P.ParagraphProperties.ParagraphStyleId.Val.Value = "BullList";
                                        }
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "BullList" };
                                }
                            }
                            else
                            {
                                P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "BullList" });   //24_09_2019

                            }
                            //if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null)
                            //{
                            //    if (P.ParagraphProperties.ParagraphStyleId.Val != null)
                            //    {
                            //        P.ParagraphProperties.ParagraphStyleId.Val.Value = "BullList";
                            //    }
                            //    else
                            //    {
                            //        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "BullList" };
                            //    }
                            //}
                            //else
                            //{
                            //    P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "BullList" });   //24_09_2019

                            //}
                        }
                        else if (strBull8 != null)
                        {
                            if (P.ParagraphProperties != null)  //Developer name:priyanka vishwakarma ,Date:13_09_2019 ,Requirement:Not apply Listing for Appendix in word document .,Integrated by:Vikas sir.   //Developer Name:Priyanka Vishwakarma , Date:25_5_2019 ,Requirement:Within table Para start with No. of K-wires this is consider as Alpha num list to avoid check if para has "TCH" char style. ,Integrated by:Vikas Sir  //Developer name:priyanka vishwakarma ,Date:24_08_2019 ,Requirement:Not apply Listing for Appendix in word document .,Integrated by:Vikas sir.   //Developer Name:Priyanka Vishwakarma , Date:25_5_2019 ,Requirement:Within table Para start with No. of K-wires this is consider as Alpha num list to avoid check if para has "TCH" char style. ,Integrated by:Vikas Sir
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId.Val != "TCH" && /*P.ParagraphProperties.ParagraphStyleId.Val != "NL" &&*/ P.ParagraphProperties.ParagraphStyleId.Val != "UID")
                                    {
                                        {
                                            P.ParagraphProperties.ParagraphStyleId.Val.Value = "BullList";
                                        }
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "BullList" };
                                }
                            }
                            else
                            {
                                P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "BullList" });   //24_09_2019

                            }
                            //if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null)
                            //{
                            //    if (P.ParagraphProperties.ParagraphStyleId.Val != null)
                            //    {
                            //        P.ParagraphProperties.ParagraphStyleId.Val.Value = "BullList";
                            //    }
                            //    else
                            //    {
                            //        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "BullList" };
                            //    }
                            //}
                            //else
                            //{
                            //    P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "BullList" });   //24_09_2019

                            //}
                        }
                        else if (strBull9 != null)
                        {
                            if (P.ParagraphProperties != null)  //Developer name:priyanka vishwakarma ,Date:13_09_2019 ,Requirement:Not apply Listing for Appendix in word document .,Integrated by:Vikas sir.   //Developer Name:Priyanka Vishwakarma , Date:25_5_2019 ,Requirement:Within table Para start with No. of K-wires this is consider as Alpha num list to avoid check if para has "TCH" char style. ,Integrated by:Vikas Sir  //Developer name:priyanka vishwakarma ,Date:24_08_2019 ,Requirement:Not apply Listing for Appendix in word document .,Integrated by:Vikas sir.   //Developer Name:Priyanka Vishwakarma , Date:25_5_2019 ,Requirement:Within table Para start with No. of K-wires this is consider as Alpha num list to avoid check if para has "TCH" char style. ,Integrated by:Vikas Sir
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId.Val != "TCH" && /*P.ParagraphProperties.ParagraphStyleId.Val != "NL" &&*/ P.ParagraphProperties.ParagraphStyleId.Val != "UID")
                                    {
                                        {
                                            P.ParagraphProperties.ParagraphStyleId.Val.Value = "BullList";
                                        }
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "BullList" };
                                }
                            }
                            else
                            {
                                P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "BullList" });   //24_09_2019

                            }
                            //if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null)
                            //{
                            //    if (P.ParagraphProperties.ParagraphStyleId.Val != null)
                            //    {
                            //        P.ParagraphProperties.ParagraphStyleId.Val.Value = "BullList";
                            //    }
                            //    else
                            //    {
                            //        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "BullList" };
                            //    }
                            //}
                            //else
                            //{
                            //    P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "BullList" });   //24_09_2019

                            //}
                        }
                        //else if (strBull10 != null)
                        //{
                        //    if (P.ParagraphProperties != null)  //Developer name:priyanka vishwakarma ,Date:13_09_2019 ,Requirement:Not apply Listing for Appendix in word document .,Integrated by:Vikas sir.   //Developer Name:Priyanka Vishwakarma , Date:25_5_2019 ,Requirement:Within table Para start with No. of K-wires this is consider as Alpha num list to avoid check if para has "TCH" char style. ,Integrated by:Vikas Sir  //Developer name:priyanka vishwakarma ,Date:24_08_2019 ,Requirement:Not apply Listing for Appendix in word document .,Integrated by:Vikas sir.   //Developer Name:Priyanka Vishwakarma , Date:25_5_2019 ,Requirement:Within table Para start with No. of K-wires this is consider as Alpha num list to avoid check if para has "TCH" char style. ,Integrated by:Vikas Sir
                        //    {
                        //        if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                        //        {
                        //            if (P.ParagraphProperties.ParagraphStyleId.Val != "TCH" && /*P.ParagraphProperties.ParagraphStyleId.Val != "NL" &&*/ P.ParagraphProperties.ParagraphStyleId.Val != "UID")
                        //            {
                        //                {
                        //                    P.ParagraphProperties.ParagraphStyleId.Val.Value = "CircList";
                        //                }
                        //            }
                        //        }
                        //        else
                        //        {
                        //            P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "CircList" };
                        //        }
                        //    }
                        //    else
                        //    {
                        //        P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "CircList" });   //24_09_2019

                        //    }
                        //    //if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null)
                        //    //{
                        //    //    if (P.ParagraphProperties.ParagraphStyleId.Val != null)
                        //    //    {
                        //    //        P.ParagraphProperties.ParagraphStyleId.Val.Value = "CircList";
                        //    //    }
                        //    //    else
                        //    //    {
                        //    //        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "CircList" };
                        //    //    }
                        //    //}
                        //    //else
                        //    //{
                        //    //    P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "CircList" });   //24_09_2019

                        //    //}
                        //}
                        else if (strSquare != null)
                        {
                            if (P.ParagraphProperties != null)  //Developer name:priyanka vishwakarma ,Date:13_09_2019 ,Requirement:Not apply Listing for Appendix in word document .,Integrated by:Vikas sir.   //Developer Name:Priyanka Vishwakarma , Date:25_5_2019 ,Requirement:Within table Para start with No. of K-wires this is consider as Alpha num list to avoid check if para has "TCH" char style. ,Integrated by:Vikas Sir  //Developer name:priyanka vishwakarma ,Date:24_08_2019 ,Requirement:Not apply Listing for Appendix in word document .,Integrated by:Vikas sir.   //Developer Name:Priyanka Vishwakarma , Date:25_5_2019 ,Requirement:Within table Para start with No. of K-wires this is consider as Alpha num list to avoid check if para has "TCH" char style. ,Integrated by:Vikas Sir
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId.Val != "TCH" && /*P.ParagraphProperties.ParagraphStyleId.Val != "NL" &&*/ P.ParagraphProperties.ParagraphStyleId.Val != "UID")
                                    {
                                        {
                                            P.ParagraphProperties.ParagraphStyleId.Val.Value = "EmptySquareList";
                                        }
                                    }
                                }
                                else
                                {
                                    P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "EmptySquareList" };
                                }
                            }
                            else
                            {
                                P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "EmptySquareList" });   //24_09_2019

                            }
                            //if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null)
                            //{
                            //    if (P.ParagraphProperties.ParagraphStyleId.Val != null)
                            //    {
                            //        P.ParagraphProperties.ParagraphStyleId.Val.Value = "EmptySquareList";
                            //    }
                            //    else
                            //    {
                            //        P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "EmptySquareList" };
                            //    }
                            //}
                            //else
                            //{
                            //    P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "EmptySquareList" });   //24_09_2019
                            //}
                        }


                    }
                }
                D.Save();
            }
        }
        #endregion
        public static bool checklistisCircleList(Paragraph p, string listText)
        {
            if (listText.EndsWith(" "))
            {
                return true;
            }
            if (p.Descendants<Run>().Any(x => x.InnerText == listText))
            {
                var runfirst = p.Descendants<Run>().Where(x => x.InnerText == listText).FirstOrDefault();
                if (runfirst.NextSibling().Count() > 0)
                {
                    var checktab = runfirst.NextSibling().Any(x => x.LocalName == W.tab.LocalName);
                    if (checktab)
                    {
                        foreach (var tx in runfirst.NextSibling())
                        {
                            if (tx.LocalName == W.tab.LocalName)
                            {
                                tx.Remove();
                            }

                        }
                        if (runfirst.NextSibling().Any(x => x.LocalName == W.t.LocalName))
                        {
                            foreach (var tx in runfirst.NextSibling().Descendants())
                            {
                                if (tx.LocalName == W.t.LocalName)
                                {
                                    ((Text)tx).Text = ((Text)tx).Text + "\u00A0";////tab replace with space
                                }

                            }
                        }
                        else
                        {
                            if (runfirst.NextSibling().FirstOrDefault().Parent != null && runfirst.NextSibling().FirstOrDefault().Parent.LocalName == W.r.LocalName)
                                runfirst.NextSibling().FirstOrDefault().Parent.Append(new Text() { Text = "\u00A0" });////tab replace with space
                        }
                        return true;
                    }
                }
            }

            return false;
        }

        //Developer Name:Priyanka Vishwakarma , Date:30_5_2019 , Requirement:Apply TCHCenter style within table which table head having center alignment ,Integrated By:Vikas sir.
        public static void ApplyTCH_CenterTableStyles(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (var xe1 in D.Descendants<DocumentFormat.OpenXml.Wordprocessing.Table>().ToList())
                {
                    foreach (var xe2 in xe1.Descendants<DocumentFormat.OpenXml.Wordprocessing.TableRow>().ToList())
                    {
                        foreach (var xe3 in xe2.Descendants<DocumentFormat.OpenXml.Wordprocessing.TableCell>().ToList())
                        {
                            //Developer name :Priyanka Vishwakarma .Date:22_10_2019 ,Requirement:apply center align to only colspan in table .,Integrated by :Vikas sir.
                            if (xe3.Descendants().ToList().Where(x => x.XName.LocalName.ToString() == "gridSpan").Count() > 0 && Convert.ToInt32(xe3.Descendants().ToList().Where(x => x.XName.LocalName.ToString() == "gridSpan").FirstOrDefault().GetAttribute("val", xe3.NamespaceUri).Value) > 1)
                            {

                                foreach (var xe4 in xe3.Descendants<DocumentFormat.OpenXml.Wordprocessing.Paragraph>().ToList())
                                {
                                    foreach (var xe5 in xe4.Descendants<DocumentFormat.OpenXml.Wordprocessing.ParagraphProperties>().ToList())
                                    {

                                        if (xe4.InnerText.Trim() != "" && xe5.Descendants().Where(x => x.XName == W.pStyle).ToList().Count > 0 && xe5.Descendants().Where(x => x.XName == W.pStyle).FirstOrDefault().GetAttribute("val", xe5.NamespaceUri).Value == "TCH" && xe5.Descendants().Where(x => x.XName == W.jc).ToList().Count() > 0 && xe5.Descendants().Where(x => x.XName == W.jc).LastOrDefault().GetAttribute("val", xe5.NamespaceUri).Value == "center")
                                        {

                                            foreach (var xe6 in xe5.Descendants().ToList())
                                            {
                                                if (xe6.LocalName == "pStyle")
                                                {
                                                    xe4.ParagraphProperties.ParagraphStyleId.Val = "TCHCenter";
                                                }
                                            }
                                        }

                                    }
                                }
                            }
                        }
                    }
                }

                D.Save();
                WPD.Save();
            }

        }

        //-------------------------Developer Name:Priyanka Vishwakarma ,Date:29_6_2019 ,Requirement :Multiple Multiple TCH Handle (doc: ASJO-19-00012.docx)
        public static void ApplyTXTToTCHWithinTable(string newDoc)
        {
            int row_count = 0;
            using (WordprocessingDocument WPD = WordprocessingDocument
                .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (var xe1 in D.Descendants<DocumentFormat.OpenXml.Wordprocessing.Table>().ToList())
                {
                    row_count = 0;
                    foreach (var xe2 in xe1.Descendants<DocumentFormat.OpenXml.Wordprocessing.TableRow>().ToList())  //w:tr 
                    {
                        row_count++;

                        foreach (var xe3 in xe2.Descendants<DocumentFormat.OpenXml.Wordprocessing.TableCell>().ToList())  //w:tc 
                        {
                            foreach (var xe4 in xe3.Descendants<DocumentFormat.OpenXml.Wordprocessing.Paragraph>().ToList())
                            {
                                foreach (var xe5 in xe4.Descendants<DocumentFormat.OpenXml.Wordprocessing.ParagraphProperties>().ToList())
                                {

                                    if (xe4.InnerText.Trim() != "" && xe5.Descendants().Where(x => x.XName == W.pStyle).ToList().Count > 0 && xe5.Descendants().Where(x => x.XName == W.pStyle).FirstOrDefault().GetAttribute("val", xe5.NamespaceUri).Value == "TCH" && row_count > 4)//change on 11_09_2019 for apply TCH style to t-txt style in table.
                                    {
                                        foreach (var xe6 in xe5.Descendants().ToList())
                                        {
                                            if (xe6.LocalName == "pStyle")
                                            {
                                                xe4.ParagraphProperties.ParagraphStyleId.Val = "T-TXT";

                                            }
                                        }

                                        foreach (var run1 in xe4.Descendants<DocumentFormat.OpenXml.Wordprocessing.Run>().ToList())
                                        {
                                            Bold bold = new Bold();
                                            run1.RunProperties.AppendChild(bold);
                                        }
                                    }

                                }
                            }
                        }
                    }
                }

                D.Save();
                WPD.Save();
            }

        }

        public static void ApplyTXTToTCHWithinTableForSageIndia(string newDoc)
        {
            int row_count = 0;
            using (WordprocessingDocument WPD = WordprocessingDocument
                .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (var xe1 in D.Descendants<DocumentFormat.OpenXml.Wordprocessing.Table>().ToList())
                {
                    row_count = 0;
                    foreach (var xe2 in xe1.Descendants<DocumentFormat.OpenXml.Wordprocessing.TableRow>().ToList())  //w:tr 
                    {
                        row_count++;

                        foreach (var xe3 in xe2.Descendants<DocumentFormat.OpenXml.Wordprocessing.TableCell>().ToList())  //w:tc 
                        {
                            foreach (var xe4 in xe3.Descendants<DocumentFormat.OpenXml.Wordprocessing.Paragraph>().ToList())
                            {
                                foreach (var xe5 in xe4.Descendants<DocumentFormat.OpenXml.Wordprocessing.ParagraphProperties>().ToList())
                                {

                                    if (xe4.InnerText.Trim() != "" && xe5.Descendants().Where(x => x.XName == W.pStyle).ToList().Count > 0 && xe5.Descendants().Where(x => x.XName == W.pStyle).FirstOrDefault().GetAttribute("val", xe5.NamespaceUri).Value == "TCH" && row_count > 2)//change on 11_09_2019 for apply TCH style to t-txt style in table.
                                    {
                                        foreach (var xe6 in xe5.Descendants().ToList())
                                        {
                                            if (xe6.LocalName == "pStyle")
                                            {
                                                xe4.ParagraphProperties.ParagraphStyleId.Val = "T-TXT";

                                            }
                                        }

                                        foreach (var run1 in xe4.Descendants<DocumentFormat.OpenXml.Wordprocessing.Run>().ToList())
                                        {
                                            Bold bold = new Bold();
                                            if (run1.RunProperties != null)
                                            {
                                                run1.RunProperties.AppendChild(bold);
                                            }
                                        }
                                    }

                                }
                            }
                        }
                    }
                }

                D.Save();
                WPD.Save();
            }

        }

        public static void CheckRowInTable(string newDoc)
        {
            int row_count = 0;
            using (WordprocessingDocument WPD = WordprocessingDocument
                .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (var xe1 in D.Descendants<DocumentFormat.OpenXml.Wordprocessing.Table>().ToList())
                {
                    row_count = 0;
                    foreach (var xe2 in xe1.Descendants<DocumentFormat.OpenXml.Wordprocessing.TableRow>().ToList())  //w:tr 
                    {

                        if (xe2.Descendants().ToList().Where(x => x.XName.LocalName == "vMerge").ToList().Count() > 0 || xe2.Descendants().ToList().Where(x => x.XName.LocalName == "gridSpan").ToList().Count() > 0)
                        {
                            row_count++;
                            if (row_count < 2)
                            {
                                var TblParaList = xe2.Descendants<DocumentFormat.OpenXml.Wordprocessing.TableCell>().ToList();
                                bool allParaTextBold = false;
                                string paraStyle = "";

                                foreach (var para in TblParaList.ToList())
                                {
                                    foreach (var parasty in para.Descendants<DocumentFormat.OpenXml.Wordprocessing.Paragraph>().ToList())
                                    {
                                        if (parasty.ParagraphProperties != null && parasty.ParagraphProperties.ParagraphStyleId != null && parasty.ParagraphProperties.ParagraphStyleId.Val != null && parasty.ParagraphProperties.ParagraphStyleId.Val.Value == "TCH")
                                        {
                                            allParaTextBold = true;
                                        }
                                        else if (parasty.ParagraphProperties != null && parasty.ParagraphProperties.ParagraphStyleId != null && parasty.ParagraphProperties.ParagraphStyleId.Val != null && parasty.ParagraphProperties.ParagraphStyleId.Val.Value == "T-TXT")
                                        {
                                            paraStyle = parasty.ParagraphProperties.ParagraphStyleId.Val.Value;
                                        }
                                        else
                                        {
                                            allParaTextBold = false;
                                        }
                                    }
                                }

                                if (allParaTextBold == true && paraStyle != "T-TXT")
                                {
                                    var nertTR = xe2.NextSibling();
                                    if (nertTR != null)
                                    {
                                        bool allParaTextBold1 = false;
                                        var TblParaList1 = nertTR.Descendants<DocumentFormat.OpenXml.Wordprocessing.TableCell>().ToList();

                                        foreach (var para1 in TblParaList1.ToList())
                                        {
                                            foreach (var parasty1 in para1.Descendants<DocumentFormat.OpenXml.Wordprocessing.Paragraph>().ToList())
                                            {
                                                if (parasty1.InnerText.Trim() != "") ////Developer Name:Priyanka Vishwakarma,Date:29-09-2021,Requirement:Add function for apply T-TXT to bold text in table from second row 
                                                {
                                                    if (parasty1.ParagraphProperties != null && parasty1.ParagraphProperties.ParagraphStyleId != null && parasty1.ParagraphProperties.ParagraphStyleId.Val != null && parasty1.ParagraphProperties.ParagraphStyleId.Val.Value == "TCH")
                                                    {
                                                        allParaTextBold1 = true;
                                                    }
                                                    else
                                                    {
                                                        allParaTextBold1 = false;
                                                    }
                                                }
                                            }
                                        }

                                        if (allParaTextBold1 == false)
                                        {
                                            foreach (var para in TblParaList.ToList())
                                            {
                                                foreach (var parasty in para.Descendants<DocumentFormat.OpenXml.Wordprocessing.Paragraph>().ToList())
                                                {
                                                    if (parasty.ParagraphProperties != null && parasty.ParagraphProperties.ParagraphStyleId != null && parasty.ParagraphProperties.ParagraphStyleId.Val != null )
                                                    {
                                                        parasty.ParagraphProperties.ParagraphStyleId.Val.Value = "T-TXT";
                                                    }
                                                    if (parasty.ParagraphProperties != null && parasty.ParagraphProperties.ParagraphStyleId != null && parasty.ParagraphProperties.ParagraphStyleId.Val != null && parasty.ParagraphProperties.ParagraphStyleId.Val.Value=="TCH")
                                                    {
                                                        foreach (var run1 in parasty.Descendants<DocumentFormat.OpenXml.Wordprocessing.Run>().ToList())
                                                        {
                                                            Bold bold = new Bold();
                                                            run1.RunProperties.AppendChild(bold);
                                                        }
                                                    }
                                                }

                                            }
                                        }
                                    }
                                }
                                else if (allParaTextBold == false && paraStyle == "T-TXT")
                                {
                                    var nertTR1 = xe2.NextSibling();
                                    if (nertTR1 != null)
                                    {
                                        var TblParaList2 = nertTR1.Descendants<DocumentFormat.OpenXml.Wordprocessing.TableCell>().ToList();

                                        foreach (var para in TblParaList2.ToList())
                                        {
                                            foreach (var parasty in para.Descendants<DocumentFormat.OpenXml.Wordprocessing.Paragraph>().ToList())
                                            {
                                                if (parasty.ParagraphProperties != null && parasty.ParagraphProperties.ParagraphStyleId != null && parasty.ParagraphProperties.ParagraphStyleId.Val != null && parasty.ParagraphProperties.ParagraphStyleId.Val != "T-TXT")
                                                {
                                                    parasty.ParagraphProperties.ParagraphStyleId.Val.Value = "T-TXT";
                                                    foreach (var run1 in parasty.Descendants<DocumentFormat.OpenXml.Wordprocessing.Run>().ToList())
                                                    {
                                                        Bold bold = new Bold();
                                                        run1.RunProperties.AppendChild(bold);
                                                    }
                                                }

                                            }

                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                D.Save();
                WPD.Save();
            }

        }

        public static void CheckAllTableCell(string newDoc)
        {
            int row_count = 0;
            using (WordprocessingDocument WPD = WordprocessingDocument
                .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (var xe1 in D.Descendants<DocumentFormat.OpenXml.Wordprocessing.Table>().ToList())
                {
                    row_count = 0;
                    foreach (var xe2 in xe1.Descendants<DocumentFormat.OpenXml.Wordprocessing.TableRow>().ToList())  //w:tr 
                    {
                        row_count++;
                        if (row_count == 2)
                        {
                            var RowList = xe2.Descendants<DocumentFormat.OpenXml.Wordprocessing.TableCell>().ToList();
                            var allParaTextBold = false;
                            foreach (var row in RowList.ToList())
                            {
                                foreach (var parasty in row.Descendants<DocumentFormat.OpenXml.Wordprocessing.Paragraph>().ToList())
                                {
                                    if (parasty.ParagraphProperties != null && parasty.ParagraphProperties.ParagraphStyleId != null && parasty.ParagraphProperties.ParagraphStyleId.Val != null && parasty.ParagraphProperties.ParagraphStyleId.Val.Value == "TCH")
                                    {
                                        allParaTextBold = true;
                                    }
                                    else
                                    {
                                        allParaTextBold = false;
                                    }
                                }
                            }
                            if (allParaTextBold == false)
                            {
                                foreach (var para in RowList.ToList())
                                {
                                    foreach (var parasty in para.Descendants<DocumentFormat.OpenXml.Wordprocessing.Paragraph>().ToList())
                                    {
                                        if (parasty.ParagraphProperties != null && parasty.ParagraphProperties.ParagraphStyleId != null && parasty.ParagraphProperties.ParagraphStyleId.Val != null && parasty.ParagraphProperties.ParagraphStyleId.Val.Value == "TCH")
                                        {
                                            parasty.ParagraphProperties.ParagraphStyleId.Val.Value = "T-TXT";
                                            foreach (var run1 in parasty.Descendants<DocumentFormat.OpenXml.Wordprocessing.Run>().ToList())
                                            {
                                                Bold bold = new Bold();
                                                run1.RunProperties.AppendChild(bold);
                                            }
                                        }
                                    }
                                }
                            }


                        }
                        else if ((row_count == 1 && xe2.Descendants().ToList().Where(x => x.XName.LocalName == "vMerge").ToList().Count() == 0) || (row_count == 1 && xe2.Descendants().ToList().Where(x => x.XName.LocalName == "gridSpan").ToList().Count() == 0))
                        {
                            var RowList = xe2.Descendants<DocumentFormat.OpenXml.Wordprocessing.TableCell>().ToList();
                            var allParaTextBold = false;
                            foreach (var row in RowList.ToList())
                            {
                                foreach (var parasty in row.Descendants<DocumentFormat.OpenXml.Wordprocessing.Paragraph>().ToList())
                                {
                                    if (parasty.ParagraphProperties != null && parasty.ParagraphProperties.ParagraphStyleId != null && parasty.ParagraphProperties.ParagraphStyleId.Val != null && parasty.ParagraphProperties.ParagraphStyleId.Val.Value == "TCH")
                                    {
                                        allParaTextBold = true;
                                    }
                                    else
                                    {
                                        allParaTextBold = false;
                                    }
                                }
                            }
                            if (allParaTextBold == false)
                            {
                                foreach (var para in RowList.ToList())
                                {
                                    foreach (var parasty in para.Descendants<DocumentFormat.OpenXml.Wordprocessing.Paragraph>().ToList())
                                    {
                                        if (parasty.ParagraphProperties != null && parasty.ParagraphProperties.ParagraphStyleId != null && parasty.ParagraphProperties.ParagraphStyleId.Val != null && parasty.ParagraphProperties.ParagraphStyleId.Val.Value == "TCH")
                                        {
                                            parasty.ParagraphProperties.ParagraphStyleId.Val.Value = "T-TXT";
                                            foreach (var run1 in parasty.Descendants<DocumentFormat.OpenXml.Wordprocessing.Run>().ToList())
                                            {
                                                Bold bold = new Bold();
                                                run1.RunProperties.AppendChild(bold);
                                            }
                                        }
                                    }
                                }
                            }

                        }
                    }
                }

                D.Save();
                WPD.Save();
            }
        }

        //-----------------------------------------end----------------------------------

        public static void mergeCitefigStyle(string strProcessDoc)
        {

            using (WordprocessingDocument WPD = WordprocessingDocument.Open(strProcessDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    Run newR = new Run();
                    string newCitefig = null;
                    bool start = false;
                    //Developer name:Priyanka Vishwakarma ,Date:20_09_2019 ,Requirement:check if last run contains citefig style.Integrated by:Vikas sir.
                    int runCount = 0;
                    int count = P.Descendants<Run>().ToList().Count();

                    foreach (var run in P.Descendants<Run>().ToList())
                    {
                        runCount++;
                        if (run.RunProperties != null && run.RunProperties.RunStyle != null && run.RunProperties.RunStyle.Val != null && run.InnerText.ToLower().StartsWith("fig") || run.InnerText.ToLower().StartsWith("figs") && run.RunProperties.RunStyle.Val == "citefig")
                        {
                            start = true;
                            newR = (Run)run.Clone();
                            newCitefig = run.InnerText;
                            if (runCount == count)
                                break;
                            run.Remove();
                        }
                        else if (run.RunProperties != null && run.RunProperties.RunStyle != null && run.RunProperties.RunStyle.Val != null && (!run.InnerText.ToLower().StartsWith("fig") || !run.InnerText.ToLower().StartsWith("figs")) && run.RunProperties.RunStyle.Val == "citefig")
                        {
                            newCitefig = newCitefig + run.InnerText;
                            if (runCount == count)  //Developer name:Priyanka Vishwakarma ,Date:20_09_2019 ,Requirement:check if last run contains citefig style.Integrated by:Vikas sir.
                                break;
                            run.Remove();

                        }
                        //Developer name:Priyanka Vishwakarma ,Date:20_09_2019 ,Requirement:check if last run contains citefig style.Integrated by:Vikas sir.
                        else if (run.RunProperties != null && run.RunProperties.RunStyle != null && run.RunProperties.RunStyle.Val != null && (!run.InnerText.ToLower().StartsWith("fig") || !run.InnerText.ToLower().StartsWith("figs")) && run.RunProperties.RunStyle.Val == "citefig" && run.InnerText.Trim() == "and")/////condition added by vikas with run.RunProperties != null && run.RunProperties.RunStyle != null && run.RunProperties.RunStyle.Val != null && (!run.InnerText.ToLower().StartsWith("fig") || !run.InnerText.ToLower().StartsWith("figs")) && run.RunProperties.RunStyle.Val == "citefig" with and on 25-11-2019
                        {
                            newCitefig = newCitefig + run.InnerText;
                            if (runCount == count)
                                break;
                            run.Remove();
                        }
                        //----------------------------------------End---------------------
                        else
                        {
                            if (start == true)
                            {
                                var rr = newR.InnerText;
                                foreach (Text T in newR.Descendants<Text>().ToList())
                                {
                                    T.Text = newCitefig;

                                }
                                run.InsertBeforeSelf(newR);
                                start = false;

                            }

                        }


                    }




                }
                D.Save();
            }
        }
        //Developer Name:Priyanka Vishwakarma , Date:27_09_2019 , Requirement:Apply TCH Paragraph style to bold text within Table. ,Integrated By:Vikas sir.
        public static void ApplyTCHStyleInTable(string newDoc)
        {
            int row_count = 0;
            using (WordprocessingDocument WPD = WordprocessingDocument
                .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (var xe1 in D.Descendants<DocumentFormat.OpenXml.Wordprocessing.Table>().ToList())
                {
                    row_count = 0;
                    foreach (var xe2 in xe1.Descendants<DocumentFormat.OpenXml.Wordprocessing.TableRow>().ToList())  //w:tr 
                    {
                        row_count++;

                        foreach (var xe3 in xe2.Descendants<DocumentFormat.OpenXml.Wordprocessing.TableCell>().ToList())  //w:tc 
                        {
                            foreach (var xe4 in xe3.Descendants<DocumentFormat.OpenXml.Wordprocessing.Paragraph>().ToList())
                            {
                                //if (xe5.Descendants().Any(x => x.XName == W.b /*|| x.XName == W.bCs*/))
                                if (CheckifCompleteParaIsBold(xe4.Descendants<Run>().Where(x => x.InnerText.Trim() != "")) == true)
                                {
                                    if (xe4.ParagraphProperties != null)
                                    {
                                        if (xe4.ParagraphProperties.ParagraphStyleId != null)
                                        {
                                            if (xe4.ParagraphProperties.ParagraphStyleId.Val != null && xe4.ParagraphProperties.ParagraphStyleId.Val.Value != "T-TXT")   //Developer name:Priyanka vishwakarma ,Date:04-03-2020 ,Requirement:T-TXT style change to TCH style in Table . Integrated by:Vikas sir. 4537_THI_J_4530_IJCDW-20-0211.docx
                                            {
                                                xe4.ParagraphProperties.ParagraphStyleId.Val = "TCH";
                                            }
                                        }
                                        else
                                        {
                                            xe4.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "TCH" };
                                        }
                                    }
                                    else
                                    {
                                        xe4.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "TCH" });
                                    }
                                }
                                else
                                {

                                }

                            }




                        }
                    }
                }

                D.Save();
                WPD.Save();
            }

        }
        public static void ApplyCenterAlignForColspan(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (var xe1 in D.Descendants<DocumentFormat.OpenXml.Wordprocessing.Table>().ToList())
                {
                    foreach (var xe2 in xe1.Descendants<DocumentFormat.OpenXml.Wordprocessing.TableRow>().ToList())
                    {
                        foreach (var xe3 in xe2.Descendants<DocumentFormat.OpenXml.Wordprocessing.TableCell>().ToList())
                        {
                            //Developer name :Priyanka Vishwakarma .Date:22_10_2019 ,Requirement:apply center align to only colspan in table .,Integrated by :Vikas sir.
                            if (xe3.Descendants().ToList().Where(x => x.XName.LocalName.ToString() == "gridSpan").Count() > 0 && Convert.ToInt32(xe3.Descendants().ToList().Where(x => x.XName.LocalName.ToString() == "gridSpan").FirstOrDefault().GetAttribute("val", xe3.NamespaceUri).Value) > 1)
                            {

                                foreach (var xe4 in xe3.Descendants<DocumentFormat.OpenXml.Wordprocessing.Paragraph>().ToList())
                                {
                                    if (xe4.Descendants().ToList().Where(x => x.LocalName.ToString() == "r").ToList().Count() > 0 && xe4.Descendants().ToList().Where(x => x.LocalName.ToString() == "r").ToList().Count() == 1)
                                    {
                                        foreach (var xe5 in xe4.Descendants<DocumentFormat.OpenXml.Wordprocessing.ParagraphProperties>().ToList())
                                        {

                                            if (xe4.InnerText.Trim() != "" && xe5.Descendants().Where(x => x.XName == W.pStyle).ToList().Count > 0 && xe5.Descendants().Where(x => x.XName == W.pStyle).FirstOrDefault().GetAttribute("val", xe5.NamespaceUri).Value == "TCH")
                                            {

                                                foreach (var xe6 in xe5.Descendants().ToList())
                                                {
                                                    if (xe6.LocalName == "pStyle")
                                                    {
                                                        xe4.ParagraphProperties.ParagraphStyleId.Val = "TCHCenter";
                                                    }
                                                }
                                            }
                                            else if (xe4.InnerText.Trim() != "" && xe5.Descendants().Where(x => x.XName == W.pStyle).ToList().Count > 0 && xe5.Descendants().Where(x => x.XName == W.pStyle).FirstOrDefault().GetAttribute("val", xe5.NamespaceUri).Value == "T-TXT")
                                            {

                                                foreach (var xe6 in xe5.Descendants().ToList())
                                                {
                                                    if (xe6.LocalName == "pStyle")
                                                    {
                                                        xe4.ParagraphProperties.ParagraphStyleId.Val = "T-TXTCenter";
                                                    }
                                                }
                                            }

                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                D.Save();
                WPD.Save();
            }

        }
        //--- Developer name:Priyanka Vishwakarma , Date: 11-01-2020 ,Requirement:Add * as Superscript in Word when it does not come as Superscript only with in AU Paragraph ,Integrated by:Vikas sir.
        public static void addVeralignForAstricInAUPara(string strProcessDoc)
        {

            using (WordprocessingDocument WPD = WordprocessingDocument.Open(strProcessDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(x => x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val != null && x.ParagraphProperties.ParagraphStyleId.Val.Value == "AU"))
                {
                    if (P.InnerText.Contains("*"))
                    {
                        foreach (Run r in P.Descendants<Run>().Where(x => x.InnerText == "*" || x.InnerText.Contains("*")).ToList())
                        {
                            if (r.Descendants().ToList().Where(x => x.LocalName == "vertAlign").ToList().Count() == 0)
                            {
                                if (r.InnerText.Contains("*") && r.InnerText.Trim().StartsWith("***"))
                                {
                                    Run supRun = new Run(new RunProperties(new Bold(), new VerticalTextAlignment() { Val = VerticalPositionValues.Superscript }), new Text("****"));

                                    foreach (var text in r.Descendants<Text>().ToList())
                                    {
                                        if (text.Text.Contains("***"))
                                        {
                                            text.Text = text.Text.Replace("***", " ");
                                        }
                                    }

                                    r.InsertBeforeSelf(supRun);

                                }
                                else if (r.InnerText.Contains("**") && r.InnerText.Trim().StartsWith("**"))
                                {
                                    Run supRun = new Run(new RunProperties(new Bold(), new VerticalTextAlignment() { Val = VerticalPositionValues.Superscript }), new Text("**"));

                                    foreach (var text in r.Descendants<Text>().ToList())
                                    {
                                        if (text.Text.Contains("**"))
                                        {
                                            text.Text = text.Text.Replace("**", " ");
                                        }
                                    }

                                    r.InsertBeforeSelf(supRun);

                                }
                                else if (r.InnerText.Contains("*") && r.InnerText.Trim().StartsWith("*"))
                                {
                                    Run supRun = new Run(new RunProperties(new Bold(), new VerticalTextAlignment() { Val = VerticalPositionValues.Superscript }), new Text("*"));

                                    foreach (var text in r.Descendants<Text>().ToList())
                                    {
                                        if (text.Text.Contains("*"))
                                        {
                                            text.Text = text.Text.Replace("*", " ");
                                        }
                                    }

                                    r.InsertBeforeSelf(supRun);

                                }

                            }

                        }
                    }

                }
                D.Save();
            }
        }
        public static void KeywordandAbstractparaRemoveList(string strProcessDoc)
        {
            bool foundBodySectionData = false;
            bool AbstractTextStart = false;

            using (WordprocessingDocument WPD = WordprocessingDocument.Open(strProcessDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(x => x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val != null))
                {
                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val.Value == "AB")
                    {
                        AbstractTextStart = true;
                    }
                    else if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && (P.ParagraphProperties.ParagraphStyleId.Val.Value == "H1" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H2" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H3" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H4" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H5" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H6" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H7"))
                    {
                        foundBodySectionData = true;
                        AbstractTextStart = false;
                    }
                    if (foundBodySectionData == false && AbstractTextStart == true)
                    {
                        if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                        {
                            if (P.Parent.XName.LocalName != "tc" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "KYWD" && (P.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower() == "nl" || P.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower() == "bl" || P.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower() == "ul" || P.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower().EndsWith("list")))
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "AB-TXT";
                            }
                        }
                    }
                }
                D.Save();
            }
        }

        public static void FloridaArticleMappinngBasedonText(string newDoc)
        {
            bool abstractParaStart = false; //Developer name:Priyanka Vishwakarma, Date:25-03-2021, Requirement:handle Abstract with 2 or more Paras till next heading or keywords.
            if (GlobalMethods.strCopyEditingRequired != null && GlobalMethods.strCopyEditingRequired.ToLower() == "true")
                ConvertTOHardEnters(newDoc);
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;


                foreach (Paragraph P in D.Descendants<Paragraph>().Where(x => x.Parent != null && x.Parent.LocalName != W.tc.LocalName).ToList())
                {

                    if (P.InnerText.StartsWith("<a>"))
                    {
                        P.Descendants<Text>().FirstOrDefault().Text = P.Descendants<Text>().FirstOrDefault().Text.Replace("<a>", "");
                        if (P.Descendants<Text>().FirstOrDefault().Text != "<a>")
                        {
                            string text = "";
                            foreach (var r in P.Descendants<Run>().ToList())
                            {
                                if (r.Descendants().Where(x => x.LocalName.ToString() == "b").ToList().Count() == 0)
                                {
                                    text += r.InnerText;
                                }
                            }

                            if (text == "<a>")
                            {
                                foreach (var r in P.Descendants<Run>().ToList())
                                {
                                    if (r.Descendants().Where(x => x.LocalName.ToString() == "b").ToList().Count() == 0)
                                    {
                                        r.Remove();
                                    }
                                }
                            }

                        }

                        // P.Descendants<Text>().FirstOrDefault().Text = P.Descendants<Text>().FirstOrDefault().Text.Replace("<a>", "");
                        if (P.ParagraphProperties != null && (P.InnerText != "References Cited" && P.InnerText != "References" && P.InnerText != "Reference" && P.InnerText != "Selected Bibliography" && P.InnerText.ToLower().Trim()!= "bibliografia"))//Developer Name:Priyanka Vishwakarma,Date:11-05-2021,Requirement:Add condiiton for apply ref style.
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "H1";
                                abstractParaStart = false;

                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "H1" });
                                abstractParaStart = false;
                            }
                        }
                        else if (P.ParagraphProperties != null && (P.InnerText == "References Cited" || P.InnerText == "References" || P.InnerText == "Reference" || P.InnerText == "Selected Bibliography"))//Developer Name:Priyanka Vishwakarma,Date:11-05-2021,Requirement:Add condiiton for apply ref style.
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "REF";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "REF" });
                            }
                        }
                        else if (P.InnerText == "References Cited" || P.InnerText == "References" || P.InnerText == "Reference")
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "REF" }));

                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "H1" }));

                        }
                    }
                    else if (P.InnerText.StartsWith("<b>"))
                    {
                        P.Descendants<Text>().FirstOrDefault().Text = P.Descendants<Text>().FirstOrDefault().Text.Replace("<b>", "");
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "H2";
                                abstractParaStart = false;
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "H2" });
                                abstractParaStart = false;
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "H2" }));
                            abstractParaStart = false;

                        }
                    }
                    else if (P.InnerText.StartsWith("<c>"))
                    {
                        P.Descendants<Text>().FirstOrDefault().Text = P.Descendants<Text>().FirstOrDefault().Text.Replace("<c>", "");
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "H3";
                                abstractParaStart = false;
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "H3" });
                                abstractParaStart = false;
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "H3" }));
                            abstractParaStart = false;

                        }
                    }
                    else if (P.InnerText.StartsWith("<ab>"))
                    {
                        P.Descendants<Text>().FirstOrDefault().Text = P.Descendants<Text>().FirstOrDefault().Text.Replace("<ab>", "");
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "AB";
                                abstractParaStart = true;
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "AB" });
                                abstractParaStart = true;
                            }

                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "AB" }));
                            abstractParaStart = true;

                        }
                    }
                    else if (P.InnerText.StartsWith("<rh>"))
                    {
                        P.Descendants<Text>().FirstOrDefault().Text = P.Descendants<Text>().FirstOrDefault().Text.Replace("<rh>", "");
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "RRH";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "RRH" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "RRH" }));

                        }
                    }
                    else if (P.InnerText.StartsWith("<ct>"))
                    {
                        P.Descendants<Text>().FirstOrDefault().Text = P.Descendants<Text>().FirstOrDefault().Text.Replace("<ct>", "");
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "TI";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "TI" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "TI" }));

                        }
                    }
                    //Developer Name:Priyanka Vishwakarma,Date:20-01-2021,Requirement:Apply TI style to para which start with <cs> for UFL.
                    else if (P.InnerText.StartsWith("<cs>"))
                    {
                        P.Descendants<Text>().FirstOrDefault().Text = P.Descendants<Text>().FirstOrDefault().Text.Replace("<cs>", "");
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "TI";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "TI" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "TI" }));

                        }
                    }//end on 20-01-2021
                    else if (P.InnerText.StartsWith("<ca>"))
                    {
                        P.Descendants<Text>().FirstOrDefault().Text = P.Descendants<Text>().FirstOrDefault().Text.Replace("<ca>", "");
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "AU";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "AU" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "AU" }));

                        }
                    }
                    else if (P.InnerText.StartsWith("<fn>"))
                    {
                        P.Descendants<Text>().FirstOrDefault().Text = P.Descendants<Text>().FirstOrDefault().Text.Replace("<fn>", "");
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "AFFL";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "AFFL" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "AFFL" }));

                        }
                    }
                    else if (P.InnerText.StartsWith("<key>"))
                    {
                        P.Descendants<Text>().FirstOrDefault().Text = P.Descendants<Text>().FirstOrDefault().Text.Replace("<key>", "");
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "KYWD";
                                abstractParaStart = false;
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "KYWD" });
                                abstractParaStart = false;
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "KYWD" }));
                            abstractParaStart = false;

                        }
                    }
                    else if (P.InnerText.StartsWith("<txt>"))
                    {
                        P.Descendants<Text>().FirstOrDefault().Text = P.Descendants<Text>().FirstOrDefault().Text.Replace("<txt>", "");
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "BodyA";
                                abstractParaStart = false;

                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "BodyA" });
                                abstractParaStart = false;
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "BodyA" }));

                        }
                    }
                    else if (P.InnerText.StartsWith("<ep>") || P.InnerText.StartsWith("<ext>"))
                    {
                        P.Descendants<Text>().FirstOrDefault().Text = P.Descendants<Text>().FirstOrDefault().Text.Replace("<ep>", "").Replace("<ext>", "");
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "EXT";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "EXT" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "EXT" }));

                        }
                    }
                    else if (P.ParagraphProperties != null && P.ParagraphProperties.Justification != null && P.ParagraphProperties.Justification.Val.Value == JustificationValues.Right)
                    {
                        if (P.PreviousSibling() != null && P.PreviousSibling().LocalName == W.p.LocalName && ((Paragraph)P.PreviousSibling()).ParagraphProperties != null && ((Paragraph)P.PreviousSibling()).ParagraphProperties.ParagraphStyleId != null && ((Paragraph)P.PreviousSibling()).ParagraphProperties.ParagraphStyleId.Val == "EXT")
                        {
                            if (P.ParagraphProperties != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                                {
                                    P.ParagraphProperties.ParagraphStyleId.Val.Value = "EXT-AU";
                                }
                                else
                                {
                                    P.ParagraphProperties.Append(new ParagraphStyleId { Val = "EXT-AU" });
                                }
                            }
                            else
                            {
                                P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "EXT-AU" }));

                            }
                        }
                    }
                    else if (P.InnerText.StartsWith("<rc>"))
                    {
                        P.Descendants<Text>().FirstOrDefault().Text = P.Descendants<Text>().FirstOrDefault().Text.Replace("<rc>", "");
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "REF1";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "REF1" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "REF1" }));

                        }
                    }
                    else if (P.InnerText.StartsWith("DOI"))
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "UID";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "UID" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "UID" }));

                        }
                    }
                    else if (P.InnerText.StartsWith("Received") || P.InnerText.StartsWith("Revised") || P.InnerText.StartsWith("Accepted"))
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "UID";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "UID" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "UID" }));

                        }
                    }
                    else if (P.InnerText.StartsWith("*Correspondence to:") || P.InnerText.Trim().StartsWith("E-mail:") || P.InnerText.Trim().StartsWith("*Corresponding author:") || P.InnerText.Trim().ToLower().StartsWith("e-mail:") ||P.InnerText.Trim().ToLower().StartsWith("*corresponding author:"))  //developer name:Priyanka Vishwakarma ,Date:31-08-2021,Requirement:Add condition for apply CORR
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "CORR";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "CORR" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "CORR" }));
                        }
                    }
                    //else if (P.InnerText.StartsWith("<Research Article>") || (P.InnerText == "-" && P.Parent != null && P.Parent.LocalName != W.tc.LocalName))
                    //{
                    //    P.Remove();
                    //}
                    else if (P.InnerText == "" && P.Parent != null && P.Parent.LocalName != W.tc.LocalName)
                    {
                        P.Remove();
                    }

                    else if (abstractParaStart)
                    {
                        P.Descendants<Text>().FirstOrDefault().Text = P.Descendants<Text>().FirstOrDefault().Text.Replace("<ab>", "");
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "AB";

                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "AB" });

                            }

                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "AB" }));


                        }
                    }
                    else if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && (P.ParagraphProperties.ParagraphStyleId.Val == "BodyText" || P.ParagraphProperties.ParagraphStyleId.Val == "EndNoteBibliography" || P.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower() == "paragraph"))
                    {
                        P.ParagraphProperties.ParagraphStyleId.Val = "BodyA";
                    }
                    else if (P.InnerText.Trim() == "<ls>" && P.Parent != null && P.Parent.LocalName != W.tc.LocalName) //Developer Name:Priyanka Vishwakarma,Date:17-02-2021,Requirement:Remove <ls> tag from UFL input.
                    {
                        P.Remove();
                    }
                    //if (Regex.Match(P.InnerText, @"({insert figures|{insert tables)+\s([0-9]+)[\-|\–|\-|\.]+([0-9]+\s(here}))",RegexOptions.IgnoreCase).Success || Regex.Match(P.InnerText, @"({insert figure|{insert table)+\s([0-9]+\s(here}))",RegexOptions.IgnoreCase).Success || Regex.Match(P.InnerText, @"({insert figures|{insert tables)+\s([0-9]+)\s(and)+\s+([0-9]+)\s(here})",RegexOptions.IgnoreCase).Success)
                    if (P.InnerText.Contains("{insert") && P.InnerText.Trim().EndsWith("}"))
                    {
                        foreach (var text in P.Descendants<Text>().ToList())
                        {
                            var txt = text.Text.Split('{');
                            text.Text = txt[0];
                            //if (Regex.Match(text.Text, @"({insert figures)+\s([0-9]+)[\-|\–|\-|\.]+([0-9]+\s(here}))").Success )
                            //{
                            //    text.Text = Regex.Replace(text.Text, @"({insert figures)+\s([0-9]+)[\-|\–|\-|\.]+([0-9]+\s(here}))", "");
                            //}
                            //else if(Regex.Match(text.Text, @"({insert figure)+\s([0-9]+\s(here}))").Success)
                            //{
                            //    text.Text = Regex.Replace(text.Text, @"({insert figure)+\s([0-9]+\s(here}))", "");
                            //}
                            //else if (Regex.Match(text.Text, @"({insert figures)+\s([0-9]+)\s(and)+\s+([0-9]+)\s(here})").Success)
                            //{
                            //    text.Text = Regex.Replace(text.Text, @"({insert figures)+\s([0-9]+)\s(and)+\s+([0-9]+)\s(here})", "");
                            //}                            
                        }
                    }
                }

                D.Save();
            }

            Replaceplaceholders(newDoc);///for remove <c> tag from heading
        }


        public static void ConvertTOHardEnters(string wordFilePath)/////In 3rd level heading <txt> replaced with hard enter needed as different para from <txt> text
        {
            try
            {
                object outputFileName = null;
                object oMissing = System.Reflection.Missing.Value;
                Microsoft.Office.Interop.Word.Application word = new Microsoft.Office.Interop.Word.Application();
                try
                {
                    word.Visible = false;
                    word.ScreenUpdating = false;
                    word.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
                    Object filename = (Object)wordFilePath;
                    //Document doc = word.Documents.Open(ref filename, ref oMissing,
                    //                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                    //                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                    //                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing);
                    Microsoft.Office.Interop.Word.Document doc = word.Documents.Open(filename, false);
                    try
                    {
                        Microsoft.Office.Interop.Word.Range r = doc.Content;
                        r.WholeStory();
                        // r.Find.Execute("<txt>", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "^p", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        //r.Find.Execute("(Table 1)", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "(Table 1 )", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        doc.SaveAs(ref filename,
                                    ref oMissing, ref oMissing,
                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing);
                    }
                    finally
                    {
                        //object saveChanges = WdSaveOptions.wdDoNotSaveChanges;
                        //((_Document)doc).Close(ref saveChanges, ref oMissing, ref oMissing);
                        //doc = null;
                        doc.Close();
                    }
                }
                finally
                {
                    //((_Application)word).Quit(ref oMissing, ref oMissing, ref oMissing);
                    word.Quit();
                    word = null;
                }


            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);

            }
        }
        public static void CitetblStyleRemoveforSpace(string strProcessDoc)
        {
            using (WordprocessingDocument docx = WordprocessingDocument.Open(strProcessDoc, true))
            {
                try
                {
                    var eleAllRprOfCiteFig = docx.MainDocumentPart.Document.Body.Descendants<RunStyle>().
                    Where(rStyle => rStyle != null && rStyle.Val == "citetbl").ToList();

                    foreach (var i in eleAllRprOfCiteFig)
                    {
                        if (i.Parent != null && i.Parent.LocalName == W.rPr.LocalName && i.Parent.Parent.LocalName == W.r.LocalName)
                        {
                            foreach (var t in i.Parent.Parent.Descendants<Text>().ToList())
                            {
                                if (t.Text.EndsWith(" "))
                                {
                                    t.Text = t.Text.Trim();
                                }
                            }
                        }
                    }
                    var FigCPara = docx.MainDocumentPart.Document.Body.Descendants<Paragraph>().
                    Where(rStyle => rStyle != null && rStyle.ParagraphProperties != null && rStyle.ParagraphProperties.ParagraphStyleId != null && rStyle.ParagraphProperties.ParagraphStyleId.Val == "FIGC").ToList();

                    foreach (var figpara in FigCPara)
                    {
                        foreach (var figR in figpara.Descendants<RunStyle>().ToList().Where(rStyle => rStyle != null && rStyle.Val == "label-Strong").Skip(1).ToList())
                        {

                            if (figR.Parent != null && figR.Parent.Parent != null)
                            {
                                foreach (var bold in figR.Parent.Parent.Descendants<Bold>())
                                {
                                    bold.Remove();
                                }

                            }
                            figR.Remove();
                        }
                    }

                }
                catch (Exception ex)
                {

                }

                docx.Save();
            }
        }

        public static void Replaceplaceholders(string wordFilePath)/////In 3rd level heading <txt> replaced with hard enter needed as different para from <txt> text
        {
            try
            {
                object outputFileName = null;
                object oMissing = System.Reflection.Missing.Value;
                Microsoft.Office.Interop.Word.Application word = new Microsoft.Office.Interop.Word.Application();
                try
                {
                    word.Visible = false;
                    word.ScreenUpdating = false;
                    word.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
                    Object filename = (Object)wordFilePath;
                    //Document doc = word.Documents.Open(ref filename, ref oMissing,
                    //                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                    //                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                    //                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing);
                    Microsoft.Office.Interop.Word.Document doc = word.Documents.Open(filename, false);
                    try
                    {
                        Microsoft.Office.Interop.Word.Range r = doc.Content;
                        r.WholeStory();
                        r.Find.Execute("<c>", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        doc.SaveAs(ref filename,
                                    ref oMissing, ref oMissing,
                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing);
                    }
                    finally
                    {
                        //object saveChanges = WdSaveOptions.wdDoNotSaveChanges;
                        //((_Document)doc).Close(ref saveChanges, ref oMissing, ref oMissing);
                        //doc = null;
                        doc.Close();
                    }
                }
                finally
                {
                    //((_Application)word).Quit(ref oMissing, ref oMissing, ref oMissing);
                    word.Quit();
                    word = null;
                }


            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);

            }
        }
        public static void ReplaceplaceholdersSageIndia(string wordFilePath)/////In document remove copyedited tags marking
        {
            try
            {
                List<string> strSagetags = new List<string>();
                strSagetags = GlobalMethods.ReadAndStoreFileValuesInArray(ConfigurationManager.AppSettings.Get("SageIndiaCopyEditingtags"));



                object oMissing = System.Reflection.Missing.Value;
                Microsoft.Office.Interop.Word.Application word = new Microsoft.Office.Interop.Word.Application();
                try
                {
                    word.Visible = false;
                    word.ScreenUpdating = false;
                    word.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
                    Object filename = (Object)wordFilePath;
                    Microsoft.Office.Interop.Word.Document doc = word.Documents.Open(filename, false);
                    try
                    {
                        Microsoft.Office.Interop.Word.Range r = doc.Content;
                        r.WholeStory();
                        strSagetags.ForEach(txt =>
                        {
                            r.Find.Execute(txt, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        });
                        doc.SaveAs(ref filename,
                                    ref oMissing, ref oMissing,
                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing);
                    }
                    finally
                    {
                        //object saveChanges = WdSaveOptions.wdDoNotSaveChanges;
                        //((_Document)doc).Close(ref saveChanges, ref oMissing, ref oMissing);
                        //doc = null;
                        doc.Close();
                    }
                }
                finally
                {
                    //((_Application)word).Quit(ref oMissing, ref oMissing, ref oMissing);
                    word.Quit();
                    word = null;
                }


            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);

            }
        }
        public static void ReplaceplaceholdersPPS(string wordFilePath)/////In document remove copyedited tags marking
        {
            try
            {
                List<string> strSagetags = new List<string>();
                //strSagetags = GlobalMethods.ReadAndStoreFileValuesInArray(ConfigurationManager.AppSettings.Get("SageIndiaCopyEditingtags"));



                object oMissing = System.Reflection.Missing.Value;
                Microsoft.Office.Interop.Word.Application word = new Microsoft.Office.Interop.Word.Application();
                try
                {
                    word.Visible = false;
                    word.ScreenUpdating = false;
                    word.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
                    Object filename = (Object)wordFilePath;
                    Microsoft.Office.Interop.Word.Document doc = word.Documents.Open(filename, false);
                    try
                    {
                        Microsoft.Office.Interop.Word.Range r = doc.Content;
                        r.WholeStory();
                        //strSagetags.ForEach(txt =>
                        //{
                        r.Find.Execute("<H1>", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute("<h1>", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute("<RH>", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute("<Rh>", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute("<rh>", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);

                        //});
                        doc.SaveAs(ref filename,
                                    ref oMissing, ref oMissing,
                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing);
                    }
                    finally
                    {
                        //object saveChanges = WdSaveOptions.wdDoNotSaveChanges;
                        //((_Document)doc).Close(ref saveChanges, ref oMissing, ref oMissing);
                        //doc = null;
                        doc.Close();
                    }
                }
                finally
                {
                    //((_Application)word).Quit(ref oMissing, ref oMissing, ref oMissing);
                    word.Quit();
                    word = null;
                }


            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);

            }
        }

        public static void CheckAbstractParaStyle(string strProcessDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument.Open(strProcessDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(x => x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val != null && x.ParagraphProperties.ParagraphStyleId.Val == "AB-TXT").Skip(2))
                {
                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                    {
                        P.ParagraphProperties.ParagraphStyleId.Val = "BodyA";
                    }
                }
                D.Save();
            }
        }
        public static void CheckTTandFIGCPara(string strProcessDoc)
        {
            List<string> ttLabelList = new List<string>();
            using (WordprocessingDocument WPD = WordprocessingDocument.Open(strProcessDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(x => x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val != null && x.ParagraphProperties.ParagraphStyleId.Val == "TT").Reverse().ToList())
                {
                    foreach (Run R in P.Descendants<Run>().ToList())
                    {
                        if (R.RunProperties != null && R.RunProperties.RunStyle != null && R.RunProperties.RunStyle.Val.Value != null && R.RunProperties.RunStyle.Val.Value == "label-Strong")
                        {
                            if(Regex.Match(R.InnerText.Trim(), @"(Table\s[A-Z][0-9]+\.?)").Value != "" && GlobalMethods.strClientName.ToLower()=="sage")//Developer Name:Priyanka Vishwakarma,Date:19-08-2021;Requirement:Add condition for avoid appendix table 
                            {
                                if (ttLabelList.Contains(R.InnerText.Replace(" ", "").Trim().TrimEnd('.')))
                                {
                                    R.RunProperties.Remove();
                                    P.ParagraphProperties.ParagraphStyleId.Val.Value = "BodyA";
                                }
                                else
                                {
                                    ttLabelList.Add(R.InnerText.Replace(" ", "").Trim().TrimEnd('.'));
                                }
                            }
                            else if (ttLabelList.Contains(R.InnerText.Replace(" ", "").Trim().TrimEnd('.')))
                            {
                                R.RunProperties.RunStyle.Val.Value = "citetbl";
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "BodyA";
                            }
                            else
                            {
                                ttLabelList.Add(R.InnerText.Replace(" ", "").Trim().TrimEnd('.'));
                            }
                            break;
                        }
                    }

                }
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(x => x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val != null && x.ParagraphProperties.ParagraphStyleId.Val == "FIGC").Reverse().ToList())
                {
                    foreach (Run R in P.Descendants<Run>().ToList())
                    {
                        if (R.RunProperties != null && R.RunProperties.RunStyle != null && R.RunProperties.RunStyle.Val.Value != null && R.RunProperties.RunStyle.Val.Value == "label-Strong")
                        {
                            if (Regex.Match(R.InnerText.Trim(), @"(Figure\s[A-Z][0-9]+\.?)").Value != "" && GlobalMethods.strClientName.ToLower() == "sage")//Developer Name:Priyanka Vishwakarma,Date:19-08-2021;Requirement:Add condition for avoid appendix table 
                            {
                               
                                if (ttLabelList.Contains(R.InnerText.Trim().TrimEnd('.')))
                                {
                                    R.RunProperties.Remove();
                                    P.ParagraphProperties.ParagraphStyleId.Val.Value = "BodyA";
                                }
                                else
                                {
                                    ttLabelList.Add(R.InnerText.Trim().TrimEnd('.'));
                                }
                            }
                            else if (ttLabelList.Contains(R.InnerText.Trim().TrimEnd('.')))
                            {
                                R.RunProperties.RunStyle.Val.Value = "citefig";
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "BodyA";
                            }
                            else
                            {
                                ttLabelList.Add(R.InnerText.Trim().TrimEnd('.'));
                            }
                            break;
                        }
                    }

                }
                D.Save();
            }
        }

        public static void InformsArticleMappinngBasedonText(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;


                foreach (Paragraph P in D.Descendants<Paragraph>().Where(x => x.Parent != null && x.Parent.LocalName != W.tc.LocalName).ToList())
                {
                    if (P.InnerText.ToLower().StartsWith("<abstract>"))
                    {
                        P.Descendants<Text>().FirstOrDefault().Text = P.Descendants<Text>().FirstOrDefault().Text.Replace("<ABSTRACT>", "");
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "AB";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "AB" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "AB" }));

                        }
                    }
                    else if (P.InnerText.ToLower().StartsWith("<rrh>"))
                    {
                        P.Descendants<Text>().FirstOrDefault().Text = P.Descendants<Text>().FirstOrDefault().Text.Replace("<RRH>", "");
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "RRH";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "RRH" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "RRH" }));

                        }
                    }
                    else if (P.InnerText.StartsWith("<TITLE>"))
                    {
                        P.Descendants<Text>().FirstOrDefault().Text = P.Descendants<Text>().FirstOrDefault().Text.Replace("<TITLE>", "");
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "TI";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "TI" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "TI" }));

                        }
                    }
                    else if (P.InnerText.StartsWith("<Author>"))
                    {
                        P.Descendants<Text>().FirstOrDefault().Text = P.Descendants<Text>().FirstOrDefault().Text.Replace("<Author>", "");
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "AU";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "AU" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "AU" }));

                        }
                    }
                    else if (P.InnerText.StartsWith("<AFF>"))
                    {
                        P.Descendants<Text>().FirstOrDefault().Text = P.Descendants<Text>().FirstOrDefault().Text.Replace("<AFF>", "");
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "AFFL";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "AFFL" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "AFFL" }));

                        }
                    }
                    else if (P.InnerText.StartsWith("<Keywords>"))
                    {
                        P.Descendants<Text>().FirstOrDefault().Text = P.Descendants<Text>().FirstOrDefault().Text.Replace("<Keywords>", "");
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "KYWD";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "KYWD" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "KYWD" }));

                        }
                    }
                    else if (P.InnerText.StartsWith("<History>"))
                    {
                        P.Descendants<Text>().FirstOrDefault().Text = P.Descendants<Text>().FirstOrDefault().Text.Replace("<History>", "");
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "UID";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "UID" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "UID" }));

                        }
                    }
                    else if (P.InnerText.StartsWith("Received") || P.InnerText.StartsWith("Revised") || P.InnerText.StartsWith("Accepted"))
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "UID";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "UID" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "UID" }));

                        }
                    }
                    else if (P.InnerText.StartsWith("*Correspondence to:") || P.InnerText.Trim().StartsWith("E-mail:") || P.InnerText.ToLower().StartsWith("mailto"))
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "CORR";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "CORR" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "CORR" }));
                        }
                    }
                    else if (P.InnerText.StartsWith("Notes:"))
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "TFN";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "TFN" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "TFN" }));
                        }
                    }
                    else if (P.InnerText.Trim() == "[, ][],n," || P.InnerText.Trim().StartsWith("[[ INSERT"))
                    {
                        P.Remove();
                    }
                    else if (P.InnerText == "" && P.Parent != null && P.Parent.LocalName != W.tc.LocalName)
                    {
                        P.Remove();
                    }
                    else if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && (P.ParagraphProperties.ParagraphStyleId.Val == "BodyText" || P.ParagraphProperties.ParagraphStyleId.Val == "EndNoteBibliography" || P.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower() == "paragraph"))
                    {
                        P.ParagraphProperties.ParagraphStyleId.Val = "BodyA";
                    }

                }

                D.Save();
            }

        }

        public static void SageArticleMappinngBasedonText(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                var abstarctound = false;
                var keywordsfound = false;
                var corrfound = false;
                var heading = false;
                var Auapply = false;
                var TIApply = false;
                var paracnt = 0;
                foreach (Paragraph P in D.Descendants<Paragraph>().Where(x => x.Parent != null && x.Parent.LocalName != W.tc.LocalName).ToList())
                {
                    if (P.InnerText.Trim() != "")
                    {
                        paracnt++;
                    }
                    if (paracnt == 1)
                    {
                        if (P.Descendants<Run>().Count() > 0)/////This cheeck required to check for If AffL Para is there like Theime skip this function
                        {
                            if (P.Descendants<Run>().FirstOrDefault().Descendants().ToList().Any(x => x.LocalName == "vertAlign"))
                            {
                                goto Nxt;
                            }
                        }
                    }

                    if (P.InnerText.Replace(" ", "").ToLower().StartsWith("abstract"))
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "AB";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "AB" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "AB" }));

                        }
                        abstarctound = true;
                        corrfound = false;
                    }
                    else if (CheckifCompleteParaIsBold(P.Descendants<Run>()) == false && P.PreviousSibling<Paragraph>() != null && P.PreviousSibling<Paragraph>().Count() > 0 && P.PreviousSibling<Paragraph>().FirstOrDefault().Parent != null && P.PreviousSibling<Paragraph>().FirstOrDefault().Parent.LocalName == W.p.LocalName && ((Paragraph)P.PreviousSibling<Paragraph>().FirstOrDefault().Parent).ParagraphProperties != null && ((Paragraph)P.PreviousSibling<Paragraph>().FirstOrDefault().Parent).ParagraphProperties.ParagraphStyleId != null && ((Paragraph)P.PreviousSibling<Paragraph>().FirstOrDefault().Parent).ParagraphProperties != null && (((Paragraph)P.PreviousSibling<Paragraph>().FirstOrDefault().Parent).ParagraphProperties.ParagraphStyleId.Val.Value == "TI" || ((Paragraph)P.PreviousSibling<Paragraph>().FirstOrDefault().Parent).ParagraphProperties.ParagraphStyleId.Val.Value == "RRH"|| ((Paragraph)P.PreviousSibling<Paragraph>().FirstOrDefault().Parent).ParagraphProperties.ParagraphStyleId.Val.Value == "DT")) //Developer name:PriyankaVishwakarma,Date:26-11-2020 ,Requirement:add condition for check parent paragraph property not null
                    {
                        if (P.InnerText.Trim().StartsWith("Correspondence to:") || P.InnerText.Trim().StartsWith("Authors: ") || P.InnerText.Trim().StartsWith("Corresponding Author:") || P.InnerText.Trim().StartsWith("Correspond Author:"))  //Developer Name:Priyanka Vishwakarma,Date:16-10-2020,Requirement:Apply CORR Paragraph Style
                        {
                            if (P.ParagraphProperties != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                                {
                                    P.ParagraphProperties.ParagraphStyleId.Val.Value = "CORR";
                                }
                                else
                                {
                                    P.ParagraphProperties.Append(new ParagraphStyleId { Val = "CORR" });
                                }
                            }
                            else
                            {
                                P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "CORR" }));
                            }
                            corrfound = true;
                        }
                        else
                        {
                            if (P.ParagraphProperties != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                                {
                                    P.ParagraphProperties.ParagraphStyleId.Val.Value = "AU";
                                }
                                else
                                {
                                    P.ParagraphProperties.Append(new ParagraphStyleId { Val = "AU" });
                                }
                            }
                            else
                            {
                                P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "AU" }));
                            }
                            Auapply = true;
                        }

                    }
                    else if (P.InnerText.Replace(" ", "").ToLower().StartsWith("keywords") || P.InnerText.Replace(" ", "").ToLower().StartsWith("keyword") || P.InnerText.Replace(" ", "").ToLower().StartsWith("<KW>"))
                    {

                        if (P.Descendants<Run>().ToList().Count > 0 && P.Descendants<Run>().ToList().LastOrDefault().InnerText.Trim().EndsWith("."))
                        {
                            if (P.Descendants<Run>().ToList().LastOrDefault().Descendants<Text>().Count() > 0)
                            {
                                P.Descendants<Run>().ToList().LastOrDefault().Descendants<Text>().LastOrDefault().Text = P.Descendants<Run>().ToList().LastOrDefault().Descendants<Text>().LastOrDefault().Text.TrimEnd('.');
                            }
                        }

                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "KYWD";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "KYWD" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "KYWD" }));

                        }
                        keywordsfound = true;
                        corrfound = false;
                    }
                    else if (P.InnerText.Replace(" ", "").ToLower() == "briefbiographicalstatement" || P.InnerText.Replace(" ", "").ToLower() == "bio:" || P.InnerText.Replace(" ", "").ToLower() == "authorbios:" || P.InnerText.Replace(" ", "").ToLower() == "authorbios:" || P.InnerText.Replace(" ", "").ToLower() == "conclusionsandfutureresearch"||P.InnerText.Replace(" ","").ToLower()== "authorbiographies")
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "H1";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "H1" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "H1" }));

                        }
                    }
                    else if ((P.InnerText.Trim().StartsWith("Correspondence to:") || P.InnerText.Trim().StartsWith("Corresponding Author:") || P.InnerText.Trim().StartsWith("Corresponding Author") || P.InnerText.Trim().StartsWith("Correspond Author:") || P.InnerText.Trim().StartsWith("Author:") || P.InnerText.Trim().StartsWith("Address") || P.InnerText.Trim().StartsWith("Home Address") || P.InnerText.Trim().StartsWith("E-mail:") || P.InnerText.Trim().ToLower().StartsWith("phone/fax") || P.InnerText.Trim().ToLower().Contains("email:")) && abstarctound == false && keywordsfound == false && heading == false && Auapply)
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId.Val != "AFFL")
                                    P.ParagraphProperties.ParagraphStyleId.Val.Value = "CORR";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "CORR" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "CORR" }));
                        }
                        corrfound = true;
                    }
                    else if (P.InnerText.Trim().StartsWith("Correspond Author:") || P.InnerText.Trim().StartsWith("E-mail:") || P.InnerText.Trim().ToLower().StartsWith("phone/fax") || (P.InnerText.Trim().StartsWith("Email:") && P.InnerText.Contains("@"))) ////Developer Name:Priyanka Vishwakarma,Date:16-10-2020,Requirement:Apply CORR Paragraph Style
                    {
                        if (P.InnerText.Trim().ToLower().StartsWith("e-mail") || P.InnerText.Trim().ToLower().StartsWith("emai"))///for check eamil id not ends with dot then remove dot
                        {
                            if (P.Descendants<Run>().ToList().Count > 0 && P.Descendants<Run>().ToList().LastOrDefault().InnerText.Trim().EndsWith("."))
                            {
                                if (P.Descendants<Run>().ToList().LastOrDefault().Descendants<Text>().Count() > 0)
                                {
                                    P.Descendants<Run>().ToList().LastOrDefault().Descendants<Text>().LastOrDefault().Text = P.Descendants<Run>().ToList().LastOrDefault().Descendants<Text>().LastOrDefault().Text.TrimEnd('.');
                                }
                            }
                        }
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "CORR";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "CORR" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "CORR" }));
                        }
                        corrfound = true;
                    }

                    else if (P.InnerText.ToLower().TrimStart().StartsWith("note.") || P.InnerText.ToLower().TrimStart().StartsWith("source.") || P.InnerText.ToLower().TrimStart().StartsWith("note:") || P.InnerText.ToLower().TrimStart().StartsWith("source:")|| P.InnerText.ToLower().TrimStart().StartsWith("notes.")|| P.InnerText.ToLower().TrimStart().StartsWith("notes:"))
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "TFN";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "TFN" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "TFN" }));
                        }
                    }
                    else if (P.InnerText.Trim().ToLower().StartsWith("running head"))
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "RRH";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "RRH" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "RRH" }));
                        }
                    }
                    else if (P.InnerText.Contains("https://orcid.org/") && GlobalMethods.RegExSearch(P.InnerText.TrimStart(' '), @"[0-9]{4}\-[0-9]{4}\-[0-9]{4}\-[0-9X]{4}") != "")//Developer name:Priyanka Vishwakarma,Date:14-10-2020,Requirement:Apply ORCID-AU Para style for sage.
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "ORCID-AU";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "ORCID-AU" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "ORCID-AU" }));
                        }
                    }
                    else if (P.InnerText.Replace(" ", "").StartsWith("(Insert") || P.InnerText.Replace(" ", "").StartsWith("[Insert") || P.InnerText.ToLower().Replace(" ", "").StartsWith("insertfigure") || P.InnerText.ToLower().Replace(" ", "").StartsWith("inserttable") || (P.InnerText.Trim().ToLower().Replace(" ", "").StartsWith("table") && P.InnerText.Trim().ToLower().Replace(" ", "").EndsWith("here") || (P.InnerText.Trim().ToLower().Replace(" ", "").StartsWith("figure") && P.InnerText.Trim().ToLower().Replace(" ", "").EndsWith("here"))))
                    {

                        P.Remove();
                    }
                    else if (P.InnerText.Trim() == "" && P.Parent != null && P.Parent.LocalName != W.tc.LocalName)
                    {
                        P.Remove();
                    }
                    else if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val == "PageBreak")
                    {
                        P.Remove();
                    }
                    else if ((CheckifCompleteParaIsBold(P.Descendants<Run>()) == true && P.ParagraphProperties.Justification != null && P.ParagraphProperties.Justification.Val != null && P.ParagraphProperties.Justification.Val.Value.ToString().ToLower() == "center" || paracnt <=3) && abstarctound == false && keywordsfound == false)
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId.Val != "AU" && P.ParagraphProperties.ParagraphStyleId.Val != "DT")  //Developer Name:Priyanka Vishwakarma,Date:20-10-2020,Requirement :not apply TI if paragraph already have AU para style.
                                {
                                    P.ParagraphProperties.ParagraphStyleId.Val.Value = "TI";
                                    TIApply = true;
                                }
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "TI" });
                                TIApply = true;
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "TI" }));
                            TIApply = true;
                        }
                       
                    }
                    else if (CheckifCompleteParaIsBold(P.Descendants<Run>().Where(x => x.InnerText.Trim() != "")) == true && P.ParagraphProperties.Justification != null && P.ParagraphProperties.Justification.Val != null && P.ParagraphProperties.Justification.Val.Value.ToString().ToLower() == "center" && (abstarctound == true || keywordsfound == true))
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "H1";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "H1" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "H1" }));
                        }
                        heading = true;
                    }
                    else if (CheckifCompleteParaIsBoldandItalic(P.Descendants<Run>().Where(x => x.InnerText.Trim() != "")) == true && TIApply)
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "H3";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "H3" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "H3" }));
                        }
                        heading = true;
                    }
                    else if (CheckifCompleteParaIsBold(P.Descendants<Run>().Where(x => x.InnerText.Trim() != "")) == true && TIApply)
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId.Val != "AU" && P.ParagraphProperties.ParagraphStyleId.Val != "H1")  //Developer Name:Priyanka Vishwakarma,Date:19-10-2020,Requirement:Add condition for avoid to apply TI para to AU paragraph
                                {
                                    P.ParagraphProperties.ParagraphStyleId.Val.Value = "H2";
                                }
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "H2" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "H2" }));
                        }
                        heading = true;
                    }

                    else if ((corrfound == false && keywordsfound == false && abstarctound == false && heading == false && TIApply == true) || (heading == false && TIApply == true && P.Descendants<Run>().Count() > 0 && P.Descendants<Run>().FirstOrDefault().Descendants().ToList().Any(x => x.LocalName == "vertAlign")))
                    {
                        if (P.Descendants<Run>().Count() > 0)/////This cheeck required to check for If AffL Para is there like Theime skip this function
                        {
                            if (P.Descendants<Run>().FirstOrDefault().Descendants().ToList().Any(x => x.LocalName == "vertAlign"))
                            {
                                if (P.ParagraphProperties != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val.Value = "AFFL";
                                    }
                                    else
                                    {
                                        P.ParagraphProperties.Append(new ParagraphStyleId { Val = "AFFL" });
                                    }
                                }
                                else
                                {
                                    P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "AFFL" }));
                                }
                            }
                        }
                        else if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "AFFL";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "AFFL" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "AFFL" }));
                        }
                    }
                    else if (P.ParagraphProperties != null && P.ParagraphProperties.Indentation != null && P.ParagraphProperties.Indentation.Left != null && P.ParagraphProperties.Indentation.Left.Value != null && P.ParagraphProperties.Indentation.Left.Value != "0")
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "EXT";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "EXT" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "EXT" }));
                        }
                        heading = true;
                    }
                }
            Nxt: { }
                D.Save();
            }

        }
        public static void CSIROArticleMappinngBasedonText(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                var abstractfound = false;
                foreach (Paragraph P in D.Descendants<Paragraph>().Where(x => x.Parent != null && x.Parent.LocalName != W.tc.LocalName).ToList())
                {

                    if (P.InnerText.Replace(" ", "").StartsWith("(Insert") || P.InnerText.Replace(" ", "").StartsWith("[Insert") || P.InnerText.ToLower().Replace(" ", "").StartsWith("{insert") || P.InnerText.ToLower().Replace(" ", "").StartsWith("insertfigure") || P.InnerText.ToLower().Replace(" ", "").StartsWith("inserttable") || (P.InnerText.Trim().ToLower().Replace(" ", "").StartsWith("table") && P.InnerText.Trim().ToLower().Replace(" ", "").EndsWith("here") || (P.InnerText.Trim().ToLower().Replace(" ", "").StartsWith("figure") && P.InnerText.Trim().ToLower().Replace(" ", "").EndsWith("here"))))
                    {

                        P.Remove();
                    }
                    else if (P.InnerText.Replace(" ", "").ToLower() == "introduction" || P.InnerText.Replace(" ", "").ToLower() == "materialsandmethods" || P.InnerText.Replace(" ", "").ToLower() == "results" || P.InnerText.Replace(" ", "").ToLower() == "discussion" || P.InnerText.Replace(" ", "").ToLower() == "conclusion")
                    {

                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "H1";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "H1" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "H1" }));

                        }

                    }
                    else if (P.InnerText.Replace(" ", "").ToLower().StartsWith("abbreviations:") || P.InnerText.Replace(" ", "").ToLower().StartsWith("note:"))
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "TFN";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "TFN" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "TFN" }));

                        }
                    }
                    else if (P.InnerText.Replace(" ", "").ToLower().Contains("ORCID is "))
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "ORCID";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "ORCID" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "ORCID" }));

                        }
                    }
                    else if (P.InnerText.Replace(" ", "").ToLower().StartsWith("fig"))
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "FIGC";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "FIGC" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "FIGC" }));

                        }
                    }
                    else if (P.InnerText.Replace(" ", "").ToLower().StartsWith("table"))
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "TT";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "TT" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "TT" }));

                        }
                    }
                    else if (P.InnerText.Replace(" ", "").ToLower().StartsWith("keywords"))
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "KYWD";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "KYWD" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "KYWD" }));

                        }
                        abstractfound = false;
                    }
                    else if (P.InnerText.Replace(" ", "").ToLower() == "abstract")
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "AB";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "AB" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "AB" }));

                        }
                        abstractfound = true;
                    }
                    else if (abstractfound)
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "AB-TXT";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "AB-TXT" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "AB-TXT" }));

                        }
                        abstractfound = true;
                    }
                    else if (P.InnerText.Trim() == "" && P.Parent != null && P.Parent.LocalName != W.tc.LocalName)
                    {
                        P.Remove();
                    }
                }
                D.Save();
            }
            MarkReferenceCitations(newDoc);
        }

        private static bool CheckifCompleteParaIsBoldandItalic(IEnumerable<Run> RunColl)
        {
            bool bcompleteParaIsBoldItalic = false;

            foreach (Run R in RunColl.ToList())
            {
                if (R.HasChildren == true)
                {
                    if (R.RunProperties != null)
                    {
                        if (R.RunProperties.Bold != null && R.RunProperties.Italic != null)  //19-10-2020
                        {
                            bcompleteParaIsBoldItalic = true;
                        }

                        else
                        {
                            bcompleteParaIsBoldItalic = false;
                            return false;
                        }
                    }
                    else
                    {
                        bcompleteParaIsBoldItalic = false;
                        return false;
                    }
                }
                else
                {
                    bcompleteParaIsBoldItalic = false;
                    return false;
                }
            }

            if (bcompleteParaIsBoldItalic)
                return true;

            return false;
        }

        public static void SageboldItalicParagraphMarkRemove(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (ParagraphMarkRunProperties Prp in D.Descendants<ParagraphMarkRunProperties>().Where(x => x.Descendants().Any(xy => xy.LocalName == W.b.LocalName) && x.Descendants().Any(xy => xy.LocalName == W.i.LocalName)).ToList())
                {
                    foreach (var ele in Prp.Descendants())
                    {
                        if (ele.LocalName == W.b.LocalName || ele.LocalName == W.bCs.LocalName || ele.LocalName == W.i.LocalName || ele.LocalName == W.iCs.LocalName)
                        {
                            ele.Remove();
                        }
                    }
                    if (Prp.HasChildren == false)
                    {
                        Prp.Remove();
                    }

                }
                foreach (ParagraphMarkRunProperties Prp in D.Descendants<ParagraphMarkRunProperties>().Where(x => x.Descendants().Any(xy => xy.LocalName == W.b.LocalName)).ToList())
                {
                    foreach (var ele in Prp.Descendants())
                    {
                        if (ele.LocalName == W.b.LocalName || ele.LocalName == W.bCs.LocalName)
                        {
                            ele.Remove();
                        }
                    }
                    if (Prp.HasChildren == false)
                    {
                        Prp.Remove();
                    }

                }
                foreach (ParagraphMarkRunProperties Prp in D.Descendants<ParagraphMarkRunProperties>().Where(x => x.Descendants().Any(xy => xy.LocalName == W.i.LocalName)).ToList())
                {
                    foreach (var ele in Prp.Descendants())
                    {
                        if (ele.LocalName == W.i.LocalName || ele.LocalName == W.iCs.LocalName)
                        {
                            ele.Remove();
                        }
                    }
                    if (Prp.HasChildren == false)
                    {
                        Prp.Remove();
                    }

                }
            }
        }


        public static void RemoveNormalStyleapplyBodyA(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().Where(x => x.Parent != null && x.Parent.LocalName != W.tc.LocalName).ToList())
                {
                    if (P.ParagraphProperties != null)
                    {
                        if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && (P.ParagraphProperties.ParagraphStyleId.Val.Value.StartsWith("Normal") || P.ParagraphProperties.ParagraphStyleId.Val.Value.StartsWith("HTML")))///HTML Preformatted style
                        {
                            P.ParagraphProperties.ParagraphStyleId.Val.Value = "BodyA";
                        }

                    }
                    else
                    {
                        P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "BodyA" }));
                    }
                    if (P.InnerText.Trim() == "" && P.Descendants<CommentReference>().ToList().Count() == 0)
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val.Value != "BoxStart" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "BoxEnd" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "AppendixHead" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "CustomListStart" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "CustomListEnd")//Developer Name:Priyanka Vishwakarma,Date:30-07-2021,Requirement:Add condiition for avoiding to remove cumtomlistStart and customlistend
                            {
                                P.Remove();
                            }
                        }
                        else
                        {
                            P.Remove();
                        }
                    }

                }
            }
        }

        public static void MergeCORRParaForSage(string newDoc)
        {
            Paragraph newpara = new Paragraph();
            string Corrtext = "";
            bool CommentWithoutTextFound = false;
            Dictionary<int, string> commentRangeStartText = new Dictionary<int, string>();
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                var CountCorrParaList = D.Descendants<Paragraph>().Where(x => x.Parent != null && x.Parent.LocalName != W.tc.LocalName && x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val != null && x.ParagraphProperties.ParagraphStyleId.Val.Value == "CORR" && x.InnerText != "").ToList();
                var CorrParaList = D.Descendants<Paragraph>().Where(x => x.Parent != null && x.Parent.LocalName != W.tc.LocalName && x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val != null && x.ParagraphProperties.ParagraphStyleId.Val.Value == "CORR" && !x.InnerText.Contains("@")).ToList();
                if (CountCorrParaList.Count() > 2)
                {

                    foreach (var p in CorrParaList.ToList())
                    {
                        //Develope Name:Priyanka Vishwakarma ,Date:28_5_2019 ,Requirement: for adding Comment in Reference on bibnumber only.
                        foreach (var PS in p.Descendants().ToList().Where(x => x.XName == W.commentRangeStart).ToList())
                        {
                            commentRangeStartText.Add(Convert.ToInt16(((DocumentFormat.OpenXml.Wordprocessing.MarkupRangeType)PS).Id.InnerText), PS.NextSibling().InnerText.Trim());
                            CommentWithoutTextFound = true;

                        }

                        foreach (var run in p.Descendants<Run>().ToList())
                        {
                            if (run.InnerText.Contains(":"))
                            {
                                Corrtext += run.InnerText + " ";
                            }
                            else
                            {
                                Corrtext += run.InnerText;
                            }

                            //else
                            //{
                            //    if (run.InnerText.Trim()!="," && run.InnerText.Trim().EndsWith(","))
                            //    {
                            //        Corrtext += run.InnerText.Replace(".", "") + " ";
                            //    }
                            //    else
                            //    {
                            //        Corrtext += run.InnerText + ", ";
                            //    }
                            //}
                        }

                    }
                    Corrtext = Corrtext.Trim();
                    if (newpara != null)
                    {
                        newpara.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "CORR" });
                        Run text = new Run();
                        Text newtext1 = new Text();
                        newtext1.Text = Corrtext.TrimEnd(',');
                        text.AppendChild(newtext1);
                        newpara.AppendChild(text);
                        var lastCorrParaList = D.Descendants<Paragraph>().Where(x => x.Parent != null && x.Parent.LocalName != W.tc.LocalName && x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val != null && x.ParagraphProperties.ParagraphStyleId.Val.Value == "CORR" && !x.InnerText.Contains("@")).ToList().LastOrDefault();
                        if (lastCorrParaList != null)
                        {
                            lastCorrParaList.InsertAfterSelf(newpara);

                            foreach (var para in CorrParaList.ToList())
                            {
                                para.Remove();
                            }
                        }
                    }

                }
                else
                {
                    var CorrParaList1 = D.Descendants<Paragraph>().Where(x => x.Parent != null && x.Parent.LocalName != W.tc.LocalName && x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val != null && x.ParagraphProperties.ParagraphStyleId.Val.Value == "CORR" && x.InnerText.Trim() != "").ToList();
                    bool coorPara1Found = false;
                    if (CorrParaList1.Count() == 2)
                    {
                        foreach (var p in D.Descendants<Paragraph>().ToList())
                        {
                            if (p.ParagraphProperties != null && p.ParagraphProperties.ParagraphStyleId != null && p.ParagraphProperties.ParagraphStyleId.Val != null && p.ParagraphProperties.ParagraphStyleId.Val.Value == "CORR")
                            {
                                if (coorPara1Found == true)
                                {
                                    coorPara1Found = false;
                                    break;
                                }
                                else
                                {
                                    coorPara1Found = true;
                                    continue;
                                }

                            }
                            if (p.ParagraphProperties != null && p.ParagraphProperties.ParagraphStyleId != null && p.ParagraphProperties.ParagraphStyleId.Val != null && p.ParagraphProperties.ParagraphStyleId.Val.Value == "TI" || p.ParagraphProperties.ParagraphStyleId.Val.Value == "DT" || p.ParagraphProperties.ParagraphStyleId.Val.Value == "RRH" || p.ParagraphProperties.ParagraphStyleId.Val.Value == "AU" || p.ParagraphProperties.ParagraphStyleId.Val.Value == "AFFL")
                            {
                                goto NxtFun;
                            }
                            if (coorPara1Found)
                            {
                                if (p.ParagraphProperties != null)
                                {
                                    if (p.ParagraphProperties.ParagraphStyleId != null && p.ParagraphProperties.ParagraphStyleId.Val != null)
                                    {
                                        p.ParagraphProperties.ParagraphStyleId.Val.Value = "CORR";
                                    }
                                    else
                                    {
                                        p.ParagraphProperties.Append(new ParagraphStyleId { Val = "CORR" });
                                    }
                                }
                                else
                                {
                                    p.Append(new ParagraphProperties(new ParagraphStyleId { Val = "CORR" }));

                                }

                            }

                        }

                        var CorrParaListUpdate = D.Descendants<Paragraph>().Where(x => x.Parent != null && x.Parent.LocalName != W.tc.LocalName && x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val != null && x.ParagraphProperties.ParagraphStyleId.Val.Value == "CORR" && x.InnerText.Trim() != "" && !x.InnerText.Contains("@")).ToList();
                        Corrtext = "";
                        if (CorrParaListUpdate.Count() > 2)
                        {

                            foreach (var p in CorrParaListUpdate.ToList())
                            {
                                foreach (var run in p.Descendants<Run>().ToList())
                                {
                                    if (run.InnerText.Contains(":"))
                                    {
                                        Corrtext += run.InnerText + " ";
                                    }
                                    else
                                    {
                                        //  Corrtext += run.InnerText + ", ";
                                    }
                                }

                            }

                            if (newpara != null)
                            {
                                newpara.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "CORR" });
                                Run text = new Run();
                                Text newtext1 = new Text();
                                // newtext1.Text = Corrtext.TrimEnd(',');
                                // text.AppendChild(newtext1);
                                newpara.AppendChild(text);
                                var lastCorrParaList = D.Descendants<Paragraph>().Where(x => x.Parent != null && x.Parent.LocalName != W.tc.LocalName && x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val != null && x.ParagraphProperties.ParagraphStyleId.Val.Value == "CORR" && !x.InnerText.Contains("@")).ToList().LastOrDefault();
                                if (lastCorrParaList != null)
                                {
                                    lastCorrParaList.InsertAfterSelf(newpara);

                                    foreach (var para in CorrParaListUpdate.ToList())
                                    {
                                        para.Remove();
                                    }
                                }
                            }

                        }

                    }
                }

                var CountCorrParaList1 = D.Descendants<Paragraph>().Where(x => x.Parent != null && x.Parent.LocalName != W.tc.LocalName && x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val != null && x.ParagraphProperties.ParagraphStyleId.Val.Value == "CORR" && x.InnerText != "").ToList();
                if (CommentWithoutTextFound)
                {
                    foreach (var cmt in commentRangeStartText.ToList())
                    {
                        var key = cmt.Key;
                        if (!string.IsNullOrEmpty(key.ToString()))
                        {
                            CountCorrParaList1.FirstOrDefault().AppendChild(new CommentRangeStart() { Id = key.ToString() });
                            RunProperties rpr = new RunProperties(new RunStyle() { Val = "CommentReference" });

                            CountCorrParaList1.FirstOrDefault().AppendChild(new Run(new CommentReference() { Id = key.ToString() })).Append(rpr);
                            CountCorrParaList1.FirstOrDefault().AppendChild(new CommentRangeEnd() { Id = key.ToString() });
                            new Run(new CommentReference() { Id = key.ToString() });
                        }
                    }

                }
            NxtFun: { }
                D.Save();
            }

        }

        public static void RemovespaceStrtEndPara(string newDoc)     //Developer Name:Narayan, Date:19_10_2020 ,Requirement:Apply remove space in start and end of para.
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P.Descendants<Run>().ToList().Count > 0)
                    {
                        var runfirst = P.Descendants<Run>().FirstOrDefault();
                        var runlast = P.Descendants<Run>().LastOrDefault();
                        if (runfirst != null)
                        {
                            if (runfirst.Descendants<Text>().ToList().Count > 0)
                            {
                                var textfirst = runfirst.Descendants<Text>().FirstOrDefault();
                                textfirst.Text = textfirst.Text.TrimStart();
                            }
                        }
                        if (runlast != null)
                        {
                            if (runlast.Descendants<Text>().ToList().Count > 0)
                            {
                                var textlast = runlast.Descendants<Text>().LastOrDefault();
                                textlast.Text = textlast.Text.TrimEnd();
                            }
                        }
                    }
                }
                D.Save();

            }
        }
        public static void doublecommaspacetocommaspace(string wordFilePath)/////In comma double space and double dot remove text
        {
            try
            {
                object outputFileName = null;
                object oMissing = System.Reflection.Missing.Value;
                Microsoft.Office.Interop.Word.Application word = new Microsoft.Office.Interop.Word.Application();
                try
                {
                    word.Visible = false;
                    word.ScreenUpdating = false;
                    word.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
                    Object filename = (Object)wordFilePath;
                    //Document doc = word.Documents.Open(ref filename, ref oMissing,
                    //                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                    //                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                    //                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing);
                    Microsoft.Office.Interop.Word.Document doc = word.Documents.Open(filename, false);
                    try
                    {
                        Microsoft.Office.Interop.Word.Range r = doc.Content;
                        r.WholeStory();

                        r.Find.Execute(", ,  (", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, " (", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute(",  ", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute("...", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "\u2026", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute(". . .", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "\u2026", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute("..", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ".", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute("\t", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, " ", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute(@" \ ", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, @"\", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute("---", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "—", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute("--", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "–", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute(" - ", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "-", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute("- ", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "-", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute(" -", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "-", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute(" – ", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "–", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute("– ", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "–", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute(" –", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "–", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute(" — ", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "—", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute("— ", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "—", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute(" —", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "—", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute("! ’", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "!’", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        if (GlobalMethods.strClientName.ToLower() != "csiro")
                        {
                            r.Find.Execute(",1", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ", 1", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        }
                        r.Find.Execute(", ’", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ",’", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute(",(", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "(", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        /////Added by vikas on 07-01-2020 for semicolon and opening paranthesis remove semiclon
                        r.Find.Execute(";(", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "(", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute(", (", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, " (", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        /////Added by vikas on 07-01-2020 for semicolon and opening paranthesis remove semiclon
                        r.Find.Execute("; (", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, " (", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute("( ", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "(", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute("[ ", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "[", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute("{ ", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "{", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute(" )", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ")", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute(" ]", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "]", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute(" }", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "}", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute(", ,", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ",", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute("\u00A0", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, " ", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute("  ", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, " ", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute(" ?", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "?", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute(" ,", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ",", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute(";;", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ";", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute(" / ", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "/", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute(" /", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "/", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute("/ ", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "/", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute(" \u0022", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, " \u201C", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);///stright quote to smart quote opening quote
                        r.Find.Execute("\u0022 ", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "\u201D ", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);///stright quote to smart quote closing quote



                        doc.SaveAs(ref filename,
                                    ref oMissing, ref oMissing,
                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing);
                    }
                    finally
                    {
                        //object saveChanges = WdSaveOptions.wdDoNotSaveChanges;
                        //((_Document)doc).Close(ref saveChanges, ref oMissing, ref oMissing);
                        //doc = null;
                        doc.Close();
                    }
                }
                finally
                {
                    //((_Application)word).Quit(ref oMissing, ref oMissing, ref oMissing);
                    word.Quit();
                    word = null;
                }


            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);

            }
        }
        public static void ApplyREFStructureandcitebibforSage(string newDoc, string StyleMappingConfig)
        {

            GlobalMethods.strReferncePatternFilename = null;
            if (GlobalMethods.strClientName.ToLower() == "informs")
            {
                GlobalMethods.strReferncePatternFilename = ConfigurationManager.AppSettings.Get("RefrencePatternFilenameForINF");

            }
            else if (GlobalMethods.strClientName.ToLower() == "sage")  //10-10-2020
            {
                GlobalMethods.strReferncePatternFilename = ConfigurationManager.AppSettings.Get("RefrencePatternFilenameForSage");

            }
            else
            {
                GlobalMethods.strReferncePatternFilename = ConfigurationManager.AppSettings.Get("RefrencePatternFilename");
            }
            //-------------End on 10-09-2020
            GlobalMethods.strJournalDBFilename = null;
            GlobalMethods.strPublisherDBFilename = null;
            if (GlobalMethods.strClientName.ToLower() == "sage")  //10-10-2020
            {
                GlobalMethods.strJournalDBFilename = ConfigurationManager.AppSettings.Get("JournalNameDBSage");
                GlobalMethods.strPublisherDBFilename = ConfigurationManager.AppSettings.Get("PublisherNameDBSage");
            }
            else
            {
                GlobalMethods.strJournalDBFilename = ConfigurationManager.AppSettings.Get("JournalNameDB");
                GlobalMethods.strPublisherDBFilename = ConfigurationManager.AppSettings.Get("PublisherNameDB");
            }
            if (GlobalMethods.strClientName.ToLower() != "ufl")
            {
                References.MergeReferenceElements(newDoc, GlobalMethods.strReferncePatternFilename, GlobalMethods.strJournalDBFilename, GlobalMethods.strPublisherDBFilename);  //Comment for Florida  14-08-2020
            }


        }
        public static void MarkReferenceCitations(string strWordDoc)
        {
            try
            {
                // Reference citation citebib style apply for brazil project added by vikas on 19-05-2020 tis will run for inly xmloutput required by client //


                using (WordprocessingDocument WPD = WordprocessingDocument
                    .Open(strWordDoc, true))
                {

                    MainDocumentPart MDP = WPD.MainDocumentPart;

                    Document D = MDP.Document;

                    foreach (Paragraph P in D.Descendants<Paragraph>().Where(x => x.Parent != null && x.Parent.LocalName != W.tc.LocalName).ToList())
                    {
                        if (P.HasChildren)
                        {
                            if (P.Descendants<Run>().Count() > 0)
                            {
                                foreach (Run R in P.Descendants<Run>().ToList())
                                {
                                    if (R.RunProperties != null && R.PreviousSibling() != null && R.PreviousSibling<Run>() != null && (R.PreviousSibling<Run>().InnerText.EndsWith(".") || R.PreviousSibling<Run>().InnerText.EndsWith(",") || R.PreviousSibling<Run>().InnerText.EndsWith(":")))
                                    {
                                        if (R.RunProperties.VerticalTextAlignment != null)
                                        {
                                            if (R.RunProperties.VerticalTextAlignment.Val == "superscript")
                                            {
                                                R.RunProperties.Append(new RunStyle() { Val = "citebib" });
                                            }

                                        }
                                        if (R.RunProperties.Position != null)
                                        {
                                            if (Convert.ToInt32(R.RunProperties.Position.Val.Value) > 0)
                                            {
                                                R.RunProperties.Append(new RunStyle() { Val = "citebib" });
                                            }

                                        }
                                    }
                                    else if ((R.InnerText == "-" || R.InnerText == "–" || Regex.Match(R.InnerText, "[0-9]+").Success) && !R.InnerText.EndsWith("+"))
                                    {
                                        if (R.RunProperties.VerticalTextAlignment != null)
                                        {
                                            if (R.RunProperties.VerticalTextAlignment.Val == "superscript")
                                            {
                                                R.RunProperties.Append(new RunStyle() { Val = "citebib" });
                                            }

                                        }
                                        if (R.RunProperties.Position != null)
                                        {
                                            if (Convert.ToInt32(R.RunProperties.Position.Val.Value) > 0)
                                            {
                                                R.RunProperties.Append(new RunStyle() { Val = "citebib" });
                                            }

                                        }
                                    }
                                }
                            }
                        }
                    }

                    D.Save();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void NspacetoNormalspace(string wordFilePath)/////In comma double space and double dot remove text
        {
            try
            {
                object outputFileName = null;
                object oMissing = System.Reflection.Missing.Value;
                Microsoft.Office.Interop.Word.Application word = new Microsoft.Office.Interop.Word.Application();
                try
                {
                    word.Visible = false;
                    word.ScreenUpdating = false;
                    word.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
                    Object filename = (Object)wordFilePath;
                    //Document doc = word.Documents.Open(ref filename, ref oMissing,
                    //                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                    //                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                    //                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing);
                    Microsoft.Office.Interop.Word.Document doc = word.Documents.Open(filename, false);
                    try
                    {
                        Microsoft.Office.Interop.Word.Range r = doc.Content;
                        r.WholeStory();
                        r.Find.Execute("[\u00A0", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "[", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute("\u00A0]", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "]", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute("\u00A0", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, " ", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);



                        doc.SaveAs(ref filename,
                                    ref oMissing, ref oMissing,
                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing);
                    }
                    finally
                    {
                        //object saveChanges = WdSaveOptions.wdDoNotSaveChanges;
                        //((_Document)doc).Close(ref saveChanges, ref oMissing, ref oMissing);
                        //doc = null;
                        doc.Close();
                    }
                }
                finally
                {
                    //((_Application)word).Quit(ref oMissing, ref oMissing, ref oMissing);
                    word.Quit();
                    word = null;
                }


            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);

            }
        }

        public static void RemovespacedotwithdotinPara(string newDoc)     //Developer Name:Narayan, Date:19_10_2020 ,Requirement:Apply remove space in start and end of para.
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P.Descendants<Run>().ToList().Count > 0)
                    {
                        var runlast = P.Descendants<Run>().LastOrDefault();

                        if (runlast.Descendants<Text>().ToList().Count > 0 && runlast.Descendants<Text>().LastOrDefault().InnerText.EndsWith(" ."))
                        {
                            var textfirst = runlast.Descendants<Text>().LastOrDefault();
                            textfirst.Text = textfirst.Text.TrimEnd('.').TrimEnd() + ".";
                        }


                    }
                }
                D.Save();

            }
        }
        public static void ApplyTFNAfterTable(string strProcessDoc)
        {
            bool TTParaFound = false;
            using (WordprocessingDocument WPD = WordprocessingDocument.Open(strProcessDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(x => x.ParagraphProperties != null && x.ParagraphProperties.ParagraphStyleId != null && x.ParagraphProperties.ParagraphStyleId.Val != null))
                {
                    if (P.ParagraphProperties != null && P.Parent != null && P.Parent.LocalName != "tc")  //Developer Name:Priyanka Vishwakarma .Date:20-07-2020 ,Requirement :Avoid to remove blank para from table.
                    {
                        if (P.ParagraphProperties.ParagraphStyleId.Val.Value == "TT")
                        {
                            TTParaFound = true;
                        }
                        else if (P.ParagraphProperties.ParagraphStyleId.Val.Value == "H1" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H2"
                            || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H3" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H4"
                            || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H5" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H6"
                            || P.ParagraphProperties.ParagraphStyleId.Val.Value == "FIGC" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "BoxStart"
                            || P.ParagraphProperties.ParagraphStyleId.Val.Value == "BoxEnd" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "CustomListStart"
                            || P.ParagraphProperties.ParagraphStyleId.Val.Value == "CustomListEnd")
                        {
                            TTParaFound = false;
                        }
                        if (TTParaFound)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId.Val.Value == "BodyA" || P.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower().EndsWith("list"))
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "TFN";
                            }

                        }
                    }
                }
                D.Save();
            }
        }
        public static void ApplyBoxStartandBoxEndToAppendixPara(string newDoc)     //Developer Name:Priyanka Vishwakarma, Date:20_02_2020 ,Requirement:Apply BoxStart and BoxEnd Paragraph style to for Appendix Paragraphs.,Integrated by:Vikas sir.
        {
            bool AppendixParaFound = false;
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {

                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && (P.ParagraphProperties.ParagraphStyleId.Val.Value == "H1" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "Heading1" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "TT" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "Header")) //Developer name:Priyanka Vishwakarma ;Date :03-06-2020 ;Requirement: Handle Appendix Table Without Heading 1 ; 
                    {
                        if (P.InnerText.ToLower().Trim().StartsWith("appendix"))
                        {
                            Paragraph paraStart = new Paragraph();
                            paraStart.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "BoxStart" });
                            P.InsertBeforeSelf(paraStart);
                            AppendixParaFound = true;
                            break;

                        }
                    }
                }

                if (AppendixParaFound)
                {
                    Paragraph paraEnd = new Paragraph();
                    paraEnd.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "BoxEnd" });
                    D.AppendChild(paraEnd);
                }
                D.Save();
            }
        }

        public static void SageIndiaEnglishArticleMappinngBasedonText(string newDoc)
        {
            bool corrStart = false;
            bool ABTxtStart = false;
            bool keywordStart = false;
            bool indent = false;
            bool blockquoteStart = false;
            bool blockquoteEnd = false;
            if (GlobalMethods.strCopyEditingRequired != null && GlobalMethods.strCopyEditingRequired.ToLower() == "true")
                ConvertTOHardEnters(newDoc);
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;


                foreach (Paragraph P in D.Descendants<Paragraph>().Where(x => x.Parent != null && x.Parent.LocalName != W.tc.LocalName).ToList())
                {

                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && (P.ParagraphProperties.ParagraphStyleId.Val == "Heading1" || P.ParagraphProperties.ParagraphStyleId.Val == "NormalWeb"))////removed all customer style applied and applied BodyA
                    {
                        P.ParagraphProperties.ParagraphStyleId.Val.Value = "BodyA";
                    }

                    /////added by vikas for article has paragraph style on 31-03-2021 
                    if (P.ParagraphProperties != null && P.ParagraphProperties.Justification != null && P.ParagraphProperties.Justification.Val == JustificationValues.Right)/////For Right align text
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "BodyTextRight";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "BodyTextRight" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "BodyTextRight" }));

                        }
                        continue;
                    }
                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val == "authors")
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "TI";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "TI" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "TI" }));

                        }
                        continue;
                    }
                    if (P.InnerText.StartsWith("<Article Type>") || P.InnerText.StartsWith("<Dochead>") || P.InnerText.ToLower().StartsWith("<article type>") || P.InnerText.ToLower().StartsWith("<dochead>") || P.InnerText.ToLower().StartsWith("<atype>"))
                    {
                        P.Descendants<Text>().FirstOrDefault().Text = P.Descendants<Text>().FirstOrDefault().Text.Replace("<Article Type>", "").Replace("<Dochead>", "").Replace("<ATYPE>", "");
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "DT";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "DT" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "DT" }));

                        }
                        continue;
                    }
                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower() == "articletitle")
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "TI";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "TI" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "TI" }));

                        }
                        continue;
                    }
                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower() == "alevel")
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                if (P.InnerText.ToLower().Replace("<a level>", "").Replace("level a", "").StartsWith("appendix ") && P.NextSibling() != null && P.NextSibling().LocalName == "tbl")
                                {
                                    P.ParagraphProperties.Append(new ParagraphStyleId { Val = "TT" });
                                }
                                else
                                {
                                    P.ParagraphProperties.ParagraphStyleId.Val.Value = "H1";
                                }
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "H1" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "H1" }));

                        }
                        continue;
                    }
                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower() == "bodytextstart")
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "BodyA";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "BodyA" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "BodyA" }));

                        }
                        continue;
                    }
                    //////End//////////////
                    if (corrStart)
                    {
                        if (P.InnerText.Trim().Contains("</CA>") || P.InnerText.ToLower().Contains("<ed>"))
                        {
                            P.Descendants<Text>().LastOrDefault().Text = P.Descendants<Text>().LastOrDefault().Text.Replace("</CA>", "");
                            if (P.ParagraphProperties != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                                {
                                    P.ParagraphProperties.ParagraphStyleId.Val.Value = "CORR";
                                    corrStart = false;
                                }
                                else
                                {
                                    P.ParagraphProperties.Append(new ParagraphStyleId { Val = "CORR" });
                                    corrStart = false;
                                }
                            }
                            else
                            {
                                P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "CORR" }));
                                corrStart = false;

                            }
                        }
                        else if (P.InnerText.Trim().ToLower().StartsWith("<abs head>"))
                        {
                            corrStart = false;
                            if (P.ParagraphProperties != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                                {
                                    P.ParagraphProperties.ParagraphStyleId.Val.Value = "AB";
                                }
                                else
                                {
                                    P.ParagraphProperties.Append(new ParagraphStyleId { Val = "AB" });
                                }
                            }
                            else
                            {
                                P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "AB" }));

                            }
                        }
                        else
                        {
                            if (P.ParagraphProperties != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                                {
                                    P.ParagraphProperties.ParagraphStyleId.Val.Value = "CORR";
                                }
                                else
                                {
                                    P.ParagraphProperties.Append(new ParagraphStyleId { Val = "CORR" });
                                }
                            }
                            else
                            {
                                P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "CORR" }));

                            }
                        }
                    }
                    else if (ABTxtStart)
                    {
                        if (P.InnerText.Trim().EndsWith("</Abs>"))
                        {
                            corrStart = false;
                            P.Descendants<Text>().LastOrDefault().Text = P.Descendants<Text>().LastOrDefault().Text.Replace("</Abs>", "");
                            if (P.ParagraphProperties != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                                {
                                    P.ParagraphProperties.ParagraphStyleId.Val.Value = "AB-TXT";
                                    ABTxtStart = false;
                                }
                                else
                                {
                                    P.ParagraphProperties.Append(new ParagraphStyleId { Val = "AB-TXT" });
                                    ABTxtStart = false;
                                }
                            }
                            else
                            {
                                P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "AB-TXT" }));
                                ABTxtStart = false;

                            }
                        }
                        else if (P.InnerText.Trim().ToLower() == "keywords" || P.InnerText.Trim().ToLower().StartsWith("<kw>") || P.InnerText.Trim().ToLower().StartsWith("<k/w>"))
                        {
                            if (P.ParagraphProperties != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                                {
                                    P.ParagraphProperties.ParagraphStyleId.Val.Value = "KYWD";
                                    keywordStart = true;
                                    ABTxtStart = false;
                                }
                                else
                                {
                                    P.ParagraphProperties.Append(new ParagraphStyleId { Val = "KYWD" });
                                    keywordStart = true;
                                    ABTxtStart = false;
                                }
                            }
                            else
                            {
                                P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "KYWD" }));
                                keywordStart = true;
                                ABTxtStart = false;

                            }
                        }
                        else
                        {
                            if (P.ParagraphProperties != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                                {
                                    P.ParagraphProperties.ParagraphStyleId.Val.Value = "AB-TXT";
                                }
                                else
                                {
                                    P.ParagraphProperties.Append(new ParagraphStyleId { Val = "AB-TXT" });
                                }
                            }
                            else
                            {
                                P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "AB-TXT" }));

                            }
                        }

                    }
                    else if (keywordStart)
                    {
                        if (P.InnerText.Trim().ToLower().EndsWith("</kw>"))
                        {
                            corrStart = false;
                            P.Descendants<Text>().LastOrDefault().Text = P.Descendants<Text>().LastOrDefault().Text.Replace("</kw>", "");
                            if (P.ParagraphProperties != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                                {
                                    P.ParagraphProperties.ParagraphStyleId.Val.Value = "KYWD";
                                    keywordStart = false;
                                }
                                else
                                {
                                    P.ParagraphProperties.Append(new ParagraphStyleId { Val = "KYWD" });
                                    keywordStart = false;
                                }
                            }
                            else
                            {
                                P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "KYWD" }));
                                keywordStart = false;

                            }
                        }
                        else
                        {
                            if (P.ParagraphProperties != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                                {
                                    P.ParagraphProperties.ParagraphStyleId.Val.Value = "KYWD";
                                    keywordStart = false;
                                }
                                else
                                {
                                    P.ParagraphProperties.Append(new ParagraphStyleId { Val = "KYWD" });
                                    keywordStart = false;
                                }
                            }
                            else
                            {
                                P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "KYWD" }));
                                keywordStart = false;

                            }
                        }

                    }

                    if (P.InnerText.Trim().StartsWith("<A Level>") || P.InnerText.Trim().StartsWith("<Level A>") || P.InnerText.Trim().StartsWith("<Appendix>") || P.InnerText.Trim().ToLower().StartsWith("<appendix>") || P.InnerText.Trim().ToLower().StartsWith("<annexures>"))////////<Level A> added by vikas on 31-03-2021
                    {
                        keywordStart = false;
                        ABTxtStart = false;
                        corrStart = false;
                        if (P.Descendants<Text>().FirstOrDefault() != null && P.Descendants<Text>().FirstOrDefault().Text.Trim() == "")
                        {
                            foreach (var text in P.Descendants<Text>().ToList())
                            {
                                text.Text = text.Text.Replace("<A Level>", "").Replace("<Level A>", "");
                            }
                        }
                        else
                        {
                            P.Descendants<Text>().FirstOrDefault().Text = P.Descendants<Text>().FirstOrDefault().Text.Replace("<A Level>", "").Replace("<Level A>", "");
                        }
                        if (P.Descendants<Text>().FirstOrDefault().Text != "<A Level>")
                        {
                            string text = "";
                            foreach (var r in P.Descendants<Run>().ToList())
                            {
                                if (r.Descendants().Where(x => x.LocalName.ToString() == "b").ToList().Count() == 0)
                                {
                                    text += r.InnerText;
                                }
                            }

                            if (text == "<A Level>")
                            {
                                foreach (var r in P.Descendants<Run>().ToList())
                                {
                                    if (r.Descendants().Where(x => x.LocalName.ToString() == "b").ToList().Count() == 0)
                                    {
                                        r.Remove();
                                    }
                                }
                            }

                        }
                        else if (P.Descendants<Text>().FirstOrDefault().Text != "<Level A>")
                        {
                            string text = "";
                            foreach (var r in P.Descendants<Run>().ToList())
                            {
                                if (r.Descendants().Where(x => x.LocalName.ToString() == "b").ToList().Count() == 0)
                                {
                                    text += r.InnerText;
                                }
                            }

                            if (text == "<Level A>")
                            {
                                foreach (var r in P.Descendants<Run>().ToList())
                                {
                                    if (r.Descendants().Where(x => x.LocalName.ToString() == "b").ToList().Count() == 0)
                                    {
                                        r.Remove();
                                    }
                                }
                            }

                        }
                        // P.Descendants<Text>().FirstOrDefault().Text = P.Descendants<Text>().FirstOrDefault().Text.Replace("<a>", "");
                        if (P.ParagraphProperties != null && (P.InnerText != "References Cited" && P.InnerText != "References" && P.InnerText != "Reference"))
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "H1";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "H1" });
                            }
                        }

                        else if (P.ParagraphProperties != null && (P.InnerText == "References Cited" || P.InnerText == "References" || P.InnerText == "Reference"))
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "REF";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "REF" });
                            }
                        }
                        else if (P.InnerText == "References Cited" || P.InnerText == "References" || P.InnerText == "Reference")
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "REF" }));

                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "H1" }));

                        }
                    }
                    else if (P.InnerText.Trim().StartsWith("<B Level>") || (P.InnerText.Trim().StartsWith("<Level B>")))
                    {
                        keywordStart = false;
                        ABTxtStart = false;
                        corrStart = false;
                        if (P.Descendants<Text>().FirstOrDefault() != null && P.Descendants<Text>().FirstOrDefault().Text.Trim() == "")
                        {
                            foreach (var text in P.Descendants<Text>().ToList())
                            {
                                text.Text = text.Text.Replace("<B Level>", "").Replace("<Level B>", "");
                            }
                        }
                        else
                        {
                            P.Descendants<Text>().FirstOrDefault().Text = P.Descendants<Text>().FirstOrDefault().Text.Replace("<B Level>", "").Replace("<Level B>", "");
                        }
                        if (P.Descendants<Text>().FirstOrDefault().Text != "<B Level>")
                        {
                            string text = "";
                            foreach (var r in P.Descendants<Run>().ToList())
                            {
                                if (r.Descendants().Where(x => x.LocalName.ToString() == "b").ToList().Count() == 0)
                                {
                                    text += r.InnerText;
                                }
                            }

                            if (text == "<B Level>")
                            {
                                foreach (var r in P.Descendants<Run>().ToList())
                                {
                                    if (r.Descendants().Where(x => x.LocalName.ToString() == "b").ToList().Count() == 0)
                                    {
                                        r.Remove();
                                    }
                                }
                            }

                        }
                        else if (P.Descendants<Text>().FirstOrDefault().Text != "<Level B>")
                        {
                            string text = "";
                            foreach (var r in P.Descendants<Run>().ToList())
                            {
                                if (r.Descendants().Where(x => x.LocalName.ToString() == "b").ToList().Count() == 0)
                                {
                                    text += r.InnerText;
                                }
                            }

                            if (text == "<Level B>")
                            {
                                foreach (var r in P.Descendants<Run>().ToList())
                                {
                                    if (r.Descendants().Where(x => x.LocalName.ToString() == "b").ToList().Count() == 0)
                                    {
                                        r.Remove();
                                    }
                                }
                            }

                        }
                        // P.Descendants<Text>().FirstOrDefault().Text = P.Descendants<Text>().FirstOrDefault().Text.Replace("<a>", "");
                        if (P.ParagraphProperties != null && (P.InnerText != "References Cited" && P.InnerText != "References" && P.InnerText != "Reference"))
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "H2";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "H2" });
                            }
                        }
                    }
                    else if (P.InnerText.Trim().StartsWith("<C Level>") || P.InnerText.Trim().StartsWith("<Level C>"))
                    {
                        keywordStart = false;
                        ABTxtStart = false;
                        corrStart = false;
                        if (P.Descendants<Text>().FirstOrDefault() != null && P.Descendants<Text>().FirstOrDefault().Text.Trim() == "")
                        {
                            foreach (var text in P.Descendants<Text>().ToList())
                            {
                                text.Text = text.Text.Replace("<C Level>", "").Replace("<Level C>", "");
                            }
                        }
                        else
                        {
                            P.Descendants<Text>().FirstOrDefault().Text = P.Descendants<Text>().FirstOrDefault().Text.Replace("<C Level>", "").Replace("<Level C>", "");
                        }
                        if (P.Descendants<Text>().FirstOrDefault().Text != "<C Level>")
                        {
                            string text = "";
                            foreach (var r in P.Descendants<Run>().ToList())
                            {
                                if (r.Descendants().Where(x => x.LocalName.ToString() == "b").ToList().Count() == 0)
                                {
                                    text += r.InnerText;
                                }
                            }

                            if (text == "<C Level>")
                            {
                                foreach (var r in P.Descendants<Run>().ToList())
                                {
                                    if (r.Descendants().Where(x => x.LocalName.ToString() == "b").ToList().Count() == 0)
                                    {
                                        r.Remove();
                                    }
                                }
                            }

                        }
                        else if (P.Descendants<Text>().FirstOrDefault().Text != "<Level C>")
                        {
                            string text = "";
                            foreach (var r in P.Descendants<Run>().ToList())
                            {
                                if (r.Descendants().Where(x => x.LocalName.ToString() == "b").ToList().Count() == 0)
                                {
                                    text += r.InnerText;
                                }
                            }

                            if (text == "<Level C>")
                            {
                                foreach (var r in P.Descendants<Run>().ToList())
                                {
                                    if (r.Descendants().Where(x => x.LocalName.ToString() == "b").ToList().Count() == 0)
                                    {
                                        r.Remove();
                                    }
                                }
                            }

                        }
                        // P.Descendants<Text>().FirstOrDefault().Text = P.Descendants<Text>().FirstOrDefault().Text.Replace("<a>", "");
                        if (P.ParagraphProperties != null && (P.InnerText != "References Cited" && P.InnerText != "References" && P.InnerText != "Reference"))
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "H3";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "H3" });
                            }
                        }
                    }
                    else if (P.InnerText.Trim().StartsWith("<D Level>") || (P.InnerText.Trim().StartsWith("<Level D>")))
                    {
                        keywordStart = false;
                        ABTxtStart = false;
                        corrStart = false;
                        if (P.Descendants<Text>().FirstOrDefault() != null && P.Descendants<Text>().FirstOrDefault().Text.Trim() == "")
                        {
                            foreach (var text in P.Descendants<Text>().ToList())
                            {
                                text.Text = text.Text.Replace("<D Level>", "").Replace("<Level D>", "");
                            }
                        }
                        else
                        {
                            P.Descendants<Text>().FirstOrDefault().Text = P.Descendants<Text>().FirstOrDefault().Text.Replace("<D Level>", "").Replace("<Level D>", "");
                        }
                        if (P.Descendants<Text>().FirstOrDefault().Text != "<D Level>")
                        {
                            string text = "";
                            foreach (var r in P.Descendants<Run>().ToList())
                            {
                                if (r.Descendants().Where(x => x.LocalName.ToString() == "b").ToList().Count() == 0)
                                {
                                    text += r.InnerText;
                                }
                            }

                            if (text == "<D Level>")
                            {
                                foreach (var r in P.Descendants<Run>().ToList())
                                {
                                    if (r.Descendants().Where(x => x.LocalName.ToString() == "b").ToList().Count() == 0)
                                    {
                                        r.Remove();
                                    }
                                }
                            }

                        }
                        else if (P.Descendants<Text>().FirstOrDefault().Text != "<Level D>")
                        {
                            string text = "";
                            foreach (var r in P.Descendants<Run>().ToList())
                            {
                                if (r.Descendants().Where(x => x.LocalName.ToString() == "b").ToList().Count() == 0)
                                {
                                    text += r.InnerText;
                                }
                            }

                            if (text == "<Level D>")
                            {
                                foreach (var r in P.Descendants<Run>().ToList())
                                {
                                    if (r.Descendants().Where(x => x.LocalName.ToString() == "b").ToList().Count() == 0)
                                    {
                                        r.Remove();
                                    }
                                }
                            }

                        }
                        // P.Descendants<Text>().FirstOrDefault().Text = P.Descendants<Text>().FirstOrDefault().Text.Replace("<a>", "");
                        if (P.ParagraphProperties != null && (P.InnerText != "References Cited" && P.InnerText != "References" && P.InnerText != "Reference"))
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "H4";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "H4" });
                            }
                        }
                    }
                    else if (P.InnerText.StartsWith("<Article Title>") || P.InnerText.StartsWith("<AT>") || P.InnerText.StartsWith("<Article title>") || P.InnerText.ToLower().StartsWith("<at>") || P.InnerText.ToLower().StartsWith("<article title>"))
                    {
                        P.Descendants<Text>().FirstOrDefault().Text = P.Descendants<Text>().FirstOrDefault().Text.Replace("<Article Title>", "").Replace("<AT>", "");
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "TI";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "TI" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "TI" }));

                        }

                    }
                    else if (P.InnerText.StartsWith("<Indent>") || indent == true)/////Indent condition added by vikas on 31-03-2021
                    {
                        indent = true;
                        if (P.InnerText.EndsWith("</Indent>"))
                        {
                            indent = false;
                        }
                        P.Descendants<Text>().FirstOrDefault().Text = P.Descendants<Text>().FirstOrDefault().Text.Replace("<Indent>", "");
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "BodyTextIndent";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "BodyTextIndent" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "BodyTextIndent" }));

                        }
                    }
                    else if (P.InnerText.StartsWith("<Author Name>") || P.InnerText.StartsWith("<Author>") || P.InnerText.StartsWith("<Author Names>") || P.InnerText.StartsWith("<AN>") || P.InnerText.StartsWith("<author>") || P.InnerText.ToLower().StartsWith("<author name>") || P.InnerText.ToLower().StartsWith("<author>") || P.InnerText.ToLower().StartsWith("<author names>") || P.InnerText.ToLower().StartsWith("<an>") || P.InnerText.ToLower().StartsWith("<auth>"))//31-01-2021
                    {
                        P.Descendants<Text>().FirstOrDefault().Text = P.Descendants<Text>().FirstOrDefault().Text.Replace("<Author Name>", "").Replace("<Author>", "");
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "AU";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "AU" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "AU" }));

                        }
                    }
                    else if (P.InnerText.StartsWith("<Aff>") || P.InnerText.ToLower().StartsWith("<affl>") || P.InnerText.ToLower().Trim().StartsWith("<affil>"))////aff1 condition added by vikas on 31-03-2021
                    {
                        P.Descendants<Text>().FirstOrDefault().Text = P.Descendants<Text>().FirstOrDefault().Text.Replace("<Aff>", "").Replace("<aff1>", "").Replace("<Aff1>", "");
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "AFFL";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "AFFL" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "AFFL" }));

                        }
                    }
                    else if (P.InnerText.StartsWith("<CA>") || P.InnerText.ToLower().StartsWith("<ca>") || P.InnerText.ToLower().Trim().StartsWith("<correspondence>"))
                    {
                        P.Descendants<Text>().FirstOrDefault().Text = P.Descendants<Text>().FirstOrDefault().Text.Replace("<CA>", "");
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "CORR";
                                corrStart = true;
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "CORR" });
                                corrStart = true;
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "CORR" }));
                            corrStart = true;

                        }
                    }
                    else if (P.InnerText.ToLower().StartsWith("corresponding author") || P.InnerText.ToLower().StartsWith("e-mail"))//////Added by vikas on 31-03-2021
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "CORR";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "CORR" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "CORR" }));
                        }
                    }
                    else if (P.InnerText.ToLower() == "notes" || P.InnerText.ToLower() == "note")//////Added by vikas on 31-03-2021
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "H1";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "H1" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "H1" }));
                        }
                    }
                    else if (P.InnerText.StartsWith("<ed>"))
                    {
                        P.Descendants<Text>().FirstOrDefault().Text = P.Descendants<Text>().FirstOrDefault().Text.Replace("<ed>", "");
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "CORR";
                                corrStart = false;
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "CORR" });
                                corrStart = false;
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "CORR" }));
                            corrStart = false;

                        }
                    }
                    else if (P.InnerText.StartsWith("<Abs head>") || P.InnerText.StartsWith("<Abshead>") || P.InnerText.ToLower().StartsWith("<abs head>") || P.InnerText.ToLower().StartsWith("<abshead>"))//31-05-2021
                    {
                        corrStart = false;
                        P.Descendants<Text>().FirstOrDefault().Text = P.Descendants<Text>().FirstOrDefault().Text.Replace("<Abs head>", "");
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "AB";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "AB" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "AB" }));

                        }
                    }
                    else if (P.InnerText.StartsWith("<Abs>") || P.InnerText.StartsWith("<abs>"))
                    {
                        P.Descendants<Text>().FirstOrDefault().Text = P.Descendants<Text>().FirstOrDefault().Text.Replace("<Abs>", "");
                        P.Descendants<Text>().LastOrDefault().Text = P.Descendants<Text>().LastOrDefault().Text.Replace("</Abs>", "");
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "AB-TXT";
                                ABTxtStart = true;
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "AB-TXT" });
                                ABTxtStart = true;
                            }

                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "AB-TXT" }));
                            ABTxtStart = true;

                        }
                    }
                    else if (P.InnerText.StartsWith("<kw>") || P.InnerText.StartsWith("<Keywords>") || P.InnerText.ToLower().StartsWith("<keywords>") || P.InnerText.ToLower().Trim() == "keywords" || P.InnerText.ToLower().Trim().StartsWith("<k/w>"))
                    {
                        ABTxtStart = false;
                        P.Descendants<Text>().FirstOrDefault().Text = P.Descendants<Text>().FirstOrDefault().Text.Replace("<kw>", "").Replace("<Keywords>", "");
                        P.Descendants<Text>().LastOrDefault().Text = P.Descendants<Text>().LastOrDefault().Text.Replace("</kw>", "");
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "KYWD";
                                keywordStart = true;
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "KYWD" });
                                keywordStart = true;
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "KYWD" }));
                            keywordStart = true;

                        }
                    }
                    else if (P.InnerText.StartsWith("<rh>"))
                    {
                        P.Descendants<Text>().FirstOrDefault().Text = P.Descendants<Text>().FirstOrDefault().Text.Replace("<rh>", "");
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "RRH";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "RRH" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "RRH" }));

                        }
                    }
                    //Developer Name:Priyanka Vishwakarma,Date:23-04-2021,Requirement:handle Quote paragraph for sage india 
                    else if (blockquoteStart == true)
                    {
                        if (P.InnerText.ToLower().Trim() == "<block quote ends>")
                        {
                            blockquoteStart = false;
                            continue;
                        }

                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "EXT";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "EXT" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "EXT" }));

                        }
                        // blockquoteStart = false;

                    }
                    else if (P.InnerText.ToLower().Trim() == "<block quote begins>")
                    {
                        blockquoteStart = true;
                        P.Descendants<Text>().FirstOrDefault().Text = P.Descendants<Text>().FirstOrDefault().Text.Replace("<Block Quote Begins>", "").Replace("<Block quote begins>", "");
                    }
                    else if (P.InnerText.ToLower().Trim() == "<block quote ends>")
                    {
                        blockquoteStart = false;
                        P.Descendants<Text>().LastOrDefault().Text = P.Descendants<Text>().LastOrDefault().Text.Replace("<Block Quote Ends>", "").Replace("<Block quote ends>", "").Replace("<Block Quote Ends", "");


                    }
                    else if (P.InnerText.StartsWith("<Block Quote Begins>") || P.InnerText.StartsWith("<Block quote begins>"))////For Quote added  by vikas on 23-03-2021
                    {
                        P.Descendants<Text>().FirstOrDefault().Text = P.Descendants<Text>().FirstOrDefault().Text.Replace("<Block Quote Begins>", "").Replace("<Block quote begins>", "");
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "EXT";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "EXT" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "EXT" }));

                        }
                        P.Descendants<Text>().LastOrDefault().Text = P.Descendants<Text>().LastOrDefault().Text.Replace("<Block Quote Ends>", "").Replace("<Block quote ends>", "").Replace("<Block Quote Ends", "");

                    }
                    else if (P.InnerText.ToLower().Trim().StartsWith("source:") || P.InnerText.ToLower().Trim().StartsWith("note:") || P.InnerText.ToLower().Trim().StartsWith("*") || P.InnerText.ToLower().Trim().StartsWith("notes:"))/////changed by vikas for toLower() check on 31-03-2021
                    {

                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "TFN";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "TFN" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "TFN" }));

                        }

                    }

                    else if (P.InnerText.ToLower().Trim() == "authors’ bio-sketch" || P.InnerText.ToLower().Trim() == "author bio-sketch")
                    {

                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "H1";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "H1" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "H1" }));

                        }

                    }
                    else if (P.InnerText.ToLower().Trim() == "<list begins>") //Developer Name:Priyanka Vishwakarma,Date:30-07-2021,Requirement:Add condition for apply customliststart in sage
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "CustomListStart";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "CustomListStart" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "CustomListStart" }));

                        }

                    }
                    else if (P.InnerText.ToLower().Trim() == "<list ends>") //Developer Name:Priyanka Vishwakarma,Date:30-07-2021,Requirement:Add condition for apply customlistEnd in sage
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "CustomListEnd";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "CustomListEnd" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "CustomListEnd" }));

                        }

                    }
                    else if (P.InnerText == "" && P.Parent != null && P.Parent.LocalName != W.tc.LocalName)
                    {
                        P.Remove();
                    }
                    //if (Regex.Match(P.InnerText, @"({insert figures|{insert tables)+\s([0-9]+)[\-|\–|\-|\.]+([0-9]+\s(here}))",RegexOptions.IgnoreCase).Success || Regex.Match(P.InnerText, @"({insert figure|{insert table)+\s([0-9]+\s(here}))",RegexOptions.IgnoreCase).Success || Regex.Match(P.InnerText, @"({insert figures|{insert tables)+\s([0-9]+)\s(and)+\s+([0-9]+)\s(here})",RegexOptions.IgnoreCase).Success)
                    if (P.InnerText.Contains("{insert") && P.InnerText.Trim().EndsWith("}"))
                    {
                        foreach (var text in P.Descendants<Text>().ToList())
                        {
                            var txt = text.Text.Split('{');
                            text.Text = txt[0];
                            //if (Regex.Match(text.Text, @"({insert figures)+\s([0-9]+)[\-|\–|\-|\.]+([0-9]+\s(here}))").Success )
                            //{
                            //    text.Text = Regex.Replace(text.Text, @"({insert figures)+\s([0-9]+)[\-|\–|\-|\.]+([0-9]+\s(here}))", "");
                            //}
                            //else if(Regex.Match(text.Text, @"({insert figure)+\s([0-9]+\s(here}))").Success)
                            //{
                            //    text.Text = Regex.Replace(text.Text, @"({insert figure)+\s([0-9]+\s(here}))", "");
                            //}
                            //else if (Regex.Match(text.Text, @"({insert figures)+\s([0-9]+)\s(and)+\s+([0-9]+)\s(here})").Success)
                            //{
                            //    text.Text = Regex.Replace(text.Text, @"({insert figures)+\s([0-9]+)\s(and)+\s+([0-9]+)\s(here})", "");
                            //}                            
                        }
                    }
                    else if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val == "authoraffiliation" && !P.InnerText.StartsWith("<"))
                    {
                        if (P.PreviousSibling() != null && P.PreviousSibling<Paragraph>().Count() > 0 && P.PreviousSibling<Paragraph>().FirstOrDefault().XName.LocalName == "pPr" && ((ParagraphProperties)P.PreviousSibling<Paragraph>().FirstOrDefault()) != null && ((ParagraphProperties)P.PreviousSibling<Paragraph>().FirstOrDefault()).ParagraphStyleId != null && ((ParagraphProperties)P.PreviousSibling<Paragraph>().FirstOrDefault()).ParagraphStyleId.Val == "TI")
                        {
                            P.ParagraphProperties.ParagraphStyleId.Val.Value = "TI";
                        }
                    }
                    else if (P.InnerText.Contains("https://orcid.org/") && GlobalMethods.RegExSearch(P.InnerText.TrimStart(' '), @"[0-9]{4}\-[0-9]{4}\-[0-9]{4}\-[0-9X]{4}") != "")//Developer name:Priyanka Vishwakarma,Date:20-04-2021,Requirement:Apply ORCID-AU Para style for sage.
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "ORCID-AU";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "ORCID-AU" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "ORCID-AU" }));
                        }
                    }
                    else if (Regex.Match(P.InnerText.Trim(), @"^(Appendix\s{1,}[IVX]+)|^(Appendix\s{1,}[A-Z])|^(appendix\s{1,}[IVX]+)|^(appendix\s{1,}[A-Z])").Success)////Developer Name:Priyanka Vishwakarma,Date:15-09-2021, Requirement:Apply heading 1 to appendix heading para.
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val = "H1";
                            }
                            else
                            {
                                P.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId { Val = "H1" };
                            }
                        }
                        else
                        {
                            P.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "H1" });
                        }
                    }
                    else if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val == "body")
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "BodyA";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "BodyA" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "BodyA" }));

                        }
                        continue;
                    }
                    else if ((P.InnerText.ToLower().Trim() == "<backmatter>" /*|| P.InnerText.ToLower().Trim() == "<list begins>" || P.InnerText.ToLower().Trim() == "<list ends>"*/) && P.Parent.LocalName != W.tc.LocalName)
                    {
                        P.Remove();
                    }


                }

                D.Save();
            }

            ReplaceplaceholdersSageIndia(newDoc);///for remove copyedited tag from document
        }
        public static void ArticleMappinngBasedonTags(string newDoc)
        {
            bool corrStart = false;
            bool ABTxtStart = false;
            bool keywordStart = false;
            bool indent = false;
            bool blockquoteStart = false;
            bool blockquoteEnd = false;
            ConvertTOHardEnters(newDoc);
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;


                foreach (Paragraph P in D.Descendants<Paragraph>().Where(x => x.Parent != null && x.Parent.LocalName != W.tc.LocalName).ToList())
                {
                   if (P.InnerText.Trim().StartsWith("<A Level>") || P.InnerText.Trim().StartsWith("<Level A>") || P.InnerText.Trim().StartsWith("<Appendix>") || P.InnerText.Trim().ToLower().StartsWith("<appendix>") || P.InnerText.Trim().ToLower().StartsWith("<annexures>"))////////<Level A> added by vikas on 31-03-2021
                    {
                        keywordStart = false;
                        ABTxtStart = false;
                        corrStart = false;
                        if (P.Descendants<Text>().FirstOrDefault() != null && P.Descendants<Text>().FirstOrDefault().Text.Trim() == "")
                        {
                            foreach (var text in P.Descendants<Text>().ToList())
                            {
                                text.Text = text.Text.Replace("<A Level>", "").Replace("<Level A>", "");
                            }
                        }
                        else
                        {
                            P.Descendants<Text>().FirstOrDefault().Text = P.Descendants<Text>().FirstOrDefault().Text.Replace("<A Level>", "").Replace("<Level A>", "");
                        }
                        if (P.Descendants<Text>().FirstOrDefault().Text != "<A Level>")
                        {
                            string text = "";
                            foreach (var r in P.Descendants<Run>().ToList())
                            {
                                if (r.Descendants().Where(x => x.LocalName.ToString() == "b").ToList().Count() == 0)
                                {
                                    text += r.InnerText;
                                }
                            }

                            if (text == "<A Level>")
                            {
                                foreach (var r in P.Descendants<Run>().ToList())
                                {
                                    if (r.Descendants().Where(x => x.LocalName.ToString() == "b").ToList().Count() == 0)
                                    {
                                        r.Remove();
                                    }
                                }
                            }

                        }
                        else if (P.Descendants<Text>().FirstOrDefault().Text != "<Level A>")
                        {
                            string text = "";
                            foreach (var r in P.Descendants<Run>().ToList())
                            {
                                if (r.Descendants().Where(x => x.LocalName.ToString() == "b").ToList().Count() == 0)
                                {
                                    text += r.InnerText;
                                }
                            }

                            if (text == "<Level A>")
                            {
                                foreach (var r in P.Descendants<Run>().ToList())
                                {
                                    if (r.Descendants().Where(x => x.LocalName.ToString() == "b").ToList().Count() == 0)
                                    {
                                        r.Remove();
                                    }
                                }
                            }

                        }
                        // P.Descendants<Text>().FirstOrDefault().Text = P.Descendants<Text>().FirstOrDefault().Text.Replace("<a>", "");
                        if (P.ParagraphProperties != null && (P.InnerText != "References Cited" && P.InnerText != "References" && P.InnerText != "Reference"))
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "H1";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "H1" });
                            }
                        }

                        else if (P.ParagraphProperties != null && (P.InnerText == "References Cited" || P.InnerText == "References" || P.InnerText == "Reference"))
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "REF";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "REF" });
                            }
                        }
                        else if (P.InnerText == "References Cited" || P.InnerText == "References" || P.InnerText == "Reference")
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "REF" }));

                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "H1" }));

                        }
                    }
                    else if (P.InnerText.Trim().StartsWith("<B Level>") || (P.InnerText.Trim().StartsWith("<Level B>")))
                    {
                        keywordStart = false;
                        ABTxtStart = false;
                        corrStart = false;
                        if (P.Descendants<Text>().FirstOrDefault() != null && P.Descendants<Text>().FirstOrDefault().Text.Trim() == "")
                        {
                            foreach (var text in P.Descendants<Text>().ToList())
                            {
                                text.Text = text.Text.Replace("<B Level>", "").Replace("<Level B>", "");
                            }
                        }
                        else
                        {
                            P.Descendants<Text>().FirstOrDefault().Text = P.Descendants<Text>().FirstOrDefault().Text.Replace("<B Level>", "").Replace("<Level B>", "");
                        }
                        if (P.Descendants<Text>().FirstOrDefault().Text != "<B Level>")
                        {
                            string text = "";
                            foreach (var r in P.Descendants<Run>().ToList())
                            {
                                if (r.Descendants().Where(x => x.LocalName.ToString() == "b").ToList().Count() == 0)
                                {
                                    text += r.InnerText;
                                }
                            }

                            if (text == "<B Level>")
                            {
                                foreach (var r in P.Descendants<Run>().ToList())
                                {
                                    if (r.Descendants().Where(x => x.LocalName.ToString() == "b").ToList().Count() == 0)
                                    {
                                        r.Remove();
                                    }
                                }
                            }

                        }
                        else if (P.Descendants<Text>().FirstOrDefault().Text != "<Level B>")
                        {
                            string text = "";
                            foreach (var r in P.Descendants<Run>().ToList())
                            {
                                if (r.Descendants().Where(x => x.LocalName.ToString() == "b").ToList().Count() == 0)
                                {
                                    text += r.InnerText;
                                }
                            }

                            if (text == "<Level B>")
                            {
                                foreach (var r in P.Descendants<Run>().ToList())
                                {
                                    if (r.Descendants().Where(x => x.LocalName.ToString() == "b").ToList().Count() == 0)
                                    {
                                        r.Remove();
                                    }
                                }
                            }

                        }
                        // P.Descendants<Text>().FirstOrDefault().Text = P.Descendants<Text>().FirstOrDefault().Text.Replace("<a>", "");
                        if (P.ParagraphProperties != null && (P.InnerText != "References Cited" && P.InnerText != "References" && P.InnerText != "Reference"))
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "H2";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "H2" });
                            }
                        }
                    }
                    else if (P.InnerText.Trim().StartsWith("<C Level>") || P.InnerText.Trim().StartsWith("<Level C>"))
                    {
                        keywordStart = false;
                        ABTxtStart = false;
                        corrStart = false;
                        if (P.Descendants<Text>().FirstOrDefault() != null && P.Descendants<Text>().FirstOrDefault().Text.Trim() == "")
                        {
                            foreach (var text in P.Descendants<Text>().ToList())
                            {
                                text.Text = text.Text.Replace("<C Level>", "").Replace("<Level C>", "");
                            }
                        }
                        else
                        {
                            P.Descendants<Text>().FirstOrDefault().Text = P.Descendants<Text>().FirstOrDefault().Text.Replace("<C Level>", "").Replace("<Level C>", "");
                        }
                        if (P.Descendants<Text>().FirstOrDefault().Text != "<C Level>")
                        {
                            string text = "";
                            foreach (var r in P.Descendants<Run>().ToList())
                            {
                                if (r.Descendants().Where(x => x.LocalName.ToString() == "b").ToList().Count() == 0)
                                {
                                    text += r.InnerText;
                                }
                            }

                            if (text == "<C Level>")
                            {
                                foreach (var r in P.Descendants<Run>().ToList())
                                {
                                    if (r.Descendants().Where(x => x.LocalName.ToString() == "b").ToList().Count() == 0)
                                    {
                                        r.Remove();
                                    }
                                }
                            }

                        }
                        else if (P.Descendants<Text>().FirstOrDefault().Text != "<Level C>")
                        {
                            string text = "";
                            foreach (var r in P.Descendants<Run>().ToList())
                            {
                                if (r.Descendants().Where(x => x.LocalName.ToString() == "b").ToList().Count() == 0)
                                {
                                    text += r.InnerText;
                                }
                            }

                            if (text == "<Level C>")
                            {
                                foreach (var r in P.Descendants<Run>().ToList())
                                {
                                    if (r.Descendants().Where(x => x.LocalName.ToString() == "b").ToList().Count() == 0)
                                    {
                                        r.Remove();
                                    }
                                }
                            }

                        }
                        // P.Descendants<Text>().FirstOrDefault().Text = P.Descendants<Text>().FirstOrDefault().Text.Replace("<a>", "");
                        if (P.ParagraphProperties != null && (P.InnerText != "References Cited" && P.InnerText != "References" && P.InnerText != "Reference"))
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "H3";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "H3" });
                            }
                        }
                    }
                    else if (P.InnerText.Trim().StartsWith("<D Level>") || (P.InnerText.Trim().StartsWith("<Level D>")))
                    {
                        keywordStart = false;
                        ABTxtStart = false;
                        corrStart = false;
                        if (P.Descendants<Text>().FirstOrDefault() != null && P.Descendants<Text>().FirstOrDefault().Text.Trim() == "")
                        {
                            foreach (var text in P.Descendants<Text>().ToList())
                            {
                                text.Text = text.Text.Replace("<D Level>", "").Replace("<Level D>", "");
                            }
                        }
                        else
                        {
                            P.Descendants<Text>().FirstOrDefault().Text = P.Descendants<Text>().FirstOrDefault().Text.Replace("<D Level>", "").Replace("<Level D>", "");
                        }
                        if (P.Descendants<Text>().FirstOrDefault().Text != "<D Level>")
                        {
                            string text = "";
                            foreach (var r in P.Descendants<Run>().ToList())
                            {
                                if (r.Descendants().Where(x => x.LocalName.ToString() == "b").ToList().Count() == 0)
                                {
                                    text += r.InnerText;
                                }
                            }

                            if (text == "<D Level>")
                            {
                                foreach (var r in P.Descendants<Run>().ToList())
                                {
                                    if (r.Descendants().Where(x => x.LocalName.ToString() == "b").ToList().Count() == 0)
                                    {
                                        r.Remove();
                                    }
                                }
                            }

                        }
                        else if (P.Descendants<Text>().FirstOrDefault().Text != "<Level D>")
                        {
                            string text = "";
                            foreach (var r in P.Descendants<Run>().ToList())
                            {
                                if (r.Descendants().Where(x => x.LocalName.ToString() == "b").ToList().Count() == 0)
                                {
                                    text += r.InnerText;
                                }
                            }

                            if (text == "<Level D>")
                            {
                                foreach (var r in P.Descendants<Run>().ToList())
                                {
                                    if (r.Descendants().Where(x => x.LocalName.ToString() == "b").ToList().Count() == 0)
                                    {
                                        r.Remove();
                                    }
                                }
                            }

                        }
                        // P.Descendants<Text>().FirstOrDefault().Text = P.Descendants<Text>().FirstOrDefault().Text.Replace("<a>", "");
                        if (P.ParagraphProperties != null && (P.InnerText != "References Cited" && P.InnerText != "References" && P.InnerText != "Reference"))
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "H4";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "H4" });
                            }
                        }
                    }
                    else if (P.InnerText.StartsWith("<rh>"))
                    {
                        P.Descendants<Text>().FirstOrDefault().Text = P.Descendants<Text>().FirstOrDefault().Text.Replace("<rh>", "");
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "RRH";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "RRH" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "RRH" }));

                        }
                    }                                       
                    else if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val == "body")
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "BodyA";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "BodyA" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "BodyA" }));

                        }
                        continue;
                    }
                   


                }

                D.Save();
            }

            ReplaceplaceholdersSageIndia(newDoc);///for remove copyedited tag from document
        }

        public static void CheckForbibnumberInPara(string newDoc)     //Developer Name:Priyanka Vishwakarma, Date:15-04-2021 ,Requirement:Apply REF1 paragraph style when para contains bibnumber char style.
        {
            bool AppendixParaFound = false;
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {

                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                    {
                        if (P.Descendants<Run>().ToList().Any(x => x.RunProperties != null && x.RunProperties.RunStyle != null && x.RunProperties.RunStyle.Val != null && x.RunProperties.RunStyle.Val.Value == "bibnumber"))
                        {
                            P.ParagraphProperties.ParagraphStyleId.Val.Value = "REF1";
                        }

                    }
                }

                D.Save();
            }
        }

        public static void CheckParaStyleBodyAtoTTXTInTable(string newDoc)     //Developer Name:Priyanka Vishwakarma, Date:21-06-2021 ,Requirement:Apply T-TXT Paragarpha style instead of BodyA Para style in table.
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                   .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P.ParagraphProperties != null && P.Parent != null && P.Parent.LocalName == "tc" && P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val.Value == "BodyA")
                    {
                        P.ParagraphProperties.ParagraphStyleId.Val.Value = "T-TXT";
                    }
                    else if (P.ParagraphProperties != null && P.Parent != null && P.Parent.LocalName == "tc" && P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val.Value == "TCH" && P.InnerText.Trim() == "")
                    {
                        P.ParagraphProperties.ParagraphStyleId.Val.Value = "T-TXT";
                    }
                }
                D.Save();
            }
        }

        public static void JaypeeArticleMappinngBasedonText(string newDoc)
        {
            int CounterTitle = 0;
            int CounterRRH = 0;
            int ParagraphCount = 0;
            int CounterCorr = 0;
            if (GlobalMethods.strCopyEditingRequired != null && GlobalMethods.strCopyEditingRequired.ToLower() == "true")
                ConvertTOHardEnters(newDoc);
            bool boolHeader = false;
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                ParagraphCount++;
                MainDocumentPart MDP = WPD.MainDocumentPart;
                Document D = MDP.Document;
                foreach (Paragraph P in D.Descendants<Paragraph>().Where(x => x.Parent != null && x.Parent.LocalName != W.tc.LocalName).ToList())
                {
                    if (P.InnerText.ToLower().Trim().StartsWith("title:"))
                    {
                        //P.Descendants<Text>().FirstOrDefault().Text = P.Descendants<Text>().FirstOrDefault().Text.Trim().Replace("Title: ", "").Replace("TITLE: ", "").Replace("title: ", "").Replace("Title:", "").Replace("TITLE:", "").Replace("title:", "").TrimStart(' ');
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "TI";
                                CounterTitle = 1;
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "TI" });
                                CounterTitle = 1;
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "TI" }));
                            CounterTitle = 1;
                        }
                    }
                    else if (P.InnerText.ToLower().Trim().StartsWith("category:"))
                    {
                        P.Descendants<Text>().FirstOrDefault().Text = P.Descendants<Text>().FirstOrDefault().Text.Trim().Replace("Category: ", "").Replace("CATEGORY: ", "").Replace("category: ", "").Replace("Category:", "").Replace("CATEGORY:", "").Replace("category:", "");
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "DT";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "DT" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "DT" }));
                        }
                    }
                    else if (P.InnerText.ToLower().Trim().StartsWith("running head"))
                    {
                        P.Descendants<Text>().FirstOrDefault().Text = P.Descendants<Text>().FirstOrDefault().Text.Trim().Replace("Running Head: ", "").Replace("RUNNING HEAD: ", "").Replace("running head: ", "").Replace("Running Head:", "").Replace("RUNNING HEAD:", "").Replace("running head:", "").Replace("Running head:", "");
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "RRH";
                                CounterRRH = 1;
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "RRH" });
                                CounterRRH = 1;
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "RRH" }));
                            CounterRRH = 1;
                        }
                    }
                    else if (P.InnerText.ToLower().Trim().StartsWith("correspond") || P.InnerText.ToLower().Trim().StartsWith("email:"))
                    {
                        if (CounterCorr == 0)
                        {
                            if (P.ParagraphProperties != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                                {
                                    P.ParagraphProperties.ParagraphStyleId.Val.Value = "CORR";
                                    CounterCorr = 1;
                                }
                                else
                                {
                                    P.ParagraphProperties.Append(new ParagraphStyleId { Val = "CORR" });
                                    CounterCorr = 1;
                                }
                            }
                            else
                            {
                                P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "CORR" }));
                                CounterCorr = 1;
                            }
                        }
                    }
                    else if (P.InnerText.ToLower().Trim().StartsWith("abstract"))
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "AB";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "AB" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "AB" }));
                        }
                        boolHeader = true;
                    }
                    else if (P.InnerText.ToLower().Trim().StartsWith("keyword") || P.InnerText.ToLower().Trim().StartsWith("key word") || P.InnerText.ToLower().Trim().StartsWith("ky word"))
                    {
                        if (P.ParagraphProperties != null)
                        {

                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "KYWD";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "KYWD" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "KYWD" }));
                        }
                        boolHeader = true;
                    }
                    else if (P.InnerText.ToLower().Trim() == "final references" || P.InnerText.ToLower().Trim() == "references" || P.InnerText.ToLower().Trim() == "reference" || P.InnerText.ToLower().Trim() == "final reference" || P.InnerText.ToLower().Trim() == "refernce" || P.InnerText.ToLower().Trim() == "refrence")
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "REF";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "REF" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "REF" }));
                        }
                        boolHeader = true;
                    }
                    else if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower() == "article-type") //Developer Name:Priyanka Vishwakarma, Date:13-1-2022, Add condition for apply DT paragraph style for SSLLC
                    {
                        P.ParagraphProperties.ParagraphStyleId.Val.Value = "DT";
                    }
                    else if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && (P.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower() == "article-title"|| P.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower() == "ti"))
                    {
                        P.ParagraphProperties.ParagraphStyleId.Val.Value = "TI";
                        CounterTitle = 1;
                    }
                    else if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower() == "aff")
                    {
                        P.ParagraphProperties.ParagraphStyleId.Val.Value = "AFFL";
                    }
                    else if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower() == "rrh")
                    {
                        P.ParagraphProperties.ParagraphStyleId.Val.Value = "RRH";
                        CounterRRH = 1;
                    }
                    else
                    {
                        // Conditons for Head Part
                        if (boolHeader == false)
                        {

                            if (P.InnerText.ToLower().Trim().Length > 10)
                            {
                                if (P.ParagraphProperties!= null && P.ParagraphProperties.ParagraphStyleId!=null && P.ParagraphProperties.ParagraphStyleId.Val!=null && (P.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower().Trim() == "txt" || P.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower().Trim() == "bodya" || P.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower().Trim() == "body"))
                                {
                                    if (CounterTitle == 0)
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val.Value = "TI";
                                        CounterTitle = 1;
                                    }
                                    else if (CounterRRH == 0)
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val.Value = "RRH";
                                        CounterRRH = 1;
                                    }
                                    if (CounterTitle == 1 && CounterRRH == 1)
                                    {
                                        boolHeader = true;
                                    }
                                }
                            }

                        }
                    }
                }

                D.Save();
            }
            ReplaceplaceholdersJaypee(newDoc);

        }

       
        public static void JaypeeArticleMappinngBasedonTextold(string newDoc)
        {
            ConvertTOHardEnters(newDoc);
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;
                Document D = MDP.Document;
                foreach (Paragraph P in D.Descendants<Paragraph>().Where(x => x.Parent != null && x.Parent.LocalName != W.tc.LocalName).ToList())
                {
                    if (P.InnerText.ToLower().Trim().StartsWith("title:"))
                    {
                        //P.Descendants<Text>().FirstOrDefault().Text = P.Descendants<Text>().FirstOrDefault().Text.Trim().Replace("Title: ", "").Replace("TITLE: ", "").Replace("title: ", "").Replace("Title:", "").Replace("TITLE:", "").Replace("title:", "").TrimStart(' ');
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "TI";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "TI" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "TI" }));
                        }
                    }
                    else if (P.InnerText.ToLower().Trim().StartsWith("category:"))
                    {
                        P.Descendants<Text>().FirstOrDefault().Text = P.Descendants<Text>().FirstOrDefault().Text.Trim().Replace("Category: ", "").Replace("CATEGORY: ", "").Replace("category: ", "").Replace("Category:", "").Replace("CATEGORY:", "").Replace("category:", "");
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "DT";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "DT" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "DT" }));
                        }
                    }
                    else if (P.InnerText.ToLower().Trim().StartsWith("running head:"))
                    {
                        P.Descendants<Text>().FirstOrDefault().Text = P.Descendants<Text>().FirstOrDefault().Text.Trim().Replace("Running Head: ", "").Replace("RUNNING HEAD: ", "").Replace("running head: ", "").Replace("Running Head:", "").Replace("RUNNING HEAD:", "").Replace("running head:", "").Replace("Running head:", "");
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "RRH";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "RRH" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "RRH" }));
                        }
                    }
                    else if (P.InnerText.ToLower().Trim().StartsWith("corresponding author:") || P.InnerText.ToLower().Trim().StartsWith("email:"))
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "CORR";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "CORR" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "CORR" }));
                        }
                    }
                    else if (P.InnerText.ToLower().Trim().StartsWith("abstract:"))
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "AB";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "AB" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "AB" }));
                        }
                    }
                    else if (P.InnerText.ToLower().Trim().StartsWith("keyword:") || P.InnerText.ToLower().Trim().StartsWith("key words:"))
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "KYWD";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "KYWD" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "KYWD" }));
                        }
                    }
                    else if (P.InnerText.ToLower().Trim() == "final references:" || P.InnerText.ToLower().Trim() == "references:" || P.InnerText.ToLower().Trim() == "references" || P.InnerText.ToLower().Trim() == "final references" || P.InnerText.ToLower().Trim() == "reference" || P.InnerText.ToLower().Trim() == "reference:")
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "REF";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "REF" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "REF" }));
                        }
                    }
                }

                D.Save();
            }
            ReplaceplaceholdersJaypee(newDoc);

        }
        public static void ApplyABTXTParagraphStyle(string newDoc)
        {
            bool ABParaFound = false;
            bool KWDParaFound = false;
            using (WordprocessingDocument WPD = WordprocessingDocument
                .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;
                Document D = MDP.Document;
                foreach (Paragraph P in D.Descendants<Paragraph>().Where(x => x.Parent != null && x.Parent.LocalName != W.tc.LocalName).ToList())
                {
                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val.Value == "AB" && P.ParagraphProperties.ParagraphStyleId.Val.Value == "KYWD")//Changes made by Danish: date 13-10-2023,Keyword style was not applied thats why we added condition. 
                    {
                        ABParaFound = true;
                        KWDParaFound = true;
                        continue;
                    }
                    else if (GlobalMethods.strClientName.ToLower()=="pps" && P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val.Value == "KYWD")
                    {
                        ABParaFound = false;
                       // break;
                    }
                    else if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && (P.ParagraphProperties.ParagraphStyleId.Val.Value == "KYWD" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H1" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H2" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H3" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H4" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H5" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H6"))
                    {
                        ABParaFound = false;
                        break;
                    }

                    if (ABParaFound)
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "AB-TXT";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "AB-TXT" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "AB-TXT" }));
                        }
                    }
                }
                D.Save();
            }
        }

        public static void ReplaceplaceholdersJaypee(string wordFilePath)
        {
            try
            {
                List<string> strSagetags = new List<string> { "Title: ", "TITLE: ", "title: ", "Title: ", "Category: ", "CATEGORY: ", "category: ", "Running Head: ", "Running head: ", "RUNNING HEAD: ", "running head: " };
                
                object oMissing = System.Reflection.Missing.Value;
                Microsoft.Office.Interop.Word.Application word = new Microsoft.Office.Interop.Word.Application();
                try
                {
                    word.Visible = false;
                    word.ScreenUpdating = false;
                    word.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
                    Object filename = (Object)wordFilePath;
                    Microsoft.Office.Interop.Word.Document doc = word.Documents.Open(filename, false);
                    try
                    {
                        Microsoft.Office.Interop.Word.Range r = doc.Content;
                        r.WholeStory();
                        strSagetags.ForEach(txt =>
                        {
                            r.Find.Execute(txt, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        });
                        doc.SaveAs(ref filename,
                                    ref oMissing, ref oMissing,
                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing);
                    }
                    finally
                    {
                        //object saveChanges = WdSaveOptions.wdDoNotSaveChanges;
                        //((_Document)doc).Close(ref saveChanges, ref oMissing, ref oMissing);
                        //doc = null;
                        doc.Close();
                    }
                }
                finally
                {
                    //((_Application)word).Quit(ref oMissing, ref oMissing, ref oMissing);
                    word.Quit();
                    word = null;
                }


            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);

            }
        }

        public static void ApplyHeadingTwoForbackMatterHeading(string newDoc)
        {
            bool ABParaFound = false;
            using (WordprocessingDocument WPD = WordprocessingDocument
                .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;
                Document D = MDP.Document;
                foreach (Paragraph P in D.Descendants<Paragraph>().Where(x => x.Parent != null && x.Parent.LocalName != W.tc.LocalName).ToList())
                {
                    if (P.InnerText.Trim().ToLower() == "acknowledgement" ||
                        P.InnerText.Trim().ToLower() == "acknowledgements" ||
                        P.InnerText.Trim().ToLower() == "declaration of conflicting interests" ||
                        P.InnerText.Trim().ToLower() == "declaration of conflicting interest" ||
                        P.InnerText.Trim().ToLower() == "funding")
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "H2";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "H2" });
                            }
                        }

                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "H2" }));
                        }
                    }
                }
                foreach (Paragraph P in D.Descendants<Paragraph>().Where(x => x.Parent != null && x.Parent.LocalName != W.tc.LocalName).ToList())
                {
                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val.Value == "ACK-TXT")
                    {
                        P.ParagraphProperties.ParagraphStyleId.Val.Value = "BodyA";
                    }
                }
                D.Save();
            }
        }
        public static void addOrcidPara(List<XElement> orcidList, string newDoc)
        {
            bool addOrcidParaFound = false;
            using (WordprocessingDocument WPD = WordprocessingDocument
               .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(c => c.Parent.LocalName != W.tc && c.ParagraphProperties != null && c.ParagraphProperties.ParagraphStyleId != null && c.ParagraphProperties.ParagraphStyleId.Val != null && c.ParagraphProperties.ParagraphStyleId.Val.Value == "H1").ToList())
                {
                    if(P.InnerText.ToLower()== "orcid ids" || P.InnerText.Trim() == "ORCID iD" || P.InnerText.Trim() == "ORCID iD"|| P.InnerText.Trim().ToLower() == "orcid id" || P.InnerText.Trim().ToLower() == "orcid id")
                    {
                        addOrcidParaFound = true;
                    }
                }

                if(addOrcidParaFound==false)
                {
                    List<string> authorNameWithOrcidId = new List<string>();
                    foreach(var orcid in orcidList.ToList())
                    {
                        string AuthorName = "";
                        string id = "";
                        var firstName = orcid.Descendants("first_name").ToList().FirstOrDefault().Value;
                        var middleName = orcid.Descendants("middle_name").ToList().FirstOrDefault().Value;
                        var surnameName = orcid.Descendants("last_name").ToList().FirstOrDefault().Value;
                        var orcidId = orcid.Descendants("orcid").ToList().FirstOrDefault().Value;
                        if (!string.IsNullOrEmpty(firstName))
                        {
                            AuthorName = firstName + " ";
                        }
                        if(!string.IsNullOrEmpty(middleName))
                        {
                            AuthorName = AuthorName + middleName + " ";
                        }
                        if (!string.IsNullOrEmpty(surnameName))
                        {
                            AuthorName = AuthorName + surnameName + " ";
                        }
                        if (!string.IsNullOrEmpty(orcidId))
                        {
                            id = orcidId;
                        }
                        //ORCID iD
                        // Daniel Penido de Lima Amorim https://orcid.org/0000-0002-2844-3079

                        string orcidPara = AuthorName + " " + "https://orcid.org/" + id;
                        authorNameWithOrcidId.Add(orcidPara);

                    }
                    if (authorNameWithOrcidId.Count() > 0)
                    {
                        var refPara = D.Descendants<Paragraph>().ToList().Where(c => c.Parent.LocalName != W.tc && c.ParagraphProperties != null && c.ParagraphProperties.ParagraphStyleId != null && c.ParagraphProperties.ParagraphStyleId.Val != null && c.ParagraphProperties.ParagraphStyleId.Val.Value == "REF").ToList().FirstOrDefault();
                        if (refPara != null) ;
                        Paragraph heading = new Paragraph();
                        heading.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "H1" });
                        Run r1 = new Run();
                        Text newtext = new Text();
                        newtext.Text = "ORCID iD";
                        r1.AppendChild(newtext);
                        heading.AppendChild(r1);
                        refPara.Parent.InsertBefore(heading, refPara);

                        foreach(var p in authorNameWithOrcidId.ToList())
                        {
                            Paragraph orcidpara = new Paragraph();
                            orcidpara.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "ORCID-AU" });
                            Run r2 = new Run();
                            Text newtext1 = new Text();
                            newtext1.Text = p;
                            r2.AppendChild(newtext1);
                            orcidpara.AppendChild(r2);
                            refPara.Parent.InsertBefore(orcidpara, refPara);
                        }
                    }
                }
                D.Save();
            }

        }

        public static void CheckDTParaForSAGE(string newDoc)
        {            
            var strDTabbr = ConfigurationManager.AppSettings.Get("DTStyleAbbr");
            List<string> strDTabbrColl = new List<string>();
            strDTabbrColl = GlobalMethods.ReadAndStoreFileValuesInArray(strDTabbr);
            if (strDTabbrColl.Count() > 0)
            {
                using (WordprocessingDocument WPD = WordprocessingDocument
                   .Open(newDoc, true))
                {
                    MainDocumentPart MDP = WPD.MainDocumentPart;

                    Document D = MDP.Document;
                    var DTPara = D.Descendants<Paragraph>().ToList().Where(c => c.Parent.LocalName != W.tc && c.ParagraphProperties != null && c.ParagraphProperties.ParagraphStyleId != null && c.ParagraphProperties.ParagraphStyleId.Val != null && c.ParagraphProperties.ParagraphStyleId.Val.Value == "DT").ToList().FirstOrDefault();
                    if (DTPara == null)
                    {
                        var TIPara = D.Descendants<Paragraph>().ToList().Where(c => c.Parent.LocalName != W.tc && c.ParagraphProperties != null && c.ParagraphProperties.ParagraphStyleId != null && c.ParagraphProperties.ParagraphStyleId.Val != null && c.ParagraphProperties.ParagraphStyleId.Val.Value == "TI").ToList().FirstOrDefault();
                        if (TIPara != null && TIPara.InnerText.Trim() != "")
                        {
                            Paragraph NewDtParagraph = new Paragraph();
                            NewDtParagraph.ParagraphProperties = new ParagraphProperties(new ParagraphStyleId { Val = "DT" });
                            Run r1 = new Run();
                            Text newtext = new Text();
                            foreach (var str in strDTabbrColl)
                            {
                                if (str.ToLower().Contains(GlobalMethods.strArticleType.ToLower()))
                                {
                                    newtext.Text = str.Split('|').LastOrDefault();
                                }
                            }
                            r1.AppendChild(newtext);
                            NewDtParagraph.AppendChild(r1);
                            TIPara.Parent.InsertBefore(NewDtParagraph, TIPara);
                        }
                    }


                    D.Save();
                }
            }

        }

        public static void ReplaceplaceholdersForPunctuations(string wordFilePath)
        {
            try
            {
                object outputFileName = null;
                object oMissing = System.Reflection.Missing.Value;
                Microsoft.Office.Interop.Word.Application word = new Microsoft.Office.Interop.Word.Application();
                try
                {
                    word.Visible = false;
                    word.ScreenUpdating = false;
                    word.DisplayAlerts = Microsoft.Office.Interop.Word.WdAlertLevel.wdAlertsNone;
                    Object filename = (Object)wordFilePath;
                    //Document doc = word.Documents.Open(ref filename, ref oMissing,
                    //                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                    //                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                    //                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing);
                    Microsoft.Office.Interop.Word.Document doc = word.Documents.Open(filename, false);
                    try
                    {
                        Microsoft.Office.Interop.Word.Range r = doc.Content;
                        r.WholeStory();
                        r.Find.Execute(" , ", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ", ", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute(" . ", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ". ", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute(" ; ", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "; ", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute(" : ", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ": ", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute(" ? ", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "? ", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute(" ,", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ",", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute(" .", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ".", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute(" ;", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ";", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute(" :", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ":", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        r.Find.Execute(" ?", ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, "?", Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll);
                        doc.SaveAs(ref filename,
                                    ref oMissing, ref oMissing,
                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing);
                    }
                    finally
                    {
                        //object saveChanges = WdSaveOptions.wdDoNotSaveChanges;
                        //((_Document)doc).Close(ref saveChanges, ref oMissing, ref oMissing);
                        //doc = null;
                        doc.Close();
                    }
                }
                finally
                {
                    //((_Application)word).Quit(ref oMissing, ref oMissing, ref oMissing);
                    word.Quit();
                    word = null;
                }


            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);

            }
        }

        public static void mergeRef1Para(string newDoc)  //Developer Name:Priyanka Vishwkarma,Date:29-3-2022, Requirement: merge reference paragraph.
        {
            bool refParaFound = false;
            List<Paragraph> ALLRef1Para = new List<Paragraph>();
            using (WordprocessingDocument WPD = WordprocessingDocument
                .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;
                Document D = MDP.Document;
                foreach (Paragraph P in D.Descendants<Paragraph>().Where(x => x.Parent != null && x.Parent.LocalName != W.tc.LocalName).ToList())
                {
                    var newP = P.CloneNode(true);
                    if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val.Value == "REF")
                    {
                        refParaFound = true;
                        continue;
                    }
                    else if (refParaFound == true && P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && (P.ParagraphProperties.ParagraphStyleId.Val.Value == "KYWD" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H1" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H2" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H3" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H4" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H5" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H6" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "FIGC" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "TT" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "TFN" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "TCH" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "T-TXT"))
                    {
                        refParaFound = false;
                        break;
                    }
                    else if (refParaFound == true && (P.InnerText.Trim().ToLower().StartsWith("graph") || P.InnerText.Trim().ToLower().StartsWith("fig") || P.InnerText.Trim().ToLower().StartsWith("flowchart") || P.InnerText.Trim().ToLower().StartsWith("table")))
                    {
                        refParaFound = false;
                        break;
                    }

                    if (refParaFound)
                    {
                        if (P.NextSibling() != null && P.NextSibling().LocalName.ToString() == "p")
                        {
                            Paragraph checkp = (Paragraph)P.NextSibling();
                            Paragraph checkNextP = null;

                            //if (checkp == null)
                            //{
                            //    checkNextP = (Paragraph)P.NextSibling().NextSibling();
                            //}


                            if (checkp != null && checkp.Parent != null && checkp.Parent.LocalName != W.tc.LocalName)
                            {
                                if (checkp.ParagraphProperties != null && checkp.ParagraphProperties.ParagraphStyleId != null && checkp.ParagraphProperties.ParagraphStyleId.Val != null && (checkp.ParagraphProperties.ParagraphStyleId.Val.Value != "KYWD" && checkp.ParagraphProperties.ParagraphStyleId.Val.Value != "H1" && checkp.ParagraphProperties.ParagraphStyleId.Val.Value != "H2" && checkp.ParagraphProperties.ParagraphStyleId.Val.Value != "H3" && checkp.ParagraphProperties.ParagraphStyleId.Val.Value != "H4" && checkp.ParagraphProperties.ParagraphStyleId.Val.Value != "H5" && checkp.ParagraphProperties.ParagraphStyleId.Val.Value != "H6" && checkp.ParagraphProperties.ParagraphStyleId.Val.Value != "FIGC" && checkp.ParagraphProperties.ParagraphStyleId.Val.Value != "TT" && checkp.ParagraphProperties.ParagraphStyleId.Val.Value != "TFN" && P.ParagraphProperties.ParagraphStyleId.Val.Value != "TCH" && checkp.ParagraphProperties.ParagraphStyleId.Val.Value != "T-TXT"))
                                {
                                    if (refParaFound == true && (checkp.InnerText.Trim().ToLower().StartsWith("graph") || checkp.InnerText.Trim().ToLower().StartsWith("fig") || checkp.InnerText.Trim().ToLower().StartsWith("flowchart") || checkp.InnerText.Trim().ToLower().StartsWith("table")))
                                    {
                                        refParaFound = false;
                                        break;
                                    }
                                    else
                                    { 
                                    var strnum = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(checkp.InnerText.Trim(), @"^[0-9]+\.\s?");

                                    if (string.IsNullOrEmpty(strnum))
                                    {
                                        List<Run> allRun = checkp.Descendants<Run>().ToList();
                                        foreach (var run in allRun.ToList())
                                        {
                                            var newR = run.CloneNode(true);
                                            newP.AppendChild(newR);
                                        }
                                        checkp.Remove();

                                        P.InsertAfterSelf(newP);
                                        if (P.NextSibling().NextSibling().LocalName.ToString() == "p" && (Paragraph)P.NextSibling().NextSibling() != null)
                                        {
                                            if (P.NextSibling().NextSibling().LocalName.ToString() == "p")
                                            {
                                                Paragraph checkNextp = (Paragraph)P.NextSibling().NextSibling();

                                                if (checkNextp != null && checkNextp.Parent != null && checkNextp.Parent.LocalName != W.tc.LocalName)
                                                {
                                                    if (checkNextp.ParagraphProperties != null && checkNextp.ParagraphProperties.ParagraphStyleId != null && checkNextp.ParagraphProperties.ParagraphStyleId.Val != null && (checkNextp.ParagraphProperties.ParagraphStyleId.Val.Value != "KYWD" && checkNextp.ParagraphProperties.ParagraphStyleId.Val.Value != "H1" && checkNextp.ParagraphProperties.ParagraphStyleId.Val.Value != "H2" && checkNextp.ParagraphProperties.ParagraphStyleId.Val.Value != "H3" && checkNextp.ParagraphProperties.ParagraphStyleId.Val.Value != "H4" && checkNextp.ParagraphProperties.ParagraphStyleId.Val.Value != "H5" && checkNextp.ParagraphProperties.ParagraphStyleId.Val.Value != "H6" && checkNextp.ParagraphProperties.ParagraphStyleId.Val.Value != "FIGC" && checkNextp.ParagraphProperties.ParagraphStyleId.Val.Value != "TT" && checkNextp.ParagraphProperties.ParagraphStyleId.Val.Value != "TFN" && checkNextp.ParagraphProperties.ParagraphStyleId.Val.Value != "TCH" && checkNextp.ParagraphProperties.ParagraphStyleId.Val.Value != "T-TXT"))
                                                    {
                                                        var strnum1 = GlobalMethods.SearchRegExPatternFirstSearchInstanceOnly(checkNextp.InnerText.Trim(), @"^[0-9]+\.\s?");

                                                        if (string.IsNullOrEmpty(strnum1))
                                                        {
                                                            List<Run> allRun1 = checkNextp.Descendants<Run>().ToList();
                                                            foreach (var run in allRun1.ToList())
                                                            {
                                                                var newR = run.CloneNode(true);
                                                                newP.AppendChild(newR);
                                                            }
                                                            checkNextp.Remove();
                                                        }
                                                    }
                                                }
                                            }
                                        }

                                        P.Remove();
                                    }
                                }
                            }
                            }
                        }

                    }
                }
                D.Save();
            }
        }
        
        public static void PPSArticleMappinngBasedonText(string newDoc)
        {
            int CounterTitle = 0;
            int CounterRRH = 0;
            int ParagraphCount = 0;
            int CounterCorr = 0;
            if (GlobalMethods.strCopyEditingRequired != null && GlobalMethods.strCopyEditingRequired.ToLower() == "true")
                ConvertTOHardEnters(newDoc);
            bool boolHeader = false;
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                ParagraphCount++;
                MainDocumentPart MDP = WPD.MainDocumentPart;
                Document D = MDP.Document;
                foreach (Paragraph P in D.Descendants<Paragraph>().Where(x => x.Parent != null && x.Parent.LocalName != W.tc.LocalName).ToList())
                {
                    if (P.InnerText.ToLower().Trim().StartsWith("<h1>"))
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "H1";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "H1" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "H1" }));
                        }
                    }
                    else if (P.InnerText.ToLower().Trim() == "funding" || P.InnerText.ToLower().Trim() == "fundings" || P.InnerText.ToLower().Trim() == "conflict of interest" || P.InnerText.ToLower().Trim() == "conflicts of interest" || P.InnerText.ToLower().Trim() == "ethical disclosures")
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "H1";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "H1" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "H1" }));

                        }

                    }
                    else if (P.InnerText.ToLower().Trim().StartsWith("<rh>")|| P.InnerText.ToLower().Trim().StartsWith("running head"))
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "RRH";
                                CounterRRH = 1;
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "RRH" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "RRH" }));

                        }

                    }
                    else if (P.InnerText.Replace("*", "").Trim().ToLower().StartsWith("correspondence to") || P.InnerText.Replace("*", "").Trim().ToLower().StartsWith("corresponding author") || P.InnerText.Replace("*", "").Trim().ToLower().StartsWith("correspond author"))
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "CORR";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "CORR" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "CORR" }));

                        }
                    }
                    else if (P.InnerText.Trim().StartsWith("DOI") || P.InnerText.Trim().StartsWith("Received:") || P.InnerText.Trim().StartsWith("Accepted:"))
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "UID";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "UID" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "UID" }));

                        }
                        boolHeader = true;
                    }
                    else if (P.InnerText.ToLower().Trim().StartsWith("abstract") || P.InnerText.ToLower().Trim().StartsWith("resumo"))
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "AB";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "AB" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "AB" }));
                        }
                        boolHeader = true;
                    }
                    else if (P.InnerText.ToLower().Trim().StartsWith("keyword") || P.InnerText.ToLower().Trim().StartsWith("key word") || P.InnerText.ToLower().Trim().StartsWith("ky word") || P.InnerText.ToLower().Trim().StartsWith("keywords") || P.InnerText.ToLower().Trim().StartsWith("palavras-chave")|| P.InnerText.ToLower().Trim().StartsWith("palavras–chave") || P.InnerText.ToLower().Trim().StartsWith("palavras—chave"))
                    {
                        if (P.ParagraphProperties != null)
                        {

                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "KYWD";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "KYWD" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "KYWD" }));
                        }
                        boolHeader = true;
                    }
                    else if (P.InnerText.ToLower().Trim() == "final references" || P.InnerText.ToLower().Trim() == "references" || P.InnerText.ToLower().Trim() == "reference" || P.InnerText.ToLower().Trim() == "final reference" || P.InnerText.ToLower().Trim() == "refernce" || P.InnerText.ToLower().Trim() == "refrence")
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null)
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "REF";
                            }
                            else
                            {
                                P.ParagraphProperties.Append(new ParagraphStyleId { Val = "REF" });
                            }
                        }
                        else
                        {
                            P.Append(new ParagraphProperties(new ParagraphStyleId { Val = "REF" }));
                        }
                        boolHeader = true;
                    }
                    
                    else
                    {
                        // Conditons for Head Part
                        if (boolHeader == false)
                        {

                            if (P.InnerText.ToLower().Trim().Length > 10)
                            {
                                if (P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && (P.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower().Trim() == "txt" || P.ParagraphProperties.ParagraphStyleId.Val.Value.ToLower().Trim() == "bodya"))
                                {
                                    if (CounterTitle == 0)
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val.Value = "TI";
                                        if (P.NextSibling() != null && P.NextSibling().InnerText != "")
                                        {
                                            var nextPara = P.NextSibling<Paragraph>();
                                            if(nextPara!=null)
                                            {
                                                if (nextPara.ParagraphProperties != null)
                                                {
                                                    if (nextPara.ParagraphProperties.ParagraphStyleId != null && nextPara.ParagraphProperties.ParagraphStyleId.Val != null)
                                                    {
                                                        nextPara.ParagraphProperties.ParagraphStyleId.Val.Value = "Alt-TI";
                                                    }
                                                    else
                                                    {
                                                        nextPara.ParagraphProperties.Append(new ParagraphStyleId { Val = "Alt-TI" });
                                                    }
                                                }
                                                else
                                                {
                                                    nextPara.Append(new ParagraphProperties(new ParagraphStyleId { Val = "Alt-TI" }));
                                                }
                                            }
                                        }
                                        CounterTitle = 1;
                                    }
                                    else if (CounterRRH == 0)
                                    {
                                        P.ParagraphProperties.ParagraphStyleId.Val.Value = "RRH";
                                        CounterRRH = 1;
                                    }
                                    if (CounterTitle == 1 && CounterRRH == 1)
                                    {
                                        boolHeader = true;
                                    }
                                }
                            }

                        }
                    }
                }

                D.Save();
            }
            ReplaceplaceholdersPPS(newDoc);///for remove copyedited tag from document

        }


    }
}
