﻿using DocumentFormat.OpenXml.Packaging;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using System.IO.Packaging;
using OpenXmlPowerTools;
using DocumentFormat.OpenXml.Wordprocessing;
using DocumentFormat.OpenXml;
using System.Xml;
using System.Text.RegularExpressions;
using System.IO;
using System.Configuration;

namespace MultiInstanceJournalCleanup
{
    class AuthorAffiliation
    {
        public static List<string> LstAuthorStyleColl = null;
        public static List<string> LstOfAffNumber = null;  //Developer Name:Priyanka Vishwakarma,Date:22-09-2020 ,Requirement:Create List of Author affiliation use in AU para.
        public static void AuthorAffiliationMarking(string strWordDoc)
        {
            try
            {
                // Added comment
                // Extract Author Pattern Filename from Configuration
                string strAuthorPatternFileName = null;
                strAuthorPatternFileName = ConfigurationManager.AppSettings.Get("AuthorPattern");

                // Read the Reference Pattern Lookup and sort the pattern on length //
                // Read the Reference patterns from the configuration and store in list
                List<string> strAuthorPatterns = new List<string>();
                strAuthorPatterns = GlobalMethods.ReadAndStoreFileValuesInArray(strAuthorPatternFileName);

                GlobalMethods.UpdateReferencePatternIndex(strAuthorPatterns, strAuthorPatternFileName);

                // Update the Reference Pattern Lookup File //

                LstAuthorStyleColl = new List<string>();
                LstAuthorStyleColl.Clear();

                GlobalMethods.strAuthorStyleDB = ConfigurationManager.AppSettings.Get("AuthorStyleDB");

                LstAuthorStyleColl = GlobalMethods.ReadAndStoreFileValuesInArray(GlobalMethods.strAuthorStyleDB);

                checkAuthorAFFLId(strWordDoc); //Developer name:Priyanka Vishwakarma ,Date:13_09_2019 ,Requirement:add dummy superscript for AFFL id in AU paragraph. Integrated by:Vikas sir.


                MergeAuthorElementsIntoOneGroup(strWordDoc, strAuthorPatternFileName);

                // Crosslink Author with Affiliation
                if (GlobalMethods.strClientName.ToLower() == "ufl")  //Developer Name:Priyanka Vishwakarma,Date:22-09-2020,Requirement:Add function for apply AFFL para style without <fn> tag for ufl.
                {
                    LstOfAffNumber = new List<string>();

                    LstOfAffNumber = ApplyAFFLStyleForUFL(strWordDoc, LstOfAffNumber);
                    if (LstOfAffNumber.Count() > 0)
                    {
                        ApplyAFFLUsingAUIDList(strWordDoc, LstOfAffNumber);
                    }
                }

                GenerateCrosslink(strWordDoc);

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }


        private static void GenerateCrosslink(string newDoc)
        {
            try
            {
                List<string> lstAuthorAffIDs = new List<string>();
                lstAuthorAffIDs.Clear();

                using (WordprocessingDocument WPD = WordprocessingDocument
                .Open(newDoc, true))
                {

                    MainDocumentPart MDP = WPD.MainDocumentPart;

                    Document D = MDP.Document;

                    // Go thorugh Author Paragraph and extract all the superscript values 
                    // and store in Array

                    string strAuthorID = null;
                    string strAffID = null;
                    bool bSuperScript = false;


                    foreach (Paragraph P in D.Descendants<Paragraph>().ToList().
                           Where(e => e != null && e.ParagraphProperties != null
                               && e.ParagraphProperties.ParagraphStyleId != null
                               && (e.ParagraphProperties.ParagraphStyleId.Val == "AU" || e.ParagraphProperties.ParagraphStyleId.Val == "AU-LET" || e.ParagraphProperties.ParagraphStyleId.Val == "au-let" || e.ParagraphProperties.ParagraphStyleId.Val == "au-pre"))) //Developer name:priyanka vishwakarma ,Date:27_08_2019 ,Requirement:Apply affnumber for generating aff id in xml . Integrated by:Vikas sir.   ///AU-LET and au-let style added by Karan on 16-10-2018///AU-LET and au-let style added by Karan on 16-10-2018
                    {
                        // Extract superscript values

                        if (P.HasChildren == true)
                        {
                            if (P.Descendants<Run>().Count() > 0)
                            {
                                foreach (Run R in P.Descendants<Run>().ToList())
                                {
                                    if (R.RunProperties != null)
                                    {
                                        if (R.RunProperties.VerticalTextAlignment != null)
                                        {
                                            bSuperScript = false;
                                            if (R.RunProperties.VerticalTextAlignment.Val == "superscript")
                                            {
                                                bSuperScript = true;
                                            }
                                        }
                                    }

                                    strAuthorID = null;
                                    foreach (Text T in R.Descendants<Text>().ToList())
                                    {
                                        if (bSuperScript)
                                        {
                                            bSuperScript = false;
                                            strAuthorID += T.Text.Trim();

                                            if (GlobalMethods.strClientName.ToLower() == "ufl")
                                            {
                                                if (strAuthorID.Contains(","))
                                                {
                                                    // Split the string on comma and seperate the Affiliation ID's
                                                    string[] separators = { "," };
                                                    string[] AffID = strAuthorID.Split(separators, StringSplitOptions.RemoveEmptyEntries);

                                                    if (AffID.Length > 0)
                                                    {
                                                        for (int counter = 0; counter < AffID.Length; counter++)
                                                        {
                                                            if (lstAuthorAffIDs.Contains(AffID[counter]) == false)
                                                            {
                                                                if (AffID[counter].Trim() != "")
                                                                {
                                                                    if (strAuthorID.Trim().Length > 1)
                                                                    {
                                                                        var alltext = strAuthorID.ToCharArray();
                                                                        foreach (var text in alltext)
                                                                        {
                                                                            if (lstAuthorAffIDs.Contains(text.ToString()) == false)
                                                                            {
                                                                                lstAuthorAffIDs.Add(text.ToString());
                                                                            }
                                                                        }

                                                                    }
                                                                    else
                                                                    {
                                                                        if (lstAuthorAffIDs.Contains(AffID[counter].Trim()) == false)
                                                                        {
                                                                            lstAuthorAffIDs.Add(AffID[counter].Trim());      //Priyanka Vishwakarma:Priyanka Vishwakarma ,Date:12-02-2020 ,requirement:Affid Not match because of space in AU paragraph superscript. ,Integrated by:Vikas sir.
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                                else
                                                {



                                                    if (lstAuthorAffIDs.Contains(strAuthorID) == false)
                                                    {
                                                        if (strAuthorID.Trim() != "")
                                                        {
                                                            if (strAuthorID.Trim().Length > 1)
                                                            {
                                                                var alltext = strAuthorID.ToCharArray();
                                                                foreach (var text in alltext)
                                                                {
                                                                    if (lstAuthorAffIDs.Contains(text.ToString()) == false)
                                                                    {
                                                                        lstAuthorAffIDs.Add(text.ToString());
                                                                    }
                                                                }

                                                            }
                                                            else
                                                            {
                                                                if (lstAuthorAffIDs.Contains(strAuthorID.Trim()) == false)
                                                                {

                                                                    lstAuthorAffIDs.Add(strAuthorID.Trim());  //Developer Name:priyanka Vishwakarma ,Date:15_5_2019 ,Requirement:Affnumber comes with space in document ,Integrated By:Vikas sir
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                            else
                                            {
                                                if (strAuthorID.Contains(","))
                                                {
                                                    // Split the string on comma and seperate the Affiliation ID's
                                                    string[] separators = { "," };
                                                    string[] AffID = strAuthorID.Split(separators, StringSplitOptions.RemoveEmptyEntries);

                                                    if (AffID.Length > 0)
                                                    {
                                                        for (int counter = 0; counter < AffID.Length; counter++)
                                                        {
                                                            if (lstAuthorAffIDs.Contains(AffID[counter]) == false)
                                                            {
                                                                lstAuthorAffIDs.Add(AffID[counter].Trim());      //Priyanka Vishwakarma:Priyanka Vishwakarma ,Date:12-02-2020 ,requirement:Affid Not match because of space in AU paragraph superscript. ,Integrated by:Vikas sir.
                                                            }
                                                        }
                                                    }
                                                }
                                                else
                                                {
                                                    if (lstAuthorAffIDs.Contains(strAuthorID) == false)
                                                    {
                                                        lstAuthorAffIDs.Add(strAuthorID.Trim());  //Developer Name:priyanka Vishwakarma ,Date:15_5_2019 ,Requirement:Affnumber comes with space in document ,Integrated By:Vikas sir
                                                    }
                                                }

                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    strAffID = null;
                    foreach (Paragraph P in D.Descendants<Paragraph>().ToList().
                            Where(e => e.ParagraphProperties != null
                                && e.ParagraphProperties.ParagraphStyleId != null
                                && e.ParagraphProperties.ParagraphStyleId.Val == "AFFL"))
                    {
                        if (P.HasChildren == true)
                        {
                            if (P.Descendants<Run>().Count() > 0)
                            {
                                foreach (Run R in P.Descendants<Run>().ToList())
                                {
                                    if (R.RunProperties != null)
                                    {
                                        if (R.RunProperties.VerticalTextAlignment != null)
                                        {
                                            bSuperScript = false;
                                            if (R.RunProperties.VerticalTextAlignment.Val == "superscript")
                                            {
                                                bSuperScript = true;
                                            }
                                        }
                                    }

                                    strAffID = null;
                                    foreach (Text T in R.Descendants<Text>().ToList())
                                    {
                                        if (bSuperScript)
                                        {
                                            bSuperScript = false;
                                            strAffID += T.Text.Trim();  //Developer Name:priyanka Vishwakarma ,Date:15_5_2019 ,Requirement:Affnumber comes with space in document ,Integrated By:Vikas sir

                                            if (lstAuthorAffIDs.Contains(strAffID) || lstAuthorAffIDs.Contains(strAffID + "*"))//////* condition added by vikas for florida job on 14-08-2020
                                            {
                                                if (R.RunProperties != null)
                                                {
                                                    if (R.RunProperties.RunStyle != null)
                                                    {
                                                        R.RunProperties.RunStyle.Remove();
                                                    }
                                                }

                                                // Create a new Run Style for the number

                                                RunStyle rs = new RunStyle();
                                                rs.Val = "affnumber";

                                                R.RunProperties.AppendChild(rs);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }



        //private static void MergeAuthorElementsIntoOneGroup(string newDoc, string RefPatternFile)
        //{
        //    // Read the Reference patterns from the configuration and store in list
        //    List<string> strRefPatterns = new List<string>();
        //    strRefPatterns = GlobalMethods.ReadAndStoreFileValuesInArray(RefPatternFile);

        //    //string strUsedPatternFilename = ConfigurationManager.AppSettings.Get("UsedPattern");
        //    //StreamWriter sw = new StreamWriter(strUsedPatternFilename);

        //    //string strUnStructuredReferencesFilename = ConfigurationManager.AppSettings.Get("UnStructuredReferences");
        //    //StreamWriter sw1 = new StreamWriter(strUnStructuredReferencesFilename);


        //    using (WordprocessingDocument WPD = WordprocessingDocument
        //        .Open(newDoc, true))
        //    {
        //        SimplifyMarkupSettings settings = new SimplifyMarkupSettings
        //        {
        //            //RemoveComments = false,//commented by Karan on 06-08-2018
        //            RemoveContentControls = true,
        //            RemoveEndAndFootNotes = false,
        //            RemoveFieldCodes = true,
        //            RemoveLastRenderedPageBreak = true,
        //            RemovePermissions = true,
        //            RemoveProof = true,
        //            RemoveRsidInfo = true,
        //            RemoveSmartTags = true,
        //            RemoveSoftHyphens = false,
        //            ReplaceTabsWithSpaces = true,
        //        };

        //        MarkupSimplifier.SimplifyMarkup(WPD, settings);

        //        MainDocumentPart MDP = WPD.MainDocumentPart;

        //        Document D = MDP.Document;

        //        bool bParaHasStructuredRef = false;

        //        string strAuthorText = null;

        //        // Search all Paragraphs that is "TOC1 to TOC3" style.
        //        foreach (Paragraph P in D.Descendants<Paragraph>().ToList().
        //            Where(e => e.ParagraphProperties != null
        //                && e.ParagraphProperties.ParagraphStyleId != null
        //                && e.ParagraphProperties.ParagraphStyleId.Val == "AU"))
        //        {
        //            bParaHasStructuredRef = false;

        //            if (P.HasChildren == false)
        //            {
        //                try
        //                {
        //                    P.Remove();
        //                }
        //                catch (Exception ex)
        //                {
        //                    Console.WriteLine(ex.Message);
        //                }
        //            }
        //            else
        //            {
        //                if (P.HasChildren == true)
        //                {
        //                    if (P.Descendants<Run>().Count() > 0)
        //                    {
        //                        List<OpenXmlElement> RList = P.Descendants<OpenXmlElement>().ToList();

        //                        bParaHasStructuredRef = CheckIfParaHasStructuredAuthors(RList);

        //                        if (bParaHasStructuredRef == true)
        //                        {
        //                            bParaHasStructuredRef = false;
        //                            continue;
        //                        }

        //                        // Read the Text from the paragraph if superscript then move next text //

        //                        //bool comma = false;

        //                        foreach (Run R in P.Descendants<Run>().ToList())
        //                        {
        //                            if (R.RunProperties != null)
        //                            {
        //                                if (R.RunProperties.VerticalTextAlignment != null)
        //                                {
        //                                    if (R.RunProperties.VerticalTextAlignment.Val == "superscript")
        //                                    {
        //                                        continue;
        //                                    }
        //                                }
        //                            }
        //                            strAuthorText = null;
        //                            foreach (Text T in R.Descendants<Text>().ToList())
        //                            {

        //                                strAuthorText += T.Text;
        //                            }

        //                            //if (strAuthorText.StartsWith(","))
        //                            //{
        //                            //    comma = true;
        //                            //    strAuthorText = strAuthorText.Replace(",", "");

        //                            //}

        //                            if (strAuthorText == null)
        //                                goto NextRef;

        //                            /// Build the pattern and Groups before searching and creating runs //

        //                            List<string> strRefGroups = new List<string>();
        //                            bool bPatternStart = false;
        //                            string SearchPattern = null;
        //                            int ReplaceGrpCount = 0;
        //                            strRefGroups.Clear();
        //                            int nGrpCounter = 0;
        //                            int nPatternIndex = 0;
        //                            bool bStartsWithSpace = false;
        //                            bool bEndsWithSpace = false;
        //                            string strTmpAuthorText = null;

        //                            strTmpAuthorText = null;
        //                            strTmpAuthorText = strAuthorText;

        //                            for (int i = 0; i < strRefPatterns.Count; i++)
        //                            {
        //                                if (strRefPatterns[i].ToLower().StartsWith("[pattern start]") == true)
        //                                {
        //                                    nPatternIndex++;
        //                                    strRefGroups.Clear();
        //                                    bPatternStart = true;
        //                                    continue;
        //                                }

        //                                if (bPatternStart == true)
        //                                {
        //                                    if (strRefPatterns[i].ToLower().StartsWith("searchpattern:") == true)
        //                                    {
        //                                        SearchPattern = strRefPatterns[i].Replace("SearchPattern:", "");

        //                                        continue;
        //                                    }

        //                                    if (strRefPatterns[i].ToLower().StartsWith("replacegroup:") == true)
        //                                    {
        //                                        string RpGrp = strRefPatterns[i].Replace("ReplaceGroup:", "");
        //                                        ReplaceGrpCount = Convert.ToInt32(RpGrp);
        //                                        continue;
        //                                    }

        //                                    if (strRefPatterns[i].ToLower().StartsWith("group:") == true)
        //                                    {
        //                                        strRefGroups.Add(strRefPatterns[i].Replace("Group:", ""));
        //                                        continue;
        //                                    }
        //                                }

        //                                if (strRefPatterns[i].ToLower().StartsWith("[pattern end]") == true)
        //                                {
        //                                    bPatternStart = false;

        //                                    //SearchPattern

        //                                    if (SearchPattern != null)
        //                                    {
        //                                        strAuthorText = strTmpAuthorText;
        //                                        // Search operation is ready

        //                                        bStartsWithSpace = false;
        //                                        if (strAuthorText.StartsWith(" "))
        //                                        {
        //                                            bStartsWithSpace = true;
        //                                            strAuthorText = strAuthorText.TrimStart();
        //                                        }

        //                                        bEndsWithSpace = false;
        //                                        if (strAuthorText.EndsWith(" "))
        //                                        {
        //                                            bEndsWithSpace = true;
        //                                            strAuthorText = strAuthorText.TrimEnd();
        //                                        }
        //                                        if (ReplaceGrpCount > 0)
        //                                        {
        //                                            if (strRefGroups.Count != ReplaceGrpCount)
        //                                            {
        //                                                strRefGroups.Clear();
        //                                                goto NextRefSearchPattern;
        //                                            }

        //                                            MatchCollection matches = Regex.Matches(strAuthorText, SearchPattern);

        //                                            if (matches.Count == 1)
        //                                            {
        //                                                //sw.WriteLine("Pattern Index: " + nPatternIndex);
        //                                                //sw.WriteLine(strReferenceText);
        //                                                //sw.WriteLine(strRefSearchPattern[nIndex]);
        //                                                //sw.WriteLine("");

        //                                                // Build the complete match string and compare it with the document string to 
        //                                                // check if they are equal else move to next pattern

        //                                                string strMatchText = null;
        //                                                foreach (Match match in matches)
        //                                                {
        //                                                    strMatchText += match.Value;
        //                                                }

        //                                                if (strMatchText != strAuthorText)
        //                                                    goto NextRefSearchPattern;


        //                                                foreach (Match match in matches)
        //                                                {
        //                                                    if ((match.Groups.Count - 1) != ReplaceGrpCount)
        //                                                        goto NextRefSearchPattern;

        //                                                    if (bStartsWithSpace == true)
        //                                                    {
        //                                                        bStartsWithSpace = false;
        //                                                        Run newrun = new Run();
        //                                                        newrun.AppendChild(new Text(" ") { Space = SpaceProcessingModeValues.Preserve });
        //                                                        R.InsertBeforeSelf(newrun);
        //                                                    }

        //                                                    // Extract group info 
        //                                                    int GrpNo = 0;

        //                                                    for (nGrpCounter = 0; nGrpCounter < strRefGroups.Count; nGrpCounter++)
        //                                                    {
        //                                                        string tmpstr = null;
        //                                                        tmpstr = strRefGroups[nGrpCounter];
        //                                                        GrpNo = 0;
        //                                                        GrpNo = nGrpCounter + 1;

        //                                                        if (tmpstr.Contains(":"))
        //                                                        {
        //                                                            // Split the string
        //                                                            string[] separators = { ":" };
        //                                                            string[] strValues = tmpstr.Split(separators, StringSplitOptions.RemoveEmptyEntries);

        //                                                            if (strValues.Length > 0)
        //                                                            {
        //                                                                if (strValues[0] == "space")
        //                                                                {
        //                                                                    Run newrun = new Run();
        //                                                                    newrun.AppendChild(new Text(" ") { Space = SpaceProcessingModeValues.Preserve });
        //                                                                    R.InsertBeforeSelf(newrun);
        //                                                                }
        //                                                                else if (strValues[0] == "blank")
        //                                                                {
        //                                                                    // No action required
        //                                                                }
        //                                                                else if (strValues[0] == "value")
        //                                                                {
        //                                                                    //Run run = P.AppendChild(new Run());
        //                                                                    // Add Text to the Run element.
        //                                                                    Run newrun = new Run();
        //                                                                    newrun.AppendChild(new Text(match.Groups[nGrpCounter + 1].Value));
        //                                                                    R.InsertBeforeSelf(newrun);
        //                                                                }

        //                                                                if (strValues[1] != "") // Style
        //                                                                {
        //                                                                    Run newrun = new Run();
        //                                                                    RunProperties rpr = new RunProperties(new RunStyle() { Val = strValues[1] });
        //                                                                    newrun.AppendChild(rpr);

        //                                                                    newrun.AppendChild(new Text(match.Groups[nGrpCounter + 1].Value));

        //                                                                    R.InsertBeforeSelf(newrun);
        //                                                                }
        //                                                            }
        //                                                        }
        //                                                        else if (tmpstr.Contains("space"))
        //                                                        {
        //                                                            //Run run = P.AppendChild(new Run());
        //                                                            //OpenXmlAttribute openXmlAttribute = new OpenXmlAttribute("space", "xml", "preserve");
        //                                                            // Add Text to the Run element.
        //                                                            Run newrun = new Run();
        //                                                            Text T = new Text(" ") { Space = SpaceProcessingModeValues.Preserve };
        //                                                            //T.SetAttribute(openXmlAttribute);
        //                                                            newrun.AppendChild(T);
        //                                                            R.InsertBeforeSelf(newrun);
        //                                                        }
        //                                                        else if (tmpstr.Contains("blank"))
        //                                                        {
        //                                                        }
        //                                                        else if (tmpstr.Contains("value"))
        //                                                        {
        //                                                            //Run run = P.AppendChild(new Run());
        //                                                            // Add Text to the Run element.
        //                                                            Run newrun = new Run();
        //                                                            newrun.AppendChild(new Text(match.Groups[nGrpCounter + 1].Value));
        //                                                            R.InsertBeforeSelf(newrun);
        //                                                        }
        //                                                        else
        //                                                        {
        //                                                            Run newrun = new Run();
        //                                                            //Run run = new Run(new RunProperties(new RunStyle() { Val = tmpstr }));
        //                                                            RunProperties rpr = new RunProperties(new RunStyle() { Val = tmpstr });
        //                                                            newrun.AppendChild(rpr);
        //                                                            //P.AppendChild(run);
        //                                                            // Add Text to the Run element.
        //                                                            newrun.AppendChild(new Text(match.Groups[nGrpCounter + 1].Value));
        //                                                            R.InsertBeforeSelf(newrun);
        //                                                        }
        //                                                    }
        //                                                }
        //                                                if (bEndsWithSpace == true)
        //                                                {
        //                                                    bEndsWithSpace = false;
        //                                                    Run newrun = new Run();
        //                                                    newrun.AppendChild(new Text(" ") { Space = SpaceProcessingModeValues.Preserve });
        //                                                    R.InsertBeforeSelf(newrun);
        //                                                }

        //                                                //R.InsertBeforeSelf(newrun);
        //                                                R.Remove();

        //                                                goto NextRef;
        //                                            }
        //                                        }
        //                                    }
        //                                }

        //                                NextRefSearchPattern:
        //                                {
        //                                    continue;
        //                                }
        //                            }

        //                            strRefGroups.Clear();

        //                            //sw1.WriteLine(strReferenceText);
        //                            //sw1.WriteLine("");

        //                            NextRef:
        //                            {
        //                                continue;
        //                            }
        //                        }
        //                    }
        //                }
        //            }
        //            //sw.Close();
        //            //sw1.Close();
        //            D.Save();
        //        }
        //    }
        //}

        private static void MergeAuthorElementsIntoOneGroup(string newDoc, string RefPatternFile)
        {
            // Read the Reference patterns from the configuration and store in list
            List<string> strRefPatterns = new List<string>();
            strRefPatterns = GlobalMethods.ReadAndStoreFileValuesInArray(RefPatternFile);

            //string strUsedPatternFilename = ConfigurationManager.AppSettings.Get("UsedPattern");
            //StreamWriter sw = new StreamWriter(strUsedPatternFilename);

            //string strUnStructuredReferencesFilename = ConfigurationManager.AppSettings.Get("UnStructuredReferences");
            //StreamWriter sw1 = new StreamWriter(strUnStructuredReferencesFilename);


            using (WordprocessingDocument WPD = WordprocessingDocument
                .Open(newDoc, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    //RemoveComments = false,//commented by Karan on 06-08-2018
                    RemoveContentControls = true,
                    RemoveEndAndFootNotes = false,
                    RemoveFieldCodes = true,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = false,//Developer name :Priyanka Vishwakarma. Date:29_5_2019, Requirement:it removes the indentation from the nested list  ,Integrated By:Vikas sir. 
                };

                MarkupSimplifier.SimplifyMarkup(WPD, settings);

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                bool bParaHasStructuredRef = false;
                bool commentlistFound = false;//Added by Priyanka on 11_4_2019 for commented text
                bool commentAdded = false;   //Developer name :Priyanka Vishwakarma ,Date:29_11_2019 ,Requirement:Add Author comment at end if All Author names are selected in comment ,Integrated by :Vikas sir 
                string strAuthorText = null;
                Dictionary<int, string> commentRangeStartText = new Dictionary<int, string>();  //Added by Priyanka on 11_4_2019 for commented text added into dictionary 
                Dictionary<int, string> commentRangeEndText = new Dictionary<int, string>();//Added by Priyanka on 11_4_2019 for commented text added into dictionary 



                // Search all Paragraphs that is "TOC1 to TOC3" style.
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().
                    Where(e => e.ParagraphProperties != null
                        && e.ParagraphProperties.ParagraphStyleId != null
                        && e.ParagraphProperties.ParagraphStyleId.Val == "AU"))
                {

                    //Added on 11_4_2019 by priyanka for list for CommentRangeStart and CommentRangeEnd
                    foreach (var PE in P.Descendants().ToList())
                    {
                        if (PE.XName == W.commentRangeStart)
                        {
                            commentRangeStartText.Add(Convert.ToInt16(((DocumentFormat.OpenXml.Wordprocessing.MarkupRangeType)PE).Id.InnerText), PE.NextSibling().InnerText.Trim());
                            commentlistFound = true;
                        }

                    }

                    //-----------------------End by priyanka on 11_4_2019------------------------------------------------
                    bParaHasStructuredRef = false;

                    if (P.HasChildren == false)
                    {
                        try
                        {
                            P.Remove();
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(ex.Message);
                        }
                    }
                    else
                    {
                        if (P.HasChildren == true)
                        {
                            if (P.Descendants<Run>().Count() > 0)
                            {
                                List<OpenXmlElement> RList = P.Descendants<OpenXmlElement>().ToList();

                                bParaHasStructuredRef = CheckIfParaHasStructuredAuthors(RList);

                                if (bParaHasStructuredRef == true)
                                {
                                    bParaHasStructuredRef = false;
                                    continue;
                                }

                                // Read the Text from the paragraph if superscript then move next text //

                                //bool comma = false;
                                strAuthorText = null; //Added on 11_4_2019 by priyanka 
                                Run PrevRun = null;   //Added on 11_4_2019 by priyanka 
                                List<Run> runlist = new List<Run>(); //Added on 11_4_2019 by Priyanka for create list of run 

                                foreach (Run R in P.Descendants<Run>().ToList())
                                {
                                    if (R.RunProperties != null)
                                    {
                                        if (R.RunProperties.VerticalTextAlignment != null)
                                        {
                                            if (R.RunProperties.VerticalTextAlignment.Val == "superscript")
                                            {
                                                if (strAuthorText == null)
                                                    continue;

                                                // Call for Author Marking method and pass the author string //
                                                if (PrevRun != null && runlist.Count() > 0)
                                                {
                                                    string newStrAuthorText="";
                                                    if (GlobalMethods.strClientName.ToLower()=="sage")  //Developer name:Priyanka Vishwakarma,Date:14-10-2020,Requirement:Avoid to remove Punctuation from AU paragraph
                                                    {
                                                        newStrAuthorText = strAuthorText.Replace("  "," ").Replace("                         "," ").Trim();
                                                    }
                                                    else
                                                    {
                                                         newStrAuthorText = strAuthorText.Replace(",", "").Trim();   //added on 18_4_2019 by priyanka for strAuthor text come with , 
                                                    }
                                                    //string newStrAuthorText = strAuthorText.Replace(",", "").Trim();   //added on 18_4_2019 by priyanka for strAuthor text come with , 
                                                    
                                                    if (newStrAuthorText.Trim() == "and")
                                                    {
                                                        continue;
                                                    }

                                                    MarkAuthor(newStrAuthorText, strRefPatterns, PrevRun, runlist, commentRangeStartText);
                                                }


                                                runlist.Clear();
                                                strAuthorText = null;
                                                continue;
                                            }
                                        }
                                    }


                                    foreach (Text T in R.Descendants<Text>().ToList())
                                    {
                                        strAuthorText += T.Text;
                                    }

                                    PrevRun = R;
                                    runlist.Add(R);  ////Added on 11_4_2019 by Priyanka for create list of run 


                                    //if (strAuthorText.StartsWith(","))
                                    //{
                                    //    comma = true;
                                    //    strAuthorText = strAuthorText.Replace(",", "");

                                    //}

                                    if (strAuthorText == null)
                                        continue;

                                    #region for marking au character style comment by priyanka
                                    //    /// Build the pattern and Groups before searching and creating runs //

                                    //    List<string> strRefGroups = new List<string>();
                                    //    bool bPatternStart = false;
                                    //    string SearchPattern = null;
                                    //    int ReplaceGrpCount = 0;
                                    //    strRefGroups.Clear();
                                    //    int nGrpCounter = 0;
                                    //    int nPatternIndex = 0;
                                    //    bool bStartsWithSpace = false;
                                    //    bool bEndsWithSpace = false;
                                    //    string strTmpAuthorText = null;

                                    //    strTmpAuthorText = null;
                                    //    strTmpAuthorText = strAuthorText;

                                    //    for (int i = 0; i < strRefPatterns.Count; i++)
                                    //    {
                                    //        if (strRefPatterns[i].ToLower().StartsWith("[pattern start]") == true)
                                    //        {
                                    //            nPatternIndex++;
                                    //            strRefGroups.Clear();
                                    //            bPatternStart = true;
                                    //            continue;
                                    //        }

                                    //        if (bPatternStart == true)
                                    //        {
                                    //            if (strRefPatterns[i].ToLower().StartsWith("searchpattern:") == true)
                                    //            {
                                    //                SearchPattern = strRefPatterns[i].Replace("SearchPattern:", "");

                                    //                continue;
                                    //            }

                                    //            if (strRefPatterns[i].ToLower().StartsWith("replacegroup:") == true)
                                    //            {
                                    //                string RpGrp = strRefPatterns[i].Replace("ReplaceGroup:", "");
                                    //                ReplaceGrpCount = Convert.ToInt32(RpGrp);
                                    //                continue;
                                    //            }

                                    //            if (strRefPatterns[i].ToLower().StartsWith("group:") == true)
                                    //            {
                                    //                strRefGroups.Add(strRefPatterns[i].Replace("Group:", ""));
                                    //                continue;
                                    //            }
                                    //        }

                                    //        if (strRefPatterns[i].ToLower().StartsWith("[pattern end]") == true)
                                    //        {
                                    //            bPatternStart = false;

                                    //            //SearchPattern

                                    //            if (SearchPattern != null)
                                    //            {
                                    //                strAuthorText = strTmpAuthorText;
                                    //                // Search operation is ready

                                    //                bStartsWithSpace = false;
                                    //                if (strAuthorText.StartsWith(" "))
                                    //                {
                                    //                    bStartsWithSpace = true;
                                    //                    strAuthorText = strAuthorText.TrimStart();
                                    //                }

                                    //                bEndsWithSpace = false;
                                    //                if (strAuthorText.EndsWith(" "))
                                    //                {
                                    //                    bEndsWithSpace = true;
                                    //                    strAuthorText = strAuthorText.TrimEnd();
                                    //                }
                                    //                if (ReplaceGrpCount > 0)
                                    //                {
                                    //                    if (strRefGroups.Count != ReplaceGrpCount)
                                    //                    {
                                    //                        strRefGroups.Clear();
                                    //                        goto NextRefSearchPattern;
                                    //                    }

                                    //                    MatchCollection matches = Regex.Matches(strAuthorText, SearchPattern);

                                    //                    if (matches.Count == 1)
                                    //                    {
                                    //                        //sw.WriteLine("Pattern Index: " + nPatternIndex);
                                    //                        //sw.WriteLine(strReferenceText);
                                    //                        //sw.WriteLine(strRefSearchPattern[nIndex]);
                                    //                        //sw.WriteLine("");

                                    //                        // Build the complete match string and compare it with the document string to 
                                    //                        // check if they are equal else move to next pattern

                                    //                        string strMatchText = null;
                                    //                        foreach (Match match in matches)
                                    //                        {
                                    //                            strMatchText += match.Value;
                                    //                        }

                                    //                        if (strMatchText != strAuthorText)
                                    //                            goto NextRefSearchPattern;


                                    //                        foreach (Match match in matches)
                                    //                        {
                                    //                            if ((match.Groups.Count - 1) != ReplaceGrpCount)
                                    //                                goto NextRefSearchPattern;

                                    //                            if (bStartsWithSpace == true)
                                    //                            {
                                    //                                bStartsWithSpace = false;
                                    //                                Run newrun = new Run();
                                    //                                newrun.AppendChild(new Text(" ") { Space = SpaceProcessingModeValues.Preserve });
                                    //                                R.InsertBeforeSelf(newrun);
                                    //                            }

                                    //                            // Extract group info 
                                    //                            int GrpNo = 0;

                                    //                            for (nGrpCounter = 0; nGrpCounter < strRefGroups.Count; nGrpCounter++)
                                    //                            {
                                    //                                string tmpstr = null;
                                    //                                tmpstr = strRefGroups[nGrpCounter];
                                    //                                GrpNo = 0;
                                    //                                GrpNo = nGrpCounter + 1;

                                    //                                if (tmpstr.Contains(":"))
                                    //                                {
                                    //                                    // Split the string
                                    //                                    string[] separators = { ":" };
                                    //                                    string[] strValues = tmpstr.Split(separators, StringSplitOptions.RemoveEmptyEntries);

                                    //                                    if (strValues.Length > 0)
                                    //                                    {
                                    //                                        if (strValues[0] == "space")
                                    //                                        {
                                    //                                            Run newrun = new Run();
                                    //                                            newrun.AppendChild(new Text(" ") { Space = SpaceProcessingModeValues.Preserve });
                                    //                                            R.InsertBeforeSelf(newrun);
                                    //                                        }
                                    //                                        else if (strValues[0] == "blank")
                                    //                                        {
                                    //                                            // No action required
                                    //                                        }
                                    //                                        else if (strValues[0] == "value")
                                    //                                        {
                                    //                                            //Run run = P.AppendChild(new Run());
                                    //                                            // Add Text to the Run element.
                                    //                                            Run newrun = new Run();
                                    //                                            newrun.AppendChild(new Text(match.Groups[nGrpCounter + 1].Value));
                                    //                                            R.InsertBeforeSelf(newrun);
                                    //                                        }

                                    //                                        if (strValues[1] != "") // Style
                                    //                                        {
                                    //                                            Run newrun = new Run();
                                    //                                            RunProperties rpr = new RunProperties(new RunStyle() { Val = strValues[1] });
                                    //                                            newrun.AppendChild(rpr);

                                    //                                            newrun.AppendChild(new Text(match.Groups[nGrpCounter + 1].Value));

                                    //                                            R.InsertBeforeSelf(newrun);
                                    //                                        }
                                    //                                    }
                                    //                                }
                                    //                                else if (tmpstr.Contains("space"))
                                    //                                {
                                    //                                    //Run run = P.AppendChild(new Run());
                                    //                                    //OpenXmlAttribute openXmlAttribute = new OpenXmlAttribute("space", "xml", "preserve");
                                    //                                    // Add Text to the Run element.
                                    //                                    Run newrun = new Run();
                                    //                                    Text T = new Text(" ") { Space = SpaceProcessingModeValues.Preserve };
                                    //                                    //T.SetAttribute(openXmlAttribute);
                                    //                                    newrun.AppendChild(T);
                                    //                                    R.InsertBeforeSelf(newrun);
                                    //                                }
                                    //                                else if (tmpstr.Contains("blank"))
                                    //                                {
                                    //                                }
                                    //                                else if (tmpstr.Contains("value"))
                                    //                                {
                                    //                                    //Run run = P.AppendChild(new Run());
                                    //                                    // Add Text to the Run element.
                                    //                                    Run newrun = new Run();
                                    //                                    newrun.AppendChild(new Text(match.Groups[nGrpCounter + 1].Value));
                                    //                                    R.InsertBeforeSelf(newrun);
                                    //                                }
                                    //                                else
                                    //                                {
                                    //                                    Run newrun = new Run();
                                    //                                    //Run run = new Run(new RunProperties(new RunStyle() { Val = tmpstr }));
                                    //                                    RunProperties rpr = new RunProperties(new RunStyle() { Val = tmpstr });
                                    //                                    newrun.AppendChild(rpr);
                                    //                                    //P.AppendChild(run);
                                    //                                    // Add Text to the Run element.
                                    //                                    newrun.AppendChild(new Text(match.Groups[nGrpCounter + 1].Value));
                                    //                                    R.InsertBeforeSelf(newrun);
                                    //                                }
                                    //                            }
                                    //                        }
                                    //                        if (bEndsWithSpace == true)
                                    //                        {
                                    //                            bEndsWithSpace = false;
                                    //                            Run newrun = new Run();
                                    //                            newrun.AppendChild(new Text(" ") { Space = SpaceProcessingModeValues.Preserve });
                                    //                            R.InsertBeforeSelf(newrun);
                                    //                        }

                                    //                        //R.InsertBeforeSelf(newrun);
                                    //                        R.Remove();

                                    //                        goto NextRef;
                                    //                    }
                                    //                }
                                    //            }
                                    //        }

                                    //        NextRefSearchPattern:
                                    //        {
                                    //            continue;
                                    //        }
                                    //    }

                                    //    strRefGroups.Clear();

                                    ////sw1.WriteLine(strReferenceText);
                                    ////sw1.WriteLine("");

                                    //NextRef:
                                    //    {
                                    //        continue;
                                    //    }

                                    #endregion
                                }
                            }
                        }
                    }
                    //--------------------Added by Priyanka on 11_4_2019----for Marking comment------------------
                    if (commentlistFound)
                    {
                        //check For comment exist.....
                        string AuthorCommentText = null;
                        string AuthorSigleText = null;
                        int runCount = 0;

                        foreach (CommentRangeStart cStart in P.Descendants<CommentRangeStart>().ToList())
                        {
                            cStart.Remove();
                        }
                        foreach (CommentRangeEnd cEnd in P.Descendants<CommentRangeEnd>().ToList())
                        {
                            cEnd.Remove();
                        }
                        foreach (CommentReference cRef in P.Descendants<CommentReference>().ToList())
                        {
                            cRef.Remove();
                        }

                        foreach (Run R in P.Descendants<Run>().ToList())
                        {
                            if (R.RunProperties != null && R.RunProperties.VerticalTextAlignment != null && R.RunProperties.VerticalTextAlignment.Val == "superscript")
                            {
                                foreach (Text T in R.Descendants<Text>().ToList())
                                {
                                    runCount = 0;
                                    AuthorCommentText = null;
                                    AuthorSigleText = null;

                                }

                                //if (R.RunProperties.VerticalTextAlignment != null)
                                //{
                                //    if (R.RunProperties.VerticalTextAlignment.Val == "superscript")
                                //    {
                                //        AuthorCommentText = null;
                                //    }
                                //}
                            }
                            else
                            {
                                foreach (Text T in R.Descendants<Text>().ToList())
                                {

                                    commentAdded = false;   //Developer name :Priyanka Vishwakarma ,Date:29_11_2019 ,Requirement:Add Author comment at end if All Author names are selected in comment ,Integrated by :Vikas sir 
                                    runCount++;
                                    AuthorCommentText = AuthorCommentText + T.Text;
                                    AuthorSigleText = T.Text;

                                    if (commentRangeStartText.ContainsValue(AuthorCommentText.Trim()) || commentRangeStartText.Any(kvp => AuthorCommentText.StartsWith(kvp.Value))) //Developer name:Priyanka Vishwakarma, Date:14_09_2019 ,Requirement:when author comment not exactly match with commentText ,Integrated by:Vikas sir
                                    {
                                        int AuthorNameLenght = AuthorCommentText.Trim().Split(' ').Count();

                                        if (AuthorCommentText.Trim().Contains(" ") && !AuthorCommentText.Trim().Contains("."))    //Mathew Joseph  contains Space 
                                        {
                                            if (AuthorNameLenght == 2)  //commented on fname and middlename
                                            {

                                                var key = commentRangeStartText.FirstOrDefault(x => x.Value == AuthorCommentText.Trim()).Key;
                                                //Developer name:Priyanka Vishwakarma, Date:14_09_2019 ,Requirement:when author comment not exactly match with commentText ,Integrated by:Vikas sir
                                                if (key == 0)
                                                {
                                                    foreach (var val in commentRangeStartText)
                                                    {

                                                        if (AuthorCommentText.StartsWith(val.Value))
                                                        {
                                                            key = val.Key;
                                                        }

                                                    }
                                                }
                                                if (!P.Descendants<CommentRangeStart>().ToList().Any(x => x.GetAttributes().Any(l => l.LocalName == "id" && l.Value == key.ToString())))
                                                {
                                                    R.RunProperties.AppendChild(new Bold());
                                                    R.PreviousSibling().PreviousSibling().InsertBeforeSelf(new CommentRangeStart() { Id = key.ToString() });
                                                    RunProperties rpr = new RunProperties(new RunStyle() { Val = "CommentReference" });
                                                    R.InsertAfterSelf(new Run(new CommentReference() { Id = key.ToString() })).Append(rpr);
                                                    R.InsertAfterSelf(new CommentRangeEnd() { Id = key.ToString() });
                                                    new Run(new CommentReference() { Id = key.ToString() });
                                                    commentAdded = true;  //Developer name :Priyanka Vishwakarma ,Date:29_11_2019 ,Requirement:Add Author comment at end if All Author names are selected in comment ,Integrated by :Vikas sir
                                                }
                                            }
                                            else if (AuthorNameLenght == 3)  //commeted on fname ,middlename and surname
                                            {
                                                var key = commentRangeStartText.FirstOrDefault(x => x.Value == AuthorCommentText.Trim()).Key;
                                                //Developer name:Priyanka Vishwakarma, Date:14_09_2019 ,Requirement:when author comment not exactly match with commentText ,Integrated by:Vikas sir
                                                if (key == 0)
                                                {
                                                    foreach (var val in commentRangeStartText)
                                                    {

                                                        if (AuthorCommentText.StartsWith(val.Value))
                                                        {
                                                            key = val.Key;
                                                        }

                                                    }
                                                }
                                                if (!P.Descendants<CommentRangeStart>().ToList().Any(x => x.GetAttributes().Any(l => l.LocalName == "id" && l.Value == key.ToString())))
                                                {
                                                    R.RunProperties.AppendChild(new Bold());
                                                    R.PreviousSibling().PreviousSibling().PreviousSibling().PreviousSibling().InsertBeforeSelf(new CommentRangeStart() { Id = key.ToString() });
                                                    RunProperties rpr = new RunProperties(new RunStyle() { Val = "CommentReference" });
                                                    R.InsertAfterSelf(new Run(new CommentReference() { Id = key.ToString() })).Append(rpr);
                                                    R.InsertAfterSelf(new CommentRangeEnd() { Id = key.ToString() });
                                                    new Run(new CommentReference() { Id = key.ToString() });
                                                    commentAdded = true;  //Developer name :Priyanka Vishwakarma ,Date:29_11_2019 ,Requirement:Add Author comment at end if All Author names are selected in comment ,Integrated by :Vikas sir
                                                }
                                            }

                                        }
                                        else if (AuthorCommentText.Trim().Contains(".") && !AuthorCommentText.Trim().Contains(" "))   //A.R. does not contains 
                                        {
                                            var key = commentRangeStartText.FirstOrDefault(x => x.Value == AuthorCommentText.Trim()).Key;
                                            //Developer name:Priyanka Vishwakarma, Date:14_09_2019 ,Requirement:when author comment not exactly match with commentText ,Integrated by:Vikas sir
                                            if (key == 0)
                                            {
                                                foreach (var val in commentRangeStartText)
                                                {

                                                    if (AuthorCommentText.StartsWith(val.Value))
                                                    {
                                                        key = val.Key;
                                                    }

                                                }
                                            }
                                            if (!P.Descendants<CommentRangeStart>().ToList().Any(x => x.GetAttributes().Any(l => l.LocalName == "id" && l.Value == key.ToString())))
                                            {
                                                R.RunProperties.AppendChild(new Bold());
                                                R.PreviousSibling().InsertBeforeSelf(new CommentRangeStart() { Id = key.ToString() });
                                                RunProperties rpr = new RunProperties(new RunStyle() { Val = "CommentReference" });
                                                R.InsertAfterSelf(new Run(new CommentReference() { Id = key.ToString() })).Append(rpr);
                                                R.InsertAfterSelf(new CommentRangeEnd() { Id = key.ToString() });
                                                new Run(new CommentReference() { Id = key.ToString() });
                                                commentAdded = true;  //Developer name :Priyanka Vishwakarma ,Date:29_11_2019 ,Requirement:Add Author comment at end if All Author names are selected in comment ,Integrated by :Vikas sir
                                            }
                                        }
                                        else if (AuthorCommentText.Trim().Contains(".") && AuthorCommentText.Trim().Contains(" ")) //M. S.
                                        {
                                            if (AuthorNameLenght == 2)  //commented on fname and middlename
                                            {
                                                var key = commentRangeStartText.FirstOrDefault(x => x.Value == AuthorCommentText.Trim()).Key;
                                                //Developer name:Priyanka Vishwakarma, Date:14_09_2019 ,Requirement:when author comment not exactly match with commentText ,Integrated by:Vikas sir
                                                if (key == 0)
                                                {
                                                    foreach (var val in commentRangeStartText)
                                                    {

                                                        if (AuthorCommentText.StartsWith(val.Value))
                                                        {
                                                            key = val.Key;
                                                        }

                                                    }
                                                }
                                                if (!P.Descendants<CommentRangeStart>().ToList().Any(x => x.GetAttributes().Any(l => l.LocalName == "id" && l.Value == key.ToString())))
                                                {
                                                    R.RunProperties.AppendChild(new Bold());
                                                    R.PreviousSibling().PreviousSibling().InsertBeforeSelf(new CommentRangeStart() { Id = key.ToString() });
                                                    RunProperties rpr = new RunProperties(new RunStyle() { Val = "CommentReference" });
                                                    R.InsertAfterSelf(new Run(new CommentReference() { Id = key.ToString() })).Append(rpr);
                                                    R.InsertAfterSelf(new CommentRangeEnd() { Id = key.ToString() });
                                                    new Run(new CommentReference() { Id = key.ToString() });
                                                    commentAdded = true;  //Developer name :Priyanka Vishwakarma ,Date:29_11_2019 ,Requirement:Add Author comment at end if All Author names are selected in comment ,Integrated by :Vikas sir
                                                }
                                            }
                                            else if (AuthorNameLenght == 3)  //commeted on fname ,middlename and surname
                                            {
                                                var key = commentRangeStartText.FirstOrDefault(x => x.Value == AuthorCommentText.Trim()).Key;
                                                //Developer name:Priyanka Vishwakarma, Date:14_09_2019 ,Requirement:when author comment not exactly match with commentText ,Integrated by:Vikas sir
                                                if (key == 0)
                                                {
                                                    foreach (var val in commentRangeStartText)
                                                    {

                                                        if (AuthorCommentText.StartsWith(val.Value))
                                                        {
                                                            key = val.Key;
                                                        }

                                                    }
                                                }
                                                if (!P.Descendants<CommentRangeStart>().ToList().Any(x => x.GetAttributes().Any(l => l.LocalName == "id" && l.Value == key.ToString())))
                                                {
                                                    R.RunProperties.AppendChild(new Bold());
                                                    R.PreviousSibling().PreviousSibling().PreviousSibling().PreviousSibling().InsertBeforeSelf(new CommentRangeStart() { Id = key.ToString() });
                                                    RunProperties rpr = new RunProperties(new RunStyle() { Val = "CommentReference" });
                                                    R.InsertAfterSelf(new Run(new CommentReference() { Id = key.ToString() })).Append(rpr);
                                                    R.InsertAfterSelf(new CommentRangeEnd() { Id = key.ToString() });
                                                    new Run(new CommentReference() { Id = key.ToString() });
                                                    commentAdded = true;  //Developer name :Priyanka Vishwakarma ,Date:29_11_2019 ,Requirement:Add Author comment at end if All Author names are selected in comment ,Integrated by :Vikas sir
                                                }

                                            }



                                        }
                                        else   //commeted on fname only
                                        {
                                            var key = commentRangeStartText.FirstOrDefault(x => x.Value == AuthorSigleText.Trim()).Key;
                                            //Developer name:Priyanka Vishwakarma, Date:14_09_2019 ,Requirement:when author comment not exactly match with commentText ,Integrated by:Vikas sir
                                            if (key == 0)
                                            {
                                                foreach (var val in commentRangeStartText)
                                                {

                                                    if (AuthorCommentText.StartsWith(val.Value))
                                                    {
                                                        key = val.Key;
                                                    }

                                                }
                                            }
                                            if (!P.Descendants<CommentRangeStart>().ToList().Any(x => x.GetAttributes().Any(l => l.LocalName == "id" && l.Value == key.ToString())))
                                            {
                                                R.RunProperties.AppendChild(new Bold());
                                                R.InsertBeforeSelf(new CommentRangeStart() { Id = key.ToString() });
                                                RunProperties rpr = new RunProperties(new RunStyle() { Val = "CommentReference" });
                                                R.InsertAfterSelf(new Run(new CommentReference() { Id = key.ToString() })).Append(rpr);
                                                R.InsertAfterSelf(new CommentRangeEnd() { Id = key.ToString() });
                                                new Run(new CommentReference() { Id = key.ToString() });
                                                commentAdded = true;  //Developer name :Priyanka Vishwakarma ,Date:29_11_2019 ,Requirement:Add Author comment at end if All Author names are selected in comment ,Integrated by :Vikas sir
                                            }

                                        }
                                        AuthorCommentText = null;
                                    }
                                    else if (commentRangeStartText.ContainsValue(AuthorSigleText.Trim())) //for single comment
                                    {
                                        var key = commentRangeStartText.FirstOrDefault(x => x.Value == AuthorSigleText.Trim()).Key;
                                        if (!P.Descendants<CommentRangeStart>().ToList().Any(x => x.GetAttributes().Any(l => l.LocalName == "id" && l.Value == key.ToString())))
                                        {
                                            R.RunProperties.AppendChild(new Bold());
                                            R.InsertBeforeSelf(new CommentRangeStart() { Id = key.ToString() });
                                            RunProperties rpr = new RunProperties(new RunStyle() { Val = "CommentReference" });

                                            R.InsertAfterSelf(new Run(new CommentReference() { Id = key.ToString() })).Append(rpr);
                                            R.InsertAfterSelf(new CommentRangeEnd() { Id = key.ToString() });
                                            new Run(new CommentReference() { Id = key.ToString() });
                                            commentAdded = true;  //Developer name :Priyanka Vishwakarma ,Date:29_11_2019 ,Requirement:Add Author comment at end if All Author names are selected in comment ,Integrated by :Vikas sir
                                        }
                                    }
                                    AuthorSigleText = null;
                                }
                            }

                        }
                    }
                    ////Developer name :Priyanka Vishwakarma ,Date:29_11_2019 ,Requirement:Add Author comment at end if All Author names are selected in comment ,Integrated by :Vikas sir 
                    if (commentAdded != true && commentRangeStartText.Count() > 0)
                    {
                        foreach (var k in commentRangeStartText.Keys)
                        {
                            if (!P.Descendants<CommentRangeStart>().ToList().Any(x => x.GetAttributes().Any(l => l.LocalName == "id" && l.Value == k.ToString())))
                            {
                                Run r = new Run();
                                CommentReference cRef = new CommentReference() { Id = k.ToString() };
                                r.AppendChild(cRef);
                                P.AppendChild(r);
                                commentAdded = false;
                            }
                        }


                    }
                    //---------------End-----------------------------------------------
                    //-----------------------end by Priyanka on 11_4_2019-----------------------------------


                    //sw.Close();
                    //sw1.Close();
                    D.Save();
                }
            }
        }
        #region for marking of AU character style added by priyanka on 



        private static void MarkAuthor(string strAuthorText, List<string> strRefPatterns, Run R, List<Run> listRun, Dictionary<int, string> commentRangeStartText)
        {
            try
            {
                /// Build the pattern and Groups before searching and creating runs //

                List<string> strRefGroups = new List<string>();
                bool bPatternStart = false;
                string SearchPattern = null;
                int ReplaceGrpCount = 0;
                strRefGroups.Clear();
                int nGrpCounter = 0;
                int nPatternIndex = 0;
                bool bStartsWithSpace = false;
                bool bEndsWithSpace = false;
                string strTmpAuthorText = null;

                strTmpAuthorText = null;
                //strTmpAuthorText = strAuthorText;
                if (strAuthorText.Trim().StartsWith("and"))
                {
                    strAuthorText = strAuthorText.Replace("and ", "").Trim();
                    Run newrun1 = new Run();
                    Text T = new Text(" ") { Space = SpaceProcessingModeValues.Preserve };
                    newrun1.AppendChild(T);
                    R.InsertBeforeSelf(newrun1);
                    Run newrun = new Run();
                    RunProperties rpr = new RunProperties();
                    rpr.AppendChild(new Bold());
                    newrun.AppendChild(rpr);
                    newrun.AppendChild(new Text("and"));
                    R.InsertBeforeSelf(newrun);
                    Run newrun2 = new Run();
                    Text T1 = new Text(" ") { Space = SpaceProcessingModeValues.Preserve };
                    newrun2.AppendChild(T1);
                    R.InsertBeforeSelf(newrun2);
                }
                strTmpAuthorText = strAuthorText;

                for (int i = 0; i < strRefPatterns.Count; i++)
                {
                    if (strRefPatterns[i].ToLower().StartsWith("[pattern start]") == true)
                    {
                        nPatternIndex++;
                        strRefGroups.Clear();
                        bPatternStart = true;
                        continue;
                    }

                    if (bPatternStart == true)
                    {
                        if (strRefPatterns[i].ToLower().StartsWith("searchpattern:") == true)
                        {
                            SearchPattern = strRefPatterns[i].Replace("SearchPattern:", "");

                            continue;
                        }

                        if (strRefPatterns[i].ToLower().StartsWith("replacegroup:") == true)
                        {
                            string RpGrp = strRefPatterns[i].Replace("ReplaceGroup:", "");
                            ReplaceGrpCount = Convert.ToInt32(RpGrp);
                            continue;
                        }

                        if (strRefPatterns[i].ToLower().StartsWith("group:") == true)
                        {
                            strRefGroups.Add(strRefPatterns[i].Replace("Group:", ""));
                            continue;
                        }
                    }

                    if (strRefPatterns[i].ToLower().StartsWith("[pattern end]") == true)
                    {
                        bPatternStart = false;

                        //SearchPattern

                        if (SearchPattern != null)
                        {
                            strAuthorText = strTmpAuthorText;
                            // Search operation is ready

                            bStartsWithSpace = false;
                            if (strAuthorText.StartsWith(" "))
                            {
                                bStartsWithSpace = true;
                                strAuthorText = strAuthorText.TrimStart();
                            }

                            bEndsWithSpace = false;
                            if (strAuthorText.EndsWith(" "))
                            {
                                bEndsWithSpace = true;
                                strAuthorText = strAuthorText.TrimEnd();
                            }
                            if (ReplaceGrpCount > 0)
                            {
                                if (strRefGroups.Count != ReplaceGrpCount)
                                {
                                    strRefGroups.Clear();
                                    goto NextRefSearchPattern;
                                }

                                MatchCollection matches = Regex.Matches(strAuthorText, SearchPattern);

                                if (matches.Count == 1)
                                {

                                    if (matches[0].Value.ToString().Trim() != strAuthorText.Trim())   //Developer name:Priyanka Vishwakarma ,Date:06-02-2020,Requirement:Matched text should be same as input text ,Integrated by:Vikas sir.
                                    {
                                        goto NextRefSearchPattern;
                                    }
                                    //sw.WriteLine("Pattern Index: " + nPatternIndex);
                                    //sw.WriteLine(strReferenceText);
                                    //sw.WriteLine(strRefSearchPattern[nIndex]);
                                    //sw.WriteLine("");

                                    // Build the complete match string and compare it with the document string to 
                                    // check if they are equal else move to next pattern

                                    string strMatchText = null;
                                    foreach (Match match in matches)
                                    {
                                        strMatchText += match.Value;
                                    }

                                    if (strMatchText != strAuthorText)
                                        goto NextRefSearchPattern;


                                    foreach (Match match in matches)
                                    {
                                        if ((match.Groups.Count - 1) != ReplaceGrpCount)
                                            goto NextRefSearchPattern;

                                        if (bStartsWithSpace == true)
                                        {
                                            bStartsWithSpace = false;
                                            Run newrun = new Run();
                                            newrun.AppendChild(new Text(" ") { Space = SpaceProcessingModeValues.Preserve });
                                            R.InsertBeforeSelf(newrun);
                                        }

                                        // Extract group info 
                                        int GrpNo = 0;

                                        for (nGrpCounter = 0; nGrpCounter < strRefGroups.Count; nGrpCounter++)
                                        {
                                            string tmpstr = null;
                                            tmpstr = strRefGroups[nGrpCounter];
                                            GrpNo = 0;
                                            GrpNo = nGrpCounter + 1;

                                            if (tmpstr.Contains(":"))
                                            {
                                                // Split the string
                                                string[] separators = { ":" };
                                                string[] strValues = tmpstr.Split(separators, StringSplitOptions.RemoveEmptyEntries);

                                                if (strValues.Length > 0)
                                                {
                                                    if (strValues[0] == "space")
                                                    {
                                                        Run newrun = new Run();
                                                        newrun.AppendChild(new Text(" ") { Space = SpaceProcessingModeValues.Preserve });
                                                        R.InsertBeforeSelf(newrun);
                                                    }
                                                    else if (strValues[0] == "blank")
                                                    {
                                                        // No action required
                                                    }
                                                    else if (strValues[0] == "value")
                                                    {
                                                        //Run run = P.AppendChild(new Run());
                                                        // Add Text to the Run element.
                                                        Run newrun = new Run();
                                                        newrun.AppendChild(new Text(match.Groups[nGrpCounter + 1].Value));
                                                        R.InsertBeforeSelf(newrun);
                                                    }

                                                    if (strValues[1] != "") // Style
                                                    {
                                                        
                                                            Run newrun = new Run();
                                                            RunProperties rpr = new RunProperties(new RunStyle() { Val = strValues[1] });
                                                            rpr.AppendChild(new Bold());  //priyanka
                                                            newrun.AppendChild(rpr);

                                                            newrun.AppendChild(new Text(match.Groups[nGrpCounter + 1].Value));

                                                            R.InsertBeforeSelf(newrun);
                                                        
                                                    }
                                                }
                                            }
                                            else if (tmpstr.Contains("space"))
                                            {
                                                //Run run = P.AppendChild(new Run());
                                                //OpenXmlAttribute openXmlAttribute = new OpenXmlAttribute("space", "xml", "preserve");
                                                // Add Text to the Run element.
                                                Run newrun = new Run();
                                                Text T = new Text(" ") { Space = SpaceProcessingModeValues.Preserve };
                                                //T.SetAttribute(openXmlAttribute);
                                                newrun.AppendChild(T);
                                                R.InsertBeforeSelf(newrun);
                                            }
                                            else if (tmpstr.Contains("blank"))
                                            {
                                            }
                                            else if (tmpstr.Contains("value"))
                                            {
                                                //Run run = P.AppendChild(new Run());
                                                // Add Text to the Run element.
                                                Run newrun = new Run();
                                                newrun.AppendChild(new Text(match.Groups[nGrpCounter + 1].Value));
                                                R.InsertBeforeSelf(newrun);
                                            }
                                            else
                                            {
                                                Run newrun = new Run();
                                                //Run run = new Run(new RunProperties(new RunStyle() { Val = tmpstr }));
                                                if (match.Groups[nGrpCounter + 1].Value != "and")/////Added by vikas for if and comes in AU on 14-10-2020
                                                {
                                                    RunProperties rpr = new RunProperties(new RunStyle() { Val = tmpstr });
                                                    rpr.AppendChild(new Bold());    //12_4_2019
                                                    newrun.AppendChild(rpr);
                                                }
                                                else
                                                {
                                                    RunProperties rpr = new RunProperties();
                                                    rpr.AppendChild(new Bold());    //12_4_2019
                                                    newrun.AppendChild(rpr);
                                                }
                                                //P.AppendChild(run);
                                                // Add Text to the Run element.
                                                newrun.AppendChild(new Text(match.Groups[nGrpCounter + 1].Value));   //check name has comment.
                                                R.InsertBeforeSelf(newrun);

                                            }


                                        }
                                    }
                                    if (bEndsWithSpace == true)
                                    {
                                        bEndsWithSpace = false;
                                        Run newrun = new Run();
                                        newrun.AppendChild(new Text(" ") { Space = SpaceProcessingModeValues.Preserve });
                                        R.InsertBeforeSelf(newrun);
                                    }

                                    //R.InsertBeforeSelf(newrun);
                                    if (listRun != null && listRun.Count > 1)
                                    {

                                        foreach (var removeRun in listRun.ToList())
                                        {
                                            removeRun.Remove();
                                        }

                                    }
                                    else
                                    {
                                        R.Remove();
                                    }



                                    goto NextRef;
                                }
                            }
                        }
                    }

                NextRefSearchPattern:
                    {
                        continue;
                    }
                }

                strRefGroups.Clear();

            //sw1.WriteLine(strReferenceText);
            //sw1.WriteLine("");

            NextRef:
                {
                    return;
                }
            }
            catch (Exception ex)
            {
            }
        }

        #endregion
        private static bool CheckIfParaHasStructuredAuthors(List<OpenXmlElement> RList)
        {
            foreach (OpenXmlElement R in RList)
            {
                if (R.LocalName != null)
                {
                    if (R.LocalName == "r")
                    {
                        if (R.HasChildren)
                        {
                            foreach (OpenXmlElement el in R.Elements())
                            {
                                if (el.LocalName == "rPr")
                                {
                                    if (el.HasChildren)
                                    {
                                        foreach (OpenXmlElement el1 in el.Elements())
                                        {
                                            if (el1.LocalName == "rStyle")
                                            {
                                                string Style = ((DocumentFormat.OpenXml.Wordprocessing.String253Type)el1).Val;

                                                if (Style != null)
                                                {
                                                    if (CheckIfTheStyleIsAuthorStyle(Style) == true)
                                                        return true;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            return false;
        }

        private static bool CheckIfTheStyleIsAuthorStyle(string strStyleName)
        {

            if (LstAuthorStyleColl.Contains(strStyleName))
            {
                return true;
            }

            return false;
        }

        public static void AuthorMarking(string newDoc)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                .Open(newDoc, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    RemoveComments = false,
                    RemoveContentControls = true,
                    RemoveEndAndFootNotes = false,
                    RemoveFieldCodes = true,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = false,//Developer name :Priyanka Vishwakarma. Date:29_5_2019, Requirement:it removes the indentation from the nested list  ,Integrated By:Vikas sir. 
                };

                MarkupSimplifier.SimplifyMarkup(WPD, settings);

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().
                    Where(e => e.ParagraphProperties != null
                        && e.ParagraphProperties.ParagraphStyleId != null
                        && e.ParagraphProperties.ParagraphStyleId.Val == "AU"))
                {
                    if (P.HasChildren == false)
                    {
                        try
                        {
                            P.Remove();
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(ex.Message);
                        }
                    }
                    else
                    {
                        var ppr = P.Descendants<ParagraphProperties>();
                        string dummytext = null;

                        bool bothtagexist = false;
                        bool firsttagexist = false;
                        bool secondtagexist = false;

                        if (P.InnerText != null)
                        {
                            List<string> commentedtext = new List<string>();


                            //bool and int only For run comment text
                            bool getruntext = false;
                            int rcounter = 0;

                            foreach (var PE in P.Elements().ToList())
                            {
                                if (PE.XName == W.commentRangeStart)
                                {
                                    getruntext = true;
                                }
                                else if (PE.XName == W.bookmarkStart)
                                {
                                    dummytext = dummytext + "</bookmarkStart_DummyText>";
                                    getruntext = false;
                                    rcounter = 0;
                                }
                                if (PE.XName == W.r && getruntext == true)
                                {
                                    if (PE.InnerText != null && rcounter == 0)
                                    {
                                        dummytext += "<bookmarkStart_DummyText>" + PE.InnerText;
                                        rcounter++;
                                    }
                                    else
                                    {
                                        dummytext += PE.InnerText;
                                    }
                                }
                                else
                                {
                                    dummytext += PE.InnerText;
                                }
                            }
                        }

                        foreach (Run R in P.Descendants<Run>().ToList())
                        {
                            ////without superscript run remove in para
                            if (R.RunProperties != null)
                            {
                                if (R.RunProperties.VerticalTextAlignment != null)
                                {
                                    if (R.RunProperties.VerticalTextAlignment.Val == "superscript")
                                    {
                                        continue;
                                    }
                                }
                            }
                            R.Remove();
                        }

                        ////get para elements use for commented text

                        string[] separators = { "," };
                        string[] links = dummytext.Trim().Split(separators, StringSplitOptions.RemoveEmptyEntries);

                        for (int i = 0; i < links.Count(); i++)
                        {
                            if (links[i].Contains("<bookmarkStart_DummyText>") && links[i].Contains("</bookmarkStart_DummyText>"))
                            {
                                bothtagexist = true;
                            }
                            else if (links[i].Contains("<bookmarkStart_DummyText>"))
                            {
                                firsttagexist = true;
                            }
                            else if (links[i].Contains("</bookmarkStart_DummyText>"))
                            {
                                firsttagexist = false;
                                secondtagexist = true;
                            }
                            else
                            {
                                firsttagexist = false;
                                secondtagexist = false;
                                bothtagexist = false;
                            }

                            bool SuperscriptFoundAfterComma = false;

                            string[] separators_space = { " " };
                            string[] links_space = links[i].Split(separators_space, StringSplitOptions.RemoveEmptyEntries);

                            formatingapply(bothtagexist, firsttagexist, secondtagexist, links_space, P, SuperscriptFoundAfterComma);
                        }
                    }
                }
                D.Save();
            }
        }

        public static void formatingapply(bool bothtagexist, bool firsttagexist, bool secondtagexist, string[] links_space, Paragraph P, bool SuperscriptFoundAfterComma)
        {

            #region bothtagexist
            if (bothtagexist)
            {
                bothtagexist = false;

                for (int auname = 0; auname < links_space.Count(); auname++)
                {
                    Run newrunadd = new Run();
                    if (links_space.Count() == 4)
                    {
                        if (links_space[auname] == "0")
                        {

                        }
                        else if (links_space[auname] == "1")
                        {

                        }
                        else if (links_space[auname] == "2")
                        {

                        }
                        else if (links_space[auname] == "3")
                        {

                        }

                    }
                    else if (links_space.Count() == 3)
                    {
                        if (auname == 0)
                        {
                            //superscript check 
                            int n;

                            string supval = links_space[auname].Substring(links_space[auname].Length - 1);

                            bool isnumeric = int.TryParse(supval, out n);
                            if (isnumeric)
                            {
                                foreach (Run R in P.Elements<Run>().ToList())
                                {
                                    P.Append(R.CloneNode(true));
                                    R.Remove();
                                    SuperscriptFoundAfterComma = true;
                                    break;
                                }
                            }
                            else
                            {
                                newrunadd.RunProperties = new RunProperties(new RunStyle { Val = "aufname" });
                                Text newtxtadd = new Text(links_space[auname] + " ");
                                newrunadd.Append(newtxtadd);
                                P.Append(newrunadd);
                            }
                        }
                        else if (auname == 1)
                        {
                            if (SuperscriptFoundAfterComma)
                            {
                                newrunadd.RunProperties = new RunProperties(new RunStyle { Val = "aufname" });

                                string newtext = CommentStartTextandEndText(links_space[auname], P);

                                Text newtxtadd = new Text(newtext + " ");
                                newrunadd.Append(newtxtadd);
                                P.LastChild.PreviousSibling().InsertBeforeSelf(newrunadd);
                                SuperscriptFoundAfterComma = false;
                            }
                            else
                            {
                                newrunadd.RunProperties = new RunProperties(new RunStyle { Val = "aumiddlename" });
                                Text newtxtadd = new Text(links_space[auname] + " ");
                                newrunadd.Append(newtxtadd);
                                P.Append(newrunadd);
                            }
                        }
                        else if (auname == 2)
                        {
                            int n;

                            string supval = links_space[auname].Substring(links_space[auname].Length - 1);

                            bool isnumeric = int.TryParse(supval, out n);

                            if (isnumeric)
                            {
                                newrunadd.RunProperties = new RunProperties(new RunStyle { Val = "ausurname" });
                                Text newtxtadd1 = new Text(links_space[auname].Replace(supval, ""));
                                newrunadd.Append(newtxtadd1);
                                P.Append(newrunadd);

                                foreach (Run R in P.Elements<Run>().ToList())
                                {
                                    P.Append(R.CloneNode(true));
                                    R.Remove();
                                    break;
                                }
                            }
                            else
                            {
                                newrunadd.RunProperties = new RunProperties(new RunStyle { Val = "ausurname" });
                                Text newtxtadd = new Text(links_space[auname]);
                                newrunadd.Append(newtxtadd);
                                P.Append(newrunadd);
                            }

                            CommaAdd(P);
                        }
                    }
                    else if (links_space.Count() == 2)
                    {
                        if (auname == 0)
                        {
                            newrunadd.RunProperties = new RunProperties(new RunStyle { Val = "aufname" });
                            string newtext = CommentStartTextandEndText(links_space[auname], P);
                            Text newtxtadd = new Text(newtext + " ");
                            newrunadd.Append(newtxtadd);
                            P.Append(newrunadd);

                        }
                        else if (auname == 1)
                        {
                            int n;

                            string supval = links_space[auname].Substring(links_space[auname].Length - 1);

                            bool isnumeric = int.TryParse(supval, out n);

                            if (isnumeric)
                            {
                                newrunadd.RunProperties = new RunProperties(new RunStyle { Val = "ausurname" });
                                Text newtxtadd1 = new Text(links_space[auname].Replace(supval, ""));
                                newrunadd.Append(newtxtadd1);
                                P.Append(newrunadd);

                                foreach (Run R in P.Elements<Run>().ToList())
                                {
                                    P.Append(R.CloneNode(true));
                                    R.Remove();
                                    break;
                                }
                            }
                            else
                            {
                                newrunadd.RunProperties = new RunProperties(new RunStyle { Val = "ausurname" });
                                Text newtxtadd = new Text(links_space[auname]);
                                newrunadd.Append(newtxtadd);
                                P.Append(newrunadd);
                            }

                            CommaAdd(P);
                        }
                    }
                }
            }
            #endregion bothtagexist end

            #region firsttagexist
            else if (firsttagexist)
            {
                for (int auname = 0; auname < links_space.Count(); auname++)
                {
                    Run newrunadd = new Run();
                    if (links_space.Count() == 4)
                    {
                        if (links_space[auname] == "0")
                        {

                        }
                        else if (links_space[auname] == "1")
                        {

                        }
                        else if (links_space[auname] == "2")
                        {

                        }
                        else if (links_space[auname] == "3")
                        {

                        }

                    }
                    else if (links_space.Count() == 3)
                    {
                        if (auname == 0)
                        {

                            //superscript check 
                            int n;

                            string supval = links_space[auname].Substring(links_space[auname].Length - 1);

                            bool isnumeric = int.TryParse(supval, out n);
                            if (isnumeric)
                            {
                                foreach (Run R in P.Elements<Run>().ToList())
                                {
                                    P.Append(R.CloneNode(true));
                                    R.Remove();
                                    SuperscriptFoundAfterComma = true;
                                    break;
                                }
                            }
                            else
                            {
                                newrunadd.RunProperties = new RunProperties(new RunStyle { Val = "aufname" });
                                Text newtxtadd = new Text(links_space[auname] + " ");
                                newrunadd.Append(newtxtadd);
                                P.Append(newrunadd);
                            }
                        }
                        else if (auname == 1)
                        {
                            if (SuperscriptFoundAfterComma)
                            {
                                newrunadd.RunProperties = new RunProperties(new RunStyle { Val = "aufname" });
                                Text newtxtadd = new Text(links_space[auname] + " ");
                                newrunadd.Append(newtxtadd);
                                P.Append(newrunadd);
                                SuperscriptFoundAfterComma = false;
                            }
                            else
                            {
                                newrunadd.RunProperties = new RunProperties(new RunStyle { Val = "aumiddlename" });
                                Text newtxtadd = new Text(links_space[auname] + " ");
                                newrunadd.Append(newtxtadd);
                                P.Append(newrunadd);
                            }
                        }
                        else if (auname == 2)
                        {
                            int n;

                            string supval = links_space[auname].Substring(links_space[auname].Length - 1);

                            bool isnumeric = int.TryParse(supval, out n);

                            if (isnumeric)
                            {
                                newrunadd.RunProperties = new RunProperties(new RunStyle { Val = "ausurname" });
                                Text newtxtadd1 = new Text(links_space[auname].Replace(supval, ""));
                                newrunadd.Append(newtxtadd1);
                                P.Append(newrunadd);

                                foreach (Run R in P.Elements<Run>().ToList())
                                {
                                    P.Append(R.CloneNode(true));
                                    R.Remove();
                                    break;
                                }
                            }
                            else
                            {
                                newrunadd.RunProperties = new RunProperties(new RunStyle { Val = "ausurname" });
                                Text newtxtadd = new Text(links_space[auname]);
                                newrunadd.Append(newtxtadd);
                                P.Append(newrunadd);
                            }

                            CommaAdd(P);
                        }
                    }
                    else if (links_space.Count() == 2)
                    {
                        if (auname == 0)
                        {
                            newrunadd.RunProperties = new RunProperties(new RunStyle { Val = "aufname" });
                            Text newtxtadd = new Text(links_space[auname] + " ");
                            newrunadd.Append(newtxtadd);
                            P.Append(newrunadd);

                        }
                        else if (auname == 1)
                        {
                            int n;

                            string supval = links_space[auname].Substring(links_space[auname].Length - 1);

                            bool isnumeric = int.TryParse(supval, out n);

                            if (isnumeric)
                            {
                                newrunadd.RunProperties = new RunProperties(new RunStyle { Val = "ausurname" });
                                Text newtxtadd1 = new Text(links_space[auname].Replace(supval, ""));
                                newrunadd.Append(newtxtadd1);
                                P.Append(newrunadd);

                                foreach (Run R in P.Elements<Run>().ToList())
                                {
                                    P.Append(R.CloneNode(true));
                                    R.Remove();
                                    break;
                                }
                            }
                            else
                            {
                                newrunadd.RunProperties = new RunProperties(new RunStyle { Val = "ausurname" });
                                Text newtxtadd = new Text(links_space[auname]);
                                newrunadd.Append(newtxtadd);
                                P.Append(newrunadd);
                            }

                            CommaAdd(P);
                        }
                    }
                }
            }
            #endregion firsttagexist End

            #region secondtagexist
            else if (secondtagexist)
            {
                secondtagexist = false;
                firsttagexist = false;


                for (int auname = 0; auname < links_space.Count(); auname++)
                {
                    Run newrunadd = new Run();
                    if (links_space.Count() == 4)
                    {
                        if (links_space[auname] == "0")
                        {

                        }
                        else if (links_space[auname] == "1")
                        {

                        }
                        else if (links_space[auname] == "2")
                        {

                        }
                        else if (links_space[auname] == "3")
                        {

                        }

                    }
                    else if (links_space.Count() == 3)
                    {
                        if (auname == 0)
                        {

                            //superscript check 
                            int n;

                            string supval = links_space[auname].Substring(links_space[auname].Length - 1);

                            bool isnumeric = int.TryParse(supval, out n);
                            if (isnumeric)
                            {
                                foreach (Run R in P.Elements<Run>().ToList())
                                {
                                    P.Append(R.CloneNode(true));
                                    R.Remove();
                                    SuperscriptFoundAfterComma = true;
                                    break;
                                }
                            }
                            else
                            {
                                newrunadd.RunProperties = new RunProperties(new RunStyle { Val = "aufname" });
                                Text newtxtadd = new Text(links_space[auname] + " ");
                                newrunadd.Append(newtxtadd);
                                P.Append(newrunadd);
                            }
                        }
                        else if (auname == 1)
                        {
                            if (SuperscriptFoundAfterComma)
                            {
                                newrunadd.RunProperties = new RunProperties(new RunStyle { Val = "aufname" });
                                Text newtxtadd = new Text(links_space[auname] + " ");
                                newrunadd.Append(newtxtadd);
                                P.Append(newrunadd);
                                SuperscriptFoundAfterComma = false;
                            }
                            else
                            {
                                newrunadd.RunProperties = new RunProperties(new RunStyle { Val = "aumiddlename" });
                                Text newtxtadd = new Text(links_space[auname] + " ");
                                newrunadd.Append(newtxtadd);
                                P.Append(newrunadd);
                            }
                        }
                        else if (auname == 2)
                        {
                            int n;

                            string supval = links_space[auname].Substring(links_space[auname].Length - 1);

                            bool isnumeric = int.TryParse(supval, out n);

                            if (isnumeric)
                            {
                                newrunadd.RunProperties = new RunProperties(new RunStyle { Val = "ausurname" });
                                Text newtxtadd1 = new Text(links_space[auname].Replace(supval, ""));
                                newrunadd.Append(newtxtadd1);
                                P.Append(newrunadd);

                                foreach (Run R in P.Elements<Run>().ToList())
                                {
                                    P.Append(R.CloneNode(true));
                                    R.Remove();
                                    break;
                                }
                            }
                            else
                            {
                                newrunadd.RunProperties = new RunProperties(new RunStyle { Val = "ausurname" });
                                Text newtxtadd = new Text(links_space[auname]);
                                newrunadd.Append(newtxtadd);
                                P.Append(newrunadd);
                            }

                            CommaAdd(P);
                        }
                    }
                    else if (links_space.Count() == 2)
                    {
                        if (auname == 0)
                        {
                            newrunadd.RunProperties = new RunProperties(new RunStyle { Val = "aufname" });
                            Text newtxtadd = new Text(links_space[auname] + " ");
                            newrunadd.Append(newtxtadd);
                            P.Append(newrunadd);

                        }
                        else if (auname == 1)
                        {
                            int n;

                            string supval = links_space[auname].Substring(links_space[auname].Length - 1);

                            bool isnumeric = int.TryParse(supval, out n);

                            if (isnumeric)
                            {
                                newrunadd.RunProperties = new RunProperties(new RunStyle { Val = "ausurname" });
                                Text newtxtadd1 = new Text(links_space[auname].Replace(supval, ""));
                                newrunadd.Append(newtxtadd1);
                                P.Append(newrunadd);

                                foreach (Run R in P.Elements<Run>().ToList())
                                {
                                    P.Append(R.CloneNode(true));
                                    R.Remove();
                                    break;
                                }
                            }
                            else
                            {
                                newrunadd.RunProperties = new RunProperties(new RunStyle { Val = "ausurname" });
                                Text newtxtadd = new Text(links_space[auname]);
                                newrunadd.Append(newtxtadd);
                                P.Append(newrunadd);
                            }

                            CommaAdd(P);
                        }
                    }
                }
            }
            #endregion secondtagexist end

            #region no tag exist
            else if (firsttagexist == false && secondtagexist == false)
            {
                for (int auname = 0; auname < links_space.Count(); auname++)
                {
                    Run newrunadd = new Run();
                    if (links_space.Count() == 4)
                    {
                        if (links_space[auname] == "0")
                        {

                        }
                        else if (links_space[auname] == "1")
                        {

                        }
                        else if (links_space[auname] == "2")
                        {

                        }
                        else if (links_space[auname] == "3")
                        {

                        }

                    }
                    else if (links_space.Count() == 3)
                    {
                        if (auname == 0)
                        {

                            //superscript check 
                            int n;

                            string supval = links_space[auname].Substring(links_space[auname].Length - 1);

                            bool isnumeric = int.TryParse(supval, out n);
                            if (isnumeric)
                            {
                                foreach (Run R in P.Elements<Run>().ToList())
                                {
                                    P.Append(R.CloneNode(true));
                                    R.Remove();
                                    SuperscriptFoundAfterComma = true;
                                    break;
                                }
                            }
                            else
                            {
                                newrunadd.RunProperties = new RunProperties(new RunStyle { Val = "aufname" });
                                Text newtxtadd = new Text(links_space[auname] + " ");
                                newrunadd.Append(newtxtadd);
                                P.Append(newrunadd);
                            }
                        }
                        else if (auname == 1)
                        {
                            if (SuperscriptFoundAfterComma)
                            {
                                newrunadd.RunProperties = new RunProperties(new RunStyle { Val = "aufname" });
                                Text newtxtadd = new Text(links_space[auname] + " ");
                                newrunadd.Append(newtxtadd);
                                P.Append(newrunadd);
                                SuperscriptFoundAfterComma = false;
                            }
                            else
                            {
                                newrunadd.RunProperties = new RunProperties(new RunStyle { Val = "aumiddlename" });
                                Text newtxtadd = new Text(links_space[auname] + " ");
                                newrunadd.Append(newtxtadd);
                                P.Append(newrunadd);
                            }
                        }
                        else if (auname == 2)
                        {
                            int n;

                            string supval = links_space[auname].Substring(links_space[auname].Length - 1);

                            bool isnumeric = int.TryParse(supval, out n);

                            if (isnumeric)
                            {
                                newrunadd.RunProperties = new RunProperties(new RunStyle { Val = "ausurname" });
                                Text newtxtadd1 = new Text(links_space[auname].Replace(supval, ""));
                                newrunadd.Append(newtxtadd1);
                                P.Append(newrunadd);

                                foreach (Run R in P.Elements<Run>().ToList())
                                {
                                    P.Append(R.CloneNode(true));
                                    R.Remove();
                                    break;
                                }
                            }
                            else
                            {
                                newrunadd.RunProperties = new RunProperties(new RunStyle { Val = "ausurname" });
                                Text newtxtadd = new Text(links_space[auname]);
                                newrunadd.Append(newtxtadd);
                                P.Append(newrunadd);
                            }

                            CommaAdd(P);
                        }
                    }
                    else if (links_space.Count() == 2)
                    {
                        if (auname == 0)
                        {
                            newrunadd.RunProperties = new RunProperties(new RunStyle { Val = "aufname" });
                            Text newtxtadd = new Text(links_space[auname] + " ");
                            newrunadd.Append(newtxtadd);
                            P.Append(newrunadd);

                        }
                        else if (auname == 1)
                        {
                            int n;

                            string supval = links_space[auname].Substring(links_space[auname].Length - 1);

                            bool isnumeric = int.TryParse(supval, out n);

                            if (isnumeric)
                            {
                                newrunadd.RunProperties = new RunProperties(new RunStyle { Val = "ausurname" });
                                Text newtxtadd1 = new Text(links_space[auname].Replace(supval, ""));
                                newrunadd.Append(newtxtadd1);
                                P.Append(newrunadd);

                                foreach (Run R in P.Elements<Run>().ToList())
                                {
                                    P.Append(R.CloneNode(true));
                                    R.Remove();
                                    break;
                                }
                            }
                            else
                            {
                                newrunadd.RunProperties = new RunProperties(new RunStyle { Val = "ausurname" });
                                Text newtxtadd = new Text(links_space[auname]);
                                newrunadd.Append(newtxtadd);
                                P.Append(newrunadd);
                            }

                            CommaAdd(P);
                        }
                    }
                }
            }
            #endregion notagexist end

        }

        public static string CommentStartTextandEndText(string commnetstartadd, Paragraph P)
        {
            if (commnetstartadd.Contains("<bookmarkStart_DummyText>") && commnetstartadd.Contains("</bookmarkStart_DummyText>"))
            {
                commnetstartadd = commnetstartadd.Replace("<bookmarkStart_DummyText>", "").Replace("</bookmarkStart_DummyText>", "");
                foreach (var item in P.Elements().ToList())
                {
                    if (item.XName == W.commentRangeStart)
                    {
                        P.Append(item.CloneNode(true));
                        item.Remove();
                    }
                    else if (item.XName == W.commentRangeEnd)
                    {
                        P.Append(item.CloneNode(true));
                        item.Remove();
                    }
                    else if (item.XName == W.bookmarkStart)
                    {
                        P.Append(item.CloneNode(true));
                        item.Remove();
                        break;
                    }
                }
            }
            return commnetstartadd;
        }

        public static string commentstarttext(string commnetstartadd, Paragraph P)
        {
            if (commnetstartadd.Contains("<bookmarkStart_DummyText>"))
            {
                commnetstartadd = commnetstartadd.Replace("<bookmarkStart_DummyText>", "");
                foreach (var item in P.Elements().ToList())
                {
                    if (item.XName == W.commentRangeStart)
                    {
                        P.InsertAfterSelf(item.CloneNode(true));
                        item.Remove();
                        break;
                    }
                }
            }
            return commnetstartadd;
        }

        public static string commentendtext(string commnetstartadd, Paragraph P)
        {
            if (commnetstartadd.Contains("</bookmarkStart_DummyText>"))
            {
                commnetstartadd = commnetstartadd.Replace("</bookmarkStart_DummyText>", "");
                foreach (var item in P.Elements().ToList())
                {
                    if (item.XName == W.commentRangeEnd)
                    {
                        P.InsertAfterSelf(item.CloneNode(true));
                        item.Remove();
                    }
                    else if (item.XName == W.bookmarkStart)
                    {
                        P.InsertAfterSelf(item.CloneNode(true));
                        item.Remove();
                        break;
                    }
                }
            }
            return commnetstartadd;
        }


        public static void CommaAdd(Paragraph P)
        {
            Run r = new Run();
            Text t = new Text(",");
            r.Append(t);
            P.Append(r.CloneNode(true));
        }
        public static void checkAuthorAFFLId(string strword)   //Developer name:Priyanka Vishwakarma ,Date:13_09_2019 ,Requirement:Author query missing because of Author AFFL id(Superscript number) not provide in word document. 
        {
            using (WordprocessingDocument WPD = WordprocessingDocument.Open(strword, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;
                Document D = MDP.Document;
                Run dummysup = new Run(new RunProperties(new Bold(), new VerticalTextAlignment() { Val = VerticalPositionValues.Superscript }), new Text(" "));
                List<string> Author = new List<string>(); //Developer name:Priyanka Vishwakarma, Date:13_01_2020 ,Requirement:check all affId present in AU paragraph ,Integrated by:Vikas sir
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().Where(e => e != null && e.ParagraphProperties != null && e.ParagraphProperties.ParagraphStyleId != null && e.ParagraphProperties.ParagraphStyleId.Val == "AU"))
                {
                    //Developer name:Priyanka Vishwakarma, Date:13_01_2020 ,Requirement:check all affId present in AU paragraph ,Integrated by:Vikas sir
                    Author = P.InnerText.Split(',').ToList();

                    foreach (var str in Author.ToList())
                    {
                        string s = GlobalMethods.RegExSearch(str.TrimStart(' '), @"([A-Za-z]+)");
                        if (string.IsNullOrEmpty(s))
                        {
                            Author.Remove(str);
                        }

                    }
                    int numOfaff = P.Descendants().ToList().Where(x => x.LocalName == "vertAlign").ToList().Count();

                    if (numOfaff < Author.Count())  //Developer name:Priyanka Vishwakarma, Date:13_01_2020 ,Requirement:check all affId present in AU paragraph ,Integrated by:Vikas sir
                    {
                        foreach (Run r in P.Descendants<Run>().ToList())
                        {
                            int numberOfAuthor = r.InnerText.Trim().Split(',').Count();

                            if ((r.InnerText.Trim().StartsWith(",") || r.InnerText.Trim().EndsWith(",")) && numberOfAuthor < 3)   //For Single author name
                            {
                                if (r.PreviousSibling().Descendants().ToList().Where(x => x.LocalName == "commentReference").ToList().Count == 1)
                                {
                                    if (r.PreviousSibling().PreviousSibling().Descendants().ToList().Where(x => x.LocalName == "vertAlign").ToList().Count != 1)
                                    {
                                        r.InsertBeforeSelf(dummysup);
                                    }

                                }
                                else if (r.PreviousSibling().Descendants().ToList().Where(x => x.LocalName == "vertAlign").ToList().Count != 1)
                                {
                                    r.InsertBeforeSelf(dummysup);
                                }
                            }
                            else if (numberOfAuthor >= 3 && r.Descendants().ToList().Where(x => x.LocalName == "vertAlign").ToList().Count != 1)   //for multiple author name./Developer name:Priyanka Vishwakarma ,Date:12022020,Requirement Extra text come in AU paragraph.,Integrated by:Vikas sir.
                            {
                                string[] authorname = r.InnerText.Trim().Split(',');
                                if (authorname.Count() > 1)
                                {
                                    for (int i = 0; i < authorname.Count(); i++)
                                    {
                                        if (authorname[i].Trim() != "")
                                        {
                                            Run r1 = new Run(new RunProperties(new Bold()), new Text(authorname[i]));
                                            r.InsertBeforeSelf(r1);
                                            r.PreviousSibling().InsertAfterSelf(new Run(new RunProperties(new Bold(), new VerticalTextAlignment() { Val = VerticalPositionValues.Superscript }), new Text(" ")));
                                            // r.InsertAfterSelf(dummysup);
                                        }
                                    }
                                }
                                r.Remove();
                            }
                        }
                    }
                }
                D.Save();
            }
        }
        private static List<string> ApplyAFFLStyleForUFL(string newDoc, List<string> lstAuthorAffID)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                .Open(newDoc, true))
            {

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                // Go thorugh Author Paragraph and extract all the superscript values 
                // and store in Array

                string strAuthorID = null;
                string strAffID = null;
                bool bSuperScript = false;


                foreach (Paragraph P in D.Descendants<Paragraph>().ToList().
                       Where(e => e != null && e.ParagraphProperties != null
                           && e.ParagraphProperties.ParagraphStyleId != null
                           && (e.ParagraphProperties.ParagraphStyleId.Val == "AU" || e.ParagraphProperties.ParagraphStyleId.Val == "AU-LET" || e.ParagraphProperties.ParagraphStyleId.Val == "au-let" || e.ParagraphProperties.ParagraphStyleId.Val == "au-pre"))) //Developer name:priyanka vishwakarma ,Date:27_08_2019 ,Requirement:Apply affnumber for generating aff id in xml . Integrated by:Vikas sir.   ///AU-LET and au-let style added by Karan on 16-10-2018///AU-LET and au-let style added by Karan on 16-10-2018
                {
                    // Extract superscript values

                    if (P.HasChildren == true)
                    {
                        if (P.Descendants<Run>().Count() > 0)
                        {
                            foreach (Run R in P.Descendants<Run>().ToList())
                            {
                                if (R.RunProperties != null)
                                {
                                    if (R.RunProperties.VerticalTextAlignment != null)
                                    {
                                        bSuperScript = false;
                                        if (R.RunProperties.VerticalTextAlignment.Val == "superscript")
                                        {
                                            bSuperScript = true;
                                        }
                                    }
                                }

                                strAuthorID = null;
                                foreach (Text T in R.Descendants<Text>().ToList())
                                {
                                    if (bSuperScript)
                                    {
                                        bSuperScript = false;
                                        strAuthorID += T.Text.Trim();

                                        if (GlobalMethods.strClientName.ToLower() == "ufl")
                                        {
                                            if (strAuthorID.Contains(","))
                                            {
                                                // Split the string on comma and seperate the Affiliation ID's
                                                string[] separators = { "," };
                                                string[] AffID = strAuthorID.Split(separators, StringSplitOptions.RemoveEmptyEntries);

                                                if (AffID.Length > 0)
                                                {
                                                    for (int counter = 0; counter < AffID.Length; counter++)
                                                    {
                                                        if (lstAuthorAffID.Contains(AffID[counter]) == false)
                                                        {
                                                            if (AffID[counter].Trim() != "")
                                                            {
                                                                if (strAuthorID.Trim().Length > 1)
                                                                {
                                                                    var alltext = strAuthorID.ToCharArray();
                                                                    foreach (var text in alltext)
                                                                    {
                                                                        if (lstAuthorAffID.Contains(text.ToString()) == false)
                                                                        {
                                                                            lstAuthorAffID.Add(text.ToString());
                                                                        }
                                                                    }

                                                                }
                                                                else
                                                                {
                                                                    if (lstAuthorAffID.Contains(AffID[counter].Trim()) == false)
                                                                    {
                                                                        lstAuthorAffID.Add(AffID[counter].Trim());      //Priyanka Vishwakarma:Priyanka Vishwakarma ,Date:12-02-2020 ,requirement:Affid Not match because of space in AU paragraph superscript. ,Integrated by:Vikas sir.
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                            else
                                            {



                                                if (lstAuthorAffID.Contains(strAuthorID) == false)
                                                {
                                                    if (strAuthorID.Trim() != "")
                                                    {
                                                        if (strAuthorID.Trim().Length > 1)
                                                        {
                                                            var alltext = strAuthorID.ToCharArray();
                                                            foreach (var text in alltext)
                                                            {
                                                                if (lstAuthorAffID.Contains(text.ToString()) == false)
                                                                {
                                                                    lstAuthorAffID.Add(text.ToString());
                                                                }
                                                            }

                                                        }
                                                        else
                                                        {
                                                            if (lstAuthorAffID.Contains(strAuthorID.Trim()) == false)
                                                            {

                                                                lstAuthorAffID.Add(strAuthorID.Trim());  //Developer Name:priyanka Vishwakarma ,Date:15_5_2019 ,Requirement:Affnumber comes with space in document ,Integrated By:Vikas sir
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                D.Save();
            }

            return lstAuthorAffID;
        }

        public static void ApplyAFFLUsingAUIDList(string newDoc, List<string> LstOfAffNumber)     //Developer Name:Priyanka Vishwakarma, Date:03-09-2020 ,Requirement:Convert nl Para to Numlist and BL para to bulllist.
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P != null && P.InnerText.Trim() != "")
                    {
                        if (P != null && P.ParagraphProperties != null && P.ParagraphProperties.ParagraphStyleId != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val != null && P.ParagraphProperties.ParagraphStyleId.Val != "AFFL" && P.ParagraphProperties.ParagraphStyleId.Val != "CORR")
                        {
                            if (P.ParagraphProperties.ParagraphStyleId.Val.Value == "H1" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H2" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H3" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H4" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H5" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H6" || P.ParagraphProperties.ParagraphStyleId.Val.Value == "H7")
                            {
                                break;
                            }
                            else if (LstOfAffNumber.Any(x => P.InnerText.Trim().StartsWith(x)))
                            {
                                P.ParagraphProperties.ParagraphStyleId.Val.Value = "AFFL";
                            }
                        }

                    }

                }
                D.Save();
            }
        }


    }
}

