﻿using System;
using System.Collections.Generic;
using System.Linq;
using DocumentFormat.OpenXml.Packaging;
using OpenXmlPowerTools;
using DocumentFormat.OpenXml.Wordprocessing;
using System.Configuration;

namespace MultiInstanceJournalCleanup
{
    class EntityConversion
    {
        public static void ConvertEntities(string newDoc)
        {
            // Convert Font to Arial Unicode MS Font //

            ConvertSpecialFontCharacters(newDoc);

            GlobalMethods.StrEntityFile = ConfigurationManager.AppSettings.Get("3CMStyleEntityColl");

            List<string> strEntityColl = new List<string>();
            strEntityColl.Clear();
            strEntityColl = GlobalMethods.ReadAndStoreFileValuesInArray(GlobalMethods.StrEntityFile);

            using (WordprocessingDocument WPD = WordprocessingDocument
            .Open(newDoc, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    NormalizeXml = false,
                    RemoveComments = false,
                    RemoveContentControls = true,
                    RemoveEndAndFootNotes = false,
                    RemoveFieldCodes = true,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = false,//Developer name :Priyanka Vishwakarma. Date:29_5_2019, Requirement:it removes the indentation from the nested list  ,Integrated By:Vikas sir. 
                    RemoveHyperlinks = false,
                    AcceptRevisions = true,
                    //RemoveBookmarks = true,
                    RemoveGoBackBookmark = true,
                    RemoveWebHidden = true,
                    RemoveMarkupForDocumentComparison = true,
                };

                MarkupSimplifier.SimplifyMarkup(WPD, settings);

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                // Search all Paragraphs that is "TOC1 to TOC3" style.
                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P.HasChildren == true)
                    {
                        if (P.Descendants<Run>().Count() > 0)
                        {
                            foreach (Run R in P.Descendants<Run>().ToList())
                            {
                                if (R.HasChildren)
                                {
                                    foreach (var ele in R.Elements().ToList())
                                    {
                                        if (ele.LocalName == "sym")
                                        {
                                            if (ele.HasAttributes)
                                            {
                                                string strFont = null;
                                                string strChar = null;
                                                int nIndex = 0;

                                                foreach (var xa in ele.GetAttributes())
                                                {
                                                    if (xa.LocalName == "font")
                                                    {
                                                        strFont = xa.Value;
                                                    }

                                                    if (xa.LocalName == "char")
                                                    {
                                                        strChar = xa.Value;
                                                    }
                                                }

                                                // Compare the font and the character with configuration 

                                                for (nIndex = 0; nIndex < strEntityColl.Count; nIndex++)
                                                {
                                                    string[] separators = { "<eql>" };
                                                    string[] EntityInfo = strEntityColl[nIndex].Split(separators, StringSplitOptions.RemoveEmptyEntries);

                                                    string lookupFont = null;
                                                    string lookupChar = null;
                                                    string repChar = null;
                                                    if (EntityInfo.Length == 3)
                                                    {
                                                        lookupFont = EntityInfo[0];
                                                        lookupChar = EntityInfo[1];
                                                        repChar = EntityInfo[2];

                                                        if (strFont != null && lookupFont != null && strChar != null && lookupChar != null && strChar == lookupChar)
                                                        {
                                                            if (strFont.ToLower() == lookupFont.ToLower())
                                                            {
                                                                //// Font and Character matched with the configuration //
                                                                //// Replace the character with the Entity //
                                                                //Text T = new Text(repChar);
                                                                //ele.InsertAfterSelf(T);
                                                                //ele.Remove();
                                                                ////MessageBox.Show("Got it.....");
                                                                ////temp.Add(repChar);

                                                                string strRunStyle = null;

                                                                if (R.RunProperties != null)
                                                                {
                                                                    if (R.RunProperties.RunStyle != null)
                                                                    {
                                                                        strRunStyle = R.RunProperties.RunStyle.Val;
                                                                    }
                                                                }


                                                                Run rSpecialFont = new Run();
                                                                RunFonts rf = new RunFonts();
                                                                rf.Ascii = "Arial Unicode MS";

                                                                RunProperties rp = null;
                                                                if (strRunStyle != null)
                                                                {
                                                                    rp = new RunProperties(new RunStyle() { Val = strRunStyle });
                                                                    rp.AppendChild(rf);
                                                                }
                                                                else
                                                                {
                                                                    rp = new RunProperties(rf);
                                                                }

                                                                rSpecialFont.PrependChild(rp);

                                                                rSpecialFont.AppendChild(new Text(repChar));

                                                                // Insert new Run with new character

                                                                R.InsertAfterSelf(rSpecialFont);

                                                                // Delete the previous Run //

                                                                R.Remove();

                                                                break;
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                D.Save();
            }

        }

        public static void ConvertSpecialFontCharacters(string newDoc)
        {
            GlobalMethods.StrEntityFile = ConfigurationManager.AppSettings.Get("3CMFontConversion");

            List<string> strEntityColl = new List<string>();
            strEntityColl.Clear();
            strEntityColl = GlobalMethods.ReadAndStoreFileValuesInArray(GlobalMethods.StrEntityFile);

            using (WordprocessingDocument WPD = WordprocessingDocument
            .Open(newDoc, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    RemoveComments = false,
                    RemoveContentControls = true,
                    RemoveEndAndFootNotes = false,
                    RemoveFieldCodes = true,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = false,//Developer name :Priyanka Vishwakarma. Date:29_5_2019, Requirement:it removes the indentation from the nested list  ,Integrated By:Vikas sir. 
                };

                MarkupSimplifier.SimplifyMarkup(WPD, settings);

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                string strFontName = null;
                bool bSymbolFontFound = false;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    foreach (Run R in P.Descendants<Run>().ToList())
                    {
                        if (R.RunProperties != null)
                        {
                            if (R.RunProperties.RunFonts != null)
                            {
                                if (R.RunProperties.RunFonts.HasAttributes)
                                {
                                    bSymbolFontFound = false;

                                    foreach (DocumentFormat.OpenXml.OpenXmlAttribute at in R.RunProperties.RunFonts.GetAttributes())
                                    {
                                        if (at.LocalName == "ascii")
                                        {
                                            strFontName = at.Value;

                                            if (strFontName.ToLower() == "symbol")
                                            {
                                                bSymbolFontFound = true;
                                                break;
                                            }
                                        }
                                    }
                                }
                            }

                            foreach (Text T in R.Descendants<Text>().ToList())
                            {
                                if (bSymbolFontFound)
                                {
                                    // Compare the Font Character with the list and replace the R value //

                                    int nCounter = 0;

                                    for (nCounter = 0; nCounter < strEntityColl.Count; nCounter++)
                                    {
                                        string[] strCharColl = strEntityColl[nCounter].Split('|');

                                        if (strCharColl[0] == T.Text)
                                        {

                                            string strRunStyle = null;

                                            if (R.RunProperties != null)
                                            {
                                                if (R.RunProperties.RunStyle != null)
                                                {
                                                    strRunStyle = R.RunProperties.RunStyle.Val;
                                                }
                                            }

                                            // Prepare new Run element with new character

                                            Run rSpecialFont = new Run();
                                            RunFonts rf = new RunFonts();
                                            rf.Ascii = "Arial Unicode MS";
                                            //RunProperties rp = new RunProperties(rf);

                                            RunProperties rp = null;
                                            if (strRunStyle != null)
                                            {
                                                rp = new RunProperties(new RunStyle() { Val = strRunStyle });
                                                rp.AppendChild(rf);
                                            }
                                            else
                                            {
                                                rp = new RunProperties(rf);
                                            }

                                            rSpecialFont.PrependChild(rp);

                                            rSpecialFont.AppendChild(new Text(strCharColl[1]));

                                            // Insert new Run with new character

                                            R.InsertAfterSelf(rSpecialFont);

                                            // Delete the previous Run //

                                            R.Remove();

                                            bSymbolFontFound = false;

                                            break;
                                        }
                                    }

                                    bSymbolFontFound = false;
                                }
                            }
                        }
                    }
                }

                D.Save();
            }
        }

    }

}
