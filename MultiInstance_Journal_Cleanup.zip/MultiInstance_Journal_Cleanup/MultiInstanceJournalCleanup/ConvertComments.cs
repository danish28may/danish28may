﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DocumentFormat.OpenXml.Packaging;
using OpenXmlPowerTools;
using DocumentFormat.OpenXml.Wordprocessing;
using System.Xml.Linq;
using System.IO;
using System.Xml;
using DocumentFormat.OpenXml;

namespace MultiInstanceJournalCleanup
{
    class ConvertComments
    {

        public static List<DocumentFormat.OpenXml.Wordprocessing.Run> aftercommentrangeR = new List<DocumentFormat.OpenXml.Wordprocessing.Run>();

        //public static List<DocumentFormat.OpenXml.Wordprocessing.Run> commentHyperlink = new List<DocumentFormat.OpenXml.Wordprocessing.Run>();

        ///commented by Karan on 19-05-2018 
        //public static void ProcessComments(string filename)
        //{
        //    ExportCommentAndInsertBookmark(filename);
        //    exportCommentsAndRemoveFromDocument(filename);
        //}
        ///commented end by Karan on 19-05-2018




        public static void RemoveCommenteName(string filename)
        {
            aftercommentrangeR = new List<DocumentFormat.OpenXml.Wordprocessing.Run>();

            using (WordprocessingDocument WPD = WordprocessingDocument
                                                .Open(filename, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    RemoveComments = false,
                    RemoveContentControls = true,
                    RemoveEndAndFootNotes = false,
                    RemoveFieldCodes = true,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = false,//Developer name :Priyanka Vishwakarma. Date:29_5_2019, Requirement:it removes the indentation from the nested list  ,Integrated By:Vikas sir. 
                };

                MarkupSimplifier.SimplifyMarkup(WPD, settings);

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    foreach (Run R in P.Descendants<Run>().ToList())
                    {
                        if (R.ChildElements != null)
                        {
                            foreach (var item in R.ChildElements.ToList())
                            {

                                if (item.XName == W.commentReference)
                                {
                                    if (item.HasAttributes)
                                    {
                                        if (((DocumentFormat.OpenXml.Wordprocessing.MarkupType)item).Id != null)
                                        {
                                            BookmarkStart bks = new BookmarkStart();
                                            string bksvalue = ((DocumentFormat.OpenXml.Wordprocessing.MarkupType)item).Id.Value;

                                            //insert bookmark id and name
                                            bks.Id = "AUC_" + bksvalue;
                                            bks.Name = "AUC_" + bksvalue;

                                            //added bookmarks
                                            R.InsertBeforeSelf(bks);
                                            //R added in list then R remove.
                                            aftercommentrangeR.Add(R);
                                            R.Remove();
                                        }
                                    }
                                }
                            }
                        }
                    }
                    #region CommentRangeEnd logic commented by karan
                    ////if (P.HasChildren == true)
                    ////{
                    ////    if (P.Descendants<CommentRangeStart>().Count() > 0)
                    ////    {
                    ////        #region commented by Karan on 19-05-2018
                    ////        //////foreach (CommentRangeStart CRS in P.Descendants<CommentRangeStart>().ToList())
                    ////        //////{
                    ////        //////    BookmarkStart bks = new BookmarkStart();
                    ////        //////    bks.Id = "AUC_" + CRS.Id;
                    ////        //////    bks.Name = "AUC_" + CRS.Id;
                    ////        //////    CRS.InsertBeforeSelf(bks);
                    ////        //////    bCommentFound = true;
                    ////        //////}
                    ////        #endregion commented by Karan on 19-05-2018

                    ////        if (P.Descendants<CommentRangeEnd>().Count() > 0)
                    ////        {
                    ////            foreach (CommentRangeEnd CRE in P.Descendants<CommentRangeEnd>().ToList())
                    ////            {
                    ////                #region commented by Karan on 19-05-2018
                    ////                //////BookmarkEnd bke = new BookmarkEnd();
                    ////                //////bke.Id = "AUC_" + CRE.Id;
                    ////                //////CRE.InsertAfterSelf(bke);
                    ////                //////bCommentFound = true;
                    ////                #endregion commented by Karan on 19-05-2018

                    ////                if (CRE.NextSibling().LocalName == "r")
                    ////                {

                    ////                    var comrefdel = (Run)CRE.NextSibling();

                    ////                    aftercommentrangeR.Add(comrefdel);
                    ////                    comrefdel.Remove();
                    ////                }
                    ////            }
                    ////            foreach (Run R in P.Descendants<Run>().ToList())
                    ////            {

                    ////            }
                    ////            foreach (OpenXmlElement ox in P.Elements())
                    ////            {
                    ////                if (ox.XName == W.ins)
                    ////                {

                    ////                }
                    ////            }
                    ////            //{
                    ////            //    #region commented by Karan on 19-05-2018
                    ////            //    //////BookmarkEnd bke = new BookmarkEnd();
                    ////            //    //////bke.Id = "AUC_" + CRE.Id;
                    ////            //    //////CRE.InsertAfterSelf(bke);
                    ////            //    //////bCommentFound = true;
                    ////            //    #endregion commented by Karan on 19-05-2018

                    ////            //    if (CRE1.NextSibling().LocalName == "r")
                    ////            //    {
                    ////            //        var comrefdel = (Run)CRE1.NextSibling();

                    ////            //        aftercommentrangeR.Add(comrefdel);
                    ////            //        comrefdel.Remove();
                    ////            //    }
                    ////            //}

                    ////        }
                    ////    }
                    ////    #region code commented by Karan on 19-05-2018
                    ////    //////else if (P.Descendants<CommentRangeEnd>().Count() > 0)
                    ////    //////{
                    ////    //////    foreach (CommentRangeEnd CRE in P.Descendants<CommentRangeEnd>().ToList())
                    ////    //////    {
                    ////    //////        bCommentFound = true;
                    ////    //////        BookmarkEnd bke = new BookmarkEnd();
                    ////    //////        bke.Id = "AUC_" + CRE.Id;
                    ////    //////        CRE.InsertAfterSelf(bke);
                    ////    //////    }

                    ////    //////    if (P.Descendants<CommentRangeStart>().Count() > 0)
                    ////    //////    {
                    ////    //////        bCommentFound = true;
                    ////    //////        foreach (CommentRangeStart CRS in P.Descendants<CommentRangeStart>().ToList())
                    ////    //////        {
                    ////    //////            BookmarkStart bks = new BookmarkStart();
                    ////    //////            bks.Id = "AUC_" + CRS.Id;
                    ////    //////            bks.Name = "AUC_" + CRS.Id;
                    ////    //////            CRS.InsertBeforeSelf(bks);
                    ////    //////        }
                    ////    //////    }
                    ////    //////}
                    ////    //////else if (P.Descendants<Run>().Count() > 0)
                    ////    //////{
                    ////    //////    foreach (Run R in P.Descendants<Run>().ToList())
                    ////    //////    {
                    ////    //////        if (R.HasChildren)
                    ////    //////        {
                    ////    //////            foreach (var ele in R.Elements().ToList())
                    ////    //////            {
                    ////    //////                if (ele.LocalName == "commentReference")
                    ////    //////                {
                    ////    //////                    if (ele.HasAttributes)
                    ////    //////                    {
                    ////    //////                        foreach (var att in ele.GetAttributes())
                    ////    //////                        {
                    ////    //////                            if (att.LocalName == "id")
                    ////    //////                            {
                    ////    //////                                BookmarkStart bks = new BookmarkStart();
                    ////    //////                                bks.Id = "AUC_" + att.Value;
                    ////    //////                                bks.Name = "AUC_" + att.Value;
                    ////    //////                                ele.InsertAfterSelf(bks);

                    ////    //////                                BookmarkEnd bke = new BookmarkEnd();
                    ////    //////                                bke.Id = "AUC_" + att.Value;
                    ////    //////                                bks.InsertAfterSelf(bke);
                    ////    //////                            }
                    ////    //////                        }
                    ////    //////                    }
                    ////    //////                }
                    ////    //////            }
                    ////    //////        }
                    ////    //////    }
                    ////    //////}
                    ////    #endregion 
                    ////}
                    #endregion
                }
                D.Save();
            }
        }


        public static void ExportCommentName(string filename)
        {

            using (WordprocessingDocument WPD = WordprocessingDocument
                                                .Open(filename, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    RemoveComments = false,
                    RemoveContentControls = true,
                    RemoveEndAndFootNotes = false,
                    RemoveFieldCodes = true,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = false,//Developer name :Priyanka Vishwakarma. Date:29_5_2019, Requirement:it removes the indentation from the nested list  ,Integrated By:Vikas sir. 
                };

                MarkupSimplifier.SimplifyMarkup(WPD, settings);

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                string commentRefValFromList = null;
                string commentRefvalFromRun = null;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P.HasChildren == true)
                    {
                        foreach (BookmarkStart bokmrk in P.Descendants<BookmarkStart>().ToList())
                        {
                            if (bokmrk.Name != null)
                            {
                                if (bokmrk.Name.Value != null)
                                {
                                    //find bookmark value
                                    string bkmrk = bokmrk.Name.Value;
                                    commentRefValFromList = bkmrk.Replace("AUC_", "");
                                }
                            }
                            else
                            {
                                continue;
                            }
                            var j= aftercommentrangeR.Where(x=>x.ChildElements.ToList().Where(f=>f.XName==W.commentReference && f.HasAttributes).Where(i=>i.OfType<MarkupType>().FirstOrDefault().Id!=null && i.OfType<MarkupType>().FirstOrDefault().Id.Value== commentRefValFromList).Count()>0);
                            foreach (var match in aftercommentrangeR)
                            {
                                if (match.ChildElements != null)
                                {
                                    foreach (var item in match.ChildElements.ToList())
                                    {

                                        if (item.XName == W.commentReference)
                                        {
                                            if (item.HasAttributes)
                                            {
                                                if (((DocumentFormat.OpenXml.Wordprocessing.MarkupType)item).Id != null)
                                                {
                                                    ///find in list commentreference value
                                                    commentRefvalFromRun = ((DocumentFormat.OpenXml.Wordprocessing.MarkupType)item).Id.Value;
                                                }
                                                ///match bookmark value and list value( both ID)
                                                if (commentRefValFromList == commentRefvalFromRun)
                                                {
                                                    //if (match.Parent != null)
                                                    //{
                                                        //run inserted before bookmark and bookmark removed.
                                                        bokmrk.InsertAfterSelf(match.CloneNode(true));
                                                        bokmrk.Remove();
                                                    goto nextpara;
                                                    //}                                                
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            nextpara:
                            {

                            }
                        }
                    }
                }
                D.Save();
            }
        }

        

        public static void ExportCommentAndInsertBookmark(string filename)
        {
            using (WordprocessingDocument WPD = WordprocessingDocument
                                                .Open(filename, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    RemoveComments = false,
                    RemoveContentControls = true,
                    RemoveEndAndFootNotes = false,
                    RemoveFieldCodes = true,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = false,//Developer name :Priyanka Vishwakarma. Date:29_5_2019, Requirement:it removes the indentation from the nested list  ,Integrated By:Vikas sir. 
                };

                MarkupSimplifier.SimplifyMarkup(WPD, settings);

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

                bool bCommentFound = false;

                foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
                {
                    if (P.HasChildren == true)
                    {
                        if (P.Descendants<CommentRangeStart>().Count() > 0)
                        {
                            foreach (CommentRangeStart CRS in P.Descendants<CommentRangeStart>().ToList())
                            {
                                BookmarkStart bks = new BookmarkStart();
                                bks.Id = "AUC_" + CRS.Id;
                                bks.Name = "AUC_" + CRS.Id;
                                CRS.InsertBeforeSelf(bks);
                                bCommentFound = true;
                            }

                            if (P.Descendants<CommentRangeEnd>().Count() > 0)
                            {
                                foreach (CommentRangeEnd CRE in P.Descendants<CommentRangeEnd>().ToList())
                                {
                                    BookmarkEnd bke = new BookmarkEnd();
                                    bke.Id = "AUC_" + CRE.Id;
                                    CRE.InsertAfterSelf(bke);
                                    bCommentFound = true;

                                    if (CRE.NextSibling().NextSibling().LocalName == "r")
                                    {
                                        var comrefdel = CRE.NextSibling().NextSibling();
                                        foreach (var item in comrefdel.Elements<CommentReference>().ToList())
                                        {
                                            item.Remove();
                                        }
                                    }
                                }
                            }
                        }
                        else if (P.Descendants<CommentRangeEnd>().Count() > 0)
                        {
                            foreach (CommentRangeEnd CRE in P.Descendants<CommentRangeEnd>().ToList())
                            {
                                bCommentFound = true;
                                BookmarkEnd bke = new BookmarkEnd();
                                bke.Id = "AUC_" + CRE.Id;
                                CRE.InsertAfterSelf(bke);
                            }

                            if (P.Descendants<CommentRangeStart>().Count() > 0)
                            {
                                bCommentFound = true;
                                foreach (CommentRangeStart CRS in P.Descendants<CommentRangeStart>().ToList())
                                {
                                    BookmarkStart bks = new BookmarkStart();
                                    bks.Id = "AUC_" + CRS.Id;
                                    bks.Name = "AUC_" + CRS.Id;
                                    CRS.InsertBeforeSelf(bks);
                                }
                            }
                        }
                        else if (P.Descendants<Run>().Count() > 0)
                        {
                            foreach (Run R in P.Descendants<Run>().ToList())
                            {
                                if (R.HasChildren)
                                {
                                    foreach (var ele in R.Elements().ToList())
                                    {
                                        if (ele.LocalName == "commentReference")
                                        {
                                            if (ele.HasAttributes)
                                            {
                                                foreach (var att in ele.GetAttributes())
                                                {
                                                    if (att.LocalName == "id")
                                                    {
                                                        BookmarkStart bks = new BookmarkStart();
                                                        bks.Id = "AUC_" + att.Value;
                                                        bks.Name = "AUC_" + att.Value;
                                                        ele.InsertAfterSelf(bks);

                                                        BookmarkEnd bke = new BookmarkEnd();
                                                        bke.Id = "AUC_" + att.Value;
                                                        bks.InsertAfterSelf(bke);
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                D.Save();
            }
        }

        public static void exportCommentsAndRemoveFromDocument(string filename)
        {
            string strCommentsFilename = null;

            if (GlobalMethods.ArticlePath != "")
            {
                strCommentsFilename = GlobalMethods.ArticlePath;

                if (strCommentsFilename != null)
                {
                    if (strCommentsFilename.EndsWith("\\") == false)
                    {
                        strCommentsFilename = strCommentsFilename + "\\";
                    }

                    strCommentsFilename = strCommentsFilename + "Manuscript";

                    if (Directory.Exists(strCommentsFilename) == false)
                    {
                        Directory.CreateDirectory(strCommentsFilename);
                    }

                    strCommentsFilename = strCommentsFilename + "\\Comments.txt";

                    using (WordprocessingDocument wordDoc =
                        WordprocessingDocument.Open(filename, false))
                    {
                        WordprocessingCommentsPart commentsPart =
                            wordDoc.MainDocumentPart.WordprocessingCommentsPart;

                        if (commentsPart != null && commentsPart.Comments != null)
                        {
                            StreamWriter sw = new StreamWriter(strCommentsFilename);

                            foreach (Comment comment in commentsPart.Comments.Elements<Comment>())
                            {
                                string target = null;
                                string data = null;

                                target = "oxy_comment_start";
                                data = "author=" + "\"" + comment.Author + "\"" + " timestamp=" + "\"" + DateTime.Now + "\"" + " comment=" + "\"" + comment.InnerText + "\"";

                                XProcessingInstruction xps = new XProcessingInstruction(target, data);

                                sw.WriteLine(xps.ToString());
                            }

                            sw.Close();
                        }
                    }
                }
            }
        }

        public static void RemoveComments(WordprocessingDocument document)
        {
            // remove w:commentRangeStart, w:commentRangeEnd, w:commentReference
            XNamespace w = "http://schemas.openxmlformats.org/wordprocessingml/2006/main";
            XDocument mainDocumentXDoc = document.MainDocumentPart.GetXDocument();

            // pre-atomize the XName objects so that they are not atomized for every item in the collection
            XName commentRangeStart = w + "commentRangeStart";
            XName commentRangeEnd = w + "commentRangeEnd";
            XName commentReference = w + "commentReference";
            mainDocumentXDoc.Descendants()
                .Where(x => x.Name == commentRangeStart || x.Name == commentRangeEnd || x.Name == commentReference)
                .Remove();

            // remove the comment part
            document.MainDocumentPart.DeletePart(document.MainDocumentPart.WordprocessingCommentsPart);

            using (XmlWriter xw =
              XmlWriter.Create(document.MainDocumentPart.GetStream(FileMode.Create, FileAccess.Write)))
                mainDocumentXDoc.Save(xw);
        }
    }
}
