﻿using DocumentFormat.OpenXml.Packaging;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using System.IO.Packaging;
using OpenXmlPowerTools;
using DocumentFormat.OpenXml.Wordprocessing;
using DocumentFormat.OpenXml;
using System.Xml;
using System.Text.RegularExpressions;
using System.IO;
using System.Configuration;

namespace MultiInstanceJournalCleanup
{
    class MissingSections
    {
        //public static List<string> KeywordSeperatorColl = null;

        public static void CheckForMissingSections(string strWordDoc)
        {
            // Check and Split Abstract Para on Keyword //
            CheckAndInsertMissingSections(strWordDoc);
        }

        private static void CheckAndInsertMissingSections(string strWordDoc)
        {
            try
            {
                using (WordprocessingDocument WPD = WordprocessingDocument
                    .Open(strWordDoc, true))
                {
                    SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                    {
                        //RemoveComments = false,//commented by Karan on 06-08-2018
                        RemoveContentControls = true,
                        RemoveEndAndFootNotes = false,
                        RemoveFieldCodes = true,
                        RemoveLastRenderedPageBreak = true,
                        RemovePermissions = true,
                        RemoveProof = true,
                        RemoveRsidInfo = true,
                        RemoveSmartTags = true,
                        RemoveSoftHyphens = false,
                        ReplaceTabsWithSpaces = false,//Developer name :Priyanka Vishwakarma. Date:29_5_2019, Requirement:it removes the indentation from the nested list  ,Integrated By:Vikas sir. 
                    };

                    MarkupSimplifier.SimplifyMarkup(WPD, settings);

                    MainDocumentPart MDP = WPD.MainDocumentPart;

                    Document D = MDP.Document;

                    string secLevelNum = null;

                    int nsecLevelNum = 0;
                    int nPrevsecLevelNum = 0;
                    int nNewSecLevelNum = 0;

                    // Search all Paragraphs that has "AB-TXT" style.
                    foreach (Paragraph P in D.Descendants<Paragraph>().ToList().
                    Where(e => e.ParagraphProperties != null
                        && e.ParagraphProperties.ParagraphStyleId != null))
                    {
                        if (P.HasChildren)
                        {
                            if (P.Descendants<Run>().Count() > 0)
                            {
                                if (P.ParagraphProperties != null)
                                {
                                    if (P.ParagraphProperties.ParagraphStyleId != null)
                                    {
                                        if (P.ParagraphProperties.ParagraphStyleId.Val == "H1" ||
                                            P.ParagraphProperties.ParagraphStyleId.Val == "H2" ||
                                            P.ParagraphProperties.ParagraphStyleId.Val == "H3" ||
                                            P.ParagraphProperties.ParagraphStyleId.Val == "H4" ||
                                            P.ParagraphProperties.ParagraphStyleId.Val == "H5" ||
                                            P.ParagraphProperties.ParagraphStyleId.Val == "H6" ||
                                            P.ParagraphProperties.ParagraphStyleId.Val == "H7")
                                        {
                                            secLevelNum = P.ParagraphProperties.ParagraphStyleId.Val;
                                            secLevelNum = secLevelNum.Replace("H", "");

                                            int n;
                                            bool isnumeric = int.TryParse(secLevelNum, out n);

                                            if (isnumeric)
                                            {
                                                nsecLevelNum = n;

                                                if(nsecLevelNum == 1)
                                                {
                                                    nPrevsecLevelNum = nsecLevelNum;
                                                    goto NextPara;
                                                }

                                                // Need to check if next Section level is greater then available section then what has to be done //
                                                if(nPrevsecLevelNum == 0)
                                                {
                                                    nPrevsecLevelNum = nsecLevelNum;

                                                    // First section heading in the document when the prev section is 0 or not initialized
                                                    if(nsecLevelNum != 1)
                                                    {
                                                        InsertNewSec:
                                                        {

                                                        }

                                                        nNewSecLevelNum++;

                                                        if (nNewSecLevelNum == nsecLevelNum)
                                                        {
                                                            nPrevsecLevelNum = nNewSecLevelNum;
                                                            nNewSecLevelNum = 0;
                                                            goto NextPara;
                                                        }

                                                        if (nNewSecLevelNum > 7)
                                                        {
                                                            nPrevsecLevelNum = nNewSecLevelNum;
                                                            nNewSecLevelNum = 0;
                                                            goto NextPara;
                                                        }

                                                        // Section should always starts with H1
                                                        Paragraph appendAbsractPara = new Paragraph(new ParagraphProperties(new ParagraphStyleId() { Val = "H" + nNewSecLevelNum }));
                                                        Run newrun = new Run(new RunProperties(new Bold()));
                                                        newrun.AppendChild(new Text("") { Space = SpaceProcessingModeValues.Preserve });
                                                        appendAbsractPara.AppendChild(newrun);

                                                        P.InsertBeforeSelf(appendAbsractPara);

                                                        if (nNewSecLevelNum < nsecLevelNum)
                                                            goto InsertNewSec;

                                                        nNewSecLevelNum = 0;

                                                        // Insert new sections till the current section 
                                                    }
                                                }
                                                else
                                                {
                                                    if (nsecLevelNum != nPrevsecLevelNum)
                                                    {
                                                        if(nPrevsecLevelNum < nsecLevelNum)
                                                        {
                                                            RecheckSection:
                                                            {

                                                            }

                                                            int nTmpNum = 0;

                                                            nTmpNum = nPrevsecLevelNum + 1;

                                                            if (nTmpNum > 7)
                                                            {
                                                                nPrevsecLevelNum = nNewSecLevelNum;
                                                                nNewSecLevelNum = 0;
                                                                goto NextPara;
                                                            }

                                                            if (nTmpNum == nsecLevelNum)
                                                            {
                                                                nPrevsecLevelNum = nsecLevelNum;
                                                                goto NextPara;
                                                            }

                                                            nPrevsecLevelNum = nTmpNum;

                                                            // Insert new section //

                                                            // Section should always starts with H1
                                                            Paragraph appendAbsractPara = new Paragraph(new ParagraphProperties(new ParagraphStyleId() { Val = "H" + nPrevsecLevelNum }));
                                                            Run newrun = new Run(new RunProperties(new Bold()));
                                                            newrun.AppendChild(new Text("") { Space = SpaceProcessingModeValues.Preserve });
                                                            appendAbsractPara.AppendChild(newrun);

                                                            P.InsertBeforeSelf(appendAbsractPara);

                                                            goto RecheckSection;

                                                        }
                                                    }
                                                }

                                                nPrevsecLevelNum = nsecLevelNum;
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        NextPara:
                        { };

                    }

                    D.Save();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
