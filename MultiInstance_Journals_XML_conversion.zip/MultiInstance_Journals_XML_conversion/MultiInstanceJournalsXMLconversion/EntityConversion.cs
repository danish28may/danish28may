﻿using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;
using OpenXmlPowerTools;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Xml.Linq;

namespace MultiInstanceJournalsXMLconversion
{
    class EntityConversion
    {
        public static void ConvertEntities(string newDoc)
        {
            GlobalMethods.StrEntityFile = ConfigurationManager.AppSettings.Get("3CMStyleEntityColl");

            List<string> strEntityColl = new List<string>();
            strEntityColl.Clear();
            strEntityColl = GlobalMethods.ReadAndStoreFileValuesInArray(GlobalMethods.StrEntityFile);

            using (WordprocessingDocument WPD = WordprocessingDocument
            .Open(newDoc, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    NormalizeXml = true,
                    RemoveComments = false,
                    RemoveContentControls = true,
                    RemoveEndAndFootNotes = false,
                    RemoveFieldCodes = true,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = true,
                    RemoveHyperlinks = true,
                    AcceptRevisions = true,
                    RemoveBookmarks = true,
                    RemoveGoBackBookmark = true,
                    RemoveWebHidden = true,
                    RemoveMarkupForDocumentComparison = true,
                };

                MarkupSimplifier.SimplifyMarkup(WPD, settings);

                MainDocumentPart MDP = WPD.MainDocumentPart;

                Document D = MDP.Document;

            // Search all Paragraphs that is "TOC1 to TOC3" style.
            foreach (Paragraph P in D.Descendants<Paragraph>().ToList())
            {
                if (P.HasChildren == true)
                {
                    if (P.Descendants<Run>().Count() > 0)
                    {
                        foreach (Run R in P.Descendants<Run>().ToList())
                        {
                            if(R.HasChildren)
                            {
                                foreach (var ele in R.Elements().ToList())
                                {
                                    if(ele.LocalName == "sym")
                                    {
                                            if (ele.HasAttributes)
                                            {
                                                string strFont = null;
                                                string strChar = null;
                                                int nIndex = 0;

                                                foreach (var xa in ele.GetAttributes())
                                                {
                                                    if (xa.LocalName == "font")
                                                    {
                                                        strFont = xa.Value;
                                                    }

                                                    if (xa.LocalName == "char")
                                                    {
                                                        strChar = xa.Value;
                                                    }
                                                }

                                                // Compare the font and the character with configuration 

                                                for (nIndex = 0; nIndex < strEntityColl.Count; nIndex++)
                                                {
                                                    string[] separators = { "<eql>" };
                                                    string[] EntityInfo = strEntityColl[nIndex].Split(separators, StringSplitOptions.RemoveEmptyEntries);

                                                    string lookupFont = null;
                                                    string lookupChar = null;
                                                    string repChar = null;
                                                    if (EntityInfo.Length == 3)
                                                    {
                                                        lookupFont = EntityInfo[0];
                                                        lookupChar = EntityInfo[1];
                                                        repChar = EntityInfo[2];

                                                        if (strFont != null && lookupFont != null && strChar != null && lookupChar != null && strChar == lookupChar)
                                                        {
                                                            if (strFont.ToLower() == lookupFont.ToLower())
                                                            {
                                                                // Font and Character matched with the configuration //
                                                                // Replace the character with the Entity //
                                                                Text T = new Text(repChar);
                                                                ele.InsertAfterSelf(T);
                                                                ele.Remove();
                                                                //MessageBox.Show("Got it.....");
                                                                //temp.Add(repChar);
                                                                break;
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                D.Save();
            }

        }

    }

}
