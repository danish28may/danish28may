﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml.Linq;
using System.Linq;

namespace MultiInstanceJournalsXMLconversion
{
    class GlobalMethods
    {
        public static string StrInFolder = null;
        public static string StrOutFolder = null;
        public static string StrProcessFolder = null;
        public static string StrEntityFile = null;
        //public static bool bIncludeParaInFigCaption = false;
        public static string strXMLOutputrequired = null;//Developer Name:Priyanka Vishwakarma,Date:12-05-2021,Requirement:read content sub job type.
        public static string strSelectedDTDORSchema = ""; //Developer Name:Priyanka Vishwakarma,Date:12-05-2021,Requirement:read content sub job type.
        public static string strArticleID = null;//Developer Name:Priyanka Vishwakarma,Date:12-05-2021,Requirement:read content sub job type.
        public static string strJournalDoi = null;   //strJournalDoi added by priyanka on 26_3_2019 
        public static string strPrintISSN = null;  //strPrintISSN added by priyanka on 26_3_2019
        public static string strJournalInfoLine = null; //JournalInfoLine added by priyanka on 26_3_2019


        public static string DOI = null;
        public static string ISSN = null;
        public static string eISSN = null;
        //public static string VolumeTitle;
        //public static string SeriesTitle;
        //public static string BookTitle;
        //public static string BookSubTitle;
        //public static string Edition;
        //public static string CopyrightNote;
        //public static string CopyrightYear;
        //public static string Publisher;
        //public static string AuthorInfo;
        //public static string EditorInfo;
        public static string ArticleTitle = null;

        public static string ManuscriptID = null;
        public static string ManuscriptNumber = null;
        public static string metaInfoXMLPath = null;
        public static string ArticlePath = null;
        public static string ArticleImagePath = null;
        public static string Volume = null;
        public static string Issue = null;
        public static string FirstPage = null;
        public static string LastPage = null;

        ///new varible declare by Karan on 12-3-2018
        public static string JournalID = null;
        ///end


        public static string InvalidAuthorQuery = null; /*Developer Name:Priyanka Vishwakarma Date:26_11_2019 , Requirement:For handling Invalid Author Queries ,Integrated by:Vikas sir*/

        public static string ArticleType = null;
        public static string ArticleLanguage = null;
        public static string ArticleYear = null;

        ///Added by Karan on 09-07-2018 Start
        public static string strJobTransId = null;
        public static string strDocumentType = null;
        public static string strArticleType = null;////strArticleType Added in globle method by Karan on 18-08-2018
        public static string strServiceType = null;
        public static string strJournalID = null;
        public static string strJournalTitle = null;
        public static string strEISSN = null;
        public static string strPublisherName = null;
        public static string strPublisherLocation = null;
        public static string ArticleID = null;
        public static string strDOI = null;
        public static string strManuscript = null;
        public static string strProjectName = null;
        public static string strChapterPath = null;
        public static string strArticleLanguage = null;
        public static string strlicense = null;
        public static string stropenaccess = null;
        public static string streduprog = null;
        public static string strImagePath = null;//Added by Karan on 11-09-2018 for equation
        public static string strRefNum = null;
        ///Added by Karan on 09-07-2018 End 
        public static string strProjectNameForNumber = null;    //Developer name:Priyanka Vishwakarma ,Date:07_09_2019 ,Requirement:Last Five number should take as manuscript number ,suggested by :Anil sir ,Integrated by:Vikas sir,

        public static List<string> Refsurnames = new List<string>();
        public static List<string> allcitebib = new List<string>();
        public static string strClienName = null;//12_11_2019
        public static string strCpyStat = null;//30-12-19
        public static List<string> symbolentityList = new List<string>();

        public static Dictionary<string, string> equationnumberandid = new Dictionary<string, string>();///Added by vikas on 08-09-2020 for equation linking for informs client

        public static string CheckifParaStartWithNumber(string strParaText)
        {
            string strSearchRegEx = null;
            strSearchRegEx = null;
            strSearchRegEx = @"^[0-9]{1,}\.?[0-9]{1,}\.?[0-9]{1,}?\s|^[0-9]{1,}\.?[0-9]{1,}\.?[0-9]{1,}\.?\s";
            if (GlobalMethods.ValidateRegEx(strParaText, strSearchRegEx) == true)
            {
                string strRetVal = GlobalMethods.RegExSearch(strParaText, strSearchRegEx);

                if (strParaText.StartsWith(strRetVal.Trim()))
                {
                    return strRetVal;
                }
            }

            strSearchRegEx = @"^[0-9]{1,}\.?[0-9]{1,}?\s|^[0-9]{1,}\.?[0-9]{1,}\.?\s";
            if (GlobalMethods.ValidateRegEx(strParaText, strSearchRegEx) == true)
            {
                string strRetVal = GlobalMethods.RegExSearch(strParaText, strSearchRegEx);

                if (strParaText.StartsWith(strRetVal.Trim()))
                {
                    return strRetVal;
                }
            }

            strSearchRegEx = @"^[0-9]{1,}\s|^[0-9]{1,}\.\s";
            if (GlobalMethods.ValidateRegEx(strParaText, strSearchRegEx) == true)
            {
                string strRetVal = GlobalMethods.RegExSearch(strParaText, strSearchRegEx);

                if (strParaText.StartsWith(strRetVal.Trim()))
                {
                    return strRetVal;
                }
            }

            return "";
        }

        public static string RegExSearch(string strDocContent, string strSearchRegEx)
        {
            List<string> strMatchText = new List<string>();

            strMatchText.Clear();

            Regex regexText = new Regex(strSearchRegEx);

            // Match the regular expression pattern against a text string.
            Match m = regexText.Match(strDocContent);

            if (m.Success)
            {
                return m.Value;
            }

            return "";
        }

        public static bool ValidateRegEx(string strDocContent, string strSearchRegEx)
        {
            List<string> strMatchText = new List<string>();

            strMatchText.Clear();

            Regex regexText = new Regex(strSearchRegEx);

            // Match the regular expression pattern against a text string.
            Match m = regexText.Match(strDocContent);

            if (m.Success)
            {
                return true;
            }

            return false;
        }

        public static string TrimStart(string target, string trimString)
        {
            string result = target;
            while (result.StartsWith(trimString))
            {
                result = result.Substring(trimString.Length);
            }

            return result;
        }

        public static string TrimEnd(string input, string suffixToRemove)
        {
            while (input != null && suffixToRemove != null && input.EndsWith(suffixToRemove))
            {
                input = input.Substring(0, input.Length - suffixToRemove.Length);
            }
            return input;
        }

        public static string SentenceCase(string input)
        {
            if (input.Length < 1)
                return input;

            string sentence = input.ToLower();
            return sentence[0].ToString().ToUpper() +
               sentence.Substring(1);
        }


        public static List<string> ReadAndStoreFileValuesInArray(string StyleMappingConfigFile)
        {
            //string[] strStyleMapping = new string[1];
            List<string> strStyleMapping = new List<string>();

            int counter = 0;

            string strLine = null;

            StreamReader sr = new StreamReader(StyleMappingConfigFile);

            strStyleMapping.Clear();

            while ((strLine = sr.ReadLine()) != null)
            {
                if (strLine.StartsWith("//") == false)
                {
                    strStyleMapping.Add(strLine.Trim());
                    counter++;
                }
            }

            sr.Close();

            return strStyleMapping;
        }

        public static void ReadCustomPropertiesXML(string strXMLPath)
        {
            var customProperties = from custProp in XElement.Load(strXMLPath).Elements() select custProp;

            foreach (var property in customProperties)
            {
                if (property.Name.LocalName == "TransactionID")
                {
                    strJobTransId = property.Value;
                    //continue;
                }
               else if (property.Name.LocalName == "DocumentType")
                {
                    strDocumentType = property.Value;
                    //continue;
                }
                else if (property.Name.LocalName == "ServiceType")
                {
                    strServiceType = property.Value;
                   // continue;
                }
                ////new property added in xml on 19-08-2018 Start
                else if (property.Name.LocalName == "ArticleType")
                {
                    strArticleType = property.Value;
                    //continue;
                }
                else if (property.Name.LocalName == "JournalId")
                {
                    strJournalID = property.Value;
                    //continue;
                }
                else if (property.Name.LocalName == "JournalTitle")
                {
                    strJournalTitle = property.Value;
                    //continue;
                }
                else if (property.Name.LocalName == "EISSN")
                {
                    strEISSN = property.Value;
                    //continue;
                }
                else if (property.Name.LocalName == "PublisherName")
                {
                    strPublisherName = property.Value;
                    //continue;
                }
                else if (property.Name.LocalName == "PublisherLocation")
                {
                    strPublisherLocation = property.Value;
                    //continue;
                }
                else if (property.Name.LocalName == "ArticleDOI")
                {
                    strDOI = property.Value;
                    continue;
                }
                else if (property.Name.LocalName == "ArticalManuscript")
                {
                    strManuscript = property.Value;
                    //continue;
                }
                else if (property.Name.LocalName == "ProjectName")
                {
                    //strProjectName = property.Value.Substring(property.Value.LastIndexOf("_") + 1); commented by bhavesh 07-02-2019
                    //Update by Bhavesh --- On 07-02-2019 -- Suggested By Sunil For actual jobName__For Image naming---
                    strProjectName = property.Value;
                     if (!string.IsNullOrEmpty(strProjectName))
                    {

                        strProjectNameForNumber = property.Value;    //07_09_2019

                        if (strProjectNameForNumber.Contains("_") && strProjectNameForNumber.Split('_').Count() > 2)/////changed by priyanka for figure name
                        {
                            strProjectNameForNumber = strProjectName.Substring(strProjectName.IndexOf("_") + 1);
                            strProjectNameForNumber = strProjectName.Substring(strProjectName.IndexOf("_") + 1);
                            strProjectNameForNumber = strProjectName.Substring(strProjectName.IndexOf("_") + 1);
                        }

                        if (!string.IsNullOrEmpty(strProjectNameForNumber))
                        {
                            string OnlyDigit = Regex.Replace(strProjectNameForNumber, "[^0-9]", "");  //Read only number from string name.                   

                            if (OnlyDigit.Length >= 5)
                            {
                                strProjectNameForNumber = OnlyDigit.Substring(OnlyDigit.Length - 5, 5);   //for read last 5 digit 
                            }
                            else if (OnlyDigit.Length == 4)
                            {
                                strProjectNameForNumber = "0" + OnlyDigit;
                            }
                            else if (OnlyDigit.Length == 3)
                            {
                                strProjectNameForNumber = "00" + OnlyDigit;
                            }
                            else if (OnlyDigit.Length == 2)
                            {
                                strProjectNameForNumber = "000" + OnlyDigit;
                            }
                            else if (OnlyDigit.Length == 1)
                            {
                                strProjectNameForNumber = "0000" + OnlyDigit;
                            }
                        }

                        if (strProjectName.Contains("_"))
                        {
                            //strProjectName = property.Value.Substring(property.Value.IndexOf("_"));

                            string[] a = strProjectName.Split('_');
                             if (a.Count() > 3)
                            {
                                string ProjectName = a[0] + "_" + a[1] + "_" + a[2] + "_";
                                strProjectName = strProjectName.Replace(ProjectName, "");

                                //strProjectName = property.Value.Substring(property.Value.LastIndexOf("_") + 1);
                                //continue;
                            }

                        }
                       
                    }

                    //continue;
                }
                else if (property.Name.LocalName == "ChapterPath")
                {
                    strChapterPath = property.Value;
                    //continue;
                }
                else if (property.Name.LocalName == "ArticleLanguage")
                {
                    strArticleLanguage = property.Value;
                    //continue;
                }
                else if (property.Name.LocalName == "license")
                {
                    strlicense = property.Value;
                   // continue;
                }
                else if (property.Name.LocalName == "OpenAccess")
                {
                    stropenaccess = property.Value;
                    //continue;
                }
                else if (property.Name.LocalName == "EduProg")
                {
                    streduprog = property.Value;
                    //continue;
                }
                //Added by Karan on 10-09-2018 Start
                else if (property.Name.LocalName == "ImagePath")
                {
                    strImagePath = property.Value;
                    //continue;
                }
                else if (property.Name.LocalName == "RefType")
                {
                    strRefNum = property.Value;
                    //continue;
                }
                else if (property.Name.LocalName == "JournalDOI")   //added by Priyanka on 26_3_2019 for Journal id Doi in xml
                {
                    strJournalDoi = property.Value;
                    //continue;
                }
                else if (property.Name.LocalName == "PrintISSN")
                {
                    //strPrintISSN = property.Value;
                }
                else if (property.Name.LocalName == "JournalInfoLine")
                {
                    //strJournalInfoLine = property.Value;
                }
                //Developer name:Priyanka vishwakarma ,Date:11_12_2019 ,Requirement:
                else if (property.Name.LocalName == "ClientName")
                {
                    strClienName = property.Value;
                }
                else if (property.Name.LocalName == "CopyRight")
                {
                    strCpyStat = property.Value;
                    // strCopyrightYear = copyrightstat.Value;
                    //continue;
                }
                else if (property.Name.LocalName == "XMLOutputRequired")
                {
                    strXMLOutputrequired = property.Value;
                    continue;
                }
                else if (property.Name.LocalName == "ContentSubJobType") ////Developer Name:Priyanka Vishwakarma ,Date:12-05-2021 ,Requirement:Read contentsubjobtype from properties xml.
                {
                    strSelectedDTDORSchema = property.Value;
                    continue;
                }
                else if (property.Name.LocalName == "ArticleId") ////Developer Name:Priyanka Vishwakarma ,Date:12-05-2021 ,Requirement:Read contentsubjobtype from properties xml.
                {
                    strArticleID = property.Value;
                    continue;
                }
                //else
                //{
                //    strRefNum = "UnNumbered";
                //}
                //Added by Karan on 10-09-2018 End
                ////new property added in xml on 19-08-2018 End 
            }
        }

    }
}
