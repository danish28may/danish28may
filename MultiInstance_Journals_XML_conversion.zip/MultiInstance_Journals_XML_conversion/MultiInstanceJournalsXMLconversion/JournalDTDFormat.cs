﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;

namespace MultiInstanceJournalsXMLconversion
{
    class JournalDTDFormat
    {
        public static XDocument ThiemeJournal30(XDocument xdoc)
        {

            // var ProcessingjobPath = new FileInfo(xmlPath).Directory.Parent.FullName;

            try
            {

                // XDocument xdoc = XDocument.Load(xmlPath);
                //var chapterno = "";

                //XDocumentType doctype = new XDocumentType("book", "-//OASIS//DTD DocBook XML V5.0//EN", "docbook.dtd", null);


                foreach (var aff in xdoc.Descendants("aff").ToList())
                {
                    var affnodes = aff.Descendants("sup").ToList().FirstOrDefault();
                    affnodes.Remove();

                }

                foreach (var aff in xdoc.Descendants().ToList())
                {
                    foreach (var comment1 in aff.Descendants().ToList())
                    {
                        foreach (var processingin in comment1.Nodes().ToList())
                        {
                            var nodetype = processingin.NodeType;
                            if (nodetype.ToString() == "ProcessingInstruction")
                            {
                                processingin.Remove();
                            }
                        }
                    }
                }

                foreach (var subject in xdoc.Descendants("subject").ToList())
                {
                    if (subject.Descendants("b").Count() > 0)
                    {
                        string value = subject.Value;
                        subject.Value = value;
                    }
                }
                foreach (var xref in xdoc.Descendants("xref").ToList())
                {
                    if (xref.Descendants("sup").Count() > 0)
                    {
                        string value = xref.Value;
                        if (value.ToLower().StartsWith("rang"))
                        {
                            string rangval = value.Replace("rang", "");
                            if (xref.HasAttributes)
                            {
                                if (xref.Attribute("idref") != null && (xref.Attribute("idref").Value.StartsWith("JR_rang") || xref.Attribute("idref").Value.StartsWith("BR_rang") || xref.Attribute("idref").Value.StartsWith("OR_rang")))
                                {
                                    string attrval = xref.Attribute("idref").Value.Replace("rang", "");
                                    xref.Attribute("idref").Value = attrval;
                                }
                            }
                            xref.Value = rangval;

                        }
                        else
                        {
                            xref.Value = value;
                        }
                    }
                }

                foreach (var list in xdoc.Descendants("list").ToList())
                {
                    if (list.HasAttributes)
                    {
                        if (list.Attribute("letterwith") != null)
                        {
                            list.Attribute("letterwith").Remove();
                        }
                        if (list.Attribute("lsttype") != null && list.Attribute("lsttype").Value == "circle")
                        {
                            list.Attribute("lsttype").Value = "asterisk";
                        }
                        if (list.Attribute("lsttype") != null && list.Attribute("lsttype").Value == "Upperroman")
                        {
                            list.Attribute("lsttype").Value = "roman";
                        }
                    }
                }

                foreach (var sec1 in xdoc.Descendants("sec1").ToList())
                {
                    if (sec1.HasAttributes)
                    {
                        if (sec1.Attribute("style") != null && sec1.Attribute("style").Value == "appendixData")
                        {
                            sec1.Remove();
                        }
                    }
                }
                foreach (var p in xdoc.Descendants("p").ToList())
                {
                    if (p.HasAttributes)
                    {
                        if (p.Attribute("style") != null)
                        {
                            p.Attribute("style").Remove();
                        }
                    }
                }
                foreach (var td in xdoc.Descendants("td").ToList())
                {
                    if (td.HasAttributes)
                    {
                        if (td.Attribute("align") != null && td.Attribute("align").Value == "both")
                        {
                            td.Attribute("align").Value = "justify";
                        }
                    }
                }
                foreach (var table in xdoc.Descendants("table").ToList())
                {
                    foreach (var emph in table.Descendants("emph").ToList())
                    {
                        if (emph.HasAttributes)
                        {
                            if (emph.Attribute("type") != null && emph.Attribute("type").Value == "bold")
                            {
                                emph.Attribute("type").Remove();
                                emph.Name = "b";

                            }
                            else if (emph.Attribute("type") != null && emph.Attribute("type").Value == "italic")
                            {
                                emph.Attribute("type").Remove();
                                emph.Name = "i";
                            }
                            else if (emph.Attribute("type") != null && emph.Attribute("type").Value == "underline")
                            {
                                emph.Attribute("type").Remove();
                                emph.Name = "u";
                            }
                            else if (emph.Attribute("type") != null && emph.Attribute("type").Value == "bolditalic")
                            {
                                emph.Attribute("type").Remove();
                                emph.Name = "bi";
                            }

                        }
                    }
                }
                foreach (var reftext in xdoc.Descendants("ref-list").ToList())
                {
                    foreach (var middlename in reftext.Descendants("middle-names").ToList())
                    {
                        middlename.Name = "middle-name";
                    }
                }
                foreach (var issue in xdoc.Descendants("issue").ToList())
                {
                    if (issue.Value.Length == 1)
                    {
                        string val = issue.Value;
                        issue.Value = "0" + val;
                    }

                }
                foreach (var reftext in xdoc.Descendants("ref-list").ToList())
                {
                    foreach (var txt in xdoc.Descendants("txt").ToList())
                    {
                        if (txt.Descendants("dummy").ToList().Count() > 0)
                        {
                            var dummytxt = txt.Descendants("dummy").ToList();
                            foreach (var t in dummytxt.ToList())
                            {
                                string val = t.Value;
                                XText text = new XText(val);
                                t.AddAfterSelf(text);
                                t.Remove();
                            }

                        }
                    }
                }
                foreach (var reftext in xdoc.Descendants("ref-list").ToList())
                {
                    foreach (var uri in xdoc.Descendants("uri").ToList())
                    {

                        string val = uri.Value;
                        XText text = new XText(val);
                        uri.AddAfterSelf(text);
                        uri.Remove();

                    }
                }

                foreach (var formula in xdoc.Descendants("formula").ToList())
                {
                    formula.Remove();
                }
                foreach (var td in xdoc.Descendants("disp-formula-group").ToList())
                {
                    if (td.HasAttributes)
                    {
                        if (td.Attribute("number") != null)
                        {
                            td.Attribute("number").Remove();
                        }
                    }
                }
                foreach (var rrh in xdoc.Descendants("rrh").ToList())
                {
                    rrh.Remove();
                }
                foreach (var table in xdoc.Descendants("table").ToList())
                {
                    if (table.Descendants("tfoot").Count() == 1)
                    {
                        var tfootele = table.Descendants("tfoot").ToList().FirstOrDefault();

                        var tablebody = table.Descendants("tbody").ToList().FirstOrDefault();
                        if (tablebody != null)
                        {
                            tablebody.AddBeforeSelf(tfootele);
                        }
                        tfootele.Remove();
                    }
                }

                foreach (var iconfig in xdoc.Descendants("iconflict").ToList())
                {
                    var permissionele = xdoc.Descendants("permissions").ToList().FirstOrDefault();
                    if (permissionele != null)
                    {
                        permissionele.AddBeforeSelf(iconfig);
                        iconfig.Remove();
                    }
                }
                //For funding group
                foreach (var sec5 in xdoc.Descendants("sec5").ToList())
                {
                    if (sec5.Descendants("award-group").Count() > 0)
                    {
                        //XElement funding_grp = new XElement("funding-group");
                        XElement funding_stmt = new XElement("funding-statement");

                        var title = sec5.Descendants("title").ToList().FirstOrDefault();
                        if (title != null)
                        {
                            XElement bele = new XElement("b");
                            bele.Add(title.Value);
                            funding_stmt.Add(bele);
                            title.Remove();

                        }

                        var p = sec5.Descendants("p").ToList();
                        foreach (var pele in p.ToList())
                        {
                            funding_stmt.Add(pele.Value);
                            p.Remove();
                        }
                        sec5.Add(funding_stmt);
                        sec5.Name = "funding-group";
                        var articlemeta = xdoc.Descendants("article-meta").ToList().FirstOrDefault();
                        if (articlemeta != null)
                        {
                            articlemeta.Add(sec5);
                            sec5.Remove();
                        }

                    }
                }
                List<XElement> sec5headingList = new List<XElement>();
                foreach (var sec5 in xdoc.Descendants("sec5").ToList())
                {
                    if (sec5.Descendants("title").Count() > 0)
                    {
                        if (sec5.Descendants("title").ToList().FirstOrDefault().Value.ToLower() == "note"
                            || sec5.Descendants("title").ToList().FirstOrDefault().Value.ToLower() == "clinical significance"
                            || sec5.Descendants("title").ToList().FirstOrDefault().Value.ToLower() == "source(s) of support"
                             || sec5.Descendants("title").ToList().FirstOrDefault().Value.ToLower() == "source of support")
                        {
                            foreach (var titleele in sec5.Descendants("title").ToList())
                            {
                                sec5headingList.Add(titleele);
                            }
                            foreach (var pele in sec5.Descendants("p").ToList())
                            {
                                sec5headingList.Add(pele);
                            }
                        }
                    }
                }
                if (sec5headingList.Count() > 0)
                {
                    bool configadd = false;
                    var iconf = xdoc.Descendants("iconflict").ToList().FirstOrDefault();
                    if (iconf != null)
                    {
                        //sec5headingList.Reverse();
                        foreach (var ele in sec5headingList.ToList())
                        {
                            iconf.Add(ele);
                            configadd = true;
                        }
                    }
                    if (configadd)
                    {
                        foreach (var sec5 in xdoc.Descendants("sec5").ToList())
                        {
                            if (sec5.Descendants("title").Count() > 0)
                            {
                                if (sec5.Descendants("title").ToList().FirstOrDefault().Value.ToLower() == "note"
                                    || sec5.Descendants("title").ToList().FirstOrDefault().Value.ToLower() == "clinical significance"
                                    || sec5.Descendants("title").ToList().FirstOrDefault().Value.ToLower() == "source(s) of support"
                                     || sec5.Descendants("title").ToList().FirstOrDefault().Value.ToLower() == "source of support")
                                {
                                    sec5.Remove();
                                }
                            }
                        }
                    }
                }
                foreach (var fngroupele in xdoc.Descendants("fn-group").ToList())
                {
                    foreach (var p in fngroupele.Descendants("p").ToList())
                    {
                        if (p.Parent != null && p.Parent.Name != "fn")
                        {
                            p.Remove();

                        }

                    }
                }

                foreach (var ack in xdoc.Descendants("ack").ToList())
                {
                    var backele = xdoc.Descendants("back").ToList().FirstOrDefault();
                    if (backele != null)
                    {
                        backele.AddFirst(ack);
                        ack.Remove();
                    }
                }
                foreach (var supmat in xdoc.Descendants("supmat").ToList())
                {
                    var refele = xdoc.Descendants("ref-list").ToList().FirstOrDefault();
                    if (refele != null)
                    {
                        refele.AddBeforeSelf(supmat);
                        supmat.Remove();
                    }
                }





                // xdoc = new XDocument(doctype, xdoc.Root);
                return xdoc;
            }
            catch (Exception ex)
            {
                return xdoc;

            }
        }
        public static XDocument NLMDTDXML(XDocument doc)
        {
           

            if (doc.Root.HasAttributes)
            {
                doc.Root.Attributes().ToList().Remove();

                XAttribute articlety = new XAttribute("article-type", "research-article");
                XAttribute dtdnm = new XAttribute("dtd-version", "1.1d1");
                XAttribute mml = new XAttribute(XNamespace.Xmlns + "mml", "http://www.w3.org/1998/Math/MathML");
                XAttribute xlink = new XAttribute(XNamespace.Xmlns + "xlink", "http://www.w3.org/1999/xlink");
                XAttribute xsi = new XAttribute(XNamespace.Xmlns + "xsi", "http://www.w3.org/2001/XMLSchema-instance");
                doc.Root.Add(articlety);
                doc.Root.Add(dtdnm);
                doc.Root.Add(mml);
                doc.Root.Add(xlink);
                doc.Root.Add(xsi);

                foreach (var xele in doc.Descendants().ToList())
                {
                    if (xele.Name == "journal-meta" || xele.Name == "kwd-group" || xele.Name == "back")
                    {
                        if (xele.HasAttributes)
                        {
                            xele.Attributes().Remove();
                        }
                    }
                }

                foreach (var xele in doc.Descendants().Nodes().Where(x => x.NodeType == XmlNodeType.Comment))
                {
                    xele.Remove();
                }

            }
            XDocumentType doctype = new XDocumentType("article", "-//NLM//DTD JATS (Z39.96) Journal Publishing DTD v1.1d1 20130915//EN", "JATS-journalpublishing1.dtd", null);
            var xdoc1 = new XDocument(doctype, doc.Root);
            return xdoc1;

           
        }
        public static  XDocument NLMDTDConversion(XDocument doc)////Added by vikas on 23-10-2020 for Sage client
        {
            
            var journalid = "";
            var articleid = "";
            XNamespace xlink = "http://www.w3.org/1999/xlink";
            XNamespace xmml = "http://www.w3.org/1998/Math/MathML";

            if (doc.Root.HasAttributes)
            {
                doc.Root.Attributes().ToList().Remove();

                XAttribute lang = new XAttribute(XNamespace.Xml + "lang", "EN");
                XAttribute articlety = new XAttribute("article-type", "research-article");
                XAttribute dtdnm = new XAttribute("dtd-version", "1.1d1");
                XAttribute mml = new XAttribute(XNamespace.Xmlns + "mml", "http://www.w3.org/1998/Math/MathML");
                XAttribute xlink1 = new XAttribute(XNamespace.Xmlns + "xlink", "http://www.w3.org/1999/xlink");
                doc.Root.Add(lang);
                doc.Root.Add(dtdnm);
                doc.Root.Add(mml);
                doc.Root.Add(xlink1);
                doc.Root.Add(articlety);


                foreach (var xele in doc.Descendants().ToList())
                {
                    if (xele.Name == "kwd-group" || xele.Name == "back" || xele.Name == "p")
                    {
                        if (xele.HasAttributes)
                        {
                            xele.Attributes().Remove();
                        }
                    }
                }

                foreach (var xele in doc.Descendants().Nodes().Where(x => x.NodeType == XmlNodeType.Comment))
                {
                    xele.Remove();
                }

            }
            XDocumentType doctype = new XDocumentType("article", "-//NLM//DTD JATS (Z39.96) Journal Publishing DTD v1.1d1 20130915//EN", "JATS-journalpublishing1.dtd", null);
            var xdoc1 = new XDocument(doctype, doc.Root);          
           

            if (!string.IsNullOrEmpty(GlobalMethods.strJournalID))
            {
                journalid = GlobalMethods.strJournalID;
            }
            if (!string.IsNullOrEmpty(GlobalMethods.strArticleID))
            {
                articleid = GlobalMethods.strArticleID;
            }
            ///Journal-Meat Start/////
            var docjournalmeta = doc.Descendants("journal-meta");
            if (docjournalmeta.Count() > 0)
            {
                foreach (var docmetatag in doc.Descendants("journal-meta").Descendants().ToList())
                {
                    if (docmetatag.Name == "journal-id" && docmetatag.HasAttributes && docmetatag.Attribute("journal-id-type") != null && docmetatag.Attribute("journal-id-type").Value == "doi")
                    {
                        docmetatag.Attribute("journal-id-type").Value = "publisher-id";
                        docmetatag.Value = journalid;
                    }
                    if (docmetatag.Name == "journal-id" && docmetatag.HasAttributes && docmetatag.Attribute("journal-id-type") != null && docmetatag.Attribute("journal-id-type").Value == "pmc")
                    {
                        docmetatag.Attribute("journal-id-type").Value = "hwp";
                        docmetatag.Value = "sp" + journalid.ToLower();
                    }
                    if (docmetatag.Name == "journal-id" && docmetatag.HasAttributes && docmetatag.Attribute("journal-id-type") != null && docmetatag.Attribute("journal-id-type").Value == "publisher")
                    {
                        docmetatag.Remove();
                    }
                    if (docmetatag.Name == "issn" && docmetatag.HasAttributes && docmetatag.Attribute("pub-type") != null && docmetatag.Attribute("pub-type").Value == "print")
                    {
                        docmetatag.Remove();
                    }
                    if (docmetatag.Name == "issn" && docmetatag.HasAttributes && docmetatag.Attribute("pub-type") != null && docmetatag.Attribute("pub-type").Value == "e-issn")
                    {
                        docmetatag.Attribute("pub-type").Value = "ppub";
                    }
                    if (docmetatag.Name == "publisher-name")
                    {
                        if (GlobalMethods.strClienName.ToLower() == "sage")
                        {
                            docmetatag.Value = "SAGE Publications";
                        }
                        else if (GlobalMethods.strClienName.ToLower().ToLower() == "csiro")
                        {
                            docmetatag.Value = "CSIRO Publications";
                        }
                        else
                        {
                            docmetatag.Value = "DiTech Publications";
                        }
                    }
                    if (docmetatag.Name == "publisher-loc")
                    {
                        if (GlobalMethods.strClienName.ToLower().ToLower() == "sage")
                        {
                            docmetatag.Value = "Sage CA: Los Angeles, CA";
                        }
                        else if (GlobalMethods.strClienName.ToLower().ToLower() == "csiro")
                        {

                            docmetatag.Value = "CSIRO, Australia";
                        }
                        else
                        {

                            docmetatag.Value = "DiTech, USA";
                        }
                    }
                }
                /////Journal-Meta End////

                ////Article-Meta start/////
                var docarticlemeta = doc.Descendants("article-meta");
                if (docarticlemeta.Count() > 0)
                {
                    foreach (var docmetatag in doc.Descendants("article-meta").Descendants().ToList())
                    {
                        if (docmetatag.Name == "article-id" && docmetatag.HasAttributes && docmetatag.Attribute("pub-id-type") != null && docmetatag.Attribute("pub-id-type").Value == "manuscript")
                        {
                            docmetatag.Attribute("pub-id-type").Value = "publisher-id";
                            docmetatag.Value = articleid.Replace("/", "_");

                            var articlecategories = new XElement("article-categories");
                            var subjgroup = new XElement("subj-group", new XAttribute("subj-group-type", "heading"));
                            var subject = new XElement("subject", "Articles");

                            subjgroup.Add(subject);
                            articlecategories.Add(subjgroup);

                            docmetatag.AddAfterSelf(articlecategories);

                        }
                        if (docmetatag.Name == "article-title")
                        {
                            var valuetitle = docmetatag.Value;
                            if (valuetitle.Contains(":"))
                            {
                                var newtitlevalue = valuetitle.Split(':')[0];
                                var halftitle = "";
                                foreach (var hti in valuetitle.Split(':').Skip(1).ToList())
                                {
                                    halftitle += hti + ":";
                                }
                                if (halftitle.Trim() != "")
                                {
                                    var subtitle = new XElement("subtitle", halftitle.TrimEnd(':').Trim());
                                    docmetatag.AddAfterSelf(subtitle);
                                }
                                if (newtitlevalue.Trim() != "")
                                {
                                    docmetatag.Value = newtitlevalue.Trim();
                                }
                            }
                            else
                            {
                                docmetatag.Value = valuetitle.Trim();
                            }
                        }
                    }
                }

                ////Contrib-group Start///

                var doccontribgroups = doc.Descendants("contrib-group");
                int cnt = 0;
                foreach (var contribgroup in doccontribgroups)
                {
                    foreach (var contrib in contribgroup.Descendants())
                    {
                        if (contrib.Name == "contrib")
                        {
                            cnt++;
                        }
                        if (cnt == 1)
                        {
                            var middlename = "";


                            if (contrib.Name == "contrib" && contrib.HasAttributes && contrib.Attribute("contrib-type") != null && contrib.Attribute("contrib-type").Value == "equal-contrib")
                            {
                                contrib.Attribute("contrib-type").Value = "author";

                                if (contrib.Descendants("middle-name").Count() > 0)
                                {
                                    middlename = contrib.Descendants("middle-name").FirstOrDefault().Value;
                                    contrib.Descendants("middle-name").FirstOrDefault().Remove();
                                }
                            }
                            if (contrib.Name == "contrib" && contrib.HasAttributes && contrib.Attribute("corresp") == null)
                            {
                                contrib.Add(new XAttribute("corresp", "yes"));
                            }
                            if (contrib.Name == "given-names")
                            {
                                if (middlename.Trim() != "")
                                    contrib.Value = contrib.Value + " " + middlename;
                            }
                            if (contrib.Name == "xref" && contrib.HasAttributes && contrib.Attribute("idref") != null && contrib.Attribute("idref").Value.StartsWith("AF_"))
                            {
                                var valueatt = contrib.Attribute("idref").Value;
                                contrib.Attribute("idref").Remove();

                                contrib.Add(new XAttribute("ref-type", "aff"));
                                contrib.Add(new XAttribute("rid", valueatt.Replace("AF_", "aff")));


                                var xref = new XElement("xref", new XAttribute("ref-type", "corresp"), new XAttribute("rid", "corresp" + valueatt.Replace("AF_", "")));

                                contrib.AddAfterSelf(xref);
                            }
                        }
                        else
                        {
                            var middlename = "";

                            foreach (var contribn in contribgroup.Descendants())
                            {
                                if (contrib.Name == "contrib" && contrib.HasAttributes && contrib.Attribute("contrib-type") != null && contrib.Attribute("contrib-type").Value == "equal-contrib")
                                {
                                    contrib.Attribute("contrib-type").Value = "author";

                                    if (contrib.Descendants("middle-name").Count() > 0)
                                    {
                                        middlename = contrib.Descendants("middle-name").FirstOrDefault().Value;
                                        contrib.Descendants("middle-name").FirstOrDefault().Remove();
                                    }
                                }

                                if (contrib.Name == "given-names")
                                {
                                    if (middlename.Trim() != "")
                                        contrib.Value = contrib.Value + " " + middlename;
                                }
                                if (contrib.Name == "xref" && contrib.HasAttributes && contrib.Attribute("idref") != null && contrib.Attribute("idref").Value.StartsWith("AF_"))
                                {
                                    var valueatt = contrib.Attribute("idref").Value;
                                    contrib.Attribute("idref").Remove();

                                    contrib.Add(new XAttribute("ref-type", "aff"));
                                    contrib.Add(new XAttribute("rid", valueatt.Replace("AF_", "aff")));
                                }
                            }

                        }
                        if (contribgroup == doccontribgroups.LastOrDefault())
                        {
                            var bodytitletags = doc.Descendants("body").Descendants("title");

                            if (bodytitletags.Any(x => x.Value.ToLower().Replace(" ", "") == "briefbiographicalstatement"))
                            {
                                var biosection = bodytitletags.Where(x => x.Value.ToLower().Replace(" ", "") == "briefbiographicalstatement").LastOrDefault().Parent;
                                bodytitletags.Where(x => x.Value.ToLower().Replace(" ", "") == "briefbiographicalstatement").LastOrDefault().Value = "Author Biography";
                                if (biosection.Name.ToString().StartsWith("sec"))
                                {
                                    biosection.Name = "bio";
                                    var newbiosection = biosection;
                                    biosection.Remove();
                                    doccontribgroups.FirstOrDefault().Add(newbiosection);

                                    //bodytitletags.Where(x => x.Value.ToLower().Replace(" ", "") == "briefbiographicalstatement").LastOrDefault().Parent.Remove();
                                }
                            }
                            else if (bodytitletags.Any(x => x.Value.ToLower().Replace(" ", "") == "authorbios:"))
                            {
                                var biosection = bodytitletags.Where(x => x.Value.ToLower().Replace(" ", "") == "authorbios:").LastOrDefault().Parent;
                                bodytitletags.Where(x => x.Value.ToLower().Replace(" ", "") == "authorbios:").LastOrDefault().Value = "Author Biographies";

                                if (biosection.Name.ToString().StartsWith("sec"))
                                {
                                    biosection.Name = "bio";
                                    var newbiosection = biosection;
                                    biosection.Remove();
                                    doccontribgroups.FirstOrDefault().Add(newbiosection);

                                    //bodytitletags.Where(x => x.Value.ToLower().Replace(" ", "") == "briefbiographicalstatement").LastOrDefault().Parent.Remove();
                                }
                            }
                            else if (bodytitletags.Any(x => x.Value.ToLower().Replace(" ", "") == "bio:"))
                            {
                                var biosection = bodytitletags.Where(x => x.Value.ToLower().Replace(" ", "") == "bio:").LastOrDefault().Parent;
                                bodytitletags.Where(x => x.Value.ToLower().Replace(" ", "") == "bio:").LastOrDefault().Value = "Author Biography";

                                if (biosection.Name.ToString().StartsWith("sec"))
                                {
                                    biosection.Name = "bio";
                                    var newbiosection = biosection;
                                    biosection.Remove();
                                    doccontribgroups.FirstOrDefault().Add(newbiosection);

                                    //bodytitletags.Where(x => x.Value.ToLower().Replace(" ", "") == "briefbiographicalstatement").LastOrDefault().Parent.Remove();
                                }
                            }


                        }
                    }
                }


                ////Contrib-group End///
                ///////Author notes///


                var docauthornotes = doc.Descendants("author-notes");

                foreach (var authornote in docauthornotes.Descendants().ToList())
                {
                    var corresp = new XElement("corresp", new XAttribute("id", "corresp01"));
                    int correspcnt = 0;
                    if (authornote.Name == "title")
                    {
                        authornote.Remove();
                    }
                    else if (authornote.Name == "corresp")
                    {
                        correspcnt++;

                        if (correspcnt == 1)
                        {
                            authornote.AddBeforeSelf(corresp);
                            if (!authornote.Value.Contains("@"))
                                corresp.Value += authornote.Value.Replace(",,", ",");
                            else if (authornote.Value.Contains("@"))
                            {
                                foreach (var email in authornote.Nodes())
                                {
                                    if (email.NodeType == System.Xml.XmlNodeType.Element)
                                    {
                                        var eml = ((XElement)email);
                                        if (eml.Name == "email")
                                        {
                                            if (eml.HasAttributes)
                                            {
                                                eml.Attributes().ToList().Remove();
                                            }
                                            corresp.Add(email);
                                        }
                                        else if (eml.Value != ":")
                                        {
                                            corresp.Value += eml.Value.Replace(",,", ",");
                                        }
                                    }
                                    else if (email.NodeType == System.Xml.XmlNodeType.Text)
                                    {
                                        corresp.Value += " " + ((XText)email).Value;
                                    }
                                }
                            }
                        }
                        authornote.Remove();
                    }


                }
                /////Author notes////
                /////Afflation Start////
                var docaffilations = doc.Descendants("aff");
                int cntaff = 0;
                foreach (var aff in docaffilations.ToList())
                {
                    cntaff++;
                    var newaff = new XElement("aff", new XAttribute("id", "aff0" + cntaff.ToString()));

                    foreach (var affch in aff.Elements())
                    {
                        if (affch.Name == "institution")
                        {
                            foreach (var child in affch.Nodes())
                            {
                                if (child.NodeType == System.Xml.XmlNodeType.Element)
                                {
                                    if (((XElement)child).Name == "sup")
                                    {
                                        ((XElement)child).Name = "label";
                                        newaff.Add(child);
                                    }
                                    else
                                    {
                                        newaff.Add(child);
                                    }
                                }
                                else
                                {
                                    newaff.Add(child);
                                }
                            }
                        }
                    }
                    if (docauthornotes.Count() > 0)
                    {
                        docauthornotes.FirstOrDefault().AddBeforeSelf(newaff);
                        aff.Remove();
                    }
                    else
                    {
                        aff.AddBeforeSelf(newaff);
                        aff.Remove();
                    }
                }

                ///Add pub-date//
                var pubdate = new XElement("pub-date", new XAttribute("pub-type", "epub-ppub"));
                var month = new XElement("month", "00");
                var year = new XElement("year", "0000");
                pubdate.Add(month);
                pubdate.Add(year);
                var volume = new XElement("volume", "00");
                var issue = new XElement("issue", "0");
                var fpage = new XElement("fpage", "000");
                var lpage = new XElement("lpage", "000");


                if (docauthornotes.Count() > 0)
                {
                    docauthornotes.FirstOrDefault().AddAfterSelf(pubdate);
                    pubdate.AddAfterSelf(lpage);
                    pubdate.AddAfterSelf(fpage);
                    pubdate.AddAfterSelf(issue);
                    pubdate.AddAfterSelf(volume);
                }
                else if (doc.Descendants("aff").Count() > 0)
                {
                    doc.Descendants("aff").FirstOrDefault().AddAfterSelf(pubdate);
                    pubdate.AddAfterSelf(lpage);
                    pubdate.AddAfterSelf(fpage);
                    pubdate.AddAfterSelf(issue);
                    pubdate.AddAfterSelf(volume);

                }
                else if (doccontribgroups.Count() > 0)
                {
                    doccontribgroups.FirstOrDefault().AddAfterSelf(pubdate);
                    pubdate.AddAfterSelf(lpage);
                    pubdate.AddAfterSelf(fpage);
                    pubdate.AddAfterSelf(issue);
                    pubdate.AddAfterSelf(volume);
                }
                ///End//

                ////Affilation End////
                ///////permission//
                var permissions = new XElement("permissions");
                var copyrightstatement = new XElement("copyright-statement", "© The Author(s)" + DateTime.Now.Year.ToString());
                var copyrightyear = new XElement("copyright-year", DateTime.Now.Year.ToString());
                var copyrightholder = new XElement("copyright-holder", new XAttribute("content-type", "sage"), "SAGE Publications");
                permissions.Add(copyrightstatement);
                permissions.Add(copyrightyear);
                permissions.Add(copyrightholder);
                if (doc.Descendants("permissions").Count() == 0)
                {
                    lpage.AddAfterSelf(permissions);
                }
                ////End///
                
                    if (doc.Descendants("abstract").Count() > 0)
                {
                    doc.Descendants("abstract").Descendants("title").Remove();
                }
                if (doc.Descendants("kwd-group").Count() > 0)
                {
                    doc.Descendants("kwd-group").Descendants("title").Remove();
                }
                foreach(var kywd in doc.Descendants("kwd-group").ToList())
                {
                    if (kywd.Descendants().ToList().Count() == 0)
                    {
                        kywd.Remove();
                    }
                }

                ////start custom-meta group
                var custommetagroup = new XElement("custom-meta-group");
                var custommeta = new XElement("custom-meta");
                var metaname = new XElement("meta-name", "typesetter");
                var metavalue = new XElement("meta-value", "ts3");
                custommeta.Add(metaname);
                custommeta.Add(metavalue);
                custommetagroup.Add(custommeta);
                if (docarticlemeta.Count() > 0)
                {
                    docarticlemeta.FirstOrDefault().Add(custommetagroup);
                }
                //////End//////

                ////Article-Meta start/////

                /////////Start Body-Matter/////

                if (doc.Descendants("body").Count() == 1)
                {
                    if (doc.Descendants("body").Descendants("sec1").Count() >= 1)
                    {
                        /////Start section without title///
                        foreach (var sec1 in doc.Descendants("body").Descendants("sec1").ToList())
                        {
                            if (sec1.Elements().Any(x => x.Name == "title") == false)
                            {
                                sec1.Elements().ToList().ForEach(x =>
                                {
                                    sec1.AddBeforeSelf(x);
                                });
                                sec1.Remove();
                            }
                            sec1.Name = "sec";
                        }
                    }
                    /////End section without title///
                    ///////For multi section///
                    foreach (var sec2 in doc.Descendants("body").Descendants("sec2").ToList())
                    {
                        if (sec2.Elements().Any(x => x.Name == "title") == false)
                        {
                            foreach (var sec3 in sec2.Descendants("sec3").ToList())
                            {
                                if (sec3.Elements().Any(x => x.Name == "title") == false)
                                {
                                    foreach (var sec4 in sec3.Descendants("sec4").ToList())
                                    {
                                        if (sec4.Elements().Any(x => x.Name == "title") == false)
                                        {
                                            foreach (var sec5 in sec4.Descendants("sec5").ToList())
                                            {
                                                sec2.AddBeforeSelf(sec5);
                                            }
                                            sec2.Remove();
                                            goto next;
                                        }
                                    }
                                }
                            }

                        }
                    next: { }
                    }
                    /////End////
                    /////Start section level 4 creation///
                    foreach (var bold in doc.Descendants("p").Descendants("b").ToList())
                    {
                        if (bold.Value.Trim().EndsWith(".") && bold.PreviousNode == null)
                        {
                            var section = new XElement("sec");
                            var title = new XElement("title", bold.Value.TrimEnd('.'));
                            section.Add(title);
                            var parentbold = bold.Parent;
                            bold.Remove();
                            if (parentbold.Name == "p")
                            {
                                section.Add(parentbold);
                                parentbold.AddBeforeSelf(section);
                                parentbold.Remove();
                            }

                        }
                    }
                    foreach (var bolditalic in doc.Descendants("p").Descendants("bi").ToList())
                    {
                        if (bolditalic.Value.Trim().EndsWith(".") && bolditalic.PreviousNode == null)
                        {
                            var section = new XElement("sec");
                            var title = new XElement("title", bolditalic.Value.TrimEnd('.'));
                            section.Add(title);
                            var parentbold = bolditalic.Parent;
                            bolditalic.Remove();
                            if (parentbold.Name == "p")
                            {
                                section.Add(parentbold);
                                parentbold.AddBeforeSelf(section);
                                parentbold.Remove();
                            }
                        }

                    }
                    /////End section level 4 creation///

                    /////Start listing creation///
                    var listcnt = 0;
                    foreach (var list in doc.Descendants("list").ToList())
                    {
                        listcnt++;
                        if (list.HasAttributes && list.Attribute("lsttype") != null)
                        {
                            if (list.Attribute("lsttype").Value == "number")
                            {
                                list.Attribute("lsttype").Remove();
                                list.Add(new XAttribute("list-type", "num"));
                            }
                            else if (list.Attribute("lsttype").Value == "bullet")
                            {
                                list.Attribute("lsttype").Remove();
                                list.Add(new XAttribute("list-type", "bullet"));
                            }
                        }
                        list.Add(new XAttribute("id", "L" + listcnt.ToString()));
                    }
                    /////End listing creation///

                    /////Start figure creation///
                    int figurecnt = 0;
                    foreach (var figgroup in doc.Descendants("fig").ToList())
                    {
                        figurecnt++;
                        var figure = new XElement("fig", new XAttribute("id", "F" + figurecnt.ToString()));
                        var figp = 0;
                        var graphics = new XElement("graphic");
                        var captiontfn = new XElement("caption");

                        if (figgroup.Descendants("ext-link").Count() > 0)
                        {
                            graphics.Add(new XAttribute(xlink + "href", figgroup.Descendants("ext-link").FirstOrDefault().Attribute("href").Value));
                        }
                        foreach (var figpara in figgroup.Descendants("p").ToList())
                        {
                            figp++;
                            if (figp == 1)
                            {
                                var nodecnt = 0;
                                var caption = new XElement("caption");
                                var p = new XElement("p");
                                caption.Add(p);
                                foreach (var paranode in figpara.Nodes().ToList())
                                {
                                    nodecnt++;


                                    if (nodecnt == 1 && paranode.NodeType == System.Xml.XmlNodeType.Element)
                                    {
                                        var label = new XElement("label", ((XElement)paranode).Value);
                                        figure.Add(label);
                                        figure.Add(caption);
                                        figure.Add(graphics);


                                    }
                                    else
                                    {
                                        if (paranode.NodeType == System.Xml.XmlNodeType.Element)
                                        {
                                            p.Add(((XElement)paranode).Value);
                                        }
                                        else if (paranode.NodeType == System.Xml.XmlNodeType.Text)
                                        {
                                            p.Add(((XText)paranode).Value);
                                        }
                                        else
                                        {
                                            p.Add(paranode);
                                        }
                                    }
                                }
                            }
                            else
                            {
                                var p = new XElement("p");
                                var italic = new XElement("italic");
                                var italicpara = false;
                                foreach (var paranode in figpara.Nodes().ToList())
                                {
                                    ///figpara.Elements().Count() conndition added by vikas on 23-04-2021
                                    if (figpara.Elements().Count() > 0 && figpara.Elements().FirstOrDefault().Name == "i" && paranode.NodeType == System.Xml.XmlNodeType.Element && figpara.Elements().FirstOrDefault().Name == ((XElement)paranode).Name)
                                    {
                                        italic = new XElement("italic");
                                        italic.Value = ((XElement)paranode).Value;
                                        italicpara = true;
                                        p.Add(italic);
                                    }
                                    else if (paranode.NodeType == System.Xml.XmlNodeType.Element && ((XElement)paranode).Name == "i" && italicpara)
                                    {
                                        italic.Value += ((XElement)paranode).Value;
                                    }
                                    else
                                    {
                                        p.Add(paranode);
                                        italicpara = false;
                                    }
                                }
                                captiontfn.Add(p);
                                graphics.Add(captiontfn);
                            }
                        }
                        figgroup.AddBeforeSelf(figure);
                        figgroup.Remove();
                    }
                    /////End figure creation///

                    /////Start table creation///
                    var tablecnt = 0;
                    foreach (var table in doc.Descendants("body").Descendants("table").ToList())
                    {
                        tablecnt++;
                        var tablewrap = new XElement("table-wrap");
                        tablewrap.Add(new XAttribute("id", "T" + tablecnt.ToString()));
                        if (table.HasAttributes)
                        {
                            table.Attributes().ToList().Remove();

                            table.Add(new XAttribute("frame", "void"));
                            table.Add(new XAttribute("rules", "groups"));
                        }
                        ////th para///
                        foreach (var th in table.Descendants("th").ToList())
                        {
                            foreach (var p in th.Descendants("p").ToList())
                            {
                                foreach (var text in p.Nodes())
                                {
                                    p.AddAfterSelf(text);
                                }
                                p.Remove();
                            }
                        }
                        ////td para///
                        foreach (var td in table.Descendants("td").ToList())
                        {
                            foreach (var p in td.Descendants("p").ToList())
                            {
                                foreach (var text in p.Nodes())
                                {
                                    p.AddAfterSelf(text);
                                }
                                p.Remove();
                            }
                        }
                        var newtable = table;

                        foreach (var label in table.Descendants("label").ToList())
                        {
                            var newlabel = label;
                            newlabel.Value = newlabel.Value.Trim();
                            tablewrap.Add(newlabel);
                            label.Remove();
                        }
                        foreach (var caption in table.Descendants("caption").ToList())
                        {
                            var newcaption = caption;
                            tablewrap.Add(caption);
                            caption.Remove();
                        }


                        var tfoot = new XElement("table-wrap-foot");
                        ////tfoot para///
                        foreach (var tf in table.Descendants("tfoot").ToList())
                        {

                            var tp = 0;
                            foreach (var p in tf.Descendants("td").ToList())
                            {
                                tp++;
                                var tfootfootnt = new XElement("fn", new XAttribute("id", "TFN" + tablecnt.ToString()));
                                var tfootpara = new XElement("p");
                                tfootfootnt.Add(tfootpara);
                                tfoot.Add(tfootfootnt);
                                foreach (var text in p.Nodes())
                                {
                                    tfootpara.Add(text);
                                }
                                p.Remove();
                            }


                            tf.Remove();
                        }
                        tablewrap.Add(newtable);
                        if (tfoot.Descendants().Count() > 0)
                        {
                            tablewrap.Add(tfoot);
                        }
                        table.AddAfterSelf(tablewrap);
                        table.Remove();
                    }


                    /////End table creation///

                    ////Start Quote creation//
                    ////single para
                    foreach (var quote in doc.Descendants("quote").Where(x => x.Elements().Count() == 1))
                    {
                        quote.Name = "boxed-text";
                    }
                    ////Multi-para
                    foreach (var quote in doc.Descendants("quote").Where(x => x.Elements().Count() != 1))
                    {
                        quote.Name = "verse-group";
                        foreach (var p in quote.Descendants("p").ToList())
                        {
                            p.Name = "verse-line";
                        }
                    }
                    ////End Quote creation//

                    ///////Start xref creation
                    foreach (var xref in doc.Descendants("xref").ToList())
                    {
                        if (xref.HasAttributes && xref.Attribute("idref") != null && xref.Attribute("idref").Value.StartsWith("TB"))
                        {
                            var val = xref.Attribute("idref").Value;
                            xref.Attribute("idref").Remove();
                            xref.Add(new XAttribute("ref-type", "table"));
                            xref.Add(new XAttribute("rid", val.Replace("B_", "")));
                        }
                        else if (xref.HasAttributes && xref.Attribute("idref") != null && xref.Attribute("idref").Value.StartsWith("FI"))
                        {
                            var val = xref.Attribute("idref").Value;
                            xref.Attribute("idref").Remove();
                            xref.Add(new XAttribute("ref-type", "fig"));
                            xref.Add(new XAttribute("rid", val.Replace("I-", "")));
                        }
                        else if (xref.HasAttributes && xref.Attribute("idref") != null && xref.Attribute("idref").Value.StartsWith("JR"))
                        {


                            xref.Attribute("idref").Value = xref.Attribute("idref").Value.Replace("rang", "");
                            foreach (var sup in xref.Descendants("sup").ToList())
                            {
                                sup.Value = sup.Value.Replace("rang", "");
                            }

                            var val = xref.Attribute("idref").Value;
                            xref.Attribute("idref").Remove();
                            xref.Add(new XAttribute("ref-type", "bibr"));
                            xref.Add(new XAttribute("rid", val.Replace("JR_", "bibr")));
                        }
                        else if (xref.HasAttributes && xref.Attribute("idref") != null && xref.Attribute("idref").Value.StartsWith("BR"))
                        {
                            xref.Attribute("idref").Value = xref.Attribute("idref").Value.Replace("rang", "");
                            foreach (var sup in xref.Descendants("sup").ToList())
                            {
                                sup.Value = sup.Value.Replace("rang", "");
                            }
                            var val = xref.Attribute("idref").Value;
                            xref.Attribute("idref").Remove();
                            xref.Add(new XAttribute("ref-type", "bibr"));
                            xref.Add(new XAttribute("rid", val.Replace("BR_", "bibr")));
                        }
                        else if (xref.HasAttributes && xref.Attribute("idref") != null && xref.Attribute("idref").Value.StartsWith("OR"))
                        {
                            xref.Attribute("idref").Value = xref.Attribute("idref").Value.Replace("rang", "");
                            foreach (var sup in xref.Descendants("sup").ToList())
                            {
                                sup.Value = sup.Value.Replace("rang", "");
                            }
                            var val = xref.Attribute("idref").Value;
                            xref.Attribute("idref").Remove();
                            xref.Add(new XAttribute("ref-type", "bibr"));
                            xref.Add(new XAttribute("rid", val.Replace("OR_", "bibr")));
                        }
                        else if (xref.HasAttributes && xref.Attribute("idref") != null && xref.Attribute("idref").Value.StartsWith("FN"))
                        {
                            var val = xref.Attribute("idref").Value;
                            xref.Attribute("idref").Remove();
                            xref.Add(new XAttribute("ref-type", "fn"));
                            xref.Add(new XAttribute("rid", val.Replace("N00", "N").Replace("N0", "N")));
                        }
                    }
                    ///////End xref creation
                    foreach (var sec1 in doc.Descendants("body").Descendants("sec1").ToList())
                    {
                        sec1.Name = "sec";
                    }
                    foreach (var sec2 in doc.Descendants("body").Descendants("sec2").ToList())
                    {
                        sec2.Name = "sec";
                    }
                    foreach (var sec3 in doc.Descendants("body").Descendants("sec3").ToList())
                    {
                        sec3.Name = "sec";
                    }
                    foreach (var sec4 in doc.Descendants("body").Descendants("sec4").ToList())
                    {
                        sec4.Name = "sec";
                    }
                    foreach (var sec5 in doc.Descendants("body").Descendants("sec5").ToList())
                    {
                        sec5.Name = "sec";
                    }
                }
                /////////End Body-Matter/////
                if (doc.Descendants("back").Count() == 1)
                {
                    var ftncnt = 0;
                    var ftnotegroup = new XElement("fn-group");
                    foreach (var ftn in doc.Descendants("container").Descendants("footnote").ToList())
                    {
                        ftncnt++;
                        var fn = new XElement("fn", new XAttribute("id", "FN" + ftncnt.ToString()));
                        var p = new XElement("p");
                        fn.Add(p);
                        foreach (var ele in ftn.Nodes().ToList())
                        {
                            if (ele.NodeType == XmlNodeType.Element && ((XElement)ele).Name == "label")
                            {
                                ((XElement)ele).Name = "sup";
                                p.Add(ele);
                            }
                            else
                            {
                                p.Add(ele);
                            }
                        }
                        ftnotegroup.Add(fn);


                    }
                    if (doc.Descendants("back").Descendants("ref-list").Count() > 0 && doc.Descendants("container").Count() > 0)
                    {
                        doc.Descendants("back").Descendants("ref-list").FirstOrDefault().AddBeforeSelf(ftnotegroup);
                    }
                    else if (doc.Descendants("container").Count() > 0)
                    {
                        doc.Descendants("back").FirstOrDefault().Add(ftnotegroup);
                    }
                    doc.Descendants("container").ToList().Remove();



                    ////////Start ref-list////
                    var BackMatter = doc.Descendants("ref-list").Elements().ToList();
                    foreach (var reftag in BackMatter.ToList().Skip(1))
                    {
                        if (reftag.Name.LocalName == "jnref")
                        {
                            foreach (var text in reftag.Descendants().ToList())
                            {
                                if (text.Name.LocalName == "journal-title")
                                {
                                    text.Name = "source";
                                }
                                else if (text.Name.LocalName == "ti")
                                {
                                    text.Name = "article-title";
                                }
                            }
                        }

                        if (reftag.Name.LocalName == "bkref")
                        {
                            foreach (var text in reftag.Descendants().ToList())
                            {
                                if (text.Name.LocalName == "pubname")
                                {
                                    text.Name = "publisher-name";
                                }
                                else if (text.Name.LocalName == "ti")
                                {
                                    text.Name = "article-title";
                                }
                                else if (text.Name == "journal-title")
                                {
                                    text.Name = "source";
                                }
                            }
                        }


                        foreach (var text in reftag.Descendants("date").ToList())
                        {
                            var date = text.Descendants("year").FirstOrDefault();
                            text.AddBeforeSelf(date);
                            text.Remove();
                        }



                        foreach (var text in reftag.Descendants("doi").ToList())
                        {
                            //<pub-id pub-id-type="doi">10.1177/0895904818807317</pub-id>
                            text.Name = "pub-id";
                            text.SetAttributeValue("pub-id-type", "doi");
                            text.Value = text.Value.Replace("doi:", "").Trim();

                        }


                        foreach (var uriText in reftag.Descendants("uri").ToList())
                        {
                            var uritxt = uriText.Value;
                            XElement extlink = new XElement("ext-link", uritxt, new XAttribute(xlink + "href", uritxt), new XAttribute("ext-link-type", "uri"));
                            uriText.AddAfterSelf(extlink);
                            uriText.Remove();

                        }
                        foreach (var uriText in reftag.Descendants("url").ToList())
                        {
                            var uritxt = uriText.Value;
                            XElement extlink = new XElement("ext-link", uritxt, new XAttribute(xlink + "href", uritxt), new XAttribute("ext-link-type", "uri"));
                            uriText.AddAfterSelf(extlink);
                            uriText.Remove();

                        }





                        XElement mixedcite = null;
                        //-<mixed-citation publication-type="journal">    -<person-group person-group-type = "author" >
                        if (reftag.Name.LocalName == "jnref")
                        {
                            reftag.Name = "ref";
                            if (reftag.Attribute("id") != null)
                            {
                                string refid = reftag.Attribute("id").Value.Replace("JR_", "bibr").Replace("BR_", "bibr").Replace("OR_", "bibr");
                                reftag.RemoveAttributes();
                                reftag.SetAttributeValue("id", refid);

                            }

                            mixedcite = new XElement("mixed-citation", new XAttribute("publication-type", "journal"));


                            foreach (var ele in reftag.Nodes().ToList())
                            {
                                mixedcite.Add(ele);
                                ele.Remove();
                            }
                            reftag.AddFirst(mixedcite);

                        }
                        else if (reftag.Name.LocalName == "bkref")
                        {
                            reftag.Name = "ref";
                            if (reftag.Attribute("id") != null)
                            {
                                string refid = reftag.Attribute("id").Value.Replace("JR_", "bibr").Replace("BR_", "bibr").Replace("OR_", "bibr");
                                reftag.RemoveAttributes();
                                reftag.SetAttributeValue("id", refid);

                            }
                            mixedcite = new XElement("mixed-citation", new XAttribute("publication-type", "book"));
                            foreach (var ele in reftag.Nodes().ToList())
                            {
                                mixedcite.Add(ele);
                                ele.Remove();
                            }
                            reftag.AddFirst(mixedcite);
                        }
                        else if (reftag.Name.LocalName == "otherref")
                        {
                            reftag.Name = "ref";
                            if (reftag.Attribute("id") != null)
                            {
                                string refid = reftag.Attribute("id").Value.Replace("JR_", "bibr").Replace("BR_", "bibr").Replace("OR_", "bibr");
                                reftag.RemoveAttributes();
                                reftag.SetAttributeValue("id", refid);

                            }
                            mixedcite = new XElement("mixed-citation", new XAttribute("publication-type", "other"));
                            foreach (var ele in reftag.Nodes().ToList())
                            {
                                mixedcite.Add(ele);
                                ele.Remove();
                            }
                            reftag.AddFirst(mixedcite);
                        }

                        List<XElement> Listofauthorname = new List<XElement>();
                        List<XElement> ListofPartauthorname = new List<XElement>();

                        foreach (var author in reftag.Descendants("name").ToList().Where(x => x.Parent != null && x.Parent.Parent != null && x.Parent.Parent.Parent != null && x.Parent.Parent.Parent.Name != "partof").ToList())
                        {
                            if (author.Name.LocalName == "name")
                            {
                                XElement name = new XElement("name");
                                foreach (var authorname in author.Descendants().ToList())
                                {
                                    if (authorname.Name.LocalName == "surname" || authorname.Name.LocalName == "given-names")
                                    {
                                        name.Add(authorname);
                                    }
                                }
                                if (name.Descendants().Count() > 0)
                                {
                                    Listofauthorname.Add(name);
                                }
                            }
                        }

                        foreach (var author in reftag.Descendants("name").ToList().Where(x => x.Parent != null && x.Parent.Parent != null && x.Parent.Parent.Parent != null && x.Parent.Parent.Parent.Name == "partof").ToList())
                        {
                            if (author.Name.LocalName == "name")
                            {
                                XElement name = new XElement("name");
                                foreach (var authorname in author.Descendants().ToList())
                                {
                                    if (authorname.Name.LocalName == "surname")
                                    {
                                        name.Add(authorname);
                                    }
                                    else if (authorname.Name.LocalName == "given-names")
                                    {
                                        name.Add(authorname);
                                    }
                                }
                                if (name.Descendants().Count() > 0)
                                {
                                    ListofPartauthorname.Add(name);
                                }
                            }
                        }

                        if (Listofauthorname.Count() > 0)
                        {
                            XElement personGroup = new XElement("person-group", new XAttribute("person-group-type", "author"));
                            foreach (var names in Listofauthorname.ToList())
                            {
                                personGroup.Add(names);
                            }

                            if (personGroup.Descendants().Count() > 0)
                            {
                                var refcontrib = reftag.Descendants("contrib-group").ToList().FirstOrDefault();
                                refcontrib.AddBeforeSelf(personGroup);
                                foreach (var contribgroup in reftag.Descendants("contrib-group").ToList())
                                {
                                    contribgroup.Remove();
                                }

                            }
                        }

                        if (ListofPartauthorname.Count() > 0)
                        {
                            XElement personGroup = new XElement("person-group", new XAttribute("person-group-type", "editor"));
                            foreach (var names in ListofPartauthorname.ToList())
                            {
                                personGroup.Add(names);
                            }

                            if (personGroup.Descendants().Count() > 0)
                            {
                                var refcontrib = reftag.Descendants("person-group").ToList().Where(x => x.Attribute("person-group-type") != null && x.Attribute("person-group-type").Value == "author").FirstOrDefault();
                                refcontrib.AddAfterSelf(personGroup);
                                foreach (var contribgroup in reftag.Descendants("partof").ToList())
                                {
                                    contribgroup.Remove();
                                }

                            }
                        }

                        var personeditor = reftag.Descendants("person-group").ToList().Where(x => x.Attribute("person-group-type") != null && x.Attribute("person-group-type").Value == "editor").FirstOrDefault();

                        if (personeditor != null)
                        {
                            foreach (var name in personeditor.Descendants("name").ToList())
                            {
                                var surname = name.Descendants("surname").ToList().FirstOrDefault();
                                var givenname = name.Descendants("given-names").ToList().FirstOrDefault();

                                if (surname != null && givenname != null)
                                {
                                    foreach (var n in name.Elements().ToList())
                                    {
                                        if (n.Name == "surname")
                                        {
                                            n.Remove();
                                        }
                                        else if (n.Name == "given-names")
                                        {
                                            n.Remove();
                                        }

                                    }
                                    name.Add(surname);
                                    name.Add(givenname);
                                }
                            }

                        }
                        foreach (var text in reftag.Nodes().OfType<XText>().ToList())
                        {
                            if (text.Value.Trim() == ", &" || text.Value.Trim() == ", , &" || text.Value.Trim() == ", , , &" || text.Value.Trim() == ", &")
                            {
                                text.Value = Regex.Replace(text.Value, @"([\,\&\s]+)", "", RegexOptions.IgnoreCase);
                            }

                        }
                        foreach (var nodes in reftag.Descendants("mixed-citation").Nodes().ToList())
                        {
                            if (nodes.NodeType.ToString() == "Text")
                            {
                                ((System.Xml.Linq.XText)(nodes)).Value = ((System.Xml.Linq.XText)(nodes)).Value.Replace(", ", "").Replace("&", "");
                            }

                            else if (nodes.NodeType.ToString() == "Element" && ((System.Xml.Linq.XElement)(nodes)).Name.LocalName == "year")
                            {
                                break;
                            }
                            else if (nodes.NodeType.ToString() == "Element" && ((System.Xml.Linq.XElement)(nodes)).Name.LocalName == "txt")
                            {
                                if (((System.Xml.Linq.XElement)(nodes)).Value == "&")
                                {
                                    nodes.Remove();
                                }
                            }

                        }

                        foreach (var itc in reftag.Descendants("i").ToList())
                        {
                            XText italictext = new XText("");
                            italictext.Value = itc.Value;
                            itc.ReplaceWith(italictext);

                        }


                        foreach (var nodes in reftag.Descendants().ToList().Where(x => x.Descendants().FirstOrDefault() != null && x.Descendants().FirstOrDefault().Name.LocalName == "i").ToList())
                        {

                            nodes.Value = nodes.Value;

                        }



                        foreach (var nodes in reftag.Descendants("contrib-group").ToList())
                        {
                            if (nodes.Descendants("collab").ToList().Count() > 0)
                            {

                                var orgnizationName = nodes.Descendants("collab-name").ToList().FirstOrDefault().Value;
                                //<collab collab-type="author">ACARA</collab>
                                if (!string.IsNullOrEmpty(orgnizationName))
                                {
                                    XElement collabele = new XElement("collab", orgnizationName, new XAttribute("collab-type", "author"));
                                    nodes.AddBeforeSelf(collabele);
                                    nodes.Remove();
                                }

                            }

                        }

                        foreach (var nodes in reftag.Descendants("mixed-citation").ToList())
                        {
                            if (nodes.Descendants("ext-link").Count() > 0)
                            {
                                nodes.Attribute("publication-type").Value = "web";
                            }


                        }
                    }


                    ///End ref-list///////





                }
                var seccnt = 0;
                foreach (var sec in doc.Descendants("sec").ToList())
                {
                    seccnt++;

                    sec.Add(new XAttribute("id", "section" + seccnt.ToString()));

                }
                foreach (var sup in doc.Descendants("sup").ToList())
                {
                    sup.Attributes().ToList().Remove();
                    foreach (var x in sup.Nodes())
                    {
                        if (x.NodeType == System.Xml.XmlNodeType.Comment)
                        {
                            var newtext = new XText(((XComment)x).Value);
                            x.Remove();
                            sup.Add(newtext);
                        }
                    }
                }
                foreach (var listitem in doc.Descendants("listitem").ToList())
                {
                    listitem.Name = "list-item";
                }
                foreach (var i in doc.Descendants("i").ToList())
                {
                    i.Name = "italic";
                    if (i.NextNode != null && i.NextNode.NodeType == XmlNodeType.Text)
                    {
                        if (!((XText)i.NextNode).Value.StartsWith(" "))
                        {
                            ((XText)i.NextNode).Value = " " + ((XText)i.NextNode).Value;
                        }
                    }
                    if (i.Value == ". ")
                    {
                        i.Nodes().ToList().ForEach(x => i.AddBeforeSelf(x));
                        i.Remove();
                    }
                }
                foreach (var b in doc.Descendants("b").ToList())
                {
                    b.Name = "bold";
                    if (b.NextNode != null && b.NextNode.NodeType == XmlNodeType.Text)
                    {
                        if (!((XText)b.NextNode).Value.StartsWith(" "))
                        {
                            ((XText)b.NextNode).Value = " " + ((XText)b.NextNode).Value;
                        }
                    }
                }
                foreach (var bi in doc.Descendants("bi").ToList())
                {

                    if (bi.Value.Trim() == "")
                    {
                        bi.Remove();
                    }
                }

                foreach (var emph in doc.Descendants("emph").ToList())
                {
                    if (emph.HasAttributes && emph.Attribute("type") != null && emph.Attribute("type").Value == "bold")
                    {
                        emph.Name = "bold";
                        emph.Attributes().Remove();
                    }
                    else if (emph.HasAttributes && emph.Attribute("type") != null && emph.Attribute("type").Value == "italic")
                    {
                        emph.Name = "italic";
                        emph.Attributes().Remove();
                    }
                    if (emph.HasAttributes && emph.Attribute("type") != null && emph.Attribute("type").Value == "sc")
                    {
                        emph.Name = "sc";
                        emph.Attributes().Remove();
                    }
                    if (emph.Value.Trim() == "")
                    {
                        emph.Remove();
                    }
                }

                foreach (var aunotes in doc.Descendants("author-notes").ToList())
                {
                    int correspcnt = 0;
                    foreach (var corresp in aunotes.Descendants("corresp").ToList())
                    {
                        correspcnt++;
                        var newcorresp = new XElement("corresp");
                        if (correspcnt == 1)
                        {
                            newcorresp = corresp;
                            newcorresp.Value = newcorresp.Value.TrimStart(':').Replace(",,", ",");
                            corresp.Attributes().ToList().ForEach(x =>
                            {
                                if (newcorresp.Attribute(x.Name) == null)
                                    newcorresp.Add(x);
                            });
                            corresp.AddBeforeSelf(newcorresp);
                            corresp.Remove();
                        }
                        else
                        {
                            foreach (var node in corresp.Nodes().ToList())
                            {
                                newcorresp.Add(node);
                            }
                            corresp.Remove();
                        }
                    }
                }
                foreach (var txt in doc.Descendants("txt").ToList())
                {
                    if (txt.Parent != null && txt.Parent.Name == "name" && txt.Parent.Parent != null && txt.Parent.Parent.Name == "contrib")
                    {
                        txt.Remove();
                        continue;
                    }
                    foreach (var txtnode in txt.Nodes().ToList())
                    {
                        txt.AddBeforeSelf(txtnode);
                    }
                    txt.Remove();
                }
                foreach (var txt in doc.Descendants("dummy").ToList())
                {
                    foreach (var txtnode in txt.Nodes().ToList())
                    {
                        txt.AddBeforeSelf(txtnode);
                    }
                    txt.Remove();
                }
                foreach (var txt in doc.Descendants("symbol").ToList())
                {
                    foreach (var txtnode in txt.Nodes().ToList())
                    {
                        txt.AddBeforeSelf(txtnode);
                    }
                    txt.Remove();
                }
                foreach (var txt in doc.Descendants("contrib").Nodes().Where(x => x.NodeType == XmlNodeType.Text).ToList())
                {
                    if (txt.Parent != null && txt.Parent.Name == "contrib" && txt.Parent.Parent != null && txt.Parent.Parent.Name == "contrib-group")
                        txt.Remove();
                }
                foreach (var txt in doc.Descendants("fig").Descendants("label").Nodes().Where(x => x.NodeType == XmlNodeType.Text).ToList())
                {
                    ((XText)txt).Value = ((XText)txt).Value.Trim();
                }

                foreach (var p in doc.Descendants("p").ToList())
                {
                    if (p.HasAttributes)
                    {
                        p.Attributes().ToList().ForEach(x => x.Remove());
                    }
                    if (p.Nodes().ToList().Count > 0 && p.Nodes().ToList().FirstOrDefault().NodeType == XmlNodeType.Element)
                    {
                        continue;
                    }
                    int textcnt = 0;
                    foreach (var txt in p.Nodes().Where(x => x.NodeType == XmlNodeType.Text).ToList())
                    {

                        textcnt++;
                        if (textcnt == 1 && ((XText)txt).Value.StartsWith(" "))
                        {
                            ((XText)txt).Value = ((XText)txt).Value.TrimStart();
                        }
                        if (textcnt == doc.Descendants("p").Nodes().Where(x => x.NodeType == XmlNodeType.Text).ToList().Count() && ((XText)txt).Value.EndsWith(" "))
                        {
                            ((XText)txt).Value = ((XText)txt).Value.TrimEnd();
                        }
                    }
                }

                foreach (var p in doc.Descendants().Where(x => (x.Name == "boxed-text" || x.Name == "p")).ToList())
                {
                    var xele = new XElement("sec");
                    if (p.PreviousNode != null && p.PreviousNode.NodeType == XmlNodeType.Element && ((XElement)p.PreviousNode).Name == "sec")
                    {
                        xele = ((XElement)p.PreviousNode);
                        var newp = p;
                        xele.Add(newp);
                        p.Remove();
                    }

                }
                foreach (var email in doc.Descendants("email").ToList())
                {
                    email.Attributes().Remove();
                }
                foreach (var rrh in doc.Descendants("rrh").ToList())
                {
                    rrh.Remove();
                }
                foreach (var articleca in doc.Descendants("article-categories").Skip(1).ToList())
                {
                    articleca.Remove();
                }
                foreach (var lang in doc.Descendants("language").ToList())
                {
                    lang.Remove();
                }
                foreach (var disp in doc.Descendants("disp-formula-group").ToList())
                {
                    disp.Remove();
                }
                foreach (var identifier in doc.Descendants("identifier").Where(x => x.HasAttributes && x.Attribute("value") != null && x.Attribute("value").Value == "ORCID").ToList())
                {
                    var contribid = new XElement("contrib-id", new XAttribute("contrib-id-type", "orcid"));
                    contribid.Value = "https://orcid.org/" + identifier.Value;
                    if (identifier.Parent != null && identifier.Parent.Descendants("name").Count() > 0)
                    {
                        identifier.Parent.Descendants("name").FirstOrDefault().AddBeforeSelf(contribid);
                    }
                    identifier.Remove();
                }
                foreach (var xref in doc.Descendants("xref").Where(x => x.HasAttributes && x.Attribute("idref") != null && x.Attribute("idref").Value.StartsWith("CO_")).ToList())
                {
                    xref.Remove();
                }
                foreach (var license in doc.Descendants("license").ToList())
                {
                    license.Remove();
                }
                foreach (var iconflict in doc.Descendants("iconflict").ToList())
                {
                    var newfn = new XElement("fn");
                    foreach (var ic in iconflict.Elements())
                    {
                        if (ic.Name == "title")
                        {
                            var newlabel = new XElement("label");
                            newlabel.Value = ic.Value;
                            newfn.Add(newlabel);
                        }
                        else if (ic.Name == "p")
                        {

                            newfn.Add(ic);
                        }
                    }
                    iconflict.Remove();
                    if (doc.Descendants("fn-group").Count() > 0 && doc.Descendants("fn-group").FirstOrDefault().Elements("fn").Count() > 0)
                    {
                        var footnotecnt = doc.Descendants("fn-group").FirstOrDefault().Elements("fn").Count();
                        newfn.Add(new XAttribute("id", "FN" + footnotecnt.ToString()));
                        newfn.Add(new XAttribute("fn-type", "conflict"));
                        doc.Descendants("fn-group").Elements("fn").FirstOrDefault().AddBeforeSelf(newfn);

                    }
                    else
                    {
                        if (doc.Descendants("back").Descendants("ref-list").Count() > 0)
                        {
                            var ftnotegroup = new XElement("fn-group");
                            newfn.Add(new XAttribute("id", "FN1"));
                            newfn.Add(new XAttribute("fn-type", "conflict"));
                            ftnotegroup.Add(newfn);
                            doc.Descendants("back").Descendants("ref-list").FirstOrDefault().AddBeforeSelf(ftnotegroup);
                        }
                    }
                }
                foreach (var seri in doc.Descendants("mixed-citation").Descendants("serie").ToList())
                {
                    foreach (var seriele in seri.Descendants())
                    {
                        if (seriele.Name == "volume")
                        {
                            seri.AddAfterSelf(seriele);
                            seri.Remove();
                            break;
                        }
                    }
                }
                foreach (var part in doc.Descendants("mixed-citation").Descendants("partof"))
                {
                    part.Name = "source";
                    part.Value = part.Value;
                }


                //////Start Math changes////
                foreach (var formula in doc.Descendants("formula").ToList())
                {
                    if (formula.HasAttributes && formula.Attribute("type") != null && formula.Attribute("type").Value == "inline")//////Inline EQ
                    {
                        var id = "";
                        if (formula.Attribute("id") != null)
                        {
                            id = formula.Attribute("id").Value;
                        }
                        formula.Attributes().Remove();
                        formula.Name = "inline-formula";
                        var alternatives = new XElement("alternatives");
                        formula.Elements().ToList().ForEach(x => alternatives.Add(x));
                        if (formula.Elements().Count() > 0)
                        {
                            formula.Elements().FirstOrDefault().AddAfterSelf(alternatives);
                            formula.Elements().FirstOrDefault().Remove();
                        }
                        foreach (var sem in formula.Descendants().Where(x => x.Name.LocalName == "semantics").ToList())
                        {
                            sem.Elements().ToList().ForEach(x => sem.AddBeforeSelf(x));
                            sem.Remove();
                        }
                        foreach (var mathchild in alternatives.Descendants().ToList())
                        {
                            if (mathchild.Name.LocalName == "math")
                            {
                                mathchild.Attributes().Remove();
                            }
                            mathchild.Name = xmml + mathchild.Name.LocalName;
                            if (mathchild.Name.LocalName == "annotation")
                            {
                                mathchild.Remove();
                            }
                        }
                        foreach (var mathchild in alternatives.Descendants().Where(x => x.Name.LocalName == "mn" && x.HasElements).ToList())
                        {
                            if (mathchild.Parent != null)
                            {
                                foreach (var child in mathchild.Nodes().ToList())
                                {

                                    if (child.NodeType == XmlNodeType.Text && ((XText)child).Value != "(" && ((XText)child).Value != ")")
                                    {
                                        var mn = new XElement(xmml + "mn");
                                        mn.Add(child);
                                        mathchild.AddBeforeSelf(mn);

                                    }
                                    else
                                    {
                                        var newxmlele = child;
                                        if (mathchild != null)
                                        {
                                            mathchild.AddBeforeSelf(newxmlele);
                                        }
                                    }
                                }
                                mathchild.Remove();
                            }

                        }

                        //if (alternatives.HasElements)
                        //{
                        //    var inlinegraphic = new XElement("inline-graphic");
                        //    inlinegraphic.Add(new XAttribute(xlink + "href", id + ".gif"));
                        //    alternatives.Add(inlinegraphic);
                        //}
                        if (formula.NextNode != null && formula.NextNode.NodeType == XmlNodeType.Element)
                        {
                            if (((XElement)formula.NextNode).Name == "inline-formula")
                            {
                                var inlinegraphic = new XElement("inline-graphic");
                                inlinegraphic.Add(new XAttribute(xlink + "href", id + ".gif"));
                                if (alternatives.HasElements)
                                {
                                    alternatives.Add(inlinegraphic);
                                }
                                    ((XElement)formula.NextNode).Remove();
                            }
                        }
                    }
                    else if (formula.HasAttributes && formula.Attribute("type") != null && formula.Attribute("type").Value == "display")/////Display EQ
                    {
                        var id = "";
                        if (formula.Attribute("id") != null)
                        {
                            id = formula.Attribute("id").Value;
                        }
                        formula.Attributes().Remove();
                        formula.Name = "disp-formula";
                        formula.Add(new XAttribute("id", id));

                        var alternatives = new XElement("alternatives");
                        formula.Elements().ToList().ForEach(x => alternatives.Add(x));
                        if (formula.Elements().Count() > 0)
                        {
                            formula.Elements().FirstOrDefault().AddAfterSelf(alternatives);
                            formula.Elements().FirstOrDefault().Remove();
                        }
                        foreach (var sem in formula.Descendants().Where(x => x.Name.LocalName == "semantics").ToList())
                        {
                            sem.Elements().ToList().ForEach(x => sem.AddBeforeSelf(x));
                            sem.Remove();
                        }
                        foreach (var mathchild in alternatives.Descendants().ToList())
                        {
                            if (mathchild.Name.LocalName == "math")
                            {
                                mathchild.Attributes().Remove();
                                mathchild.Add(new XAttribute("display", "block"));
                            }
                            mathchild.Name = xmml + mathchild.Name.LocalName;

                            if (mathchild.Name.LocalName == "annotation")
                            {
                                mathchild.Remove();
                            }
                        }
                        foreach (var mathchild in alternatives.Descendants().Where(x => x.Name.LocalName == "mn" && x.HasElements).ToList())
                        {
                            if (mathchild.Parent != null)
                            {
                                foreach (var child in mathchild.Nodes().ToList())
                                {

                                    if (child.NodeType == XmlNodeType.Text && ((XText)child).Value != "(" && ((XText)child).Value != ")")
                                    {
                                        var mn = new XElement(xmml + "mn");
                                        mn.Add(child);
                                        mathchild.AddBeforeSelf(mn);

                                    }
                                    else
                                    {
                                        var newxmlele = child;
                                        if (mathchild != null)
                                        {
                                            mathchild.AddBeforeSelf(newxmlele);
                                        }
                                    }
                                }
                                mathchild.Remove();
                            }

                        }

                        if (alternatives.HasElements)
                        {
                            var graphic = new XElement("graphic");
                            graphic.Add(new XAttribute(xlink + "href", id + ".gif"));
                            alternatives.Add(graphic);
                        }

                    }
                }
                doc.Descendants("td").ToList().ForEach(x =>
                {
                    x.Attributes().ToList().ForEach(y =>
                    {
                        if (y.Name == "align" && y.Value == "both")
                        {
                            y.Value = "left";
                        }
                    });

                });
                doc.Descendants("uri").ToList().ForEach(x =>
                {
                    x.Attributes().ToList().ForEach(y =>
                    {
                        if (y.Name == "href")
                        {
                            y.Remove();
                        }
                    });

                });
                var afffnnode = doc.Descendants("front").ToList().Descendants("xref").ToList().Where(x => x.HasAttributes && x.Attribute("ref-type") != null && x.Attribute("ref-type").Value == "fn").ToList();
                if (afffnnode != null)
                {
                    foreach (var fn in afffnnode.ToList())
                    {
                        var num = fn.Value.Trim();
                        fn.SetAttributeValue("ref-type", "aff");
                        if (num.Length == 1)
                        {
                            fn.SetAttributeValue("rid", "aff" + "0" + num.Trim());
                        }
                        else
                        {
                            fn.SetAttributeValue("rid", "aff" + num.Trim());
                        }
                        fn.Value = num.Trim();

                    }
                }


                doctype = new XDocumentType("article", "-//NLM//DTD JATS (Z39.96) Journal Publishing DTD v1.1d1 20130915//EN", "JATS-journalpublishing1.dtd", null);
                xdoc1 = new XDocument(doctype, doc.Root);
                //return xdoc1;
              
            }
            return xdoc1;
        }

    }
}
