﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MultiInstanceJournalsXMLconversion
{
    class Program
    {
        static void Main(string[] args)
        {


            ////form 06-01-2019 Schema 3.0 update code

           // string filepath = @"C:\3CMAutomation\JournalXMLConversion\Process\48380";

            string filepath = args[0];            
            try
            {
                Start(filepath);
            }
            catch (Exception ex)
            {
                string folderpath = filepath.Substring(filepath.LastIndexOf("\\"));

                //folderpath = folderpath.Substring(folderpath.LastIndexOf("\\"));

                string strErrorFileName = null;
                string strProcessFolder = null;

                if (GlobalMethods.StrOutFolder != null || GlobalMethods.StrOutFolder != "")
                {
                    strErrorFileName = GlobalMethods.StrOutFolder;
                    if (folderpath.StartsWith("\\"))
                        strErrorFileName = strErrorFileName + folderpath;
                    else
                        strErrorFileName = strErrorFileName + "\\" + folderpath;

                    if (Directory.Exists(strErrorFileName) == false)
                        Directory.CreateDirectory(strErrorFileName);

                    if (strErrorFileName.EndsWith("\\") == false)
                        strErrorFileName = strErrorFileName + "\\";

                    strErrorFileName = strErrorFileName + "Error.log";

                    // Generate Error log and the move the error log in the out folder
                    StreamWriter sw = new StreamWriter(strErrorFileName);
                    sw.WriteLine(ex.ToString());
                    sw.WriteLine("Journals XMLConversion");
                    sw.WriteLine("Exception in Processing the document. Please consult 3CM Administrator.");
                    sw.Close();

                }

                strProcessFolder = GlobalMethods.StrProcessFolder;

                if (folderpath.StartsWith("\\"))
                    strProcessFolder = strProcessFolder + folderpath;
                else
                    strProcessFolder = strProcessFolder + "\\" + folderpath;

                Directory.Delete(strProcessFolder, true);
            }
        }

        public static void Start(string strDocumentName)
        {
            //09-07-2018
            GlobalMethods.StrInFolder = ConfigurationManager.AppSettings.Get("XMLConversionIN");
            GlobalMethods.StrOutFolder = ConfigurationManager.AppSettings.Get("XMLConversionOUT");
            GlobalMethods.StrProcessFolder = ConfigurationManager.AppSettings.Get("XMLConversionPROCESS");
            object OutputFilename = null;

            FileInfo ff = null;

            GlobalMethods.strJobTransId = null;
            GlobalMethods.strDocumentType = null;
            GlobalMethods.strServiceType = null;

            DirectoryInfo Dir = new DirectoryInfo(strDocumentName);

            FileInfo[] filesForProcess = Dir.GetFiles();
            foreach (var files in filesForProcess)
            {
                if (files.Extension == ".xml")
                {
                    /// read XML file for document custom properties
                    GlobalMethods.ReadCustomPropertiesXML(files.FullName);
                }
                if (files.Extension == ".docx")
                {
                    if (!files.Name.StartsWith("~$"))
                    {
                        ff = files;
                    }
                }
            }

            if (ff == null)
            {
                Console.WriteLine("Job name: " + ff.Name + " ," + "Job ID: " + ff.Directory.Name + " ," + "Processing start time:" + DateTime.Now.ToString("dd-MM-yyyy hh:mm:ss"));

                string strErrorFileName = null;

                if (GlobalMethods.StrOutFolder != null && GlobalMethods.StrOutFolder != "")
                {
                    strErrorFileName = GlobalMethods.StrOutFolder + "\\" + Dir.Name;

                    if (Directory.Exists(strErrorFileName) == false)
                        Directory.CreateDirectory(strErrorFileName);

                    if (strErrorFileName.EndsWith("\\") == false)
                        strErrorFileName = strErrorFileName + "\\";

                    strErrorFileName = strErrorFileName + "Error.log";

                    // Generate Error log and the move the error log in the out folder
                    StreamWriter sw = new StreamWriter(strErrorFileName);
                    sw.WriteLine("Document not found in Journals XMLConversion Input folder. Please consult 3CM Administrator.");
                    sw.Close();
                }

                // Remove the document from Process folder

                goto EndProcess;
            }

            if (GlobalMethods.strJobTransId == null || GlobalMethods.strJobTransId == "")
            {
                string strErrorFileName = null;

                if (GlobalMethods.StrOutFolder != null && GlobalMethods.StrOutFolder != "")
                {
                    strErrorFileName = GlobalMethods.StrOutFolder + "\\" + ff.Directory.Name;

                    if (Directory.Exists(strErrorFileName) == false)
                        Directory.CreateDirectory(strErrorFileName);

                    if (strErrorFileName.EndsWith("\\") == false)
                        strErrorFileName = strErrorFileName + "\\";

                    // Generate Error log and the move the error log in the out folder
                    StreamWriter sw = new StreamWriter(strErrorFileName);
                    sw.WriteLine("Journals XMLConversion");
                    sw.WriteLine("Either the Job Transaction ID is missing in the document properties or is empty. Please consult 3CM Administrator.");
                    sw.Close();
                }

                // Remove the document from Process folder

                goto EndProcess;
            }

            if (GlobalMethods.strDocumentType == null || GlobalMethods.strDocumentType == "")
            {
                string strErrorFileName = null;

                if (GlobalMethods.StrOutFolder != null && GlobalMethods.StrOutFolder != "")
                {
                    strErrorFileName = GlobalMethods.StrOutFolder + "\\" + GlobalMethods.strJobTransId;

                    if (Directory.Exists(strErrorFileName) == false)
                        Directory.CreateDirectory(strErrorFileName);

                    if (strErrorFileName.EndsWith("\\") == false)
                        strErrorFileName = strErrorFileName + "\\";

                    // Generate Error log and the move the error log in the out folder
                    StreamWriter sw = new StreamWriter(strErrorFileName);
                    sw.WriteLine("Journals XMLConversion");
                    sw.WriteLine("Either the DocumentType is missing in the document properties or is empty. Please consult 3CM Administrator.");
                    sw.Close();
                }

                // Remove the document from Process folder

                goto EndProcess;
            }

            if (GlobalMethods.strServiceType == null || GlobalMethods.strServiceType == "")
            {
                string strErrorFileName = null;

                if (GlobalMethods.StrOutFolder != null && GlobalMethods.StrOutFolder != "")
                {
                    strErrorFileName = GlobalMethods.StrOutFolder + "\\" + GlobalMethods.strJobTransId;

                    if (Directory.Exists(strErrorFileName) == false)
                        Directory.CreateDirectory(strErrorFileName);

                    if (strErrorFileName.EndsWith("\\") == false)
                        strErrorFileName = strErrorFileName + "\\";

                    // Generate Error log and the move the error log in the out folder
                    StreamWriter sw = new StreamWriter(strErrorFileName);
                    sw.WriteLine("Journals XMLConversion");
                    sw.WriteLine("Either the ServiceType is missing in the document properties or is empty. Please consult 3CM Administrator.");
                    sw.Close();
                }

                // Remove the document from Process folder

                goto EndProcess;
            }
            //09-07-2018

            OutputFilename = Word2XMLConversion.ConvertToXML(ff.FullName);

            if (OutputFilename != null)
            {
                if (File.Exists(OutputFilename.ToString()))
                {

                    // Move the processed document to out folder
                    FileInfo fout = new FileInfo(OutputFilename.ToString());
                    string strParentDirectory = fout.Directory.Name;
                    string outfile = null;

                    outfile = fout.Name;

                    if (Directory.Exists(GlobalMethods.StrOutFolder + "\\" + strParentDirectory) == false)
                    {
                        Directory.CreateDirectory(GlobalMethods.StrOutFolder + "\\" + strParentDirectory);
                    }

                    outfile = GlobalMethods.StrOutFolder + "\\" + strParentDirectory + "\\" + outfile;

                    // On completion copy the output file in out folder

                    File.Copy(OutputFilename.ToString(), outfile, true);

                    // Delete the files from the Process folder

                    fout.Delete();

                    // Remove unnecessary files and folders from out folder

                    Directory.Delete(GlobalMethods.StrProcessFolder + "\\" + strParentDirectory, true);

                    System.Threading.Thread.Sleep(1000);
                }
            }
            EndProcess:
            {
                if (Directory.Exists(GlobalMethods.StrProcessFolder + "\\" + Dir.Name))
                {
                    Directory.Delete(GlobalMethods.StrProcessFolder + "\\" + Dir.Name);
                }
            }
        }

    }
    //}
    //catch (Exception e)
    //{
    //    var line = Convert.ToInt32(e.StackTrace.Substring(e.StackTrace.LastIndexOf(' ')));
    //    StreamWriter sw = new StreamWriter(GlobalMethods.StrOutFolder + "\\" + "Error.log");
    //    sw.WriteLine(e.Message + " Line no:" + line.ToString());
    //    sw.Close();
    //}

}
