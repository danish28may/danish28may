﻿using Microsoft.Office.Interop.Word;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;
using OpenXmlPowerTools;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;

namespace MultiInstanceJournalsXMLconversion
{
    class EquationConversion
    {
        public static Microsoft.Office.Interop.Word.Application wordApp = null;

        public static void CreateEquationParaIfExist(string newDoc)
        {
            // Check if the Equation text and images exist on the server //
            if (GlobalMethods.ArticlePath != null)
            {
                if (GlobalMethods.ArticlePath != "")
                {
                    DirectoryInfo dd = new DirectoryInfo(GlobalMethods.ArticlePath);
                    GlobalMethods.ArticleImagePath = dd.Parent.FullName;

                    if (GlobalMethods.ArticleImagePath.EndsWith("\\"))
                        GlobalMethods.ArticleImagePath = GlobalMethods.ArticleImagePath + "Images\\Equations";
                    else
                        GlobalMethods.ArticleImagePath = GlobalMethods.ArticleImagePath + "\\Images\\Equations";
                }
            }

            if (Directory.Exists(GlobalMethods.ArticleImagePath) == false)
                return;

            string[] filePaths = Directory.GetFiles(GlobalMethods.ArticleImagePath, "*.txt");

            if (filePaths.Count() <= 0)
                return;

            using (DocumentFormat.OpenXml.Packaging.WordprocessingDocument WPD = WordprocessingDocument
                 .Open(newDoc, true))
            {
                SimplifyMarkupSettings settings = new SimplifyMarkupSettings
                {
                    NormalizeXml = true,
                    RemoveHyperlinks = false,
                    RemoveComments = false,
                    RemoveContentControls = true,
                    RemoveLastRenderedPageBreak = true,
                    RemovePermissions = true,
                    RemoveProof = true,
                    RemoveRsidInfo = true,
                    RemoveSmartTags = true,
                    RemoveSoftHyphens = false,
                    ReplaceTabsWithSpaces = true,

                    RemoveEndAndFootNotes = false,
                    RemoveFieldCodes = true,
                    AcceptRevisions = true,
                    RemoveBookmarks = true,
                    RemoveGoBackBookmark = true,
                    RemoveWebHidden = true,
                    RemoveMarkupForDocumentComparison = true,
                };

                MarkupSimplifier.SimplifyMarkup(WPD, settings);

                DocumentFormat.OpenXml.Packaging.MainDocumentPart MDP = WPD.MainDocumentPart;

                DocumentFormat.OpenXml.Wordprocessing.Document D = MDP.Document;

                int EquationCount = 0;

                foreach (DocumentFormat.OpenXml.Wordprocessing.Paragraph P in D.Descendants<DocumentFormat.OpenXml.Wordprocessing.Paragraph>().ToList())
                {
                    if (P.HasChildren == true)
                    {
                        if (P.ParagraphProperties != null)
                        {
                            if (P.ParagraphProperties.ParagraphStyleId != null)
                            {
                                if (P.ParagraphProperties.ParagraphStyleId.Val == "EQ")
                                {
                                    if(filePaths.Count() >= EquationCount)
                                    {
                                        // Insert new Paragraph and set EQ style and delete the existing paragraph //
                                        DocumentFormat.OpenXml.Wordprocessing.Paragraph pp = new DocumentFormat.OpenXml.Wordprocessing.Paragraph(new ParagraphProperties());
                                        pp.ParagraphProperties.ParagraphStyleId = new ParagraphStyleId();

                                        pp.ParagraphProperties.ParagraphStyleId.Val = "EQ";

                                        FileInfo ff = new FileInfo(filePaths[EquationCount]);

                                        Run r = new Run(new Text(ff.Name));

                                        pp.Append(r);

                                        P.InsertBeforeSelf<DocumentFormat.OpenXml.Wordprocessing.Paragraph>(pp);

                                        P.Remove();
                                    }

                                    EquationCount++;
                                }
                            }
                        }
                    }
                }
                D.Save();
            }

            try
            {
                // // Create and Place Equation object within word document //

                Microsoft.Office.Interop.Word.Document mdoc = null;

                // Load Word Document Content
                mdoc = LoadWordDocument(newDoc);

                int nIndex = 0;
                string strSearchText = "";

                for (nIndex = 0; nIndex < filePaths.Length; nIndex++)
                {
                    FileInfo ff = new FileInfo(filePaths[nIndex]);
                    strSearchText = ff.Name;

                    SearchAndReplace(mdoc, strSearchText, "", "EQ", "", "", false, false, false, false, ff.FullName);
                }

                object oMissing = System.Reflection.Missing.Value;

                object saveChanges = WdSaveOptions.wdSaveChanges;
                ((_Document)mdoc).Close(ref saveChanges, ref oMissing, ref oMissing);
                mdoc = null;
            }
            catch(Exception ex)
            {

            }
            finally
            {
                if (wordApp != null)
                {
                    object oMissing = System.Reflection.Missing.Value;
                    ((_Application)wordApp).Quit(ref oMissing, ref oMissing, ref oMissing);
                    wordApp = null;
                }
            }

            
        }

        public static Microsoft.Office.Interop.Word.Document LoadWordDocument(string strDoc)
        {
            object oMissing = System.Reflection.Missing.Value;
            wordApp = new Microsoft.Office.Interop.Word.Application();

            try
            {
                wordApp.Visible = false;
                wordApp.ScreenUpdating = false;

                Object filename = (Object)strDoc;
                Microsoft.Office.Interop.Word.Document mdoc = wordApp.Documents.Open(ref filename, ref oMissing,
                                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                                                   ref oMissing, ref oMissing, ref oMissing, ref oMissing);

                return mdoc;

            }
            catch (Exception ex)
            {
                return null;
            }
        }



        public static bool SearchAndReplace(Microsoft.Office.Interop.Word.Document oActiveDoc, string strSearchText, string strReplaceText, string strSearchInParaStyle, string strReplaceCharStyle, string strReplaceParaStyle, bool bCharStyle, bool bParaStyle, bool bReplaceAll, bool bGeneralCrosslink, string MathTxtFile)
        {
            // Clear Previous searched settings from Word Find dialog box
            //ClearFindAndReplaceParameters(oActiveDoc); // not required as of now //

            // get the range of the curent paragraph
            Range rngDoc = oActiveDoc.Range();

            // setup Microsoft Word Find based upon
            // Regular Expression Match
            rngDoc.Find.ClearFormatting();
            rngDoc.Find.Replacement.ClearFormatting();
            rngDoc.Find.Forward = true;

            if (strSearchText != "")
                rngDoc.Find.Text = strSearchText;

            if (strReplaceText != "")
                rngDoc.Find.Replacement.Text = strReplaceText;

            if (bReplaceAll == true && bGeneralCrosslink == true)
            {
                if (strSearchInParaStyle != "")
                    rngDoc.Find.set_Style(strSearchInParaStyle);

                if (bParaStyle == true)
                    rngDoc.Find.Replacement.set_Style(strReplaceParaStyle);

                if (bCharStyle == true)
                    rngDoc.Find.Replacement.set_Style(strReplaceCharStyle);
            }

            if (bGeneralCrosslink == false)
            {
                if (strSearchInParaStyle != "")
                    rngDoc.Find.set_Style(strSearchInParaStyle);

                if (bCharStyle == true)
                    rngDoc.Find.Replacement.set_Style(strReplaceCharStyle);

                if (bParaStyle == true)
                    rngDoc.Find.Replacement.set_Style(strReplaceParaStyle);
            }

            // make search case sensitive
            object caseSensitive = "0";
            object missingValue = Type.Missing;

            rngDoc.Find.Wrap = Microsoft.Office.Interop.Word.WdFindWrap.wdFindStop;

            // wild cards
            object matchWildCards = Type.Missing;

            object replaceAll = Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll;
            //object replaceOne = Microsoft.Office.Interop.Word.WdReplace.wdReplaceOne;


            if (bReplaceAll == true)
            {
                // find the text in the word document
                rngDoc.Find.Execute(ref missingValue, ref missingValue,
                    ref missingValue, ref missingValue, ref missingValue,
                    ref missingValue, ref missingValue, ref missingValue,
                    ref missingValue, ref missingValue, replaceAll,
                    ref missingValue, ref missingValue, ref missingValue,
                    ref missingValue);
            }
            else
            {
                rngDoc.Find.Execute(ref missingValue, ref caseSensitive,
                       ref missingValue, ref missingValue, ref missingValue,
                       ref missingValue, ref missingValue, ref missingValue,
                       ref missingValue, ref missingValue, missingValue,
                       ref missingValue, ref missingValue, ref missingValue,
                       ref missingValue);

                // we found the text
                if (rngDoc.Find.Found)
                {
                    do
                    {
                        if (rngDoc.ParagraphStyle.NameLocal == "EQ")
                        {
                            // Convert the Equation and Replace the clipboard content //

                            System.Threading.Thread.Sleep(500);

                            Process pr = new Process();
                            pr.StartInfo.Arguments = "clip" + " " + "\"" + MathTxtFile + "\"";
                            //pr.StartInfo.Arguments = "TXT";
                            //pr.StartInfo.CreateNoWindow = true;
                            pr.StartInfo.FileName = "ConvertEquations.exe";
                            pr.StartInfo.WindowStyle = ProcessWindowStyle.Normal;
                            pr.Start();
                            pr.WaitForExit();

                            rngDoc.Paste();

                            return true;
                        }
                        else
                        {
                            return false;
                        }

                        //rngDoc.Move();

                        //rngDoc.Find.Execute(ref missingValue, ref caseSensitive,
                        //ref missingValue, ref missingValue, ref missingValue,
                        //ref missingValue, ref missingValue, ref missingValue,
                        //ref missingValue, ref missingValue, missingValue,
                        //ref missingValue, ref missingValue, ref missingValue,
                        //ref missingValue);

                    } while (rngDoc.Find.Found);

                    return false;
                }
            }


            return false;

        }

    }
}
